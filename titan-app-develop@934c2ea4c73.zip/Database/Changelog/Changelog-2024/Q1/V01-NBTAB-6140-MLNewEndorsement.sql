﻿CREATE TABLE [cms].[FullTimeDefinitionType]
(
	[FullTimeDefinitionType_Id] INT NOT NULL PRIMARY KEY,	
    [Name] VARCHAR(100) NOT NULL, 
    [Code] VARCHAR(100) NOT NULL, 
    [Description] VARCHAR(500) NOT NULL,	
    [SortOrder] INT NULL  	
)

GO

-------------------------------------------------------------
MERGE INTO [cms].[FullTimeDefinitionType] AS Target 
USING (VALUES 
  (1, 'FTD15', '15', 'Full Time Definition-15' , 1), 
  (2, 'FTD20', '20', 'Full Time Definition-20' , 2),    
  (3, 'FTD25', '25', 'Full Time Definition-25' , 3),
  (4, 'FTD30', '30', 'Full Time Definition-30' , 4)
) 
AS Source (FullTimeDefinitionType_Id, Name, Code, [Description], SortOrder) 
ON Target.FullTimeDefinitionType_Id = Source.FullTimeDefinitionType_Id
WHEN MATCHED THEN 
UPDATE SET 
	Name = Source.Name,
	Code = Source.Code,
	[Description] = Source.[Description],
	[SortOrder] = Source.[SortOrder] 
WHEN NOT MATCHED BY TARGET THEN 
INSERT (FullTimeDefinitionType_Id, Name, Code ,[Description], SortOrder) 
VALUES (FullTimeDefinitionType_Id, Name, Code ,[Description], SortOrder) 
WHEN NOT MATCHED BY SOURCE THEN 
DELETE;


--------------------------------------------------------------------
ALTER TABLE [cms].EligibilityConfiguration 
ADD [FullTimeDefinitionType_Id] INT NOT NULL CONSTRAINT DF_EligibilityConfiguration_FullTimeDefinitionType_Id DEFAULT 4;

ALTER TABLE [cms].EligibilityConfiguration
ADD CONSTRAINT FK_EligibilityConfiguration_FullTimeDefinitionType
FOREIGN KEY (FullTimeDefinitionType_Id) REFERENCES [cms].FullTimeDefinitionType(FullTimeDefinitionType_Id);