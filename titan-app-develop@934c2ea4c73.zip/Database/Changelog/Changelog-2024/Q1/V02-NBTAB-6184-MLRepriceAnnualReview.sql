﻿ALTER PROCEDURE [cms].[USP_BeginAnnualReview]
	@CaseId int,
	@TitanUserId int
AS
BEGIN

	declare @ClassIdTable TABLE(ClassId INT)

	INSERT INTO @ClassIdTable
		SELECT 
			PDRC.PlanDesignRequestClass_Id 
		FROM [cms].[PlanDesignRequestClass] PDRC
		INNER JOIN [cms].[PlanDesignRequest] PDR 
			ON PDR.PlanDesignRequest_Id = PDRC.PlanDesignRequest_Id 
		WHERE PDR.Case_Id = @CaseId
		AND PDRC.PlanDesignRequestClass_Id  NOT IN 
	   (SELECT PSC.PlanDesignRequestClass_Id FROM [cms].PDRSoldClass PSC 
		INNER JOIN [cms].[PlanDesignRequest] PDR 
			ON PDR.PlanDesignRequest_Id = PSC.PlanDesignRequest_Id 
			WHERE PDR.Case_Id = @CaseId and PSC.IsActive = 1)

		DELETE FROM [cms].[PlanDesignRequestClassLTDCoverage] WHERE PlanDesignRequestClass_Id IN 
		(SELECT ClassId FROM @ClassIdTable) 

		DELETE FROM [cms].[EligibilityConfiguration] WHERE PlanDesignRequestClass_Id IN 
		(SELECT ClassId FROM @ClassIdTable)

		DELETE FROM [cms].[PDRClassCustomizedIDIInsurableIncome] WHERE PlanDesignRequestClass_Id IN 
		(SELECT ClassId FROM @ClassIdTable)

		DELETE FROM [cms].[PlanDesignRequestClassProduct] WHERE PlanDesignRequestClass_Id IN 
		(SELECT ClassId FROM @ClassIdTable) 

		DELETE FROM [cms].[PlanDesignRequestClassRider] WHERE PlanDesignRequestClass_Id IN 
		(SELECT ClassId FROM @ClassIdTable) 

		DELETE FROM [cms].[CaseCompanyRetirementPlan] WHERE PlanDesignRequestClass_Id IN 
		(SELECT ClassId FROM @ClassIdTable)

	  /* Update Plan designrequest class id as null which are not in pdr Sold Class*/
	  UPDATE [cms].[EnrollmentPDRClass] SET PlanDesignRequestClass_Id = NULL WHERE PlanDesignRequestClass_Id IN
	   (SELECT ClassId FROM @ClassIdTable)

	   /* Update Plan designrequest class id as null for the participants which are not in pdr Sold Class */
	  UPDATE [cms].[Participant]  SET PlanDesignRequestClass_Id = NULL WHERE PlanDesignRequestClass_Id IN 
	   (SELECT ClassId FROM @ClassIdTable)
      

	  UPDATE [cms].[Census] SET PlanDesignRequest_Id = NULL WHERE PlanDesignRequest_Id IN 
	  (SELECT PlanDesignRequest_Id FROM [cms].[PlanDesignRequest] 
	  WHERE  Case_Id = @CaseId  AND  PlanDesignRequest_Id  NOT IN 
	  (SELECT PSC.PlanDesignRequest_Id FROM [cms].PDRSoldClass PSC 
	  INNER JOIN [cms].[PlanDesignRequest] PDR ON PDR.PlanDesignRequest_Id = PSC.PlanDesignRequest_Id 
	  WHERE PDR.Case_Id = @CaseId and PSC.IsActive = 1 ))

	  DELETE FROM [cms].[PlanDesignRequestClass]
	  WHERE PlanDesignRequestClass_Id IN (SELECT ClassId FROM @ClassIdTable)

	  DELETE FROM [cms].[PlanDesignRequest]
	  WHERE  Case_Id = @CaseId and  PlanDesignRequest_Id  NOT IN 
		(SELECT PSC.PlanDesignRequest_Id 
		FROM [cms].PDRSoldClass PSC 
		INNER JOIN [cms].[PlanDesignRequest] PDR 
			ON PDR.PlanDesignRequest_Id = PSC.PlanDesignRequest_Id 
			WHERE PDR.Case_Id = @CaseId and PSC.IsActive = 1 )
 
		 DELETE FROM @ClassIdTable

 DECLARE @IsApproved AS bit
       SET @IsApproved = (select IsApproved from [cms].[PricingApprovedStates] PS
				          inner join [cms].[CaseUnderwritingRequest] CR
						  on PS.StateTypeId=CR.StateType_Id
						  where CR.Case_Id=@CaseId and PS.IsActive=1 and (PS.PricingType_Id = 2))	

/* Logic to handle Original case has 2019 PC in the Product Type Field, 
for the Annual Review for the PDR we would default to PC2019, 
if state is not approved (SC)*/

DECLARE @StateTypeId as int
	SET @StateTypeId = (select [StateTypeId] from [cms].[PricingApprovedStates] PS
				          inner join [cms].[CaseUnderwritingRequest] CR
						  on PS.StateTypeId=CR.StateType_Id
						  where CR.Case_Id=@CaseId and PS.IsActive=1 and PS.PricingType_Id = 2)

 DECLARE @IsSC2023Approved AS bit
  SET @IsSC2023Approved = (select IsApproved from [cms].[PricingApprovedStates] where PricingType_Id = 3 and StateTypeId='48')

IF @StateTypeId = 48 and @IsSC2023Approved = 1
BEGIN
	update [cms].[CaseUnderwritingRequest]
	 set PricingType_Id=(Case when (PricingType_Id = 2 or PricingType_Id = 1 or PricingType_Id IS NULL) then 3 													
							  END)
		where Case_Id = @CaseId		

	INSERT INTO [cms].[Log]
					   ([LogDate],[Logger],[Application],[LogLevel],[Message]
					   ,[UserId],[CaseId])
						VALUES
					   (GETDATE(),'USP_BeginAnnualReview','WebApp','Trace','Annual Review Process - StateID=48 and approved.', @TitanUserid, @CaseId)
END
ELSE IF @StateTypeId = 48 and @IsSC2023Approved = 0
BEGIN
	update [cms].[CaseUnderwritingRequest]
	 set PricingType_Id=(Case when (PricingType_Id = 2 or PricingType_Id = 1)  then 2							
							  when (PricingType_Id IS NULL)  then 2
							  END)
		where Case_Id = @CaseId		

	INSERT INTO [cms].[Log]
					   ([LogDate],[Logger],[Application],[LogLevel],[Message]
					   ,[UserId],[CaseId])
						VALUES
					   (GETDATE(),'USP_BeginAnnualReview','WebApp','Trace','Annual Review Process - StateID=48 and unapproved.', @TitanUserid, @CaseId)
	
END
ELSE
BEGIN
	update [cms].[CaseUnderwritingRequest]
	 set PricingType_Id=(Case when (@IsApproved = 1 and (PricingType_Id = 1 OR PricingType_Id IS NULL)) then 3 
							  when ((@IsApproved = 0 OR @IsApproved IS NULL) and (PricingType_Id = 1 OR PricingType_Id IS NULL))  then 1
							  when (@IsApproved = 1 and PricingType_Id = 2) then 3 	
							  when ((@IsApproved = 0 OR @IsApproved IS NULL) and (PricingType_Id = 2))  then 1	
							  when (@IsApproved = 1 and PricingType_Id = 3) then 3 	
							  END)
	where Case_Id=@CaseId
END



 
		DECLARE @oldClassId INT
		DECLARE @PDRSoldClass_Id INT
		DECLARE @RequestId INT
		DECLARE @ClassName VARCHAR(500)

	DECLARE cursorPDRRequest SCROLL CURSOR FOR 

	SELECT DISTINCT			
			PDR.PlanDesignRequest_Id			
		FROM [cms].[PDRSoldClassPlan] PSC
			INNER JOIN [cms].[PDRSoldClass]  PDSC 
				ON PDSC.PDRSoldClass_Id = PSC.PDRSoldClass_Id
			INNER JOIN [cms].[PlanDesignRequest] PDR 
				ON PDR.PlanDesignRequest_Id = PDSC.PlanDesignRequest_Id 
			INNER JOIN [cms].[PlanDesignRequestClass] PDRC 
				ON PDRC.PlanDesignRequestClass_Id = PDSC.PlanDesignRequestClass_Id
		WHERE PDR.Case_Id = @CaseId  AND PDSC.IsActive = 1

	OPEN cursorPDRRequest
		
	FETCH NEXT FROM cursorPDRRequest INTO  @RequestId

	WHILE @@FETCH_STATUS=0
	BEGIN	
			INSERT INTO cms.PlanDesignRequest
			(
				Case_Id,
				PlanDesignRequestStatusType_Id,				
				RequestHeaderName,
				CreationDate,
				IsActive,			
				IllustrationEffectiveDate,
				IsApproved				
			)
			SELECT
				@CaseId,
				1,
				RequestHeaderName,
				GETDATE(),
				1,
				IllustrationEffectiveDate,
				0
			FROM cms.PlanDesignRequest where PlanDesignRequest_Id = @RequestId

			DECLARE @NewRequestId INT
			SET @NewRequestId = (SELECT SCOPE_IDENTITY())

				INSERT INTO [cms].[Log]
					   ([LogDate],[Logger],[Application],[LogLevel],[Message]
					   ,[UserId],[CaseId])
						VALUES
					   (GETDATE(),'USP_BeginAnnualReview','WebApp','Trace','New Request created - Annual Review Process.', @TitanUserid, @CaseId)	

			DECLARE cursorPDRRequestClass SCROLL CURSOR FOR 
			SELECT DISTINCT
			PDRC.PlanDesignRequestClass_Id,
			PDSC.PDRSoldClass_Id,			
			PDRC.PlanDesignRequestClassName
			FROM [cms].[PDRSoldClassPlan] PSC
			INNER JOIN [cms].[PDRSoldClass]  PDSC 
				ON PDSC.PDRSoldClass_Id = PSC.PDRSoldClass_Id
			INNER JOIN [cms].[PlanDesignRequest] PDR 
				ON PDR.PlanDesignRequest_Id = PDSC.PlanDesignRequest_Id 
			INNER JOIN [cms].[PlanDesignRequestClass] PDRC 
				ON PDRC.PlanDesignRequestClass_Id = PDSC.PlanDesignRequestClass_Id
			WHERE PDR.Case_Id = @CaseId AND PDSC.PlanDesignRequest_Id = @RequestId AND PDSC.IsActive = 1

			OPEN cursorPDRRequestClass

			FETCH NEXT FROM cursorPDRRequestClass INTO @oldClassId, @PDRSoldClass_Id, @ClassName

			WHILE @@FETCH_STATUS=0
			BEGIN
						INSERT INTO cms.Census
						(
							Case_Id,
							PlanDesignRequest_Id,
							ReceivedDateTime,
							IsActiveIndicator
						)
						VALUES
						(
							@CaseId,
							@NewRequestId,
							GETDATE(),
							1
						)

						DECLARE @NewCensusId INT
						SET @NewCensusId = (SELECT SCOPE_IDENTITY())			

						INSERT INTO [cms].[Log]
					   ([LogDate],[Logger],[Application],[LogLevel],[Message]
					   ,[UserId],[CaseId])
						VALUES
					   (GETDATE(),'USP_BeginAnnualReview','WebApp','Trace','New Census created - Annual Review Process.', @TitanUserid, @CaseId)	

						INSERT INTO cms.PlanDesignRequestClass
						(
						[RequestedPlanDesignType_Id], 
						[PlanDesignNotes],
						[RequestedBenefitPeriod_Id],
						[BenefitPeriodNotes],
						[RequestedEliminationPeriod_Id],
						[EliminationPeriodNotes],
						[RequestedLTDPercentage],
						[LTDPercentageNotes],
						[RequestedIDIPercentage],
						[IDIPercentageNotes],
						[RequestedPremiumPayerAndTaxabilityType_Id],
						[PremiumPayerAndTaxabilityNotes],
						[RequestedMaximumReplacementRatio],
						[MaximumReplacementRatioNotes],
						[RequestedLTDCoversNext],
						[LTDCoversNextNotes],
						[RequestedIDICovers1st],
						[IDICovers1stNotes],
						[RequestedCoveredEarningsType_Id],
						[CoveredEarningsTypeNotes],
						[RequestedFlatRateType_Id],
						[RequestedFlatRate_Other],
						[RequestedRetirementContributionsType_Id],
						[RetirementContributionNotes],
						[RequestedAnnualContributions],
						[AnnualContributionsNotes],
						[RequestedCoveredEarningsPercentage],
						[CoveredEarningsPercentageNotes],
						[RequestedRppRiderCoveredEarningsType_Id],
						[RppRiderCoveredEarningsTypeNotes],
						[RequestedRppRiderCoveredEarningsTypeOther],
						[RequestedTaxabilityType_Id],
						[TaxabilityTypeNotes],
						[RequestedCoveredEarningsBonusOnlyType_Id],
						[RequestedTypeOfShareType_Id],
						[RequestedEmployerPaidPremium],
						[EmployerPaidPremiumNotes],[RequestedEmployeePaidPremium],
						[RequestedEmployerPaysupto],
						[EmployerPaysuptoNotes],
						[RequestedCostShareTaxabilityType_Id], 
						[VoluntaryGSIBuyUpPlanNotes],
						[VoluntaryGSIBuyUpPlanDesignNotes],
						[GSIBuyUpCoveredEarningsTypeNotes],
						[GSIBuyUpReplacementPercentageNotes],
						[RequestedEligiblePopulationText], 
						[EligiblePopulationTextNotes], 
						[PlanDesignRequest_Id], 
						[PlanDesignRequestClassName]
						)
						SELECT
							PSC.[PlanDesignType_Id],
							PSC.[PlanDesignNotes],
							PSC.[BenefitPeriod_Id],
							PSC.[BenefitPeriodNotes],
							PSC.[EliminationPeriod_Id],
							PSC.[EliminationPeriodNotes],
							PSC.[LTDPercentage],
							PSC.[LTDPercentageNotes],
							PSC.[IDIPercentage],
							PSC.[IDIPercentageNotes],
							PSC.[PremiumPayerAndTaxabilityType_Id],
							PSC.[PremiumPayerAndTaxabilityNotes],
							PSC.[MaximumReplacementRatio],
							PSC.[MaximumReplacementRatioNotes],
							PSC.[LTDCoversNext],
							PSC.[LTDCoversNextNotes],
							PSC.[IDICovers1st],
							PSC.[IDICovers1stNotes],
							PSC.[CoveredEarningsType_Id],
							PSC.[CoveredEarningsTypeNotes],
							PSC.[FlatRateType_Id],
							PSC.[FlatRate_Other],
							PSC.[RetirementContributionsType_Id],
							PSC.[RetirementContributionsNotes],
							PSC.[AnnualContributions],
							PSC.[AnnualContributionsNotes],
							PSC.[CoveredEarningsPercentage],
							PSC.[CoveredEarningsPercentageNotes],
							PSC.[RppRiderCoveredEarningsType_Id],
							PSC.[RppRiderCoveredEarningsTypeNotes],
							PSC.[RppRiderCoveredEarningsTypeOther],
							PSC.[TaxabilityType_Id],
							PSC.[TaxabilityTypeNotes],
							PSC.[CoveredEarningsBonusOnlyType_Id],
							PSC.[TypeOfShareType_Id],
							PSC.[EmployerPaidPremium],
							PSC.[EmployerPaidPremiumNotes],
							PSC.[EmployeePaidPremium],
							PSC.[EmployerPaysupto],
							PSC.[EmployerPaysuptoNotes],
							PSC.[CostShareTaxabilityType_Id],
							PSC.[GSIBuyUpPlanNotes],
							PSC.[GSIBuyUpPlanDesignNotes],
							PSC.[GSIBuyUpCoveredEarningsTypeNotes],
							PSC.[GSIBuyUpReplacementPercentageNotes],
							SC.[EligiblePopulationText],
							SC.[EligiblePopulationTextNotes],
							 @NewRequestId, 
							 @ClassName
						FROM [cms].[PDRSoldClassPlan] PSC
						INNER JOIN cms.[PDRSoldClass] SC
							ON SC.PDRSoldClass_Id = PSC.PDRSoldClass_Id
						WHERE SC.PDRSoldClass_Id = @PDRSoldClass_Id AND PSC.PDRClassPlanType_Id = 1

					DECLARE @newClassId INT
					SET @newClassId = (SELECT SCOPE_IDENTITY())

					UPDATE  PDC
							SET
							RequestedVoluntaryGSIBuyUpPlanDesignType_Id = S.[PlanDesignType_Id],
							VoluntaryGSIBuyUpPlanDesignNotes = S.[GSIBuyUpPlanDesignNotes],
							RequestedGSIBuyUpCoveredEarningsType_Id =  S.[CoveredEarningsType_Id],
							RequestedGSIBuyUpCoveredEarningsBonusOnlyType_Id = S.[CoveredEarningsBonusOnlyType_Id],
							GSIBuyUpCoveredEarningsTypeNotes = S.[GSIBuyUpCoveredEarningsTypeNotes],
							[RequestedGSIBuyUpReplacementPercentage] = S.[ReplacementPercentage],
							GSIBuyUpReplacementPercentageNotes = S.[GSIBuyUpReplacementPercentageNotes]
					  FROM [cms].[PlanDesignRequestClass] PDC
					  INNER JOIN (SELECT @newClassId as ClassId, PSC.[PlanDesignType_Id], PSC.[GSIBuyUpPlanDesignNotes], PSC.[CoveredEarningsType_Id],
					   PSC.[CoveredEarningsBonusOnlyType_Id], PSC.[GSIBuyUpCoveredEarningsTypeNotes],PSC.[ReplacementPercentage],PSC.[GSIBuyUpReplacementPercentageNotes] FROM [cms].[PDRSoldClassPlan] PSC
									INNER JOIN [cms].[PDRSoldClass]  PDSC 
										ON PDSC.PDRSoldClass_Id = PSC.PDRSoldClass_Id
									WHERE PDSC.PDRSoldClass_Id = @PDRSoldClass_Id 
									AND PSC.PDRClassPlanType_Id = 2) S
						ON PDC.PlanDesignRequestClass_Id = S.ClassId			 

						/* set IsRequestedVoluntaryGSIBuyUpPlan column  */

						UPDATE [cms].PlanDesignRequestClass 
							SET IsRequestedVoluntaryGSIBuyUpPlan =  (SELECT CASE WHEN EXISTS(
							SELECT 1 FROM [cms].[PDRSoldClassPlan] PSCP
							INNER JOIN [cms].[PDRSoldClass]  PDSC 
								ON PDSC.PDRSoldClass_Id = PSCP.PDRSoldClass_Id
							WHERE PDSC.PDRSoldClass_Id = @PDRSoldClass_Id AND PSCP.PDRClassPlanType_Id = 2) THEN 1 ELSE 0
							END )
					   WHERE PlanDesignRequestClass_Id = @newClassId

					   EXEC [cms].[USP_BeginAnnualReviewInsertParticipants] @oldClassId, @newClassId, @NewCensusId, @TitanUserid, @CaseId

					   /* Eligibility Configuration */

					   INSERT INTO cms.EligibilityConfiguration
					   (
							Case_Id,
							PlanDesignRequest_Id,
							PlanDesignRequestClass_Id,
							MinimumAge,
							MaximumAge,
							IncreaseDuetoAge,
							MaximumGSIAmount,
							MinimumInsurableIncomeAmount,
							EmployerPaidMinimumInsurableIncomeAmount,
							RPPMaximumIndemnityAmount,
							RPPMaximumIndemnityAmountUnderAge49,
							CATLimitAmount,
							MaximumSolicitation,
							IssueLimitMaximum,
							ParticipationLimit,
							MinimumBenefitAmount
					   )
					   SELECT Case_Id,
						PlanDesignRequest_Id,
						(@newClassId),
						MinimumAge,
						MaximumAge,
						IncreaseDuetoAge,
						MaximumGSIAmount,
						MinimumInsurableIncomeAmount,
						EmployerPaidMinimumInsurableIncomeAmount,
						RPPMaximumIndemnityAmount,
						RPPMaximumIndemnityAmountUnderAge49,
						CATLimitAmount,
						MaximumSolicitation,
						IssueLimitMaximum,
						ParticipationLimit,
						MinimumBenefitAmount FROM cms.EligibilityConfiguration WHERE PlanDesignRequestClass_Id = @oldClassId

					/* LTD Coverage */
						INSERT INTO [cms].PlanDesignRequestClassLTDCoverage
						SELECT 
							(@newClassId),
							[EligiblePopulationText],[CarrierText],[EliminationPeriodDays],
							[BenefitPeriodDays],[GroupLTDReplacementPercentage],
							[GroupLTDCapAmount],[GroupLTDCoveredEarningsType_Id],
							[GroupLTDCoveredEarningsType_Other],[PremiumAndTaxpayerLiabilityType_Id],
							[TypeOfPayType_Id],[IsVoluntaryLTDBuyUpIndicator],
							[LTDBuyUpReplacementPercentage],[LTDBuyUpLTDCapAmount],
							[LTDBuyUpCoveredEarningsType_Id],[LTDBuyUpCoveredEarningsType_Other],
							[IsLTDPlanExistingIndicator],[AdditionalDetailsText],				
							[BaseSalaryPercentage],[BonusPercentage],[CommissionPercentage],
							[OtherIncomePercentage],[K1EarningsPercentage],
							[BonusNumberofYears],[CommissionNumberofYears],[K1EarningsNumberofYears]			
						FROM [cms].[PDRSoldClassLTDCoverage] WHERE PDRSoldClass_Id = @PDRSoldClass_Id

						/* Primary Plan customized Insurable*/	  
						INSERT INTO [cms].[PDRClassCustomizedIDIInsurableIncome]
						SELECT
								(@newClassId),
								BaseSalaryPercentage,
								BonusPercentage,
								CommissionPercentage,
								OtherIncomePercentage,
								K1EarningsPercentage,
								BonusNumberofYears,
								CommissionNumberofYears,
								K1EarningsNumberofYears,
								0
						FROM [cms].[PDRSoldClassPlanCustomizedIDIInsurableIncome] PSCPC
						INNER JOIN cms.[PDRSoldClassPlan]  PSCP
							ON  PSCP.PDRSoldClassPlan_Id = PSCPC.PDRSoldClassPlan_Id
						WHERE PSCP.PDRSoldClass_Id = @PDRSoldClass_Id AND  PSCP.PDRClassPlanType_Id = 1

						/* BuyUp Plan customized Insurable*/
						INSERT INTO [cms].[PDRClassCustomizedIDIInsurableIncome]
						SELECT
								(@newClassId),
								BaseSalaryPercentage,
								BonusPercentage,
								CommissionPercentage,
								OtherIncomePercentage,
								K1EarningsPercentage,
								BonusNumberofYears,
								CommissionNumberofYears,
								K1EarningsNumberofYears,
								1
						FROM [cms].[PDRSoldClassPlanCustomizedIDIInsurableIncome] PSCPC
						INNER JOIN cms.[PDRSoldClassPlan]  PSCP
							ON  PSCP.PDRSoldClassPlan_Id = PSCPC.PDRSoldClassPlan_Id
						WHERE PSCP.PDRSoldClass_Id = @PDRSoldClass_Id AND  PSCP.PDRClassPlanType_Id = 2


						/* Product Table Primary Plan Product and Rider*/

						INSERT INTO [cms].[PlanDesignRequestClassProduct]
						   ([PlanDesignRequestClass_Id]
						   ,[GSIAmount]
						   ,[BaseDiscountType_Id]
						   ,[DemographicDiscountType_Id]
						   ,[ParticipationPercentage]
						   ,[DefinitionOfDisabilityType_Id]
						   ,[MentalSubstanceLimitationType_Id]
						   ,[PreExistingConditionLimitType_Id]
						   ,[EliminationPeriodType_Id]
						   ,[BenefitPeriodType_Id]
						   ,[IsGSIPlanIndicator]
						   ,[TotalMaxGSIAmount]
						   ,[MinimumCaseLevelGSIAmount]
						   ,[DiscountOverride]
						   ,[IsOneStepEnrollmentIndicator])
					   SELECT
							  (@newClassId),
							  PSCP.[GSIAmount],
							  ISNULL(PSCP.BaseDiscountType_Id,1),
							  PSCP.[DemographicDiscountType_Id],
							  PSCP.[ParticipationPercentage],
							  PSCP.[DefinitionOfDisabilityType_Id],
							  PSCP.[MentalSubstanceLimitationType_Id],
							  PSCP.[PreExistingConditionLimitType_Id],
							  PSCP.[EliminationPeriod_Id],
							  PSCP.[BenefitPeriod_Id],
							  0,
							  PSCP.[TotalMaxGSIAmount],
							  PSCP.[MinimumCaseLevelGSIAmount],
							  PSCP.[DiscountOverride],
							  PSCP.[IsOneStepEnrollmentIndicator]
						FROM [cms].[PDRSoldClassPlan] PSCP
						INNER JOIN [cms].[PDRSoldClass]  PDSC 
							ON PDSC.PDRSoldClass_Id = PSCP.PDRSoldClass_Id
						WHERE PSCP.PDRSoldClass_Id = @PDRSoldClass_Id AND  PSCP.PDRClassPlanType_Id = 1
	   
					   INSERT INTO [cms].[PlanDesignRequestClassRider]
						   ([PlanDesignRequestClass_Id]
						   ,[BenefitType_Id]
						   ,[BenefitGroupType_Id]
						   ,[EliminationPeriodType_Id]
						   ,[BenefitPeriodType_Id]
						   ,[ApprovedAmount]
						   ,[IsGSIPlanIndicator])
					   SELECT
							  (@newClassId),
							  PSCP.[BenefitType_Id],
							  PSCP.[BenefitGroupType_Id],
							  PSCP.[EliminationPeriodType_Id],
							  PSCP.[BenefitPeriodType_Id],
							  PSCP.[ApprovedAmount],
							  0
					   FROM [cms].[PDRSoldClassPlanRiders] PSCP
							INNER JOIN [cms].[PDRSoldClassPlan] PSP 
								ON PSP.PDRSoldClassPlan_Id = PSCP.PDRSoldClassPlan_Id
							INNER JOIN [cms].[PDRSoldClass]  PDSC 
								ON PDSC.PDRSoldClass_Id = PSP.PDRSoldClass_Id
					   WHERE PSP.PDRSoldClass_Id = @PDRSoldClass_Id AND PSP.PDRClassPlanType_Id = 1

					 /* BuyUp Plan Product and Rider */

					   INSERT INTO [cms].[PlanDesignRequestClassProduct]
						   ([PlanDesignRequestClass_Id]
						   ,[GSIAmount]
						   ,[BaseDiscountType_Id]
						   ,[DemographicDiscountType_Id]
						   ,[ParticipationPercentage]
						   ,[DefinitionOfDisabilityType_Id]
						   ,[MentalSubstanceLimitationType_Id]
						   ,[PreExistingConditionLimitType_Id]
						   ,[EliminationPeriodType_Id]
						   ,[BenefitPeriodType_Id]
						   ,[IsGSIPlanIndicator]
						   ,[TotalMaxGSIAmount]
						   ,[MinimumCaseLevelGSIAmount]
						   ,[DiscountOverride]
						   ,[IsOneStepEnrollmentIndicator])
						SELECT
							  (@newClassId),
							  PSCP.[GSIAmount],
							  ISNULL(PSCP.BaseDiscountType_Id,1),
							  PSCP.[DemographicDiscountType_Id],
							  PSCP.[ParticipationPercentage],
							  PSCP.[DefinitionOfDisabilityType_Id],
							  PSCP.[MentalSubstanceLimitationType_Id],
							  PSCP.[PreExistingConditionLimitType_Id],
							  PSCP.[EliminationPeriod_Id],
							  PSCP.[BenefitPeriod_Id],
							  1,
							  PSCP.[TotalMaxGSIAmount],
							  PSCP.[MinimumCaseLevelGSIAmount],
							  PSCP.[DiscountOverride],
							  PSCP.[IsOneStepEnrollmentIndicator]
						FROM [cms].[PDRSoldClassPlan] PSCP
						INNER JOIN [cms].[PDRSoldClass]  PDSC 
							ON PDSC.PDRSoldClass_Id = PSCP.PDRSoldClass_Id
						WHERE PSCP.PDRSoldClass_Id = @PDRSoldClass_Id AND  PSCP.PDRClassPlanType_Id = 2
	   
						   INSERT INTO [cms].[PlanDesignRequestClassRider]
							   ([PlanDesignRequestClass_Id]
							   ,[BenefitType_Id]
							   ,[BenefitGroupType_Id]
							   ,[EliminationPeriodType_Id]
							   ,[BenefitPeriodType_Id]
							   ,[ApprovedAmount]
							   ,[IsGSIPlanIndicator])
						   SELECT
								  (@newClassId),
								  PSCP.[BenefitType_Id],
								  PSCP.[BenefitGroupType_Id],
								  PSCP.[EliminationPeriodType_Id],
								  PSCP.[BenefitPeriodType_Id],
								  PSCP.[ApprovedAmount],
								  1
						   FROM [cms].[PDRSoldClassPlanRiders] PSCP
						   INNER JOIN [cms].[PDRSoldClassPlan] PSP ON PSP.PDRSoldClassPlan_Id = PSCP.PDRSoldClassPlan_Id
						   INNER JOIN [cms].[PDRSoldClass]  PDSC ON PDSC.PDRSoldClass_Id = PSP.PDRSoldClass_Id
						   WHERE PSP.PDRSoldClass_Id = @PDRSoldClass_Id AND PSP.PDRClassPlanType_Id = 2


						INSERT INTO [cms].[CaseCompanyRetirementPlan]
						SELECT 
							PSCP.CompanyRetirementPlanType_Id,
							(@newClassId),
							PSCP.IsChecked,
							PSCP.CompanyRetirementPlanType_Other 
						FROM [cms].[PDRSoldClassCompanyRetirementPlan] PSCP
						INNER JOIN [cms].[PDRSoldClass]  PDSC 
							ON PDSC.PDRSoldClass_Id = PSCP.PDRSoldClass_Id
						WHERE PDSC.PDRSoldClass_Id = @PDRSoldClass_Id 


					   UPDATE cms.PDRSoldClass
					   SET [IsAnnualReviewComplete] = 1
					   WHERE PDRSoldClass_Id = @PDRSoldClass_Id		

				FETCH NEXT FROM cursorPDRRequestClass INTO @oldClassId, @PDRSoldClass_Id, @ClassName
		   END

		   CLOSE cursorPDRRequestClass
		   DEALLOCATE cursorPDRRequestClass		
		
		FETCH NEXT FROM cursorPDRRequest INTO  @RequestId

		END
	CLOSE cursorPDRRequest
	DEALLOCATE cursorPDRRequest
END
