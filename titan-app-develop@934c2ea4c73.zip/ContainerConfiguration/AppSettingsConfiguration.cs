﻿using CMS.Interfaces.Configurations;
using Common.Utilities;

namespace ContainerConfiguration
{
    public class AppSettingsConfiguration : IConfiguration
    {
        public string BuildVersion { get; set; }

        public string CMSDatabaseConnection { get; set; }
        public string DisabilityReferenceLibraryDatabaseConnection { get; set; }

        public CredentialInfo CMSServiceCredentials { get; set; }

        public string UserProfileServiceUrl { get; set; }
        public string UserProfileServiceCallerId { get; set; }
        public string UserProfileServiceUserName { get; set; }
        public string UserProfileServicePassword { get; set; }

        public string LawsServiceUrl { get; set; }

        public string TibcoQueueServer { get; set; }
        public string TibcoQueueFromGa { get; set; }
        public string TibcoQueueToGa { get; set; }
        public CredentialInfo TibcoQueueCredentials { get; set; }

        public double GaQueuePoolingIntervalInSeconds { get; set; }

        public CredentialInfo CMSCalculationServiceCredentials { get; set; }
        public string CMSCalculationServiceBaseUrl { get; set; }


        public CredentialInfo FileNetServiceCredentials { get; set; }
        public string FileNetSearchWebServiceUrl { get; set; }
        public string FileNetDocumentWebServiceUrl { get; set; }
        public string FileNetSaveAnnotationsWebServiceUrl { get; set; }
        public string FileNetUpdateIndexValuesServiceUrl { get; set; }
        public string FileNetUploadDocumentServiceUrl { get; set; }

        public CredentialInfo NewFileNetServiceCredentials { get; set; }
        //public bool UseNewFileNetUrl { get; set; }
        public string NewFileNetWebServiceUrl { get; set; }
       
        //public string NewFileNetServiceUserName { get; set; }
        //public string NewFileNetServicePassword { get; set; }

        public string LocatorWebServiceUrl { get; set; }

        public int PremiumCalculationsPerRequestFactor { get; set; }
        public int PremiumCalculationsPerRequestMax { get; set; }
        public int PremiumCalculationsPerRequestMin { get; set; }
        
        public string ExtreamAxwayFileUrl { get; set; }
        public string ExtreamAxwayApiUrl { get; set; }        
        public CredentialInfo ExtreamAxwayCredentials { get; set; }
        public string ExtreamAxwayCCJobName { get; set; }
        public string ExtreamAxwayCCJobNameForPostCard { get; set; }
        public string ExtreamAxwayFileDownloadUrl { get; set; }
        public string ExtreamAxwayApiDownloadUrl { get; set; }
        public bool ExtreamDropFakeFiles { get; set; }
        public string AxwayBridgelineXmlUploadUrl { get; set; }
        public string ExtreamAxwayStfpHostName { get; set; }
        public string ExtreamAxwayStfpHostPort { get; set; }
        public string SalesForceStfpHostPath { get; set; }
        public int ExtreamAxwayStfpJobTriggerHour { get; set; }
        public string ExtreamAxwayStfpImageUploadUrl { get; set; }

        public string AnnualReviewReportUrl { get; set; }
        public string MLAppEntryPolicyDecisionUrl { get; set; }
        public string TitanLogOutUrl { get; set; }
        public string IndexWSBaseUrl { get; set; }
        public string FilenetSearchBaseUrl { get; set; }
        public string FilenetDocId { get; set; }
        public string EncryptionKey { get; set; }

        public string ApigeeOAuthTokenUrl { get; set; }
        public string CUDBApiBaseUrl { get; set; }
        public CredentialInfo CUDBCredentials { get; set; }

        public string MLDEApiBaseUrl { get; set; }
        public CredentialInfo MLDECredentials { get; set; }

        public string LocalhostAccount { get; set; }

        public string MLDEAdminUrl { get; set; }
        public AppSettingsConfiguration()
        {
            // databases
            CMSDatabaseConnection = Common.Utilities.AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");
            DisabilityReferenceLibraryDatabaseConnection = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ProductLibraryDatabaseConnection");

            EncryptionKey = Common.Utilities.AppSettingsReader.ReadAppSettingValue("EncryptionKey");

            // web services
            CMSServiceCredentials = ReadCredential("CMSServiceUserName", "CMSServicePassword", true);
           

            // user profile
            UserProfileServiceUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("UserProfileServiceUrl");
            UserProfileServiceCallerId = Common.Utilities.AppSettingsReader.ReadAppSettingValue("UserProfileServiceCallerId");
            UserProfileServiceUserName = Common.Utilities.AppSettingsReader.ReadAppSettingValue("UserProfileServiceUserName");
            UserProfileServicePassword = StringCipherHelper.Decrypt(Common.Utilities.AppSettingsReader.ReadAppSettingValue("UserProfileServicePassword"), EncryptionKey);

            // laws service
            LawsServiceUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("LawsServiceUrl");

            //Log out

            TitanLogOutUrl= Common.Utilities.AppSettingsReader.ReadAppSettingValue("CMSLogout");

            // tibco ga queue
            TibcoQueueServer = Common.Utilities.AppSettingsReader.ReadAppSettingValue("TibcoQueueServer");
            TibcoQueueFromGa = Common.Utilities.AppSettingsReader.ReadAppSettingValue("TibcoQueueFromGa");
            TibcoQueueToGa = Common.Utilities.AppSettingsReader.ReadAppSettingValue("TibcoQueueToGa");
            TibcoQueueCredentials = ReadCredential("TibcoQueueUserName", "TibcoQueuePassword", true);

            // GA queue pooling interval
            GaQueuePoolingIntervalInSeconds = double.Parse(Common.Utilities.AppSettingsReader.ReadAppSettingValue("GaQueuePoolingIntervalInSeconds"));

            // calculation web service
            CMSCalculationServiceCredentials = ReadCredential("CMSCalculationServiceUserName", "CMSCalculationServicePassword", true);
            CMSCalculationServiceBaseUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("CMSCalculationServiceBaseUrl");

            LocatorWebServiceUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("LocatorWebServiceUrl");

            // FileNet services
            FileNetServiceCredentials = ReadCredential("FileNetServiceUserName", "FileNetServicePassword", true);
            FileNetSearchWebServiceUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("FileNetSearchWebServiceUrl");
            FileNetDocumentWebServiceUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("FileNetDocumentWebServiceUrl");
            FileNetSaveAnnotationsWebServiceUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("FileNetSaveAnnotationsWebServiceUrl");
            FileNetUpdateIndexValuesServiceUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("FileNetUpdateIndexValuesServiceUrl");
            FileNetUploadDocumentServiceUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("FileNetUploadDocumentServiceUrl");

            NewFileNetWebServiceUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("NewFileNetWebServiceUrl");
            //UseNewFileNetUrl = bool.Parse(Common.Utilities.AppSettingsReader.ReadAppSettingValue("UseNewFileNetUrl"));            
            //NewFileNetServiceCredentials = ReadCredential("NewFileNetServiceUserName", "NewFileNetServicePassword", true);

            // premium calculation settings
            PremiumCalculationsPerRequestFactor = int.Parse(Common.Utilities.AppSettingsReader.ReadAppSettingValue("PremiumCalculationsPerRequestFactor"));
            PremiumCalculationsPerRequestMax = int.Parse(Common.Utilities.AppSettingsReader.ReadAppSettingValue("PremiumCalculationsPerRequestMax"));
            PremiumCalculationsPerRequestMin = int.Parse(Common.Utilities.AppSettingsReader.ReadAppSettingValue("PremiumCalculationsPerRequestMin"));
            
            // axway settings
            ExtreamAxwayFileUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayFileUrl");
            ExtreamAxwayApiUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayApiUrl");
            ExtreamAxwayCredentials = ReadCredential("ExtreamAxwayUserName", "ExtreamAxwayPassword", true);
            ExtreamAxwayCCJobName = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayCCJobName");
            ExtreamAxwayCCJobNameForPostCard = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayCCJobNameForPostCard");
            ExtreamAxwayFileDownloadUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayFileDownloadUrl");            
            ExtreamAxwayApiDownloadUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayApiDownloadUrl");
            AxwayBridgelineXmlUploadUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("AxwayBridgelineXmlUploadUrl");

            ExtreamAxwayStfpHostName = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayStfpHostName");
            ExtreamAxwayStfpHostPort = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayStfpHostPort");
            SalesForceStfpHostPath = Common.Utilities.AppSettingsReader.ReadAppSettingValue("SalesForceStfpHostPath");
            ExtreamAxwayStfpJobTriggerHour = int.Parse(Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayStfpJobTriggerHour"));
            ExtreamAxwayStfpImageUploadUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("ExtreamAxwayStfpImageUploadUrl");

            BuildVersion = Common.Utilities.AppSettingsReader.ReadAppSettingValue("BuildVersion");
            BuildVersion = BuildVersion == "__BuildVersion__" ? "" : BuildVersion;

            AnnualReviewReportUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("AnnualReviewReportUrl");

            MLAppEntryPolicyDecisionUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("MLAppEntryPolicyDecisionUrl");

            //FileNet Service
            FilenetSearchBaseUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("FilenetSearchBaseUrl");
            FilenetDocId = Common.Utilities.AppSettingsReader.ReadAppSettingValue("FilenetDocId");
            // IndexWS service
            IndexWSBaseUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("IndexWSBaseUrl");

            // CUDB/CUW API
            ApigeeOAuthTokenUrl = AppSettingsReader.ReadAppSettingValue("ApigeeOAuthTokenUrl");
            CUDBApiBaseUrl = AppSettingsReader.ReadAppSettingValue("CUDBApiBaseUrl");
            CUDBCredentials = ReadCredential("CUDBUsername", "CUDBPassword", true);

            //REMOVE the try catch before mlde prod deployment
            try
            {
                //MLDE API
                MLDEApiBaseUrl = AppSettingsReader.ReadAppSettingValue("MLDEApiBaseUrl");
                MLDECredentials = ReadCredential("MLDEUsername", "MLDEPassword", true);
            }
            catch
            {
                MLDEApiBaseUrl = AppSettingsReader.ReadAppSettingValue("MLDEApiBaseUrl");
                MLDECredentials = ReadCredential("MLDEUsername", "MLDEPassword", false);
            }

            LocalhostAccount = AppSettingsReader.ReadAppSettingValue("LocalhostAccount");

            MLDEAdminUrl = Common.Utilities.AppSettingsReader.ReadAppSettingValue("MLDEAdminUrl");
        }

        private CredentialInfo ReadCredential(string credentialUserNameKey, string credentialPasswordKey, bool needDecryption)
        {
            return new CredentialInfo()
            {
                UserName = Common.Utilities.AppSettingsReader.ReadAppSettingValue(credentialUserNameKey),
                Password = needDecryption == true ? StringCipherHelper.Decrypt(Common.Utilities.AppSettingsReader.ReadAppSettingValue(credentialPasswordKey), EncryptionKey) : Common.Utilities.AppSettingsReader.ReadAppSettingValue(credentialPasswordKey)
            };
        }
    }
}