﻿using CMS.DataAccess.Repositories;
using CMS.Integrations.BrokerDataServices;
using CMS.Integrations.BrokerLicensingService;
using CMS.Integrations.FileNetDocumentRepositories;
using CMS.Integrations.MLAppEntryServices;
using CMS.Integrations.PremiumCalculationService;
using CMS.Integrations.ProductLibraryService;
using CMS.Integrations.QueueMessagingService;
using CMS.Integrations.IndexWSService;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.BrokerDataServices;
using CMS.Interfaces.Integrations.BrokerLicensingServices;
using CMS.Interfaces.Integrations.FileNetDocumentRepositories;
using CMS.Interfaces.Integrations.IndexWSServices;
using CMS.Interfaces.Integrations.MLAppEntryServices;
using CMS.Interfaces.Integrations.PremiumCalculationServices;
using CMS.Interfaces.Integrations.ProductLibraryServices;
using CMS.Interfaces.Integrations.QueueMessagingServices;
using CMS.Interfaces.Integrations.UserProfileServices;
using CMS.Interfaces.Managers.AnnualReviewManagers;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Interfaces.Managers.BillingManagers;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.CensusManagers;
using CMS.Interfaces.Managers.CensusReconciliationManagers;
using CMS.Interfaces.Managers.ContactAddressManagers;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Interfaces.Managers.GAMessageManagers;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Interfaces.Managers.ITAdminManagers;
using CMS.Interfaces.Managers.LookupManagers;
using CMS.Interfaces.Managers.OccupationClassAssignmentManagers;
using CMS.Interfaces.Managers.OfferLetterManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Interfaces.Managers.QuickSearchManagers;
using CMS.Interfaces.Managers.ReleaseManagers;
using CMS.Interfaces.Managers.SecurityManagers;
using CMS.Interfaces.Managers.TaskManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Managers.AnnualReviewManagers;
using CMS.Managers.BenefitAmountsCalculationManagers;
using CMS.Managers.BillingManagers;
using CMS.Managers.BusinessManagers;
using CMS.Managers.BusinessManagers.BenefitAndPremiums;
using CMS.Managers.BusinessManagers.ExistingCoverage;
using CMS.Managers.BusinessManagers.RateSheet;
using CMS.Managers.CaseManagers;
using CMS.Managers.CensusManagers;
using CMS.Managers.CensusReconsiliationManagers;
using CMS.Managers.ContactAddressManagers;
using CMS.Managers.DocumentManagers;
using CMS.Managers.DocumentManagers.DocumentGenerators;
using CMS.Managers.EligibilityManager;
using CMS.Managers.GAMessageManagers;
using CMS.Managers.ImplementationManangers;
using CMS.Managers.LookupManagers;
using CMS.Managers.OccupationClassAssignmentManagers;
using CMS.Managers.OfferLetterManagers;
using CMS.Managers.PlanManagers;
using CMS.Managers.ReleaseManagers;
using CMS.Managers.SearchManagers;
using CMS.Managers.TaskManagers;
using CMS.StateMachine;
using ITAdminManagers;
using Microsoft.Practices.Unity;
using SecurityManagers;
using UserProfileService;
using Logger.Static;
using CMS.Integrations.MLDEService;
using CMS.Interfaces.Integrations.MLDEServices;

namespace ContainerConfiguration
{
    public class UnityContainerFactory
    {
        public UnityContainer CreateContainer()
        {
            var container = new UnityContainer();

            // Configuration and unit of work factory
            container.RegisterType<IConfiguration, AppSettingsConfiguration>(new ContainerControlledLifetimeManager());
            container.RegisterType<IUnitOfWorkFactory, UnitOfWorkFactory>();

            // Integrations
            container.RegisterType<IProductLibraryService, ProductLibraryServiceClient>();
            container.RegisterType<IPremiumCalculationService, PremiumCalculationServiceClient>();

            //if (container.Resolve<IConfiguration>().UseNewFileNetUrl == true)
            //{
                Log.TraceFormat("Using new FileNet container");
                container.RegisterType<IFileNetDocumentRepository, FileNetServiceClientV2>();
            //}
            //else
            //{
            //    Log.TraceFormat("Using old FileNet container");
            //    container.RegisterType<IFileNetDocumentRepository, FileNetServiceClient>();
            //}


            container.RegisterType<IUserProfileServiceClient, UserProfileServiceClient>();
            container.RegisterType<IBrokerLicensingServiceClient, BrokerLicensingServiceClient>();
            container.RegisterType<IBrokerDataClient, BrokerDataClient>();
            container.RegisterType<IQueueMessagingClient, GaQueueMessagingClient>();
            container.RegisterType<IProductLibraryWebServiceClient, ProductLibraryWebServiceClient>();
            container.RegisterType<IIndexWSService, IndexWSServiceClient>();
            container.RegisterType<IMLDEService, MLDEService>();

            // Managers
            container.RegisterType<ILookupManager, LookupManager>();
            container.RegisterType<ICaseManager, CaseManager>();
            container.RegisterType<IStatePricingTypeManager, StatePricingTypeManager>();
            container.RegisterType<ICompactStateManager, CompactStateManager>();
            container.RegisterType<IQuickSearch, QuickSearchManager>();
            container.RegisterType<ICompanyManager, CompanyManager>();
            container.RegisterType<ITaskManager, TaskManager>();
            container.RegisterType<IProductLibraryManager, ProductLibraryManager>();
            container.RegisterType<ISampleQuoteManager, SampleQuoteManager>();
            container.RegisterType<ISecurityManager, SecurityManager>();
            container.RegisterType<ICaseExistingCoverageManager, CaseExistingCoverageManager>();
            container.RegisterType<ICaseBrokerManager, CaseBrokerManager>();
            container.RegisterType<IWholesalerManager, WholesalerManager>();
            container.RegisterType<IPlanDesignRequestManager, PlanDesignRequestManager>(); 
            container.RegisterType<ICaseBrokerManager, CaseBrokerManager>();
            container.RegisterType<IGaMessageManager, GaMessageManager>();
            container.RegisterType<IIllustrationRequestDatabaseManager, IllustrationRequestDatabaseManager>();
            container.RegisterType<IIllustrationRequestManager, IllustrationRequestManager>();
            container.RegisterType<IAdminGaMessageHistoryManager, AdminGaMessageHistoryManager>();
            container.RegisterType<IProductLibraryOptionsManager, ProductLibraryOptionsManager>();
            container.RegisterType<ICensusManager, CensusManager>();
            container.RegisterType<IBenefitAmountsCalculationManager, BenefitAmountsCalculationManager>();
            container.RegisterType<IAMBBenefitAmountsCalculationManager, AMBBenefitAmountCalculationManager>();
            container.RegisterType<IEligibilityConfigurationManager, EligibilityConfigurationManager>();
            container.RegisterType<IEligibilityDeterminationManager, EligibilityDeterminationManager>();
            container.RegisterType<IOccupationClassAssignmentManager, OccupationClassAssignmentManager>();
            container.RegisterType<IIllustrationManager, IllustrationManager>();
            container.RegisterType<IOfferLetterRequestManager, OfferLetterRequestManager>();
            container.RegisterType<IEnrollmentManager, EnrollmentManager>();
            container.RegisterType<IReleaseManager, ReleaseManager>();
            container.RegisterType<IDocumentManager, DocumentManager>();
            container.RegisterType<IExtreamFileUploader, ExtreamFileUploader>();
            container.RegisterType<IExtreamFileDownloader, ExtreamFileDownloader>();
            container.RegisterType<IPlanDesignRequestSoldManager, PlanDesignRequestSoldManager>();
            container.RegisterType<IPlanDesignRequestSaveSoldManager, PlanDesignRequestSaveSoldManager>();
            container.RegisterType<IFileNetDocumentUploader, FileNetDocumentUploader>();
            container.RegisterType<IAxwaySalesForceUploader, AxwaySalesForceUploader>();
            container.RegisterType<IContactAddressManager, ContactAddressManager>();
            container.RegisterType<IBillingManager, BillingManager>();
            container.RegisterType<IAnnualReviewManager, AnnualReviewManager>();
            container.RegisterType<IBenefitPremiumManager, BenefitPremiumManager>();
            container.RegisterType<IBridgelineMessageManager, BridgelineMessageManager>();
            container.RegisterType<IAxwayFileUploader, BridgelineXmlUploader>();
            container.RegisterType<IPriorCoverageManager, PriorCoverageManager>();
            container.RegisterType<IAppEntryService, AppEntryService>();
            container.RegisterType<IEnrollmentOutputXmlManager, EnrollmentOutputXmlManager>();
            container.RegisterType<IPostCardXmlManager, PostCardXmlManager>();
            container.RegisterType<ICUDBManager, CUDBManager>();
            container.RegisterType<IMLDEManager, MLDEManger>();
            container.RegisterType<IEmailCampaignManager, EmailCampaignManager>();

            // Document generators
            container.RegisterType<IIllustrationDocumentGenerator, IllustrationDocumentGenerator>();
            container.RegisterType<IOfferLetterDocumentGenerator, OfferLetterDocumentGenerator>();
            container.RegisterType<IBenefitPremiumDocumentGenerator, BenefitPremiumDocumentGenerator>();
            container.RegisterType<IBridgelineXmlGenerator, BridgelineXmlGenerator>();
            container.RegisterType<IEnrollmentKitXmlGenerator, EnrollmentKitXmlGenerator>();
            container.RegisterType<IEnrollmentToolDocumentGenerator, EnrollmentToolDocumentGenerator>();
            container.RegisterType<IProducerCertificationDocumentGenerator, ProducerCertificationDocumentGenerator>();
            container.RegisterType<IPostCardXmlGenerator, PostCardXmlGenerator>();
            // Reconciliation
            container.RegisterType<ICensusReconciliationManager, CensusReconciliationManager>();
            container.RegisterType<IDuplicatesManager, DuplicatesManager>();
            container.RegisterType<IPartialMatchesManager, PartialMatchesManager>();
            container.RegisterType<INewUnmatchedManager, NewUnmatchedManager>();
            container.RegisterType<IExistingUnmatchedManager, ExistingUnmatchedManager>();
            container.RegisterType<IMatchWithChangesManager, MatchWithChangesManager>();

            // WorkUnit handlers
            container.RegisterType<IWorkUnitManager, WorkUnitManager>();
            container.RegisterType<IWorkUnitHandler, ExtreamFileUploader>(WorkUnitType.ExtreamFileUpload.ToString());
            container.RegisterType<IWorkUnitHandler, PostCardXmlGenerator>(WorkUnitType.PostCard.ToString());
            container.RegisterType<IWorkUnitHandler, ExtreamFileDownloader>(WorkUnitType.ExtreamFileDownload.ToString());
            container.RegisterType<IWorkUnitHandler, IllustrationRequestManager>(WorkUnitType.IllustrationDocument.ToString());
            container.RegisterType<IWorkUnitHandler, BenefitPremiumManager>(WorkUnitType.BenefitAndPremiumDocument.ToString());
            container.RegisterType<IWorkUnitHandler, BridgelineXmlGenerator>(WorkUnitType.BridgelineXml.ToString());
            container.RegisterType<IWorkUnitHandler, EnrollmentKitXmlGenerator>(WorkUnitType.EnrollmentKit.ToString());
            container.RegisterType<IWorkUnitHandler, AnnualReviewTaskManager>(WorkUnitType.AnnualReviewTask.ToString());
            container.RegisterType<IWorkUnitHandler, EnrollmentToolDocumentGenerator>(WorkUnitType.EnrollmentTool.ToString());
            container.RegisterType<IWorkUnitHandler, BridgelineXmlUploader>(WorkUnitType.BridgelineFileAxwayUpload.ToString());
            container.RegisterType<IWorkUnitHandler, OfferLetterDocumentGenerator>(WorkUnitType.OfferLetterDocument.ToString());
            container.RegisterType<IWorkUnitHandler, PriorCoverageManager>(WorkUnitType.PriorCoverageSearch.ToString());
            container.RegisterType<IWorkUnitHandler, ProducerCertificationDocumentGenerator>(WorkUnitType.ProducerCertification.ToString());
            container.RegisterType<IWorkUnitHandler, SolicitationDeclinesTaskManager>(WorkUnitType.SolicitationDeclinesTask.ToString());
            container.RegisterType<IWorkUnitHandler, EnrollmentInProgressManager>(WorkUnitType.EnrollmentInProgress.ToString());
            container.RegisterType<IWorkUnitHandler, PostEnrollmentManager>(WorkUnitType.PostEnrollment.ToString());
            container.RegisterType<IWorkUnitHandler, MaskedCaseManger>(WorkUnitType.TibcoPostToGA.ToString());
            container.RegisterType<IWorkUnitHandler, PolicyNumberGeneratorManager>(WorkUnitType.PolicyNumberGeneration.ToString());            
            container.RegisterType<IWorkUnitHandler, ProcessPolicyToSTPQueueManager>(WorkUnitType.ProcessPolicyToSTPQueue.ToString());
            container.RegisterType<IWorkUnitHandler, PolicyNumberUpdationManager>(WorkUnitType.PolicyNumberFilenetUpdation.ToString());           
            container.RegisterType<IWorkUnitHandler, CUDBManager>(WorkUnitType.CUDBRequest.ToString());
            //container.RegisterType<IWorkUnitHandler, CUDBManager>(WorkUnitType.SalesForceAxwayUpload.ToString());
            container.RegisterType<IProcessPolicyToSTPQueueManager, ProcessPolicyToSTPQueueManager>();           
            container.RegisterType<IPolicyNumberGenerationManager, PolicyNumberGeneratorManager>();           
            container.RegisterType<IPolicyNumberUpdationManager, PolicyNumberUpdationManager>();           

            return container;
        }
    }
}
