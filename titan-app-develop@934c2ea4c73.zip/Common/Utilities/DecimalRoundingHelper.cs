﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utilities
{
    public static class DecimalRoundingHelper
    {
        public static decimal Roundoff(this decimal value, int decimalsPoints = 0)
        {
            return decimal.Round(value, decimalsPoints, System.MidpointRounding.AwayFromZero);
        }

        public static int NearestRoundoff(this decimal value, int roundOffValue = 10) 
        {
            //return ((int)Math.Round(value / RoundOffValue)) * RoundOffValue;
             return (int)(Math.Ceiling(value / roundOffValue) * roundOffValue);
        }
    }
}
