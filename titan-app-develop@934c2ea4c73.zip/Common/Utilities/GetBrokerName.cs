﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utilities
{
    public static class GetBrokerName
    {
        public static string BrokerName(string brokerLastName, string brokerFirstName)
        {
            string BrokerName = string.Empty;
            string Commmaseperator = ", ";
            if (!string.IsNullOrEmpty(brokerLastName) && !string.IsNullOrEmpty(brokerFirstName))
            {
                BrokerName = brokerLastName + Commmaseperator + brokerFirstName;
            }
            else if (!string.IsNullOrEmpty(brokerLastName) && string.IsNullOrEmpty(brokerFirstName))
            {
                BrokerName = brokerLastName;
            }
            else if (string.IsNullOrEmpty(brokerLastName) && !string.IsNullOrEmpty(brokerFirstName))
            {
                BrokerName = brokerFirstName;
            }
            return BrokerName;
        }
    }
}
