﻿using Guardian.Core.Entities.Product.Enums;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Common.Utilities
{
    public static class CompactStatesUtillity
    {
        public static List<int> GetNonCompactStates()
        {
            throw new Exception("Error : Not Used Anymore");
            //List<int> nonCompactStateIds = new List<int>();
            //nonCompactStateIds = new List<int>
            //{
            //    (int)StateTypeEnum.CT,
            //    (int)StateTypeEnum.CA,
            //    (int)StateTypeEnum.DC,
            //    (int)StateTypeEnum.DE,
            //    (int)StateTypeEnum.FL,
            //    (int)StateTypeEnum.MT,
            //    (int)StateTypeEnum.ND,
            //    (int)StateTypeEnum.NY,
            //    (int)StateTypeEnum.SD
            //};

            //return nonCompactStateIds.ToList();
        }

        public static List<int> GetCompactStates()
        {
            throw new Exception("Error : Not Used Anymore");

            //List<int> compactStateIds = new List<int>();

            //compactStateIds = new List<int>
            //{
            //    (int)StateTypeEnum.ID,
            //    (int)StateTypeEnum.MA,
            //    (int)StateTypeEnum.MO,
            //    (int)StateTypeEnum.NM,
            //    (int)StateTypeEnum.RI,
            //    (int)StateTypeEnum.VA,
            //    (int)StateTypeEnum.VT,
            //    (int)StateTypeEnum.AL,
            //    (int)StateTypeEnum.AK,
            //    (int)StateTypeEnum.AR,
            //    (int)StateTypeEnum.AZ,
            //    (int)StateTypeEnum.CO,
            //    (int)StateTypeEnum.GA,
            //    (int)StateTypeEnum.HI,
            //    (int)StateTypeEnum.IL,
            //    (int)StateTypeEnum.IN,
            //    (int)StateTypeEnum.IA,
            //    (int)StateTypeEnum.KS,
            //    (int)StateTypeEnum.KY,
            //    (int)StateTypeEnum.LA,
            //    (int)StateTypeEnum.ME,
            //    (int)StateTypeEnum.MD,
            //    (int)StateTypeEnum.MI,
            //    (int)StateTypeEnum.MN,
            //    (int)StateTypeEnum.MS,
            //    (int)StateTypeEnum.NE,
            //    (int)StateTypeEnum.NV,
            //    (int)StateTypeEnum.NH,
            //    (int)StateTypeEnum.NJ,
            //    (int)StateTypeEnum.NC,
            //    (int)StateTypeEnum.OH,
            //    (int)StateTypeEnum.OK,
            //    (int)StateTypeEnum.OR,
            //    (int)StateTypeEnum.PA,
            //    (int)StateTypeEnum.SC,
            //    (int)StateTypeEnum.TN,
            //    (int)StateTypeEnum.TX,
            //    (int)StateTypeEnum.UT,
            //    (int)StateTypeEnum.WA,
            //    (int)StateTypeEnum.WV,
            //    (int)StateTypeEnum.WI,
            //    (int)StateTypeEnum.WY
            //};

            //return compactStateIds.ToList();
        }

        public static List<int> GetNonCompactStates2019()
        {
            throw new Exception("Error : Not Used Anymore");
            //List<int> nonCompactStateIds2019 = new List<int>();
            //nonCompactStateIds2019 = new List<int>
            //{
            //    (int)StateTypeEnum.CT,
            //    (int)StateTypeEnum.CA,
            //    (int)StateTypeEnum.DE,
            //    (int)StateTypeEnum.FL,
            //    (int)StateTypeEnum.MT,
            //    (int)StateTypeEnum.ND,
            //    (int)StateTypeEnum.NY,
            //    (int)StateTypeEnum.SD,
            //    (int)StateTypeEnum.WY
            //};

            //return nonCompactStateIds2019.ToList();
        }

        public static List<int> GetCompactStates2019()
        {
            throw new Exception("Error : Not Used Anymore");


            //List<int> compactStateIds2019 = new List<int>();

            //compactStateIds2019 = new List<int>
            //{
            //    (int)StateTypeEnum.ID,
            //    (int)StateTypeEnum.MA,
            //    (int)StateTypeEnum.MO,
            //    (int)StateTypeEnum.NM,
            //    (int)StateTypeEnum.RI,
            //    (int)StateTypeEnum.VA,
            //    (int)StateTypeEnum.VT,
            //    (int)StateTypeEnum.AL,
            //    (int)StateTypeEnum.AK,
            //    (int)StateTypeEnum.AR,
            //    (int)StateTypeEnum.AZ,
            //    (int)StateTypeEnum.CO,
            //    (int)StateTypeEnum.DC,
            //    (int)StateTypeEnum.GA,
            //    (int)StateTypeEnum.HI,
            //    (int)StateTypeEnum.IL,
            //    (int)StateTypeEnum.IN,
            //    (int)StateTypeEnum.IA,
            //    (int)StateTypeEnum.KS,
            //    (int)StateTypeEnum.KY,
            //    (int)StateTypeEnum.LA,
            //    (int)StateTypeEnum.ME,
            //    (int)StateTypeEnum.MD,
            //    (int)StateTypeEnum.MI,
            //    (int)StateTypeEnum.MN,
            //    (int)StateTypeEnum.MS,
            //    (int)StateTypeEnum.NE,
            //    (int)StateTypeEnum.NV,
            //    (int)StateTypeEnum.NH,
            //    (int)StateTypeEnum.NJ,
            //    (int)StateTypeEnum.NC,
            //    (int)StateTypeEnum.OH,
            //    (int)StateTypeEnum.OK,
            //    (int)StateTypeEnum.OR,
            //    (int)StateTypeEnum.PA,
            //    (int)StateTypeEnum.SC,
            //    (int)StateTypeEnum.TN,
            //    (int)StateTypeEnum.TX,
            //    (int)StateTypeEnum.UT,
            //    (int)StateTypeEnum.WA,
            //    (int)StateTypeEnum.WV,
            //    (int)StateTypeEnum.WI,
            //};

            //return compactStateIds2019.ToList();
        }


    }
}
