﻿using System;
using System.Configuration;
using Logger.Static;

namespace Common.Utilities
{
    public class AppSettingsReader 
    {       
        public static string ReadAppSettingValue(string appSettingKey)
        {
            var appSettingValue = ConfigurationManager.AppSettings[appSettingKey];
            if (appSettingValue == null) throw new ApplicationException(appSettingKey + " has not been found in the appSettings.config!");

            if (!appSettingKey.ToLower().Contains("password"))
            {
                Log.TraceFormat("AppSetting {0}={1}", appSettingKey, appSettingValue);
            }
            return appSettingValue;
        }
    }
}