﻿using Newtonsoft.Json;
using System.Data;

namespace Common.Utilities
{
    public static class DataTableMapper
    {
        public static DataTable GetDataTable(string obj)
        {
            DataTable dataTable = (DataTable)JsonConvert.DeserializeObject(obj, (typeof(DataTable)));
            return dataTable;
        }
    }
}
