﻿

namespace Common.Utilities
{
    public static class AdjustCurrentAmount
    {
        public static decimal? GetAdjustedAmount(decimal? currentAmount, decimal? priorAmount)
        {
            decimal? result = null;
            if (priorAmount.HasValue && priorAmount != 0m)
            {
                result = (currentAmount + priorAmount) * 0.5m;
            }
            else
            {
                result = currentAmount * 0.75m;
            }
            return result;
        }
    }
}
