﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utilities
{
    public static class MinHelper
    {
        public static decimal? GetMinVal(this decimal value1, decimal value2, decimal? values3 = null, decimal? values4 = null, decimal? values5 = null, decimal? values6 = null)
        {
            decimal? minValue = 0; 

            if (value1 > value2)
            {
                minValue = value2;
            }
            else
            {
                minValue = value1;
            }

            if (values3 != null && minValue > values3)
            {
                minValue = values3;
            }

            if (values4 != null && minValue > values4)
            {
                minValue = values4;
            }

            if (values5 != null && minValue > values5)
            {
                minValue = values5;
            }

            if (values6 != null && minValue > values6)
            {
                minValue = values6;
            }

            return minValue;
        }
    }
}
