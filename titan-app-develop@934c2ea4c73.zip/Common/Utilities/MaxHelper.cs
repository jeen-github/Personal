﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utilities
{
    public static class MaxHelper
    {
        public static decimal? GetMaxVal(this decimal value1, decimal value2, decimal? values3 = null, decimal? values4 = null, decimal? values5 = null, decimal? values6 = null)
        {
            decimal? maxValue = 0; 

            if (value1 < value2)
            {
                maxValue = value2;
            }
            else
            {
                maxValue = value1;
            }

            if (values3 != null && maxValue < values3)
            {
                maxValue = values3;
            }

            if (values4 != null && maxValue < values4)
            {
                maxValue = values4;
            }

            if (values5 != null && maxValue < values5)
            {
                maxValue = values5;
            }

            if (values6 != null && maxValue < values6)
            {
                maxValue = values6;
            }

            return maxValue;
        }
    }
}
