﻿using System;

namespace Common.Utilities
{
    public class FileMimeTypeUtility
    {
        public static string GetMimeType(string fileExtension)
        {
            if (string.IsNullOrEmpty(fileExtension)) throw new ArgumentNullException("fileExtension");
            fileExtension = fileExtension.ToLowerInvariant();

            switch (fileExtension)
            {
                case "pdf":
                    return "application/pdf";
                case "doc":
                    return "application/msword";
                case "docx":
                    return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                case "xls":
                    return "application/vnd.ms-excel";
                case "xlsx":
                    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                case "csv":
                    return "text/csv";
                case "jpg":
                    return "image/jpeg";
                case "jpeg":
                    return "image/jpeg";
                case "png":
                    return "image/png";
                case "gif":
                    return "image/gif";
                case "tiff":
                    return "image/tiff";
                case "ppt":
                    return "application/vnd.ms-powerpoint";
                case "pptx":
                    return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
                case "eps":
                    return "application/postscript";
                case "txt":
                    return "text/csv";

                default:
                    throw new Exception("Mime type not found");
            }
        }
    }
}