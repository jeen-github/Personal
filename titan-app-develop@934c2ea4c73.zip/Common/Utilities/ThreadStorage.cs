﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Common.Utilities
{
    public class ThreadLocalData
    {
        public ThreadLocalData()
        {
            AuditData = new Dictionary<string, object>();
            LoggingContext = new Dictionary<string, object>();
        }

        //public UnitOfWork UnitOfWork { get; set; }
        public Dictionary<string, object> AuditData { get; set; }
        public Dictionary<string, object> LoggingContext { get; set; }
    }

    public class ThreadStorage
    {
        static ThreadLocal<ThreadLocalData> _ThreadLocal = new ThreadLocal<ThreadLocalData>(() => new ThreadLocalData());

        public static ThreadLocalData ThreadLocal
        {
            get
            {
                return _ThreadLocal.Value;
            }
        }

        public static void Clear()
        {
            _ThreadLocal.Value.AuditData.Clear();
            _ThreadLocal.Value.LoggingContext.Clear();
        }
    }
}
