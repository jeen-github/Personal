﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Common.Logging;
using Logger;
using NLog.Targets;
using NLog;

namespace Common.Utilities
{
    public static class LogUtility
    {
        public static void InitializeLogger(string applicationName)
        {
            const string loggerDictionaryName = "LoggerDictionary";

            LogContext.Initialize(
                (valuesDictionary) => {
                    if (HttpContext.Current != null)
                    {
                        HttpContext.Current.Items[loggerDictionaryName] = valuesDictionary;
                    }
                    else
                    {
                        ThreadStorage.ThreadLocal.LoggingContext = valuesDictionary;
                    }
                },
                () => {
                    if (HttpContext.Current == null) return ThreadStorage.ThreadLocal.LoggingContext;

                    if (HttpContext.Current.Items[loggerDictionaryName] == null)
                    {
                        HttpContext.Current.Items[loggerDictionaryName] = new Dictionary<string, object>();
                    }

                    return HttpContext.Current.Items[loggerDictionaryName] as Dictionary<string, object>;
                });

            GlobalDiagnosticsContext.Set("applicationName", applicationName);
            GlobalDiagnosticsContext.Set("CMSDatabaseConnection", AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection"));
            
            var log = LogWrapper.GetLogger(MethodBase.GetCurrentMethod().DeclaringType.ToString());
            log.Trace("Logging Initialized");            
        }

        public static void AddCaseToContext(int caseId)
        {
            LogContext.Add("CaseId", caseId);
        }

        public static void AddPdrToContext(int pdrId)
        {
            LogContext.Add("PdrId", pdrId);
        }

        public static void AddQuoteToContext(int quoteId)
        {
            LogContext.Add("QuoteId", quoteId);
        }

        public static void AddSessionIdToContext(string sessionId)
        {
            LogContext.Add("SessionId", sessionId);
        }

        public static void AddWorkUnitIdToContext(int workUnitId)
        {
            LogContext.Add("WorkUnitId", workUnitId);
        }
    }
}
