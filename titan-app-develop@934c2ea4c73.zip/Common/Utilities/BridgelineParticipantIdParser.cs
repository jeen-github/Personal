﻿using System.Linq;
using Common.Exceptions;
using Logger.Static;

namespace Common.Utilities
{
    public class BridgelineParticipantIdParser
    {
        private const char BridgelineParticipantIdSeparator = '-';
        public static int GetParticipantId(string bridgelineParticipantId)
        {
            Log.TraceFormat("+BridgelineParticipantIdParser.GetParticipantId bridgelineParticipantId={0}", bridgelineParticipantId);

            if (string.IsNullOrEmpty(bridgelineParticipantId)) throw new ValidationException("Empty bridgeline participant Id!");

            var participantIdString = bridgelineParticipantId;
            if (bridgelineParticipantId.Contains(BridgelineParticipantIdSeparator))
            {
                participantIdString = bridgelineParticipantId.Split(BridgelineParticipantIdSeparator).Last();
            }

            var enrollmentParticipantId = 0;
            if (!int.TryParse(participantIdString, out enrollmentParticipantId)) throw new ValidationException("Invalid participant id " + participantIdString);

            Log.TraceFormat("-BridgelineParticipantIdParser.GetParticipantId bridgelineParticipantId={0} => enrollmentParticipantId={1}", bridgelineParticipantId, enrollmentParticipantId);

            return enrollmentParticipantId;
        }
    }
}