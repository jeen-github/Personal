﻿namespace Common.Utilities
{
    public static class PercentageHelper
    {
        public static decimal? ToDBPercentage(this decimal? source)
        {
            return source / 100;
        }

        public static decimal? ToViewPercentage(this decimal? source)
        {
            return source * 100;
        }
    }
}
