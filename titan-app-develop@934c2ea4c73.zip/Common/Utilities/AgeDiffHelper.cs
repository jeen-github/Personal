﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utilities
{
    public static class AgeDiffHelper
    {
        public static int GetAge(this DateTime? source, DateTime? customDate)
        {
            if (!source.HasValue)
            {
                return -1;
            }
            var today = DateTime.Today;
            if (customDate.HasValue)
            {
                today = customDate.Value;
            }
            var age = today.Year - source.Value.Year;
            if (source > today.AddYears(-age)) age--;
            return age;
        }
    }
}
