﻿using Logger.Static;
using System;
using System.Linq;
using System.Web;
using System.Web.Http.Controllers;

namespace Common.Utilities
{
    public static class HttpActionContextHelper
    {
        public static int GetCaseId(HttpActionContext actionContext)
        {
            try
            {
                object caseIdObject;
                string caseIdKey = actionContext.ActionArguments.Keys
                    .FirstOrDefault(key => string.Equals(key, "caseId", StringComparison.OrdinalIgnoreCase));
                if (caseIdKey != null && actionContext.ActionArguments.TryGetValue(caseIdKey, out caseIdObject))
                {
                    return (int)caseIdObject;
                }
                else
                {
                    var queryString = HttpUtility.ParseQueryString(actionContext.Request.RequestUri.Query);
                    string caseIdQueryStringKey = queryString.AllKeys
                        .FirstOrDefault(key => string.Equals(key, "caseId", StringComparison.OrdinalIgnoreCase));
                    int caseIdFromQueryString;
                    if (caseIdQueryStringKey != null && int.TryParse(queryString[caseIdQueryStringKey], out caseIdFromQueryString))
                    {
                        return caseIdFromQueryString;
                    }
                }
            }
            catch (Exception ex)
            {
                string actionName = actionContext.ActionDescriptor.ActionName;
                string requestUrl = actionContext.Request.RequestUri.ToString();
                Log.WarnFormat($"Error extracting caseId from action '{actionName}' with request URL '{requestUrl}': {ex}");
            }

            return -1;
        }
    }
}
