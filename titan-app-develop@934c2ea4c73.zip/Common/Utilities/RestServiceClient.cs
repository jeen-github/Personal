﻿using Newtonsoft.Json;
using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace Common.Utilities
{
    public class RestServiceClient
    {
        private readonly string _serviceUrl;
        private readonly string _userName;
        private readonly string _password;

        public RestServiceClient(string serviceUrl, string userName, string password)
        {
            ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Ssl3 | System.Net.SecurityProtocolType.Tls | System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
            ServicePointManager.ServerCertificateValidationCallback += (object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors policyErrors) => true;

            _serviceUrl = serviceUrl;
            _userName = userName;
            _password = password;
        }

        public async Task<TResponse> GetAsync<TResponse>() where TResponse : new()
        {
            var client = new RestClient(_serviceUrl)
            {
                Authenticator = new HttpBasicAuthenticator(_userName, _password)
            };

            var restRequest = new RestRequest(Method.GET) { Timeout = 300000 };

            var restResponse = await client.ExecuteGetAsync<TResponse>(restRequest);

            if (restResponse.ErrorException != null)
            {
                throw new ApplicationException("Error retrieving response.  Check inner details for more info.", restResponse.ErrorException);
            }

            if (restResponse.StatusCode != HttpStatusCode.OK)
            {
                var message = $"Error retrieved from server: {JsonConvert.SerializeObject(restResponse)}";
                throw new ApplicationException(message);
            }

            return restResponse.Data;
        }

        public async Task<TResponse> ExecuteAsync<TRequest, TResponse>(TRequest request) where TResponse : new()
        {
            var client = new RestClient();

            client.BaseUrl = new Uri(_serviceUrl);
            client.Authenticator = new HttpBasicAuthenticator(_userName, _password);

            var restRequest = new RestRequest { Method = Method.POST };
            restRequest.AddJsonBody(request);
            restRequest.Timeout = 300000;

            var restResponse = await client.ExecuteAsync<TResponse>(restRequest);

            if (restResponse.ErrorException != null)
            {
                throw restResponse.ErrorException;
            }
            if (restResponse.StatusCode != HttpStatusCode.OK)
            {
                throw new Exception("Error:" + JsonConvert.SerializeObject(restResponse));
            }

            return restResponse.Data;
        }

        public IRestResponse SendRequest(RestRequest request)
        {
            var client = new RestClient
            {
                BaseUrl = new Uri(_serviceUrl),
                Authenticator = new HttpBasicAuthenticator(_userName, _password)
            };

            request.Timeout = 300000; // 5 min

            var restResponse = client.Execute(request);

            if (restResponse.ErrorException != null)
            {
                throw restResponse.ErrorException;
            }

            if (restResponse.StatusCode != HttpStatusCode.OK)
            {
                throw new Exception("Error:" + JsonConvert.SerializeObject(restResponse));
            }

            return restResponse;
        }

        public IRestResponse SendRequestAsync(RestRequest request)
        {

            var client = new RestClient
            {
                BaseUrl = new Uri(_serviceUrl),
                Authenticator = new HttpBasicAuthenticator(_userName, _password)
            };

            request.Timeout = 300000; // 5 min

            var restResponse = client.ExecuteAsync(request).GetAwaiter().GetResult();

            if (restResponse.ErrorException != null)
            {
                throw restResponse.ErrorException;
            }

            if (restResponse.StatusCode != HttpStatusCode.OK)
            {
                throw new Exception("Error:" + JsonConvert.SerializeObject(restResponse));
            }

            return restResponse;
        }
    }
}