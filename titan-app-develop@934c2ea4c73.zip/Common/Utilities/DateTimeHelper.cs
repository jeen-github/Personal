﻿using System;

namespace Common.Utilities
{
    public static class DateTimeHelper
    {
        public static DateTime GetNormalizedDateTime(DateTime datetime)
        {
            DateTime normalizedDate = new DateTime(datetime.Year, datetime.Month, datetime.Day, 23, 59, 00);

            return normalizedDate;

        }
    }
}
