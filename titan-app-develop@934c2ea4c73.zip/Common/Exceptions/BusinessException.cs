﻿using System;
using System.Collections.Generic;

namespace Common.Exceptions
{
    public class BusinessException : Exception
    {
        public List<string> Messages { get; set; }
        public string Title { get; set; }

        public BusinessException(string title, string message) : base(message)
        {
            Messages = new List<string>
            {
                message
            };
            Title = title;
        }

        public BusinessException(string title, List<string> messages) : base(string.Join(", ", messages))
        {
            Messages = messages;
            Title = title;
        }
    }

    public class ValidationException : BusinessException
    {
        private const string ValidationErrorTitle = "Validation error!";

        public ValidationException(string message) : base(ValidationErrorTitle, message)
        {
        }

        public ValidationException(List<string> messages) : base(ValidationErrorTitle, messages)
        {
        }
    }
}