﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Filters;
using Common.Exceptions;
using Logger.Static;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NLog.Targets.Wrappers;

namespace Common.WebApiFilters
{
    public class ExceptionHandlingFilter : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext context)
        {
            ErrorViewModel errorViewModel = null;
            HttpStatusCode httpStatusCode = HttpStatusCode.OK;

            var businessException = context.Exception as BusinessException;
            if (businessException != null)
            {
                Log.WarnFormat("BUSINESS ERROR in controller:{0} action:{1}",
                    context.Exception,
                    context.ActionContext.ActionDescriptor.ControllerDescriptor.ControllerName,
                    context.ActionContext.ActionDescriptor.ActionName);

                errorViewModel = new ErrorViewModel(businessException);
                httpStatusCode = HttpStatusCode.BadRequest;                
            }
            else
            {
                Log.ErrorFormat("UNHANDLED ERROR in controller:{0} action:{1} httpMethod:{2} url:{3}",
                    context.Exception,
                    context.ActionContext.ActionDescriptor.ControllerDescriptor.ControllerName,
                    context.ActionContext.ActionDescriptor.ActionName,
                    context.ActionContext.Request.Method,
                    context.ActionContext.Request.RequestUri);

                errorViewModel = new ErrorViewModel(context.Exception);
                httpStatusCode = HttpStatusCode.InternalServerError;
            }

            var stringContent = JsonConvert.SerializeObject(errorViewModel);

            context.Response = new HttpResponseMessage(httpStatusCode)
            {
                Content = new StringContent(stringContent),
                ReasonPhrase = "Error"
            };
        }
    }
}