﻿using Common.Utilities;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Text;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace Common.WebApiFilters
{
    public class LoggingFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            LogUtility.AddSessionIdToContext(Guid.NewGuid().ToString());
            LogUtility.AddCaseToContext(HttpActionContextHelper.GetCaseId(actionContext));

            if (actionContext.ControllerContext.ControllerDescriptor.ControllerName != "Health")
            {
                var inputParameters = GetInputParameters(actionContext);
                if (!string.IsNullOrEmpty(inputParameters))
                {
                    Log.TraceFormat("+{0}.{1} Params:{2}",
                        actionContext.ControllerContext.ControllerDescriptor.ControllerName,
                        actionContext.ActionDescriptor.ActionName,
                        inputParameters);
                }
                else
                {
                    Log.TraceFormat("+{0}.{1}",
                        actionContext.ControllerContext.ControllerDescriptor.ControllerName,
                        actionContext.ActionDescriptor.ActionName);
                }
            }

            base.OnActionExecuting(actionContext);
        }

        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            if (actionExecutedContext.ActionContext.ControllerContext.ControllerDescriptor.ControllerName != "Health")
            {
                Log.TraceFormat("-{0}.{1}",
                    actionExecutedContext.ActionContext.ControllerContext.ControllerDescriptor.ControllerName,
                    actionExecutedContext.ActionContext.ActionDescriptor.ActionName);
            }

            base.OnActionExecuted(actionExecutedContext);
        }

        private string GetInputParameters(HttpActionContext actionContext)
        {
            var stringBuilder = new StringBuilder();

            foreach (var paramName in actionContext.ActionArguments.Keys)
            {
                var paramValue = actionContext.ActionArguments[paramName];
                string paramValueString;

                if (paramValue is string)
                {
                    paramValueString = (string)paramValue;
                }
                else
                {
                    paramValueString = JsonConvert.SerializeObject(paramValue);
                }

                stringBuilder.AppendFormat("{0}='{1}' ", paramName, paramValueString);
            }

            return stringBuilder.ToString();
        }
    }
}
