﻿using System;
using System.Collections.Generic;
using Common.Exceptions;

namespace Common.WebApiFilters
{
    public class ErrorViewModel
    {
        public bool IsBusinessError { get; set; }
        public string Title { get; set; }
        public List<string> Messages { get; set; }
        public Exception Exception { get; set; }

        public ErrorViewModel(BusinessException exception)
        {
            IsBusinessError = true;
            Messages = exception.Messages;
            Title = exception.Title;
        }

        public ErrorViewModel(Exception exception)
        {
            IsBusinessError = false;            
            Title = exception.Message;
            Exception = exception;
        }
    }
}