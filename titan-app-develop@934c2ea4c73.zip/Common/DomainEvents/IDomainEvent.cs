﻿using System;

namespace Common.DomainEvents
{
    public interface IDomainEvent
    {
        DateTime DateOccurred { get; }
    }
}