﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using CMS.Model.Attributes;

namespace CMS.Model.Extensions
{
    public static class EnumExtensions
    {
        public static T GetValueFromDescription<T>(this string description)
        {
            var type = typeof(T);
            if (!type.IsEnum) throw new InvalidOperationException();
            foreach (var field in type.GetFields())
            {
                var attribute = Attribute.GetCustomAttribute(field,
                    typeof(CodeAttribute)) as CodeAttribute;
                if (attribute != null)
                {
                    if (attribute.Name == description)
                        return (T)field.GetValue(null);
                }
                else
                {
                    if (field.Name == description)
                        return (T)field.GetValue(null);
                }
            }
            return default(T);
        }

        public static string GetDescription(this Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());
            if (fi == null)
            {
                return "";
            }

            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

            if (attributes != null && attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        public static List<EnumMetadata> GetDescriptions(this Enum value)
        {
            var results = new List<EnumMetadata>();
            var enumValues = value.GetType().GetEnumValues();
            foreach (var enumValue in enumValues)
            {
                FieldInfo fi = value.GetType().GetField(enumValue.ToString());
                DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                var enumViewModel = new EnumMetadata
                {
                    Id = (int)fi.GetValue(enumValue),
                    EnumName = enumValue.ToString(),
                };

                if (attributes != null && attributes.Length > 0)
                {
                    enumViewModel.Description = attributes[0].Description;
                }

                results.Add(enumViewModel);
            }

            return results;
        }

        public static string GetCode(this Enum value)
        {
            var attributes = (CodeAttribute[])value
                .GetType()
                .GetField(value.ToString())
                .GetCustomAttributes(typeof(CodeAttribute), false);
            return attributes.Length > 0 ? attributes[0].Name : null;
        }
    }

    public class EnumMetadata
    {
        public int Id { get; set; }
        public string EnumName { get; set; }
        public string Description { get; set; }
    }
}