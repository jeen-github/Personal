﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// PlanDesignRequestStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum PlanDesignRequestStatusTypeEnum
    {
      
		[Description("Underwriting_Review")]
		[Code("Underwriting_Review")]
        UnderwritingReview = 1,
      
		[Description("Approved")]
		[Code("Approved")]
        Approved = 2,
      
		[Description("Referred")]
		[Code("Referred")]
        Referred = 3,
      
		[Description("Released")]
		[Code("Released")]
        Released = 4,
      
		[Description("Withdrawn")]
		[Code("Withdrawn")]
        Withdrawn = 5,
      
		[Description("Declined")]
		[Code("Declined")]
        Declined = 6,
      
		[Description("Submitted")]
		[Code("Submitted")]
        Submitted = 7,
      
		[Description("Census Approved")]
		[Code("CensusApproved")]
        CensusApproved = 8,
      
		[Description("Formal Offer")]
		[Code("FormalOffer")]
        FormalOffer = 9,
      
		[Description("Sold")]
		[Code("Sold")]
        Sold = 10
  }
}
 