﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// BillingMethodType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum BillingMethodTypeEnum
    {
      
		[Description("Guardian Anytime")]
		[Code("GuardianAnytime")]
        GuardianAnytime = 1,
      
		[Description("Automatic Payroll Deduction")]
		[Code("AutomaticPayrollDeduction")]
        AutomaticPayrollDeduction = 2,
      
		[Description("List Bill")]
		[Code("ListBill")]
        ListBill = 3,
      
		[Description("List Bill GOM")]
		[Code("ListBillGOM")]
        ListBillGOM = 4,
      
		[Description("Direct Bill")]
		[Code("DirectBill")]
        DirectBill = 5
  }
}
 