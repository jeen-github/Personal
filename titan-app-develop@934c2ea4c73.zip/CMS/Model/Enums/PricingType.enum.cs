﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// PricingType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum PricingTypeEnum
    {      
		[Description("Provider Choice 2016")]
		[Code("PC2016")]
        PC2016 = 1,
      
		[Description("Provider Choice 2019")]
		[Code("PC2019")]
        PC2019 = 2,

        [Description("Provider Choice 2023")]
        [Code("PC2023")]
        PC2023 = 3
    }
}
 