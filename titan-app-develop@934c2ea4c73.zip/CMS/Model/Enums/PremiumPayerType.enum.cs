﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// PremiumPayerType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum PremiumPayerTypeEnum
    {
      
		[Description("Employee")]
		[Code("Employee")]
        Employee = 1,
      
		[Description("Employer")]
		[Code("Employer")]
        Employer = 2
  }
}
 