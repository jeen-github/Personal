﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// EnrollmentParticipantOnlineStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum EnrollmentParticipantOnlineStatusTypeEnum
    {
      
		[Description("No Response")]
		[Code("NoResponse")]
        NoResponse = 1,
      
		[Description("Incomplete")]
		[Code("Incomplete")]
        Incomplete = 2,
      
		[Description("Enrollment Complete")]
		[Code("EnrollmentComplete")]
        EnrollmentComplete = 3,
      
		[Description("Declined Coverage")]
		[Code("DeclinedCoverage")]
        DeclinedCoverage = 4,
      
		[Description("Accepted Paper Application")]
		[Code("AcceptedPaperApplication")]
        AcceptedPaperApplication = 5
  }
}
 