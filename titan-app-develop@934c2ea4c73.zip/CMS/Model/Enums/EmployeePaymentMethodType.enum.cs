﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// EmployeePaymentMethodType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum EmployeePaymentMethodTypeEnum
    {
      
		[Description("EE Portion Direct Bill")]
		[Code("EEPortionDirectBill")]
        EEPortionDirectBill = 1,
      
		[Description("EE Portion Payroll Deduct")]
		[Code("EEPortionPayrollDeduct")]
        EEPortionPayrollDeduct = 2,
      
		[Description("Direct Bill")]
		[Code("DirectBill")]
        DirectBill = 3,
      
		[Description("Payroll Deduct")]
		[Code("PayrollDeduct")]
        PayrollDeduct = 4
  }
}
 