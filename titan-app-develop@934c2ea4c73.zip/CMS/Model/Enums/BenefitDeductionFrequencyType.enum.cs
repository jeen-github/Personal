﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// BenefitDeductionFrequencyType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum BenefitDeductionFrequencyTypeEnum
    {
      
		[Description("Annual")]
		[Code("1")]
        Annual = 1,
      
		[Description("Bi Monthly (24 weeks)")]
		[Code("24")]
        BiMonthly24weeks = 2,
      
		[Description("Bi Weekly (26 Paychecks)")]
		[Code("26")]
        BiWeekly26Paychecks = 3,
      
		[Description("Direct Bill")]
		[Code("0")]
        DirectBill = 4,
      
		[Description("Semi Monthly (24 Paychecks)")]
		[Code("24")]
        SemiMonthly24Paychecks = 5,
      
		[Description("Monthly")]
		[Code("12")]
        Monthly = 6,
      
		[Description("Weekly")]
		[Code("52")]
        Weekly = 7,
      
		[Description("Semi-Annual")]
		[Code("SemiAnnual")]
        SemiAnnual = 8,
      
		[Description("Quarterly")]
		[Code("Quarterly")]
        Quarterly = 9
  }
}
 