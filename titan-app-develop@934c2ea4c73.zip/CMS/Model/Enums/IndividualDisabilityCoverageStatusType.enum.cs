﻿using CMS.Model.Attributes;
using System.CodeDom.Compiler;
using System.ComponentModel;

namespace CMS.Model.Enums
{
	/// <summary>
	/// IndividualDisabilityCoverageStatusType auto generated enumeration
	/// </summary>
	[GeneratedCode("TextTemplatingFileGenerator", "10")]
	public enum IndividualDisabilityCoverageStatusTypeEnum
	{
		[Description("Active coverage status indicator")]
		[Code("Active")]
		Active = 1,

		[Description("Deleted coverage status indicator")]
		[Code("Deleted")]
		Deleted = 2
	}
}