﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// PDRClassPlanType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum PDRClassPlanTypeEnum
    {
      
		[Description("Primary")]
		[Code("Primary")]
        Primary = 1,
      
		[Description("Voluntary GSI BuyUp")]
		[Code("VoluntaryGSIBuyUp")]
        VoluntaryGSIBuyUp = 2
  }
}
 