﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// NotesCategoryType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum NotesCategoryTypeEnum
    {
      
		[Description("Company Tab")]
		[Code("Company_Tab")]
        Company_Tab = 1,
      
		[Description("Existing Coverage Tab")]
		[Code("Existing_Coverage_Tab")]
        Existing_Coverage_Tab = 2,
      
		[Description("Producer Tab")]
		[Code("Producer_Tab")]
        Producer_Tab = 3,
      
		[Description("PDR Tab")]
		[Code("PDR_Tab")]
        PDR_Tab = 4,
      
		[Description("Release Tab")]
		[Code("Release_Tab")]
        Release_Tab = 5,
      
		[Description("Illustration Tab")]
		[Code("Illustration_Tab")]
        Illustration_Tab = 6,
      
		[Description("Implementation Tab")]
		[Code("Implementation_Tab")]
        Implementation_Tab = 7,
      
		[Description("Census Reconciliation Tab")]
		[Code("Census_Reconciliation_Tab")]
        Census_Reconciliation_Tab = 8,
      
		[Description("Address Tab")]
		[Code("Address_Tab")]
        Address_Tab = 9,
      
		[Description("Billing Tab")]
		[Code("Billing_Tab")]
        Billing_Tab = 10,
      
		[Description("AnnualReview Tab")]
		[Code("AnnualReview_Tab")]
        AnnualReview_Tab = 11
  }
}
 