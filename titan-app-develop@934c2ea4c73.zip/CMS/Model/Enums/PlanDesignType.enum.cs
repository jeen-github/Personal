﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// PlanDesignType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum PlanDesignTypeEnum
    {
      
		[Description("Supplemental Plan")]
		[Code("SupplementalPlan")]
        SupplementalPlan = 1,
      
		[Description("Bonus Only Plan")]
		[Code("BonusOnlyPlan")]
        BonusOnlyPlan = 2,
      
		[Description("Combination Plan (Traditional 60% Plan split between LTD and IDI, i.e., 40% LTD/20% IDI)")]
		[Code("CombinationPlan")]
        CombinationPlan = 3,
      
		[Description("Reverse Combination Plan")]
		[Code("ReverseCombinationPlan")]
        ReverseCombinationPlan = 4,
      
		[Description("Flat Benefit Plan")]
		[Code("FlatBenefitPlan")]
        FlatBenefitPlan = 5,
      
		[Description("Stand Alone Individual Disability Insurance (IDI) Plan")]
		[Code("StandAloneIDIPlan")]
        StandAloneIDIPlan = 6,
      
		[Description("Stand Alone Retirement Protection Plus (RPP) Plan")]
		[Code("StandAloneRPPPlan")]
        StandAloneRPPPlan = 7
  }
}
 