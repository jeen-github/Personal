﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// RetirementContributionsType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum RetirementContributionsTypeEnum
    {
      
		[Description("Flat Contribution")]
		[Code("FlatContribution")]
        FlatContribution = 1,
      
		[Description("Percent of Covered Earnings")]
		[Code("PercentofCoveredEarnings")]
        PercentofCoveredEarnings = 2,
      
		[Description("Actual Contribution on Census")]
		[Code("ActualContributiononCensus")]
        ActualContributiononCensus = 3
  }
}
 