﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// TaxabilityType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum TaxabilityTypeEnum
    {
      
		[Description("Taxable")]
		[Code("Taxable")]
        Taxable = 1,
      
		[Description("Non-Taxable / Gross Up")]
		[Code("Non_Taxable_Gross_Up")]
        Non_Taxable_Gross_Up = 2,
      
		[Description("Non-Taxable / Tax Choice")]
		[Code("Non_Taxable_Tax_Choice")]
        Non_Taxable_Tax_Choice = 3
  }
}
 