﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// WholesalerType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum WholesalerTypeEnum
    {
      
		[Description("Internal")]
		[Code("Internal")]
        Internal = 1,
      
		[Description("External")]
		[Code("External")]
        External = 2
  }
}
 