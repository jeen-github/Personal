﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// BenefitPremiumDocumentStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum BenefitPremiumDocumentStatusTypeEnum
    {
      
		[Description("Under Review")]
		[Code("UnderReview")]
        UnderReview = 1,
      
		[Description("Approved")]
		[Code("Approved")]
        Approved = 2,
      
		[Description("Delivered")]
		[Code("Delivered")]
        Delivered = 3,
      
		[Description("Participants are in error")]
		[Code("B&PError")]
        Participants_are_in_error = 4
  }
}
 