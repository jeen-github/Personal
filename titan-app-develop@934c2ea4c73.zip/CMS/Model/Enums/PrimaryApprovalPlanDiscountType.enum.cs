﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// PrimaryApprovalPlanDiscountType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum PrimaryApprovalPlanDiscountTypeEnum
    {
      
		[Description("0%")]
		[Code("0")]
        Discount_0 = 1,
      
		[Description("5%")]
		[Code("5")]
        Discount_5 = 2,
      
		[Description("10%")]
		[Code("10")]
        Discount_10 = 3,
      
		[Description("15%")]
		[Code("15")]
        Discount_15 = 4,
      
		[Description("20%")]
		[Code("20")]
        Discount_20 = 5,
      
		[Description("25%")]
		[Code("25")]
        Discount_25 = 6,
      
		[Description("30%")]
		[Code("30")]
        Discount_30 = 7,
      
		[Description("35%")]
		[Code("35")]
        Discount_35 = 8
  }
}
 