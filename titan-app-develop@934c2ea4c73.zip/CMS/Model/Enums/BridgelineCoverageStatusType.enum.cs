﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// BridgelineCoverageStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum BridgelineCoverageStatusTypeEnum
    {
      
		[Description("Known in Titan without changes")]
		[Code("Known_in_Titan_without_changes")]
        Known_in_Titan_without_changes = 1,
      
		[Description("Known in Titan with changes")]
		[Code("Known_in_Titan_with_changes")]
        Known_in_Titan_with_changes = 2,
      
		[Description("Added coverage")]
		[Code("Added_coverage")]
        Added_coverage = 3
  }
}
 