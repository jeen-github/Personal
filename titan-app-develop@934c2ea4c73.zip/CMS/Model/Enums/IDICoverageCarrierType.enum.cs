﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// IDICoverageCarrierType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum IDICoverageCarrierTypeEnum
    {
      
		[Description("Guardian")]
		[Code("Guardian")]
        Guardian = 1,
      
		[Description("Berkshire")]
		[Code("Berkshire")]
        Berkshire = 2,
      
		[Description("MassMutual")]
		[Code("MassMutual")]
        MassMutual = 3,
      
		[Description("MetLife")]
		[Code("MetLife")]
        MetLife = 4,
      
		[Description("Unum")]
		[Code("Unum")]
        Unum = 5,
      
		[Description("Principal")]
		[Code("Principal")]
        Principal = 6,
      
		[Description("Standard")]
		[Code("Standard")]
        Standard = 7,
      
		[Description("Ameritas")]
		[Code("Ameritas")]
        Ameritas = 8,
      
		[Description("VA")]
		[Code("VA")]
        VA = 9,
      
		[Description("Other/Multiple")]
		[Code("Other/Multiple")]
        Other = 99
  }
}
 