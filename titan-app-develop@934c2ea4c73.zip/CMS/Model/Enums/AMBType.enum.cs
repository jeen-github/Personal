﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// AMBType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum AMBTypeEnum
    {
      
		[Description("Negative")]
		[Code("Negative")]
        Negative = 1,
      
		[Description("Online/Paper")]
		[Code("OnlinePaper")]
        OnlinePaper = 2,
      
		[Description("Paper")]
		[Code("Paper")]
        Paper = 3
  }
}
 