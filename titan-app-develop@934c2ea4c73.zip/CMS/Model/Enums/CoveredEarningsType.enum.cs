﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// CoveredEarningsType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum CoveredEarningsTypeEnum
    {
      
		[Description("Base Salary Only")]
		[Code("BaseSalaryOnly")]
        BaseSalaryOnly = 1,
      
		[Description("Base Salary + Bonus")]
		[Code("BaseSalary+Bonus")]
        BaseSalary_Bonus = 2,
      
		[Description("Base Salary + Bonus + Commission")]
		[Code("BaseSalary+Bonus+Commission")]
        BaseSalary_Bonus_Commission = 3,
      
		[Description("Base Salary + Commission")]
		[Code("BaseSalary+Commission")]
        BaseSalary_Commission = 4,
      
		[Description("W-2 Income")]
		[Code("W-2Income")]
        W_2Income = 5,
      
		[Description("K-1 Earnings")]
		[Code("K-1Earnings")]
        K_1Earnings = 6,
      
		[Description("Total Compensation")]
		[Code("TotalCompensation")]
        TotalCompensation = 7,
      
		[Description("IDI Insurable Income")]
		[Code("IDIInsurableIncome")]
        IDIInsurableIncome = 8,

        [Description("Base Salary + K-1 Earnings")]
        [Code("BaseSalary_K_1Earnings")]
        BaseSalary_K_1Earnings = 9,

        [Description("Base Salary + Bonus + K-1 Earnings")]
        [Code("BaseSalary_Bonus_K_1Earnings")]
        BaseSalary_Bonus_K_1Earnings = 10,

        [Description("Base Salary + Commission + K-1 Earnings")]
        [Code("BaseSalary_Commission_K_1Earnings")]
        BaseSalary_Commission_K_1Earnings = 11,

        [Description("K-1 Earnings + Bonus")]
        [Code("K_1Earnings_and_bonus")]
        K_1Earnings_and_bonus = 12,

        [Description("K-1 Earnings + Commission")]
        [Code("K_1Earnings_Commission")]
        K_1Earnings_Commission = 13,

        [Description("K-1 Earnings + Bonus + Commission")]
        [Code("K_1Earnings_Bonus_Commission")]
        K_1Earnings_Bonus_Commission = 14,

        [Description("Other")]
		[Code("Other")]
        Other = 99
  }
}
 