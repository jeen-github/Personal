﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;

namespace CMS.Model.Enums
{
    /// <summary>
    /// CaseDocumentType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum CaseDocumentTypeEnum
    {

        [Description("Illustration")]
        [Code("Illustration")]
        Illustration = 1,

        [Description("Offer Letter")]
        [Code("Offer Letter")]
        OfferLetter = 2,

        [Description("LTD Experience")]
        [Code("LTD Experience")]
        LTDExperience = 3,

        [Description("GLTD Book")]
        [Code("GLTD Book")]
        GLTDBook = 4,

        [Description("E-Mail")]
        [Code("E-Mail")]
        EMail = 5,

        [Description("Billing")]
        [Code("Billing")]
        Billing = 6,

        [Description("Product Summary")]
        [Code("Product Summary")]
        ProductSummary = 7,

        [Description("Program Summary")]
        [Code("Program Summary")]
        ProgramSummary = 8,

        [Description("Enrollment")]
        [Code("Enrollment")]
        Enrollment = 9,

        [Description("Group LTD Booklet")]
        [Code("Group LTD Booklet")]
        GroupLTDBooklet = 10,

        [Description("Communication Tools")]
        [Code("Communication Tools")]
        CommunicationTools = 11,

        [Description("Benefit & Premiums")]
        [Code("Benefit & Premiums")]
        BenefitAndPremium = 12,

        [Description("Enrollment Kit")]
        [Code("Enrollment Kit")]
        EnrollmentKit = 13,

        [Description("Enrollment Tool")]
        [Code("Enrollment Tool")]
        EnrollmentTool = 14,

        [Description("Announcement Letters")]
        [Code("Announcement Letters")]
        AnnouncementLetters = 15,

        [Description("Sweep")]
        [Code("Sweep")]
        Sweep = 16,

        [Description("Producer Certification")]
        [Code("Producer Certification")]
        ProducerCertification = 17,

        [Description("Payroll File")]
        [Code("Payroll File")]
        PayrollFile = 18,

        [Description("Payroll Calendar")]
        [Code("Payroll Calendar")]
        PayrollCalendar = 19,

        [Description("Invoice")]
        [Code("Invoice")]
        Invoice = 20,

        [Description("Letter")]
        [Code("Letter")]
        Letter = 21,

        [Description("Report")]
        [Code("Report")]
        Report = 22,

        [Description("Payment Back Up")]
        [Code("Payment Back Up")]
        PaymentBackUp = 23,

        [Description("W9")]
        [Code("W9")]
        W9 = 24,

        [Description("Census")]
        [Code("Census")]
        Census = 25,

        [Description("Enrollment Census")]
        [Code("Enrollment Census")]
        EnrollmentCensus = 26,

        [Description("Negative Enrollment Letter")]
        [Code("Negative Enrollment Letter")]
        NegativeEnrollmentLetter = 27,

        [Description("ReEnrollment Census")]
        [Code("ReEnrollment Census")]
        ReEnrollmentCensus = 28,

        [Description("Add On Census")]
        [Code("Add On Census")]
        AddOnCensus = 29,

        [Description("Sold Case Submission")]
        [Code("Sold Case Submission")]
        SoldCaseSubmission = 30,

        [Description("Application")]
        [Code("Application")]
        Application = 31,
      
		[Description("Company Logo")]
		[Code("Company Logo")]
        CompanyLogo = 32,      

        [Description("Post Card")]
        [Code("Post Card")]
        PostCard = 33,

        [Description("Other")]
        [Code("Other")]
        Other = 99
    }
}
