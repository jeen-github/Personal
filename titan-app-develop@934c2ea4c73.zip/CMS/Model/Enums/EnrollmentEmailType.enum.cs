﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// EnrollmentEmailType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum EnrollmentEmailTypeEnum
    {
      
		[Description("Promote Open Enrollment")]
		[Code("Promote Open Enrollment")]
        PromoteOpenEnrollment = 1,
      
		[Description("Open Enrollment Kick-off")]
		[Code("Open Enrollment Kick-off")]
        OpenEnrollmentKickOff = 2,
      
		[Description("Reminder 1")]
		[Code("Reminder 1")]
        Reminder1 = 3,
      
		[Description("Reminder 2")]
		[Code("Reminder 2")]
        Reminder2 = 4,
      
		[Description("Final Reminder")]
		[Code("Final Reminder")]
        FinalReminder = 5
  }
}
 