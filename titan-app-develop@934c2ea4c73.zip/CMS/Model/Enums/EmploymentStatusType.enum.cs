﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// EmploymentStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum EmploymentStatusTypeEnum
    {
      
		[Description("Full Time")]
		[Code("FullTime")]
        FullTime = 1,
      
		[Description("Part Time")]
		[Code("PartTime")]
        PartTime = 2,
      
		[Description("Leave")]
		[Code("Leave")]
        Leave = 3,
      
		[Description("Terminated")]
		[Code("Terminated")]
        Terminated = 4
  }
}
 