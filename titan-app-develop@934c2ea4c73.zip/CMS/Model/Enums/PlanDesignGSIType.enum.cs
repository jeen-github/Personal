﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// PlanDesignGSIType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum PlanDesignGSITypeEnum
    {
      
		[Description("Supplemental Plan")]
		[Code("SupplementalPlan")]
        SupplementalPlan = 1,
      
		[Description("Bonus Only Plan")]
		[Code("BonusOnlyPlan")]
        BonusOnlyPlan = 2
  }
}
 