﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// InEligibleReasonType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum InEligibleReasonTypeEnum
    {
      
		[Description("Maximum # of solicitations")]
		[Code("MaximumNoOfSolicitations")]
        MaximumNoOfSolicitations = 1,
      
		[Description("Age")]
		[Code("Age")]
        Age = 2,
      
		[Description("At Max GSI")]
		[Code("AtMaxGSI")]
        AtMaxGSI = 3,
      
		[Description("Minimum Income")]
		[Code("MinimumIncome")]
        MinimumIncome = 4,
      
		[Description("Insufficient Income")]
		[Code("InsufficientIncome")]
        InsufficientIncome = 5,
      
		[Description("Ineligible for Increase -- AGE")]
		[Code("IneligibleforIncreaseAGE")]
        IneligibleforIncreaseAGE = 6,
      
		[Description("Job Duties")]
		[Code("JobDuties")]
        JobDuties = 7,
      
		[Description("Leave of Absence")]
		[Code("LeaveofAbsence")]
        LeaveofAbsence = 8,
      
		[Description("Medical Decline")]
		[Code("MedicalDecline")]
        MedicalDecline = 9,
      
		[Description("Fully Insured")]
		[Code("FullyInsured")]
        FullyInsured = 10,
      
		[Description("Part-time")]
		[Code("Parttime")]
        Parttime = 11,
      
		[Description("Policy Status")]
		[Code("PolicyStatus")]
        PolicyStatus = 12,
      
		[Description("Previous Solicitation")]
		[Code("PreviousSolicitation")]
        PreviousSolicitation = 13,
      
		[Description("Termination")]
		[Code("Termination")]
        Termination = 14,
      
		[Description("Below Minimum GSI")]
		[Code("BelowMinimumGSI")]
        BelowMinimumGSI = 15,
      
		[Description("No longer in group")]
		[Code("NoLongerInGroup")]
        NoLongerInGroup = 16,
      
		[Description("Active policy - no longer in group")]
		[Code("ActivePolicyNoLongerInGroup")]
        ActivePolicyNoLongerInGroup = 17,
      
		[Description("Not on New Census")]
		[Code("NotonNewCensus")]
        NotonNewCensus = 18,
      
		[Description("Do Not Solicit")]
		[Code("DoNotSolicit")]
        DoNotSolicit = 19,
      
		[Description("Missing or invalid SSN")]
		[Code("MissingorinvalidSSN")]
        MissingorinvalidSSN = 20,
      
		[Description("Not actively at work")]
		[Code("Notactivelyatwork")]
        Notactivelyatwork = 21,
      
		[Description("Not US citizen/green card holder")]
		[Code("NotUScitizenORgreencardholder")]
        NotUScitizenORgreencardholder = 22,
      
		[Description("Hours Worked")]
		[Code("HoursWorked")]
        HoursWorked = 23,
      
		[Description("Other")]
		[Code("Other")]
        Other = 99
  }
}
 