﻿using CMS.Model.Attributes;
using System.CodeDom.Compiler;
using System.ComponentModel;

namespace CMS.Model.Enums
{
    /// <summary>
    /// FullTimeDefinition auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum FullTimeDefinitionEnum
    {

        [Description("Full Time Definition-15")]
        [Code("15")]
        FTD15 = 1,

        [Description("Full Time Definition-20")]
        [Code("20")]
        FTD20 = 2,

        [Description("Full Time Definition-25")]
        [Code("25")]
        FTD25 = 3,

        // NOTE: FTD30 is the default value. It's equivalent to having a null value or no impact or not transmitted to CLOAS via MLAppEntry    
        [Description("Full Time Definition-30")]
        [Code("30")]
        FTD30 = 4
    }
}
