﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// EnrollmentKitType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum EnrollmentKitTypeEnum
    {
      
		[Description("Address Slip")]
		[Code("Address_Slip")]
        Address_Slip = 1,
      
		[Description("Cover Letter")]
		[Code("Cover_Letter")]
        Cover_Letter = 2,
      
		[Description("Enrollment Kit")]
		[Code("Enrollment_Kit")]
        Enrollment_Kit = 3,
      
		[Description("Sweep")]
		[Code("Sweep")]
        Sweep = 4,
      
		[Description("Applications")]
		[Code("Applications")]
        Applications = 5,
      
		[Description("Application Instructions")]
		[Code("Application_Instructions")]
        Application_Instructions = 6,
      
		[Description("Replacement Forms")]
		[Code("Replacement_Forms")]
        Replacement_Forms = 7,
      
		[Description("Outline of Coverage")]
		[Code("Outline_of_Coverage")]
        Outline_of_Coverage = 8,
      
		[Description("Guard-O-Matic Authorization")]
		[Code("Guard_O_Matic_Authorization")]
        Guard_O_Matic_Authorization = 9,
      
		[Description("RPP - Authorization and Irrevocable Assignment")]
		[Code("RPP_Authorization_and_Irrevocable_Assignment")]
        RPP_Authorization_and_Irrevocable_Assignment = 10,
      
		[Description("RPP - Disclosure Statement")]
		[Code("RPP_Disclosure_Statement")]
        RPP_Disclosure_Statement = 11,
      
		[Description("RPP Rider - Authorization and Irrevocable Assignment")]
		[Code("RPP_Rider_Authorization_and_Irrevocable_Assignment")]
        RPP_Rider_Authorization_and_Irrevocable_Assignment = 12,
      
		[Description("RPP Rider - Disclosure Statement")]
		[Code("RPP_Rider_Disclosure_Statement")]
        RPP_Rider_Disclosure_Statement = 13,
      
		[Description("Reg 194 Disclosure")]
		[Code("Reg_194_Disclosure")]
        Reg_194_Disclosure = 14,
      
		[Description("Civil Union Disclosure")]
		[Code("Civil_Union_Disclosure")]
        Civil_Union_Disclosure = 15,
      
		[Description("Declination of Coverage")]
		[Code("Declination_of_Coverage")]
        Declination_of_Coverage = 16
  }
}
 