﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// MldeStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum MldeStatusTypeEnum
    {
      
		[Description("No Response")]
		[Code("C")]
        NoResponse = 1,

        [Description("Registered")]
        [Code("H")]
        Registered = 2,

        [Description("Review Stage")]
		[Code("E")]
        Review = 3,
      
		[Description("Activities Begun")]
		[Code("F")]
        ActivitiesBegun = 4,
      
		[Description("Declined")]
		[Code("B")]
        Declined = 5,
      
		[Description("Enrollment Complete")]
		[Code("A")]
        Complete = 6,

        [Description("Accepted")]
        [Code("G")]
        Accepted = 7,

        [Description("User Verified")]
        [Code("D")]
        UserVerified = 8,


    }
}
 