﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// CensusClassType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum CensusClassTypeEnum
    {
      
		[Description("Ineligible")]
		[Code("Ineligible")]
        Ineligible = -3,
      
		[Description("Unassigned Class")]
		[Code("Unassigned")]
        Unassigned = -2,
      
		[Description("Error Class")]
		[Code("Error")]
        Error = -1,
      
		[Description("All Participants")]
		[Code("All")]
        All = 0
  }
}
 