﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;

namespace CMS.Model.Enums
{
    /// <summary>
    /// MldeUploadStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum MldeUploadStatusTypeEnum
    {
        [Description("Invalid")]
        [Code("Invalid")]
        Invalid = 0,

        [Description("Valid")]
        [Code("Valid")]
        Valid = 1,

        [Description("Reconciled")]
        [Code("Reconciled")]
        Reconciled = 2,
       



    }
}
