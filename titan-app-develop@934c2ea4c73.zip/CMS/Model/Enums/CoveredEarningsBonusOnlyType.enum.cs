﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// CoveredEarningsBonusOnlyType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum CoveredEarningsBonusOnlyTypeEnum
    {
      
		[Description("Bonus")]
		[Code("Bonus")]
        Bonus = 1,
      
		[Description("Commissions")]
		[Code("Commissions")]
        Commissions = 2,
      
		[Description("Bonus + Commission")]
		[Code("Bonus+Commission")]
        Bonus_Commission = 3,
      
		[Description("K-1 Earnings")]
		[Code("K-1Earnings")]
        K_1Earnings = 4,
      
		[Description("All Variable Compensation on Census")]
		[Code("AllVariableCompensationonCensus")]
        AllVariableCompensationonCensus = 5
  }
}
 