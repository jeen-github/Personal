﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// ExistingCoveragePremiumAndTaxpayerLiabilityType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum
    {
      
		[Description("Employer Paid")]
		[Code("EmployerPaid")]
        EmployerPaid = 1,
      
		[Description("Mandatory Partner Plan / Non-Taxable")]
		[Code("MandatoryPartnerPlan/Non-Taxable")]
        MandatoryPartnerPlan_Non_Taxable = 2,
      
		[Description("Voluntary Plan / Non-Taxable")]
		[Code("VoluntaryPlan/Non-Taxable")]
        VoluntaryPlan_Non_Taxable = 3,
      
		[Description("Cost Share")]
		[Code("CostShare")]
        CostShare = 4
  }
}
 