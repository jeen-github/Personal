﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// ColoradoReplacementType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum ColoradoReplacementTypeEnum
    {
      
		[Description("Additional benefits")]
		[Code("Additional_benefits")]
        Additional_benefits = 1,
      
		[Description("No change in benefits, but lower premiums")]
		[Code("No_change_in_benefits_but_lower_premiums")]
        No_change_in_benefits_but_lower_premiums = 2,
      
		[Description("Fewer benefits and lower premiums")]
		[Code("Fewer_benefits_and_lower_premiums")]
        Fewer_benefits_and_lower_premiums = 3,
      
		[Description("Other")]
		[Code("Other")]
        Other = 99
  }
}
 