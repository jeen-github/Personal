﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// ParticipantCategoryCodeType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum ParticipantCategoryCodeTypeEnum
    {
      
		[Description("AMB")]
		[Code("AMB")]
        AMB = 1,
      
		[Description("Newly Eligible")]
		[Code("NE")]
        NE = 2,
      
		[Description("Previously Solicited")]
		[Code("PS")]
        PS = 3,
      
		[Description("Final Offer")]
		[Code("FO")]
        FO = 4
  }
}
 