﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// EnrollmentParticipantStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum EnrollmentParticipantStatusTypeEnum
    {
      
		[Description("No Response")]
		[Code("NoResponse")]
        NoResponse = 1,
      
		[Description("Incomplete")]
		[Code("Incomplete")]
        Incomplete = 2,
      
		[Description("Declined")]
		[Code("Declined")]
        Declined = 3,
      
		[Description("Accepted")]
		[Code("Accepted")]
        Accepted = 4,
      
		[Description("Do Not Solicit")]
		[Code("DoNotSolicit")]
        DoNotSolicit = 5
  }
}
 