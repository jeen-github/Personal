﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// CaseStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum CaseStatusTypeEnum
    {
      
		[Description("Inquiry")]
		[Code("Inquiry")]
        Inquiry = 1,
      
		[Description("PDR Submitted")]
		[Code("PDRSubmitted")]
        PDRSubmitted = 2,
      
		[Description("Underwriting Review")]
		[Code("UnderwritingReview")]
        UnderwritingReview = 3,
      
		[Description("Initial Offer Approved")]
		[Code("InitialOfferApproved")]
        InitialOfferApproved = 4,
      
		[Description("Initial Offer Declined")]
		[Code("InitialOfferDeclined")]
        InitialOfferDeclined = 5,
      
		[Description("Initial Offer Withdrawn")]
		[Code("InitialOfferWithdrawn")]
        InitialOfferWithdrawn = 6,
      
		[Description("Offer Requested")]
		[Code("OfferRequested")]
        OfferRequested = 7,
      
		[Description("Formal Offer")]
		[Code("FormalOffer")]
        FormalOffer = 8,
      
		[Description("Offer Accepted")]
		[Code("OfferAccepted")]
        OfferAccepted = 9,
      
		[Description("Enrollment Review")]
		[Code("EnrollmentReview")]
        EnrollmentReview = 10,
      
		[Description("Implementation Pending")]
		[Code("ImplementationPending")]
        ImplementationPending = 11,
      
		[Description("Implementation In Progress")]
		[Code("ImplementationInProgress")]
        ImplementationInProgress = 12,
      
		[Description("Enrollment In Progress")]
		[Code("EnrollmentinProgress")]
        EnrollmentinProgress = 13,
      
		[Description("Post Enrollment")]
		[Code("PostEnrollment")]
        PostEnrollment = 14,
      
		[Description("Application Coding In Progress")]
		[Code("ApplicationCodinginProgress")]
        ApplicationCodinginProgress = 15,
      
		[Description("Billing In Progress")]
		[Code("BillinginProgress")]
        BillinginProgress = 16,
      
		[Description("Billing Past Due")]
		[Code("BillingPastDue")]
        BillingPastDue = 17,
      
		[Description("Active")]
		[Code("Active")]
        Active = 18,
      
		[Description("Annual Review Pending")]
		[Code("AnnualReviewPending")]
        AnnualReviewPending = 19,
      
		[Description("Re-Enrollment Review")]
		[Code("ReEnrollmentReview")]
        ReEnrollmentReview = 20,
      
		[Description("Withdrawn")]
		[Code("Withdrawn")]
        Withdrawn = 21
  }
}
 