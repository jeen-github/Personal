﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// CompanyGuardianProductType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum CompanyGuardianProductTypeEnum
    {
      
		[Description("Long Term Disability (LTD)")]
		[Code("LTD")]
        LongTermDisability = 1,
      
		[Description("Short Term Disability (STD)")]
		[Code("STD")]
        ShortTermDisability = 2,
      
		[Description("ASO STD")]
		[Code("ASO_STD")]
        ASOSTD = 3,
      
		[Description("Accidental Death & Dismemberment (AD&D)")]
		[Code("ADD")]
        AccidentalDeathAndDismemberment = 4,
      
		[Description("Basic Life")]
		[Code("Basic_Life")]
        BasicLife = 5,
      
		[Description("Voluntary Life")]
		[Code("Voluntary_Life")]
        VoluntaryLife = 6,
      
		[Description("Voluntary Permanent Life")]
		[Code("Voluntary_Permanent_Life")]
        VoluntaryPermanentLife = 7,
      
		[Description("Hospital Indemnity")]
		[Code("Hospital_Indemnity")]
        HospitalIndemnity = 8,
      
		[Description("Critical Illness")]
		[Code("Critical_Illness")]
        CriticalIllness = 9,
      
		[Description("Cancer")]
		[Code("Cancer")]
        Cancer = 10,
      
		[Description("Dental")]
		[Code("Dental")]
        Dental = 11,
      
		[Description("Vision")]
		[Code("Vision")]
        Vision = 12,
      
		[Description("401(k)")]
		[Code("401_K")]
        K401 = 13
  }
}
 