﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// EnrollmentOutputIncomeDefinitionType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum EnrollmentOutputIncomeDefinitionTypeEnum
    {
      
		[Description("Offer Letter Insurable Income Definition")]
		[Code("Offer_Letter_Insurable_Income_Definition")]
        OfferLetterInsurableIncomeDefinition = 1,
      
		[Description("Other")]
		[Code("Other")]
        Other = 2
  }
}
 