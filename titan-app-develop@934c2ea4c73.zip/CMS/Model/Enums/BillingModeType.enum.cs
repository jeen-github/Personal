﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// BillingModeType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum BillingModeTypeEnum
    {
      
		[Description("Monthly")]
		[Code("Monthly")]
        Monthly = 1,
      
		[Description("Monthly GOM")]
		[Code("MonthlyGOM")]
        MonthlyGOM = 2,
      
		[Description("Quarterly")]
		[Code("Quarterly")]
        Quarterly = 3,
      
		[Description("Semi Annual")]
		[Code("Semi Annual")]
        Semi_Annual = 4,
      
		[Description("Annual")]
		[Code("Annual")]
        Annual = 5,
      
		[Description("Direct Bill Monthly")]
		[Code("DirectBillMonthly")]
        DirectBillMonthly = 6
  }
}
 