﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// ContactAddressCategoryType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum ContactAddressCategoryTypeEnum
    {
      
		[Description("Accounts Payable")]
		[Code("Accounts_Payable")]
        AccountsPayable = 1,
      
		[Description("GA Admin")]
		[Code("GA_Admin")]
        GAAdmin = 2,
      
		[Description("Payroll Deduction Admin")]
		[Code("Payroll_Deduction_Admin")]
        PayrollDeductionAdmin = 3,
      
		[Description("Commissioned")]
		[Code("Commissioned")]
        Commissioned = 4,
      
		[Description("Follow Up - Delivery Requirements")]
		[Code("Follow_Up_Delivery_Requirements")]
        FollowUpDeliveryRequirements = 5,
      
		[Description("Enrollment Contact")]
		[Code("Enrollment_Contact")]
        EnrollmentContact = 6,
      
		[Description("Follow Up - NIGO ")]
		[Code("Follow_Up_NIGO ")]
        FollowUpNIGO  = 7,
      
		[Description("Agency")]
		[Code("Agency")]
        Agency = 8,
      
		[Description("Correspondence copies to")]
		[Code("Correspondence_copies_to")]
        Correspondencecopiesto = 9,
      
		[Description("Underwriting Output")]
		[Code("Underwriting_Output")]
        UnderwritingOutput = 10
  }
}
 