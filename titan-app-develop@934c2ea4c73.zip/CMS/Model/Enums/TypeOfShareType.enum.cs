﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// TypeOfShareType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum TypeOfShareTypeEnum
    {
      
		[Description("Percent of Premium")]
		[Code("PercentofPremium")]
        PercentofPremium = 1,
      
		[Description("Premium Amount")]
		[Code("PremiumAmount")]
        PremiumAmount = 2
  }
}
 