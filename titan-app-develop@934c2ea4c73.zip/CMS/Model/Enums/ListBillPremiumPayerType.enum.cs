﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// ListBillPremiumPayerType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum ListBillPremiumPayerTypeEnum
    {
      
		[Description("Employee")]
		[Code("Employee")]
        Employee = 1,
      
		[Description("Employer")]
		[Code("Employer")]
        Employer = 2,
      
		[Description("Cost Share")]
		[Code("CostShare")]
        CostShare = 3,
      
		[Description("Employer with VGSI")]
		[Code("EmployerwithVGSI")]
        EmployerwithVGSI = 4
  }
}
 