﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// EnrollmentMethodType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum EnrollmentMethodTypeEnum
    {
      
		[Description("Paper")]
		[Code("Paper")]
        Paper = 1,
      
		[Description("Online")]
		[Code("Online")]
        Online = 2,
      
		[Description("Paper/online")]
		[Code("Paper/online")]
        PaperOnline = 3,

        [Description("One-step")]
        [Code("One-step")]
        OneStep = 4,

        [Description("Direct Coverage")]
        [Code("Direct Coverage")]
        DirectCoverage = 5
    }
}
 