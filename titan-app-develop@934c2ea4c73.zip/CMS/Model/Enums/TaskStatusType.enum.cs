﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// TaskStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum TaskStatusTypeEnum
    {
      
		[Description("Unclaimed")]
		[Code("Unclaimed")]
        Unclaimed = 1,
      
		[Description("Claimed")]
		[Code("Claimed")]
        Claimed = 2,
      
		[Description("Suspended")]
		[Code("Suspended")]
        Suspended = 3,
      
		[Description("Completed")]
		[Code("Completed")]
        Completed = 4
  }
}
 