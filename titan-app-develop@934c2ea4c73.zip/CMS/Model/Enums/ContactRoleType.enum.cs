﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;

namespace CMS.Model.Enums
{
    /// <summary>
    /// ContactRoleType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum ContactRoleTypeEnum
    {

        [Description("Billing Contact")]
        [Code("Billing_Contact")]
        BillingContact = 1,

        [Description("HR Contact")]
        [Code("HR_Contact")]
        HRContact = 2,

        [Description("IT Contact")]
        [Code("IT_Contact")]
        ITContact = 3,

        [Description("Payroll Contact")]
        [Code("Payroll_Contact")]
        PayrollContact = 4,

        [Description("Producer")]
        [Code("Producer")]
        Producer = 5,

        [Description("Internal Wholesaler")]
        [Code("Internal_Wholesaler")]
        InternalWholesaler = 6,

        [Description("External Wholesaler")]
        [Code("External_Wholesaler")]
        ExternalWholesaler = 7,

        [Description("DIS")]
        [Code("DIS")]
        DIS = 8,

        [Description("Group Rep")]
        [Code("Group_Rep")]
        GroupRep = 9,

        [Description("Enrollment Manager")]
        [Code("Enrollment_Manager")]
        EnrollmentManager = 10,

        [Description("Implementation Analyst")]
        [Code("Implementation_Analyst")]
        ImplementationAnalyst = 11,

        [Description("Billing Specialist")]
        [Code("Billing_Specialist")]
        BillingSpecialist = 12,

        [Description("Underwriter")]
        [Code("Underwriter")]
        Underwriter = 13,

        [Description("Other")]
        [Code("Other")]
        Other = 14,

        [Description("Enrollment Contact")]
        [Code("Enrollment_Contact")]
        EnrollmentContact = 15
    }
}
