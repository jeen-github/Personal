﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// EnrollmentOutputShowType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum EnrollmentOutputShowTypeEnum
    {
      
		[Description("Gross Income")]
		[Code("Gross_Income")]
        GrossIncome = 1,
      
		[Description("Net Income")]
		[Code("Net_Income")]
        NetIncome = 2
  }
}
 