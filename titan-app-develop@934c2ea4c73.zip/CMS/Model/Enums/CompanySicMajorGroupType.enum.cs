﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// CompanySicMajorGroupType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum CompanySicMajorGroupTypeEnum
    {
      
		[Description("Agricultural Production Crops")]
		[Code("0001")]
        _0001 = 1,    
          
		[Description("Agriculture production livestock and animal specialties")]
		[Code("0002")]
        _0002 = 2,
      
		[Description("Agricultural Services")]
		[Code("0007")]
        _0007 = 3,
      
		[Description("Forestry")]
		[Code("0008")]
        _0008 = 4,
      
		[Description("Fishing, hunting, and trapping")]
		[Code("0009")]
        _0009 = 5,
      
		[Description("Metal Mining")]
		[Code("0010")]
        _0010 = 6,
      
		[Description("Coal Mining")]
		[Code("0012")]
        _0012 = 7,
      
		[Description("Oil And Gas Extraction")]
		[Code("0013")]
        _0013 = 8,
      
		[Description("Mining And Quarrying Of Nonmetallic Minerals, Except Fuels")]
		[Code("0014")]
        _0014 = 9,
      
		[Description("Building Construction General Contractors And Operative Builders")]
		[Code("0015")]
        _0015 = 10,
      
		[Description("Heavy Construction Other Than Building Construction Contractors")]
		[Code("0016")]
        _0016 = 11,
      
		[Description("Construction Special Trade Contractors")]
		[Code("0017")]
        _0017 = 12,
      
		[Description("Food And Kindred Products")]
		[Code("0020")]
        _0020 = 13,
      
		[Description("Tobacco Products")]
		[Code("0021")]
        _0021 = 14,
      
		[Description("Textile Mill Products")]
		[Code("0022")]
        _0022 = 15,
      
		[Description("Apparel And Other Finished Products Made From Fabrics And Similar Materials")]
		[Code("0023")]
        _0023 = 16,
      
		[Description("Lumber And Wood Products, Except Furniture")]
		[Code("0024")]
        _0024 = 17,
      
		[Description("Furniture And Fixtures")]
		[Code("0025")]
        _0025 = 18,
      
		[Description("Paper And Allied Products")]
		[Code("0026")]
        _0026 = 19,
      
		[Description("Printing, Publishing, And Allied Industries")]
		[Code("0027")]
        _0027 = 20,
      
		[Description("Chemicals And Allied Products")]
		[Code("0028")]
        _0028 = 21,
      
		[Description("Petroleum Refining And Related Industries")]
		[Code("0029")]
        _0029 = 22,
      
		[Description("Rubber And Miscellaneous Plastics Products")]
		[Code("0030")]
        _0030 = 23,
      
		[Description("Leather And Leather Products")]
		[Code("0031")]
        _0031 = 24,
      
		[Description("Stone, Clay, Glass, And Concrete Products")]
		[Code("0032")]
        _0032 = 25,
      
		[Description("Primary Metal Industries")]
		[Code("0033")]
        _0033 = 26,
      
		[Description("Fabricated Metal Products, Except Machinery And Transportation Equipment")]
		[Code("0034")]
        _0034 = 27,
      
		[Description("Industrial And Commercial Machinery And Computer Equipment")]
		[Code("0035")]
        _0035 = 28,
      
		[Description("Electronic And Other Electrical Equipment And Components, Except Computer Equipment")]
		[Code("0036")]
        _0036 = 29,
      
		[Description("Transportation Equipment")]
		[Code("0037")]
        _0037 = 30,
      
		[Description("Measuring, Analyzing, And Controlling Instruments; Photographic, Medical And Optical Goods; Watches And Clocks")]
		[Code("0038")]
        _0038 = 31,
      
		[Description("Miscellaneous Manufacturing Industries")]
		[Code("0039")]
        _0039 = 32,
      
		[Description("Railroad Transportation")]
		[Code("0040")]
        _0040 = 33,
      
		[Description("Local And Suburban Transit And Interurban Highway Passenger Transportation")]
		[Code("0041")]
        _0041 = 34,
      
		[Description("Motor Freight Transportation And Warehousing")]
		[Code("0042")]
        _0042 = 35,
      
		[Description("United States Postal Service")]
		[Code("0043")]
        _0043 = 36,
      
		[Description("Water Transportation")]
		[Code("0044")]
        _0044 = 37,
      
		[Description("Transportation By Air")]
		[Code("0045")]
        _0045 = 38,
      
		[Description("Pipelines, Except Natural Gas")]
		[Code("0046")]
        _0046 = 39,
      
		[Description("Transportation Services")]
		[Code("0047")]
        _0047 = 40,
      
		[Description("Communications")]
		[Code("0048")]
        _0048 = 41,
      
		[Description("Electric, Gas, And Sanitary Services")]
		[Code("0049")]
        _0049 = 42,
      
		[Description("Wholesale Trade-durable Goods")]
		[Code("0050")]
        _0050 = 43,
      
		[Description("Wholesale Trade-non-durable Goods")]
		[Code("0051")]
        _0051 = 44,
      
		[Description("Building Materials, Hardware, Garden Supply, And Mobile Home Dealers")]
		[Code("0052")]
        _0052 = 45,
      
		[Description("General Merchandise Stores")]
		[Code("0053")]
        _0053 = 46,
      
		[Description("Food Stores")]
		[Code("0054")]
        _0054 = 47,
      
		[Description("Automotive Dealers And Gasoline Service Stations")]
		[Code("0055")]
        _0055 = 48,
      
		[Description("Apparel And Accessory Stores")]
		[Code("0056")]
        _0056 = 49,
      
		[Description("Home Furniture, Furnishings, And Equipment Stores")]
		[Code("0057")]
        _0057 = 50,
      
		[Description("Eating And Drinking Places")]
		[Code("0058")]
        _0058 = 51,
      
		[Description("Miscellaneous Retail")]
		[Code("0059")]
        _0059 = 52,
      
		[Description("Depository Institutions")]
		[Code("0060")]
        _0060 = 53,
      
		[Description("Non-depository Credit Institutions")]
		[Code("0061")]
        _0061 = 54,
      
		[Description("Security And Commodity Brokers, Dealers, Exchanges, And Services")]
		[Code("0062")]
        _0062 = 55,
      
		[Description("Insurance Carriers")]
		[Code("0063")]
        _0063 = 56,
      
		[Description("Holding And Other Investment Offices")]
		[Code("0067")]
        _0067 = 57,
      
		[Description("Insurance Agents, Brokers, And Service")]
		[Code("0064")]
        _0064 = 58,
      
		[Description("Real Estate")]
		[Code("0065")]
        _0065 = 59,
      
		[Description("Hotels, Rooming Houses, Camps, And Other Lodging Places")]
		[Code("0070")]
        _0070 = 60,
      
		[Description("Personal Services")]
		[Code("0072")]
        _0072 = 61,
      
		[Description("Business Services")]
		[Code("0073")]
        _0073 = 62,
      
		[Description("Educational Services")]
		[Code("0082")]
        _0082 = 63,
      
		[Description("Museums, Art Galleries, And Botanical And Zoological Gardens")]
		[Code("0084")]
        _0084 = 64,
      
		[Description("Membership Organizations")]
		[Code("0086")]
        _0086 = 65,
      
		[Description("Engineering, Accounting, Research, Management, And Related Services")]
		[Code("0087")]
        _0087 = 66,
      
		[Description("Miscellaneous Services")]
		[Code("0089")]
        _0089 = 67,
      
		[Description("Automotive Repair, Services, And Parking")]
		[Code("0075")]
        _0075 = 68,
      
		[Description("Miscellaneous Repair Services")]
		[Code("0076")]
        _0076 = 69,
      
		[Description("Motion Pictures")]
		[Code("0078")]
        _0078 = 70,
      
		[Description("Amusement And Recreation Services")]
		[Code("0079")]
        _0079 = 71,
      
		[Description("Health Services")]
		[Code("0080")]
        _0080 = 72,
      
		[Description("Social Services")]
		[Code("0083")]
        _0083 = 73,
      
		[Description("Legal Services")]
		[Code("0081")]
        _0081 = 74,
      
		[Description("Executive, Legislative, And General Government, Except Finance")]
		[Code("0091")]
        _0091 = 76,
      
		[Description("Justice, Public Order, And Safety")]
		[Code("0092")]
        _0092 = 77,
      
		[Description("Public Finance, Taxation, And Monetary Policy")]
		[Code("0093")]
        _0093 = 78,
      
		[Description("Administration Of Human Resource Programs")]
		[Code("0094")]
        _0094 = 79,
      
		[Description("Administration Of Environmental Quality And Housing Programs")]
		[Code("0095")]
        _0095 = 80,
      
		[Description("Administration Of Economic Programs")]
		[Code("0096")]
        _0096 = 81,
      
		[Description("National Security And International Affairs")]
		[Code("0097")]
        _0097 = 82,
      
		[Description("Nonclassifiable Establishments")]
		[Code("0099")]
        _0099 = 83,
      
		[Description("Private Households")]
		[Code("0088")]
        _0088 = 84
  }
}
 