﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// AnnualReviewStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum AnnualReviewStatusTypeEnum
    {
      
		[Description("Annual Review Pending")]
		[Code("Annual_Review_Pending")]
        Annual_Review_Pending = 1,
      
		[Description("Annual Review Approved")]
		[Code("Annual_Review_Approved")]
        Annual_Review_Approved = 2,
      
		[Description("Withdraw Case")]
		[Code("Withdraw_Case")]
        Withdraw_Case = 3,
      
		[Description("Approved - Enhancement Offered")]
		[Code("Approved_Enhancement_Offered")]
        Approved_Enhancement_Offered = 4,
      
		[Description("Pending - Modification Required")]
		[Code("Pending_Modification_Required")]
        Pending_Modification_Required = 5
  }
}
 