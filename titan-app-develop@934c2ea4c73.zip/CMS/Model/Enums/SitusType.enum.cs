﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// SitusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum SitusTypeEnum
    {
      
		[Description("Corporate")]
		[Code("Corporate")]
        Corporate = 1,
      
		[Description("Residence")]
		[Code("Residence")]
        Residence = 2,
      
		[Description("Multi-State")]
		[Code("Multi_State")]
        Multi_State = 3
  }
}
 