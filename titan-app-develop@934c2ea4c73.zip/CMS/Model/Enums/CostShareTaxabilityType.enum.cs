﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// CostShareTaxabilityType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum CostShareTaxabilityTypeEnum
    {
      
		[Description("Employer Paid Portion - Taxable")]
		[Code("Employer_Paid_Portion_Taxable")]
        EmployerPaidPortionTaxable = 1,
      
		[Description("Employer Paid Portion - Non-Taxable")]
		[Code("Employer_Paid_Portion_Non_Taxable")]
        EmployerPaidPortionNonTaxable = 2
  }
}
 