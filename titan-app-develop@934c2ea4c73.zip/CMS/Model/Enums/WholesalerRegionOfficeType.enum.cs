﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// WholesalerRegionOfficeType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum WholesalerRegionOfficeTypeEnum
    {
      
		[Description("RGO")]
		[Code("RGO")]
        RGO = 1,
      
		[Description("Agency")]
		[Code("Agency")]
        Agency = 2
  }
}
 