﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// IllustrationGAStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum IllustrationGAStatusTypeEnum
    {
      
		[Description("Quote Requested")]
		[Code("Quote_Requested")]
        QuoteRequested = 1,
      
		[Description("Quote Available")]
		[Code("Quote_Available")]
        QuoteAvailable = 2,
      
		[Description("Offer Letter Requested")]
		[Code("Offer_Letter_Requested")]
        OfferLetterRequested = 3,
      
		[Description("Formal Offer")]
		[Code("Formal_Offer")]
        FormalOffer = 4
  }
}
 