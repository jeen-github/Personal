﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// OfferLetterStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum OfferLetterStatusTypeEnum
    {
      
		[Description("New")]
		[Code("New")]
        New = 1,
      
		[Description("Sold")]
		[Code("Sold")]
        Sold = 2,
      
		[Description("Released")]
		[Code("Released")]
        Released = 3,
      
		[Description("Withdrawn")]
		[Code("Withdrawn")]
        Withdrawn = 4
  }
}
 