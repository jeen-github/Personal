﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;

namespace CMS.Model.Enums
{
    /// <summary>
    /// PolicyStatusType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum PolicyStatusTypeEnum
    {

        [Description("Coded")]
        [Code("Coded")]
        Coded = 1,

        [Description("Issued")]
        [Code("Issued")]
        Issued = 2,

        [Description("Failed To Code")]
        [Code("FailedToCode")]
        FailedToCode = 3,

        [Description("Failed To Issue")]
        [Code("FailedToIssue")]
        FailedToIssue = 4
    }
}
