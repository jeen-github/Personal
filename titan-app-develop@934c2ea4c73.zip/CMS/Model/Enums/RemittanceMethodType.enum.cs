﻿using System;
using System.ComponentModel;
using System.CodeDom.Compiler;
using CMS.Model.Attributes;
   
namespace CMS.Model.Enums
{
    /// <summary>
    /// RemittanceMethodType auto generated enumeration
    /// </summary>
    [GeneratedCode("TextTemplatingFileGenerator", "10")]
    public enum RemittanceMethodTypeEnum
    {
      
		[Description("Wire Transfer")]
		[Code("WireTransfer")]
        WireTransfer = 1,
      
		[Description("ACH")]
		[Code("ACH")]
        ACH = 2,
      
		[Description("Paper Check")]
		[Code("PaperCheck")]
        PaperCheck = 3,
      
		[Description("List Bill GOM")]
		[Code("ListBillGOM")]
        ListBillGOM = 4,
      
		[Description("Direct Bill")]
		[Code("DirectBill")]
        DirectBill = 5
  }
}
 