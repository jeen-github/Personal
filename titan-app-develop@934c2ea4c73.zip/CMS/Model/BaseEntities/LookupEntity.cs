﻿namespace CMS.Model.BaseEntities
{
    public abstract class LookupEntity : Entity
    {
        public virtual string Name { get; set; }
        public virtual string Code { get; set; }
        public virtual string Description { get; set; }
        public virtual int? SortOrder { get; set; }

        public override string ToString()
        {
            return Description;
        }
    }
}