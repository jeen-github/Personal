﻿namespace CMS.Model.BaseEntities
{
    public abstract class Entity
    {
        public virtual int Id { get; set; }     
    }
}
