﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class ParticipantExistingPolicyRider : Entity
    {
        public virtual ParticipantExistingPolicyDetail ParticipantExistingPolicyDetail { get; set; }
        public virtual string RiderName { get; set; }
        public virtual string RiderValueDescription { get; set; }
        public virtual string RiderIndemnityAmountLabel { get; set; }
        public virtual decimal? Amount { get; set; }
    }
}
