﻿using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
    public class ConfidentialCaseUserGroupType : Entity
    {
        public virtual int UserGroup_Id { get; set; }
        public virtual DateTime UserAddedTime { get; set; }
        public virtual bool IsActiveIndicator { get; set; }
        
    }
}
