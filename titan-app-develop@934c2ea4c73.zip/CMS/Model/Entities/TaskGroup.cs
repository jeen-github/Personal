﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class TaskGroup : Entity
    {
        public virtual string Name { get; set; }
        public virtual string Code { get; set; }
        public virtual UserGroup UserGroup { get; set; }
    }
}
