﻿using System;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
namespace CMS.Model.Entities
{
    public class TaskActivityLog : Entity
    {
        public virtual CmsTask Task { get; set; }
        public virtual TaskGroup TaskGroup { get; set; }
        public virtual Case Case { get; set; }
        public virtual DateTime CreationDate { get; set; }
        public virtual DateTime DueDate { get; set; }
        public virtual UserGroup AssignedToUserGroup { get; set; }
        public virtual CmsUser AssignedToUser { get; set; }
        public virtual CmsUser ClaimedByUser { get; set; }
        public virtual CmsUser CompletedByUser { get; set; }
        public virtual DateTime? CompletedDate { get; set; }
        public virtual DateTime? UpdatedDueDate { get; set; }
        public virtual DateTime? FollowUpDate { get; set; }
        public virtual TaskStatusTypeEnum? TaskStatusType { get; set; }
        public virtual bool IsAdHocIndicator { get; set; }
        public virtual DateTime? ClaimedDate { get; set; }
        public virtual DateTime? SuspendedDate { get; set; }
        public virtual string Comments { get; set; }
        public virtual string CreatedBy { get; set; }
    }
}
