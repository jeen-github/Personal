﻿using System;
using System.Collections.Generic;
using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class CmsUser : Entity
    {
        public virtual string LdapUserName { get; set; }
        public virtual string FirstName { get; set; }
        public virtual string LastName { get; set; }
        public virtual string EmailAddress { get; set; }

        public virtual DateTime ModificationTime { get; set; }
        public virtual IList<UserGroup> UserGroups { get; set; }

        public CmsUser()
        {
            UserGroups = new List<UserGroup>();
        }
    }
}