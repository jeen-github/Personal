﻿using CMS.Model.BaseEntities;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    [Description("Package Status")]
    public class PackageStatusType : LookupEntity
    {
    }
}
