﻿using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
    public class EnrollmentMilestoneTaskConfiguration : Entity
    {
        public virtual EnrollmentMilestoneConfiguration EnrollmentMilestoneConfiguration { get; set; }
        public virtual string TaskName { get; set; }
        public virtual int SortOrder { get; set; }
        public virtual int TaskSLAInHours { get; set; }
        public virtual IList<EnrollmentMilestoneTaskUserGroupConfiguration> UserGroups { get; set; }

        public EnrollmentMilestoneTaskConfiguration()
        {
            UserGroups = new List<EnrollmentMilestoneTaskUserGroupConfiguration>();
        }
    }
}
