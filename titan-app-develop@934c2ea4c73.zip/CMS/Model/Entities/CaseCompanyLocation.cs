﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
    public class CaseCompanyLocation : Entity
    {
        public virtual Case Case { get; set; }
        [Audit(DisplayName = "Case Company Location Type")]
        public virtual CompanyLocationType CompanyLocationType { get; set; }
        [Audit(DisplayName ="Case Company Location Name")]
        public virtual string LocationName { get; set; }
        [Audit(DisplayName = "Case Company Address Line1")]
        public virtual string AddressLine1 { get; set; }
        [Audit(DisplayName = "Case Company Address Line2")]
        public virtual string AddressLine2 { get; set; }
        [Audit(DisplayName = "Case Company City")]
        public virtual string City { get; set; }
        [Audit(DisplayName = "Case Company Location State Type")]
        public virtual StateTypeEnum? StateType { get; set; }
        [Audit(DisplayName = "Case Company ZipCode")]
        public virtual string ZipCode { get; set; }
        [Audit(DisplayName = "Case Company Attention")]
        public virtual string Attention { get; set; }
    }
}
