﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class CompanySicSubGroupType : LookupEntity
    {
        public virtual CompanySicMajorGroupType CompanySicMajorGroupType { get; set; }

    }
}
