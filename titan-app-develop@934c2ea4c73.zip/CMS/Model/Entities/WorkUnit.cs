﻿using System;
using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class WorkUnit : Entity
    {
        public virtual string HandlerName { get; set; }
        public virtual bool IsLongRunning { get; set; }
        public virtual DateTime CreationDate { get; set; }
        public virtual bool IsProcessing { get; set; }
        public virtual DateTime? StartDate { get; set; }
        public virtual DateTime? CheckpointDate { get; set; }
        public virtual DateTime? CompleteDate { get; set; }
        public virtual string Owner { get; set; }
        public virtual int Retries { get; set; }
        public virtual string InputData { get; set; }
        public virtual string ErrorMessage { get; set; }
    }
}
