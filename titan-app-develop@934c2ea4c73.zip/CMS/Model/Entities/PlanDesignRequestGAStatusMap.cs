﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
namespace CMS.Model.Entities
{
    public class PlanDesignRequestGAStatusMap : Entity
    {
        public virtual PlanDesignRequestStatusTypeEnum? PlanDesignRequestStatusType { get; set; }
        public virtual string GAStatusName { get; set; }
    }
}
