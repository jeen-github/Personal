﻿using System;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class EnrollmentEmail : Entity
    {
        public virtual Enrollment Enrollment{ get; set; }
        public virtual EnrollmentEmailTypeEnum EnrollmentEmailType { get; set; }
        public virtual DateTime? SendDate { get; set; }
        public virtual ContactAddress Contact { get; set; }
        public virtual string Cc { get; set; }
        public virtual DateTime? ProcessedDatetime { get; set; }
        public virtual bool? IsProcessed { get; set; }
    }
}