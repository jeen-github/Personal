﻿using CMS.Model.BaseEntities;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    [Description("Mlde Status Type")]
    public class MldeStatusType : LookupEntity
    {
        public virtual string DisplayText { get; set; }
    }
}
