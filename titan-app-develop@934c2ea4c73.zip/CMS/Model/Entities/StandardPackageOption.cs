﻿using CMS.Model.BaseEntities;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class StandardPackageOption : Entity
    {
        public virtual StandardPackageType StandardPackageType { get; set; }
        public virtual int OptionNumber { get; set; }
        public virtual decimal? GSIPercentage { get; set; }
        public virtual IList<StandardPackageOptionRider> StandardPackageOptionRiders { get; set; }

        public StandardPackageOption()
        {
            StandardPackageOptionRiders = new List<StandardPackageOptionRider>();
        }

    }
}
