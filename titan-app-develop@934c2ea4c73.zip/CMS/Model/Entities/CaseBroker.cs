﻿using System;
using System.Collections.Generic;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using CMS.DataAccess.Auditing;

namespace CMS.Model.Entities
{
    public class CaseBroker : Entity
    {
        public virtual Case Case { get; set; }
        public virtual string BrokerWritingCode { get; set; }
        public virtual string BrokerParentWritingCode { get; set; }
        public virtual string BrokerName { get; set; }
        public virtual string AgencyCode { get; set; }
        public virtual BrokerAffiliationType BrokerAffiliationType { get; set; }
        public virtual IList<CaseBrokerState> CaseBrokerStates { get; set; }       
        public virtual string BrokerType {get;set;}
        public virtual int? WholesalerRegionOfficeId { get; set; }
        public virtual string CompanyName { get; set; }
        public CaseBroker()
        {
            CaseBrokerStates = new List<CaseBrokerState>();
        }
    }
}
