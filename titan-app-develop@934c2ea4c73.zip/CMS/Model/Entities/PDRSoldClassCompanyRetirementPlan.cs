﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
    public class PDRSoldClassCompanyRetirementPlan : Entity
    {
        public virtual PDRSoldClass PDRSoldClass { get; set; }
        [Audit(DisplayName = "Company Retirement Plan")]
        public virtual CompanyRetirementPlanType CompanyRetirementPlanType { get; set; }
        public virtual bool IsChecked { get; set; }
        public virtual string CompanyRetirementPlanType_Other { get; set; }
    }
}
