﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Model.BaseEntities;
using System.ComponentModel;
using CMS.Model.Entities;


namespace CMS.Model.Entities
{
    public class CompanySicDivisionType : LookupEntity
    {
        public virtual IList<CompanySicMajorGroupType> CompanySicMajorGroupTypes { get; set; }
        public CompanySicDivisionType()
        {
            CompanySicMajorGroupTypes = new List<CompanySicMajorGroupType>();
        }
    }
}
