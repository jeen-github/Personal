﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;

namespace CMS.Model.Entities
{
    public class EnrollmentParticipantPolicy : Entity
    {
        public virtual EnrollmentParticipant EnrollmentParticipant { get; set; }
        public virtual string PolicyNumber { get; set; }
        public virtual EnrollmentPDRClassOptionPlan EnrollmentPDRClassOptionPlan { get; set; }
        public virtual EnrollmentParticipantOptionPlan EnrollmentParticipantOptionPlan { get; set; }
        //public virtual string PolicyStatus { get; set; }
        public virtual PolicyStatusTypeEnum? PolicyStatusType { get; set; }
        public virtual string ReviewReason { get; set; }
        public virtual DateTime? ReleaseDate { get; set; }
    }
}
