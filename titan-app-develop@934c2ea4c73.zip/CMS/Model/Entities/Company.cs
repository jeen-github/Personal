﻿using System.Collections.Generic;
using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class Company : Entity
    {
        public virtual string EmployerClientId { get; set; }
    }
}
