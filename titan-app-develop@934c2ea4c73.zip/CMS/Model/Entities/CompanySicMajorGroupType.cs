﻿using CMS.Model.BaseEntities;
using System.Collections.Generic;


namespace CMS.Model.Entities
{
    public class CompanySicMajorGroupType : LookupEntity
    {
        public virtual IList<CompanySicSubGroupType> CompanySicSubGroupTypes { get; set; }
        public CompanySicMajorGroupType()
        {
            CompanySicSubGroupTypes = new List<CompanySicSubGroupType>();
        }
        public virtual CompanySicDivisionType CompanySicDivisionType { get; set; }

    }
}
