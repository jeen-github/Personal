﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class EnrollmentOutputIncomeDefinitionType : LookupEntity
    {
    }
}
