﻿using CMS.Model.BaseEntities;
using System;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class EnrollmentOutput : Entity
    {
        public virtual Enrollment Enrollment { get; set; }
        public virtual string CompanyFriendlyName { get; set; }
        public virtual bool IsOmitPageNumbers { get; set; }
        public virtual bool IsIncludeGLTDDefinition { get; set; }
        public virtual bool IsIncludeGLTDTaxabilityLanguage { get; set; }
        public virtual ContactAddress ReturnAddress { get; set; }
        public virtual bool IsCoverLetterIncluded { get; set; }
        public virtual EnrollmentOutputSalutationType EnrollmentOutputSalutationType { get; set; }
        public virtual string SalutationText { get; set; }
        public virtual bool IsShowReplacementPercentage { get; set; }
        public virtual string AlternateReplacementPercentText { get; set; }
        public virtual EnrollmentOutputEmployeeType EnrollmentOutputEmployeeType { get; set; }
        public virtual string CustomEmployeeTypeText { get; set; }
        public virtual bool IsCompanyLetterhead { get; set; }
        public virtual bool IsCompanyLogo { get; set; }
        public virtual bool IsSignature { get; set; }
        public virtual string ApplicationReturnInstructions { get; set; }
        public virtual ContactAddress ContactOne { get; set; }
        public virtual ContactAddress ContactTwo { get; set; }
        public virtual EnrollmentOutputIncomeDefinitionTypeEnum? EnrollmentOutputIncomeDefinitionType { get; set; }
        public virtual string OtherIncomeDefinitionText { get; set; }
        public virtual EnrollmentOutputShowTypeEnum? EnrollmentOutputShowType { get; set; }
        public virtual decimal? TaxRatePercentage { get; set; }
        public virtual EnrollmentOutputIncomeDisplayType EnrollmentOutputIncomeDisplayType { get; set; }
        public virtual EnrollmentOutputPremiumDisplayType EnrollmentOutputPremiumDisplayType { get; set; }
        public virtual bool IsDOB { get; set; }
        public virtual bool IsSSN { get; set; }
        public virtual bool IsCompensation { get; set; }
        public virtual string ResponseRequiredText { get; set; }
        public virtual bool IsPrepaidEnvelope { get; set; }
        public virtual ContactAddress HRContact { get; set; }

        public EnrollmentOutput() { }
    }
}
