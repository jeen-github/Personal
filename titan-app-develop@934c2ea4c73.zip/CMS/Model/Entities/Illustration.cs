﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;

namespace CMS.Model.Entities
{
    public class Illustration : Entity
    {
        public virtual PlanDesignRequest PlanDesignRequest { get; set; }
        public virtual string QuoteName { get; set; }
        public virtual bool IsExternalRequestIndicator { get; set; }
        public virtual bool IsProcessingIndicator { get; set; }
        public virtual string ErrorMessage { get; set; }
        public virtual string RequestedBy { get; set; }
        public virtual DateTime RequestedDateTime { get; set; }
        public virtual string ReleasedBy { get; set; }
        public virtual DateTime? ReleasedDateTime { get; set; }
        public virtual DateTime? CompletedDateTime { get; set; }
        public virtual bool IsActiveIndicator { get; set; }
        public virtual string RequestJsonText { get; set; }
        public virtual bool LikelyToSellIndicator { get; set; }
        public virtual CaseDocument RateSheetPdfDocument { get; set; }
        public virtual CaseDocument RateSheetExcelDocument { get; set; }
        public virtual CaseDocument ProductSummaryDocument { get; set; }
        public virtual CaseDocument ProgramSummaryDocument { get; set; }
        public virtual bool IsWithdrawnIndicator { get; set; }
        public virtual int? WithdrawnBy { get; set; }
        public virtual DateTime? WithdrawnDateTime { get; set; }
        public virtual bool IsReleased { get; set; }
        public virtual bool IncludeIneligibleParticipants { get; set; }
        public virtual IllustrationGAStatusTypeEnum? IllustrationGAStatusType { get; set; }
        public virtual string IllustrationDocumentStatus { get; set; }
        public virtual decimal? TotalAnnualPDRPremium { get; set; }
    }
}
