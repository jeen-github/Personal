﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class StandardPackageOptionRider : Entity
    {
        public virtual int StandardPackageOptionRider_Id { get; set; }
        public virtual StandardPackageOption standardPackageOption { get; set; }
        public virtual int BenefitGroup_Id { get; set; }
        public virtual int IsRequired { get; set; }
    }
}
