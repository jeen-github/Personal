﻿using System;
using System.Collections.Generic;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Newtonsoft.Json;

namespace CMS.Model.Entities
{
    public class CaseDocumentRequest : Entity
    {
        public virtual int Case_Id { get; set; }
        public virtual DateTime RequestDateTime { get; set; }
        public virtual string RequestFileName { get; set; }
        public virtual CaseDocumentTypeEnum CaseDocumentType { get; set; }
        public virtual string ExtreamRequest { get; set; }
        public virtual bool IsSentToExtream { get; set; }
        public virtual bool IsReceivedFromExtream { get; set; }
        public virtual DateTime? ReceivedFromExtreamDateTime { get; set; }
        public virtual string ErrorMessage { get; set; }

        [JsonIgnore]
        public virtual IList<CaseDocument> Documents { get; set; }

        public CaseDocumentRequest()
        {
            Documents = new List<CaseDocument>();
        }
    }
}