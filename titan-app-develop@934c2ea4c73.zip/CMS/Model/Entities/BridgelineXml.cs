﻿using CMS.Model.BaseEntities;
using System;

namespace CMS.Model.Entities
{
    public class BridgelineXml : Entity
    {
        public virtual Enrollment Enrollment { get; set; }
        public virtual string Name { get; set; }
        public virtual DateTime? GeneratedDateTime { get; set; }
        public virtual string GeneratedBy { get; set; }
        public virtual string Status{ get; set; }
        public virtual string FileContent { get; set; }
    }
}
