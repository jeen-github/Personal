﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;

namespace CMS.Model.Entities
{
	public class IndividualDisabilityCoverage : Entity
	{
		public virtual Participant Participant { get; set; }

		public virtual string Status { get; set; }

		public virtual int? CarrierId { get; set; }

		public virtual decimal? BenefitAmount { get; set; }

		public virtual bool? IsReplaceable { get; set; }

		public virtual decimal? ReplacementAmount { get; set; }

		public virtual int? PremiumPayer { get; set; }

		public virtual string PolicyNumber { get; set; }

		public virtual string CreatedBy { get; set; }

		public virtual DateTime CreatedAt { get; set; }

		public virtual string UpdatedBy { get; set; }

		public virtual DateTime UpdatedAt { get; set; }
	}
}