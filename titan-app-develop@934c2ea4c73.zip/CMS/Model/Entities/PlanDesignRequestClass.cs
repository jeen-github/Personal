﻿using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;
using CMS.Model.Enums;
using System.Collections.Generic;
using CMS.DataAccess.Auditing;

namespace CMS.Model.Entities
{
    public class PlanDesignRequestClass : Entity
    {
        public virtual PlanDesignRequest PlanDesignRequest { get; set; }
        [Audit(DisplayName = "Plan Design Request Class Name")]
        public virtual string PlanDesignRequestClassName { get; set; }
        [Audit(DisplayName = "Requested Eligible Population Text")]
        public virtual string RequestedEligiblePopulationText { get; set; }
        [Audit(DisplayName = "Approved Eligible Population Text")]
        public virtual string ApprovedEligiblePopulationText { get; set; }
        [Audit(DisplayName = "Eligible Population Text Notes")]
        public virtual string EligiblePopulationTextNotes { get; set; }
        [Audit(DisplayName = "Approved Elimination Period")]
        public virtual EliminationPeriodTypeEnum? ApprovedEliminationPeriod { get; set; }
        [Audit(DisplayName = "Approved Benefit Period")]
        public virtual BenefitPeriodTypeEnum? ApprovedBenefitPeriod { get; set; }
        [Audit(DisplayName = "Requested Plan Design")]
        public virtual PlanDesignTypeEnum? RequestedPlanDesignType { get; set; }
        [Audit(DisplayName = "Approved Plan Design")]
        public virtual PlanDesignTypeEnum? ApprovedPlanDesignType { get; set; }
        [Audit(DisplayName = "Plan Design Notes")]
        public virtual string PlanDesignNotes { get; set; }
        [Audit(DisplayName = "Requested Benefit Period Id")]
        public virtual int? RequestedBenefitPeriod_Id { get; set; }
        [Audit(DisplayName = "Benefit Period Notes")]
        public virtual string BenefitPeriodNotes { get; set; }
        [Audit(DisplayName = "Requested Elimination Period Id")]
        public virtual int? RequestedEliminationPeriod_Id { get; set; }
        [Audit(DisplayName = "Elimination Period Notes")]
        public virtual string EliminationPeriodNotes { get; set; }
        [Audit(DisplayName = "Requested LTD Percentage", Format = "{0:N2}")]
        public virtual decimal? RequestedLTDPercentage { get; set; }
        [Audit(DisplayName = "Approved LTD Percentage", Format = "{0:N2}")]
        public virtual decimal? ApprovedLTDPercentage { get; set; }
        [Audit(DisplayName = "LTD Percentage Notes")]
        public virtual string LTDPercentageNotes { get; set; }
        [Audit(DisplayName = "Requested IDI Percentage", Format = "{0:N2}")]
        public virtual decimal? RequestedIDIPercentage { get; set; }
        [Audit(DisplayName = "Approved IDI Percentage", Format = "{0:N2}")]
        public virtual decimal? ApprovedIDIPercentage { get; set; }
        [Audit(DisplayName = "IDI Percentage Notes")]
        public virtual string IDIPercentageNotes { get; set; }
        [Audit(DisplayName = "Requested Premium Payer And Taxability")]
        public virtual ExistingCoveragePremiumAndTaxpayerLiabilityType RequestedPremiumPayerAndTaxabilityType { get; set; }
        [Audit(DisplayName = "Approved Premium Payer And Taxability")]
        public virtual ExistingCoveragePremiumAndTaxpayerLiabilityType ApprovedPremiumPayerAndTaxabilityType { get; set; }
        [Audit(DisplayName = "Premium Payer And Taxability Notes")]
        public virtual string PremiumPayerAndTaxabilityNotes { get; set; }
        [Audit(DisplayName = "Requested Maximum Replacement Ratio", Format = "{0:N2}")]
        public virtual decimal? RequestedMaximumReplacementRatio { get; set; }
        [Audit(DisplayName = "Approved Maximum Replacement Ratio", Format = "{0:N2}")]
        public virtual decimal? ApprovedMaximumReplacementRatio { get; set; }
        [Audit(DisplayName = "Maximum Replacement Ratio Notes")]
        public virtual string MaximumReplacementRatioNotes { get; set; }
        [Audit(DisplayName = "Requested Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? RequestedCoveredEarningsType { get; set; }
        [Audit(DisplayName = "Approved Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? ApprovedCoveredEarningsType { get; set; }
        [Audit(DisplayName = "Requested Covered Earnings Type Other")]
        public virtual string RequestedCoveredEarningsTypeOther { get; set; }
        [Audit(DisplayName = "Requested Covered Earnings Bonus Only")]
        public virtual CoveredEarningsBonusOnlyTypeEnum? RequestedCoveredEarningsBonusOnlyType { get; set; }
        [Audit(DisplayName = "Approved Covered Earnings Bonus Only")]
        public virtual CoveredEarningsBonusOnlyTypeEnum? ApprovedCoveredEarningsBonusOnlyType { get; set; }
        [Audit(DisplayName = "Covered Earnings Notes")]
        public virtual string CoveredEarningsTypeNotes { get; set; }
        [Audit(DisplayName = "Requested LTD Covers Next", Format = "{0:N2}")]
        public virtual decimal? RequestedLTDCoversNext { get; set; }
        [Audit(DisplayName = "Approved LTD Covers Next", Format = "{0:N2}")]
        public virtual decimal? ApprovedLTDCoversNext { get; set; }
        [Audit(DisplayName = "LTD Covers Next Notes")]
        public virtual string LTDCoversNextNotes { get; set; }
        [Audit(DisplayName = "Requested IDI Covers 1st", Format = "{0:N2}")]
        public virtual decimal? RequestedIDICovers1st { get; set; }
        [Audit(DisplayName = "Approved IDI Covers 1st", Format = "{0:N2}")]
        public virtual decimal? ApprovedIDICovers1st { get; set; }
        [Audit(DisplayName = "IDI Covers 1st Notes")]
        public virtual string IDICovers1stNotes { get; set; }
        [Audit(DisplayName = "Requested Flat Rate")]
        public virtual FlatRateType RequestedFlatRateType { get; set; }
        [Audit(DisplayName = "Approved Flat Rate")]
        public virtual FlatRateType ApprovedFlatRateType { get; set; }
        [Audit(DisplayName = "Requested Flat Rate Other")]
        public virtual int? RequestedFlatRate_Other { get; set; }
        [Audit(DisplayName = "Approved Flat Rate Other")]
        public virtual int? ApprovedFlatRate_Other { get; set; }
        [Audit(DisplayName = "Is PDR Class Active")]
        public virtual bool IsActive { get; set; }
        [Audit(DisplayName = "Requested Annual Contributions", Format = "{0:N2}")]
        public virtual decimal? RequestedAnnualContributions { get; set; }
        [Audit(DisplayName = "Approved Annual Contributions", Format = "{0:N2}")]
        public virtual decimal? ApprovedAnnualContributions { get; set; }
        [Audit(DisplayName = "Annual Contributions Notes")]
        public virtual string AnnualContributionsNotes { get; set; }
        [Audit(DisplayName = "Requested Covered Earnings Percentage", Format = "{0:N2}")]
        public virtual decimal? RequestedCoveredEarningsPercentage { get; set; }
        [Audit(DisplayName = "Approved Covered Earnings Percentage", Format = "{0:N2}")]
        public virtual decimal? ApprovedCoveredEarningsPercentage { get; set; }
        [Audit(DisplayName = "Covered Earnings Percentage Notes")]
        public virtual string CoveredEarningsPercentageNotes { get; set; }
        [Audit(DisplayName = "Requested RPP Rider Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? RequestedRppRiderCoveredEarningsType { get; set; }
        [Audit(DisplayName = "Approved RPP Rider Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? ApprovedRppRiderCoveredEarningsType { get; set; }
        [Audit(DisplayName = "Requested RPP Rider Covered Earnings Type Other")]
        public virtual string RequestedRppRiderCoveredEarningsTypeOther { get; set; }
        [Audit(DisplayName = "RPP Rider Covered Earnings Notes")]
        public virtual string RppRiderCoveredEarningsTypeNotes { get; set; }
        public virtual IList<CaseCompanyRetirementPlan> CaseCompanyRetirementPlan { get; set; }
        [Audit(DisplayName = "Requested Retirement Contributions")]
        public virtual RetirementContributionsTypeEnum? RequestedRetirementContributionsType { get; set; }
        [Audit(DisplayName = "Approved Retirement Contributions")]
        public virtual RetirementContributionsTypeEnum? ApprovedRetirementContributionsType { get; set; }
        [Audit(DisplayName = "Retirement Contribution Notes")]
        public virtual string RetirementContributionNotes { get; set; }
        [Audit(DisplayName = "Requested Taxability")]
        public virtual TaxabilityTypeEnum? RequestedTaxabilityType { get; set; }
        [Audit(DisplayName = "Approved Taxability")]
        public virtual TaxabilityTypeEnum? ApprovedTaxabilityType { get; set; }
        [Audit(DisplayName = "Taxability Notes")]
        public virtual string TaxabilityTypeNotes { get; set; }
        [Audit(DisplayName = "Is Requested Voluntary GSI Buy Up Plan")]
        public virtual bool? IsRequestedVoluntaryGSIBuyUpPlan { get; set; }
        [Audit(DisplayName = "Is Approved Voluntary GSI Buy Up Plan")]
        public virtual bool? IsApprovedVoluntaryGSIBuyUpPlan { get; set; }
        [Audit(DisplayName = "Voluntary GSI Buy Up Plan Notes")]
        public virtual string VoluntaryGSIBuyUpPlanNotes { get; set; }
        [Audit(DisplayName = "Requested Voluntary GSI Buy Up Plan Design")]
        public virtual PlanDesignGSITypeEnum? RequestedVoluntaryGSIBuyUpPlanDesignType { get; set; }
        [Audit(DisplayName = "Approved Voluntary GSI Buy Up Plan Design")]
        public virtual PlanDesignGSITypeEnum? ApprovedVoluntaryGSIBuyUpPlanDesignType { get; set; }
        [Audit(DisplayName = "Voluntary GSI Buy Up Plan Design Notes")]
        public virtual string VoluntaryGSIBuyUpPlanDesignNotes { get; set; }
        [Audit(DisplayName = "Requested GSI Buy Up Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? RequestedGSIBuyUpCoveredEarningsType { get; set; }
        [Audit(DisplayName = "Approved GSI Buy Up Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? ApprovedGSIBuyUpCoveredEarningsType { get; set; }
        [Audit(DisplayName = "Requested GSI Buy Up Covered Earnings BonusOnly")]
        public virtual CoveredEarningsBonusOnlyTypeEnum? RequestedGSIBuyUpCoveredEarningsBonusOnlyType { get; set; }
        [Audit(DisplayName = "Approved GSI Buy Up Covered Earnings BonusOnly")]
        public virtual CoveredEarningsBonusOnlyTypeEnum? ApprovedGSIBuyUpCoveredEarningsBonusOnlyType { get; set; }
        [Audit(DisplayName = "Requested GSI Buy Up Covered Earnings Type Other")]
        public virtual string RequestedGSIBuyUpCoveredEarningsType_Other { get; set; }
        [Audit(DisplayName = "GSI Buy Up Covered Earnings Notes")]
        public virtual string GSIBuyUpCoveredEarningsTypeNotes { get; set; }
        [Audit(DisplayName = "Requested GSI Buy Up Replacement Percentage", Format = "{0:N2}")]
        public virtual decimal? RequestedGSIBuyUpReplacementPercentage { get; set; }
        [Audit(DisplayName = "Approved GSI Buy Up Replacement Percentage", Format = "{0:N2}")]
        public virtual decimal? ApprovedGSIBuyUpReplacementPercentage { get; set; }
        [Audit(DisplayName = "GSI Buy Up Replacement Percentage Notes")]
        public virtual string GSIBuyUpReplacementPercentageNotes { get; set; }
        [Audit(DisplayName = "Requested Type Of Share")]
        public virtual TypeOfShareTypeEnum? RequestedTypeOfShareType { get; set; }
        [Audit(DisplayName = "Approved Type Of Share")]
        public virtual TypeOfShareTypeEnum? ApprovedTypeOfShareType { get; set; }
        [Audit(DisplayName = "Requested Employer Paid Premium")]
        public virtual decimal? RequestedEmployerPaidPremium { get; set; }
        [Audit(DisplayName = "Approved Employer Paid Premium")]
        public virtual decimal? ApprovedEmployerPaidPremium { get; set; }
        [Audit(DisplayName = "Employer Paid Premium Notes")]
        public virtual string EmployerPaidPremiumNotes { get; set; }
        [Audit(DisplayName = "Requested Employee Paid Premium")]
        public virtual decimal? RequestedEmployeePaidPremium { get; set; }
        [Audit(DisplayName = "Approved Employee Paid Premium")]
        public virtual decimal? ApprovedEmployeePaidPremium { get; set; }
        [Audit(DisplayName = "Requested Employer Pays up to")]
        public virtual decimal? RequestedEmployerPaysupto { get; set; }
        [Audit(DisplayName = "Approved Employer Pays up to")]
        public virtual decimal? ApprovedEmployerPaysupto { get; set; }
        [Audit(DisplayName = "Employer Pays up to Notes")]
        public virtual string EmployerPaysuptoNotes { get; set; }
        [Audit(DisplayName = "Requested CostShare Taxability Type")]
        public virtual CostShareTaxabilityType RequestedCostShareTaxabilityType { get; set; }
        [Audit(DisplayName = "Approved CostShare Taxability Type")]
        public virtual CostShareTaxabilityType ApprovedCostShareTaxabilityType { get; set; }
        public virtual IList<PlanDesignRequestClassProduct> PlanDesignRequestClassProducts { get; set; }        
        public virtual IList<PlanDesignRequestClassRider> PlanDesignRequestClassRiders { get; set; }
        public virtual IList<PlanDesignRequestClassLTDCoverage> PlanDesignRequestClassLTDCoverage { get; set; }
        public virtual string GAPlanDesignRequestClassId { get; set; }
        public virtual IList<Participant> CensusParticipants { get; set; }
        public virtual IList<PDRClassCustomizedIDIInsurableIncome> PDRClassCustomizedIDIInsurableIncomes { get; set; }
        public virtual string InsurableIncomeDefinition { get; set; }
        public virtual string BuyUpInsurableIncomeDefinition { get; set; }
        public PlanDesignRequestClass()
        {
            PlanDesignRequest = new PlanDesignRequest();
            RequestedPremiumPayerAndTaxabilityType = new ExistingCoveragePremiumAndTaxpayerLiabilityType();
            ApprovedPremiumPayerAndTaxabilityType = new ExistingCoveragePremiumAndTaxpayerLiabilityType();
            CaseCompanyRetirementPlan = new List<CaseCompanyRetirementPlan>();
            RequestedFlatRateType = new FlatRateType();
            ApprovedFlatRateType = new FlatRateType();
            PlanDesignRequestClassProducts = new List<PlanDesignRequestClassProduct>();
            PlanDesignRequestClassRiders = new List<PlanDesignRequestClassRider>();
            PlanDesignRequestClassLTDCoverage = new List<PlanDesignRequestClassLTDCoverage>();
            CensusParticipants = new List<Participant>();
            RequestedCostShareTaxabilityType = new CostShareTaxabilityType();
            ApprovedCostShareTaxabilityType = new CostShareTaxabilityType();
            PDRClassCustomizedIDIInsurableIncomes = new List<PDRClassCustomizedIDIInsurableIncome>();
        }
        public override string ToString()
        {
            return PlanDesignRequestClassName;
        }
    }
}



