﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System.Collections.Generic;
using System;


namespace CMS.Model.Entities
{
    public class ListBillGroup : Entity
    {
        public virtual ListBillNumber ListBillNumber { get; set; }
        [Audit(DisplayName = "Billing Group Name")]
        public virtual string BillingGroupName { get; set; }
        [Audit(DisplayName = "List Bill Premium Payer Type")]
        public virtual ListBillPremiumPayerTypeEnum? ListBillPremiumPayerType { get; set; }
        [Audit(DisplayName = "Type Of Share Type")]
        public virtual TypeOfShareTypeEnum? TypeOfShareType { get; set; }
        [Audit(DisplayName = "Employer Paid Premium Percentage")]
        public virtual decimal? EmployerPaidPremiumPercentage { get; set; }
        [Audit(DisplayName = "Employee Paid Premium Percentage")]
        public virtual decimal? EmployeePaidPremiumPercentage { get; set; }
        [Audit(DisplayName = "Employer Pays Up To Amount")]
        public virtual decimal? EmployerPaysUpToAmount { get; set; }
        [Audit(DisplayName = "Employee Payment Method Type")]
        public virtual EmployeePaymentMethodTypeEnum? EmployeePaymentMethodType { get; set; }
        [Audit(DisplayName = "Benefit Deduction Frequency Type")]
        public virtual BenefitDeductionFrequencyTypeEnum? BenefitDeductionFrequencyType { get; set; }
        [Audit(DisplayName = "Is Payroll Calendar Received")]
        public virtual bool IsPayrollCalendarReceived { get; set; }
        [Audit(DisplayName = "Is Payroll File Needed")]
        public virtual bool IsPayrollFileNeeded { get; set; }
        [Audit(DisplayName = "Payroll Deduction File Due Date")]
        public virtual DateTime? PayrollDeductionFileDueDate { get; set; }
        [Audit(DisplayName = "Is Payroll Deduction File Sent")]
        public virtual bool IsPayrollDeductionFileSent { get; set; }
        [Audit(DisplayName = "Deduction Taken Type")]
        public virtual DeductionTakenType DeductionTakenType { get; set; }
        public virtual IList<Participant> Participants { get; set; }
        public virtual CmsTask Task { get; set; }
        public ListBillGroup()
        {
            Participants = new List<Participant>();
        }
    }
}
