﻿using CMS.Model.BaseEntities;
using System;

namespace CMS.Model.Entities
{
    public class EnrollmentMeeting : Entity
    {
        public virtual Enrollment Enrollment { get; set; }
        public virtual DateTime MeetingDateTime { get; set; }        
        public virtual string TimeZone { get; set; }
        public virtual string Location { get; set; }
        public virtual string Room { get; set; }
        public virtual string PhoneOrOther { get; set; }

        public EnrollmentMeeting() { }
    }
}
