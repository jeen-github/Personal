﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class BrokerAffiliationUnderwriterAssociation : Entity
    {
        public virtual BrokerAffiliationType BrokerAffiliationType { get; set; }
        public virtual CmsUser User { get; set; }
    }
}
