﻿using CMS.Model.BaseEntities;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    [Description("Company Business Entity")]
    public class CompanyBusinessEntityType : LookupEntity
    {
    }
}
