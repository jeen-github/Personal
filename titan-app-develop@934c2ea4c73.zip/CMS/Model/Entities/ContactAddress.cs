﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class ContactAddress : Entity
    {
        public virtual Case Case {get; set;}
        public virtual ContactRoleTypeEnum ContactRoleType { get; set; }
        public virtual string DISCode { get; set; }
        public virtual string ProducerNumber { get; set; }
        public virtual string OtherRole { get; set; }
        public virtual string ContactName { get; set; }
        public virtual bool IsPrimary { get; set; }
        public virtual string CompanyName { get; set; }
        public virtual string AddressLine1 { get; set; }
        public virtual string AddressLine2 { get; set; }
        public virtual string City { get; set; }
        public virtual StateTypeEnum? StateType { get; set; }
        public virtual string ZipCode { get; set; }
        public virtual string Email { get; set; }
        public virtual string WebPage { get; set; }
        public virtual string Phone { get; set; }
        public virtual string Extention { get; set; }
        public virtual string Mobile { get; set; }
        public virtual string Fax { get; set; }
        public virtual string Preferences { get; set; }
        public virtual IList<ContactAddressCategory> ContactAddressCategories { get; set; }
        public virtual string JobTitle { get; set; }

        public ContactAddress()
        {
            ContactAddressCategories = new List<ContactAddressCategory>();
        }
    }
}
