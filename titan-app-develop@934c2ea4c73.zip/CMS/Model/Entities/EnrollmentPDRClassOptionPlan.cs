﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class EnrollmentPDRClassOptionPlan : Entity
    {
        public virtual IList<EnrollmentPDRClassOption> EnrollmentPDRClassOptions { get; set; }

        [Audit(DisplayName = "PDR Class Plan Type")]
        public virtual PDRClassPlanTypeEnum PDRClassPlanType { get; set; }

        [Audit(DisplayName = "GSI Percentage", Format = "{0:N2}")]
        public virtual decimal? GSIPercentage { get; set; }

        [Audit(DisplayName = "Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? CoveredEarningsType { get; set; }

        [Audit(DisplayName = "Covered Earnings Bonus Only")]
        public virtual CoveredEarningsBonusOnlyTypeEnum? CoveredEarningsBonusOnlyType { get; set; }

        [Audit(DisplayName = " Replacement Ratio", Format = "{0:N2}")]
        public virtual decimal? ReplacementRatio { get; set; }

        [Audit(DisplayName = "Discount", Format = "{0:N2}")]
        public virtual decimal? Discount { get; set; }

        [Audit(DisplayName = "Elimination Period")]
        public virtual EliminationPeriodTypeEnum? EliminationPeriod { get; set; }

        [Audit(DisplayName = "Benefit Period")]
        public virtual BenefitPeriodTypeEnum? BenefitPeriod { get; set; }

        [Audit(DisplayName = "Minimum Benefit Amount", Format = "{0:N2}")]
        public virtual int? MinimumBenefitAmount { get; set; }

        [Audit(DisplayName = "Definition Of Disability")]
        public virtual DefinitionOfDisabilityTypeEnum DefinitionOfDisabilityType { get; set; }

        [Audit(DisplayName = "Mental Substance Limitation")]
        public virtual MentalSubstanceLimitationEnum MentalSubstanceLimitationType { get; set; }

        [Audit(DisplayName = "PreExisting Condition Limit")]
        public virtual PreExistingConditionLimitTypeEnum PreExistingConditionLimitType { get; set; }

        public virtual IList<EnrollmentPDRClassOptionPlanRider> EnrollmentPDRClassOptionPlanRiders { get; set; }

        public EnrollmentPDRClassOptionPlan()
        {
            EnrollmentPDRClassOptionPlanRiders = new List<EnrollmentPDRClassOptionPlanRider>();
        }

        public override string ToString()
        {
            return PDRClassPlanType != PDRClassPlanTypeEnum.VoluntaryGSIBuyUp ? "Primary Plan Approval" : "GSI Buy-Up Plan Approval";
        }
    }
}
