﻿using CMS.Model.BaseEntities;
using System;

namespace CMS.Model.Entities
{
    public class EnrollmentMLDEStatus : Entity
    {
        public virtual string Status { get; set; }

        public virtual DateTime LastUpdated { get; set; }

        public virtual string Sentby { get; set; }
        public virtual int NumberofParticipants { get; set; }

        public virtual int Enrollment_Id { get; set; }
        public virtual string MLDEJson { get; set; }
    }
   
}
