﻿using System.Collections;
using System.Collections.Generic;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Model.Entities
{
    public class EnrollmentParticipantOptionPlan : Entity
    {
        public virtual EnrollmentParticipant EnrollmentParticipant { get; set; }
        public virtual EnrollmentPDRClassOptionPlan EnrollmentPDRClassOptionPlan { get; set; }
        public virtual bool IsEligible { get; set; }
        public virtual string InEligibilityReason { get; set; }
        public virtual decimal? GSIPercentage { get; set; }
        public virtual CoveredEarningsTypeEnum? CoveredEarningsType { get; set; }
        public virtual CoveredEarningsBonusOnlyTypeEnum? CoveredEarningsBonusOnlyType { get; set; }
        public virtual decimal? ReplacementRatio { get; set; }
        public virtual decimal? Discount { get; set; }
        public virtual EliminationPeriodTypeEnum? EliminationPeriod { get; set; }
        public virtual BenefitPeriodTypeEnum? BenefitPeriod { get; set; }
        public virtual int? MinimumBenefitAmount { get; set; }
        public virtual DefinitionOfDisabilityTypeEnum DefinitionOfDisabilityType { get; set; }
        public virtual MentalSubstanceLimitationEnum MentalSubstanceLimitationType { get; set; }
        public virtual PreExistingConditionLimitTypeEnum PreExistingConditionLimitType { get; set; }
        public virtual decimal? BenefitAmountBaseMonthly {get; set;} 
        public virtual decimal? SmokerPremiumAmountBaseMonthly {get; set;} 
        public virtual decimal? SmokerPremiumAmountMonthly {get; set;} 
        public virtual decimal? SmokerPremiumAmountQuarterly {get; set;} 
        public virtual decimal? SmokerPremiumAmountSemiannually {get; set;} 
        public virtual decimal? SmokerPremiumAmountAnnually {get; set;} 
        public virtual decimal? SmokerPremiumAmountPaycheck {get; set;}   
        public virtual decimal? NonSmokerPremiumAmountBaseMonthly {get; set;} 
        public virtual decimal? NonSmokerPremiumAmountMonthly {get; set;} 
        public virtual decimal? NonSmokerPremiumAmountQuarterly {get; set;} 
        public virtual decimal? NonSmokerPremiumAmountSemiannually {get; set;} 
        public virtual decimal? NonSmokerPremiumAmountAnnually {get; set;} 
        public virtual decimal? NonSmokerPremiumAmountPaycheck {get; set;}
        public virtual PlanDesignTypeEnum? PlanDesignType { get; set; }
        public virtual PDRClassPlanTypeEnum? PDRClassPlanType { get; set; }
        public virtual string StandardOptionCodeNonSmoker { get; set; }
        public virtual string StandardOptionCodeSmoker { get; set; }

        public virtual string RiderValidationSummary { get; set; }
        public virtual IList<EnrollmentParticipantOptionPlanRider> Riders { get; set; }
        public virtual decimal? MonthlyBenefitAmount { get; set; }
        public virtual decimal? TotalMonthlyBenefitAmount { get; set; }
        public virtual decimal? SmokerEmployerPremiumPerMonth { get; set; }
        public virtual decimal? SmokerEmployerPremiumQuarterly { get; set; }
        public virtual decimal? SmokerEmployerPremiumSemiannually { get; set; }
        public virtual decimal? SmokerEmployerPremiumAnnually { get; set; }
        public virtual decimal? SmokerEmployeePremiumPerMonth { get; set; }
        public virtual decimal? SmokerEmployeePremiumQuarterly { get; set; }
        public virtual decimal? SmokerEmployeePremiumSemiannually { get; set; }
        public virtual decimal? SmokerEmployeePremiumAnnually { get; set; }
        public virtual decimal? NonSmokerEmployerPremiumPerMonth { get; set; }
        public virtual decimal? NonSmokerEmployerPremiumQuarterly { get; set; }
        public virtual decimal? NonSmokerEmployerPremiumSemiannually { get; set; }
        public virtual decimal? NonSmokerEmployerPremiumAnnually { get; set; }
        public virtual decimal? NonSmokerEmployeePremiumPerMonth { get; set; }
        public virtual decimal? NonSmokerEmployeePremiumQuarterly { get; set; }
        public virtual decimal? NonSmokerEmployeePremiumSemiannually { get; set; }
        public virtual decimal? NonSmokerEmployeePremiumAnnually { get; set; }
        public virtual decimal? SmokerEmployerPremiumAmountPaycheck { get; set; }
        public virtual decimal? NonSmokerEmployerPremiumAmountPaycheck { get; set; }
        public virtual decimal? SmokerEmployeePremiumAmountPaycheck { get; set; }
        public virtual decimal? NonSmokerEmployeePremiumAmountPaycheck { get; set; }
        public virtual decimal? GLTDReplacementCalculatedPercentage { get; set; }
        public virtual decimal? IDIReplacementCalculatedPercentage { get; set; }
        public virtual decimal? IDIBaseReplacementCalculatedPercentage { get; set; }
        public virtual decimal? TotalGLTDPlusIDICalculatedPercentage { get; set; }
        public virtual decimal? TotalGLTDPlusIDICalculatedAmount { get; set; }
        public virtual decimal? NewTotalPremiumEmployeePortionAnnualPremium { get; set; }
        public virtual decimal? NewTotalPremiumEmployeePortionModalPremium { get; set; }
        public virtual decimal? NewTotalPremiumEmployeePortionPerPaycheckPremium { get; set; }
        public virtual decimal? NewTotalPremiumEmployerPortionAnnualPremium { get; set; }
        public virtual decimal? NewTotalPremiumEmployerPortionModalPremium { get; set; }
        public virtual decimal? NewTotalPremiumEmployerPortionPerPaycheckPremium { get; set; }
        public virtual decimal? NewTotalPremiumAnnualPremium { get; set; }
        public virtual decimal? NewTotalPremiumModalPremium { get; set; }
        public virtual decimal? NewTotalPremiumPerPaycheckPremium { get; set; }
        public virtual decimal? NewTotalBuyUpPremiumAnnualPremium { get; set; }
        public virtual decimal? NewTotalBuyUpPremiumModalPremium { get; set; }
        public virtual decimal? NewTotalBuyUpPremiumPaycheckPremium { get; set; }
        public virtual decimal? AMBCalculatedAmount { get; set; }
        public virtual decimal? SmokerAMBModalPremiumAmount { get; set; }
        public virtual decimal? NonSmokerAMBModalPremiumAmount { get; set; }
        public virtual BillingModeTypeEnum? BillingMode { get; set; }
        public virtual bool? IsSmoker { get; set; }
        public virtual decimal? PreviousYearAnnualPremium { get; set; }
        public virtual decimal? PreviousYearModalPremium { get; set; }

        public EnrollmentParticipantOptionPlan()
        {
            Riders = new List<EnrollmentParticipantOptionPlanRider>();
        }
    }
}