﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class PlanDesignRequest : Entity
    {
        public virtual Case Case { get; set; }
        [Audit(DisplayName = "Is PDR Active")]
        public virtual bool IsActive { get; set; }
        public virtual DateTime CreationDate { get; set; }
        public virtual DateTime? InactiveDate { get; set; }
        public virtual string RequestHeaderName { get; set; }
        [Audit(DisplayName = "Illustration Effective Date", Format = "{0,9:d}")]
        public virtual DateTime? IllustrationEffectiveDate { get; set; }
        [Audit()]
        public virtual bool IsApproved { get; set; }
        public virtual IList<PlanDesignRequestClass> PlanDesignRequestClass { get; set; }
        public virtual string GAPlanDesignRequestId { get; set; }
        public virtual string PDRName { get; set; }
        public virtual PlanDesignRequestStatusTypeEnum? PlanDesignRequestStatusType { get; set; }
        public virtual IList<PlanDesignRequestStatusHistory> PlanDesignRequestStatusHistories { get; set; }
        public virtual IList<Illustration> Illustrations { get; set; }
        public virtual IList<PDRSoldClass> PDRSoldClass { get; set; }
        public virtual string PriorCoverageStatus { get; set; }
        public PlanDesignRequest()
        {
            Case = new Case();
            PlanDesignRequestClass = new List<PlanDesignRequestClass>();
            PlanDesignRequestStatusHistories = new List<PlanDesignRequestStatusHistory>();
            Illustrations = new List<Illustration>();
            PDRSoldClass = new List<PDRSoldClass>();
        }
        public override string ToString()
        {
            return IsApproved == true ? "Approved" : "Unapproved";
        }
    }
}
