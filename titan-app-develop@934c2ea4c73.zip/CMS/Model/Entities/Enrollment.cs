﻿using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;
using CMS.DataAccess.Auditing;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class Enrollment : Entity
    {
        public virtual Case Case { get; set; }
        public virtual string EnrollmentName { get; set; }
        public virtual DateTime EnrollmentStartDate { get; set; }
        public virtual DateTime EnrollmentEndDate { get; set; }
        public virtual DateTime ExtensionEndDate { get; set; }
        public virtual DateTime EffectiveDate { get; set; }
        public virtual EnrollmentMethodType EnrollmentMethodType { get; set; }
        public virtual bool IsAddOnIndicator { get; set; }
        public virtual bool IsFullEnrollmentMilestones { get; set; }
        public virtual string FriendlyName { get; set; }
        public virtual string EnrollmentWebsite { get; set; }
        public virtual bool IsEDeliveryIndicator { get; set; }
        public virtual bool IsLiveChatIndicator { get; set; }
        public virtual bool IsCourtesyCallsIndicator { get; set; }
        public virtual bool IsVoiceMailDropIndicator { get; set; }
        [Audit(DisplayName = "IsSuspendedToAutoCode")]
        public virtual bool IsSuspendedToAutoCode { get; set; }
        public virtual bool IsCallCenterOrIndividualReachOutIndicator { get; set; }
        [Audit(DisplayName = "Attested to")]
        public virtual bool IsAttested { get; set; }
        public virtual bool IsInitialBillingCall { get; set; }
        public virtual bool? IsW9sent { get; set; }
        public virtual IList<EnrollmentPDRClass> Classes { get; set; }
        public virtual IList<EnrollmentParticipant> CensusParticipants { get; set; }
        public virtual IList<EnrollmentMilestone> EnrollmentMilestones { get; set; }
        public virtual IList<EnrollmentMeeting> EnrollmentMeeting { get; set; }
        public virtual IList<BenefitPremiumDocument> BenefitPremiumDocuments { get; set; }
        public virtual WorkUnit SolicitationDeclinesTaskWorkUnit { get; set; }
        public virtual WorkUnit StartDateTaskWorkUnit { get; set; } //Work Unit Type-EnrollmentInProgress
        public virtual WorkUnit ExtensionEndDateTaskWorkUnit { get; set; } //Work Unit Type-PostEnrollment
        public virtual bool? IsActive { get; set; }
        public virtual AMBTypeEnum? AMBType { get; set; }
        public virtual AMBTypeEnum? BuyUpAMBType { get; set; }
        public virtual DateTime? NegativeEnrollmentDateQuequed { get; set; }
        public virtual DateTime? NegativeEnrollmentProcessDate { get; set; }
        public virtual PricingTypeEnum? PricingType { get; set; }
        public virtual string Passcode { get; set; }

        public Enrollment()
        {
            Classes = new List<EnrollmentPDRClass>();
            CensusParticipants = new List<EnrollmentParticipant>();
            EnrollmentMilestones = new List<EnrollmentMilestone>();
            EnrollmentMeeting = new List<EnrollmentMeeting>();
            BenefitPremiumDocuments = new List<BenefitPremiumDocument>();
        }
    }
}
