﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
    public class CaseCompanyRetirementPlan : Entity
    {
        public virtual PlanDesignRequestClass PlanDesignRequestClass { get; set; }
        [Audit(DisplayName = "Company Retirement Plan")]
        public virtual CompanyRetirementPlanType CompanyRetirementPlanType { get; set; }
        [Audit()]
        public virtual bool IsChecked { get; set; }
        [Audit(DisplayName = "Company Retirement Plan Type Other")]
        public virtual string CompanyRetirementPlanType_Other { get; set; }
        public override string ToString()
        {
            return "Company Retirement Plan " + CompanyRetirementPlanType.Description;
        }
    }
}
