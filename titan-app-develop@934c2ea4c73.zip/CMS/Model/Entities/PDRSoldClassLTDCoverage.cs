﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class PDRSoldClassLTDCoverage : Entity
    {
        public virtual PDRSoldClass PDRSoldClass { get; set; }
        [Audit(DisplayName = "Eligible Population Text")]
        public virtual string EligiblePopulationText { get; set; }

        [Audit(DisplayName = "Carrier Text")]
        public virtual string CarrierText { get; set; }

        [Audit(DisplayName = "Elimination Period Days")]
        public virtual int EliminationPeriodDays { get; set; }

        [Audit(DisplayName = "Benefit Period Days")]
        public virtual int BenefitPeriodDays { get; set; }

        [Audit(DisplayName = "Group LTD Replacement Percentage", Format = "{0:N2}")]
        public virtual decimal GroupLTDReplacementPercentage { get; set; }

        [Audit(DisplayName = "Group LTD Cap Amount", Format = "{0:N2}")]
        public virtual decimal GroupLTDCapAmount { get; set; }

        [Audit(DisplayName = "Group LTD Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? GroupLTDCoveredEarningsType { get; set; }

        [Audit(DisplayName = "Group LTD Covered Earnings Other")]
        public virtual string GroupLTDCoveredEarningsType_Other { get; set; }

        [Audit(DisplayName = "Premium And Taxpayer Liability")]
        public virtual ExistingCoveragePremiumAndTaxpayerLiabilityType PremiumAndTaxpayerLiabilityType { get; set; }

        [Audit(DisplayName = "Type Of Pay")]
        public virtual TaxabilityTypeEnum? TypeOfPayType { get; set; }

        [Audit(DisplayName = "Is Voluntary LTD Buy Up Indicator")]
        public virtual bool? IsVoluntaryLTDBuyUpIndicator { get; set; }

        [Audit(DisplayName = "LTD Buy Up Replacement Percentage", Format = "{0:N2}")]
        public virtual decimal? LTDBuyUpReplacementPercentage { get; set; }

        [Audit(DisplayName = "LTD Buy Up LTD Cap Amount", Format = "{0:N2}")]
        public virtual decimal? LTDBuyUpLTDCapAmount { get; set; }

        [Audit(DisplayName = "LTD Bu yUp Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? LTDBuyUpCoveredEarningsType { get; set; }

        [Audit(DisplayName = "LTD Buy Up Covered Earnings Other")]
        public virtual string LTDBuyUpCoveredEarningsType_Other { get; set; }

        [Audit(DisplayName = "LTD PlanExisting Indicator")]
        public virtual bool? IsLTDPlanExistingIndicator { get; set; }

        [Audit(DisplayName = "Additional Details Text")]
        public virtual string AdditionalDetailsText { get; set; }

        [Audit(DisplayName = "Base Salary Percentage")]
        public virtual decimal? BaseSalaryPercentage { get; set; }

        [Audit(DisplayName = "Bonus Percentage")]
        public virtual decimal? BonusPercentage { get; set; }

        [Audit(DisplayName = "Commission Percentage")]
        public virtual decimal? CommissionPercentage { get; set; }

        [Audit(DisplayName = "Other Income Percentage")]
        public virtual decimal? OtherIncomePercentage { get; set; }

        [Audit(DisplayName = "K1 Earnings Percentage")]
        public virtual decimal? K1EarningsPercentage { get; set; }

        [Audit(DisplayName = "Bonus Number of Years")]
        public virtual int? BonusNumberofYears { get; set; }

        [Audit(DisplayName = "Commission Number of Years")]
        public virtual int? CommissionNumberofYears { get; set; }

        [Audit(DisplayName = "K1 Earnings Number of Years")]
        public virtual int? K1EarningsNumberofYears { get; set; }

    }
}
