﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class EnrollmentPDRClassOption : Entity
    {
        public virtual EnrollmentPDRClass EnrollmentPDRClass { get; set; }

        [Audit(DisplayName = "Option Code")]
        public virtual string OptionCode { get; set; }

        [Audit(DisplayName = "Standard OptionCode Non Smoker")]
        public virtual string StandardOptionCodeNonSmoker { get; set; }

        [Audit(DisplayName = "Standard OptionCode Smoker")]
        public virtual string StandardOptionCodeSmoker { get; set; }

        [Audit(DisplayName = "Option is selected")]
        public virtual bool IsSelected { get; set; }

        public virtual IList<EnrollmentPDRClassOptionPlan> EnrollmentPDRClassOptionPlans { get; set; }
        public EnrollmentPDRClassOption()
        {
            EnrollmentPDRClassOptionPlans = new List<EnrollmentPDRClassOptionPlan>();
        }
    }
}
