﻿using System;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using CMS.Model.Attributes;
using CMS.DataAccess.Auditing;

namespace CMS.Model.Entities
{
    public class CaseDocument : Entity
    {
        public virtual int Case_Id { get; set; }
        public virtual string GAPDRId { get; set; }        
        public virtual string DocumentName { get; set; }
        public virtual CaseDocumentTypeEnum CaseDocumentType { get; set; }
        public virtual int? PreviousVersionCaseDocument_Id { get; set; }
        public virtual int Version { get; set; }
        public virtual DateTime CreationDateTime { get; set; }
        public virtual CmsUser CreatedByUser { get; set; }
        public virtual string UploadedByGALdapUser { get; set; }
        public virtual string UploadedByGALdapUserRole { get; set; }

        public virtual string FileName { get; set; }
        public virtual string FileMimeType { get; set; }
        public virtual long? FileNetDocumentId { get; set; }
        public virtual byte[] FileBytes { get; set; }

        public virtual CaseDocumentRequest CaseDocumentRequest { get; set; }

        public virtual bool IsExternalIndicator { get; set; }

        [Audit(DisplayName = "IsDeleted")]
        public virtual bool IsDeleted { get; set; }
        
        public virtual bool IsFileNetUploadedIndicator { get; set; }
        public virtual int FileNetUploadRetries { get; set; }
        public virtual string NewFileNetDocumentId { get; set; }

        public virtual bool IsDocumentReady()
        {
            return FileBytes != null || FileNetDocumentId != null;
        }
    }
}