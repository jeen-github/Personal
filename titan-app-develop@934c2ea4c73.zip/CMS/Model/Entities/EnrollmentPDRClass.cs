﻿using CMS.Model.BaseEntities;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class EnrollmentPDRClass : Entity
    {
        public virtual Enrollment Enrollment { get; set; }
        public virtual PlanDesignRequestClass PlanDesignRequestClass { get; set; }
        public virtual IList<EnrollmentPDRClassOption> EnrollmentPDRClassOptions { get; set; }
        public virtual StandardPackageType StandardPackageType { get; set; }
        public EnrollmentPDRClass()
        {
            EnrollmentPDRClassOptions = new List<EnrollmentPDRClassOption>();
        }
    }
}
