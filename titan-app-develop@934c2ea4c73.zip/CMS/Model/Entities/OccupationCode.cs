﻿using CMS.Model.BaseEntities;


namespace CMS.Model.Entities
{
    public class OccupationCode : Entity
    {
        public virtual string Occupation { get; set; }
        public virtual string OccCode { get; set; }
        public virtual string CommonAbbreviations { get; set; }
        public virtual int SortOrder { get; set; }
        public virtual bool IsActive { get; set; }
    }
}
