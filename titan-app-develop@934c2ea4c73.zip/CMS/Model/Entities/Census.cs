﻿using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class Census : Entity
    {
        public virtual string GACensusId { get; set; }
        public virtual Case Case { get; set; }
        public virtual PlanDesignRequest PlanDesignRequest { get; set; }
        public virtual DateTime? ReceivedDateTime { get; set; }
        public virtual bool IsActiveIndicator { get; set; }
        public virtual int? ReconciliationStatus { get; set; }
        public virtual string GAPlanDesignRequestId { get; set; }
        public virtual IList<Participant> CensusParticipants { get; set; }

        public Census()
        {
            CensusParticipants = new List<Participant>();
        }
    }
}