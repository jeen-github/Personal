﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class CaseCompanyGuardianProduct : Entity
    {
        public virtual Case Case { get; set; }
        public virtual CompanyGuardianProductType CompanyGuardianProductType { get; set; }
        public virtual bool IsAlreadyAGuardianGroupClientIndicator { get; set; }
        public virtual bool IsCurrentlyQuotingGuardianGroupProductIndicator { get; set; }
    }
}
