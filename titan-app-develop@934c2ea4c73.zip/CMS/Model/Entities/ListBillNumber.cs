﻿using System;
using System.Collections.Generic;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using CMS.DataAccess.Auditing;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Model.Entities
{
    public class ListBillNumber : Entity
    {
        public virtual Case Case { get; set; }
        [Audit(DisplayName = "Bill Number")]
        public virtual string BillNumber { get; set; }
        [Audit(DisplayName = "Bill Number")]
        public virtual bool IsDirectBill { get; set; }
        [Audit(DisplayName = "Due Date")]
        public virtual DateTime? DueDate { get; set; }
        [Audit(DisplayName = "Date Sent")]
        public virtual DateTime? DateSent { get; set; }
        [Audit(DisplayName = "Status")]
        public virtual string Status { get; set; }
        [Audit(DisplayName = "Bill Amount")]
        public virtual decimal? BillAmount { get; set; }
        [Audit(DisplayName = "Unapplied Amount")]
        public virtual decimal? UnappliedAmount { get; set; }
        [Audit(DisplayName = "Bill Method Type")]
        public virtual BillingMethodTypeEnum? BillingMethodType { get; set; }
        [Audit(DisplayName = "Bill Mode Type")]
        public virtual BillingModeTypeEnum? BillingModeType { get; set; }
        [Audit(DisplayName = "Remittance Method Type")]
        public virtual RemittanceMethodTypeEnum? RemittanceMethodType { get; set; }
        [Audit(DisplayName = "Policy Delivery Method Type")]
        public virtual PolicyDeliveryMethodType PolicyDeliveryMethodType { get; set; }
        [Audit(DisplayName = "Payroll Contact")]
        public virtual ContactAddress PayrollContact { get; set; }
        [Audit(DisplayName = "List Bill Contact")]
        public virtual ContactAddress ListBillContact { get; set; }
        [Audit(DisplayName = "Is Sent")]
        public virtual bool IsSent { get; set; }
        [Audit(DisplayName = "Is Paid")]
        public virtual bool IsPaid { get; set; }
        [Audit(DisplayName = "Common Id Employee")]
        public virtual Decimal? CommonIDEmployee { get; set; }
        [Audit(DisplayName = "Common Id Employer")]
        public virtual Decimal? CommonIDEmployer { get; set; }
        [Audit(DisplayName = "Class Code Type")]
        public virtual ClassCodeType ClassCodeType { get; set; }
        [Audit(DisplayName = "Bill End Date")]
        public virtual DateTime? BillEndDate { get; set; }
        [Audit(DisplayName = "Deduction Start Date")]
        public virtual DateTime? DeductionStartDate { get; set; }
        [Audit(DisplayName = "File Type")]
        public virtual BillingAutomaticPayrollDeductionFileType BillingAutomaticPayrollDeductionFileType { get; set; }
        [Audit(DisplayName = "Send Days")]
        public virtual int? SendDays { get; set; }
        public virtual IList<ListBillGroup> ListBillGroups { get; set; }

        public ListBillNumber()
        {
            ListBillGroups = new List<ListBillGroup>();
        }
        [Audit(DisplayName = "Is Payroll Frequency")]
        public virtual bool IsPayrollFrequency { get; set; }
        [Audit(DisplayName = "Is Deduction Amount")]
        public virtual bool IsDeductionAmount { get; set; }
        [Audit(DisplayName = "Is Employee Id")]
        public virtual bool IsEmployeeID { get; set; }
    }
}
