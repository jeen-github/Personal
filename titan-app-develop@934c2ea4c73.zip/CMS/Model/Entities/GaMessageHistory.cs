﻿using System;
using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class GaMessageHistory : Entity
    {
        public virtual DateTime ReceivedDateTime { get; set; }
        public virtual string MessageType { get; set; }
        public virtual string GaCaseId { get; set; }
        public virtual string MessageId { get; set; }
        public virtual string MessageBody { get; set; }
        public virtual bool? IsSuccessIndicator { get; set; }
        public virtual string ErrorMessage { get; set; }
        public virtual string GaPDRId { get; set; }
        public virtual DateTime? ProcessEndTime { get; set; }
    }
}
