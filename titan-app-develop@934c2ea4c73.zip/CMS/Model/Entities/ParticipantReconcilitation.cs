﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using System;

namespace CMS.Model.Entities
{
    
    public class ParticipantReconciliation : Entity
    {
        public virtual string EmployeeId { get; set; }
        public virtual Census Census { get; set; }
        public virtual Participant Participant { get; set; }                
        public virtual string FirstName { get; set; }
        public virtual string LastName { get; set; }
        public virtual string MiddleInitial { get; set; }
        public virtual string Suffix { get; set; }
        public virtual string HomeStreet1 { get; set; }
        public virtual string HomeStreet2 { get; set; }
        public virtual string HomeCity { get; set; }
        public virtual StateTypeEnum? HomeState { get; set; }
        public virtual string HomeStateDescription { get; set; }
        public virtual string HomeZipCode { get; set; }
        public virtual string PersonalEmail { get; set; }
        public virtual string CellPhone { get; set; }
        public virtual string HomePhone { get; set; }
        public virtual string WorkStreet1 { get; set; }
        public virtual string WorkStreet2 { get; set; }
        public virtual string WorkCity { get; set; }
        public virtual string WorkStateDescription { get; set; }
        public virtual string WorkZipCode { get; set; }
        public virtual string WorkStopCode { get; set; }
        public virtual string WorkLocationPhone { get; set; }
        public virtual int? Age { get; set; }
  //      public virtual string WorkLocationExtension { get; set; }
        public virtual string WorkEmail { get; set; }
        public virtual DateTime? DateOfHire { get; set; }
        public virtual DateTime? DateOfBirth { get; set; }
        public virtual string Gender { get; set; }
        public virtual int? HoursPerWeek_Id { get; set; }
        public virtual decimal? CurrentSalaryAmount { get; set; }
        public virtual decimal? MostRecentPaidBonusAmount { get; set; }
        public virtual string HoursPerWeekDescription { get; set; }
        public virtual string JobTitle { get; set; }
        public virtual string BoardCertification { get; set; }
        public virtual int? MostRecentPaidBonusYear { get; set; }
        public virtual decimal? PriorPaidBonusAmount { get; set; }
        public virtual int? PriorPaidBonusYear { get; set; }
        public virtual decimal? AdditionalPriorPaidBonusAmount { get; set; }
        public virtual int? AdditionalPriorPaidBonusYear { get; set; }
        public virtual decimal? MostRecentPaidCommissionAmount { get; set; }
        public virtual int? MostRecentPaidCommissionYear { get; set; }
        public virtual decimal? PriorPaidCommissionAmount { get; set; }
        public virtual int? PriorPaidCommissionYear { get; set; }
        public virtual decimal? AdditionalPriorPaidCommissionAmount { get; set; }
        public virtual int? AdditionalPriorPaidCommissionYear { get; set; }
        public virtual decimal? MostRecentPaidK1IncomeAmount { get; set; }
        public virtual int? MostRecentPaidK1IncomeYear { get; set; }
        public virtual decimal? PriorPaidK1IncomeAmount { get; set; }
        public virtual int? PriorPaidK1IncomeYear { get; set; }
        public virtual decimal? AdditionalPriorPaidK1IncomeAmount { get; set; }
        public virtual int? AdditionalPriorPaidK1IncomeYear { get; set; }
        public virtual decimal? OtherIncomeAmount { get; set; }
        public virtual string TypeOfIncome { get; set; }
        public virtual decimal? TotalEmployerOrEmployeeRetirementContributionAmount { get; set; }
        public virtual string EligibleClass { get; set; }
        public virtual int? GroupLTDClass { get; set; }
        public virtual string IDICarrier1Description { get; set; }
        public virtual IDICoverageCarrierTypeEnum? IDICarrier1 { get; set; }
        public virtual decimal? IDIBenefitAmount1 { get; set; }
        public virtual bool? IDIToBeReplaced1 { get; set; }
        public virtual decimal? IDIToBeReplacedAmount1 { get; set; }
        public virtual string IDIPolicyNumber1 { get; set; }
        public virtual string IDICarrier2Description { get; set; }
        public virtual IDICoverageCarrierTypeEnum? IDICarrier2 { get; set; }
        public virtual decimal? IDIBenefitAmount2 { get; set; }
        public virtual bool? IDIToBeReplaced2 { get; set; }
        public virtual decimal? IDIToBeReplacedAmount2 { get; set; }
        public virtual string IDIPolicyNumber2 { get; set; }
        public virtual string IDICarrier3Description { get; set; }
        public virtual IDICoverageCarrierTypeEnum? IDICarrier3 { get; set; }
        public virtual decimal? IDIBenefitAmount3 { get; set; }
        public virtual bool? IDIToBeReplaced3 { get; set; }
        public virtual decimal? IDIToBeReplacedAmount3 { get; set; }
        public virtual string IDIPolicyNumber3 { get; set; }
        public virtual string IDICarrier4Description { get; set; }
        public virtual IDICoverageCarrierTypeEnum? IDICarrier4 { get; set; }
        public virtual decimal? IDIBenefitAmount4 { get; set; }
        public virtual bool? IDIToBeReplaced4 { get; set; }
        public virtual decimal? IDIToBeReplacedAmount4 { get; set; }
        public virtual string IDIPolicyNumber4 { get; set; }
        public virtual int? BenefitDeductionFrequency_Id { get; set; }
        public virtual string BenefitDeductionFrequencyDescription { get; set; }
        public virtual string Occupation { get; set; }
        public virtual string CLOASOccupationCode { get; set; }
        public virtual int? OccupationClass_Id { get; set; }
        public virtual string OccupationClassDescription { get; set; }
        public virtual decimal? CurrentYearSalaryAmount { get; set; }            
        public virtual int? ParticipantReconciliationStatus { get; set; }
    }
}