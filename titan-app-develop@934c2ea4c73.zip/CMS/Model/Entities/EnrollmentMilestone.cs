﻿using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
    public class EnrollmentMilestone : Entity
    {
        public virtual Enrollment Enrollment { get; set; }
        public virtual string EnrollmentMilestoneName { get; set; }
        public virtual DateTime? MilestoneStartDate { get; set; }
        public virtual DateTime? MilestoneDueDate { get; set; }
        public virtual IList<EnrollmentMilestoneTask> EnrollmentMilestoneTasks { get; set; }
        public EnrollmentMilestone()
        {
            EnrollmentMilestoneTasks = new List<EnrollmentMilestoneTask>();
        }
    }
}
