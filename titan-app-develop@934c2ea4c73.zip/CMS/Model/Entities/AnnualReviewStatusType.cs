﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class AnnualReviewStatusType : LookupEntity
    {
    }
}
