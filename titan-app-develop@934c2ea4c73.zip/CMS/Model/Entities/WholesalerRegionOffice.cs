﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class WholesalerRegionOffice : Entity
    {
        public virtual string OfficeCode { get; set; }
        public virtual string OfficeName { get; set; }
        public virtual WholesalerRegionOfficeTypeEnum WholesalerRegionOfficeType { get; set; }
        public virtual WholesalerRegion WholesalerRegion {get;set;}
    }
}
