﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Model.Entities
{
    public class CaseUnderwritingRequest : Entity
    {
        public virtual Case Case { get; set; }
        [Audit(DisplayName = "Situs Type")]
        public virtual SitusTypeEnum? SitusType { get; set; }
        [Audit(DisplayName = "State Name")]
        public virtual StateTypeEnum? StateType { get; set; }
        [Audit(DisplayName = "Situs Multi-State1 Name")]
        public virtual StateTypeEnum? SitusMultiState1Type { get; set; }
        [Audit(DisplayName = "Situs Multi-State2 Name")]
        public virtual StateTypeEnum? SitusMultiState2Type { get; set; }
        [Audit(DisplayName = "Situs Multi-State3 Name")]
        public virtual StateTypeEnum? SitusMultiState3Type { get; set; }
        [Audit(DisplayName = "IsCompactState")]
        public virtual bool? IsCompactState { get; set; }
        [Audit(DisplayName = "Notes")]
        public virtual string Notes { get; set; }
        [Audit(DisplayName = "Pricing Type")]
        public virtual PricingTypeEnum? PricingType { get; set; }
    }
}
