﻿using CMS.Model.BaseEntities;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    [Description("Existing Individual Disability ReasonOutMarket")]
    public class ExistingIndividualDisabilityReasonOutMarketType : LookupEntity
    {
    }
}
