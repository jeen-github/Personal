﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
    public class BenefitPremiumDocument : Entity
    {
        public virtual Enrollment Enrollment { get; set; }
        public virtual string BenefitPremiumName { get; set; }
        public virtual DateTime? GeneratedDateTime { get; set; }
        public virtual string GeneratedBy {get;set;}
        public virtual DateTime EffectiveDate { get; set; }
        public virtual BenefitPremiumDocumentStatusTypeEnum? BenefitPremiumDocumentStatusType { get; set; }
        public virtual DateTime? ApprovedDateTime { get; set; }
        public virtual string ApprovedBy { get;set;}
        public virtual CaseDocument PdfDocument { get; set; }
        public virtual CaseDocument ExcelDocument { get; set; }
        public virtual bool IsActiveIndicator { get; set; }
    }
}
