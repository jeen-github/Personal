﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class EnrollmentOutputShowType : LookupEntity
    {

    }
}
