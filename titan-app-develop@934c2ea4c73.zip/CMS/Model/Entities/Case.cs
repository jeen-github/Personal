﻿using System;
using System.Collections.Generic;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using CMS.DataAccess.Auditing;

namespace CMS.Model.Entities
{
    public class Case : Entity
    {
        public virtual Company Company { get; set; }
        public virtual DateTime CreationDate { get; set; }
        public virtual string CaseNumber { get; set; }
        public virtual string GACaseId { get; set; }
        public virtual IList<CmsTask> Tasks { get; set; }
        public virtual CaseStatusTypeEnum CaseStatusType { get; set; }

        [Audit(DisplayName = "Company Name")]
        public virtual string CompanyName { get; set; }

        [Audit(DisplayName = "Company Address Line1")]
        public virtual string CompanyAddressLine1 { get; set; }

        [Audit(DisplayName = "Company Address Line2")]
        public virtual string CompanyAddressLine2 { get; set; }

        [Audit(DisplayName = "Company City")]
        public virtual string CompanyCity { get; set; }

        [Audit(DisplayName = "Company State")]
        public virtual StateTypeEnum? CompanyStateType { get; set; }

        [Audit(DisplayName = "Company ZipCode")]
        public virtual string CompanyZipCode { get; set; }

        [Audit(DisplayName = "Company Nature Of Business")]
        public virtual string CompanyNatureOfBusiness { get; set; }

        [Audit(DisplayName = "Company Web Address")]
        public virtual string CompanyWebAddress { get; set; }

        [Audit(DisplayName = "Company Business Entity")]
        public virtual CompanyBusinessEntityType CompanyBusinessEntityType { get; set; }

        [Audit(DisplayName = "Company Business Entity Unknow text")]
        public virtual string CompanyBusinessEntityUnknownComments { get; set; }

        [Audit(DisplayName = "Company SIC Code Division")]
        public virtual CompanySicDivisionType CompanySicDivisionType { get; set; }

        [Audit(DisplayName = "Company SIC Code Major Group")]
        public virtual CompanySicMajorGroupType CompanySicMajorGroupType { get; set; }

        [Audit(DisplayName = "Company SIC Code Sub Group")]
        public virtual CompanySicSubGroupType CompanySicSubGroupType { get; set; }

        [Audit(DisplayName = "Company Is there a NDA")]
        public virtual bool? IsCompanyNonDisclosureAgreementIndicator { get; set; }
        public virtual bool IsTheCompanyAlreadyGuardianGroupClientIndicator { get; set; }
        [Audit(DisplayName = "Company Is there Erisa")]
        public virtual bool? IsCompanyErisaIndicator { get; set; }
        [Audit(DisplayName = "Company Revision SIC Code")]
        public virtual string CompanyRevisionSicCode { get; set; }

        public virtual StateTypeEnum? SitusStateType { get; set; }

        public virtual DateTime? BrokerIllustrationDate { get; set; }

        public virtual DateTime? BrokerEffectiveDate { get; set; }

        public virtual DateTime? BrokerActiveCensusDate { get; set; }
        public virtual string CaseCompetitiveDescription { get; set; }
        public virtual IList<CaseCompanyLocation> CaseCompanyLocations { get; set; }
        public virtual IList<CaseBroker> CaseBrokers { get; set; }
        public virtual IList<CaseWholesaler> CaseWholesalers { get; set; }
        public virtual IList<CaseCarrier> CaseCarriers { get; set; }
        public virtual IList<CaseCompanyGuardianProduct> CaseCompanyGuardianProducts { get; set; }
        [Audit(DisplayName = "Additional Comments")]
        public virtual string AdditionalCommentsText { get; set; }
        public virtual IList<PlanDesignRequest> PlanDesignRequests { get; set; }
        public virtual IList<CaseUnderwritingRequest> CaseUnderwritingRequests { get; set; }
        public virtual int? EnrollmentManagerId { get; set; }
        public virtual int? ImplementationAnalystId { get; set; }
        public virtual IList<Enrollment> CaseEnrollments { get; set; }
        public virtual IList<ListBillNumber> ListBillNumbers { get; set; }
        public virtual bool? IsConfidentialCaseIndicator { get; set; }

        public Case()
        {
            Tasks = new List<CmsTask>();
            CaseCompanyLocations = new List<CaseCompanyLocation>();
            CaseBrokers = new List<CaseBroker>();
            CaseWholesalers = new List<CaseWholesaler>();
            CaseCarriers = new List<CaseCarrier>();
            CaseCompanyGuardianProducts = new List<CaseCompanyGuardianProduct>();
            PlanDesignRequests = new List<PlanDesignRequest>();
            CaseUnderwritingRequests = new List<CaseUnderwritingRequest>();
            CaseEnrollments = new List<Enrollment>();
            ListBillNumbers = new List<ListBillNumber>();
        }
    }
}