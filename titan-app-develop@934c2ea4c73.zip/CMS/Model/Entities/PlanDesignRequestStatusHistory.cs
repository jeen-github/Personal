﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;

namespace CMS.Model.Entities
{
    public class PlanDesignRequestStatusHistory : Entity
    {
        public virtual PlanDesignRequest PlanDesignRequest { get; set; }
        public virtual PlanDesignRequestStatusTypeEnum PlanDesignRequestStatusType { get; set; }
        public virtual DateTime DateOfChange { get; set; }
        public virtual int? ApprovedByUser_Id { get; set; }
        public virtual int TitanUserUser_id { get; set; }
        public virtual int? DeclinedByUser_Id { get; set; }
        public virtual int? SecondSignature_Id { get; set; }
        public virtual string DeclineReason { get; set; }

        public PlanDesignRequestStatusHistory()
        {
            PlanDesignRequest = new PlanDesignRequest();
        }
    }
}
