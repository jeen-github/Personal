﻿using CMS.Model.BaseEntities;
using System.Collections.Generic;
using CMS.DataAccess.Auditing;

namespace CMS.Model.Entities
{
    public class PDRSoldClass : Entity
    {
        public virtual PlanDesignRequest PlanDesignRequest { get; set; }
                
        public virtual PlanDesignRequestClass PlanDesignRequestClass { get; set; }

        public virtual IList<PDRSoldClassPlan> PDRSoldClassPlan { get; set; }

        public virtual IList<PDRSoldClassLTDCoverage> PDRSoldClassLTDCoverage { get; set; }

        public virtual IList<PDRSoldClassCompanyRetirementPlan> PDRSoldClassCompanyRetirementPlan { get; set; }

        [Audit(DisplayName = "Eligible Population Text")]
        public virtual string EligiblePopulationText { get; set; }

        [Audit(DisplayName = "Eligible Population Text Notes")]
        public virtual string EligiblePopulationTextNotes { get; set; }

        public virtual bool IsActive { get; set; }
        public virtual bool IsAnnualReviewComplete { get; set; }

        public PDRSoldClass()
        {
            PDRSoldClassPlan = new List<PDRSoldClassPlan>();
            PDRSoldClassLTDCoverage = new List<PDRSoldClassLTDCoverage>();
            PDRSoldClassCompanyRetirementPlan = new List<PDRSoldClassCompanyRetirementPlan>();
        }
        public override string ToString()
        {
            return PlanDesignRequestClass.PlanDesignRequestClassName;
        }
    }
}
