﻿using System;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System.Collections;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class CmsTask : Entity
    {
        public const string TaskNewCaseReceived = "New Case Received";

        public const string TaskVerifyEmployerClientID = "Verify Employer Client ID";

        public const string TaskRevisedCaseReceived = "Revised Case Received";
        public const string TaskSoldCaseSubmissiondocumentReceived = "Sold Case Submission document received";

        public virtual TaskGroup TaskGroup { get; set; }
        public virtual string TaskName { get; set; }
        public virtual Case Case { get; set; }
        public virtual DateTime CreationDate { get; set; }
        public virtual DateTime DueDate { get; set; }
        public virtual UserGroup AssignedToUserGroup { get; set; }
        public virtual CmsUser AssignedToUser { get; set; }
        public virtual CmsUser ClaimedByUser { get; set; }
        public virtual bool IsCompletedIndicator { get; set; }
        public virtual DateTime? CompletedDate { get; set; }
        public virtual DateTime? UpdatedDueDate { get; set; }
        public virtual DateTime? FollowUpDate { get; set; }
        public virtual TaskStatusTypeEnum? TaskStatusType { get; set; }
        public virtual bool IsAdHocIndicator { get; set; }
        public virtual string Comments { get; set; }
        public virtual DateTime? ClaimedDate { get; set; }
        public virtual DateTime? SuspendedDate { get; set; }
        public virtual CmsUser CompletedByUser { get; set; }
        public virtual IList<TaskActivityLog> TaskActivityLogs { get; set; }
        public virtual PlanDesignRequest PlanDesignRequest { get; set; }
        public virtual bool? IsActive { get; set; }
        public virtual string CreatedBy { get; set; }

        public CmsTask()
        {
            TaskActivityLogs = new List<TaskActivityLog>();
        }
    }
}
