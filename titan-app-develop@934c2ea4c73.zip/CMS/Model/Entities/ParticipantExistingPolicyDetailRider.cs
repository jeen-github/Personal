﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class ParticipantExistingPolicyDetailRider : Entity
    {

        public virtual ParticipantExistingPolicyDetail ParticipantExistingPolicyDetail { get; set; }
        public virtual BenefitTypeEnum? BenefitType { get; set; }
        public virtual string BenefitTypeDescription { get; set; }
        public virtual BenefitGroupTypeEnum? BenefitGroupType { get; set; }
        public virtual string BenefitGroupTypeDescription { get; set; }
        public virtual EliminationPeriodTypeEnum? EliminationPeriodType { get; set; }
        public virtual string EliminationPeriodTypeDescription { get; set; }
        public virtual BenefitPeriodTypeEnum? BenefitPeriodType { get; set; }
        public virtual string BenefitPeriodTypeDescription { get; set; }
        public virtual decimal? ApprovedAmount { get; set; }
    }
}
