﻿using System;
using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;
using CMS.DataAccess.Auditing;
using CMS.Model.Extensions;

namespace CMS.Model.Entities
{
    public class PDRSoldClassPlanRiders : Entity
    {
        public virtual PDRSoldClassPlan PDRSoldClassPlan { get; set; }

        [Audit(DisplayName = "Rider Benefit")]
        public virtual BenefitTypeEnum BenefitType { get; set; }

        [Audit(DisplayName = "Rider Benefit Group")]
        public virtual BenefitGroupTypeEnum BenefitGroupType { get; set; }

        [Audit(DisplayName = "Rider Elimination Period")]
        public virtual EliminationPeriodTypeEnum? EliminationPeriodType { get; set; }

        [Audit(DisplayName = "Rider Benefit Period")]
        public virtual BenefitPeriodTypeEnum? BenefitPeriodType { get; set; }

        [Audit(DisplayName = "Rider Approved Amount", Format = "{0:N2}")]
        public virtual decimal? ApprovedAmount { get; set; }

        public override string ToString()
        {
            return PDRSoldClassPlan.PDRClassPlanType == Enums.PDRClassPlanTypeEnum.VoluntaryGSIBuyUp ? "GSI Buy-Up Plan Approval Rider " + BenefitType.GetDescription() : "Primary Plan Approval Rider " + BenefitType.GetDescription();
        }
    }
}
