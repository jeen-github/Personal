﻿using CMS.Model.BaseEntities;
using System;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class PricingApprovedStates : Entity
    {
        public virtual PricingTypeEnum PricingType { get; set; }
        public virtual int StateTypeId { get; set; }
        public virtual string StateCode { get; set; }
        public virtual string StateDescription { get; set; }
        public virtual bool IsApproved { get; set; }
        public virtual bool IsActive { get; set; }
        public virtual DateTime? ApprovedDate { get; set; }
        public virtual string UpdatedBy { get; set; }
    }
}
