﻿using CMS.Model.BaseEntities;
using System;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class CompactApprovedStates : Entity
    {
        public virtual PricingTypeEnum PricingType { get; set; }
        public virtual StateType StateType { get; set; }            
        public virtual bool IsApproved { get; set; }
        public virtual bool IsActive { get; set; }
        public virtual DateTime? UpdatedDate { get; set; }
        public virtual string UpdatedBy { get; set; }
    }
}
