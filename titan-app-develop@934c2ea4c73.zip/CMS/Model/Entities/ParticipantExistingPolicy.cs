﻿using CMS.Model.BaseEntities;
using System.Collections.Generic;
namespace CMS.Model.Entities
{
    public class ParticipantExistingPolicy : Entity
    {
        public virtual Participant Participant { get; set; }
        public virtual decimal? GSIIDIBaseAMB { get; set; }
        public virtual decimal? GSIRPPBaseAMB { get; set; }
        public virtual decimal? FullyUnderwrittenIDI { get; set; }
        public virtual decimal? FullyUnderwrittenRPP { get; set; }
        public virtual IList<ParticipantExistingPolicyDetail> ParticipantExistingPolicyDetails { get; set; }


        public ParticipantExistingPolicy()
        {
            ParticipantExistingPolicyDetails = new List<ParticipantExistingPolicyDetail>();
        }
    }
}
