﻿using System;
using System.Collections.Generic;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using CMS.DataAccess.Auditing;

namespace CMS.Model.Entities
{
    public class WholesalerRegion : Entity
    {
        public virtual string RegionName { get; set; }
        public virtual Wholesaler ExternalWholesaler { get; set; }
        public virtual Wholesaler InternalWholesaler { get; set; }

        public WholesalerRegion()
        {
            ExternalWholesaler = new Wholesaler();
            InternalWholesaler = new Wholesaler();
        }
    }
}
