﻿using CMS.DataAccess.Auditing;
using CMS.Model.Attributes;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class EnrollmentParticipant : Entity
    {
        public virtual Enrollment Enrollment { get; set; }
        public virtual Participant Participant { get; set; }
        public virtual IList<EnrollmentParticipantOptionPlan> EnrollmentParticipantOptionPlans { get; set; }
        public virtual EnrollmentParticipantStatusTypeEnum? BasePlanEnrollmentParticipantStatusType { get; set; }
        public virtual EnrollmentParticipantStatusTypeEnum? VGSIPlanEnrollmentParticipantStatusType { get; set; }
        public virtual IList<EnrollmentParticipantPolicy> Policies { get; set; }
        public virtual EnrollmentPDRClassOption SelectedEnrollmentPDRClassOption { get; set; }
        public virtual CaseDocument Announcement { get; set; }
        public virtual DateTime? AnnouncementApproved { get; set; }
        public virtual string AnnouncementStatus { get; set; }
        public virtual CaseDocument Kit { get; set; }
        public virtual DateTime? KitApproved { get; set; }
        public virtual string KitStatus { get; set; }
        public virtual CaseDocument Sweep { get; set; }
        public virtual DateTime? SweepApproved { get; set; }
        public virtual string SweepStatus { get; set; }
        public virtual CaseDocument Other { get; set; }
        public virtual string OnlineEnrollmentPassword { get; set; }
        public virtual bool? IsSmoker { get; set; }
        public virtual string SocialSecurityNumber { get; set; }
        public virtual DateTime? ApplicationSignedDate { get; set; }
        public virtual string BillingCycle { get; set; }
        public virtual bool? IsHEXCLCreatedOnline { get; set; }
        public virtual bool? IsActivelyWorking { get; set; }
        public virtual bool? IsCurrentlyDisabled { get; set; }
        public virtual bool? IsUsCitizen { get; set; }
        public virtual string VisaType { get; set; }
        public virtual string VisaDuration { get; set; }
        public virtual string CATa { get; set; }
        public virtual string CATb { get; set; }
        public virtual string CATc { get; set; }
        public virtual string CATd { get; set; }
        public virtual string CATe { get; set; }
        public virtual bool? SLPQuestion { get; set; }
        public virtual bool? SISQuestion { get; set; }
        public virtual bool? IsNegativeEnrollmentProcessed { get; set; }
        public virtual string IneligibleReason { get; set; }

        public virtual bool? IsValidOSE { get; set; }
        public virtual MldeUploadStatusTypeEnum? MldeUploadStatusType { get; set; }
        public virtual MldeUploadStatusType MldeUploadStatusTypeEntity { get; set; }
        public virtual string IneligibleReasonForMLDE { get; set; }
        public virtual DateTime? DateTimeSentToMLDE { get; set; }
        public virtual bool MLDEParticipantDirtyDataIndicator { get; set; }
        public virtual string OtherStatus { get; set; }
        [Audit(DisplayName = "MldeStatusType")]
        public virtual MldeStatusTypeEnum? MldeStatusType { get; set; }
        public virtual MldeStatusType MldeStatusTypeEntity { get; set; }
        public virtual DateTime? MldeStatusDate { get; set; }
        public virtual bool? IsValidDirectCoverage { get; set; }

        [NotPersisted]
        public virtual string DirectCoverageStatus { get; set; }

        [NotPersisted]
        public virtual string OneStepStatus { get; set; }

        public virtual IList<BridgelineAdditionalLTDCoverage> BridgelineAdditionalLTDCoverage { get; set; }

        public EnrollmentParticipant()
        {
            BridgelineAdditionalLTDCoverage = new List<BridgelineAdditionalLTDCoverage>();
            Policies = new List<EnrollmentParticipantPolicy>();
        }
    }
}
