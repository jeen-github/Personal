﻿using CMS.Model.BaseEntities;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class EligibilityConfiguration : Entity
    {
        public virtual Case Case { get; set; }
        public virtual PlanDesignRequest PlanDesignRequest { get; set; }
        public virtual PlanDesignRequestClass PlanDesignRequestClass { get; set; }
        public virtual int? MinimumAge { get; set; }
        public virtual int? MaximumAge { get; set; }
        public virtual decimal? MaximumGSIAmount { get; set; }
        public virtual decimal? MinimumInsurableIncomeAmount { get; set; }
        public virtual decimal? EmployerPaidMinimumInsurableIncomeAmount { get; set; } 
        public virtual int? IncreaseDuetoAge { get; set; }   
        public virtual int? RPPMaximumIndemnityAmount { get; set; }
        public virtual int? RPPMaximumIndemnityAmountUnderAge49 { get; set; }
        public virtual int? CATLimitAmount { get; set; }
        public virtual int? MaximumSolicitation { get; set; }
        public virtual decimal? IssueLimitMaximum { get; set; }
        public virtual decimal? ParticipationLimit { get; set;}
        public virtual decimal? MinimumBenefitAmount { get; set; }
        public virtual int? StandAloneRPPMaximumAge { get; set; }
        public virtual decimal? CAIssueLimitMaximum { get; set; }
        public virtual decimal? CAParticipationLimit { get; set; }
        public virtual int? FullTimeDefinitionType_Id { get; set; }
        public virtual IList<EligibilityConfigurationbyState> EligibilityConfigurationbyStates { get; set; }
        public EligibilityConfiguration()
        {
            EligibilityConfigurationbyStates = new List<EligibilityConfigurationbyState>();
        }
    }
}
