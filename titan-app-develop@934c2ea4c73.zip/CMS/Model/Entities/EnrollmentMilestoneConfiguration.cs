﻿using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
    public class EnrollmentMilestoneConfiguration : Entity
    {
        public virtual string MilestoneName { get; set; }
        public virtual EnrollmentMethodType EnrollmentMethodType { get; set; }
        public virtual bool IsAddOnIndicator { get; set; }
        public virtual int SortOrder { get; set; }
        public virtual IList<EnrollmentMilestoneTaskConfiguration> EnrollmentMilestoneTaskConfigurations { get; set; }
        public EnrollmentMilestoneConfiguration()
        {
            EnrollmentMilestoneTaskConfigurations = new List<EnrollmentMilestoneTaskConfiguration>();
        }
    }
}
