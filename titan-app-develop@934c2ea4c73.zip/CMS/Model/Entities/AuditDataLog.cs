﻿using CMS.Model.BaseEntities;
using System;

namespace CMS.Model.Entities
{
    public class AuditDataLog : Entity
    {
        public virtual DateTime RecordedDate { get; set; }             
        public virtual string EntityTypeName { get; set; }        
        public virtual Case Case { get; set; }
        public virtual string PropertyName { get; set; }

    }
}
