﻿using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;
using System;
using CMS.Model.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.DataAccess.Auditing;

namespace CMS.Model.Entities
{
    public class PlanDesignRequestClassProduct : Entity
    {
        public virtual PlanDesignRequestClass PlanDesignRequestClass { get; set; }
        [Audit(DisplayName = "GSI Amount")]
        public virtual int GSIAmount { get; set; }
        [Audit(DisplayName = "PDR Base Discount")]
        public virtual BaseDiscountType BaseDiscountType { get; set; }
        [Audit(DisplayName = "Demographic Discount")]
        public virtual DemographicDiscountType DemographicDiscountType { get; set; }

        [Audit(DisplayName = "Employer Paid Discount")]
        public virtual EmployerPaidDiscountType EmployerPaidDiscountType { get; set; }


        [Audit(DisplayName = "Participation Percentage")]
        public virtual int ParticipationPercentage { get; set; }
        [Audit(DisplayName = "Definition Of Disability")]
        public virtual DefinitionOfDisabilityTypeEnum DefinitionOfDisabilityType { get; set; }
        [Audit(DisplayName = "Mental Substance Limitation")]
        public virtual MentalSubstanceLimitationEnum MentalSubstanceLimitationType { get; set; }
        [Audit(DisplayName = "Pre-Existing Condition Limitation")]
        public virtual PreExistingConditionLimitTypeEnum PreExistingConditionLimitType { get; set; }
        [Audit(DisplayName = "Elimination Period")]
        public virtual EliminationPeriodTypeEnum? EliminationPeriodType { get; set; }
        [Audit(DisplayName = "Benefit Period")]
        public virtual BenefitPeriodTypeEnum? BenefitPeriodType { get; set; }
        public virtual bool IsGSIPlanIndicator { get; set; }
        public virtual int TotalMaxGSIAmount { get; set; }
        [Audit(DisplayName = "Minimum Case Level GSI Amount")]
        public virtual int? MinimumCaseLevelGSIAmount { get; set; }
        [Audit(DisplayName = "Discount Override")]
        public virtual bool? DiscountOverride { get; set; }
        public override string ToString()
        {
            return IsGSIPlanIndicator == false ? "Primary Plan Approval" : "GSI Buy-Up Plan Approval";
        }
        public virtual bool IsOneStepEnrollmentIndicator { get; set; }
        public virtual bool IsDirectCoverageIndicator { get; set; }
    }
}
