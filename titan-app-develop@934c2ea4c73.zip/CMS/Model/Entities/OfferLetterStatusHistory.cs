﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;

namespace CMS.Model.Entities
{
    public class OfferLetterStatusHistory : Entity
    {
        public virtual OfferLetter OfferLetter { get; set; }
        public virtual OfferLetterStatusTypeEnum OfferLetterStatusType { get; set; }
        public virtual DateTime DateOfChange { get; set; }
        public virtual string ApprovedByUser { get; set; }
        public virtual string TitanUser { get; set; }

        public OfferLetterStatusHistory()
        {
            OfferLetter = new OfferLetter();
        }
    }
}
