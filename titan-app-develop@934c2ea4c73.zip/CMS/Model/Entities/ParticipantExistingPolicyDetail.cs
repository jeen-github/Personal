﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class ParticipantExistingPolicyDetail : Entity
    {
        public virtual ParticipantExistingPolicy ParticipantExistingPolicy { get; set; }
        public virtual string PolicyNumber { get; set; }
        public virtual string Product { get; set; }
        public virtual string PlanCode { get; set; }
        public virtual decimal? MonthlyIndemnity { get; set; }
        public virtual string CLOASPolicyStatus { get; set; }
        public virtual string CLOASRejectionType { get; set; }
        public virtual string CaseNumber { get; set; }
        public virtual string PremiumPayer { get; set; }
        public virtual DateTime? PolicyEffectiveDate { get; set; }
        public virtual decimal? AnnualizedPremium { get; set; }
        public virtual decimal? ModalPremium { get; set; }
        public virtual string BillingModeTypeDescription { get; set; }
        public virtual string RiskClassTobaccoStatus { get; set; }
        public virtual string OccupationClassDescription { get; set; }
        public virtual decimal? Discount { get; set; }
        public virtual string EliminationPeriodDescription { get; set; }
        public virtual string BenefitPeriodDescription { get; set; }
        public virtual string ContractStateDescription { get; set; }
        public virtual string ResidentStateDescription { get; set; }
        public virtual string DefinitionOfTotalDisabilityType { get; set; }
        public virtual decimal? AMBAmount { get; set; }
        public virtual string MentalSubstanceLimitationType { get; set; }
        public virtual string PreExistingConditionLimitationType { get; set; }
        public virtual bool? IsPolicyMatch { get; set; }
        public virtual string TitanPriorCoverageSearchGrouping { get; set; }
        public virtual IList<ParticipantExistingPolicyRider> ParticipantExistingPolicyRiders { get; set; }
        public virtual bool IsTerminateAndReplace { get; set; }
        public virtual bool? IsCompactState { get; set; }
        public ParticipantExistingPolicyDetail()
        {
            ParticipantExistingPolicyRiders = new List<ParticipantExistingPolicyRider>();
        }
    }
}
