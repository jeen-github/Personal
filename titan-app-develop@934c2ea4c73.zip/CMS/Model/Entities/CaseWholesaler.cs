﻿using System;
using System.Collections.Generic;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using CMS.DataAccess.Auditing;

namespace CMS.Model.Entities
{
    public class CaseWholesaler : Entity
    {
        public virtual Case Case { get; set; }
        public virtual WholesalerRegion WholesalerRegion { get; set; }
        public virtual Wholesaler InternalWholesaler { get; set; }
        public virtual Wholesaler ExternalWholesaler { get; set; }
        public virtual bool IsPrimaryIndicator { get; set; }
        public virtual int? WholesalerPercent { get; set; }
    }
}
