﻿using CMS.Model.BaseEntities;
using System.ComponentModel;
namespace CMS.Model.Entities
{
    [Description("Wholesaler Type")]
    public class WholesalerType : LookupEntity
    {
    }
}
