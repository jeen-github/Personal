﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;


namespace CMS.Model.Entities
{
    public class StandardOfferCodeConfiguration : Entity
    {
        public virtual PlanDesignTypeEnum PlanDesignType { get; set; }
        public virtual ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum PremiumPayerAndTaxabilityType { get; set; }
        public virtual string XMLOfferTypeNonSmoker { get; set; }
        public virtual string XMLOfferTypeSmoker { get; set; }
        public virtual PlanDesignGSITypeEnum? VGSIPlanDesignType { get; set; }
    }
}
