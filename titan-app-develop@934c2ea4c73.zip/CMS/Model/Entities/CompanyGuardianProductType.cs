﻿using CMS.Model.BaseEntities;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    [Description("Company Guardian Product")]
    public class CompanyGuardianProductType : LookupEntity
    {
    }
}
