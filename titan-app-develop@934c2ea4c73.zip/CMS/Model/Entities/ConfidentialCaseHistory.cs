﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;

namespace CMS.Model.Entities
{
    public class ConfidentialCaseHistory : Entity
    { 
        public virtual Case Case { get; set; }
        public virtual CmsUser LdapUser { get; set; }
        public virtual DateTime LastAccessedDateTime { get; set; }
    }
}
