﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class BridgelineAdditionalLTDCoverage : Entity
    {
        public virtual EnrollmentParticipant EnrollmentParticipant { get; set; }
        public virtual string CarrierName { get; set; }
        public virtual string ReceivedCarrierName { get; set; }
        public virtual string CoverageCategory { get; set; }
        public virtual string CoverageSource { get; set; }
        public virtual string CoverageStatus { get; set; }
        public virtual decimal? SalaryMonthlyBenefit { get; set; }
        public virtual bool? IsTaxableIncome { get; set; }
        public virtual bool? SalaryOnlyCoverage { get; set; }
        public virtual bool? UserSelectedReplacement { get; set; }
        public virtual decimal? UserSelectedAmountOfReplacement { get; set; }
        public virtual string EmployerPaysPremiums { get; set; }
        public virtual string FLReplacementPolicyNumber { get; set; }
        public virtual string FLReplacementCarrierAddress { get; set; }
        public virtual string COReplacementReason { get; set; }
        public virtual string COReplacementReasonComments { get; set; }
        public virtual bool? IsReplacementCoverage { get; set; }
        public virtual BridgelineCoverageStatusTypeEnum? BridgelineCoverageStatusType { get; set; }
    }
}
