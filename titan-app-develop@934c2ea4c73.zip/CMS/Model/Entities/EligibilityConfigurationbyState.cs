﻿using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Model.Entities
{
    public class EligibilityConfigurationbyState : Entity
    {
        public virtual EligibilityConfiguration EligibilityConfiguration { get; set; }
        public virtual StateTypeEnum StateType { get; set; }
        public virtual BenefitPeriodTypeEnum? BenefitPeriodType { get; set; }
        public virtual int? MaximumAge { get; set; }
    }
}
