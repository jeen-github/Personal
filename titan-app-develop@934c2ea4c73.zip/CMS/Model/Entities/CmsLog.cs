﻿using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
    public class CmsLog : Entity
    {
        public virtual DateTime LogDate { get; set; }
        public virtual string LogLevel { get; set; }
        public virtual string Application { get; set; }
        public virtual string Message { get; set; }
        public virtual string Exception { get; set; }
        public virtual string StackTrace { get; set; }
        public virtual string Logger { get; set; }
        public virtual string CaseId { get; set; }
        public virtual string PdrId { get; set; }
        public virtual int WorkUnitId { get; set; }

    }
}
