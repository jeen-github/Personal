﻿using CMS.DataAccess.Auditing;
using CMS.Model.Attributes;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class Participant : Entity
    {
        [Audit(DisplayName = "Participant Identifier")]
        public virtual string EmployeeId { get; set; }
        public virtual string ClientReferenceNumber { get; set; }
        public virtual Census Census { get; set; }
        public virtual PlanDesignRequestClass PlanDesignRequestClass { get; set; }
        public virtual string PlanDesignRequestClassEligiblePopulationText { get; set; }
        [Audit(DisplayName = "First Name")]
        public virtual string FirstName { get; set; }
        [Audit(DisplayName = "Last Name")]
        public virtual string LastName { get; set; }
        [Audit(DisplayName = "Middle Initial")]
        public virtual string MiddleInitial { get; set; }
        [Audit(DisplayName = "Suffix")]
        public virtual string Suffix { get; set; }
        public virtual string HomeStreet1 { get; set; }
        public virtual string HomeStreet2 { get; set; }
        public virtual string HomeCity { get; set; }
        public virtual StateTypeEnum? HomeState { get; set; }
        public virtual string HomeStateDescription { get; set; }
        public virtual string HomeZipCode { get; set; }
        public virtual string PersonalEmail { get; set; }
        public virtual string CellPhone { get; set; }
        public virtual string HomePhone { get; set; }
        public virtual string WorkStreet1 { get; set; }
        public virtual string WorkStreet2 { get; set; }
        public virtual string WorkCity { get; set; }
        public virtual string WorkStateDescription { get; set; }
        public virtual string WorkZipCode { get; set; }
        public virtual string WorkStopCode { get; set; }
        public virtual string WorkLocationPhone { get; set; }
        [Audit(DisplayName = "Age")]
        public virtual int? Age { get; set; }
        public virtual string WorkLocationExtension { get; set; }
        public virtual string WorkEmail { get; set; }
        [Audit(DisplayName = "Date Of Hire")]
        public virtual DateTime? DateOfHire { get; set; }
        [Audit(DisplayName = "Date Of Birth")]
        public virtual DateTime? DateOfBirth { get; set; }
        [Audit(DisplayName = "Gender")]
        public virtual string Gender { get; set; }
        public virtual int? HoursPerWeek_Id { get; set; }
        public virtual decimal? CurrentSalaryAmount { get; set; }
        public virtual decimal? MostRecentPaidBonusAmount { get; set; }
        public virtual string HoursPerWeekDescription { get; set; }
        public virtual string JobTitle { get; set; }
        public virtual string BoardCertification { get; set; }
        public virtual int? MostRecentPaidBonusYear { get; set; }
        public virtual decimal? PriorPaidBonusAmount { get; set; }
        public virtual int? PriorPaidBonusYear { get; set; }
        public virtual decimal? AdditionalPriorPaidBonusAmount { get; set; }
        public virtual int? AdditionalPriorPaidBonusYear { get; set; }
        public virtual decimal? MostRecentPaidCommissionAmount { get; set; }
        public virtual int? MostRecentPaidCommissionYear { get; set; }
        public virtual decimal? PriorPaidCommissionAmount { get; set; }
        public virtual int? PriorPaidCommissionYear { get; set; }
        public virtual decimal? AdditionalPriorPaidCommissionAmount { get; set; }
        public virtual int? AdditionalPriorPaidCommissionYear { get; set; }
        public virtual decimal? MostRecentPaidK1IncomeAmount { get; set; }
        public virtual int? MostRecentPaidK1IncomeYear { get; set; }
        public virtual decimal? PriorPaidK1IncomeAmount { get; set; }
        public virtual int? PriorPaidK1IncomeYear { get; set; }
        public virtual decimal? AdditionalPriorPaidK1IncomeAmount { get; set; }
        public virtual int? AdditionalPriorPaidK1IncomeYear { get; set; }
        public virtual decimal? OtherIncomeAmount { get; set; }
        public virtual string TypeOfIncome { get; set; }
        public virtual decimal? TotalEmployerOrEmployeeRetirementContributionAmount { get; set; }
        public virtual string EligibleClass { get; set; }
        public virtual int? GroupLTDClass { get; set; }
        public virtual string IDICarrier1Description { get; set; }
        public virtual IDICoverageCarrierTypeEnum? IDICarrier1 { get; set; }
        public virtual decimal? IDIBenefitAmount1 { get; set; }
        public virtual bool? IDIToBeReplaced1 { get; set; }
        public virtual decimal? IDIToBeReplacedAmount1 { get; set; }
        public virtual string IDIPolicyNumber1 { get; set; }
        public virtual string IDICarrier2Description { get; set; }
        public virtual IDICoverageCarrierTypeEnum? IDICarrier2 { get; set; }
        public virtual decimal? IDIBenefitAmount2 { get; set; }
        public virtual bool? IDIToBeReplaced2 { get; set; }
        public virtual decimal? IDIToBeReplacedAmount2 { get; set; }
        public virtual string IDIPolicyNumber2 { get; set; }
        public virtual string IDICarrier3Description { get; set; }
        public virtual IDICoverageCarrierTypeEnum? IDICarrier3 { get; set; }
        public virtual decimal? IDIBenefitAmount3 { get; set; }
        public virtual bool? IDIToBeReplaced3 { get; set; }
        public virtual decimal? IDIToBeReplacedAmount3 { get; set; }
        public virtual string IDIPolicyNumber3 { get; set; }
        public virtual string IDICarrier4Description { get; set; }
        public virtual IDICoverageCarrierTypeEnum? IDICarrier4 { get; set; }
        public virtual decimal? IDIBenefitAmount4 { get; set; }
        public virtual bool? IDIToBeReplaced4 { get; set; }
        public virtual decimal? IDIToBeReplacedAmount4 { get; set; }
        public virtual string IDIPolicyNumber4 { get; set; }
        public virtual BenefitDeductionFrequencyTypeEnum? BenefitDeductionFrequency { get; set; }
        public virtual string BenefitDeductionFrequencyDescription { get; set; }
        public virtual string Occupation { get; set; }
        public virtual string CLOASOccupationCode { get; set; }
        public virtual int? OccupationClass_Id { get; set; }
        public virtual string OccupationClassDescription { get; set; }
        public virtual decimal? CurrentYearSalaryAmount { get; set; }
        public virtual bool? IsError { get; set; }
        public virtual string ErrorReason { get; set; }
        
        [Audit(DisplayName = "IsEligible")]
        public virtual bool? IsEligible { get; set; }
        public virtual bool IsMicrositeAccess { get; set; } = false;
        
        [Audit(DisplayName = "InEligibleReason_Id")]
        public virtual int? InEligibleReason_Id { get; set; }
        
        [Audit(DisplayName = "IneligibleReason")]
        public virtual string IneligibleReason { get; set; }
        public virtual string OtherReason { get; set; }
        public virtual StateTypeEnum? WorkState { get; set; }
        public virtual decimal? LTDAmount { get; set; }
        public virtual int? MostRecentSalaryYear { get; set; }
        public virtual decimal? MostRecentSalaryAmount { get; set; }
        public virtual string MailStopCode { get; set; }
        public virtual bool? DoNotSolicit { get; set; }
        public virtual bool? DeclineNegativeIncrease { get; set; }
        public virtual decimal? EligibleGSIAmount { get; set; }
        public virtual EmploymentStatusTypeEnum? EmploymentStatusType { get; set; }
        public virtual string EmploymentStatusDescription { get; set; }
        public virtual string EmploymentStatus { get; set; }
        public virtual decimal? WeeklyHoursWorked { get; set; }
        public virtual int? FrequencyClass_Id { get; set; }
        public virtual string FrequencyClassDescription { get; set; }
        public virtual string OtherDisabilityInformation { get; set; }
        public virtual bool? IsOwnerIndicator { get; set; }
        public virtual decimal? LTDInsurableIncomeCalculatedAmount { get; set; }
        public virtual decimal? IDIInsurableIncomeCalculatedAmount { get; set; }
        public virtual decimal? IDIReplacementCalculatedPercent { get; set; }
        public virtual decimal? LTDCalculatedAmount { get; set; }
        public virtual decimal? OtherExistingIDICoverageTotalCalculatedAmount { get; set; }
        public virtual decimal? GuardianExistingIDICoverageTotalCalculatedAmount { get; set; }
        public virtual decimal? TotalEmployerOrEmployeeRetirementContributionCalculatedAmount { get; set; }
        public virtual decimal? VoluntaryGSIBuyUpCalculatedAmount { get; set; }
        public virtual decimal? IDIBaseSalaryCalculatedAmount { get; set; }
        public virtual decimal? IDIBonusIncomeCalculatedAmount { get; set; }
        public virtual decimal? IDICommissionsIncomeCalculatedAmount { get; set; }
        public virtual decimal? IDIK1IncomeCalculatedAmount { get; set; }
        public virtual decimal? GLTDBenefitCalculatedAmount { get; set; }
        public virtual decimal? GLTDReplacementCalculatedPercentage { get; set; }
        public virtual decimal? ExistingIDICalculatedAmount { get; set; }
        public virtual decimal? GSIBaseCalculatedAmount { get; set; }
        public virtual decimal? IDIBaseReplacementCalculatedPercentage { get; set; }
        public virtual decimal? TotalGLTDPlusIDICalculatedAmount { get; set; }
        public virtual decimal? TotalGLTDPlusIDICalculatedPercentage { get; set; }
        public virtual decimal? CATCalculatedAmount { get; set; }
        public virtual decimal? RPPBenefitCalculatedAmount { get; set; }
        public virtual decimal? CoveragePossibleBeforeIandPMaximums { get; set; }
        public virtual decimal? ParticipationLimitMaximum { get; set; }
        public virtual decimal? IssueLimitMaximum { get; set; }
        public virtual StateTypeEnum? ContractState { get; set; }
        public virtual string ContractStateDescription { get; set; }
        public virtual string CaseCompanyLocationName { get; set; }
        public virtual decimal? CustomLTDInsurableIncomeBaseSalaryPercentage { get; set; }
        public virtual decimal? CustomLTDInsurableIncomeBonusPercentage { get; set; }
        public virtual decimal? CustomLTDInsurableIncomeCommissionPercentage { get; set; }
        public virtual decimal? CustomLTDInsurableIncomeOtherIncomePercentage { get; set; }
        public virtual DateTime? TerminationDate { get; set; }
        public virtual int? FrequencyClass { get; set; }
        public virtual int? PremiumPayerId1 { get; set; }
        public virtual int? PremiumPayerId2 { get; set; }
        public virtual int? PremiumPayerId3 { get; set; }
        public virtual int? PremiumPayerId4 { get; set; }
        public virtual decimal? ReplacementPercent1 { get; set; }
        public virtual decimal? ReplacementPercent2 { get; set; }
        public virtual decimal? ReplacementPercent3 { get; set; }
        public virtual decimal? ReplacementPercent4 { get; set; }
        public virtual decimal? EligibleCATCalculatedAmount { get; set; }
        public virtual decimal? VGSIBuyUpIDIInsurableIncomeCalculatedAmount { get; set; }
        public virtual decimal? IDIOtherIncomeCalculatedAmount { get; set; }
        public virtual decimal? MostRecentYearPaidW2Income { get; set; }
        public virtual string AdditionalInfo1 { get; set; }
        public virtual string AdditionalInfo2 { get; set; }
        public virtual decimal? VGSIBuyUpCoveragePossibleBeforeIandPMaximums { get; set; }
        public virtual decimal? VGSIParticipationLimitMaximum { get; set; }
        public virtual decimal? VGSIBuyUpBenefit { get; set; }
        public virtual ListBillGroup ListBillGroup { get; set; }
        public virtual string BillingGroupName { get; set; }
        public virtual ListBillNumber ListBillNumber { get; set; }
        public virtual string BillNumber { get; set; }
        public virtual int? IssueAge { get; set; }
        public virtual int? BasePlanPreviousSolicitations { get; set; }
        public virtual int? VGSIPlanPreviousSolicitations { get; set; }
        public virtual bool? EnrollmentOption1IsEligible { get; set; }
        public virtual bool? EnrollmentOption2IsEligible { get; set; }
        public virtual bool? EnrollmentOption3IsEligible { get; set; }
        public virtual string EnrollmentOption1InEligibilityReason { get; set; }
        public virtual string EnrollmentOption2InEligibilityReason { get; set; }
        public virtual string EnrollmentOption3InEligibilityReason { get; set; }
        public virtual decimal? ManualBenefitAmount { get; set; }
        public virtual string BusinessPremiumValidationSummary { get; set; }
        public virtual bool? IsPushtoNewProviderChoicePolicyIndicator { get; set; }
        public virtual bool? IsBuyUpPushtoNewProviderChoicePolicyIndicator { get; set; }
        
        public virtual bool IsIDICoverageReplacedWithPriorCoverage { get; set; }
        public virtual bool? IsSpecialHandlingRequired { get; set; }
        public virtual string SpecialHandlingComments { get; set; }
        public virtual decimal? ManualVGSIBuyUpBenefitAmount { get; set; }
        public virtual bool? IsAMBIncreaseIndicator { get; set; }
        public virtual bool? IsBuyUpAMBIncreaseIndicator { get; set; }
        public virtual ParticipantCategoryCodeTypeEnum? ParticipantCategoryCodeType { get; set; }
        public virtual string ParticipantCategoryCodeDescription { get; set; }
        public virtual ParticipantCategoryCodeTypeEnum? BuyUpParticipantCategoryCodeType { get; set; }
        public virtual string BuyUpParticipantCategoryCodeDescription { get; set; }
        public virtual decimal? BaseAMBCalculatedAmount { get; set; }
        public virtual decimal? VGSIBuyUpAMBCalculatedAmount { get; set; }
        public virtual decimal? RPPAMBCalculatedAmount { get; set; }
        public virtual decimal? EEPaidIDIGSIBasePlusAMBInForceAnnualAmount { get; set; }
        public virtual decimal? ERPaidIDIGSIBasePlusAMBInForceAnnualAmount { get; set; }
        public virtual decimal? EEPaidIDIGSIBasePlusAMBInForceModalAmount { get; set; }
        public virtual decimal? ERPaidIDIGSIBasePlusAMBInForceModalAmount { get; set; }
        public virtual decimal? EEPaidRPPGSIBasePlusAMBInForceAnnualAmount { get; set; }
        public virtual decimal? ERPaidRPPGSIBasePlusAMBInForceAnnualAmount { get; set; }
        public virtual decimal? EEPaidRPPGSIBasePlusAMBInForceModalAmount { get; set; }
        public virtual decimal? ERPaidRPPGSIBasePlusAMBInForceModalAmount { get; set; }
        public virtual decimal? GSIPlusAMBTotalBaseBenefitAmount { get; set; }
        public virtual decimal? GSIPlusAMBTotalVGSIBuyUpBenefitAmount { get; set; }
        public virtual decimal? RPPPlusAMBTotalBaseBenefitAmount { get; set; }
        public virtual decimal? TotalVGSIBenefit { get; set; }
        public virtual bool? ManualOverride { get; set; }
        [NotPersisted]
        public virtual decimal? GSIIDIBaseAMB { get; set; }
        [NotPersisted]
        public virtual decimal? FullyUnderwrittenIDI { get; set; }
        public virtual bool? NY194RequestForm { get; set; }
        public virtual string SocialSecurityNumber { get; set; }
        public virtual bool? AAW { get; set; }
        public virtual bool? Citizenship { get; set; }

        [JsonIgnore]
        public virtual IList<EnrollmentParticipant> EnrollmentCensusParticipants { get; set; }

        [JsonIgnore]
        public virtual IList<ParticipantExistingPolicy> ParticipantExistingPolicies { get; set; }
        public virtual bool? IDIToBeIgnore1 { get; set; }
        public virtual bool? IDIToBeIgnore2 { get; set; }
        public virtual bool? IDIToBeIgnore3 { get; set; }
        public virtual bool? IDIToBeIgnore4 { get; set; }
        public virtual decimal? ManualRPPAmount { get; set; }
        public virtual decimal? ManualBenefitAMBIncreaseAmount { get; set; }
        public virtual decimal? ManualRPPAMBIncreaseAmount { get; set; }
        public virtual decimal? ManualVGSIBuyUpAMBIncreaseAmount { get; set; }
        [NotPersisted]
        public virtual decimal OtherIDICoverage { get; set; }

        private bool _isActive = true;
        public virtual bool IsActive
        {
            get { return _isActive; }
            set { _isActive = value; }
        }

        [NotPersisted]
        public virtual bool? HasSSN { get; set; }

        public Participant()
        {
            PlanDesignRequestClass = new PlanDesignRequestClass();
            EnrollmentCensusParticipants = new List<EnrollmentParticipant>();
            ParticipantExistingPolicies = new List<ParticipantExistingPolicy>();
        }

        public Participant(bool withoutDefaultClassAssignment)
        {            
            EnrollmentCensusParticipants = new List<EnrollmentParticipant>();
        }
    }
}