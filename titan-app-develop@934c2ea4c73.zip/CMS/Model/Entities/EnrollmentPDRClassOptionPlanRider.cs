﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;


namespace CMS.Model.Entities
{
    public class EnrollmentPDRClassOptionPlanRider : Entity
    {
        public virtual EnrollmentPDRClassOptionPlan EnrollmentPDRClassOptionPlan { get; set; }

        [Audit(DisplayName = "Rider Benefit")]
        public virtual BenefitTypeEnum BenefitType { get; set; }

        [Audit(DisplayName = "Rider Benefit Group")]
        public virtual BenefitGroupTypeEnum BenefitGroupType { get; set; }

        [Audit(DisplayName = "Rider Elimination Period")]
        public virtual EliminationPeriodTypeEnum? EliminationPeriodType { get; set; }

        [Audit(DisplayName = "Rider Benefit Period")]
        public virtual BenefitPeriodTypeEnum? BenefitPeriodType { get; set; }

        [Audit(DisplayName = "Rider Approved Amount", Format = "{0:N2}")]
        public virtual decimal? Amount { get; set; }
    }
}
