﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;

namespace CMS.Model.Entities
{
    public class TaskSLAType : Entity
    {
        public virtual int UserGroup_Id { get; set; }
        public virtual string TaskName { get; set; }
        public virtual string TaskDescription { get; set; }
        public virtual string ShortDescription { get; set; }
        public virtual int SLAInHours { get; set; }
        public virtual bool isSameDayResponseRequired { get; set; }
    }
}
