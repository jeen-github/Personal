﻿using System;
using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class BillingSpecialistRegion: Entity
    {
        public virtual string RegionName { get; set; }
        public virtual CmsUser BillingSpecialistUser { get; set; }
        public virtual CmsUser UnderWriterUser { get; set; }
    }
}
