﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class PDRSoldClassPlan : Entity
    {
        public virtual PDRSoldClass PDRSoldClass { get; set; }
        public virtual IList<PDRSoldClassPlanRiders> PDRSoldClassPlanRiders { get; set; }
        public virtual PDRClassPlanTypeEnum PDRClassPlanType { get; set; }

        [Audit(DisplayName = "Plan Design")]
        public virtual PlanDesignTypeEnum? PlanDesignType { get; set; }

        [Audit(DisplayName = "Plan Design Notes")]
        public virtual string PlanDesignNotes { get; set; }

        [Audit(DisplayName = "Base Discount")]
        public virtual BaseDiscountType BaseDiscountType { get; set; }

        [Audit(DisplayName = "Demographic Discount")]
        public virtual DemographicDiscountType DemographicDiscountType { get; set; }


        [Audit(DisplayName = "Employer Paid DiscountType")]
        public virtual EmployerPaidDiscountType EmployerPaidDiscountType { get; set; }



        [Audit(DisplayName = "Benefit Period")]
        public virtual BenefitPeriodTypeEnum? BenefitPeriod { get; set; }

        [Audit(DisplayName = "Benefit Period Notes")]
        public virtual string BenefitPeriodNotes { get; set; }

        [Audit(DisplayName = "Elimination Period")]
        public virtual EliminationPeriodTypeEnum? EliminationPeriod { get; set; }

        [Audit(DisplayName = "Elimination Period Notes")]
        public virtual string EliminationPeriodNotes { get; set; }

        [Audit(DisplayName = "GSI Amount")]
        public virtual int GSIAmount { get; set; }

        [Audit(DisplayName = "Participation Percentage")]
        public virtual int ParticipationPercentage { get; set; }

        [Audit(DisplayName = "Definition Of Disability")]
        public virtual DefinitionOfDisabilityTypeEnum DefinitionOfDisabilityType { get; set; }

        [Audit(DisplayName = "Mental Substance Limitation")]
        public virtual MentalSubstanceLimitationEnum MentalSubstanceLimitationType { get; set; }

        [Audit(DisplayName = "PreExisting Condition Limit")]
        public virtual PreExistingConditionLimitTypeEnum PreExistingConditionLimitType { get; set; }

        [Audit(DisplayName = "LTD Percentage", Format = "{0:N2}")]
        public virtual decimal? LTDPercentage { get; set; }

        [Audit(DisplayName = "LTD Percentage Notes")]
        public virtual string LTDPercentageNotes { get; set; }

        [Audit(DisplayName = "IDI Percentage", Format = "{0:N2}")]
        public virtual decimal? IDIPercentage { get; set; }

        [Audit(DisplayName = "IDI Percentage Notes")]
        public virtual string IDIPercentageNotes { get; set; }

        [Audit(DisplayName = "Premium Payer And Taxability")]
        public virtual ExistingCoveragePremiumAndTaxpayerLiabilityType PremiumPayerAndTaxabilityType { get; set; }

        [Audit(DisplayName = "Premium Payer And Taxability Notes")]
        public virtual string PremiumPayerAndTaxabilityNotes { get; set; }

        [Audit(DisplayName = "Maximum Replacement Ratio", Format = "{0:N2}")]
        public virtual decimal? MaximumReplacementRatio { get; set; }

        [Audit(DisplayName = "Maximum Replacement Ratio Notes")]
        public virtual string MaximumReplacementRatioNotes { get; set; }

        [Audit(DisplayName = "LTD Covers Next", Format = "{0:N2}")]
        public virtual decimal? LTDCoversNext { get; set; }

        [Audit(DisplayName = "LTD Covers Next Notes")]
        public virtual string LTDCoversNextNotes { get; set; }

        [Audit(DisplayName = "IDI Covers 1st", Format = "{0:N2}")]
        public virtual decimal? IDICovers1st { get; set; }

        [Audit(DisplayName = "IDI Covers 1st Notes")]
        public virtual string IDICovers1stNotes { get; set; }

        [Audit(DisplayName = "Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? CoveredEarningsType { get; set; }

        [Audit(DisplayName = "Covered Earnings Notes")]
        public virtual string CoveredEarningsTypeNotes { get; set; }

        [Audit(DisplayName = "Flat Rate")]
        public virtual FlatRateType FlatRateType { get; set; }

        [Audit(DisplayName = "Flat Rate Other")]
        public virtual int? FlatRate_Other { get; set; }

        [Audit(DisplayName = "Retirement Contributions")]
        public virtual RetirementContributionsTypeEnum? RetirementContributionsType { get; set; }

        [Audit(DisplayName = "Retirement Contributions Notes")]
        public virtual string RetirementContributionsNotes { get; set; }

        [Audit(DisplayName = "Annual Contributions", Format = "{0:N2}")]
        public virtual decimal? AnnualContributions { get; set; }

        [Audit(DisplayName = "Annual Contributions Notes")]
        public virtual string AnnualContributionsNotes { get; set; }

        [Audit(DisplayName = "Covered Earnings Percentage", Format = "{0:N2}")]
        public virtual decimal? CoveredEarningsPercentage { get; set; }

        [Audit(DisplayName = "Covered Earnings Percentage Notes")]
        public virtual string CoveredEarningsPercentageNotes { get; set; }

        [Audit(DisplayName = "RPP Rider Covered Earnings")]
        public virtual CoveredEarningsTypeEnum? RppRiderCoveredEarningsType { get; set; }

        [Audit(DisplayName = "Rpp Rider Covered Earnings Notes")]
        public virtual string RppRiderCoveredEarningsTypeNotes { get; set; }

        [Audit(DisplayName = "Rpp Rider Covered Earnings Other")]
        public virtual string RppRiderCoveredEarningsTypeOther { get; set; }

        [Audit(DisplayName = "Taxability")]
        public virtual TaxabilityTypeEnum? TaxabilityType { get; set; }

        [Audit(DisplayName = "Taxability Notes")]
        public virtual string TaxabilityTypeNotes { get; set; }

        [Audit(DisplayName = "Covered Earnings Bonus Only")]
        public virtual CoveredEarningsBonusOnlyTypeEnum? CoveredEarningsBonusOnlyType { get; set; }

        [Audit(DisplayName = "Type Of Share")]
        public virtual TypeOfShareTypeEnum? TypeOfShareType { get; set; }

        [Audit(DisplayName = "Employer Paid Premium", Format = "{0:N2}")]
        public virtual decimal? EmployerPaidPremium { get; set; }

        [Audit(DisplayName = "Employer Paid Premium Notes")]
        public virtual string EmployerPaidPremiumNotes { get; set; }

        [Audit(DisplayName = "Employee Paid Premium", Format = "{0:N2}")]
        public virtual decimal? EmployeePaidPremium { get; set; }

        [Audit(DisplayName = "Employer Pays Upto", Format = "{0:N2}")]
        public virtual decimal? EmployerPaysupto { get; set; }

        [Audit(DisplayName = "Employer Pays Upto Notes")]
        public virtual string EmployerPaysuptoNotes { get; set; }

        [Audit(DisplayName = "Cost Share Taxability")]
        public virtual CostShareTaxabilityType CostShareTaxabilityType { get; set; }

        [Audit(DisplayName = "Replacement Percentage", Format = "{0:N2}")]
        public virtual decimal? ReplacementPercentage { get; set; }

        [Audit(DisplayName = "GSI Buy Up Plan Notes")]
        public virtual string GSIBuyUpPlanNotes { get; set; }

        [Audit(DisplayName = "GSI BuyUp Plan Design Notes")]
        public virtual string GSIBuyUpPlanDesignNotes { get; set; }

        [Audit(DisplayName = "GSI BuyUp Covered Earnings Notes")]
        public virtual string GSIBuyUpCoveredEarningsTypeNotes { get; set; }

        [Audit(DisplayName = "GSI Buy Up Replacement Percentage Notes")]
        public virtual string GSIBuyUpReplacementPercentageNotes { get; set; }
        public virtual IList<PDRSoldClassPlanCustomizedIDIInsurableIncome> PDRSoldClassPlanCustomizedIDIInsurableIncomes { get; set; }

        [Audit(DisplayName = "Total Max GSI Amount")]
        public virtual int TotalMaxGSIAmount { get; set; }

        [Audit(DisplayName = "Insurable Income Definition")]
        public virtual string InsurableIncomeDefinition { get; set; }

        [Audit(DisplayName = "Minimum Case Level GSI Amount")]
        public virtual int? MinimumCaseLevelGSIAmount { get; set; }

        [Audit(DisplayName = "Discount Override")]
        public virtual bool? DiscountOverride { get; set; }

        [Audit(DisplayName = "IsOneStepEnrollmentIndicator")]
        public virtual bool IsOneStepEnrollmentIndicator { get; set; }

        [Audit(DisplayName = "IsDirectCoverageIndicator")]
        public virtual bool IsDirectCoverageIndicator { get; set; }

        public PDRSoldClassPlan()
        {
            PDRSoldClass = new PDRSoldClass();
            PDRSoldClassPlanRiders = new List<PDRSoldClassPlanRiders>();
            PDRSoldClassPlanCustomizedIDIInsurableIncomes = new List<PDRSoldClassPlanCustomizedIDIInsurableIncome>();
        }
        public override string ToString()
        {
            return PDRClassPlanType != PDRClassPlanTypeEnum.VoluntaryGSIBuyUp ? "Primary Plan Approval" : "GSI Buy-Up Plan Approval";
        }
    }
}
