﻿using CMS.Model.BaseEntities;


namespace CMS.Model.Entities
{
    public class ContactAddressCategory : Entity
    {
        public virtual ContactAddress ContactAddress { get; set; }
        public virtual ContactAddressCategoryType ContactAddressCategoryType { get; set; }
        public virtual bool IsSelect { get; set; }
        public virtual bool IsPrimary { get; set; }
    }
}
