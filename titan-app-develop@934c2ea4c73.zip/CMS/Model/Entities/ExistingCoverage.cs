﻿using CMS.DataAccess.Auditing;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Model.Entities
{
    public class ExistingCoverage : Entity
    {
        public virtual Case Case { get; set; }

        [Audit(DisplayName = "Existing Coverage Guaranteed Issue Coverage Exists")]
        public virtual bool? IsExistingGuranteedIssueCoverageIndicator { get; set; }

        [Audit(DisplayName = "Existing Coverage Existing Individual Disability Coverage Carrier")]
        public virtual ExistingIndividualDisabilityCoverageType ExistingIndividualDisabilityCoverageType { get; set; }
        [Audit(DisplayName = "Existing Coverage Existing Individual Disability Eligible Population")]
        public virtual string ExistingIndividualDisabilityEligiblePopulation { get; set; }
        [Audit(DisplayName = "Existing Coverage GSI Amount")]
        public virtual decimal? GSIAmount { get; set; }
        [Audit(DisplayName = "Existing Coverage Last Time Enrolled")]
        public virtual int? LastTimeEnrolled { get; set; }
        [Audit(DisplayName = "Existing Coverage Premium Payer")]
        public virtual ExistingIndividualDisabilityPremiumPayerType ExistingIndividualDisabilityPremiumPayerType { get; set; }
        [Audit(DisplayName = "Existing Coverage Reason Out to Market")]
        public virtual ExistingIndividualDisabilityReasonOutMarketType ExistingIndividualDisabilityReasonOutMarketType { get; set; }
        [Audit(DisplayName = "Existing Coverage Reason Out To Market Other Text")]
        public virtual string ReasonOutMarketTypeOther { get; set; }
        [Audit(DisplayName = "Reason Out To Market Other Date")]
        public virtual int? ReasonOutMarketTypeDate { get; set; }
        [Audit(DisplayName = "Existing Coverage Additional Details About Plan Being Replaced")]
        public virtual string ExistingIndividualDisabilityAdditionalDetailsText { get; set; }
        public virtual ColoradoReplacementTypeEnum? ColoradoReplacementType { get; set; }
        public virtual string ColoradoReplacementOther { get; set; }
        public virtual string FloridaReplacementCompanyName { get; set; }
        public virtual string FloridaReplacementCompanyAddressLine1 { get; set; }
        public virtual string FloridaReplacementCompanyAddressLine2 { get; set; }
        public virtual string FloridaReplacementCompanyCity { get; set; }
        public virtual StateTypeEnum? FloridaReplacementCompanyStateType { get; set; }
        public virtual string FloridaReplacementCompanyZipCode { get; set; }
        public virtual bool? EmployerOwned { get; set; }

        public ExistingCoverage()
        {
            Case = new Case();
            ExistingIndividualDisabilityCoverageType = new ExistingIndividualDisabilityCoverageType();
            ExistingIndividualDisabilityPremiumPayerType = new ExistingIndividualDisabilityPremiumPayerType();
            ExistingIndividualDisabilityReasonOutMarketType = new ExistingIndividualDisabilityReasonOutMarketType();
        }
    }
}
