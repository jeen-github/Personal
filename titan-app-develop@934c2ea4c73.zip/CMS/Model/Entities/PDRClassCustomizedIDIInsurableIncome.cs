﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class PDRClassCustomizedIDIInsurableIncome : Entity
    {
        public virtual PlanDesignRequestClass PlanDesignRequestClass { get; set; }
        public virtual decimal? BaseSalaryPercentage { get; set; }
        public virtual decimal? BonusPercentage { get; set; }
        public virtual decimal? CommissionPercentage { get; set; }
        public virtual decimal? OtherIncomePercentage { get; set; }
        public virtual decimal? K1EarningsPercentage { get; set; }
        public virtual int? BonusNumberofYears { get; set; }
        public virtual int? CommissionNumberofYears { get; set; }
        public virtual int? K1EarningsNumberofYears { get; set; }
        public virtual bool IsGSIPlanIndicator { get; set; }
        public override string ToString()
        {
            return IsGSIPlanIndicator == false ? "Primary Plan Approval" : "GSI Buy-Up Plan Approval";
        }
    }
}
