﻿using CMS.Model.BaseEntities;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    [Description("Employer Paid Discount")]
    public class EmployerPaidDiscountType : LookupEntity
    {
    }
}
