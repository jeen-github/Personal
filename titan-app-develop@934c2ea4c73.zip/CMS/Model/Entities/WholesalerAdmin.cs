﻿using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Model.Entities
{
    public class WholesalerAdmin : Entity
    {
        public virtual WholesalerType WholesalerType { get; set; }
        public virtual string LdapUserId { get; set; }
        public virtual string FirstName { get; set; }
        public virtual string LastName { get; set; }
        public virtual string AddressLine1 { get; set; }
        public virtual string AddressLine2 { get; set; }
        public virtual string City { get; set; }
        public virtual StateTypeEnum? StateType { get; set; }
        public virtual string ZipCode { get; set; }
        public virtual string TelephoneNumber { get; set; }
        public virtual string EmailAddress { get; set; }
    }
}
