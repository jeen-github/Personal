﻿using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Model.Entities
{
    public class EnrollmentParticipantOptionPlanRider : Entity
    {
        public virtual EnrollmentParticipantOptionPlan EnrollmentParticipantOptionPlan { get; set; }

        public virtual BenefitTypeEnum BenefitType { get; set; }
        public virtual BenefitGroupTypeEnum BenefitGroupType { get; set; }
        public virtual EliminationPeriodTypeEnum? EliminationPeriodType { get; set; }
        public virtual BenefitPeriodTypeEnum? BenefitPeriodType { get; set; }
        public virtual decimal? BenefitAmountMonthly {get; set;} 
        public virtual decimal? SmokerPremiumAmountMonthly {get; set;} 
        public virtual decimal? SmokerPremiumAmountAnnual {get; set;}
        public virtual decimal? NonSmokerPremiumAmountMonthly {get; set;} 
        public virtual decimal? NonSmokerPremiumAmountAnnual {get; set;}
    }
}