﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;
using System.Collections.Generic;

namespace CMS.Model.Entities
{
    public class OfferLetter : Entity
    {
        public virtual Case Case { get; set; }
        public virtual bool IsReleasedToGA { get; set; }
        public virtual bool IsExternalRequestIndicator { get; set; }
        public virtual string OfferLetterName { get; set; }
        public virtual DateTime? ReleasedDateTime { get; set; }
        public virtual int? Version { get; set; }
        public virtual IList<OfferLetterIllustration> OfferLetterIllustrations { get; set; }
        public virtual CaseDocument OfferLetterPdfDocument { get; set; }
        public virtual CaseDocument OfferLetterWordDocument { get; set; }
        public virtual CaseDocument SignedOfferLetterDocument { get; set; }
        public virtual IList<OfferLetterStatusHistory> OfferLetterStatusHistories { get; set; }
        public virtual DateTime? OfferLetterSignedDate{ get; set; }
        public OfferLetter()
        {
            OfferLetterIllustrations = new List<OfferLetterIllustration>();
            OfferLetterStatusHistories = new List<OfferLetterStatusHistory>();
        }
    }

}
