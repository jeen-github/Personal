﻿using CMS.Model.BaseEntities;
using System.Collections.Generic;
namespace CMS.Model.Entities
{
    public class OfferLetterIllustration : Entity
    {
        public virtual OfferLetter OfferLetter { get; set; }
        public virtual Illustration Illustration { get; set; }
    }
}
