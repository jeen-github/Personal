﻿using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Model.Entities
{
    public class SICCodeOccupationClass : Entity
    {
        public virtual OccupationCode OccupationCode { get; set; }
        public virtual OccupationClassTypeEnum? OccupationClassType { get; set; }
        public virtual CompanySicMajorGroupType CompanySicMajorGroupType { get; set; }
        public virtual CompanySicSubGroupType CompanySicSubGroupType { get; set; }
        public virtual bool IsEligible { get; set; }
    }
}
