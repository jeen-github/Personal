﻿using CMS.Model.BaseEntities;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    [Description("Base Discount")]
    public class BaseDiscountType : LookupEntity
    {
    }
}
