﻿using System;
using CMS.Model.BaseEntities;
using Guardian.Core.Entities.Product.Enums;
using CMS.DataAccess.Auditing;
using CMS.Model.Extensions;

namespace CMS.Model.Entities
{
    public class PDRSoldClassPlanCustomizedIDIInsurableIncome : Entity
    {
        public virtual PDRSoldClassPlan PDRSoldClassPlan { get; set; }

        [Audit(DisplayName = "Customized Base Salary Percentage")]
        public virtual decimal? BaseSalaryPercentage { get; set; }

        [Audit(DisplayName = "Customized Bonus Percentage")]
        public virtual decimal? BonusPercentage { get; set; }

        [Audit(DisplayName = "Customized Commission Percentage")]
        public virtual decimal? CommissionPercentage { get; set; }

        [Audit(DisplayName = "Customized Other Income Percentage")]
        public virtual decimal? OtherIncomePercentage { get; set; }

        [Audit(DisplayName = "Customized K1Earnings Percentage")]
        public virtual decimal? K1EarningsPercentage { get; set; }

        [Audit(DisplayName = "Customized Bonus Number of Years")]
        public virtual int? BonusNumberofYears { get; set; }

        [Audit(DisplayName = "Customized Commission Number of Years")]
        public virtual int? CommissionNumberofYears { get; set; }

        [Audit(DisplayName = "Customized K1Earnings Number of Years")]
        public virtual int? K1EarningsNumberofYears { get; set; }        
    }
}
