﻿using CMS.Model.BaseEntities;
using System;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    public enum StatusEnum
    {
        Active,
        Inactive,
        Deleted
    }

    [Description("Broker Affiliation")]
    public class BrokerAffiliationType : LookupEntity
    {
        public virtual string Status { get; set; }
        public virtual DateTime UpdatedAt { get; set; }
        public virtual string UpdatedBy { get; set; }


    }
}