﻿using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using System;

namespace CMS.Model.Entities
{
    public class AnnualReview : Entity
    {
        public virtual Case Case { get; set; }
        public virtual AnnualReviewStatusTypeEnum? AnnualReviewStatusType { get; set; }
        public virtual DateTime? AnnualReviewDate { get; set; }
        public virtual int? Reviewer_Id { get; set; }
        public virtual DateTime? NextAnniversaryDate { get; set; }
        public virtual int? CalendarYear { get; set; }
        public virtual int? CaseYear { get; set; }
        public virtual Notes Notes { get; set; }
        public virtual WorkUnit AnnualReviewTaskWorkUnit { get; set; }
        public virtual DateTime CreatedDate { get; set; }

    }
}
