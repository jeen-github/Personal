﻿using CMS.Model.BaseEntities;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    [Description("Demographic Discount")]
    public class DemographicDiscountType : LookupEntity
    {
    }
}
