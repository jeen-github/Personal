﻿using CMS.Model.BaseEntities;
using System.ComponentModel;

namespace CMS.Model.Entities
{
    [Description("Existing Coverage Premium and Taxpayer Liability")]
    public class ExistingCoveragePremiumAndTaxpayerLiabilityType : LookupEntity
    {
    }
}
