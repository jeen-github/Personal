﻿using System;
using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class UserGroup : Entity
    {
        public virtual string DisplayName { get; set; }
        public virtual string GroupName { get; set; }
        public virtual bool LdapGroupIndicator { get; set; }
        public virtual DateTime CreatedTime { get; set; }
        public virtual int? SortOrder { get; set; }

        public static readonly int Group_UnderwritingManager = 1;
        public static readonly int Group_Underwriting = 2;
        public static readonly int Group_UnderwritingAnalyst = 3;

        public static readonly int Group_EnrollmentSupervisor = 4;
        public static readonly int Group_EnrollmentManager = 5;
        public static readonly int Group_Implementation_Analyst = 6;

        public static readonly int Group_BillingManager = 7;
        public static readonly int Group_BillingSpecialist = 8;
        public static readonly int Group_PolicyIssueSpecialist = 9;

        public static readonly int Group_QualityManager = 10;
        public static readonly int Group_QualitySpecialist = 11;

        public static readonly int Group_ITAdmin = 12;
        public static readonly int Group_BusinessTechnicalSupport = 13;
        public static readonly int Group_Leadership = 14;

    }
}