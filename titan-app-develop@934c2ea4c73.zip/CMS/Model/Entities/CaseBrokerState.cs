﻿using System;
using System.Collections.Generic;
using CMS.Model.BaseEntities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using CMS.DataAccess.Auditing;

namespace CMS.Model.Entities
{
    public class CaseBrokerState : Entity
    {
        public virtual CaseBroker CaseBroker { get; set; }
        public virtual StateTypeEnum StateType { get; set; }
        public virtual decimal? CommisionPercentage { get; set; }
        public virtual bool? IsLicensedIndicator { get; set; }
        public virtual bool? IsAppointedIndicator { get; set; }
        public virtual DateTime? LicenseVerificationDate { get; set; }
        public virtual string LicenseVerificationMessage { get; set; }
        public virtual bool? IsPrimaryBrokerIndicator { get; set; }
                
        public CaseBrokerState()
        {
            CaseBroker = new CaseBroker();
        }
    }
}
