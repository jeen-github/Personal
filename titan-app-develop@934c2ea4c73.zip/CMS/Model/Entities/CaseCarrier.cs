﻿using CMS.Model.BaseEntities;

namespace CMS.Model.Entities
{
    public class CaseCarrier : Entity
    {
        public virtual Case Case { get; set; }
        public virtual ExistingIndividualDisabilityCoverageType ExistingIndividualDisabilityCoverageType { get; set; }
        public virtual bool IsCompetition { get; set; }
    }
}
