﻿using CMS.Model.BaseEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Model.Entities
{
  public class GACaseSubmission : Entity
    {
        public virtual string TitanCaseNumber { get; set; }
        public virtual string GACaseId { get; set; }
        public virtual string GACaseSubmissionId { get; set; }
        public virtual string MessageType { get; set; }
        public virtual string MessageId { get; set; }
        public virtual string CaseSubmissionName { get; set; }
        public virtual string RegionName { get; set; }
        public virtual string ExternalWholesaler { get; set; }        
        public virtual string InternalWholesaler { get; set; }
        public virtual string Note { get; set; }
        public virtual string EnrollmentType { get; set; }
        public virtual DateTime? ProposedEnrollStartDate { get; set; }
        public virtual DateTime? ProposedEnrollEndDate { get; set; }
        public virtual DateTime? ProposedExtensionEndDate { get; set; }
        public virtual DateTime? ProposedEffectiveDate { get; set; }
        public virtual bool? IsLicenseingCaseUtilizeCorpIndicator { get; set; }
        public virtual bool? IsLicenseingCaseUtilizeIndProdIndicator { get; set; }
        public virtual bool? IsLicenseingCaseUtilizeIndOtherIndicator { get; set; }
        public virtual string CorporationName { get; set; }
        public virtual string CorpWritingCode { get; set; }
        public virtual string SubProducerName { get; set; }
        public virtual string SubProdWritingCode { get; set; }
        public virtual bool? IsWritingCodeInProcessIndicator { get; set; }
        public virtual string AgencyCode { get; set; }
        public virtual string RgoCode { get; set; }
        public virtual string IndividualProducerName { get; set; }
        public virtual string IndividualProducerWritingCode { get; set; }
        public virtual bool? IsIndividualProducerWritingCodeInProcessIndicator { get; set; }
        public virtual string IndividualProducerAgencyCode { get; set; }
        public virtual string IndividualProducerRGOCode { get; set; }
        public virtual string OtherDISpecialistName { get; set; }
        public virtual string OtherDISpecialiastNumber { get; set; }
        public virtual string OtherGroupSaleRepName { get; set; }
        public virtual string OtherGroupSaleRepNumber { get; set; }
        public virtual int? EnrollmentMethodType_Id { get; set; }
        public virtual string ClientName { get; set; }
        public virtual string ClientPhone { get; set; }
        public virtual string ClientEmail { get; set; }
        public virtual string EnrollmentName { get; set; }
        public virtual string EnrollmentPhone { get; set; }
        public virtual string EnrollmentEmail { get; set; }
        public virtual bool? IsEnrollmentKitDeliveryOptionIndicator { get; set; }
        public virtual bool? IsMailDeliveryOptionIndicator { get; set; }
        public virtual string EmailName { get; set; }
        public virtual string EmailAddress { get; set; }
        public virtual string MailName { get; set; }
        public virtual string MailAttention { get; set; }
        public virtual string MailAddress { get; set; }
        public virtual string MailCity { get; set; }
        public virtual string MailState { get; set; }
        public virtual string MailZipCode { get; set; }
        public virtual string MailDeliveryInstruction { get; set; }
        public virtual bool? IsMaterialsContactInformationIndicator { get; set; }
        public virtual DateTime ReceivedDateTime { get; set; }
    }
}
