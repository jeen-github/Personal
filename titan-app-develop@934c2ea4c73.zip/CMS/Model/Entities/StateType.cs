﻿using CMS.Model.BaseEntities;
using System;
using CMS.Model.Enums;

namespace CMS.Model.Entities
{
    public class StateType : Entity
    {       
        public virtual string StateName { get; set; }
        public virtual string StateCode { get; set; }
        public virtual string Description { get; set; }
        public virtual int SortOrder { get; set; }
    }
}
