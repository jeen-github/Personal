﻿using System;

namespace CMS.Model.Attributes
{
    public class CodeAttribute : Attribute
    {
        public string Name { get; set; }

        public CodeAttribute(string name)
        {
            Name = name;
        }
    }
}