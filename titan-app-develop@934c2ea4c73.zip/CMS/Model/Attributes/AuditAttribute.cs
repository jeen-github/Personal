﻿using System;

namespace CMS.DataAccess.Auditing
{
    [AttributeUsage(AttributeTargets.Property)]
    public class AuditAttribute : Attribute
    {
        public string DisplayName { get; set; }
        public string Format { get; set; }
    }
}