﻿using System;

namespace CMS.Model.Attributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class CsvHeaderAttribute : Attribute
    {
        public string Value { get; set; }

        public CsvHeaderAttribute(string value)
        {
            Value = value;
        }
    }
}
