using System;

namespace CMS.DataAccess.Auditing
{
    public class AuditDataLog
    {
        public DateTime RecordedDate { get; set; }
        public int AuditEventType { get; set; }
        public int EntityId { get; set; }
        public string EntityTypeName { get; set; }
        public string EntityDisplayName { get; set; }
        public string PropertyName { get; set; }
        public string PropertyDisplayName { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
        public int? CaseId { get; set; }
        public int? BusinessOperationId { get; set; }
        public int? User_Id { get; set; }
        public Guid? TransactionGuid { get; set; }
        public int? SoldPDRClassId { get; set; }

    }
}