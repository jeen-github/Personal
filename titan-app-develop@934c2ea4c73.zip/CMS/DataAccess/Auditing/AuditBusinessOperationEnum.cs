﻿namespace CMS.DataAccess.Auditing
{
    public enum AuditBusinessOperationEnum
    {
        Company = 1,
        ExistingCoverage = 2,
        Broker = 3,
        PlanDesignRequest = 4,
        Census = 5,
        Enrollment = 6,
        Billing = 7
    }
}