﻿using Common.Utilities;
using System;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace CMS.DataAccess.Auditing
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class AuditActionAttribute : ActionFilterAttribute
    {
        public AuditEventType AuditLevel { get; set; }
        public AuditBusinessOperationEnum AuditBusinessOperation { get; set; }

        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            WebAuditContext.SetAuditEventLevel(AuditLevel);
            WebAuditContext.SetBusinessOperation(AuditBusinessOperation);
            WebAuditContext.SetCaseId(HttpActionContextHelper.GetCaseId(actionContext));
            base.OnActionExecuting(actionContext);
        }

        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            base.OnActionExecuted(actionExecutedContext);
        }
    }
}