﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CMS.DataAccess.Auditing
{
    public class AuditDataPersister
    {
        private readonly string _connectionString;
        private readonly ConcurrentQueue<AuditDataLog> _auditQueue;

        public AuditDataPersister(string connectionString, ConcurrentQueue<AuditDataLog> auditQueue)
        {
            _connectionString = connectionString;
            _auditQueue = auditQueue;         
        }

        public void Start()
        {
            var cancellationTokenSource = new CancellationTokenSource();
            Task.Factory.StartNew((o) => PersistAuditData(), TaskCreationOptions.LongRunning, cancellationTokenSource.Token);
        }

        private void PersistAuditData()
        {
            while (true)
            {
                try
                {
                    var audits = new List<AuditDataLog>();
                    while (!_auditQueue.IsEmpty)
                    {
                        AuditDataLog auditData;
                        if (_auditQueue.TryDequeue(out auditData))
                        {
                            audits.Add(auditData);
                        }
                    }

                    if (audits.Any())
                    {
                        SaveAuditData(audits);
                    }

                    Thread.Sleep(1000);
                }
                catch (Exception e)
                {
                    Debug.WriteLine("Error persistent auditing data {0} {1}", e.Message, e.StackTrace);
                }
            }
        }

        private void SaveAuditData(List<AuditDataLog> audits)
        {
            var bulkInsertDataTable = CreateBulkInsertDataTableStructure();
            foreach (var auditDataLog in audits)
            {
                CreateNewDataRow(auditDataLog, bulkInsertDataTable);
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                var copy = new SqlBulkCopy(connection);
                copy.BulkCopyTimeout = 10000;
                copy.DestinationTableName = "cms.AuditDataLog";

                foreach (DataColumn column in bulkInsertDataTable.Columns)
                {
                    copy.ColumnMappings.Add(column.ColumnName, column.ColumnName);
                }

                connection.Open();
                copy.WriteToServer(bulkInsertDataTable);
            }
        }

        private void CreateNewDataRow(AuditDataLog a, DataTable bulkInsertDataTable)
        {
            var row = bulkInsertDataTable.NewRow();

            row["RecordedDate"] = a.RecordedDate;            
            row["AuditEventType_Id"] = a.AuditEventType;

            row["EntityId"] = a.EntityId;
            row["EntityDisplayName"] = a.EntityDisplayName;
            row["EntityTypeName"] = a.EntityTypeName;

            row["PropertyName"] = a.PropertyName;
            row["PropertyDisplayName"] = a.PropertyDisplayName;

            row["OldValue"] = a.OldValue;
            row["NewValue"] = a.NewValue;

            row["Case_Id"] = a.CaseId;
            row["BusinessOperation_Id"] = a.BusinessOperationId;
            row["User_Id"] = a.User_Id;

            row["TransactionGuid"] = a.TransactionGuid;

            if (a.SoldPDRClassId.HasValue) row["SoldPDRClass_Id"] = a.SoldPDRClassId.Value;

            bulkInsertDataTable.Rows.Add(row);
        }

        private DataTable CreateBulkInsertDataTableStructure()
        {
            var dataTable = new DataTable("cms.AuditDataLog");

            dataTable.Columns.Add(new DataColumn("RecordedDate"));
            dataTable.Columns.Add(new DataColumn("AuditEventType_Id"));            

            dataTable.Columns.Add(new DataColumn("EntityId"));
            dataTable.Columns.Add(new DataColumn("EntityDisplayName"));
            dataTable.Columns.Add(new DataColumn("EntityTypeName"));

            dataTable.Columns.Add(new DataColumn("PropertyName"));
            dataTable.Columns.Add(new DataColumn("PropertyDisplayName"));            

            dataTable.Columns.Add(new DataColumn("OldValue"));
            dataTable.Columns.Add(new DataColumn("NewValue"));

            dataTable.Columns.Add(new DataColumn("Case_Id"));
            dataTable.Columns.Add(new DataColumn("BusinessOperation_Id"));
            dataTable.Columns.Add(new DataColumn("User_Id"));

            dataTable.Columns.Add(new DataColumn("TransactionGuid", typeof(Guid)));
            dataTable.Columns.Add(new DataColumn("SoldPDRClass_Id", typeof(int)));

            return dataTable;
        }
    }
}