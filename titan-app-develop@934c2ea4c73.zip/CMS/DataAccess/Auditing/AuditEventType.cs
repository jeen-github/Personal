﻿namespace CMS.DataAccess.Auditing
{
    public enum AuditEventType
    {
        None = 0,
        Insert = 1,
        Update = 2,
        Delete = 4
    }
}