﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Web;
using CMS.Interfaces.Managers.SecurityManagers;

namespace CMS.DataAccess.Auditing
{
    public class AuditContext
    {
        public Func<int?> GetUserId { get; set; }
        public Func<int?> GetCaseId { get; set; }
        public Func<int?> GetAuditBusinessOperationId { get; set; }
        public Func<AuditEventType> GetAuditEventLevel { get; set; }
        public Func<int?> GetSoldPDRClassId { get; set; }
    }

    public class WebAuditContext : AuditContext
    {
        private const string CaseIdKey = "CaseId";
        private const string AuditBusinessOperationIdKey = "AuditBusinessOperationId";
        private const string AuditEventLevelKey = "AuditEventLevel";
        private const string SoldPDRClassIdKey = "SoldPDRClassId";

        public WebAuditContext()
        {
            GetUserId = () =>
            {
                if (HttpContext.Current == null || HttpContext.Current.User == null || HttpContext.Current.User.Identity == null) return null;

                var user = HttpContext.Current.User as ClaimsPrincipal;
                if (user == null) return null;

                var claim = user.Claims.FirstOrDefault(c => c.Type == UserInfoDto.TitanUserIdClaimName);
                return claim != null ? int.Parse(claim.Value) : (int?)null;
            };

            GetCaseId = () =>
            {
                if (HttpContext.Current == null || HttpContext.Current.Items[CaseIdKey] == null) return null;
                return (int)HttpContext.Current.Items[CaseIdKey];
            };

            GetAuditBusinessOperationId = () =>
            {
                if (HttpContext.Current == null || HttpContext.Current.Items[AuditBusinessOperationIdKey] == null) return null;
                return (int)HttpContext.Current.Items[AuditBusinessOperationIdKey];
            };

            GetAuditEventLevel = () =>
            {
                if (HttpContext.Current == null || HttpContext.Current.Items[AuditEventLevelKey] == null) return AuditEventType.None;
                return (AuditEventType)HttpContext.Current.Items[AuditEventLevelKey];
            };
            GetSoldPDRClassId = () =>
            {
                if (HttpContext.Current == null || HttpContext.Current.Items[SoldPDRClassIdKey] == null) return null;
                return (int)HttpContext.Current.Items[SoldPDRClassIdKey];
            };
        }

        public static void SetCaseId(int caseId)
        {
            if (HttpContext.Current == null) return;            
            HttpContext.Current.Items[CaseIdKey] = caseId;
        }

        public static void SetBusinessOperation(AuditBusinessOperationEnum auditBusinessOperation)
        {
            if (HttpContext.Current == null) return;
            HttpContext.Current.Items[AuditBusinessOperationIdKey] = (int)auditBusinessOperation;
        }

        public static void SetAuditEventLevel(AuditEventType auditEventType)
        {
            if (HttpContext.Current == null) return;
            HttpContext.Current.Items[AuditEventLevelKey] = auditEventType;
        }
        public static void SetSoldPDRClassId(int soldPDRClassId)
        {
            if (HttpContext.Current == null) return;
            HttpContext.Current.Items[SoldPDRClassIdKey] = soldPDRClassId;
        }
    }
}