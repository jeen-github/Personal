﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using CMS.Model.BaseEntities;
using CMS.Model.Entities;
using CMS.Model.Extensions;
using NHibernate.Event;

namespace CMS.DataAccess.Auditing
{
    public class AuditEventListener : IPostUpdateEventListener, IPostInsertEventListener, IPostDeleteEventListener
    {
        private readonly string _connectionString;
        private readonly AuditContext _auditContext;
        private readonly ConcurrentQueue<AuditDataLog> _auditQueue = new ConcurrentQueue<AuditDataLog>();

        public AuditEventListener(string connectionString, AuditContext auditContext)
        {
            _connectionString = connectionString;
            _auditContext = auditContext;

            var auditDataPersister = new AuditDataPersister(connectionString, _auditQueue);
            auditDataPersister.Start();
        }

        public void OnPostUpdate(PostUpdateEvent @event)
        {
            ProcessEvent(@event, AuditEventType.Update);
        }

        public void OnPostInsert(PostInsertEvent @event)
        {
            ProcessEvent(@event, AuditEventType.Insert);
        }

        public void OnPostDelete(PostDeleteEvent @event)
        {
            ProcessEvent(@event, AuditEventType.Delete);
        }

        private void ProcessEvent(IPostDatabaseOperationEventArgs @event, AuditEventType eventType)
        {
            try
            {
                // verify auditing is on
                var auditLevel = _auditContext.GetAuditEventLevel();
                if (auditLevel == AuditEventType.None) return;

                // verify the right level of auditing
                if (!auditLevel.HasFlag(eventType)) return;

                // checks if entity has any auditable properties
                var auditableProperties = GetAuditablePropertiesFromEvent(@event);
                if (!auditableProperties.Any()) return;

                if (eventType == AuditEventType.Update)
                {
                    ProcessUpdateEvent(@event, auditableProperties);
                }
                else
                {
                    ProcessNonUpdateEvent(@event, eventType);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("ERROR in auditing {0} {1}", ex.Message, ex.StackTrace);
            }
        }

        private void ProcessUpdateEvent(IPostDatabaseOperationEventArgs @event, List<string> auditableProperties)
        {
            var eventObject = @event as PostUpdateEvent;
            if (eventObject == null || eventObject.OldState == null) return;

            for (int i = 0; i < @event.Persister.PropertyNames.Length; i++)
            {
                if (auditableProperties.Contains(@event.Persister.PropertyNames[i]))
                {
                    // TODO: ignore the IList auditable properties which will be handled by the Collection events
                    

                    // get the value of DisplayName from the Audit attribute
                    string propertyDisplayName = null;
                    string propertyStringFormat = null;

                    var auditableProperty = @event.Entity.GetType().GetProperties().FirstOrDefault(p => p.Name == @event.Persister.PropertyNames[i]);
                    if (auditableProperty != null)
                    {
                        var auditableAttribute = auditableProperty.GetCustomAttribute<AuditAttribute>();
                        if (auditableAttribute != null)
                        {
                            propertyDisplayName = auditableAttribute.DisplayName;
                            propertyStringFormat = auditableAttribute.Format;
                        }
                    }

                    var audit = new AuditDataLog
                    {
                        RecordedDate = DateTime.Now,
                        AuditEventType = (int)AuditEventType.Update,                        
                        EntityId = (int)@event.Id,
                        EntityTypeName = @event.Entity.GetType().ToString(),
                        EntityDisplayName = @event.Entity.ToString(),
                        PropertyName = @event.Persister.PropertyNames[i],
                        PropertyDisplayName = propertyDisplayName ?? @event.Persister.PropertyNames[i],
                        CaseId = _auditContext.GetCaseId(),
                        BusinessOperationId = _auditContext.GetAuditBusinessOperationId(),
                        User_Id = _auditContext.GetUserId(),
                        TransactionGuid = @event.Session.SessionId,
                        SoldPDRClassId = _auditContext.GetSoldPDRClassId(),
                    };
                    
                    SetOldAndNewValues(eventObject.OldState[i], eventObject.State[i], audit, propertyStringFormat);
                    
                    if (audit.OldValue != audit.NewValue)
                    {
                        _auditQueue.Enqueue(audit);
                    }
                }
            }
        }

        private void ProcessNonUpdateEvent(IPostDatabaseOperationEventArgs @event, AuditEventType eventType)
        {
            var audit = new AuditDataLog
            {
                RecordedDate = DateTime.Now,
                AuditEventType = (int)eventType,
                EntityId = (int)@event.Id,
                EntityTypeName = @event.Entity.GetType().ToString(),
                EntityDisplayName = @event.Entity.ToString(),
                CaseId = _auditContext.GetCaseId(),
                BusinessOperationId = _auditContext.GetAuditBusinessOperationId(),
                User_Id = _auditContext.GetUserId(),
                TransactionGuid = @event.Session.SessionId,
                SoldPDRClassId = _auditContext.GetSoldPDRClassId()
            };

            _auditQueue.Enqueue(audit);
        }

        private void SetOldAndNewValues(object oldState, object newState, AuditDataLog auditData, string propertyStringFormat)
        {
            if (oldState is Entity)
            {
                auditData.OldValue = oldState.ToString();
            }

            if (newState is Entity)
            {
                auditData.NewValue = newState.ToString();
                return;
            }

            if (newState is Enum)
            {
                auditData.NewValue = ((Enum)newState).GetDescription();

                if (oldState != null)
                {                   
                    var oldStateEnum = Enum.ToObject(newState.GetType(), oldState);
                    auditData.OldValue = ((Enum)oldStateEnum).GetDescription();
                }

                return;
            }

            if (newState is bool || oldState is bool)
            {
                if (newState != null)
                {
                    var newStateBool = bool.Parse(newState.ToString());
                    auditData.NewValue = newStateBool ? "Yes" : "No";
                }

                if (oldState != null)
                {
                    var oldStateBool = bool.Parse(oldState.ToString());
                    auditData.OldValue = oldStateBool ? "Yes" : "No";
                }

                return;
            }

            if (!string.IsNullOrEmpty(propertyStringFormat))
            {
                auditData.OldValue = oldState != null ? string.Format(propertyStringFormat, oldState) : null;
                auditData.NewValue = newState != null ? string.Format(propertyStringFormat, newState) : null;
            }
            else
            {
                auditData.OldValue = oldState != null ? oldState.ToString() : null;
                auditData.NewValue = newState != null ? newState.ToString() : null;
            }
        }

        private List<string> GetAuditablePropertiesFromEvent(IPostDatabaseOperationEventArgs @event)
        {
            var auditableProperties = @event.Entity.GetType().GetProperties()
                .Where(p => p.GetCustomAttribute<AuditAttribute>() != null)
                .Select(p => p.Name)
                .ToList();
            return auditableProperties;
        }
    }
}
