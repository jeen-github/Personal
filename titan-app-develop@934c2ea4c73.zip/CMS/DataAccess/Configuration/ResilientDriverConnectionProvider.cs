﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using Logger.Static;
using NHibernate.Connection;

namespace CMS.DataAccess.Configuration
{
    public class ResilientDriverConnectionProvider : DriverConnectionProvider
    {
        public const string ConnectionDelayBetweenTries = "connection.delay_between_tries";
        public const string ConnectionMaxTries = "connection.max_tries";
        
        public ResilientDriverConnectionProvider()
        {
            MaxTries = 3;
            DelayBetweenTries = TimeSpan.FromSeconds(1);
        }

        public int MaxTries { get; set; }

        public TimeSpan DelayBetweenTries { get; set; }

        public override void Configure(IDictionary<string, string> settings)
        {
            string maxTries;
            string delayBetweenTries;

            if (settings.TryGetValue(ConnectionMaxTries, out maxTries))
            {
                MaxTries = int.Parse(maxTries);
            }

            if (settings.TryGetValue(ConnectionDelayBetweenTries, out delayBetweenTries))
            {
                DelayBetweenTries = TimeSpan.Parse(delayBetweenTries);
            }

            base.Configure(settings);
        }

        public override IDbConnection GetConnection()
        {
            IDbConnection connection = null;

            for (var i = 0; i < MaxTries; ++i)
            {
                try
                {
                    connection = base.GetConnection();
                    break;
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat("Failed get connection, {0} of {1}", ex, (i + 1), MaxTries);

                    if (i == MaxTries - 1)
                    {
                        Log.FatalFormat("Could not get connection after {0} tries", ex, MaxTries);
                        throw;
                    }

                    Thread.Sleep(DelayBetweenTries);
                }
            }

            return connection;
        }
    }
}