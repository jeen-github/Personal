﻿using System.Linq;
using CMS.DataAccess.Auditing;
using CMS.DataAccess.Configuration.Conventions;
using CMS.Model.Attributes;
using CMS.Model.BaseEntities;
using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using FluentNHibernate.Conventions.Helpers;
using NHibernate;
using NHibernate.Event;


namespace CMS.DataAccess.Configuration
{
    public static class DataAccessConfiguration
    {
        private static ISessionFactory _sessionFactory = null;

        public static ISessionFactory CreateSessionFactory(string connectionString)
        {
            if (_sessionFactory != null) return _sessionFactory;

            var persistenceModel = GetPersistenceModel();

            var auditListener = new AuditEventListener(connectionString, new WebAuditContext());

            var fluentConfiguration = Fluently.Configure();            
            fluentConfiguration.ExposeConfiguration(c =>
            {
                c.EventListeners.PostUpdateEventListeners = new IPostUpdateEventListener[] { auditListener };
                c.EventListeners.PostInsertEventListeners = new IPostInsertEventListener[] { auditListener };
                c.EventListeners.PostDeleteEventListeners = new IPostDeleteEventListener[] { auditListener };
                c.SetProperty("cache.use_second_level_cache", "true");
                c.SetProperty("cache.use_query_cache", "true");
                // generate stats should not be set for production deployments
                c.SetProperty("generate_statistics", "false");
            });
           
            _sessionFactory = fluentConfiguration
              .Database(MsSqlConfiguration.MsSql2008.ConnectionString(connectionString).DefaultSchema("cms").Provider<ResilientDriverConnectionProvider>())
                .Cache(c => c.ProviderClass(typeof(NHibernate.Caches.SysCache.SysCacheProvider).AssemblyQualifiedName).UseQueryCache())
              .Mappings(m => m.AutoMappings.Add(persistenceModel))
              .BuildSessionFactory();

            return _sessionFactory;
        }

        private static AutoPersistenceModel GetPersistenceModel()
        {
            var mappingConfiguration = new DefaultMappingConvention();

            var mappings = AutoMap.AssemblyOf<Entity>(mappingConfiguration)
                                  .IgnoreBase<Entity>()
                                  .OverrideAll(p => p.IgnoreProperties(x => x.MemberInfo.CustomAttributes.Any(a => a.AttributeType == typeof(NotPersistedAttribute))))
                                  .UseOverridesFromAssemblyOf<DefaultMappingConvention>()
                                  .Conventions.Add(ConventionBuilder.Class.Always(c=>c.Cache.ReadWrite()))
                                  ;

            mappings.Conventions.Add<PrimaryKeyConvention>();
            mappings.Conventions.Add<CascadeConvention>();
            mappings.Conventions.Add<EnumConvention>();

            return mappings;
        }
    }
}
