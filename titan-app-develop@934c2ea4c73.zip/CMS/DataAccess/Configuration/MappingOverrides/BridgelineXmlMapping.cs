﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class BridgelineXmlMapping : IAutoMappingOverride<BridgelineXml>
    {
        public void Override(AutoMapping<BridgelineXml> mapping)
        {
            mapping.Map(x => x.FileContent).CustomType("StringClob").Length(int.MaxValue);
        }
    }
}
