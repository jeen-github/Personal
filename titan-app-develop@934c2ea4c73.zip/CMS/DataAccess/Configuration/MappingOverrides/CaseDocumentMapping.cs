﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class CaseDocumentMapping : IAutoMappingOverride<CaseDocument>
    {
        public void Override(AutoMapping<CaseDocument> mapping)
        {
            mapping.Map(x => x.FileBytes).CustomType("BinaryBlob").Length(int.MaxValue);            
        }
    }
}
