﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class EnrollmentPDRClassOptionMappingOverride : IAutoMappingOverride<EnrollmentPDRClassOption>
    {
        public void Override(AutoMapping<EnrollmentPDRClassOption> mapping)
        {
            mapping.Schema("cms");
            mapping.Table("[EnrollmentPDRClassOption]");
            mapping.Id(x => x.Id, "EnrollmentPDRClassOption_Id");

            mapping.HasManyToMany<EnrollmentPDRClassOptionPlan>(x => x.EnrollmentPDRClassOptionPlans)
                .Table("EnrollmentPDRClassOptionPlanAssociation")
                .ParentKeyColumn("EnrollmentPDRClassOption_Id")
                .ChildKeyColumn("EnrollmentPDRClassOptionPlan_Id")
                .AsBag()
                .Cascade.All().LazyLoad();
        }
    }
}
