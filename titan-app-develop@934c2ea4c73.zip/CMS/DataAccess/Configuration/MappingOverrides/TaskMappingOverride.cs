﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class TaskMappingOverride : IAutoMappingOverride<CmsTask>
    {
        public void Override(AutoMapping<CmsTask> mapping)
        {
            mapping.Schema("cms");
            mapping.Table("Task");
            mapping.Id(x => x.Id, "Task_Id");
        }
    }
}
