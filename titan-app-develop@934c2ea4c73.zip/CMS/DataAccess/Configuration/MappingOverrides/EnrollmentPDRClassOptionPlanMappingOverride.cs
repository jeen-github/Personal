﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class EnrollmentPDRClassOptionPlanMappingOverride : IAutoMappingOverride<EnrollmentPDRClassOptionPlan>
    {
        public void Override(AutoMapping<EnrollmentPDRClassOptionPlan> mapping)
        {
            mapping.Schema("cms");
            mapping.Table("[EnrollmentPDRClassOptionPlan]");
            mapping.Id(x => x.Id, "EnrollmentPDRClassOptionPlan_Id");

            mapping.HasManyToMany<EnrollmentPDRClassOption>(x => x.EnrollmentPDRClassOptions)
                .Table("EnrollmentPDRClassOptionPlanAssociation")
                .ParentKeyColumn("EnrollmentPDRClassOption_Id")
                .ChildKeyColumn("EnrollmentPDRClassOptionPlan_Id")
                .AsBag()
                .Cascade.None();
        }
    }
}
