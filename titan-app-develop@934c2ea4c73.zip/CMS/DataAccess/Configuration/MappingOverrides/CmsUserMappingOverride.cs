﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class CmsUserMappingOverride : IAutoMappingOverride<CmsUser>
    {
        public void Override(AutoMapping<CmsUser> mapping)
        {
            mapping.Schema("cms");
            mapping.Table("[User]");
            mapping.Id(x => x.Id, "User_Id");

            mapping.HasManyToMany<UserGroup>(x => x.UserGroups)
                .Table("User_UserGroup_Association")
                .ParentKeyColumn("User_Id")
                .ChildKeyColumn("UserGroup_Id")
                .AsBag()
                .Cascade.None();
        }
    }
}
