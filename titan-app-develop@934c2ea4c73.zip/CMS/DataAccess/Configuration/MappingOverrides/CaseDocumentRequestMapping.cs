﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class CaseDocumentRequestMapping : IAutoMappingOverride<CaseDocumentRequest>
    {
        public void Override(AutoMapping<CaseDocumentRequest> mapping)
        {
            mapping.Map(x => x.ExtreamRequest).CustomType("StringClob").Length(int.MaxValue);
        }
    }
}
