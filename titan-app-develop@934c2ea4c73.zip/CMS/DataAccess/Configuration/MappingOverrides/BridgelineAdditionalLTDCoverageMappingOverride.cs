﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class BridgelineAdditionalLTDCoverageMappingOverride : IAutoMappingOverride<BridgelineAdditionalLTDCoverage>
    {
        public void Override(AutoMapping<BridgelineAdditionalLTDCoverage> mapping)
        {
            mapping.Schema("cms");
            mapping.Table("[BridgelineAdditionalLTDCoverage]");
            mapping.Id(x => x.Id, "BridgelineAdditionalLTDCoverage_Id");
            mapping.LazyLoad();
            mapping.References(x => x.EnrollmentParticipant).Column("EnrollmentParticipant_Id");
        }
    }
}
