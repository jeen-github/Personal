﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class GaMessageHistoryMappingOverride : IAutoMappingOverride<GaMessageHistory>
    {
        public void Override(AutoMapping<GaMessageHistory> mapping)
        {
            mapping.Map(x => x.MessageBody).CustomType("StringClob").CustomSqlType("nvarchar(max)");
            mapping.Map(x => x.ErrorMessage).CustomType("StringClob").CustomSqlType("nvarchar(max)");
        }
    }
}
