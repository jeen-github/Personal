﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class WorkUnitMappingOverride : IAutoMappingOverride<WorkUnit>
    {
        public void Override(AutoMapping<WorkUnit> mapping)
        {
            mapping.Map(x => x.InputData).CustomType("StringClob").CustomSqlType("nvarchar(max)");
            mapping.Map(x => x.ErrorMessage).CustomType("StringClob").CustomSqlType("nvarchar(max)");
        }
    }
}
