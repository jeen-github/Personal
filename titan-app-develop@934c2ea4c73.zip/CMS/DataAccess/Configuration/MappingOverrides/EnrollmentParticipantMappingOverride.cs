﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class EnrollmentParticipantMappingOverride : IAutoMappingOverride<EnrollmentParticipant>
    {
        public void Override(AutoMapping<EnrollmentParticipant> mapping)
        {
            mapping.Schema("cms");
            mapping.Table("[EnrollmentParticipant]");
            mapping.Id(x => x.Id, "EnrollmentParticipant_Id");
            mapping.HasMany<BridgelineAdditionalLTDCoverage>(x => x.BridgelineAdditionalLTDCoverage)
                .Table("EnrollmentParticipant")
                .AsBag()
                .Cascade.All().LazyLoad().KeyColumn("EnrollmentParticipant_Id");
            mapping.References(x => x.MldeStatusTypeEntity, "MldeStatusType_Id").ReadOnly();
            mapping.References(x => x.MldeUploadStatusTypeEntity, "MldeUploadStatusType_Id").ReadOnly();
        }
    }
}
