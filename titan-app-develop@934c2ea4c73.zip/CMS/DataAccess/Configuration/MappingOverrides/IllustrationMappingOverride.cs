﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class IllustrationMappingOverride : IAutoMappingOverride<Illustration>
    {
        public void Override(AutoMapping<Illustration> mapping)
        {
            mapping.Map(x => x.RequestJsonText).CustomType("StringClob").CustomSqlType("nvarchar(max)");
        }
    }
}
