﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class CmsLogMappingOverride : IAutoMappingOverride<CmsLog>
    {
        public void Override(AutoMapping<CmsLog> mapping)
        {
            mapping.Schema("cms");
            mapping.Table("Log");
            mapping.Id(x => x.Id, "Log_Id");
            mapping.Map(x => x.Message).CustomType("StringClob").CustomSqlType("nvarchar(max)");
            mapping.Map(x => x.Exception).CustomType("StringClob").CustomSqlType("nvarchar(max)");
            mapping.Map(x => x.StackTrace).CustomType("StringClob").CustomSqlType("nvarchar(max)");
        }
    }
}
