﻿using CMS.Model.Entities;
using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate;

namespace CMS.DataAccess.Configuration.MappingOverrides
{
    public class EnrollmentMLDEStatusMapping : IAutoMappingOverride<EnrollmentMLDEStatus>
    {
        public void Override(AutoMapping<EnrollmentMLDEStatus> mapping)
        {
            mapping.Map(x => x.MLDEJson).CustomType("StringClob").Length(int.MaxValue);
        }
    }
}
