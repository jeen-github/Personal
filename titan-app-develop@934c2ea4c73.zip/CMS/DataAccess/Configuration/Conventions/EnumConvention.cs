﻿using System;
using FluentNHibernate.Conventions;
using FluentNHibernate.Conventions.AcceptanceCriteria;
using FluentNHibernate.Conventions.Inspections;
using FluentNHibernate.Conventions.Instances;

namespace CMS.DataAccess.Configuration.Conventions
{
    public class EnumConvention : IPropertyConvention, IPropertyConventionAcceptance
    {
        public void Apply(IPropertyInstance instance)
        {
            instance.CustomType(instance.Property.PropertyType);
            instance.Column(instance.Property.Name + "_Id");
        }
      
        public void Accept(IAcceptanceCriteria<IPropertyInspector> criteria)
        {
            criteria.Expect(x =>
            {
                var isEnum = x.Property.PropertyType.IsEnum;

                var isNullableEnum = false;
                var nullableType = Nullable.GetUnderlyingType(x.Property.PropertyType);
                if (nullableType != null)
                {
                    isNullableEnum = nullableType.IsEnum;
                }

                return isEnum || isNullableEnum;
            });
        }        
    }
}
