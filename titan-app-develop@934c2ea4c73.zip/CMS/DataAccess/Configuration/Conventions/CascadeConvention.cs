﻿using FluentNHibernate.Conventions;
using FluentNHibernate.Conventions.Instances;

namespace CMS.DataAccess.Configuration.Conventions
{
    public class CascadeConvention :  IHasManyConvention
    {        
        public void Apply(IOneToManyCollectionInstance instance)
        {            
            instance.Cascade.AllDeleteOrphan();
            instance.Inverse();
        }
    }
}
