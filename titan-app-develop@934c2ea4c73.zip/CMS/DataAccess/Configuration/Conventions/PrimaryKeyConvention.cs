﻿using FluentNHibernate.Conventions;
using FluentNHibernate.Conventions.Instances;

namespace CMS.DataAccess.Configuration.Conventions
{
    public class PrimaryKeyConvention : IIdConvention
    {
        public void Apply(IIdentityInstance instance)
        {
            instance.Column(instance.EntityType.Name + "_Id");
        }
    }
}
