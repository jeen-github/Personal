﻿using System;
using FluentNHibernate.Automapping;

namespace CMS.DataAccess.Configuration.Conventions
{
    public class DefaultMappingConvention : DefaultAutomappingConfiguration
    {
        public override bool ShouldMap(Type type)
        {
            return type.Namespace == "CMS.Model.Entities" && !type.IsEnum;
        }
    }
}
