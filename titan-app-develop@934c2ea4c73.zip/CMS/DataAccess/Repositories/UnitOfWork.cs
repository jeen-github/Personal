﻿using System;
using System.Collections.Generic;
using CMS.DataAccess.Auditing;
using CMS.DataAccess.Configuration;
using CMS.Interfaces.DataAccess;
using CMS.Model.BaseEntities;
using CMS.Model.Entities;
using NHibernate;

namespace CMS.DataAccess.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        public ISession Session { get; set; }
        public ITransaction Transaction { get; set; }

        public UnitOfWork(string connectionString)
        {
            Session = DataAccessConfiguration.CreateSessionFactory(connectionString).OpenSession();
            Session.FlushMode = FlushMode.Commit;
            Transaction = Session.BeginTransaction();
        }

        public IRepository<T> Repository<T>() where T : Entity
        {
            return new GenericRepository<T>(Session);
        }

        public IList<T> RunSqlQuery<T>(string queryString)
        {
            return Session.CreateSQLQuery(queryString).SetCacheable(false).List<T>();
        }

        public IList<T> RunSqlQueryCached<T>(string queryString)
        {
            return Session.CreateSQLQuery(queryString).SetCacheable(true).List<T>();
        }

        public IList<T> RunSqlQuery<T>(string queryString, int timeout)
        {
            return Session.CreateSQLQuery(queryString).SetTimeout(timeout).SetCacheable(false).List<T>();
        }

        public IList<T> RunSqlQueryCached<T>(string queryString, int timeout)
        {
            return Session.CreateSQLQuery(queryString).SetTimeout(timeout).SetCacheable(true).List<T>();
        }

        public void RunSqlQuery<T>(string queryString, params object[] parameters)
        {
            IQuery query = Session.CreateSQLQuery(queryString).SetCacheable(false);
            if (parameters != null && parameters.Length > 0)
            {
                for (var i = 0; i < parameters.Length; i++)
                {
                    query.SetParameter(query.NamedParameters[i], parameters[i]);
                }
                query.UniqueResult();
            }
        }

        public void RunSqlQueryWithTimeOut<T>(string queryString, int timeout, params object[] parameters)
        {
            IQuery query = Session.CreateSQLQuery(queryString).SetTimeout(timeout).SetCacheable(false);
            if (parameters != null && parameters.Length > 0)
            {
                for (var i = 0; i < parameters.Length; i++)
                {
                    query.SetParameter(query.NamedParameters[i], parameters[i]);
                }
                query.UniqueResult();
            }
        }

        public void RunSqlQueryWithTimeOutCached<T>(string queryString, int timeout, params object[] parameters)
        {
            IQuery query = Session.CreateSQLQuery(queryString).SetTimeout(timeout).SetCacheable(true);
            if (parameters != null && parameters.Length > 0)
            {
                for (var i = 0; i < parameters.Length; i++)
                {
                    query.SetParameter(query.NamedParameters[i], parameters[i]);
                }
                query.UniqueResult();
            }
        }

        public IList<T> RunSqlQuery<T>(string queryString, int timeout, params object[] parameters)
        {
            IQuery query = Session.CreateSQLQuery(queryString).SetTimeout(timeout).SetCacheable(false);
            if (parameters != null && parameters.Length > 0)
            {
                for (var i = 0; i < parameters.Length; i++)
                {
                    query.SetParameter(query.NamedParameters[i], parameters[i]);
                }
            }
            return query.List<T>();
        }

        public IList<T> RunSqlQueryCached<T>(string queryString, int timeout, params object[] parameters)
        {
            IQuery query = Session.CreateSQLQuery(queryString).SetTimeout(timeout).SetCacheable(true);
            if (parameters != null && parameters.Length > 0)
            {
                for (var i = 0; i < parameters.Length; i++)
                {
                    query.SetParameter(query.NamedParameters[i], parameters[i]);
                }
            }
            return query.List<T>();
        }

        public void Commit()
        {
            if (!Transaction.IsActive)
            {
                throw new InvalidOperationException("No active transaction");
            }
            Transaction.Commit();
        }

        public void Rollback()
        {
            if (Transaction.IsActive)
            {
                Transaction.Rollback();
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposing)
            {
                return;
            }

            if (Session == null)
            {
                return;
            }

            Session.Close();
            Session.Dispose();
            Session = null;
        }
    }
}
