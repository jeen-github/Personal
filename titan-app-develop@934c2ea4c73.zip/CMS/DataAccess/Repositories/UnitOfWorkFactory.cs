﻿using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using NHibernate;

namespace CMS.DataAccess.Repositories
{
    public class UnitOfWorkFactory : IUnitOfWorkFactory
    {
        public string ConnectionString { get; set; }

        public UnitOfWorkFactory(IConfiguration configuration)
        {
            this.ConnectionString = configuration.CMSDatabaseConnection;
        }

        public IUnitOfWork CreateUnitOfWork()
        {
            return new UnitOfWork(ConnectionString);
        }
    }
}
