﻿using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Model.BaseEntities;
using CMS.Model.Entities;
using NHibernate;
using NHibernate.Linq;

namespace CMS.DataAccess.Repositories
{
    public class GenericRepository<T> : IRepository<T> where T: Entity
    {
        private readonly ISession _session = null;

        public GenericRepository(ISession session)
        {
            _session = session;
        }

        public IQueryable<T> Linq()
        {
            return _session.Query<T>().AsQueryable();
        }

        public IQueryable<T> LinqWithTimeOut()
        {
            return _session.Query<T>().AsQueryable().Timeout(1000);
        }
        public IQueryable<T> LinqWithTimeOutCached()
        {
            return _session.Query<T>().AsQueryable().Timeout(100).Cacheable();
        }
        public IQueryable<T> LinqCached()
        {
            return _session.Query<T>().AsQueryable().Cacheable();
        }

        public void Save(T entity)
        {
            _session.SaveOrUpdate(entity);
        }

        public void Delete(T entity)
        {
            _session.Delete(entity);
        }
    }
}
