﻿using System;
using System.Linq;
using System.Net;
using CMS.Integrations.MLAppEntryServices.Model;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.MLAppEntryServices;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Model.Entities;
using Common.Utilities;
using Logger.Static;
using Newtonsoft.Json;
using RestSharp;

namespace CMS.Integrations.MLAppEntryServices
{
    public class AppEntryService : IAppEntryService
    {
        private readonly IConfiguration _configuration;
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public AppEntryService(IConfiguration configuration, IUnitOfWorkFactory unitOfWorkFactory)
        {
            _configuration = configuration;
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public void SendPolicyDecision(PolicyDecisionUpdateRequest request)
        {
            var serializedRequest = JsonConvert.SerializeObject(request);
            Log.TraceFormat("+SendPolicyDecision Request={0}", serializedRequest);

            try
            {
                
                var restClient = new RestServiceClient(_configuration.MLAppEntryPolicyDecisionUrl,
                    _configuration.CMSServiceCredentials.UserName, _configuration.CMSServiceCredentials.Password);

                var restRequest = new RestRequest("/api/v1/underwriter", Method.POST) {RequestFormat = DataFormat.Json};
                
                var uwRequest = new UnderwriterRequest
                {
                    PolicyNumber = request.PolicyNumber,
                    UnderwriterStatusType = (int) request.UnderwriterDecision,
                    Comments = request.UnderwriterResponseText
                };

                var jsonObject = JsonConvert.SerializeObject(uwRequest);
                restRequest.AddParameter("Application/Json", jsonObject, ParameterType.RequestBody);
                
                Log.Trace($"MLAppEntry PolicyDecision UWRequest= {jsonObject}");

                var response = restClient.SendRequest(restRequest);

                if (response.StatusCode != HttpStatusCode.OK)
                {
                    Log.ErrorFormat("Error response from MLAppEntry PolicyDecision. UWRequest={0}", jsonObject);
                }
                Log.Trace($"MLAppEntry PolicyDecision status updated successfully");
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error calling MLAppEntry PolicyDecision. Request={0}", ex, serializedRequest);
                throw;
            }

            Log.TraceFormat("-SendPolicyDecision");
        }

        public void SendWorkItem(WorkItemSendRequest request)
        {
            var serializedRequest = JsonConvert.SerializeObject(request);
            Log.TraceFormat("+SendWorkItem Request={0}", serializedRequest);

            try
            {
                var restClient = new RestServiceClient(_configuration.MLAppEntryPolicyDecisionUrl,
                    _configuration.CMSServiceCredentials.UserName, _configuration.CMSServiceCredentials.Password);

                var restRequest = new RestRequest("api/v1/workitem", Method.POST) { RequestFormat = DataFormat.Json };

                var wiRequest = new WorkitemRequest
                {
                    ApplicationTrackingId = request.ApplicationTrackingId,
                    CaseNumber = request.CaseNumber,
                    CaseName = request.CaseName,
                    DocumentType = (int) request.DocumentType,
                    InsuredFirstName = request.InsuredFirstName,
                    InsuredLastName = request.InsuredLastName,
                    ParticipantCMSID = request.ParticipantCMSID,
                    Status = request.Status,
                    PolicyNumber =request.PolicyNumber
                };

                var jsonObject = JsonConvert.SerializeObject(wiRequest);
                restRequest.AddParameter("Application/Json", jsonObject, ParameterType.RequestBody);

                Log.Trace($"MLAppEntry WorkItem WIRequest= {jsonObject}");

                var response = restClient.SendRequest(restRequest);

                if (response.StatusCode != HttpStatusCode.OK)
                {
                    Log.ErrorFormat("Error response from MLAppEntry WorkItem. WIRequest={0}", jsonObject);
                }
                Log.Trace($"MLAppEntry Workitem updated successfully");
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error calling MLAppEntry Workitem. Request={0}", ex, serializedRequest);
                throw;
            }

            Log.TraceFormat("-SendWorkItem");
        }

        public void SendMLDEAMBDataToMLApp(MLDEAMBDto request)
        {
            var serializedRequest = JsonConvert.SerializeObject(request);
            Log.TraceFormat("+SendMLDEAMBDataToMLApp Request={0}", serializedRequest);
            try
            {
                var restClient = new RestServiceClient(_configuration.MLAppEntryPolicyDecisionUrl,
                    _configuration.CMSServiceCredentials.UserName, _configuration.CMSServiceCredentials.Password);

                var restRequest = new RestRequest("api/v1/amb", Method.POST) { RequestFormat = DataFormat.Json };
               
                restRequest.AddParameter("Application/Json", serializedRequest, ParameterType.RequestBody);                

                var response = restClient.SendRequest(restRequest);

                if (response.StatusCode != HttpStatusCode.OK)
                {
                    Log.ErrorFormat("Error response from MLAppEntry MLDEAMB process. Request={0}", serializedRequest);
                }
                Log.Trace($"MLAppEntry MLDE AMB Data Added successfully");
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error response from MLAppEntry MLDEAMB process. Request={0}", ex, serializedRequest);
                throw;
            }

            Log.TraceFormat("-SendMLDEAMBDataToMLApp");
        }

        public void SendPolicyToMLAppStp(StpPostRequest request)
        {
            var serializedRequest = "";            
            try
            { 
             serializedRequest = JsonConvert.SerializeObject(request);
            Log.TraceFormat("+SendPolicyToMLAppStp Request={0}", serializedRequest);
                          
                var restClient = new RestServiceClient(_configuration.MLAppEntryPolicyDecisionUrl,
                    _configuration.CMSServiceCredentials.UserName, _configuration.CMSServiceCredentials.Password);

                var restRequest = new RestRequest("api/v1/stp", Method.POST) { RequestFormat = DataFormat.None };
                restRequest.AddParameter("policyNumber", request.PolicyNumber, ParameterType.QueryString);
                restRequest.AddParameter("stpStatus", StpStatusEnum.IGO, ParameterType.QueryString); //0 for IGO, 1 for NIGO in ML App Entry
                restRequest.AddParameter("callerid", "Titan", ParameterType.QueryString);
                restRequest.AddParameter("caseNumber", request.CaseNumber, ParameterType.QueryString);
              
                IRestResponse response = restClient.SendRequest(restRequest);
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    Log.ErrorFormat("Error response from MLAppEntry STP. STPRequest={0},{1}", request.PolicyNumber, request.CaseNumber);
                }
                else
                {                    
                    using (var uw = _unitOfWorkFactory.CreateUnitOfWork())
                    {
                        var enrollmentParticipantPolicy = uw.Repository<EnrollmentParticipantPolicy>()
                            .Linq().FirstOrDefault(p => p.PolicyNumber == request.PolicyNumber && p.EnrollmentParticipant.Id==request.EnrollmentParticipantId);
                        enrollmentParticipantPolicy.ReleaseDate = DateTime.Now;
                        uw.Repository<EnrollmentParticipantPolicy>().Save(enrollmentParticipantPolicy);
                        uw.Commit();
                    }
                    Log.Trace($"MLAppEntry STP updated successfully");
                }
                               
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error calling MLAppEntry STP. Request={0}", ex, serializedRequest);
                throw;
            }
            Log.TraceFormat("-SendPolicyToMLAppStp");
        }

       
    }    
}