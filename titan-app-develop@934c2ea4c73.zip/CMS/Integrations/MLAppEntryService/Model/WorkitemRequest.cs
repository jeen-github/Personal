﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Integrations.MLAppEntryServices.Model
{
    public class WorkitemRequest
    {
        public int ApplicationTrackingId { get; set; }

        public string CaseNumber { get; set; }

        public string CaseName { get; set; }

        public int DocumentType { get; set; }

        public string InsuredFirstName { get; set; }

        public string InsuredLastName { get; set; }

        public string ParticipantCMSID { get; set; }

        public string PolicyNumber { get; set; }

        public int Status { get; set; }
    }
}
