﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Integrations.MLAppEntryServices.Model
{ 
    public class UnderwriterRequest
    {
        public string PolicyNumber { get; set; }
        public int UnderwriterStatusType { get; set; }
        public string Comments { get; set; }
    }
}
