﻿using System.Collections.Generic;
using FluentNHibernate.Mapping;

namespace CMS.Integrations.BrokerDataServices.Models
{
    public class AgentContractType
    {
        public virtual int Id { get; protected set; }
        public virtual string DisplayName { get; protected set; }
        public virtual string Value { get; protected set; }
        public virtual string Code { get; protected set; }
        public virtual string DescriptionText { get; protected set; }
        public virtual int? SortOrder { get; protected set; }

        public virtual IList<AgentContract> AgentContracts
        {
            get;
            protected set;
        }
    }

    public class AgentContractTypeMap : ClassMap<AgentContractType>
    {
        public AgentContractTypeMap()
        {
            MapEntity();
        }

        public void MapEntity()
        {
            ReadOnly();
            Schema("ODS");
            Table("AgentTitleType");
            Id(x => x.Id, "AgentTitleTypeID");
            Map(x => x.Code, "Code").ReadOnly();
            Map(x => x.DescriptionText, "DescriptionText").ReadOnly();
            Map(x => x.DisplayName, "DisplayName").ReadOnly();
            Map(x => x.SortOrder, "SortOrderNumber").ReadOnly();
            Map(x => x.Value, "ValueText").ReadOnly();

            HasMany(x => x.AgentContracts).KeyColumn("AgentTitleTypeID").ReadOnly();
        }
    }
}