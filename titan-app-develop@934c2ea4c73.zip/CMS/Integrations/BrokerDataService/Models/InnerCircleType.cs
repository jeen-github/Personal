﻿using System.ComponentModel;

namespace CMS.Integrations.BrokerDataServices.Models
{
    public enum InnerCircleType
    {
        [Description("Chairmans Council")]
        ChairmansCouncil = 1,

        [Description("DI Inner Circle")]
        StandardInnerCircle = 2,

        [Description("Presidents Council")]
        PresidentsCouncil = 3,

        [Description("Platinum Inner Circle")]
        PlatinumInnerCircle = 4,

        [Description("Elite")]
        Elite = 5,

        [Description("None")]
        None = 6
    }
}