﻿using System.Collections.Generic;
using FluentNHibernate.Mapping;

namespace CMS.Integrations.BrokerDataServices.Models
{
    public class UnderwritingRegionType
    {
        public virtual int Id { get; protected set; }
        public virtual string DisplayName { get; protected set; }
        public virtual string Value { get; protected set; }
        public virtual string Code { get; protected set; }
        public virtual string Description { get; protected set; }
        public virtual int SortOrder { get; protected set; }

        public virtual IList<Agency> Agencies
        {
            get;
            protected set;
        }
    }

    public class UnderwritingRegionTypeMap : ClassMap<UnderwritingRegionType>
    {
        public UnderwritingRegionTypeMap()
        {
            MapEntity();
        }

        private void MapEntity()
        {
            ReadOnly();
            Schema("ODS");
            Table("UnderwritingRegionType");
            Id(x => x.Id, "UnderwritingRegionTypeID");
            Map(x => x.Code, "Code").ReadOnly();
            Map(x => x.Description, "DescriptionText").ReadOnly();
            Map(x => x.DisplayName, "DisplayName").ReadOnly();
            Map(x => x.SortOrder, "SortOrderNumber").ReadOnly();
            Map(x => x.Value, "ValueText").ReadOnly();

            HasMany(x => x.Agencies).KeyColumn("UnderWritingRegionTypeID").ReadOnly();
        }
    }
}