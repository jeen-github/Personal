﻿using System;
using System.Collections.Generic;
using FluentNHibernate.Mapping;
using NHibernate;

namespace CMS.Integrations.BrokerDataServices.Models
{
    public class Agency
    {
        /// <summary>
        /// Gets or sets the Primary Agency Name.
        /// </summary>
        /// <value>The Name.</value>
        public virtual string PrimaryAgencyName
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the Secondary Agency Name.
        /// </summary>
        /// <value>The Name.</value>
        public virtual string SecondaryAgencyName
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the PrimaryAgencyCode.
        /// </summary>
        /// <value>The PrimaryAgencyCode.</value>
        public virtual string PrimaryAgencyCode
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the SecondaryAgencyCode. THIS IS THE PRIMARY KEY.
        /// </summary>
        /// <value>The SecondaryAgencyCode.</value>
        public virtual string SecondaryAgencyCode
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the Sale Region ID.
        /// </summary>
        /// <value>The Region.</value>
        public virtual int? SalesRegionId
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the Underwriting Region ID.
        /// </summary>
        /// <value>The Region.</value>
        public virtual UnderwritingRegionType UnderwritingRegionType
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the LastUpdated.
        /// </summary>
        /// <value>The LastUpdated.</value>
        public virtual DateTime? LastUpdated
        {
            get;
            protected set;
        }

        public virtual string BerkshireDistributionChannelCode
        {
            get;
            protected set;
        }

        public virtual string AgencyShortCode
        {
            get;
            protected set;
        }

        public virtual bool? isBGA
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the ProducerWritingCodes.
        /// </summary>
        /// <value>The ProducerWritingCodes.</value>
        public virtual IList<AgentContract> AgentContracts { get; protected set; }

        public Agency()
        {
            AgentContracts = new List<AgentContract>();
        }
    }

    public class AgencyMap : ClassMap<Agency>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AgencyMap"/> class.
        /// </summary>
        public AgencyMap()
        {
            MapEntity();
        }

        public void MapEntity()
        {
            ReadOnly();
            Schema("ODS");
            Table("Agency");
            Id(x => x.SecondaryAgencyCode, "SecondaryAgencyCode");
            Map(x => x.LastUpdated, "LastUpdateDate").Nullable().ReadOnly();
            Map(x => x.PrimaryAgencyCode, "ODSPrimaryAgencyCode").ReadOnly();
            Map(x => x.PrimaryAgencyName, "ODSPrimaryAgencyName").ReadOnly();
            Map(x => x.SalesRegionId, "SalesRegionTypeID").Nullable().ReadOnly();
            Map(x => x.SecondaryAgencyName, "SecondaryAgencyName").ReadOnly();
            Map(x => x.BerkshireDistributionChannelCode, "BerkshireDistributionChannelCode").ReadOnly();
            Map(x => x.AgencyShortCode, "LocationName").ReadOnly();
            Map(x => x.isBGA, "IsBGAIndicator").Nullable().ReadOnly();

            References(x => x.UnderwritingRegionType).Column("UnderWritingRegionTypeID").Nullable();

            HasMany(x => x.AgentContracts).KeyColumn("SecondaryAgencyBrokerDealerCode").ReadOnly();
        }
    }

}