﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentNHibernate.Mapping;

namespace CMS.Integrations.BrokerDataServices.Models
{
    public class Producer
    {
        public virtual string Id
        {
            get
            {
                return this.ProducerCode;
            }
        }

        /// <summary>
        /// Gets or sets the Prefix.
        /// </summary>
        /// <value>The Prefix.</value>
        public virtual string Prefix
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the FirstName.
        /// </summary>
        /// <value>The FirstName.</value>
        public virtual string FirstName
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the MiddleInitial.
        /// </summary>
        /// <value>The MiddleInitial.</value>
        public virtual string MiddleName
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the LastName.
        /// </summary>
        /// <value>The LastName.</value>
        public virtual string LastName
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the Suffix.
        /// </summary>
        /// <value>The Suffix.</value>
        public virtual string Suffix
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the name of the organization.
        /// </summary>
        /// <value>
        /// The name of the organization.
        /// </value>
        public virtual string OrganizationName
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the ClientReferenceNumber.
        /// </summary>
        /// <value>The ClientReferenceNumber.</value>
        public virtual string ClientReferenceNumber
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the ProducerCode. THIS IS THE PRIMARY KEY.
        /// </summary>
        /// <value>The ProducerCode.</value>
        public virtual string ProducerCode
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the Is Organization flag.
        /// </summary>
        /// <value>The IsOrganization.</value>
        public virtual bool IsOrganization
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the is active flag.
        /// </summary>
        /// <value>
        /// The is active.
        /// </value>
        public virtual bool IsActive
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the LastUpdated.
        /// </summary>
        /// <value>The LastUpdated.</value>
        public virtual DateTime? LastUpdated
        {
            get;
            protected set;
        }

        public virtual bool? isBGA
        {
            get;
            protected set;
        }

        public virtual bool? IsDistributionAlliance
        {
            get;
            protected set;
        }

        public virtual string AddressLine1 { get; set; }
        public virtual string AddressLine2 { get; set; }
        public virtual string City { get; set; }
        public virtual string State { get; set; }
        public virtual string ZipCode { get; set; }
        public virtual string EmailAddress { get; set; }
        
        public virtual IList<AgentContract> AgentContracts { get; set; }
        
        public virtual bool? CorporateIndicator
        {
            get;
            protected set;
        }

        public Producer()
        {
            AgentContracts = new List<AgentContract>();
        }


    }

    public class ProducerMap : ClassMap<Producer>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProducerMap"/> class.
        /// </summary>
        public ProducerMap()
        {
            MapEntity();
        }

        public void MapEntity()
        {
            Schema("ODS");
            Table("Producer");
            Id(x => x.ProducerCode, "UCLAProducerCD");
            Map(x => x.ClientReferenceNumber, "CloasClientReferenceNumber").ReadOnly();
            Map(x => x.FirstName, "IndividualFirstName").ReadOnly();
            Map(x => x.IsActive, "ActiveIndicator").ReadOnly();
            Map(x => x.IsOrganization, "CorporateIndicator").ReadOnly();
            Map(x => x.LastName, "IndividualLastName").ReadOnly();
            Map(x => x.LastUpdated, "LastUpdateDate").Nullable().ReadOnly();
            Map(x => x.MiddleName, "IndividualMiddleName").ReadOnly();
            Map(x => x.OrganizationName, "OrganizationPartyName").ReadOnly();
            Map(x => x.Prefix, "IndividualPrefixCode").ReadOnly();
            Map(x => x.Suffix, "IndividualSuffixCode").ReadOnly();
            Map(x => x.IsDistributionAlliance, "IsDistributionAllianceIndicator").Nullable().ReadOnly();
            Map(x => x.isBGA, "IsBGAIndicator").Nullable().ReadOnly();

            Map(x => x.AddressLine1, "AddressLine1").ReadOnly();
            Map(x => x.AddressLine2, "AddressLine2").ReadOnly();
            Map(x => x.City, "CityName").ReadOnly();
            Map(x => x.State, "StateName").ReadOnly();
            Map(x => x.ZipCode, "Zip5DigitCode").ReadOnly();
            Map(x => x.EmailAddress, "EmailAddress").ReadOnly();
            Map(x => x.CorporateIndicator, "CorporateIndicator").ReadOnly();
            HasMany(x => x.AgentContracts).KeyColumn("UCLAProducerCD").ReadOnly();            
        }
    }
}