﻿using System;
using System.Linq;
using FluentNHibernate.Mapping;

namespace CMS.Integrations.BrokerDataServices.Models
{
    public class AgentContract
    {
        /// <summary>
        /// Gets or sets the Contract ID. THIS IS THE PRIMARY KEY. This was previously referred to as the Producer Writing Code.
        /// </summary>
        /// <value>The WritingCode.</value>
        public virtual string ContractId
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the parent contract identifier (this will be populated in the event this is a sub producer contract).
        /// </summary>
        /// <value>
        /// The parent contract identifier.
        /// </value>
        public virtual string ParentContractIdentifier
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the Terminated.
        /// </summary>
        /// <value>The Terminated.</value>
        public virtual bool IsActive
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the LastUpdated.
        /// </summary>
        /// <value>The LastUpdated.</value>
        public virtual DateTime? LastUpdated
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the contract start date.
        /// </summary>
        /// <value>
        /// The contract start date.
        /// </value>
        public virtual DateTime? ContractStartDate
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the contract end date.
        /// </summary>
        /// <value>
        /// The contract end date.
        /// </value>
        public virtual DateTime? ContractEndDate
        {
            get;
            protected set;
        }

        public virtual bool? isBGA
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets the type of the inner circle.
        /// </summary>
        /// <value>
        /// The type of the inner circle.
        /// </value>
        public virtual InnerCircleType? InnerCircleType { get; protected set; }

        /// <summary>
        /// Gets or sets the Agency.
        /// </summary>
        /// <value>The Agency.</value>
        public virtual Agency Agency
        {
            get;
            protected set;
        }

        /// <summary>
        /// Gets or sets the Producer.
        /// </summary>
        /// <value>The Producer.</value>
        public virtual Producer Producer
        {
            get;
            protected set;
        }

        public virtual AgentContractType AgentContractType
        {
            get;
            protected set;
        }

       
        
    }

    public class AgentContractMap : ClassMap<AgentContract>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AgentContractMap"/> class.
        /// </summary>
        public AgentContractMap()
        {
            MapEntity();
        }

        public void MapEntity()
        {
            ReadOnly();
            Schema("ODS");
            Table("AgentContract");
            Id(x => x.ContractId, "ODSAgentContractIdentifier");
            Map(x => x.ContractEndDate, "AgentContractIdentifierEndDate").Nullable().ReadOnly();
            Map(x => x.ContractStartDate, "AgentContractIdentifierStartDate").Nullable().ReadOnly();
            Map(x => x.IsActive, "ActiveIndicator").ReadOnly();
            Map(x => x.LastUpdated, "LastUpdateDate").ReadOnly();
            Map(x => x.ParentContractIdentifier, "SubProducerParentContract").ReadOnly();
            Map(x => x.isBGA, "IsBGAIndicator").Nullable().ReadOnly();
            Map(m => m.InnerCircleType, "InnerCircleTypeID").CustomType<InnerCircleType>().Nullable().ReadOnly();

            References(x => x.Agency).Column("SecondaryAgencyBrokerDealerCode").ReadOnly();
            References(x => x.Producer).Column("UCLAProducerCD").ReadOnly();
            References(x => x.AgentContractType).Column("AgentTitleTypeID").ReadOnly();            
        }
    }
}