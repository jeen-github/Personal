﻿using CMS.Integrations.BrokerDataServices.Models;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;

namespace CMS.Integrations.BrokerDataServices.Utilities
{
    public static class SessionFactory
    {
        private static ISessionFactory _sessionFactory = null;

        public static ISessionFactory CreateSessionFactory(string connectionString)
        {
            if (_sessionFactory != null) return _sessionFactory;
            
            _sessionFactory = Fluently.Configure()
              .Database(MsSqlConfiguration.MsSql2008.ConnectionString(connectionString))
              .Mappings(m => m.FluentMappings.AddFromAssemblyOf<Agency>())
              .BuildSessionFactory();

            return _sessionFactory;
        }
    }
}