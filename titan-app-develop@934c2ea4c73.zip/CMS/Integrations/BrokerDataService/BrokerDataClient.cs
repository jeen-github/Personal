﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Integrations.BrokerDataServices.Models;
using CMS.Integrations.BrokerDataServices.Utilities;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.BrokerDataServices;
using NHibernate.Linq;
using NHibernate;
using Common.Utilities;

namespace CMS.Integrations.BrokerDataServices
{
    public class BrokerDataClient : IBrokerDataClient
    {
        private const int ReponseLimitCount = 1;
        private readonly IConfiguration _configuration;

        public BrokerDataClient(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public List<BrokerDataDto> Search(BrokerSearchRequest request)
        {
            var sessionFactory = SessionFactory.CreateSessionFactory(_configuration.DisabilityReferenceLibraryDatabaseConnection);

            using (var session = sessionFactory.OpenSession())
            {
                var query = session.Query<AgentContract>();

                if (!string.IsNullOrEmpty(request.WritingCode))
                {
                    query = query.Where(a => a.ContractId == request.WritingCode);
                }

                if (!string.IsNullOrEmpty(request.LastName))
                {
                    query = query.Where(a => a.Producer.LastName.StartsWith(request.LastName));
                }

                if (!string.IsNullOrEmpty(request.FirstName))
                {
                    query = query.Where(a => a.Producer.FirstName.StartsWith(request.FirstName));
                }

                query = query.Take(ReponseLimitCount);

                return query.Select(b => new BrokerDataDto
                {
                    WritingCode = b.ContractId,
                    LastName = b.Producer.LastName,
                    FirstName = b.Producer.FirstName,
                    AgencyCode = b.Agency.PrimaryAgencyCode,
                    AgencyName = b.Agency.SecondaryAgencyName,
                    IsOrganization = b.Producer.IsOrganization,
                    AddressLine1 = b.Producer.AddressLine1,
                    AddressLine2 = b.Producer.AddressLine2,
                    City = b.Producer.City,
                    ZipCode = b.Producer.ZipCode,
                    EmailAddress = b.Producer.EmailAddress,
                    OrganizationPartyName = b.Producer.OrganizationName,
                    CorporateIndicator = b.Producer.CorporateIndicator,
                    ParentContractIdentifier = b.ParentContractIdentifier
                }).ToList();
            }
        }
        public List<BrokerDataDto> GetBrokerDataForSubProducers(BrokerSearchRequest request)
        {
            var sessionFactory = SessionFactory.CreateSessionFactory(_configuration.DisabilityReferenceLibraryDatabaseConnection);

            using (var session = sessionFactory.OpenSession())
            {
                var query = session.Query<AgentContract>()
                               .Where(ac => ac.IsActive && ac.ParentContractIdentifier != null && ac.Producer != null && ac.Agency != null);

                if (!string.IsNullOrEmpty(request.WritingCode))
                {
                    query = query.Where(a => a.ParentContractIdentifier == request.WritingCode);
                }
                else
                {
                    query = query.Take(ReponseLimitCount);
                }

                return query.Select(b => new BrokerDataDto
                {
                    WritingCode = b.ContractId,
                    LastName = b.Producer.LastName,
                    FirstName = b.Producer.FirstName,
                    AgencyCode = b.Agency.PrimaryAgencyCode,
                    AgencyName = b.Agency.SecondaryAgencyName,
                    IsOrganization = b.Producer.IsOrganization,
                    AddressLine1 = b.Producer.AddressLine1,
                    AddressLine2 = b.Producer.AddressLine2,
                    City = b.Producer.City,
                    ZipCode = b.Producer.ZipCode,
                    EmailAddress = b.Producer.EmailAddress,
                    OrganizationPartyName = b.Producer.OrganizationName,
                    ParentContractIdentifier = b.ParentContractIdentifier
                }).ToList();
            }
        }
        public IList<ServicingAgentDto> GetServicingNonServicingProducers(string policyNumber, string cloasClientReferenceNumber)
        {
            var sessionFactory = SessionFactory.CreateSessionFactory(_configuration.DisabilityReferenceLibraryDatabaseConnection);
            var brokers = new List<ServicingAgentDto>();
            using (var session = sessionFactory.OpenSession())
            {
                var queryString = "EXEC [Extract].[USP_PriorCoverageSearchProducerDetail] :@PolicyNumber";
                object[] parameters = new object[1];
                parameters[0] = policyNumber;
                //parameters[1] = cloasClientReferenceNumber;

                var results = RunSQlQuery<object>(session, queryString, parameters).ToArray();
                if (results != null && results.Count() > 0)
                {
                    object[] result = (object[])results[0];
                    var policyN = result[0] != null ? result[0].ToString() : string.Empty;
                    var cloasClientReferenceN = result[1] != null ? result[1].ToString() : string.Empty;
                    var servicingAgentWritingCode = result[2] != null ? result[2].ToString() : string.Empty;
                    var producer1AgentWritingCode = result[3] != null ? result[3].ToString() : string.Empty;
                    var producer1AgentWritingCode_Percentage = result[4] != null ? Convert.ToDecimal(result[4]) : 0.0m;
                    var producer2AgentWritingCode = result[5] != null ? result[5].ToString() : string.Empty;
                    var producer2AgentWritingCode_Percentage = result[6] != null ? Convert.ToDecimal(result[6]) : 0.0m;
                    var producer3AgentWritingCode = result[7] != null ? result[7].ToString() : string.Empty;
                    var producer3AgentWritingCode_Percentage = result[8] != null ? Convert.ToDecimal(result[8]) : 0.0m;
                    var producer4AgentWritingCode = result[9] != null ? result[9].ToString() : string.Empty;
                    var producer4AgentWritingCode_Percentage = result[10] != null ? Convert.ToDecimal(result[10]) : 0.0m;
                    var producer5AgentWritingCode = result[11] != null ? result[11].ToString() : string.Empty;
                    var producer5AgentWritingCode_Percentage = result[12] != null ? Convert.ToDecimal(result[12]) : 0.0m;
                    var producer6AgentWritingCode = result[13] != null ? result[13].ToString() : string.Empty;
                    var producer6AgentWritingCode_Percentage = result[14] != null ? Convert.ToDecimal(result[14]) : 0.0m;

                    if (!string.IsNullOrEmpty(producer1AgentWritingCode) && producer1AgentWritingCode.ToUpper() != "UNKNOWN")
                    {
                        var broker = GetBroker(session, policyN, cloasClientReferenceN, servicingAgentWritingCode, producer1AgentWritingCode, producer1AgentWritingCode_Percentage);
                        brokers.Add(broker);
                    }
                    if (!string.IsNullOrEmpty(producer2AgentWritingCode) && producer1AgentWritingCode.ToUpper() != "UNKNOWN")
                    {
                        var broker = GetBroker(session, policyN, cloasClientReferenceN, servicingAgentWritingCode, producer2AgentWritingCode, producer2AgentWritingCode_Percentage);
                        brokers.Add(broker);
                    }
                    if (!string.IsNullOrEmpty(producer3AgentWritingCode) && producer1AgentWritingCode.ToUpper() != "UNKNOWN")
                    {
                        var broker = GetBroker(session, policyN, cloasClientReferenceN, servicingAgentWritingCode, producer3AgentWritingCode, producer3AgentWritingCode_Percentage);
                        brokers.Add(broker);
                    }
                    if (!string.IsNullOrEmpty(producer4AgentWritingCode) && producer1AgentWritingCode.ToUpper() != "UNKNOWN")
                    {
                        var broker = GetBroker(session, policyN, cloasClientReferenceN, servicingAgentWritingCode, producer4AgentWritingCode, producer4AgentWritingCode_Percentage);
                        brokers.Add(broker);
                    }
                    if (!string.IsNullOrEmpty(producer5AgentWritingCode) && producer1AgentWritingCode.ToUpper() != "UNKNOWN")
                    {
                        var broker = GetBroker(session, policyN, cloasClientReferenceN, servicingAgentWritingCode, producer5AgentWritingCode, producer5AgentWritingCode_Percentage);
                        brokers.Add(broker);
                    }
                    if (!string.IsNullOrEmpty(producer6AgentWritingCode) && producer1AgentWritingCode.ToUpper() != "UNKNOWN")
                    {
                        var broker = GetBroker(session, policyN, cloasClientReferenceN, servicingAgentWritingCode, producer6AgentWritingCode, producer6AgentWritingCode_Percentage);
                        brokers.Add(broker);
                    }
                }

            }
            return brokers;
        }
        public IList<ServicingAgentDto> GetServicingProducers(List<string> policyNumbers)
        {
            var producers = new List<ServicingAgentDto>();
            var sessionFactory = SessionFactory.CreateSessionFactory(_configuration.DisabilityReferenceLibraryDatabaseConnection);
            using (var session = sessionFactory.OpenSession())
            {
                foreach (var policyNumber in policyNumbers)
                {
                    var producer = GetProducerForPolicy(policyNumber, session);
                    if (producer != null)
                    {
                        producers.Add(producer);
                    }
                }
            }
            return producers;
        }
        private ServicingAgentDto GetProducerForPolicy(string policyNumber, ISession session)
        {
            ServicingAgentDto producer = null;
            var queryString = "EXEC [Extract].[USP_PriorCoverageSearchProducerDetail] :@PolicyNumber";
            object[] parameters = new object[1];
            parameters[0] = policyNumber;

            var results = RunSQlQuery<object>(session, queryString, parameters).ToArray();
            if (results != null && results.Count() > 0)
            {
                object[] result = (object[])results[0];
                var policyN = result[0] != null ? result[0].ToString() : string.Empty;
                var cloasClientReferenceN = result[1] != null ? result[1].ToString() : string.Empty;
                var servicingAgentWritingCode = result[2] != null ? result[2].ToString() : string.Empty;
                if (!string.IsNullOrEmpty(servicingAgentWritingCode) && servicingAgentWritingCode.ToUpper() != "UNKNOWN")
                {
                    producer = GetBroker(session, policyN, cloasClientReferenceN, servicingAgentWritingCode, servicingAgentWritingCode, 0.0m);
                }
            }
            return producer;
        }
        private ServicingAgentDto GetBroker(ISession session, string policyN, string cloasClientReferenceN, string servicingAgentWritingCode, string writingCode, decimal producerPercentage)
        {
            var broker = new ServicingAgentDto();
            broker.PolicyNumber = policyN;
            broker.CloasClientReferenceNumber = cloasClientReferenceN;
            broker.ProducerPercent = producerPercentage;
            broker.ProducerWritingCode = writingCode;
            var agentContract = session.Query<AgentContract>().Where(a => a.ContractId == writingCode).FirstOrDefault();
            broker.AgencyCode = agentContract.Agency.PrimaryAgencyCode;
            if (agentContract.Producer.IsOrganization)
            {
                broker.ProducerName = agentContract.Producer.OrganizationName;
            }
            else
            {
                broker.ProducerName = GetBrokerName.BrokerName(agentContract.Producer.LastName, agentContract.Producer.FirstName);
                broker.LastName = agentContract.Producer.LastName;
                broker.FirstName = agentContract.Producer.FirstName;
            }
            if (servicingAgentWritingCode == writingCode)
            {
                broker.IsServicingProducer = true;
            }
            else
            {
                broker.IsServicingProducer = false;
            }
            return broker;
        }
        private IList<T> RunSQlQuery<T>(ISession session, string queryString, params object[] parameters)
        {
            IQuery query = session.CreateSQLQuery(queryString);
            if (parameters != null)
            {
                if (parameters.Length > 0)
                {
                    for (int i = 0; i < parameters.Length; i++)
                    {
                        query.SetParameter(query.NamedParameters[i], parameters[i]);
                    }
                }
            }
            return query.List<T>();
        }
    }
}