﻿using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.QueueMessagingServices;
using Guardian.Common.TIBCOConnector;
using Logger.Static;

namespace CMS.Integrations.QueueMessagingService
{
    public class GaQueueMessagingClient : IQueueMessagingClient
    {
        private readonly IConfiguration _configuration;

        public GaQueueMessagingClient(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string PullMessage()
        {
            //Log.TraceFormat("+PullMessage");

            var client = new TibcoQueueClient(
                _configuration.TibcoQueueServer,
                _configuration.TibcoQueueCredentials.UserName,
                _configuration.TibcoQueueCredentials.Password,
                _configuration.TibcoQueueFromGa);

            var gaMessage = client.PullMessage();
            
            //Log.TraceFormat("-PullMessage");
            return gaMessage;
        }

        public void PushMessage(string message)
        {
            //Log.TraceFormat("+PushMessage");

            //Log.TraceFormat("Tibco Uid: " + _configuration.TibcoQueueCredentials.UserName + 
            //    ", Pwd:" + _configuration.TibcoQueueCredentials.Password + 
            //    ", Tibcoserver: " + _configuration.TibcoQueueServer + 
            //    ", TibcoQueueToGa: " + _configuration.TibcoQueueToGa);

            var client = new TibcoQueueClient(
                _configuration.TibcoQueueServer,
                _configuration.TibcoQueueCredentials.UserName,
                _configuration.TibcoQueueCredentials.Password,
                _configuration.TibcoQueueToGa);

            client.PushMessage(message);

            //Log.TraceFormat("-PushMessage");
        }
    }
}
