﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.IndexWSServices;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Model.Entities;
using Logger.Static;
using Newtonsoft.Json;
using RestSharp;
using RestSharp.Authenticators;

namespace CMS.Integrations.IndexWSService
{
    public class IndexWSServiceClient : IIndexWSService
    {
        private readonly string _indexWSBaseUrl;      
        private readonly string _cmsServiceUsername;
        private readonly string _cmsServicePassword;

        public IndexWSServiceClient(IConfiguration configuration)
        {
            _indexWSBaseUrl = configuration.IndexWSBaseUrl;           
            _cmsServiceUsername = configuration.CMSServiceCredentials.UserName;
            _cmsServicePassword = configuration.CMSServiceCredentials.Password;
        }

        /// <summary>
        /// Creates a policy number in the NewBusiness database and sets its product type.
        /// </summary>
        /// <param name="enrollmentParticipant">An instance of the EnrollmentParticipant class.</param>
        public PolicyGenerationDto CreatePolicyNumber(EnrollmentParticipant enrollmentParticipant)
        {
            Log.Trace("+CreatePolicyNumber");

            PolicyHolder response;
            try
            {
                if (enrollmentParticipant == null) 
                    throw new ArgumentException("The parameter object 'enrollmentParticipant' is null!", nameof(enrollmentParticipant));

                var request = CreateRequest(enrollmentParticipant);

                var restRequest = new RestRequest("/disability/CreatePolicyOwner", Method.POST, DataFormat.Json);
                restRequest.AddJsonBody(JsonConvert.SerializeObject(request));
                
                var restClient = new RestClient(_indexWSBaseUrl)
                {
                    Authenticator = new HttpBasicAuthenticator(_cmsServiceUsername, _cmsServicePassword)
                };
                var restResponse = restClient.Execute(restRequest);

                response = JsonConvert.DeserializeObject<PolicyHolder>(restResponse.Content);

                //return response;
                Log.Trace("-CreatePolicyNumber");
                return  ProcessResponse(response, enrollmentParticipant);
            }
            catch (Exception e)
            {
                Log.Error("Error creating policy number!", e);
                throw;
            }

           
        }

        /// <summary>
        /// Creates the IndexWS request to create a policy number.
        /// </summary>
        /// <param name="enrollmentParticipant">An instance of the EnrollmentParticipant class.</param>
        /// <returns>An instance of the PolicyHolder class, which is the request object for the API call.</returns>
        private PolicyHolder CreateRequest(EnrollmentParticipant enrollmentParticipant)
        {
            Log.Trace("+CreateRequest");

            PolicyHolder request;
            try
            {
                request = new PolicyHolder
                {
                    FirstName = enrollmentParticipant?.Participant?.FirstName,
                    Initial = enrollmentParticipant?.Participant?.MiddleInitial,
                    LastName = enrollmentParticipant?.Participant?.LastName,
                    Suffix = enrollmentParticipant?.Participant?.Suffix,
                    DateOfBirth = enrollmentParticipant?.Participant?.DateOfBirth ?? new DateTime(1900, 1, 1),
                    TaxIDNumber = enrollmentParticipant?.Participant?.SocialSecurityNumber,
                    IsUsCitizen = enrollmentParticipant?.IsUsCitizen,
                    VisaType = enrollmentParticipant?.VisaType,
                    Agency = enrollmentParticipant?.Enrollment?.Case?.CaseBrokers.Where(i => i.AgencyCode != null)?.FirstOrDefault().AgencyCode,
                    Agent = enrollmentParticipant?.Enrollment?.Case?.CaseBrokers.Where(i => i.BrokerWritingCode != string.Empty)?.FirstOrDefault()?.BrokerWritingCode,
                    Underwriter = "204",
                    CMSID = enrollmentParticipant?.Id.ToString(),
                    CaseNumber = enrollmentParticipant?.Enrollment?.Case?.CaseNumber,
                    NoIgoApp = true,
                    IsMlPaperApplication = false,
                    IsElectronicApplication = true,
                    IsAusApplication = false,
                    Policies = new List<Policy>(),
                    PolicyRequests = new List<PolicyRequest>()
                };

                bool catAResult;
                if (bool.TryParse(enrollmentParticipant.CATa, out catAResult))
                {
                    request.CATa = catAResult;
                }

                bool catBResult;
                if (bool.TryParse(enrollmentParticipant.CATb, out catBResult))
                {
                    request.CATb = catBResult;
                }

                bool catCResult;
                if (bool.TryParse(enrollmentParticipant.CATc, out catCResult))
                {
                    request.CATc = catCResult;
                }

                bool catDResult;
                if (bool.TryParse(enrollmentParticipant.CATd, out catDResult))
                {
                    request.CATd = catDResult;
                }

                bool catEResult;
                if (bool.TryParse(enrollmentParticipant.CATe, out catEResult))
                {
                    request.CATe = catEResult;
                }

                var policyRequest = new PolicyRequest
                {
                    RequestCount = 1,
                    ProductID = 12, // default value for multi-life ProviderChoice
                    ProductLineValueText = "ProviderChoice"
                };
                request.PolicyRequests.Add(policyRequest);
            }
            catch (Exception e)
            {
                string message = "Error creating request!";
                Log.Error(message, e);
                throw;
            }

            Log.Trace("-CreateRequest");

            return request;
        }

        /// <summary>
        /// Processes the response from IndexWS.
        /// </summary>
        /// <param name="response">The response from IndexWS</param>
        /// <param name="enrollmentParticipant">The instance of the EnrollmentParticipant class that this policy number generation was for</param>
        private PolicyGenerationDto ProcessResponse(PolicyHolder response, EnrollmentParticipant enrollmentParticipant)
        {
            Log.Trace("+ProcessResponse");

            PolicyGenerationDto updateParticipantResponse = new PolicyGenerationDto();

            try
            {
                if (response == null) 
                    throw new Exception("No response returned from IndexWS!");

                if (response.Policies.Count == 0) 
                    throw new Exception($"No policy data received in response from IndexWS for enrollment participant { enrollmentParticipant.Id }");

                if (response.Policies.Count > 1) 
                    throw new Exception($"More than one policy object in response! {JsonConvert.SerializeObject(response)}");

                string policyNumber = response.Policies.FirstOrDefault()?.PolicyNumber;
                
                if (string.IsNullOrEmpty(policyNumber)) 
                    throw new Exception($"No policy number found for enrollment participant with id {enrollmentParticipant.Id}");

                Log.Debug("Updating participant in Titan...");

                 updateParticipantResponse = new PolicyGenerationDto
                {
                    EnrollmentParticipantId = enrollmentParticipant.Id,
                    PolicyNumber = policyNumber,
                    Ssn = enrollmentParticipant.Participant.SocialSecurityNumber,
                    ParticipantStatus = string.Empty,
                    SelectedOptionId = "Option 1"
                };

                Log.Trace("-ProcessResponse");                
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ProcessResponse - " + ex);

            }
            return updateParticipantResponse;
            
        }

       
    }
}
