﻿using System;
using System.Linq;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.UserProfileServices;
using Common.Exceptions;
using Guardian.Common.UserProfileService;
using Logger.Static;

namespace UserProfileService
{
    public class MockUserProfileServiceClient : IUserProfileServiceClient
    {       
        public ProfileServiceUserDto GetUserProfile(string ldapUserId)
        {           
            var profileServiceUser = new ProfileServiceUserDto
            {
                LdapUserId = ldapUserId,
                FirstName = "Mock",
                LastName = "User",
                EmailAddress = "test@glic.com",
                LdapUserGroups = new string[] { "cms_underwriter"}
            };

            return profileServiceUser;
        }
    }
}