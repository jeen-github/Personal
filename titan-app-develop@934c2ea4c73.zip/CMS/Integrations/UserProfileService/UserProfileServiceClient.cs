﻿using System;
using System.Linq;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.UserProfileServices;
using Common.Exceptions;
using Guardian.Common.UserProfileService;
using Logger.Static;

namespace UserProfileService
{
    public class UserProfileServiceClient : IUserProfileServiceClient
    {
        private readonly IConfiguration _configuration;

        public UserProfileServiceClient(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public ProfileServiceUserDto GetUserProfile(string ldapUserId)
        {
            Log.TraceFormat("+GetUserProfile ldapUserId={0}", ldapUserId);

            var userProfileServiceUserName = !string.IsNullOrEmpty(_configuration.UserProfileServiceUserName) ? 
                _configuration.UserProfileServiceUserName : _configuration.CMSServiceCredentials.UserName;
            var userProfileServicePassword = !string.IsNullOrEmpty(_configuration.UserProfileServicePassword) ? 
                _configuration.UserProfileServicePassword : _configuration.CMSServiceCredentials.Password;

            var client = new ProfileService(_configuration.UserProfileServiceUrl, _configuration.UserProfileServiceCallerId, "default",
                userProfileServiceUserName, userProfileServicePassword);

            var userProfile = client.GetUserProfile(ldapUserId);
            if (userProfile == null) throw new BusinessException("Security error!", "Unable to get the user profile from UserProfileService for ldapUserId=" + ldapUserId);
            Log.TraceFormat("UserGroups={0}", string.Join(",", userProfile.groups));

            var profileServiceUser = new ProfileServiceUserDto
            {
                LdapUserId = ldapUserId,
                FirstName = userProfile.firstName,
                LastName = userProfile.lastName,
                EmailAddress = userProfile.email,
                LdapUserGroups = userProfile.groups.Select(g => g.ToString()).ToArray()
            };

            Log.TraceFormat("-GetUserProfile ldapUserId={0}", ldapUserId);
            return profileServiceUser;
        }
    }
}