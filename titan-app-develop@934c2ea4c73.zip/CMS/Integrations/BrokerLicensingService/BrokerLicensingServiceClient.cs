﻿using System;
using System.Collections.Generic;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.BrokerLicensingServices;
using Guardian.Core.Services.ProducerLicensingService.ClientsR2;
using Logger.Static;
using Common.Exceptions;

namespace CMS.Integrations.BrokerLicensingService
{
    public class BrokerLicensingServiceClient : IBrokerLicensingServiceClient
    {
        private readonly IConfiguration _configuration;

        public BrokerLicensingServiceClient(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public BrokerLicensingValidationReponse ValidateProducerLicense(string writingCode, string stateAbbreviation, DateTime verificationDate)
        {
            Log.Debug("+ValidateProducerLicense");

            var request = CreateRequest(writingCode, null, false, stateAbbreviation,stateAbbreviation, stateAbbreviation, verificationDate, false);
            var response = ValidateLicense(request);

            Log.Debug("-ValidateProducerLicense");
            return response;
        }

        public BrokerLicensingValidationReponse ValidateCorporationLicense(string corporationWritingCode, string subProducerWritingCode, string stateAbbreviation, DateTime verificationDate)
        {
            Log.Debug("+ValidateCorporationBrokerLicense");

            var request = CreateRequest(corporationWritingCode, subProducerWritingCode, true, stateAbbreviation, stateAbbreviation, stateAbbreviation, verificationDate, true);
            var response = ValidateLicense(request);

            Log.Debug("-ValidateCorporationBrokerLicense");
            return response;
        }

        public BrokerLicensingValidationReponse ValidateSubProducerLicense(string corporationWritingCode, string subProducerWritingCode, string stateAbbreviation, DateTime verificationDate)
        {
            Log.Debug("+ValidateSubProducerLicense");

            var request = CreateRequest(corporationWritingCode, subProducerWritingCode, true, stateAbbreviation, stateAbbreviation, stateAbbreviation, verificationDate, false);
            var response = ValidateLicense(request);

            Log.Debug("-ValidateSubProducerLicense");
            return response;
        }

        public BrokerLicensingValidationReponse ValidateLicense(ProducerLicenseValidationRequest request)
        {
            Log.Debug("+ValidateBrokerLicense");

            var client = GetLawsClient();            

            ProducerLicenseValidationResponse response = null;
            try
            {
                Log.Debug("Calling LAWS service");
                response = client.ValidateProducerLicenses(request);
                Log.DebugFormat("Success calling LAWS service. StatusCode:{0} StatusDesc:{1}", response.ResponseStatusCode, response.ResponseStatusDesc);
            }
            catch (Exception ex)
            {
                Log.Debug("Error calling LAWS service " + ex.Message);
                Log.Error("Error calling LAWS service", ex);

                throw new BusinessException("LAWS Service", "Error calling LAWS service.");
            }

            var result = HandleResponse(response);

            Log.Debug("-ValidateBrokerLicense");

            return result;
        }
        
        private ValidateProducerLicenseClient GetLawsClient()
        {
            Log.Debug("+GetLAWSClient");

            ValidateProducerLicenseClient client = null;
            var serviceUrl = _configuration.LawsServiceUrl;

            if (serviceUrl.StartsWith("https"))
            {
                client = new ValidateProducerLicenseClient(_configuration.CMSServiceCredentials.UserName, _configuration.CMSServiceCredentials.Password);
                client.ConfigureForServicenetEndpoint(serviceUrl);
            }
            else
            {
                client = new ValidateProducerLicenseClient();
                client.ConfigureForHttpSoap11(serviceUrl);
            }

            Log.Debug("-GetLAWSClient");

            return client;
        }

        private ProducerLicenseValidationRequest CreateRequest(
            string agentCode, 
            string subProducerCode, 
            bool isCorporation, 
            string solicitationState,
            string contractState, 
            string residenceState, 
            DateTime applicationSignedDate,
            bool forceOrganizationValidation = false)
        {
            Log.Debug("+CreateRequest");

            var request = new ProducerLicenseValidationRequest();

            request.RequestingUser = "TitanSystem";
            request.ProductType = "DI";
            request.RequestingSystemName = "Titan";
            
            Log.DebugFormat("Agent code '{0}'", agentCode);

            request.IsCorporationWritingCode = isCorporation;

            if (request.IsCorporationWritingCode)
            {
                request.PrimaryCorporateWritingCode = agentCode;
                if (!string.IsNullOrEmpty(subProducerCode))
                {
                    request.PrimarySubProducerWritingCode = subProducerCode;
                }
                else
                {
                    if (forceOrganizationValidation)
                    {
                        request.PrimarySubProducerWritingCode = agentCode;                        
                    }
                }
            }
            else
            {
                request.PrimaryAgentWritingCode = agentCode;
            }

            request.SolicitationStateCode = solicitationState;
            request.ContractStateCode = contractState;
            request.PolicyHolderResidentStateCode = residenceState;

            request.ApplicationSignedDate = applicationSignedDate;            

            Log.Debug("-CreateRequest");

            return request;
        }

        private BrokerLicensingValidationReponse HandleResponse(ProducerLicenseValidationResponse response)
        {
            bool isLicensed = true;
            bool isAppointed = true;

            var errorMessages = new List<string>();

            foreach (WritingCodeValidationResponse validationResponse in response.WritingCodeResults)
            {
                if (validationResponse.StateType == StateType.AdditionalResidentOrSitus || validationResponse.StateType == StateType.Producer)
                    continue;

                string stateType = validationResponse.StateType + " State";
                string agentCode = validationResponse.WritingCode.Trim();
                string stateCode = validationResponse.StateCode;

                string errorMessage = string.Empty;

                if (validationResponse.ResponseType == WritingCodeResponseType.ProducerNotLicensed)
                {
                    isLicensed = false;
                    errorMessage = string.Format("License for Producer {0} is Not Found in {1} of {2}.", agentCode, stateType, stateCode);
                }
                else if (validationResponse.ResponseType == WritingCodeResponseType.ProducerSuspended)
                {
                    isLicensed = false;
                    errorMessage = string.Format("Producer {0} is Suspended.", agentCode);
                }
                else if (validationResponse.ResponseType == WritingCodeResponseType.ApplicationSignedBeforeContractEffectiveDate)
                {
                    isLicensed = false;
                    errorMessage = string.Format("Application Signed Date is before the Contract Effective Date for Producer {0}.", agentCode);
                }
                else if (validationResponse.ResponseType == WritingCodeResponseType.ApplicationSignedAfterContractTerminationDate)
                {
                    isLicensed = false;
                    errorMessage = string.Format("Application Signed Date is after the Contract Expiration Date for Producer {0}.", agentCode);
                }
                else if (validationResponse.ResponseType == WritingCodeResponseType.ApplicationSignedBeforeLicenseEffectiveDate)
                {
                    isLicensed = false;
                    errorMessage = string.Format("Application Signed Date is before the License Effective Date for Producer {0} in {1} of {2}.", agentCode, stateType, stateCode);
                }
                else if (validationResponse.ResponseType == WritingCodeResponseType.ApplicationSignedAfterLicenseTerminationDate)
                {
                    isLicensed = false;
                    errorMessage = string.Format("Application Signed Date is after the License Expiration Date for Producer {0} in {1} of {2}.", agentCode, stateType, stateCode);
                }
                else if (validationResponse.ResponseType == WritingCodeResponseType.AppointmentPending)
                {
                    isAppointed = false;
                    errorMessage = string.Format("Appointment is pending for Producer {0} in {1} of {2}. Please note that the policy will not issue until appointment occurs.", agentCode, stateType, stateCode);
                }
                else if (validationResponse.ResponseType == WritingCodeResponseType.ApplicationSignedBeforeAppointmentEffectiveDate)
                {
                    isAppointed = false;
                    errorMessage = string.Format("Application Signed Date is before the Appointment Effective Date for Producer {0} in {1} of {2}. Please note that the policy will not issue until appointment occurs.", agentCode, stateType, stateCode);
                }
                else if (validationResponse.ResponseType == WritingCodeResponseType.ApplicationSignedAfterAppointmentTerminationDate)
                {
                    isAppointed = false;
                    errorMessage = string.Format("Application Signed Date is after the Appointment Termination Date for Producer {0} in {1} of {2}. Please note that the policy will not issue until appointment occurs.", agentCode, stateType, stateCode);
                }
                else if ((int)validationResponse.ResponseType == 1201 || (int)validationResponse.ResponseType == 1270) // Invalid Corp Broker/Subproducer Writing Code AND Corp Brokers Require a Primary Writing Agent
                {
                    isLicensed = false;
                    errorMessage = string.Format("A valid Sub Producer must be identified before you can continue.");
                }
                else if ((int)validationResponse.ResponseType == 1251 ) // Invalid Corp Broker/Subproducer Writing Code AND Corp Brokers Require a Primary Writing Agent
                {
                    isLicensed = false;
                    errorMessage = string.Format("LAWS Serivce resonse code {0} , {1}", validationResponse.ResponseCode, validationResponse.ResponseMessage);
                }
                else if (validationResponse.ResponseType != WritingCodeResponseType.ValidationSuccessful)
                {
                    isLicensed = false;
                    errorMessage = string.Format("The Producer with the writing code {0} has failed validation with the following response code: {1}.", agentCode, validationResponse.ResponseMessage.ToString());
                }

                if (!string.IsNullOrEmpty(errorMessage))
                {
                    errorMessages.Add(errorMessage);
                }                
            }

            return new BrokerLicensingValidationReponse
            {
                IsLicensed = isLicensed,
                IsAppointed = isLicensed != false && isAppointed,
                Messages = errorMessages
            };
        }
    }
}
