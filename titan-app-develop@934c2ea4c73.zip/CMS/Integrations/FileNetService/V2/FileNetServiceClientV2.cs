﻿using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.FileNetDocumentRepositories;
using Common.Exceptions;
using FileNetWebServices;
using FileNetWebServices.Model;
using FileNetWebServices.Services;
using Glic.Filenetapiclient;
using Glic.Filenetapiclient.Models;
using Glic.Filenetapiclient.Models.Request;
using Glic.Filenetapiclient.Models.Response;
using Glic.Filenetapiclient.Models.SubClasses;
using Guardian.Core.Services.FileNetWebServiceClient.FnAddSinglePageDocument;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using SearchFilter = FileNetWebServices.Model.SearchFilter;
using SearchFilterV2 = Glic.Filenetapiclient.Models.SubClasses.SearchFilter;

namespace CMS.Integrations.FileNetDocumentRepositories
{
    public partial class FileNetServiceClientV2 : IFileNetDocumentRepository
    {   
        private const string FileNetApplication = "TITAN";      
        private const string ServiceResponseSuccessStatus = "success";
        private readonly IConfiguration _configuration;

        private string FileNetRequestString
        {
            get { return string.Format("TITAN-{0}", DateTime.Now.Ticks); }
        }

        public FileNetServiceClientV2(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public FileNetDocDownloadResponse DownloadDocument(FileNetDocDownloadRequest request)
        {
            Log.TraceFormat("+NewFileNet DownloadDocument");

            FileNetDocDownloadResponse response = new FileNetDocDownloadResponse();
            string newGuidFilenetId = string.Empty;           

            Log.Trace("+NewFileNet DownloadDocument: FileNetRequestId: " + FileNetRequestString + "; ClientId: " + "; FileNetDocId: " + request.OldDocumentId);

            var newClient = new FilenetApiClient(_configuration.NewFileNetWebServiceUrl, _configuration.FileNetServiceCredentials.UserName, _configuration.FileNetServiceCredentials.Password);

            if (string.IsNullOrEmpty(request.NewDocumentId)  && request.OldDocumentId > 0)
            {
                newGuidFilenetId = newClient.GetNewDocIdFromOldDocId(request.OldDocumentId, DocumentClasses.DisabilityML);

                if (newGuidFilenetId == null)
                {
                    Log.Trace("+NewFileNet DownloadDocument: NewFileNet document Id not found for the Old document id " + request.OldDocumentId);
                    throw new Exception("Error : NewFileNet document Id not found for the Old document id " + request.OldDocumentId);
                }
                else
                {
                    Log.Trace("+NewFileNet DownloadDocument document found for, Old FilenetId: " + request.OldDocumentId + ", New Document FilenetId: " + newGuidFilenetId);
                }
            } 
            else
            {
                newGuidFilenetId = request.NewDocumentId;
               
            }

            FilenetGetContentRequest newRequest = new FilenetGetContentRequest
            {
                ContentRequestInfo = new ContentRequestInfo
                {
                    Annotations = request.WithAnnotations,
                    DocumentId = newGuidFilenetId,
                    EndPageNumber = int.MaxValue,
                    StartPageNumber = 0
                }
            };

            var contentResponse = newClient.GetContent(newRequest);
            response = new FileNetDocDownloadResponse
            {
                NewFileNetDocumentId = contentResponse.DocumentInfo.DocumentId,
                ContentMimeType = contentResponse.DocumentInfo.ContentInfoList.FirstOrDefault().MimeType,                
                Content = System.Convert.FromBase64String(contentResponse.DocumentInfo.ContentInfoList.FirstOrDefault().ContentBytes)
        };

            Log.TraceFormat("-NewFileNet DownloadDocument");
            return response;
        }

        public FileNetDocUploadResponse UploadDocument(FileNetDocUploadRequest request)
        {
            Log.TraceFormat("+NewFileNet UploadDocument DocName={0} DocType={1} CaseNumber={2} DocContentType={3}",
                request.DocumentName, request.DocumentType, request.DocumentType, request.ContentType);

            if (string.IsNullOrEmpty(request.CaseNumber)) throw new ValidationException("CaseNumber is required");
            if (string.IsNullOrEmpty(request.DocumentName)) throw new ValidationException("DocumentName is required");

            var clientV2 = new FilenetApiClient(_configuration.NewFileNetWebServiceUrl, _configuration.FileNetServiceCredentials.UserName, _configuration.FileNetServiceCredentials.Password);

            FilenetAddOrUpdateRequest uploadfile = new FilenetAddOrUpdateRequest
            {
                DocumentInfo = new DocumentInfo
                {
                    DocumentClass = DocumentClasses.DisabilityML,                   
                    PropertyList = new List<Property>
                    {
                        new Property { Name = IndexFields.InputSource, Values =  new List<string> { FileNetApplication } },                        
                        new Property { Name = IndexFields.ScanDate, Values =   new List<string> { DateTime.Now.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture) } },
                        new Property { Name = IndexFields.CaseNumber, Values =  new List<string> { request.CaseNumber } },
                        new Property { Name = IndexFields.DocumentType, Values =  new List<string> { request.DocumentType.ToString() } }
                    },

                    ContentInfoList = new List<ContentInfo>
                    {
                        new ContentInfo
                            {                             
                                ContentName = request.DocumentName,
                                ContentBytes = Convert.ToBase64String(request.DocumentBytes),
                                MimeType = request.FileMimeType,                                
                                PageNumber = 0
                           }
                    }
                },
            };

            var response = clientV2.Add(uploadfile);

            if (response == null || response.StatusInfo == null) throw new ApplicationException("Null response or statusInfo returned");
            if (response.StatusInfo.Status != ServiceResponseSuccessStatus)
                throw new ApplicationException(string.Format("ERROR uploading document to FileNet. Message:{0}", response.StatusInfo.StatusMessage));

            Log.TraceFormat("-NewFileNet UploadDocument DocName={0} DocType={1} CaseNumber={2} DocContentType={3}",
                request.DocumentName, request.DocumentType, request.DocumentType, request.ContentType);

            return new FileNetDocUploadResponse(response.DocumentId);
        }

       

        public string UploadDocumentToNewBusinessRepository(FileNetNewBusinessDocUploadRequest request)
        {

            Log.TraceFormat("+NewFileNet UploadDocumentToNewBusinessRepository CaseNumber={0} PolicyNumber={1} ParticipantLastName={2} ParticipantFirstName={3}",
               request.CaseNumber, request.PolicyNumber, request.ParticipantLastName, request.ParticipantFirstName);

            byte[] documentBytes = Encoding.UTF8.GetBytes(request.DocumentText);

            var clientV2 = new FilenetApiClient(_configuration.NewFileNetWebServiceUrl, _configuration.FileNetServiceCredentials.UserName, _configuration.FileNetServiceCredentials.Password);

            FilenetAddOrUpdateRequest uploadfile = new FilenetAddOrUpdateRequest
            {
                DocumentInfo = new DocumentInfo
                {
                    DocumentClass = DocumentClasses.ToFileSecure,
                    PropertyList = new List<Property>
                    {
                        new Property { Name = IndexFields.DocumentType, Values =  new List<string> { "Policy Decision"} },
                        new Property { Name = IndexFields.InputSource, Values =  new List<string> { FileNetApplication } },
                        new Property { Name = IndexFields.FormNumber, Values =   new List<string> { request.CaseNumber } },
                        new Property { Name = IndexFields.CaseNumber, Values =  new List<string> { request.CaseNumber } },
                        new Property { Name = IndexFields.PolicyNumber, Values =  new List<string> { request.PolicyNumber } },
                        new Property { Name = IndexFields.LastName, Values =  new List<string> { request.ParticipantLastName } },
                        new Property { Name = IndexFields.FirstName, Values =  new List<string> { request.ParticipantFirstName }, },                        
                        new Property { Name = IndexFields.ScanDate, Values =   new List<string> { DateTime.Now.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture) } }
                    },

                    ContentInfoList = new List<ContentInfo>
                    {
                        new ContentInfo
                        {   
                            ContentBytes = Convert.ToBase64String(documentBytes),
                            MimeType =  "text/txt",                            
                        }
                    }
                },
            };

            var response = clientV2.Add(uploadfile);

            if (response == null || response.StatusInfo == null) throw new ApplicationException("Null response or statusInfo returned");
            if (response.StatusInfo.Status.ToUpper() != ServiceResponseSuccessStatus.ToUpper())
                throw new ApplicationException(string.Format("ERROR uploading document to FileNet. Message:{0}", response.StatusInfo.StatusMessage));

            Log.TraceFormat("-NewFileNet UploadDocumentToNewBusinessRepository CaseNumber={0} PolicyNumber={1} ParticipantLastName={2} ParticipantFirstName={3}",
             request.CaseNumber, request.PolicyNumber, request.ParticipantLastName, request.ParticipantFirstName);

            return response.DocumentId;
        }

        public List<FileNetDocSearchResponse> DocumentSearch(FileNetDocSearchRequest request)
        {
            Log.TraceFormat("+NewFileNet NewDocumentSearch"); 

            var newClient = new FilenetApiClient(_configuration.NewFileNetWebServiceUrl, _configuration.FileNetServiceCredentials.UserName, _configuration.FileNetServiceCredentials.Password);

            FilenetSearchRequest searchRquest = new FilenetSearchRequest
            {
                SearchInfo = new SearchInfo
                {
                    DocumentClasses = new List<string> { DocumentClasses.DisabilityML },
                    SearchFilters = CreateSearchFiltersV2(request),
                    SelectFields = CreateFieldNamesV2(request)
                },
            };

            var searchResponse = newClient.Search(searchRquest);

            var documentMedatas = new List<FileNetDocSearchResponse>();

            foreach (var searchResult in searchResponse.SearchResults.SearchRecordList)
            {
                var documentMetadata = new FileNetDocSearchResponse { NewDocumentId = searchResult.DocumentId };

                var documentTypeIndexField = searchResult.PropertyList.FirstOrDefault(f => f.Name == IndexFields.DocumentType);
                documentMetadata.DocumentType = documentTypeIndexField != null && documentTypeIndexField.Values.Count > 0? documentTypeIndexField.Values[0] : string.Empty;

                var documentNameIndexField = searchResult.PropertyList.FirstOrDefault(f => f.Name == IndexFields.DocumentName);
                documentMetadata.DocumentName = documentNameIndexField != null && documentNameIndexField.Values.Count > 0 ? documentNameIndexField.Values[0] : string.Empty;

                documentMedatas.Add(documentMetadata);
            }

            Log.TraceFormat("-NewFileNet NewDocumentSearch");
            return documentMedatas;
        }

        private List<SearchFilterV2> CreateSearchFiltersV2(FileNetDocSearchRequest request)
        {
            Log.TraceFormat("+NewFileNet CreateSearchFiltersV2");
            var filters = new List<SearchFilterV2>();

            if (!string.IsNullOrEmpty(request.CaseNumber))
                filters.Add(new SearchFilterV2 { PropertyName = IndexFields.CaseNumber, PropertyValues = new List<string> { request.CaseNumber }, Operator = SearchFilterOperators.Equal });

            if (!string.IsNullOrEmpty(request.DocumentType))
                filters.Add(new SearchFilterV2 { PropertyName = IndexFields.DocumentType, PropertyValues = new List<string> { request.DocumentType }, Operator = SearchFilterOperators.Equal });
                        
            if (!string.IsNullOrEmpty(request.DocumentName))
                filters.Add(new SearchFilterV2 { PropertyName = IndexFields.DocumentName, PropertyValues = new List<string> { request.DocumentName }, Operator = SearchFilterOperators.Equal });

            Log.TraceFormat("-NewFileNet CreateSearchFiltersV2");

            return filters;
        }

        private List<string> CreateFieldNamesV2(FileNetDocSearchRequest request)
        {
            var fieldNames = new List<string>() { IndexFields.CaseNumber, IndexFields.DocumentType, IndexFields.DocumentName };
            return fieldNames;
        }

        public FileNetDocUploadResponse UploadDocumentToNBApps(FileNetDocUploadRequest request)
        {
            Log.TraceFormat("+NewFileNet UploadDocument DocName={0} DocType={1} CaseNumber={2} DocContentType={3}",
                request.DocumentName, request.DocumentType, request.DocumentType, request.ContentType);

            if (string.IsNullOrEmpty(request.CaseNumber)) throw new ValidationException("CaseNumber is required");
            if (string.IsNullOrEmpty(request.DocumentName)) throw new ValidationException("DocumentName is required");

            var clientV2 = new FilenetApiClient(_configuration.NewFileNetWebServiceUrl, _configuration.FileNetServiceCredentials.UserName, _configuration.FileNetServiceCredentials.Password);

            FilenetAddOrUpdateRequest uploadfile = new FilenetAddOrUpdateRequest
            {
                DocumentInfo = new DocumentInfo
                {
                    DocumentClass = DocumentClasses.NBApps,
                    PropertyList = new List<Property>
                    {
                        new Property { Name = IndexFields.InputSource, Values =  new List<string> { FileNetApplication } },
                        new Property { Name = IndexFields.ScanDate, Values =   new List<string> { DateTime.Now.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture) } },
                        new Property { Name = IndexFields.CaseNumber, Values =  new List<string> { request.CaseNumber } },
                        new Property { Name = IndexFields.DocumentType, Values =  new List<string> { request.DocumentType.ToString() } },
                        new Property { Name = IndexFields.LastName, Values =  new List<string> { request.ParticipantLastName } },
                        new Property { Name = IndexFields.FirstName, Values =  new List<string> { request.ParticipantFirstName }, },
                        new Property { Name = IndexFields.PolicyNumber, Values =  new List<string> { request.PolicyNumber }, },
                        new Property { Name = IndexFields.AgencyCode, Values =  new List<string> { request.AgencyCode }, },
                        new Property { Name = IndexFields.SSN, Values =  new List<string> { request.SSN }, },
                        new Property { Name = IndexFields.InputSource, Values =  new List<string> { FileNetApplication } },
                        new Property { Name = IndexFields.FormNumber, Values =   new List<string> { request.CaseNumber } },
                        new Property { Name = "UserID", Values =   new List<string> { request.GeneratedBy } },
                        new Property { Name = IndexFields.VendorCode, Values =   new List<string> { "OSE" } },
                        new Property { Name = IndexFields.ExternalDocumentId, Values =   new List<string> { request.EnrollmentParticipantId.ToString() } },
                        new Property { Name = IndexFields.GroupId, Values =   new List<string> { "ML" } },
                        new Property { Name = IndexFields.Indexer, Values =   new List<string> { "TTN"} },
                    },

                    ContentInfoList = new List<ContentInfo>
                    {
                        new ContentInfo
                            {
                                ContentName = request.DocumentName,
                                ContentBytes = Convert.ToBase64String(request.DocumentBytes),
                                MimeType = request.FileMimeType,
                                PageNumber = 0
                           }
                    }
                },
            };

            var response = clientV2.Add(uploadfile);

            if (response == null || response.StatusInfo == null) throw new ApplicationException("Null response or statusInfo returned");
            if (response.StatusInfo.Status != ServiceResponseSuccessStatus)
                throw new ApplicationException(string.Format("ERROR uploading document to FileNet. Message:{0}", response.StatusInfo.StatusMessage));

            Log.TraceFormat("-NewFileNet UploadDocument DocName={0} DocType={1} CaseNumber={2} DocContentType={3}",
                request.DocumentName, request.DocumentType, request.DocumentType, request.ContentType);

            return new FileNetDocUploadResponse(response.DocumentId);
        }

        public bool UpdateExistingFileNetDocument(FileNetDocUploadRequest request)
        {
            Log.TraceFormat("+UpdateExistingFileNetDocument FilenetDocumentId={0} PolicyNUmber={1}",
                            request.FileNetDocumentId, request.PolicyNumber);

            var clientV2 = new FilenetApiClient(_configuration.NewFileNetWebServiceUrl, _configuration.FileNetServiceCredentials.UserName, _configuration.FileNetServiceCredentials.Password);
            bool response = false;

            FilenetAddOrUpdateRequest updateFileRequest = new FilenetAddOrUpdateRequest
            {
                DocumentInfo = new DocumentInfo
                {
                    DocumentId = request.FileNetDocumentId,
                    DocumentClass = DocumentClasses.NBApps,
                    PropertyList = new List<Property>
                    {   
                        new Property { Name = IndexFields.CaseNumber, Values =  new List<string> { request.CaseNumber } },
                        new Property { Name = IndexFields.DocumentType, Values =  new List<string> { request.DocumentType.ToString() } },
                        new Property { Name = IndexFields.LastName, Values =  new List<string> { request.ParticipantLastName } },
                        new Property { Name = IndexFields.FirstName, Values =  new List<string> { request.ParticipantFirstName }, },
                        new Property { Name = IndexFields.PolicyNumber, Values =  new List<string> { request.PolicyNumber }, },
                        new Property { Name = IndexFields.AgencyCode, Values =  new List<string> { request.AgencyCode }, },
                        new Property { Name = IndexFields.SSN, Values =  new List<string> { request.SSN }, },
                        new Property { Name = IndexFields.ScanDate, Values =   new List<string> 
                                        { DateTime.Now.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture) } },
                        new Property { Name = IndexFields.InputSource, Values =  new List<string> { FileNetApplication } },
                        new Property { Name = IndexFields.FormNumber, Values =   new List<string> { request.CaseNumber } },
                        new Property { Name = "UserID", Values =   new List<string> { request.GeneratedBy } },
                        new Property { Name = IndexFields.VendorCode, Values =   new List<string> { "OSE" } },
                        new Property { Name = IndexFields.ExternalDocumentId, Values =   new List<string> { request.EnrollmentParticipantId.ToString() } },
                        new Property { Name = IndexFields.GroupId, Values =   new List<string> { "ML" } },
                        new Property { Name = IndexFields.Indexer, Values =   new List<string> { "TTN"} },
                    }                  
                },
            };

            var filenetResponse = clientV2.Update(updateFileRequest);

            if (filenetResponse == null || filenetResponse.StatusInfo == null)
            {                
                throw new ApplicationException("Null response or statusInfo returned");
            }
            if (filenetResponse.StatusInfo.Status != ServiceResponseSuccessStatus)
            {                
                throw new ApplicationException(string.Format("ERROR updating document to FileNet. Message:{0}", filenetResponse.StatusInfo.StatusMessage));
            }

            response = true;

            Log.TraceFormat("-UpdateExistingFileNetDocument");

            return response;
            
        }

        public void UpdateDocumentMetadata(FileNetDocSearchResponse documentMedata)
        {
            throw new NotImplementedException();
        }
    }
}

