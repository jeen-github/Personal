﻿using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.PremiumCalculationServices;
using CMS.Interfaces.Integrations.PremiumCalculationServices.ServiceContracts;
using Common.Utilities;
using Logger.Static;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CMS.Integrations.PremiumCalculationService
{
    public class PremiumCalculationServiceClient : IPremiumCalculationService
    {
        private readonly IConfiguration _configuration;

        public PremiumCalculationServiceClient(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<PremiumCalculationResponseList> Calculate(PremiumCalculationRequestList premiumCalculationRequests)
        {
            Log.TraceFormat("+Calculate Url={0}", _configuration.CMSCalculationServiceBaseUrl);

            var calculationsPerRequest = GetCalculationsPerRequest(premiumCalculationRequests);
            var groupedRequests = SplitRequests(premiumCalculationRequests, calculationsPerRequest);

            var tasks = new List<Task<PremiumCalculationResponseList>>();
            foreach (var groupedRequest in groupedRequests)
            {
                var serviceRestClient = new RestServiceClient(
                    $"{_configuration.CMSCalculationServiceBaseUrl}/calculate",
                    _configuration.CMSCalculationServiceCredentials.UserName,
                    _configuration.CMSCalculationServiceCredentials.Password
                );
                var task = serviceRestClient.ExecuteAsync<PremiumCalculationRequestList, PremiumCalculationResponseList>(groupedRequest);
                tasks.Add(task);
            }
            await Task.WhenAll(tasks);

            var response = new PremiumCalculationResponseList();
            foreach (var task in tasks)
            {
                response.CalculationResponses.AddRange(task.Result.CalculationResponses);
                response.CalculationTimeInSeconds += task.Result.CalculationTimeInSeconds;
            }

            Log.TraceFormat("-Calculate");
            return response;
        }

        private List<PremiumCalculationRequestList> SplitRequests(PremiumCalculationRequestList premiumCalculationRequests, int calculationsPerRequest)
        {
            var groupedRequests = new List<PremiumCalculationRequestList>();
            var calcRequest = new PremiumCalculationRequestList();

            for (var i = 0; i < premiumCalculationRequests.CalculationRequests.Count; i++)
            {
                if (i % calculationsPerRequest == 0)
                {
                    calcRequest = new PremiumCalculationRequestList();
                    groupedRequests.Add(calcRequest);
                }

                calcRequest.CalculationRequests.Add(premiumCalculationRequests.CalculationRequests[i]);
            }

            return groupedRequests;
        }

        private int GetCalculationsPerRequest(PremiumCalculationRequestList premiumCalculationRequests)
        {
            var totalCalculations = premiumCalculationRequests.CalculationRequests.Count;
            var minCalculations = _configuration.PremiumCalculationsPerRequestMin;
            var maxCalculations = _configuration.PremiumCalculationsPerRequestMax;
            var factor = _configuration.PremiumCalculationsPerRequestFactor;

            if (totalCalculations <= minCalculations) return totalCalculations;

            var calculationsPerRequest = totalCalculations / factor;
            if (calculationsPerRequest >= maxCalculations) return maxCalculations;

            return calculationsPerRequest;
        }

        public async Task<dynamic> Lookup()
        {
            var serviceRestClient = new RestServiceClient(
                $"{_configuration.CMSCalculationServiceBaseUrl}/lookups",
                _configuration.CMSCalculationServiceCredentials.UserName,
                _configuration.CMSCalculationServiceCredentials.Password
            );

            return await serviceRestClient.GetAsync<dynamic>();
        }
    }
}
