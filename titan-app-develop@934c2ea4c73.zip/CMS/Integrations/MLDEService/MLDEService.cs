﻿using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.MLDEServices;
using CMS.Interfaces.Managers.ImplementationManagers;
using Guardian.Mlde.Api.Models.ViewModels;
using Guardian.Mlde.Api.Models.ViewModels.Census;
using Logger.Static;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using RestSharp.Authenticators;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CMS.Integrations.MLDEService
{
    public class MLDEService : IMLDEService
    {
        private readonly string _mldeApiUrl;
        private readonly string _apigeeOAuthTokenUrl;
        private readonly string _mldeUserName;
        private readonly string _mldePassword;
        private readonly IConfiguration _configuration;

        public MLDEService(IConfiguration configuration)
        {
            _configuration = configuration;
            _apigeeOAuthTokenUrl = _configuration.ApigeeOAuthTokenUrl;
            _mldeApiUrl = _configuration.MLDEApiBaseUrl;
            _mldeUserName = _configuration.MLDECredentials.UserName;
            _mldePassword = _configuration.MLDECredentials.Password;
        }

        public MLDEResponse SendCaseData(CaseViewModel request)
        {
            Log.Trace("+MLDEService.SendCaseData");

            var oAuthToken = GetOAuthToken();

            RestClient restClient = new RestClient(_mldeApiUrl);
            var restRequest = new RestRequest("/v1/case", Method.PUT);
            restRequest.AddHeader("Authorization", $"Bearer {oAuthToken.AccessToken}");
            restRequest.AddJsonBody(JsonConvert.SerializeObject(request));

            var response = restClient.Execute(restRequest);
            var mldeResponse = JsonConvert.DeserializeObject<MLDEResponse>(response.Content);

            Log.Trace("-MLDEService.SendCaseData");

            return mldeResponse;
        }
       

        public async Task<List<int>> GetMLDEParticipants(string caseNumber)
        {
            Log.Trace("+MLDEService.GetMLDEParticipants");

            var oAuthToken = GetOAuthToken();

            RestClient restClient = new RestClient(_mldeApiUrl);
            var restRequest = new RestRequest("/v1/censusdata/getcaseparticipants?caseNumber="+ caseNumber, Method.GET);
            restRequest.AddHeader("Authorization", $"Bearer {oAuthToken.AccessToken}");
           
            var response = await restClient.ExecuteAsync(restRequest);
            Log.Trace($"MLDEService.GetMLDEParticipants MLDEAPI Response status: {response.StatusCode} for CaseNumber:'{caseNumber}'");
            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError || response.IsSuccessful == false)
            {
                Log.Error($"MLDEService.GetMLDEParticipants - Error calling MLDE API for GetMLDEParticipants for CaseNumber: '{caseNumber}'. Response:{response.Content}");
                return null;
            }            
            JObject json = JObject.Parse(response.Content);
            List<int> enrollmentParticipants = JsonConvert.DeserializeObject<List<int>>(json["Data"].ToString());                  
            Log.Trace("-MLDEService.GetMLDEParticipants");            
            return enrollmentParticipants;
        }

        public MLDEResponse SendCensusData(CensusDataViewModel request)
        {
            Log.Trace("+MLDEService.SendCensusData");

            var oAuthToken = GetOAuthToken();

            RestClient restClient = new RestClient(_mldeApiUrl);
            var restRequest = new RestRequest("/v1/censusdata", Method.POST);
            restRequest.AddHeader("Authorization", $"Bearer {oAuthToken.AccessToken}");
            restRequest.AddJsonBody(JsonConvert.SerializeObject(request));
            
            var response = restClient.Execute(restRequest);
            Log.Trace($"MLDEService.SendCensusData MLDEAPI Response status: {response.StatusCode} for CMSCode:'{request.CMSCode}'");
            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError || response.IsSuccessful==false)
            {
                Log.Error($"MLDEService.SendCensusData - Error calling MLDE API for censusdata Case upload for CMSCode: '{request.CMSCode}'. Response:{response.Content}");
                throw new System.Exception($"Error calling MLDE API for censusdata Case upload for CMSCode: '{request.CMSCode}' & Response status: {response.StatusCode}.");
            }
            var mldeResponse = JsonConvert.DeserializeObject<MLDEResponse>(response.Content);

            Log.Trace("-MLDEService.SendCensusData");

            return mldeResponse;
        }

        public OAuthToken GetOAuthToken()
        {
            Log.Trace("+MLDEService.GetOAuthToken");

            if (string.IsNullOrWhiteSpace(_apigeeOAuthTokenUrl))
            {
                return new OAuthToken();
            }

            var restClient = new RestClient(_apigeeOAuthTokenUrl)
            {
                Authenticator = new HttpBasicAuthenticator(_mldeUserName, _mldePassword)
            };
            var restRequest = new RestRequest(Method.POST);

            var restResponse = restClient.Execute(restRequest);
            var response = JsonConvert.DeserializeObject<OAuthToken>(restResponse.Content);

            Log.Trace("-MLDEService.GetOAuthToken");

            return response;
        }

        public bool SendEnrollmentData(PatchViewModelV2 request)
        {
            Log.Trace($"+MLDEService.SendEnrollmentData EnrollmentId: '{request.ObjectIdValue}'");
            var oAuthToken = GetOAuthToken();
            
            RestClient restClient = new RestClient(_mldeApiUrl);
            var restRequest = new RestRequest("/v2/case", Method.PATCH);
            restRequest.AddHeader("Authorization", $"Bearer {oAuthToken.AccessToken}");
            restRequest.AddJsonBody(JsonConvert.SerializeObject(request));

            var response = restClient.Execute(restRequest);
            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError || response.IsSuccessful == false)
            {
                Log.Error($"MLDEService.SendEnrollmentData - Error calling MLDE API for sendEnrollmentData for EnrollmentId: '{request.ObjectIdValue}'. Response:{response.Content}");
                
                return false;
            }
           
            Log.Trace("-MLDEService.SendEnrollmentData");

            return true;
        }


    }
}
