﻿using System;
using System.Collections.Generic;
using System.Net;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.ProductLibraryServices;
using Common.Exceptions;
using Logger.Static;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using RestSharp.Authenticators;

namespace CMS.Integrations.ProductLibraryService
{
    public class ProductLibraryWebServiceClient : IProductLibraryWebServiceClient
    {
        /// <summary>
        ///     Base URL for product library
        /// </summary>
        public static string ProductLibraryApiBaseUrl { get; set; }

        private readonly IConfiguration _configuration;

        public ProductLibraryWebServiceClient(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        public List<TablePremiumSeriesResponse> GetTablePremiumSeriesCode(TablePremiumSeriesRequest request)
        {
            Log.Debug("+GetTablePremiumSeriesCode");

            IRestResponse locatorResponse = null;

            var locatorRestClient = GetLocatorRestClient();

            var locatorRestRequest = CreateTablePremiumSeriesRequest(request);

            try
            {
                Log.Debug("Calling Locator service");
                locatorResponse = locatorRestClient.Execute(locatorRestRequest);
                Log.DebugFormat($"Success calling Locator service. StatusCode: {locatorResponse.StatusCode } StatusDesc: {locatorResponse.StatusDescription}");

            }
            catch (Exception ex)
            {
                Log.ErrorFormat($"Error calling Locator Web Service. Exception {ex} Request: {locatorRestRequest}");
                throw;
            }
            
            // TODO: Need to handle some handling for status codes, like not found. 
            //TODO: Store status to database. Throw new ex  

            List<TablePremiumSeriesResponse> locatorReturnedResponse;
            if (locatorResponse.StatusCode == HttpStatusCode.OK)
            {
                
                try
                {
                    var locatorResponseOk = (JObject)JsonConvert.DeserializeObject(locatorResponse.Content);
                    locatorReturnedResponse = JsonConvert.DeserializeObject<List<TablePremiumSeriesResponse>>(locatorResponseOk["Data"].ToString());
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat($"Error deserializing Locator Web Service response. Content = {locatorResponse.Content}");
             
                    throw new Exception($"Error deserializing Locator Web Service response. Exception: {ex} Content:  {locatorResponse.Content}"); 
                }
               
            }
            else
            {
                throw new Exception($"Invalid HTTP Status Code { locatorResponse.StatusCode }.  Http Response Content { locatorResponse.Content }");
            }


            Log.Debug("-GetTablePremiumSeriesCode");

            return locatorReturnedResponse;
        }


        public List<PlanCodeResults> LookupPlanCode(PlanCodeRequest request)
        {
            Log.Debug("+GetPlaneCode");

            IRestResponse locatorResponse = null;

            var locatorRestClient = GetLocatorRestClient();

            var locatorRestRequest = new RestRequest("/plancode", Method.GET);

            locatorRestRequest.AddQueryParameter("productVariantAssociationID",
                request.ProductVariantAssociationID.ToString());
            locatorRestRequest.AddQueryParameter("stateTypeID", request.StateTypeID.ToString());
            locatorRestRequest.AddQueryParameter("EndoresedGroupIndicator", request.EndorsedGroupOptionIndicator.ToString());

            try
            {
                Log.Debug("Calling Locator service");
                locatorResponse = locatorRestClient.Execute(locatorRestRequest);
                Log.DebugFormat($"Success calling Locator service. StatusCode: {locatorResponse.StatusCode } StatusDesc: {locatorResponse.StatusDescription}");

            }
            catch (Exception ex)
            {
                Log.ErrorFormat($"Error calling Locator Web Service. Exception {ex} Request: {locatorRestRequest}");
                throw;
            }

            // TODO: Need to handle some handling for status codes, like not found. 
            //TODO: Store status to database. Throw new ex  

            List<PlanCodeResults> locatorReturnedResponse;
            if (locatorResponse.StatusCode == HttpStatusCode.OK)
            {

                try
                {
                    var locatorResponseOk = (JObject)JsonConvert.DeserializeObject(locatorResponse.Content);
                    locatorReturnedResponse = JsonConvert.DeserializeObject<List<PlanCodeResults>>(locatorResponseOk["Data"].ToString());
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat($"Error deserializing Locator Web Service response. Content = {locatorResponse.Content}");

                    throw new Exception($"Error deserializing Locator Web Service response. Exception: {ex} Content:  {locatorResponse.Content}");
                }

            }
            else
            {
                throw new Exception($"Invalid HTTP Status Code { locatorResponse.StatusCode }.  Http Response Content { locatorResponse.Content }");
            }


            Log.Debug("-GetPlaneCode");

            return locatorReturnedResponse;
        }

        public static RestRequest CreateTablePremiumSeriesRequest(TablePremiumSeriesRequest request)
        {
            Log.Debug("+CreateLocatorRequest");

            var locatorRestRequest = new RestRequest("/tblpx", Method.GET);

            locatorRestRequest.AddQueryParameter("productVariantAssociationID",
                request.ProductVariantAssociationID.ToString());
            locatorRestRequest.AddQueryParameter("stateTypeID", request.StateTypeID.ToString());

            foreach (var benefit in request.Benefits)
            {
                locatorRestRequest.AddQueryParameter("benefits", benefit.ToString());
            }

            Log.Debug("-CreateLocatorRequest");

            return locatorRestRequest;
        }

        public RestClient GetLocatorRestClient() 
        {
            Log.Debug("+GetLocatorRestClient");

            var locatorRestClient = new RestClient
            {
                BaseUrl = new Uri(_configuration.LocatorWebServiceUrl),
                Authenticator = new HttpBasicAuthenticator(
                    _configuration.CMSServiceCredentials.UserName,
                    _configuration.CMSServiceCredentials.Password)
            };

            Log.Debug("GetLocatorRestClient");

            return locatorRestClient;
        }
    }
}