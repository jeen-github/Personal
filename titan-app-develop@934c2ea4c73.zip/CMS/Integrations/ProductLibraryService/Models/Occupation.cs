﻿using FluentNHibernate.Mapping;
using Guardian.Core.Entities.Product;

namespace CMS.Integrations.ProductLibraryService.Models
{
    public class OccupationMap : ClassMap<Occupation>
    {
        public OccupationMap()
        {
            MapEntity();
        }

        public void MapEntity()
        {
            ReadOnly();
            Schema("DisabilityProduct");
            Table("OccupationType");

            Id(x => x.Id, "OccupationTypeId");

            Map(x => x.Code, "Code");
            Map(x => x.Description, "DescriptionText");
            Map(x => x.DisplayName, "DisplayName");
            Map(x => x.IsActive, "ActiveIndicator");
            Map(x => x.PrimaryGroup, "PrimaryGroup");
            Map(x => x.SecondaryGroup, "SecondaryGroup");
            Map(x => x.SortOrder, "SortOrderNumber");
            Map(x => x.Value, "ValueText");
        }
    }
}