﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Integrations.ProductLibraryService.Models;
using CMS.Interfaces.Common;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.Integrations.ProductLibraryServices;
using Guardian.Core.Entities.Product;
using Guardian.Core.Entities.Product.Enums;
using Guardian.Core.ProductLibrary.Services.ProductManagers;
using Logger.Static;
using NHibernate.Linq;
using CMS.Interfaces.Managers.ITAdminManagers;
using System.Diagnostics;
using Newtonsoft.Json;

namespace CMS.Integrations.ProductLibraryService
{
    public class ProductLibraryServiceClient : IProductLibraryService
    {
        private readonly IConfiguration _configuration;
        private readonly ICompactStateManager _compactStateManager;
        private const int CallingSystemId = 3;

        public ProductLibraryServiceClient(IConfiguration configuration, ICompactStateManager compactStateManager)
        {
            _configuration = configuration;
            _compactStateManager = compactStateManager;
        }

        public List<IdDisplayNameDto> GetProducts(StateTypeEnum stateType, DateTime applicationDate, FormCodeTypeEnum formCodeType)
        {
            Log.TraceFormat("+GetProducts");

            var productManager = new ProductManager(_configuration.DisabilityReferenceLibraryDatabaseConnection);
            var productInput = new ProductInput()
            {
                StateId = stateType,
                ApplicationDate = applicationDate,
                FormCodeId = formCodeType
            };

            var products = productManager.GetProducts(productInput);

            var productNames = products.Select(p => new IdDisplayNameDto
            {
                Id = p.ProductVariants.FirstOrDefault()?.Id ?? 0, // there is only one product variant for each product version for the new 2016 product
                DisplayName = string.Format("{0} {1}", p.ProductLine.DisplayName, p.DisplayName)
            }).ToList();

            Log.TraceFormat("-GetProducts");

            return productNames;
        }

        public ProductLibraryOptionsResponseDto GetOptions(int productVariantId, StateTypeEnum stateType, int insuredAge, bool isCompactState, int? pricingTypeId)
        {
            Log.TraceFormat("+GetOptions");

            var productManager = new ProductManager(_configuration.DisabilityReferenceLibraryDatabaseConnection);
            var benefitInput = new BenefitInput(productVariantId, stateType, insuredAge, 0)
            {
                CallingSystemID = CallingSystemId,
                ProductVersionRevision = GetProductVersion(isCompactState, stateType, pricingTypeId)
            };

            var options = productManager.GetBaseBenefit(benefitInput);

            var variants = options.SelectMany(o => o.ProductVariantBenefitVariants).ToList();

            var baseProductVariantBenefit = options.FirstOrDefault();

            Log.TraceFormat("-GetOptions");

            return new ProductLibraryOptionsResponseDto()
            {
                BaseBenefitId = baseProductVariantBenefit != null ? baseProductVariantBenefit.Benefit.Id : 0,
                DefinitionOfDisabilities = variants.Select(v => v.DefinitionOfDisability).Distinct().Select(v => new IdDisplayNameDto { Id = v.Id, DisplayName = v.DisplayName }).ToList(),
                EliminationPeriods = variants.Select(v => v.EliminationPeriod).Distinct().Select(v => new IdDisplayNameDto { Id = v.Id, DisplayName = v.DisplayName }).ToList(),
                BenefitPeriods = variants.Select(v => v.BenefitPeriod).Distinct().Select(v => new IdDisplayNameDto { Id = v.Id, DisplayName = v.DisplayName }).ToList(),
                MentalSubstances = variants.Select(v => v.MentalSubstanceLimitation).Distinct().Select(v => new IdDisplayNameDto { Id = v.Id, DisplayName = v.DisplayName }).ToList(),
            };
        }

        public BaseBenefitOptions GetBaseBenefitOptions(
            int productVariantId,
            StateTypeEnum stateType,
            int insuredAge, 
            OccupationClassTypeEnum occupationClassType,
            bool isCompactState,
            int? pricingTypeId)
        {
            Log.TraceFormat("+GetBaseBenefitOptions");

            var productManager = new ProductManager(_configuration.DisabilityReferenceLibraryDatabaseConnection);
            var benefitInput = new BenefitInput(productVariantId, stateType, insuredAge, 0)
            {
                OccupationClassTypeId = occupationClassType,
                CallingSystemID = CallingSystemId,
                ProductVersionRevision = GetProductVersion(isCompactState, stateType, pricingTypeId)
            };
            var options = productManager.GetBaseBenefit(benefitInput);

            var variants = options.SelectMany(o => o.ProductVariantBenefitVariants).ToList();            

            Log.TraceFormat("-GetBaseBenefitOptions");

            return new BaseBenefitOptions()
            {
                DefinitionOfDisabilities = variants.Select(v => v.DefinitionOfDisability).Distinct().Select(v => (DefinitionOfDisabilityTypeEnum)v.Id).ToList(),
                EliminationPeriods = variants.Select(v => v.EliminationPeriod).Distinct().Select(v => (EliminationPeriodTypeEnum)v.Id).ToList(),
                BenefitPeriods = variants.Select(v => v.BenefitPeriod).Distinct().Select(v => (BenefitPeriodTypeEnum)v.Id).ToList(),
                MentalSubstances = variants.Select(v => v.MentalSubstanceLimitation).Distinct().Select(v => (MentalSubstanceLimitationEnum) v.Id).ToList()
            };
        }

        public List<IdDisplayNameDto> GetRiders(
            int productVariantId,
            int insuredAge,
            StateTypeEnum stateType, 
            DefinitionOfDisabilityTypeEnum definitionOfDisability,
            EliminationPeriodTypeEnum eliminationPeriod,
            BenefitPeriodTypeEnum benefitPeriod,
            MentalSubstanceLimitationEnum mentalSubstance,
            OccupationClassTypeEnum occupationClass,
            OccupationGroupTypeEnum occupationGroup,
            bool isCompactState,
            int? pricingTypeId)
        {
            Log.TraceFormat("+GetRiders");

            var productManager = new ProductManager(_configuration.DisabilityReferenceLibraryDatabaseConnection);

            int productVersion = GetProductVersion(isCompactState, stateType, pricingTypeId);

            var riderInput = new RiderInput(productVariantId, stateType, insuredAge,
                definitionOfDisability, eliminationPeriod, FixBenefitPeriod(benefitPeriod),
                mentalSubstance, occupationClass, occupationGroup, 0, CallingSystemId, productVersion);

            var riders = productManager.GetRiders(riderInput);

            Log.TraceFormat("-GetRiders");

            return riders.Select(r => new IdDisplayNameDto {Id = r.Benefit.Id, DisplayName = r.Benefit.DisplayName}).ToList();
        }

        public bool IsEligibleForBaseBenefit(
            int productVariantId,
            StateTypeEnum stateId,
            int insuredAge,
            DefinitionOfDisabilityTypeEnum definitionOfDisabilityTypeId,
            EliminationPeriodTypeEnum eliminationPeriodTypeId,
            BenefitPeriodTypeEnum benefitPeriodTypeId,
            MentalSubstanceLimitationEnum mentalSubstanceLimitationId,
            OccupationClassTypeEnum occupationClassTypeId,
            bool isCompactState, 
            int? pricingTypeId)
        {

            int productVersion = GetProductVersion(isCompactState, stateId, pricingTypeId);

            var benefitInput = new BenefitInput(
                productVariantId,
                stateId,
                insuredAge,
                definitionOfDisabilityTypeId,
                eliminationPeriodTypeId,
                FixBenefitPeriod(benefitPeriodTypeId),
                mentalSubstanceLimitationId,
                occupationClassTypeId,
                OccupationGroupTypeEnum._18GIPC2016AllOccs,
                null,
                0, null, CallingSystemId, productVersion);            

            var productManager = new ProductManager(_configuration.DisabilityReferenceLibraryDatabaseConnection);
            var baseBenefits = productManager.GetBaseBenefit(benefitInput);
            return baseBenefits.Any();
        }

        public List<RiderBenefitDto> GetAvailableRidersInformation(
            int productVariantId,
            int insuredAge,
            StateTypeEnum stateType,
            DefinitionOfDisabilityTypeEnum definitionOfDisability,
            EliminationPeriodTypeEnum eliminationPeriod,
            BenefitPeriodTypeEnum benefitPeriod,
            MentalSubstanceLimitationEnum mentalSubstance,
            OccupationClassTypeEnum occupationClass,
            bool isCompactState,
            int? pricingTypeId)
        {
            Log.TraceFormat("+GetAvailableRidersInformation pricingTypeId={0}", pricingTypeId);
            var productManager = new ProductManager(_configuration.DisabilityReferenceLibraryDatabaseConnection);

            int productVersion = GetProductVersion(isCompactState, stateType, pricingTypeId);

            var riderInput = new RiderInput(productVariantId, stateType, insuredAge,
                definitionOfDisability, eliminationPeriod, FixBenefitPeriod(benefitPeriod),
                mentalSubstance, occupationClass, OccupationGroupTypeEnum._18GIPC2016AllOccs, 0, CallingSystemId, productVersion);

            Stopwatch st2 = new Stopwatch();
            st2.Start();
            var riders = productManager.GetRiders(riderInput);
            st2.Stop();
            Log.Debug($"productManager.GetRiders took : '{st2.Elapsed.TotalSeconds}' seconds ('{st2.Elapsed.TotalMilliseconds}' milliseconds) to execute.");
            st2.Reset();

            Log.TraceFormat("-GetAvailableRidersInformation pricingTypeId={0}", pricingTypeId);
            return riders.Select(rider => new RiderBenefitDto
                {
                    Benefit = (BenefitTypeEnum) rider.Benefit.Id,
                    BenefitGroup = (BenefitGroupTypeEnum) rider.Benefit.BenefitGroup.Id,
                    BenefitProperties = rider.ProductVariantBenefitVariants
                    .Select(v => new RiderBenefitInfoDto { BenefitPeriod = (BenefitPeriodTypeEnum) v.BenefitPeriod.Id, EliminationPeriod = (EliminationPeriodTypeEnum)v.EliminationPeriod.Id})
                    .ToList()                    
                })
                .ToList();
        }

        public List<int> GetRidersForSelection(
            int baseBenefitId,
            FormCodeTypeEnum formCode,
            int selectedRiderId,
            List<int> availableRiderIds, 
            bool isCompactState,
            StateTypeEnum stateId,
            int? pricingTypeId)
        {
            Log.TraceFormat("+GetRidersForSelection");

            var productManager = new ProductManager(_configuration.DisabilityReferenceLibraryDatabaseConnection);

            int productVersion = GetProductVersion(isCompactState, stateId, pricingTypeId);

            RidersForSelectionInput input = new RidersForSelectionInput()
            {
                BaseBenefitId = baseBenefitId,
                FormCode = formCode,
                SelectedRiderId = selectedRiderId,
                AvailableRiderIds = availableRiderIds,
                ProductVersionRevision = productVersion
            };

            var result = productManager.GetRidersForSelection(input);

            Log.TraceFormat("-GetRidersForSelection");

            return result;
        }

        public List<Occupation> GetOccupations()
        {
            var sessionFactory = SessionFactory.CreateSessionFactory(_configuration.DisabilityReferenceLibraryDatabaseConnection);

            using (var session = sessionFactory.OpenSession())
            {
                return session.Query<Occupation>().Where(o => o.IsActive).ToList();
            }
        }

        public BenefitPeriodTypeEnum FixBenefitPeriod(BenefitPeriodTypeEnum bp)
        {
            switch (bp)
            {
                case BenefitPeriodTypeEnum.Y02:
                    return BenefitPeriodTypeEnum.M24;
                case BenefitPeriodTypeEnum.Y05:
                    return BenefitPeriodTypeEnum.M60;
            }
            return bp;
        }

        public ProductLibraryOptionsResponseDto GetBaseBenefitOptions(
            int productVariantId,
            StateTypeEnum stateId,
            int insuredAge,
            DefinitionOfDisabilityTypeEnum definitionOfDisabilityTypeId,
            EliminationPeriodTypeEnum eliminationPeriodTypeId,
            BenefitPeriodTypeEnum benefitPeriodTypeId,
            MentalSubstanceLimitationEnum mentalSubstanceLimitationId,
            OccupationClassTypeEnum occupationClassTypeId,
            bool isCompactState,
            int? pricingTypeId)
        {
            Log.TraceFormat("+GetBaseBenefitOptions");

            int productVersion = GetProductVersion(isCompactState, stateId, pricingTypeId); 

            var benefitInput = new BenefitInput(
                productVariantId,
                stateId,
                insuredAge,
                definitionOfDisabilityTypeId,
                eliminationPeriodTypeId,
                benefitPeriodTypeId,
                mentalSubstanceLimitationId,
                occupationClassTypeId,
                OccupationGroupTypeEnum._18GIPC2016AllOccs,
                null,
                0, null, CallingSystemId, productVersion);

            //var input = JsonConvert.SerializeObject(benefitInput); // for testing purposeonly

            var productManager = new ProductManager(_configuration.DisabilityReferenceLibraryDatabaseConnection);

            var options = productManager.GetBaseBenefit(benefitInput);

            var variants = options.SelectMany(o => o.ProductVariantBenefitVariants).ToList();

            var baseProductVariantBenefit = options.FirstOrDefault();

            Log.TraceFormat("-GetBaseBenefitOptions");

            return new ProductLibraryOptionsResponseDto()
            {
                BaseBenefitId = baseProductVariantBenefit != null ? baseProductVariantBenefit.Benefit.Id : 0,
                DefinitionOfDisabilities = variants.Select(v => v.DefinitionOfDisability).Distinct().Select(v => new IdDisplayNameDto { Id = v.Id, DisplayName = v.DisplayName }).ToList(),
                EliminationPeriods = variants.Select(v => v.EliminationPeriod).Distinct().Select(v => new IdDisplayNameDto { Id = v.Id, DisplayName = v.DisplayName }).ToList(),
                BenefitPeriods = variants.Select(v => v.BenefitPeriod).Distinct().Select(v => new IdDisplayNameDto { Id = v.Id, DisplayName = v.DisplayName }).ToList(),
                MentalSubstances = variants.Select(v => v.MentalSubstanceLimitation).Distinct().Select(v => new IdDisplayNameDto { Id = v.Id, DisplayName = v.DisplayName }).ToList(),
            };
        }

        public bool OccClassAndDefOfDisabilityCheck(OccupationClassTypeEnum occClass, DefinitionOfDisabilityTypeEnum definitionOfDisability, bool hasPartialRider, bool hasGradedLifetimeRider)
        {
            var productManager = new ProductManager(_configuration.DisabilityReferenceLibraryDatabaseConnection);

            return productManager.OccClassAndDefOfDisabilityCheck(occClass, definitionOfDisability, hasPartialRider, hasGradedLifetimeRider);
        }

        public BenefitTypeEnum FixPreExistingConditionLimitationType(PreExistingConditionLimitTypeEnum preExistingConditionLimitType)
        {
            var benefitType = BenefitTypeEnum.PreExistingConditionLimitationEndorsementNoPrex;

            switch (preExistingConditionLimitType)
            {
                case PreExistingConditionLimitTypeEnum.None:
                   return BenefitTypeEnum.PreExistingConditionLimitationEndorsementNoPrex;
                case PreExistingConditionLimitTypeEnum._3_12:
                    return BenefitTypeEnum.PreExistingConditionLimitationEndorsementPrex3;
                case PreExistingConditionLimitTypeEnum._6_12:
                    return BenefitTypeEnum.PreExistingConditionLimitationEndorsementPrex6;
                case PreExistingConditionLimitTypeEnum._12_12:
                    return BenefitTypeEnum.PreExistingConditionLimitationEndorsementPrex12;
            }
            return benefitType;
        }
        public int GetProductVersion(bool isCompactState, StateTypeEnum stateType, int? pricingTypeId)
        {
            int productVersion;

            pricingTypeId = pricingTypeId ?? 1;

            var nonCompactStateIds = _compactStateManager.GetNonCompactStates(pricingTypeId.Value);

            if (nonCompactStateIds.Contains((int)stateType))
            {
                productVersion = 2;
            }
            else
            {
                productVersion = isCompactState ? 2 : 1;
            }

            if (pricingTypeId > 2)
            {
                productVersion = 1;
            }
            return productVersion;
        }
    }   
}
