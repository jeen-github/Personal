﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.BillingManagers;
using CMS.Interfaces.Managers.TaskManagers;
using Logger.Static;
using Common.Exceptions;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Interfaces.Managers.ImplementationManagers;
using System.Linq.Expressions;
using Common.Utilities;
using System.Threading.Tasks;
using CMS.Model.Extensions;
using CMS.Interfaces.Managers.CaseManagers;

namespace CMS.Managers.BillingManagers
{
    public class BillingManager : IBillingManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly BillingManagerValidator _billingManagerValidator;
        private readonly ITaskManager _taskManger;
        private readonly IEnrollmentManager _enrollmentManager;
        private readonly ICaseManager _caseManager;
        public BillingManager(IUnitOfWorkFactory unitOfWorkFactory, ITaskManager taskManger, IEnrollmentManager enrollmentManager,
            ICaseManager caseManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _billingManagerValidator = new BillingManagerValidator(unitOfWorkFactory);
            _taskManger = taskManger;
            _enrollmentManager = enrollmentManager;
            _caseManager = caseManager;
        }



        public List<ListBillNumberDto> GetListBillNumbersByCaseId(int caseId)
        {
            Log.TraceFormat("+GetListBillNumbers");
            var listBillNumberDtos = new List<ListBillNumberDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var listBillNumbers = unitOfWork.Repository<ListBillNumber>().Linq().Where(c => c.Case.Id == caseId);
                if (listBillNumbers == null) throw new ValidationException("Bill Numbers not found!");
                listBillNumberDtos = listBillNumbers.Select(c => new ListBillNumberDto
                {
                    CaseId = c.Case.Id,
                    ListBillNumberId = c.Id,
                    BillNumber = c.BillNumber,
                    IsDirectBill = c.IsDirectBill,
                    DueDate = c.DueDate,
                    DateSent = c.DateSent,
                    Status = c.Status,
                    BillAmount = c.BillAmount,
                    UnappliedAmount = c.UnappliedAmount,
                }).ToList();

            }
            Log.TraceFormat("-GetListBillNumbers");
            return listBillNumberDtos;
        }

        public void CreateTemporaryListBill(ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+CreateTemporaryListBill");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == listBillNumberDto.CaseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");

                var listBillNumber = new ListBillNumber();
                if (cmsCase.ListBillNumbers.Count() > 0)
                {
                    if (!string.IsNullOrEmpty(listBillNumberDto.BillNumber))
                    {
                        listBillNumber.BillNumber = listBillNumberDto.BillNumber;
                    }
                    else
                    {
                        var billnumber = 0;
                        var listBills = cmsCase.ListBillNumbers.Where(c => c.BillNumber.StartsWith("P")).ToList();
                        if (listBills.Any())
                        {
                            var listBill = listBills.Where(c => int.TryParse(c.BillNumber.Replace("P", ""), out billnumber) == true).OrderByDescending(c => c.Id).FirstOrDefault();
                            if (listBill != null)
                            {
                                listBillNumber.BillNumber = GenerateBillNumber(listBill.BillNumber);
                            }
                            else
                            {
                                listBillNumber.BillNumber = "P0001";
                            }
                        }
                        else
                        {
                            listBillNumber.BillNumber = "P0001";
                        }
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(listBillNumberDto.BillNumber))
                    {
                        listBillNumber.BillNumber = listBillNumberDto.BillNumber;
                    }
                    else
                    {
                        listBillNumber.BillNumber = "P0001";
                    }
                }

                listBillNumber.Case = cmsCase;
                listBillNumber.IsDirectBill = false;

                unitOfWork.Repository<ListBillNumber>().Save(listBillNumber);
                unitOfWork.Commit();
            }
            Log.TraceFormat("-CreateTemporaryListBill");
        }

        private string GenerateBillNumber(string listBillNumber)
        {
            string listBillNo = "P" +
                (Convert.ToInt32(listBillNumber.Replace("P", "")) + 1)
                    .ToString()
                    .PadLeft(4, '0');
            return listBillNo;
        }

        public void CreateDirectBill(int caseId)
        {
            Log.TraceFormat("+CreateDirectBill");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");
                var listBillNumber = new ListBillNumber();
                listBillNumber.Case = cmsCase;
                listBillNumber.BillNumber = "Direct Bill";
                listBillNumber.BillingMethodType = BillingMethodTypeEnum.DirectBill;
                listBillNumber.BillingModeType = BillingModeTypeEnum.DirectBillMonthly;
                listBillNumber.IsDirectBill = true;
                listBillNumber.RemittanceMethodType = RemittanceMethodTypeEnum.DirectBill;
                unitOfWork.Repository<ListBillNumber>().Save(listBillNumber);

                unitOfWork.Commit();
            }
            Log.TraceFormat("-CreateDirectBill");
        }

        public ListBillNumberDto GetListBillInformation(int ListBillNumberId)
        {
            Log.TraceFormat("+GetListBillInformation");
            var listBillNumberDtos = new ListBillNumberDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var listBillNumbers = unitOfWork.Repository<ListBillNumber>().Linq().FirstOrDefault(c => c.Id == ListBillNumberId);
                if (listBillNumbers == null) throw new ValidationException("Bill Numbers not found!");
                listBillNumberDtos.CaseId = listBillNumbers.Case.Id;
                listBillNumberDtos.ListBillNumberId = listBillNumbers.Id;
                listBillNumberDtos.BillNumber = listBillNumbers.BillNumber;
                listBillNumberDtos.IsDirectBill = listBillNumbers.IsDirectBill;
                listBillNumberDtos.DueDate = listBillNumbers.DueDate;
                listBillNumberDtos.DateSent = listBillNumbers.DateSent;
                listBillNumberDtos.Status = listBillNumbers.Status;
                listBillNumberDtos.BillAmount = listBillNumbers.BillAmount;
                listBillNumberDtos.UnappliedAmount = listBillNumbers.UnappliedAmount;
                listBillNumberDtos.BillingMethodTypeId = (int?)listBillNumbers.BillingMethodType;
                listBillNumberDtos.BillingModeTypeId = (int?)listBillNumbers.BillingModeType;
                listBillNumberDtos.PolicyDeliveryMethodTypeId = listBillNumbers.PolicyDeliveryMethodType != null ? (int?)listBillNumbers.PolicyDeliveryMethodType.Id : null;
                listBillNumberDtos.RemittanceMethodTypeId = (int?)listBillNumbers.RemittanceMethodType;
                listBillNumberDtos.IsPaid = listBillNumbers.IsPaid;
                listBillNumberDtos.IsSent = listBillNumbers.IsSent;
                listBillNumberDtos.PayrollContactId = listBillNumbers.PayrollContact != null ? (int?)listBillNumbers.PayrollContact.Id : null;
                listBillNumberDtos.ListBillContactId = listBillNumbers.ListBillContact != null ? (int?)listBillNumbers.ListBillContact.Id : null;
                listBillNumberDtos.CommonIDEmployee = listBillNumbers.CommonIDEmployee;
                listBillNumberDtos.CommonIDEmployer = listBillNumbers.CommonIDEmployer;
                listBillNumberDtos.ClassCodeTypeId = listBillNumbers.ClassCodeType != null ? (int?)listBillNumbers.ClassCodeType.Id : null;
                listBillNumberDtos.BillEndDate = listBillNumbers.BillEndDate;
                listBillNumberDtos.DeductionStartDate = listBillNumbers.DeductionStartDate;
                listBillNumberDtos.BillingAutomaticPayrollDeductionFileTypeId = listBillNumbers.BillingAutomaticPayrollDeductionFileType != null ? (int?)listBillNumbers.BillingAutomaticPayrollDeductionFileType.Id : null;
                listBillNumberDtos.SendDays = listBillNumbers.SendDays;
                if (listBillNumbers.ListBillGroups.Any())
                {
                    listBillNumberDtos.ListBillGroups = listBillNumbers.ListBillGroups.Select(g => new ListBillGroupDto
                    {
                        ListBillGroupId = g.Id,
                        BillingGroupName = g.BillingGroupName
                    }).ToList();
                }
                listBillNumberDtos.IsPayrollFrequency = listBillNumbers.IsPayrollFrequency;
                listBillNumberDtos.IsDeductionAmount = listBillNumbers.IsDeductionAmount;
                listBillNumberDtos.IsEmployeeID = listBillNumbers.IsEmployeeID;

                Log.TraceFormat("-GetListBillInformation");
                return listBillNumberDtos;
            }
        }

        public void SaveListBillInformation(ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+SaveListBillInformation");
            _billingManagerValidator.ValidateBillingInformation(listBillNumberDto);
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var listBillNumber = unitOfWork.Repository<ListBillNumber>().Linq().FirstOrDefault(c => c.Id == listBillNumberDto.ListBillNumberId);
                var contactAddress = unitOfWork.Repository<ContactAddress>().Linq();
                if (listBillNumber == null)
                {
                    listBillNumber = new ListBillNumber();
                    listBillNumber.Case = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == listBillNumberDto.CaseId);
                }
                listBillNumber.Id = listBillNumberDto.ListBillNumberId;
                listBillNumber.BillNumber = listBillNumberDto.BillNumber;
                listBillNumber.IsDirectBill = listBillNumberDto.IsDirectBill;
                listBillNumber.DueDate = listBillNumberDto.DueDate;
                listBillNumber.DateSent = listBillNumberDto.DateSent;
                listBillNumber.Status = listBillNumberDto.Status;
                listBillNumber.BillAmount = listBillNumberDto.BillAmount;
                listBillNumber.UnappliedAmount = listBillNumberDto.UnappliedAmount;
                listBillNumber.BillingMethodType = (BillingMethodTypeEnum?)listBillNumberDto.BillingMethodTypeId;
                listBillNumber.BillingModeType = (BillingModeTypeEnum?)listBillNumberDto.BillingModeTypeId;
                listBillNumber.PolicyDeliveryMethodType = unitOfWork.Repository<PolicyDeliveryMethodType>().Linq().FirstOrDefault(c => c.Id == listBillNumberDto.PolicyDeliveryMethodTypeId);
                listBillNumber.RemittanceMethodType = (RemittanceMethodTypeEnum?)listBillNumberDto.RemittanceMethodTypeId;
                listBillNumber.IsPaid = listBillNumberDto.IsPaid;
                listBillNumber.IsSent = listBillNumberDto.IsSent;
                listBillNumber.PayrollContact = contactAddress.FirstOrDefault(c => c.Id == listBillNumberDto.PayrollContactId);
                listBillNumber.ListBillContact = contactAddress.FirstOrDefault(c => c.Id == listBillNumberDto.ListBillContactId);
                listBillNumber.CommonIDEmployee = listBillNumberDto.CommonIDEmployee;
                listBillNumber.CommonIDEmployer = listBillNumberDto.CommonIDEmployer;
                listBillNumber.ClassCodeType = unitOfWork.Repository<ClassCodeType>().Linq().FirstOrDefault(c => c.Id == listBillNumberDto.ClassCodeTypeId);
                listBillNumber.BillEndDate = listBillNumberDto.BillEndDate;
                listBillNumber.DeductionStartDate = listBillNumberDto.DeductionStartDate;
                listBillNumber.BillingAutomaticPayrollDeductionFileType = unitOfWork.Repository<BillingAutomaticPayrollDeductionFileType>().Linq().FirstOrDefault(c => c.Id == listBillNumberDto.BillingAutomaticPayrollDeductionFileTypeId);
                listBillNumber.SendDays = listBillNumberDto.SendDays;
                listBillNumber.IsPayrollFrequency = listBillNumberDto.IsPayrollFrequency;
                listBillNumber.IsDeductionAmount = listBillNumberDto.IsDeductionAmount;
                listBillNumber.IsEmployeeID = listBillNumberDto.IsEmployeeID;

                unitOfWork.Repository<ListBillNumber>().Save(listBillNumber);

                unitOfWork.Commit();
            }

            if (listBillNumberDto.IsPaid)
            {
                var request = new CaseStatusDto
                {
                    CaseId = listBillNumberDto.CaseId,
                    CaseStatusType = CaseStatusTypeEnum.Active,
                    PlanDesignRequestStatusType = null,
                };

                _caseManager.SaveCaseStatusAndPDRStatus(request);
            }
            Log.TraceFormat("-SaveListBillInformation");
        }

        public ListBillGroupDto GetListBillGroupDetails(int listBillGroupId)
        {
            Log.TraceFormat("+GetListBillGroupDetails");
            ListBillGroupDto listBillGroupDetailsDto = null;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var listBillGroupDetails = unitOfWork.Repository<ListBillGroup>().LinqWithTimeOut().FirstOrDefault(c => c.Id == listBillGroupId);
                if (listBillGroupDetails != null)
                {
                    listBillGroupDetailsDto = new ListBillGroupDto
                    {
                        ListBillNumberId = listBillGroupDetails.ListBillNumber.Id,
                        ListBillGroupId = listBillGroupDetails.Id,
                        BillingGroupName = listBillGroupDetails.BillingGroupName,
                        ListBillPremiumPayerTypeId = listBillGroupDetails.ListBillPremiumPayerType != null ? (int?)listBillGroupDetails.ListBillPremiumPayerType : null,
                        TypeOfShareTypeId = listBillGroupDetails.TypeOfShareType != null ? (int?)listBillGroupDetails.TypeOfShareType : null,
                        EmployeePaidPremiumPercentage = listBillGroupDetails.EmployeePaidPremiumPercentage,
                        EmployerPaidPremiumPercentage = listBillGroupDetails.EmployerPaidPremiumPercentage,
                        EmployerPaysUpToAmount = listBillGroupDetails.EmployerPaysUpToAmount,
                        EmployeePaymentMethodTypeId = listBillGroupDetails.EmployeePaymentMethodType != null ? (int?)listBillGroupDetails.EmployeePaymentMethodType : null,
                        BenefitDeductionFrequencyTypeId = listBillGroupDetails.BenefitDeductionFrequencyType != null ? (int?)listBillGroupDetails.BenefitDeductionFrequencyType : null,
                        IsPayrollCalendarReceived = listBillGroupDetails.IsPayrollCalendarReceived,
                        IsPayrollFileNeeded = listBillGroupDetails.IsPayrollFileNeeded,
                        PayrollDeductionFileDueDate = listBillGroupDetails.PayrollDeductionFileDueDate,
                        IsPayrollDeductionFileSent = listBillGroupDetails.IsPayrollDeductionFileSent,
                        DeductionTakenTypeId = listBillGroupDetails.DeductionTakenType != null ? (int?)listBillGroupDetails.DeductionTakenType.Id : null
                        //ParticipantCount = listBillGroupDetails.Participants.Count
                    };
                }
            }
            Log.TraceFormat("-GetListBillGroupDetails");
            return listBillGroupDetailsDto;
        }

        public void SaveListBillGroup(ListBillGroupDto listBillGroupDto)
        {
            Log.TraceFormat("+SaveListBillGroup");
            DateTime? oldPayrollDeductionFileDueDate = null;
            _billingManagerValidator.ValidateListBillGroup(listBillGroupDto);
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var listBillGroup = unitOfWork.Repository<ListBillGroup>().Linq().FirstOrDefault(c => c.Id == listBillGroupDto.ListBillGroupId);
                var listBillNumber = unitOfWork.Repository<ListBillNumber>().Linq().FirstOrDefault(c => c.Id == listBillGroupDto.ListBillNumberId);
                if (listBillGroup == null)
                {
                    listBillGroup = new ListBillGroup();
                    listBillGroup.ListBillNumber = listBillNumber;
                }
                else
                {
                    oldPayrollDeductionFileDueDate = listBillGroup.PayrollDeductionFileDueDate;
                }

                listBillGroup.BillingGroupName = listBillGroupDto.BillingGroupName;
                listBillGroup.EmployeePaymentMethodType = (EmployeePaymentMethodTypeEnum?)listBillGroupDto.EmployeePaymentMethodTypeId;
                listBillGroup.DeductionTakenType = unitOfWork.Repository<DeductionTakenType>().Linq().FirstOrDefault(c => c.Id == listBillGroupDto.DeductionTakenTypeId);
                listBillGroup.ListBillPremiumPayerType = (ListBillPremiumPayerTypeEnum?)listBillGroupDto.ListBillPremiumPayerTypeId;
                listBillGroup.TypeOfShareType = (TypeOfShareTypeEnum?)listBillGroupDto.TypeOfShareTypeId;
                listBillGroup.EmployeePaidPremiumPercentage = listBillGroupDto.EmployeePaidPremiumPercentage.ToDBPercentage();
                listBillGroup.EmployerPaidPremiumPercentage = listBillGroupDto.EmployerPaidPremiumPercentage.ToDBPercentage();
                listBillGroup.EmployerPaysUpToAmount = listBillGroupDto.EmployerPaysUpToAmount;
                listBillGroup.BenefitDeductionFrequencyType = (BenefitDeductionFrequencyTypeEnum?)listBillGroupDto.BenefitDeductionFrequencyTypeId;
                listBillGroup.IsPayrollCalendarReceived = listBillGroupDto.IsPayrollCalendarReceived;
                listBillGroup.IsPayrollFileNeeded = listBillGroupDto.IsPayrollFileNeeded;
                listBillGroup.PayrollDeductionFileDueDate = listBillGroupDto.PayrollDeductionFileDueDate;
                listBillGroup.IsPayrollDeductionFileSent = listBillGroupDto.IsPayrollDeductionFileSent;

                if (listBillGroupDto.IsPayrollFileNeeded)
                {
                    if (listBillGroupDto.PayrollDeductionFileDueDate.HasValue)
                    {
                        var taskSLA = unitOfWork.Repository<TaskSLAType>().Linq();
                        var taskSLAForCreatePayRollFile = taskSLA.Where(i => i.ShortDescription == "CreatePayRollFile").FirstOrDefault();

                        if (taskSLAForCreatePayRollFile != null)
                        {
                            var taskName = string.Format(taskSLAForCreatePayRollFile.TaskName, listBillNumber.Case.CaseNumber, listBillNumber.BillNumber, listBillGroupDto.PayrollDeductionFileDueDate.Value.ToString(@"MM\/dd\/yyyy"));                                                      
                            if (listBillGroup.Task == null || (oldPayrollDeductionFileDueDate != null && oldPayrollDeductionFileDueDate != listBillGroupDto.PayrollDeductionFileDueDate))
                            {
                                var cmsTask = new CmsTask();
                                cmsTask = _taskManger.SaveTaskForBilling(listBillNumber.Case.Id, taskName, UserGroup.Group_BillingSpecialist, null, taskSLAForCreatePayRollFile.SLAInHours, false, listBillGroupDto.PayrollDeductionFileDueDate);
                                listBillGroup.Task = cmsTask;
                            }                           
                        }                        
                    }
                }

                unitOfWork.Repository<ListBillGroup>().Save(listBillGroup);

                unitOfWork.Commit();
            }
            Log.TraceFormat("+SaveListBillGroup");
        }

        public void DeleteListBillGroup(int listBillGroupId)
        {
            Log.TraceFormat("+DeleteListBillGroup");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var listBillGroup = unitOfWork.Repository<ListBillGroup>().Linq().FirstOrDefault(c => c.Id == listBillGroupId);
                if (listBillGroup != null)
                {
                    if (listBillGroup.Participants.Any())
                    {
                        throw new ValidationException("Please remove all participants from the Billing Group prior to deletion.");
                    }
                    unitOfWork.Repository<ListBillGroup>().Delete(listBillGroup);
                    unitOfWork.Commit();
                }

            }
            Log.TraceFormat("-DeleteListBillGroup");

        }

        public List<ParticipantBillingGroupDto> GetBillingGroupByCaseId(int caseId)
        {
            Log.TraceFormat("+GetBillingGroupByCaseId");

            var participantBillingGroupDtos = new List<ParticipantBillingGroupDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var listBillGroups = unitOfWork.Repository<ListBillGroup>().Linq().Where(c => c.ListBillNumber.Case.Id == caseId).ToList();
                if (listBillGroups == null) throw new ValidationException("Bill Groups not found!");

                participantBillingGroupDtos = listBillGroups.Select(c => new ParticipantBillingGroupDto
                {
                    ListBillNumberId = c.ListBillNumber.Id,
                    BillNumber = c.ListBillNumber.BillNumber,
                    ListBillGroupId = c.Id,
                    BillingGroupName = c.BillingGroupName,
                    EmployeePaymentMethodTypeName = c.EmployeePaymentMethodType != null ? c.EmployeePaymentMethodType.GetDescription() : null,
                    RemittanceMethodTypeName = c.ListBillNumber.RemittanceMethodType != null ? c.ListBillNumber.RemittanceMethodType.GetDescription() : null,
                    BillingModeTypeName = c.ListBillNumber.BillingModeType != null ? c.ListBillNumber.BillingModeType.GetDescription() : null,
                    PayrollContactName = c.ListBillNumber.PayrollContact != null ? c.ListBillNumber.PayrollContact.ContactName : null,
                    //GOMRunDate --> need to confirm from Bill
                    IsBankRouting = c.ListBillNumber.BillingMethodType != null ? (c.ListBillNumber.BillingMethodType == BillingMethodTypeEnum.ListBillGOM ? true : false) : false
                }).ToList();
            }

            Log.TraceFormat("-GetBillingGroupByCaseId");

            return participantBillingGroupDtos;

        }

        public void AssignParticipantsToBillingGroup(ParticipantBillingGroupDto participantBillingGroupDto)
        {
            Log.TraceFormat("+AssignParticipantsToBillingGroup");

            _billingManagerValidator.ValidateBillingGroupParticipant(participantBillingGroupDto);

            var splittedParticipantsIds = participantBillingGroupDto.ParticipantIds.ChunkBy(2000);

            Parallel.ForEach(splittedParticipantsIds, obj =>
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var participants = unitOfWork.Repository<Participant>().Linq().Where(c => obj.Contains(c.Id)).ToList();

                    var billingGroup = unitOfWork.Repository<ListBillGroup>().Linq().FirstOrDefault(c => c.Id == participantBillingGroupDto.ListBillGroupId);

                    if (billingGroup != null)
                    {
                        foreach (var participant in participants)
                        {
                            participant.ListBillGroup = billingGroup;
                            participant.BillingGroupName = participant.ListBillGroup.BillingGroupName;
                            participant.ListBillNumber = participant.ListBillGroup.ListBillNumber;
                            participant.BillNumber = participant.ListBillNumber.BillNumber;

                            unitOfWork.Repository<Participant>().Save(participant);
                        }
                    }
                    unitOfWork.Commit();
                }

            });

            Log.TraceFormat("-AssignParticipantsToBillingGroup");
        }

        public List<EnrollmentDto> GetEnrollmentDetailsForBilling(int caseId, bool showAll)
        {
            Log.TraceFormat("+GetEnrollmentDetailsForBilling");

            var enrollmentDtos = new List<EnrollmentDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                Expression<Func<Enrollment, bool>> showAllQuery = e => e.Case.Id == caseId && (e.IsActive == null || e.IsActive == true);
                Expression<Func<Enrollment, bool>> excludeClosedEnrollmentQuery = e => e.EffectiveDate.Date >= DateTime.Now.Date.AddMonths(-18);

                var predicate = PredicateBuilder.True<Enrollment>();

                predicate = predicate.And(showAllQuery);

                if (!showAll)
                {
                    predicate = predicate.And(excludeClosedEnrollmentQuery);
                }

                var enrollments = unitOfWork.Repository<Enrollment>().Linq().Where(predicate);

                if (enrollments.Any())
                {
                    enrollmentDtos = enrollments.Select(t => new EnrollmentDto
                    {
                        CaseId = t.Case.Id,
                        EnrollmentId = t.Id,
                        EnrollmentName = t.EnrollmentName,
                        EnrollmentStartDate = t.EnrollmentStartDate,
                        EnrollmentEndDate = t.EnrollmentEndDate,
                        ExtensionEndDate = t.ExtensionEndDate,
                        EffectiveDate = t.EffectiveDate,
                        IsAddOnIndicator = t.IsAddOnIndicator,
                    }).ToList();
                }

                Log.TraceFormat("-GetEnrollmentDetailsForBilling");

                return enrollmentDtos;
            }
        }

        public EnrollmentDto GetEnrollmentDetails(int enrollmentId)
        {
            var enrollmentDto = new EnrollmentDto();
            Log.TraceFormat("+GetEnrollmentDetails");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == enrollmentId);
                var pdrClassId = enrollment.Classes.Select(x => x.PlanDesignRequestClass.Id);
                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => pdrClassId.Contains(c.PlanDesignRequestClass.Id) && c.IsActive).ToList();

                bool? IsGSIPlanIndicator = false;                
                IsGSIPlanIndicator = pdrSoldClass.FirstOrDefault().PDRSoldClassPlan.Any(x => x.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                if (enrollment != null)
                {
                    enrollmentDto.EnrollmentId = enrollment.Id;
                    enrollmentDto.CaseId = enrollment.Case.Id;
                    enrollmentDto.SolicitationDeclinesTaskWorkUnitId = enrollment.SolicitationDeclinesTaskWorkUnit != null ? enrollment.SolicitationDeclinesTaskWorkUnit.Id : 0;
                    enrollmentDto.EffectiveDate = enrollment.EffectiveDate;
                    enrollmentDto.IsAttested = enrollment.IsAttested;
                    enrollmentDto.IsInitialBillingCall = enrollment.IsInitialBillingCall;
                    enrollmentDto.IsW9sent = enrollment.IsW9sent;
                    enrollmentDto.EligibleParticipants = enrollment.CensusParticipants != null ? (int?)enrollment.CensusParticipants.Count() : null;
                    enrollmentDto.EnrollmentMethodTypeId = enrollment.EnrollmentMethodType.Id;
                    enrollmentDto.AMBTypeId = (int?)enrollment.AMBType;                   
                    enrollmentDto.BuyUpAMBTypeId = (int?)enrollment.BuyUpAMBType;                   
                    enrollmentDto.IsGSIPlanIndicator = IsGSIPlanIndicator;
                    enrollmentDto.NegativeEnrollmentDateQuequed = enrollment.NegativeEnrollmentDateQuequed;
                    enrollmentDto.NegativeEnrollmentProcessDate = enrollment.NegativeEnrollmentProcessDate;
                    if (pdrSoldClass != null && pdrSoldClass.Count > 0)
                    {
                        enrollmentDto.CaseTypes = string.Join(",", (pdrSoldClass.Select(c => c.PDRSoldClassPlan.FirstOrDefault(x => x.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).PremiumPayerAndTaxabilityType.Id))).Split(',').Select(Int32.Parse).ToList();
                    }
                    else
                    {
                        enrollmentDto.CaseTypes = enrollment.Classes.Select(x => x.PlanDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Id).ToList();
                    }
                }
            }
            Log.TraceFormat("-GetEnrollmentDetails");
            return enrollmentDto;
        }

        public void SaveEnrollmentDetails(EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+SaveEnrollmentDetails");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == enrollmentDto.EnrollmentId);

                var taskSLA = unitOfWork.Repository<TaskSLAType>().Linq();

                if (enrollment == null) throw new ValidationException("Enrollments not found!");
                
                enrollment.EffectiveDate = enrollmentDto.EffectiveDate.Value;
                enrollment.IsAttested = enrollmentDto.IsAttested;
                enrollment.IsInitialBillingCall = enrollmentDto.IsInitialBillingCall;
                enrollment.IsW9sent = enrollmentDto.IsW9sent;
                enrollment.AMBType = (AMBTypeEnum?)enrollmentDto.AMBTypeId;
                enrollment.BuyUpAMBType = (AMBTypeEnum?)enrollmentDto.BuyUpAMBTypeId;
                enrollment.NegativeEnrollmentDateQuequed = enrollmentDto.NegativeEnrollmentDateQuequed;
                enrollment.NegativeEnrollmentProcessDate = enrollmentDto.NegativeEnrollmentProcessDate;

                //Added to reset the Negetative Enrollment batch queue for the story 
                //NBTC-3834 - ML INC2360647 : Negative enrollment code needs to be tweaked to be able to handle large cases efficiently 
                foreach (var enrollmentParticipant in enrollment.CensusParticipants)
                {
                    enrollmentParticipant.IsNegativeEnrollmentProcessed = false;
                }

                unitOfWork.Repository<Enrollment>().Save(enrollment);

                unitOfWork.Commit();
            }

            _enrollmentManager.UpdateSolicitationDeclinesTaskWorkUnit(enrollmentDto);

            Log.TraceFormat("+SaveEnrollmentDetails");
        }
    }
}

