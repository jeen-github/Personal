﻿using System.Collections.Generic;
using System.Linq;
using Common.Exceptions;
using CMS.Model.Enums;
using CMS.Interfaces.Managers.BillingManagers;
using Logger.Static;
using CMS.Interfaces.DataAccess;
using System.Threading.Tasks;
using Common.Utilities;
using CMS.Model.Entities;
using System.Text.RegularExpressions;
using System;

namespace CMS.Managers.BillingManagers
{
    public class BillingManagerValidator
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public BillingManagerValidator(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }
        public void ValidateBillingInformation(ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+ValidateBillingInformation");
            var errorMessages = new List<string>();
            if (listBillNumberDto.BillingMethodTypeId == (int)BillingMethodTypeEnum.AutomaticPayrollDeduction)
            {
                ValidateCommonIDEE(errorMessages, listBillNumberDto);
                ValidateCommonIDER(errorMessages, listBillNumberDto);
                ValidateClassCode(errorMessages, listBillNumberDto);
                ValidateBillEndDate(errorMessages, listBillNumberDto);
                ValidateDeductionStartDate(errorMessages, listBillNumberDto);
                ValidateFileType(errorMessages, listBillNumberDto);
                ValidateSendDays(errorMessages, listBillNumberDto);
            }
            if (errorMessages.Any()) throw new ValidationException(errorMessages);
            Log.TraceFormat("-ValidateBillingInformation");
        }

        public void ValidateCommonIDEE(List<string> errorMessages, ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+ValidateCommonIDEE");
            if (listBillNumberDto.CommonIDEmployee == null)
            {
                if (!errorMessages.Contains("Please enter Common ID EE Value."))
                {
                    errorMessages.Add("Please enter Common ID EE Value.");
                }
            }
            Log.TraceFormat("-ValidateCommonIDEE");
        }

        public void ValidateCommonIDER(List<string> errorMessages, ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+ValidateCommonIDER");
            if (listBillNumberDto.CommonIDEmployer == null)
            {
                if (!errorMessages.Contains("Please enter Common ID ER Value."))
                {
                    errorMessages.Add("Please enter Common ID ER Value.");
                }
            }
            Log.TraceFormat("-ValidateCommonIDER");
        }

        public void ValidateClassCode(List<string> errorMessages, ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+ValidateClassCode");
            if (listBillNumberDto.ClassCodeTypeId == null)
            {
                if (!errorMessages.Contains("Please select Class Code."))
                {
                    errorMessages.Add("Please select Class Code.");
                }
            }
            Log.TraceFormat("-ValidateClassCode");
        }

        public void ValidateBillEndDate(List<string> errorMessages, ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+ValidateBillEndDate");
            if (listBillNumberDto.BillEndDate == null)
            {
                if (!errorMessages.Contains("Please enter Bill End Date Value."))
                {
                    errorMessages.Add("Please enter Bill End Date Value.");
                }
            }
            Log.TraceFormat("-ValidateBillEndDate");
        }

        public void ValidateDeductionStartDate(List<string> errorMessages, ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+ValidateDeductionStartDate");
            if (listBillNumberDto.DeductionStartDate == null)
            {
                if (!errorMessages.Contains("Please enter Deduction Start Date Value."))
                {
                    errorMessages.Add("Please enter Deduction Start Date Value.");
                }
            }
            Log.TraceFormat("-ValidateDeductionStartDate");
        }

        public void ValidateFileType(List<string> errorMessages, ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+ValidateFileType");
            if (listBillNumberDto.BillingAutomaticPayrollDeductionFileTypeId == null)
            {
                if (!errorMessages.Contains("Please select File Type."))
                {
                    errorMessages.Add("Please select File Type.");
                }
            }
            Log.TraceFormat("-ValidateFileType");
        }

        public void ValidateSendDays(List<string> errorMessages, ListBillNumberDto listBillNumberDto)
        {
            Log.TraceFormat("+ValidateCommonIDEE");
            if (listBillNumberDto.SendDays == null)
            {
                if (!errorMessages.Contains("Please enter Send Days Value."))
                {
                    errorMessages.Add("Please enter Send Days Value.");
                }
            }
            Log.TraceFormat("-ValidateCommonIDEE");
        }

        public void ValidateBillingGroupParticipant(ParticipantBillingGroupDto participantBillingGroupDto)
        {
            Log.TraceFormat("+ValidateBillingGroupParticipant");

            var errorMessages = new List<string>();

            if (participantBillingGroupDto.ParticipantIds == null)
            {
                errorMessages.Add("Please select a row to assign Billing Group.");
                throw new ValidationException(errorMessages);
            }

            var splittedParticipantsIds = participantBillingGroupDto.ParticipantIds.ChunkBy(2000);


            Parallel.ForEach(splittedParticipantsIds, obj =>
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var participants = unitOfWork.Repository<Participant>().Linq().Where(c => obj.Contains(c.Id)).ToList();

                    var billingGroup = unitOfWork.Repository<ListBillGroup>().Linq().FirstOrDefault(c => c.Id == participantBillingGroupDto.ListBillGroupId);

                    string participantids = string.Empty;
                    var validateEligible = participants.Where(p => !((p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null)));
                    if (validateEligible != null && validateEligible.Count() > 0)
                    {
                        participantids = string.Join(",", validateEligible.Select(c => c.EmployeeId));

                        errorMessages.Add("Participant " + participantids + " is not eligible and cannot be added to a Billing Group.");

                    }

                    if (billingGroup.ListBillPremiumPayerType != ListBillPremiumPayerTypeEnum.Employer && billingGroup.BenefitDeductionFrequencyType != null)
                    {
                        var validatePayrollFrequency = participants.Where(c => (c.BenefitDeductionFrequency!=null) && (c.BenefitDeductionFrequency != billingGroup.BenefitDeductionFrequencyType));
                        if (validatePayrollFrequency != null && validatePayrollFrequency.Count() > 0)
                        {
                            participantids = string.Join(",", validatePayrollFrequency.Select(c => c.EmployeeId));
                            errorMessages.Add("Participant " + participantids + " does not have the correct Payroll Deduction Frequency for the selected Billing Group.");
                        }
                    }
                    
                    var validatePremiumpayer = participants.Where(c => MapToListBillPremiumPayerType(c.PlanDesignRequestClass, unitOfWork).Contains(billingGroup.ListBillPremiumPayerType));
                    if (validatePremiumpayer != null && validatePremiumpayer.Count() == 0)
                    {
                        participantids = string.Join(",", validatePremiumpayer.Select(c => c.EmployeeId));
                        errorMessages.Add("Participant " + participantids + " does not have the correct Premium Payer for the selected Billing Group.");
                    }
                }

            });
            if (errorMessages.Any()) throw new ValidationException(errorMessages);
            Log.TraceFormat("-ValidateBillingGroupParticipant");
        }

        private List<ListBillPremiumPayerTypeEnum?> MapToListBillPremiumPayerType(PlanDesignRequestClass pdrClass, IUnitOfWork unitOfWork)
        {
            List<ListBillPremiumPayerTypeEnum?> mappedType = new List<ListBillPremiumPayerTypeEnum?>();
            var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(sc => sc.PlanDesignRequestClass.Id == pdrClass.Id && sc.IsActive);
            bool? hasBuyUp = false;
            var classPreimumPayerType = new ExistingCoveragePremiumAndTaxpayerLiabilityType();
            if (pdrSoldClass == null)
            {
                classPreimumPayerType = pdrClass.ApprovedPremiumPayerAndTaxabilityType;
                hasBuyUp = pdrClass.IsApprovedVoluntaryGSIBuyUpPlan;
            }
            else
            {
                var primaryPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(scp => scp.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                classPreimumPayerType = primaryPlan.PremiumPayerAndTaxabilityType;
                var buyUpPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(scp => scp.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                if (buyUpPlan != null)
                {
                    hasBuyUp = true;
                }
            }

            if (classPreimumPayerType != null)
            {
                switch (classPreimumPayerType.Id)
                {
                    case (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare:
                        mappedType.Add(ListBillPremiumPayerTypeEnum.CostShare);
                        break;
                    case (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid:
                        if (hasBuyUp == true)
                        {
                            mappedType.Add(ListBillPremiumPayerTypeEnum.EmployerwithVGSI);
                        }
                        else
                        {
                            mappedType.Add(ListBillPremiumPayerTypeEnum.Employer);
                        }
                        break;
                    case (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable:
                        mappedType.Add(ListBillPremiumPayerTypeEnum.Employer);
                        mappedType.Add(ListBillPremiumPayerTypeEnum.Employee);
                        break;
                    case (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable:
                        mappedType.Add(ListBillPremiumPayerTypeEnum.Employee);
                        break;
                }
            }
            return mappedType;
        }

        public void ValidateListBillGroup(ListBillGroupDto listBillGroupDto)
        {
            Log.TraceFormat("+ValidateListBillGroup");

            var errorMessages = new List<string>();
            ValidateEmployerPaidPremium(errorMessages, listBillGroupDto);
            if (errorMessages.Any()) throw new ValidationException(errorMessages);

            Log.TraceFormat("-ValidateListBillGroup");
        }

        public void ValidateEmployerPaidPremium(List<string> errorMessages, ListBillGroupDto listBillGroupDto)
        {
            Log.TraceFormat("+ValidateEmployerPaidPremium");
            if (listBillGroupDto.ListBillPremiumPayerTypeId == (int?)ListBillPremiumPayerTypeEnum.CostShare && listBillGroupDto.TypeOfShareTypeId == (int?)TypeOfShareTypeEnum.PercentofPremium)
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(listBillGroupDto.EmployerPaidPremiumPercentage))
                {
                    if (listBillGroupDto.EmployerPaidPremiumPercentage < 0 || listBillGroupDto.EmployerPaidPremiumPercentage > 100)
                    {
                        errorMessages.Add("Please enter a valid Employer Paid Premium.");
                    }
                }
                else
                {
                    if (listBillGroupDto.EmployerPaidPremiumPercentage > 0 && listBillGroupDto.EmployerPaidPremiumPercentage < 100)
                    {
                        var match = Regex.Match(Convert.ToString(listBillGroupDto.EmployerPaidPremiumPercentage), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid Employer Paid Premium.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid Employer Paid Premium.");
                    }
                }
            }
            Log.TraceFormat("-ValidateEmployerPaidPremium");
        }

        private bool IsDecimalOrInteger(decimal? percentage)
        {
            return percentage % 1 == 0;
        }
    }
}
