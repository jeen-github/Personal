﻿using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.TaskManagers;
using Common.Exceptions;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Model.Enums;
using System.Text.RegularExpressions;


namespace CMS.Managers.TaskManagers
{
    public class TaskManagerValidator
    {
        public void ValidateAdHocData(TaskDto taskdto)
        {
            Log.TraceFormat("+ValidateAdHocData");

            var errorMessages = new List<string>();

            ValidateUser(taskdto, errorMessages);

            ValidateTask(taskdto, errorMessages);

            ValidateComments(taskdto, errorMessages);

            Log.TraceFormat("-ValidateAdHocData");

            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }

        public void ValidateUser(TaskDto taskdto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateUser");

            if (taskdto.UserId == null)
            {
                errorMessages.Add("Please select User");
            }

            Log.TraceFormat("-ValidateUser");
        }

        public void ValidateTask(TaskDto taskdto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateTask");

            if (taskdto.UserGroupId == null)
            {
                errorMessages.Add("Please select Task");
            }

            Log.TraceFormat("-ValidateTask");
        }

        public void ValidateComments(TaskDto taskdto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateComments");

            if (string.IsNullOrEmpty(taskdto.Comments))
            {
                errorMessages.Add("Please enter Comments");
            }

            Log.TraceFormat("-ValidateComments");
        }
    }
}
