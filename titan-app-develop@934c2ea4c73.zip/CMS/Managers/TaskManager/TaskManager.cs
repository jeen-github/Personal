﻿using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.FileNetDocumentRepositories;
using CMS.Interfaces.Integrations.MLAppEntryServices;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.TaskManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Common.Exceptions;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace CMS.Managers.TaskManagers
{
    public class TaskManager : ITaskManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IFileNetDocumentRepository _fileNetDocumentRepository;
        private readonly IAppEntryService _appEntryService;
        private readonly ICaseManager _caseManager;
        private readonly IConfiguration _configuration;
        private readonly TaskManagerValidator _taskManagerValidator;
        private readonly IPlanDesignRequestSoldManager _planDesignRequestSoldManager;
        private readonly ICaseBrokerManager _caseBrokerManager;        


        public TaskManager(IUnitOfWorkFactory unitOfWorkFactory, IFileNetDocumentRepository fileNetDocumentRepository, IAppEntryService appEntryService,
            ICaseManager caseManager, IConfiguration configuration, IPlanDesignRequestSoldManager planDesignRequestSoldManager, ICaseBrokerManager caseBrokerManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _fileNetDocumentRepository = fileNetDocumentRepository;
            _appEntryService = appEntryService;
            _caseManager = caseManager;
            _configuration = configuration;
            _planDesignRequestSoldManager = planDesignRequestSoldManager;
            _caseBrokerManager = caseBrokerManager;
            _taskManagerValidator = new TaskManagerValidator();            
        }

        public List<TaskDto> GetMyTasks(UserTasksRequestDto userTasksRequest)
        {
            string myTasksStoredProcedure = string.Empty;

            Log.TraceFormat("+GetUserTasks");

           


            List<TaskDto> userTasks = new List<TaskDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {

                myTasksStoredProcedure = "[cms].[USP_GetMyTaskDetails] @LdapUserId = " + userTasksRequest.UserInfo.TitanUserId.ToString();
                var myTasksDetails = unitOfWork.RunSqlQuery<Object>("EXEC " + myTasksStoredProcedure, 120).ToList();
                Object[] matches = myTasksDetails.ToArray();
                userTasks = GetTaskDetailsResult(matches);
            }

            Log.TraceFormat("-GetUserTasks");

            return userTasks;
        }

        public List<TaskDto> GetMyTeamsTasks(int[] userGroupIds, bool isConfidentialCase)
        {
            string myTeamsTasksStoredProcedure = string.Empty;

            Log.TraceFormat("+GetMyTeamsTasks");

            List<TaskDto> userTasks = new List<TaskDto>();

            string userGroups = string.Join(",", userGroupIds.Select(c => c));

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                object[] parameters = new object[2];
                parameters[0] = userGroups;
                parameters[1] = isConfidentialCase;
                
                var myTasksDetails = unitOfWork.RunSqlQuery<Object>("EXEC [cms].[USP_GetMyTeamsTaskDetails] :@UserGroups, :@IsConfidentialCase", 120, parameters);
                Object[] matches = myTasksDetails.ToArray();
                userTasks = GetTaskDetailsResult(matches);
            }

            Log.TraceFormat("-GetMyTeamsTasks");

            return userTasks;
        }

        public List<TaskDto> GetMyTeamsTaskDetailsWithSuspendedTasks(int[] userGroupIds, int caseId, int assignedUserId)
        {
            string myTeamsTasksStoredProcedure = string.Empty;

            Log.TraceFormat("+GetMyTeamsTaskDetailsWithSuspendedTasks");

            List<TaskDto> userTasks = new List<TaskDto>();

            string userGroups = string.Join(",", userGroupIds.Select(c => c));

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                myTeamsTasksStoredProcedure = "[cms].[USP_GetMyTeamsTaskDetailsWithSuspendedTasks] @UserGroups = '" + userGroups + "', @CaseId=" + caseId + ", @AssignedUserId=" + assignedUserId ;
                var myTasksDetails = unitOfWork.RunSqlQuery<Object>("EXEC " + myTeamsTasksStoredProcedure, 120).ToList();
                Object[] matches = myTasksDetails.ToArray();
                userTasks = GetMyTeamsTaskDetailsWithSuspendedTasksResult(matches);
            }

            Log.TraceFormat("-GetMyTeamsTaskDetailsWithSuspendedTasks");

            return userTasks;
        }

        private List<TaskDto> GetMyTeamsTaskDetailsWithSuspendedTasksResult(object[] taskDetailList)
        {
            var userTasks = new List<TaskDto>();
            if (taskDetailList != null)
            {
                foreach (Object[] taskDetail in taskDetailList)
                {
                    var task = new TaskDto();
                    task.TaskId = taskDetail[0] != null ? (int)taskDetail[0] : 0;
                    task.TaskName = taskDetail[1] != null ? (string)taskDetail[1] : string.Empty;
                    task.TaskStatus = taskDetail[2] != null ? (string)taskDetail[2] : string.Empty;
                    task.CreationDate = Convert.ToDateTime(taskDetail[3]);
                    task.CreationDateFiltered = Convert.ToDateTime(taskDetail[4]);
                    task.DueDate = Convert.ToDateTime(taskDetail[5]);
                    task.DueDateFiltered = taskDetail[6] != null ? Convert.ToDateTime(taskDetail[6]) : (DateTime?)null;
                    task.UpdatedDueDate = taskDetail[7] != null ? Convert.ToDateTime(taskDetail[7]) : (DateTime?)null;
                    task.UpdatedDueDateFiltered = taskDetail[8] != null ? Convert.ToDateTime(taskDetail[8]) : (DateTime?)null;
                    task.LastClaimedDate = taskDetail[9] != null ? Convert.ToDateTime(taskDetail[9]) : (DateTime?)null;
                    task.LastClaimedDateFiltered = taskDetail[10] != null ? Convert.ToDateTime(taskDetail[10]) : (DateTime?)null;
                    task.ClaimedBy = taskDetail[11] != null ? (string)taskDetail[11] : string.Empty;
                    task.LastSuspendedDate = taskDetail[12] != null ? Convert.ToDateTime(taskDetail[12]) : (DateTime?)null;
                    task.LastSuspendedDateFiltered = taskDetail[13] != null ? Convert.ToDateTime(taskDetail[13]) : (DateTime?)null;
                    task.FollowUpDate = taskDetail[14] != null ? Convert.ToDateTime(taskDetail[14]) : (DateTime?)null;
                    task.FollowUpDateFiltered = taskDetail[15] != null ? Convert.ToDateTime(taskDetail[15]) : (DateTime?)null;
                    task.Comments = taskDetail[16] != null ? (string)taskDetail[16] : string.Empty;
                    task.CaseId = taskDetail[17] != null ? (int)taskDetail[17] : 0;
                    task.TaskGroupId = taskDetail[18] != null ? (int)taskDetail[18] : 0;
                    task.CreatedBy = taskDetail[19] != null ? taskDetail[19].ToString() : string.Empty;
                    userTasks.Add(task);
                }
            }

            return userTasks;
        }

        public List<TaskDto> GetTaskDetailsResult(Object[] taskDetailList)
        {
            var userTasks = new List<TaskDto>();
            if (taskDetailList != null)
            {
                foreach (Object[] taskDetail in taskDetailList)
                {
                    var task = new TaskDto();
                    task.TaskId = taskDetail[0] != null ? (int)taskDetail[0] : 0;
                    task.TaskName = taskDetail[1] != null ? (string)taskDetail[1] : string.Empty;
                    task.CaseId = taskDetail[2] != null ? (int)taskDetail[2] : 0;
                    task.Region = taskDetail[3] != null ? (string)taskDetail[3] : string.Empty;
                    task.AssignedGroup = taskDetail[6] != null ? (string)taskDetail[6] : string.Empty;
                    task.DueDate = Convert.ToDateTime(taskDetail[7]);
                    task.CaseStatus = taskDetail[8] != null ? (string)taskDetail[8] : string.Empty;
                    task.TaskStatus = taskDetail[9] != null ? (string)taskDetail[9] : string.Empty;
                    task.UpdatedDueDate = taskDetail[10] != null ? Convert.ToDateTime(taskDetail[10]) : (DateTime?)null;
                    task.FollowUpDate = taskDetail[11] != null ? Convert.ToDateTime(taskDetail[11]) : (DateTime?)null;
                    task.LdapUserName = taskDetail[12] != null ? (string)taskDetail[12] : string.Empty;
                    task.PrimaryBroker = taskDetail[13] != null ? (string)taskDetail[13] : string.Empty;
                    task.ClaimedBy = taskDetail[14] != null ? (string)taskDetail[14] : string.Empty;
                    task.AssignedUser = taskDetail[15] != null ? (string)taskDetail[15] : string.Empty;
                    task.CaseNumber = taskDetail[17] != null ? (string)taskDetail[17] : string.Empty;
                    task.CompanyName = taskDetail[18] != null ? (string)taskDetail[18] : string.Empty;
                    task.UpdatedDueDateFiltered = taskDetail[19] != null ? Convert.ToDateTime(taskDetail[19]) : (DateTime?)null;
                    task.DueDateFiltered = taskDetail[20] != null ? Convert.ToDateTime(taskDetail[20]) : (DateTime?)null;
                    task.FollowUpDateFiltered = taskDetail[21] != null ? Convert.ToDateTime(taskDetail[21]) : (DateTime?)null;
                    task.TaskGroupId = taskDetail[22] != null ? (int)taskDetail[22] : 0;
                    userTasks.Add(task);
                }
            }

            return userTasks;
        }

        public void ClaimTask(ClaimTaskRequestDto request)
        {
            Log.TraceFormat("+ClaimTask Task Id {0} ", request.TaskId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var task = unitOfWork.Repository<CmsTask>().Linq().FirstOrDefault(t => t.Id == request.TaskId);
                var cmsUsers = unitOfWork.Repository<CmsUser>().Linq().ToList();

                if (task == null) throw new ValidationException("Task not found!");

                if (task.TaskStatusType == null && task.TaskName == CmsTask.TaskRevisedCaseReceived && task.PlanDesignRequest != null)
                {
                    Log.TraceFormat("+ClaimTask Task Id {0} PDR Id {1} ", request.TaskId, task.PlanDesignRequest.Id);
                    var requestCaseStatus = new CaseStatusDto
                    {
                        CaseId = task.Case.Id,
                        TaskName = CmsTask.TaskRevisedCaseReceived,
                        IsClaimingOfRevisedCase = true,
                        PlanDesignRequestStatusType = PlanDesignRequestStatusTypeEnum.UnderwritingReview,
                        CaseStatusType = CaseStatusTypeEnum.UnderwritingReview,
                        PlanDesignRequestId = task.PlanDesignRequest.Id,
                    };
                    _caseManager.SaveCaseStatusAndPDRStatus(requestCaseStatus);
                }

                UpdateAssignedUserForUnassignedCases(task, unitOfWork, cmsUsers);
                task.ClaimedDate = DateTime.Now;
                task.TaskStatusType = TaskStatusTypeEnum.Claimed;
                task.ClaimedDate = DateTime.Now;
                task.ClaimedByUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(u => u.Id == request.UserInfo.TitanUserId);
                unitOfWork.Repository<CmsTask>().Save(task);
                SaveTaskActivityLog(task, unitOfWork);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-ClaimTask");
        }

        private void UpdateAssignedUserForUnassignedCases(CmsTask task, IUnitOfWork unitOfWork, List<CmsUser> cmsUsers)
        {
            Log.TraceFormat("+UpdateAssignedUserForUnassignedCases");
            UserGroup assignedUserGroup = null;
            int? assignedToUserId = null;
            var wholeSaler = unitOfWork.Repository<CaseWholesaler>().Linq().FirstOrDefault(w => w.Case.Id == task.Case.Id);

            if (task.AssignedToUser == null && task.Case != null)
            {
                if (task.AssignedToUserGroup != null)
                {
                    assignedUserGroup = unitOfWork.Repository<UserGroup>().Linq().FirstOrDefault(t => t.Id == task.AssignedToUserGroup.Id);
                }
                if (assignedUserGroup != null)
                {
                    if (assignedUserGroup.Id == UserGroup.Group_Underwriting)
                    {
                        assignedToUserId = _caseBrokerManager.GetUnderwriterByAffiliationOrRegion(task.Case.Id);
                        if (assignedToUserId != null)
                        {
                            task.AssignedToUser = cmsUsers.FirstOrDefault(c => c.Id == assignedToUserId);
                        }
                    }
                    if (assignedUserGroup.Id == UserGroup.Group_BillingSpecialist)
                    {
                        if (wholeSaler != null && assignedUserGroup.Id == UserGroup.Group_BillingSpecialist)
                        {
                            var region = wholeSaler.WholesalerRegion.RegionName;
                            var billingSpecialist = unitOfWork.Repository<BillingSpecialistRegion>().Linq().FirstOrDefault(c => c.RegionName == region);
                            task.AssignedToUser = cmsUsers.FirstOrDefault(t => t.Id == billingSpecialist.BillingSpecialistUser.Id);
                        }
                    }
                }
            }
            Log.TraceFormat("-UpdateAssignedUserForUnassignedCases");
        }

        public void UnclaimTask(UnclaimTaskRequestDto request)
        {
            Log.TraceFormat("+UnclaimTask");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var task = unitOfWork.Repository<CmsTask>().Linq().FirstOrDefault(t => t.Id == request.TaskId);
                if (task == null) throw new ValidationException("Task not found!");

                task.ClaimedByUser = null;
                task.TaskStatusType = TaskStatusTypeEnum.Unclaimed;
                unitOfWork.Repository<CmsTask>().Save(task);
                SaveTaskActivityLog(task, unitOfWork);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-UnclaimTask");
        }

        public void CreateTask(int caseId, string taskName, int? assignedUserGroupId, int? assignedUserId, int slaHours, bool isSameDayResponseRequired, int? taskGroupId = null)
        {
            Log.TraceFormat("+CreateTask");
            var cmsTask = new CmsTask();
            bool isNewTask = true;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(t => t.Id == caseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");
                var caseWholesaler = unitOfWork.Repository<CaseWholesaler>().Linq().FirstOrDefault(v => v.Case.Id == caseId && v.IsPrimaryIndicator == true);
                UserGroup assignedUserGroup = null;
                if (assignedUserGroupId != null)
                {
                    assignedUserGroup = unitOfWork.Repository<UserGroup>().Linq().FirstOrDefault(t => t.Id == assignedUserGroupId.Value);
                }

                CmsUser assignedUser = null;

                if (caseWholesaler != null && assignedUserGroupId == UserGroup.Group_BillingSpecialist)
                {
                    var region = caseWholesaler.WholesalerRegion.RegionName;
                    var billingSpecialist = unitOfWork.Repository<BillingSpecialistRegion>().Linq().FirstOrDefault(c => c.RegionName == region);
                    if (billingSpecialist?.BillingSpecialistUser != null)
                    {
                        assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == billingSpecialist.BillingSpecialistUser.Id);
                    }
                }
                else if (assignedUserGroupId == UserGroup.Group_EnrollmentManager)
                {
                    assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == cmsCase.EnrollmentManagerId);
                }
                else if (assignedUserGroupId == UserGroup.Group_Implementation_Analyst)
                {
                    assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == cmsCase.ImplementationAnalystId);
                }
                if (assignedUserId != null)
                {
                    assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == assignedUserId.Value);
                }

                var taskGroup = unitOfWork.Repository<TaskGroup>().Linq().FirstOrDefault(t => t.Id == taskGroupId);

                isNewTask = UpdateExistingTask(taskName, assignedUserGroupId, slaHours, isSameDayResponseRequired, isNewTask, unitOfWork, cmsCase, false, null, out cmsTask);

                if (isNewTask)
                {
                    Log.TraceFormat("+CreateTask: New task created for caseId {0}", cmsCase.Id);
                    var task = new CmsTask
                    {
                        TaskName = taskName,
                        AssignedToUserGroup = assignedUserGroup,
                        AssignedToUser = assignedUser,
                        Case = cmsCase,
                        CreationDate = DateTime.Now,
                        DueDate = GetDueDate(slaHours, isSameDayResponseRequired),
                        TaskGroup = taskGroup != null ? taskGroup : null,
                        CreatedBy = "SYS_ADMIN"
                    };

                    unitOfWork.Repository<CmsTask>().Save(task);
                    SaveTaskActivityLog(task, unitOfWork);
                    unitOfWork.Commit();
                }
            }

            Log.TraceFormat("-CreateTask");
        }

        public CmsTask SaveTask(int caseId, string taskName, int? assignedUserGroupId, int? assignedUserId, int slaHours, bool isSameDayResponseRequired)
        {
            Log.TraceFormat("+SaveTask");
            var cmsTask = new CmsTask();
            bool isNewTask = true;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(t => t.Id == caseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");
                var wholeSaler = unitOfWork.Repository<CaseWholesaler>().Linq().FirstOrDefault(w => w.Case.Id == caseId);
                UserGroup assignedUserGroup = null;
                if (assignedUserGroupId != null)
                {
                    assignedUserGroup = unitOfWork.Repository<UserGroup>().Linq().FirstOrDefault(t => t.Id == assignedUserGroupId.Value);
                }

                CmsUser assignedUser = null;

                if (wholeSaler != null && assignedUserGroupId == UserGroup.Group_BillingSpecialist)
                {
                    var region = wholeSaler.WholesalerRegion.RegionName;
                    var billingSpecialist = unitOfWork.Repository<BillingSpecialistRegion>().Linq().FirstOrDefault(c => c.RegionName == region);
                    if (billingSpecialist != null)
                    {
                        assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == billingSpecialist.BillingSpecialistUser.Id);
                    }
                }

                if (assignedUserId != null)
                {
                    assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == assignedUserId.Value);
                }

                isNewTask = UpdateExistingTask(taskName, assignedUserGroupId, slaHours, isSameDayResponseRequired, isNewTask, unitOfWork, cmsCase, false, null, out cmsTask);

                if (isNewTask)
                {
                    Log.TraceFormat("+SaveTask: New task saved for caseId {0}", cmsCase.Id);
                    var newTask = new CmsTask
                    {
                        TaskName = taskName,
                        AssignedToUserGroup = assignedUserGroup,
                        AssignedToUser = assignedUser,
                        Case = cmsCase,
                        CreationDate = DateTime.Now,
                        DueDate = GetDueDate(slaHours, isSameDayResponseRequired)
                    };
                    unitOfWork.Repository<CmsTask>().Save(newTask);
                    SaveTaskActivityLog(newTask, unitOfWork);
                    unitOfWork.Commit();
                    cmsTask = newTask;
                }
            }

            Log.TraceFormat("-SaveTask");
            return cmsTask;
        }
        
        public CmsTask SaveTaskForBilling(int caseId, string taskName, int? assignedUserGroupId, int? assignedUserId, int slaHours, bool isSameDayResponseRequired, DateTime? payrollDeductionFileDueDate)
        {
            Log.TraceFormat("+SaveTaskForBilling");
            var cmsTask = new CmsTask();
            bool isNewTask = true;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(t => t.Id == caseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");
                var caseWholesaler = unitOfWork.Repository<CaseWholesaler>().Linq().FirstOrDefault(v => v.Case.Id == caseId && v.IsPrimaryIndicator == true);
                UserGroup assignedUserGroup = null;
                if (assignedUserGroupId != null)
                {
                    assignedUserGroup = unitOfWork.Repository<UserGroup>().Linq().FirstOrDefault(t => t.Id == assignedUserGroupId.Value);
                }

                CmsUser assignedUser = null;
                if (caseWholesaler != null && assignedUserGroupId == UserGroup.Group_BillingSpecialist)
                {
                    var region = caseWholesaler.WholesalerRegion.RegionName;
                    var billingSpecialist = unitOfWork.Repository<BillingSpecialistRegion>().Linq().FirstOrDefault(c => c.RegionName == region);
                    assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == billingSpecialist.BillingSpecialistUser.Id);
                }
                if (assignedUserId != null)
                {
                    assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == assignedUserId.Value);
                }

                isNewTask = UpdateExistingTask(taskName, assignedUserGroupId, slaHours, isSameDayResponseRequired, isNewTask, unitOfWork, cmsCase, true, payrollDeductionFileDueDate, out cmsTask);

                if (isNewTask)
                {
                    Log.TraceFormat("+SaveTaskForBilling: New billing task saved for caseId {0}", cmsCase.Id);
                    var task = new CmsTask
                    {
                        TaskName = taskName,
                        AssignedToUserGroup = assignedUserGroup,
                        AssignedToUser = assignedUser,
                        Case = cmsCase,
                        CreationDate = DateTime.Now,
                        DueDate = payrollDeductionFileDueDate.Value.AddHours(-slaHours)
                    };
                    unitOfWork.Repository<CmsTask>().Save(task);
                    SaveTaskActivityLog(task, unitOfWork);
                    unitOfWork.Commit();
                    cmsTask = task;
                }
            }

            Log.TraceFormat("-SaveTaskForBilling");
            return cmsTask;
        }
        private bool UpdateExistingTask(string taskName, int? assignedUserGroupId, int slaHours, bool isSameDayResponseRequired, bool isNewTask, IUnitOfWork unitOfWork, Case cmsCase, bool usePayrollFrequency, DateTime? payrollDeductionFileDueDate, out CmsTask updatedTask)
        {
            Log.TraceFormat("+UpdateExistingTask");
            CmsTask outTask = new CmsTask();
            
            if (assignedUserGroupId == UserGroup.Group_BillingSpecialist)
            {
                var existingTasks = unitOfWork.Repository<CmsTask>().Linq().OrderByDescending(j => j.Id).FirstOrDefault(i => i.TaskName.ToLower() == taskName.ToLower() 
                                                                                                         && i.AssignedToUserGroup.Id == UserGroup.Group_BillingSpecialist
                                                                                                         && i.Case.Id == cmsCase.Id);
                if (existingTasks == null)
                {
                    if (taskName.StartsWith("The enrollment date for " + cmsCase.CaseNumber))
                    {                        
                        var checkForEnrollmentTask = taskName.Substring(0, taskName.Length- 10).Trim().ToLower();
                        existingTasks = unitOfWork.Repository<CmsTask>().Linq().OrderByDescending(j => j.Id).FirstOrDefault(i => i.TaskName.ToLower().Contains(checkForEnrollmentTask)
                                                                                                         && i.AssignedToUserGroup.Id == UserGroup.Group_BillingSpecialist
                                                                                                         && i.Case.Id == cmsCase.Id);
                    }
                }

                if (existingTasks == null)
                {
                    if (taskName.StartsWith("Please create Payroll Deduction File for Case " + cmsCase.CaseNumber))
                    {                        
                        var checkForPayrollTask = taskName.Substring(0, taskName.Length - 10).Trim().ToLower();
                        existingTasks = unitOfWork.Repository<CmsTask>().Linq().OrderByDescending(j => j.Id).FirstOrDefault(i => i.TaskName.ToLower().Contains(checkForPayrollTask)
                                                                                                         && i.AssignedToUserGroup.Id == UserGroup.Group_BillingSpecialist
                                                                                                         && i.Case.Id == cmsCase.Id);
                    }
                }

                if (existingTasks != null)
                {
                    Log.TraceFormat("+UpdateExistingTask: Existing task Updated for caseId {0}", cmsCase.Id);
                    isNewTask = false;
                    existingTasks.TaskName = taskName;
                    existingTasks.Case = cmsCase;
                    existingTasks.CreationDate = DateTime.Now;
                    if (usePayrollFrequency)
                    {
                        existingTasks.DueDate = payrollDeductionFileDueDate.Value.AddHours(-slaHours);
                    }
                    else
                    {
                        existingTasks.DueDate = GetDueDate(slaHours, isSameDayResponseRequired);
                    }
                    unitOfWork.Repository<CmsTask>().Save(existingTasks);
                    SaveTaskActivityLog(existingTasks, unitOfWork);
                    unitOfWork.Commit();
                    outTask = existingTasks;
                }
            }

            if (taskName.Trim() == "Revised Case Received")
            {                                                               
                    var notCompletedUnclaimedTask = unitOfWork.Repository<CmsTask>().Linq().OrderByDescending(j => j.Id).FirstOrDefault(i => i.TaskName.ToLower() == taskName.ToLower() && i.Case.Id == cmsCase.Id && i.ClaimedByUser == null && i.IsCompletedIndicator == false);
                    var notCompletedclaimedTask = unitOfWork.Repository<CmsTask>().Linq().OrderByDescending(j => j.Id).FirstOrDefault(i => i.TaskName.ToLower() == taskName.ToLower() && i.Case.Id == cmsCase.Id && i.ClaimedByUser != null && i.IsCompletedIndicator == false);

                    if (notCompletedUnclaimedTask != null)
                    {
                        Log.TraceFormat("+UpdateExistingTask: NotCompletedUnclaimedTask Updated for caseId {0}", cmsCase.Id);
                        isNewTask = false;
                        notCompletedUnclaimedTask.TaskName = taskName;
                        notCompletedUnclaimedTask.Case = cmsCase;
                        notCompletedUnclaimedTask.CreationDate = DateTime.Now;
                        if (usePayrollFrequency)
                        {
                            notCompletedUnclaimedTask.DueDate = payrollDeductionFileDueDate.Value.AddHours(-slaHours);
                        }
                        else
                        {
                            notCompletedUnclaimedTask.DueDate = GetDueDate(slaHours, isSameDayResponseRequired);
                        }
                        unitOfWork.Repository<CmsTask>().Save(notCompletedUnclaimedTask);
                        SaveTaskActivityLog(notCompletedUnclaimedTask, unitOfWork);
                        unitOfWork.Commit();
                        outTask = notCompletedUnclaimedTask;
                        Log.TraceFormat("-UpdateExistingTask: NotCompletedUnclaimedTask Updated for caseId {0}", cmsCase.Id);
                    }
                    else if (notCompletedclaimedTask != null)
                    {
                        Log.TraceFormat("+UpdateExistingTask: notCompletedclaimedTask Updated for caseId {0}", cmsCase.Id);
                        isNewTask = false;
                        notCompletedclaimedTask.TaskName = taskName;
                        notCompletedclaimedTask.Case = cmsCase;
                        notCompletedclaimedTask.CreationDate = DateTime.Now;
                        if (usePayrollFrequency)
                        {
                            notCompletedclaimedTask.DueDate = payrollDeductionFileDueDate.Value.AddHours(-slaHours);
                        }
                        else
                        {
                            notCompletedclaimedTask.DueDate = GetDueDate(slaHours, isSameDayResponseRequired);
                        }
                        unitOfWork.Repository<CmsTask>().Save(notCompletedclaimedTask);
                        SaveTaskActivityLog(notCompletedclaimedTask, unitOfWork);
                        unitOfWork.Commit();
                        outTask = notCompletedclaimedTask;
                        Log.TraceFormat("-UpdateExistingTask: NotCompletedclaimedTask Updated for caseId {0}", cmsCase.Id);

                    }                               
            }
            Log.TraceFormat("-UpdateExistingTask");
            updatedTask = outTask;
            return isNewTask;
        }

        public DateTime GetDueDate(int slaHours, bool isSameDayResponseRequired)
        {
            Log.TraceFormat("+GetDueDate");

            DateTime dueDate = DateTime.Now;
            DateTime sameDayCutoffDateTime = Convert.ToDateTime("03:00:00 PM");

            TimeSpan dueTimeSpan = TimeSpan.FromHours(slaHours);
            DateTime sameDayExpiryDateTime = Convert.ToDateTime("11:59:00 PM");

            if (isSameDayResponseRequired)
            {
                if (dueDate < sameDayCutoffDateTime)
                {
                    dueDate = sameDayExpiryDateTime;
                }
                else
                {
                    dueDate = GetNextWorkingDay(DateTime.Now, slaHours);
                }
            }
            else
            {
                dueDate = GetNextWorkingDay(DateTime.Now, slaHours);
            }

            Log.TraceFormat("-GetDueDate");

            return dueDate;
        }     

        public void UpdateTask(int caseId, int? enrollmentManagerId, int? implementationAnalystId)
        {
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(t => t.Id == caseId);
                var cmsUsers = unitOfWork.Repository<CmsUser>().Linq().ToList();

                var enrollmentManagerTaskUser = cmsUsers.FirstOrDefault(t => t.Id == enrollmentManagerId);
                var implementationAnalystTaskUser = cmsUsers.FirstOrDefault(t => t.Id == implementationAnalystId);

                var enrollmentTasks = cmsCase.Tasks.Where(c => c.AssignedToUserGroup.Id == UserGroup.Group_EnrollmentManager).ToList();
                foreach (var task in enrollmentTasks)
                {
                    task.AssignedToUser = enrollmentManagerTaskUser;
                    unitOfWork.Repository<CmsTask>().Save(task);
                    SaveTaskActivityLog(task, unitOfWork);
                }

                var implementationTasks = cmsCase.Tasks.Where(c => c.AssignedToUserGroup.Id == UserGroup.Group_Implementation_Analyst).ToList();
                foreach (var task in implementationTasks)
                {
                    task.AssignedToUser = implementationAnalystTaskUser;
                    unitOfWork.Repository<CmsTask>().Save(task);
                    SaveTaskActivityLog(task, unitOfWork);
                }

                unitOfWork.Commit();
            }
        }

        public DateTime GetNextWorkingDay(DateTime startDate, int slaHours)
        {
            Log.TraceFormat("+GetNextWorkingDay");

            int slaInMinutes = slaHours * 60;
            DateTime nextValidDate = startDate;

            object result = string.Empty;
            try
            {
                using (var sqlConnection = new SqlConnection(_configuration.DisabilityReferenceLibraryDatabaseConnection))
                {
                    var sqlQuery = "SELECT [dbo].[UDF_GetSLADueDateTime]('" + startDate + "'," + slaInMinutes + ")";
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConnection))
                    {
                        sqlConnection.Open();
                        result = cmd.ExecuteScalar();
                        sqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error in GetNextWorkingDay from Product Library server.", ex);
            }

            Log.TraceFormat("-GetNextWorkingDay");
            DateTime.TryParse(result.ToString(), out nextValidDate);
            return nextValidDate;
        }

        public void CompleteTasks(List<int> taskIds, int? userId)
        {
            Log.TraceFormat("+CompleteTasks taskIds={0}", string.Join(",", taskIds));
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var tasks = unitOfWork.Repository<CmsTask>().Linq().Where(t => taskIds.Contains(t.Id)).ToList();
                foreach (var task in tasks)
                {
                    task.IsCompletedIndicator = true;
                    task.CompletedDate = DateTime.Now;
                    task.TaskStatusType = TaskStatusTypeEnum.Completed;
                    task.CompletedByUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(u => u.Id == userId);
                    if (task.TaskName.Trim().ToLower() == "revised case received")
                    {
                        task.ClaimedByUser = task.CompletedByUser;
                    }
                    unitOfWork.Repository<CmsTask>().Save(task);
                    SaveTaskActivityLog(task, unitOfWork);
                }
                unitOfWork.Commit();
            }
            foreach (var taksId in taskIds)
            {
                CheckEnrollmentCensusReceivedTask(taksId);
            }
            Log.TraceFormat("-CompleteTasks");
        }

        public void UpdatePolicyDecisionInFileNet(TaskPolicyDecisionDto request)
        {
            Log.TraceFormat("+UpdatePolicyDecision taskId={0}", request.TaskId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var task = unitOfWork.Repository<CmsTask>().Linq().FirstOrDefault(t => t.Id == request.TaskId);
                if (task == null) throw new ValidationException("Task not found!");

                var taskname = task.TaskName;

                string[] caseNoPlocicyNo = taskname.Split('"'); // Index - Policy Number {1} - Case Number {3} - Participant Id {5};

                if (caseNoPlocicyNo != null)
                {
                    // Fix - D2580
                    string caseNumber = caseNoPlocicyNo.Length > 5 ? caseNoPlocicyNo[3] : string.Empty;
                    string policyNumber = caseNoPlocicyNo.Length > 5 ? caseNoPlocicyNo[1] : string.Empty;
                    var enrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().FirstOrDefault(t => t.PolicyNumber == policyNumber.Trim());
                    DateTime UnderwriterResponseDateTime = DateTime.Now;

                    if (enrollmentParticipantPolicy != null)
                    {
                        int enrollmentParticipantId = enrollmentParticipantPolicy.EnrollmentParticipant.Id;

                        UploadPolicyDecisionDocToNewBusinessRepository(request, taskname, enrollmentParticipantPolicy.EnrollmentParticipant, caseNumber, policyNumber, UnderwriterResponseDateTime);
                       
                    }
                    else
                    {
                        Log.TraceFormat("UpdatePolicyDecisionInFileNet - Policy Number is not exist - " + policyNumber);
                    }
                }

                task.IsCompletedIndicator = true;
                task.CompletedDate = DateTime.Now;
                task.CompletedByUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(u => u.Id == request.TitanUserId);
                unitOfWork.Repository<CmsTask>().Save(task);
                SaveTaskActivityLog(task, unitOfWork);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-UpdatePolicyDecision");
        }

        private void UploadPolicyDecisionDocToNewBusinessRepository(TaskPolicyDecisionDto request, string taskname, EnrollmentParticipant enrollmentParticipant, string caseNumber, string policyNumber, DateTime UnderwriterResponseDateTime)
        {
            Log.TraceFormat("+UploadPolicyDecisionDocToNewBusinessRepository");

            var uploadFilenetRequest = new FileNetNewBusinessDocUploadRequest();
            uploadFilenetRequest.ParticipantFirstName = enrollmentParticipant.Participant.FirstName;
            uploadFilenetRequest.ParticipantLastName = enrollmentParticipant.Participant.LastName;
            uploadFilenetRequest.CaseNumber = caseNumber;
            uploadFilenetRequest.PolicyNumber = policyNumber;
            uploadFilenetRequest.DocumentText = UnderWriterResponse(request, taskname, UnderwriterResponseDateTime);
            request.UnderWriterResponseText = uploadFilenetRequest.DocumentText;
            SendPolicyDecision(request, enrollmentParticipant.Id, caseNumber, policyNumber, UnderwriterResponseDateTime);
            string docNumber = _fileNetDocumentRepository.UploadDocumentToNewBusinessRepository(uploadFilenetRequest);

            Log.TraceFormat("-UploadPolicyDecisionDocToNewBusinessRepository - document Number : " + docNumber);
        }

        private void SendPolicyDecision(TaskPolicyDecisionDto request, int enrollmentParticipantId, string caseNumber, string policyNumber, DateTime UnderwriterResponseDateTime)
        {
            var policyDecisionUpdateRequest = new PolicyDecisionUpdateRequest();
            policyDecisionUpdateRequest.CaseNumber = caseNumber;
            policyDecisionUpdateRequest.EnrollmentParticipantId = enrollmentParticipantId;
            policyDecisionUpdateRequest.PolicyNumber = policyNumber;
            policyDecisionUpdateRequest.UnderwriterDecision = UnderWriterPolicyDecision(request);
            policyDecisionUpdateRequest.UnderwriterResponseText = request.UnderWriterResponseText;
            policyDecisionUpdateRequest.UnderwriterResponseDateTime = UnderwriterResponseDateTime;
            _appEntryService.SendPolicyDecision(policyDecisionUpdateRequest);
        }

        private AppEntryUWPolicyDecision UnderWriterPolicyDecision(TaskPolicyDecisionDto request)
        {
            if (request.OperationId == (int)TaskPolicyDecisionOperation.Approve)
            {
                return AppEntryUWPolicyDecision.Approved;
            }
            else if (request.OperationId == (int)TaskPolicyDecisionOperation.Decline)
            {
                return AppEntryUWPolicyDecision.Declined;
            }
            else
            {
                return AppEntryUWPolicyDecision.Revised;
            }
        }

        private string UnderWriterResponse(TaskPolicyDecisionDto request, string taskname, DateTime UnderwriterResponseDateTime)
        {
            var sb = new StringBuilder();
            sb.AppendLine(taskname);

            if (request.OperationId == (int)TaskPolicyDecisionOperation.Approve)
            {
                sb.AppendLine("Underwriter action: Approve");
                sb.AppendLine(request.UnderWriterResponseText);
            }
            else if (request.OperationId == (int)TaskPolicyDecisionOperation.Decline)
            {
                sb.AppendLine("Underwriter action: Decline");
                sb.AppendLine(request.UnderWriterResponseText);
            }
            else
            {
                sb.AppendLine("Underwriter action: Revise");
                sb.AppendLine(request.UnderWriterResponseText);
            }
            sb.AppendLine("Date and Time of Underwriter Action : " + UnderwriterResponseDateTime);

            return sb.ToString();
        }

        public TaskDto GetTaskDetails(int taskId)
        {
            Log.TraceFormat("+GetTaskDetails");

            TaskDto task = null;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsTask = unitOfWork.Repository<CmsTask>().Linq().FirstOrDefault(t => t.Id == taskId);

                if (cmsTask != null)
                {
                    task = new TaskDto
                    {
                        TaskId = cmsTask.Id,
                        CaseId = cmsTask.Case.Id,
                        TaskName = cmsTask.TaskName,
                        TaskStatus = cmsTask.TaskStatusType != null ? cmsTask.TaskStatusType.GetDescription() : string.Empty,
                        IsAdHocIndicator = cmsTask.IsAdHocIndicator,
                        Comments = cmsTask.Comments,
                        DueDate = cmsTask.DueDate,
                        UpdatedDueDate = cmsTask.UpdatedDueDate,
                        FollowUpDate = cmsTask.FollowUpDate
                    };
                }
            }

            Log.TraceFormat("-GetTaskDetails");

            return task;
        }

        public void SuspendTask(SuspendTaskRequestDto request)
        {
            Log.TraceFormat("+SuspendTask");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var tasks = unitOfWork.Repository<CmsTask>().Linq().Where(t => request.TaskIds.Contains(t.Id)).ToList();

                foreach (var task in tasks)
                {
                    task.FollowUpDate = request.FollowUpDate;
                    task.SuspendedDate = DateTime.Now;
                    task.TaskStatusType = TaskStatusTypeEnum.Suspended;
                    task.SuspendedDate = DateTime.Now;
                    unitOfWork.Repository<CmsTask>().Save(task);
                    SaveTaskActivityLog(task, unitOfWork);
                }

                unitOfWork.Commit();
            }

            Log.TraceFormat("-SuspendTask");
        }

        public void UpdateTaskDueDate(UpdateTaskDueDateRequestDto request)
        {
            Log.TraceFormat("+UpdateTaskDueDate");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var tasks = unitOfWork.Repository<CmsTask>().Linq().Where(t => request.TaskIds.Contains(t.Id)).ToList();

                foreach (var task in tasks)
                {
                    task.UpdatedDueDate = request.DueDate;
                    unitOfWork.Repository<CmsTask>().Save(task);
                    SaveTaskActivityLog(task, unitOfWork);
                }

                unitOfWork.Commit();
            }

            Log.TraceFormat("-UpdateTaskDueDate");
        }

        public void UpdateTaskFollowUpDate(UpdateTaskFollowUpDateRequestDto request)
        {
            Log.TraceFormat("+UpdateTaskFollowUpDate");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var tasks = unitOfWork.Repository<CmsTask>().Linq().Where(t => request.TaskIds.Contains(t.Id)).ToList();

                foreach (var task in tasks)
                {
                    task.FollowUpDate = request.FollowUpDate;
                    unitOfWork.Repository<CmsTask>().Save(task);
                    SaveTaskActivityLog(task, unitOfWork);
                }

                unitOfWork.Commit();
            }

            Log.TraceFormat("-UpdateTaskFollowUpDate");
        }

        private void CheckEnrollmentCensusReceivedTask(int taskId)
        {
            Log.TraceFormat("+CheckEnrollmentCensusReceivedTask taskId={0}", taskId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var task = unitOfWork.Repository<CmsTask>().Linq().FirstOrDefault(t => t.Id == taskId);
                if (task == null) throw new ValidationException("Task not found!");

                if (task.TaskName.StartsWith("Enrollment Census received for Case number"))
                {
                    var taskStatus = unitOfWork.Repository<CmsTask>().Linq().Where(c => c.Case.Id == task.Case.Id && c.TaskName == task.TaskName).OrderByDescending(c => c.Id).Take(3);
                    var isNotComplete = taskStatus.Any(c => !c.IsCompletedIndicator);

                    if (!isNotComplete) // All 3 tasks are completed
                    {
                        var request = new CaseStatusDto
                        {
                            CaseId = task.Case.Id,
                            CaseStatusType = CaseStatusTypeEnum.ImplementationInProgress,
                            PlanDesignRequestStatusType = null,
                        };
                        _caseManager.SaveCaseStatusAndPDRStatus(request);

                        _caseManager.UpdatePDRStatusByCase(request.CaseId, PlanDesignRequestStatusTypeEnum.Sold);
                    }
                }
                else if (task.TaskName.StartsWith("A re-enrollment census received"))
                {
                    var isVoluntary = _planDesignRequestSoldManager.IsVoluntaryPremiumPayerClass(task.Case.Id);
                    if (isVoluntary)
                    {
                        var taskStatus = unitOfWork.Repository<CmsTask>().Linq().Where(c => c.Case.Id == task.Case.Id && c.TaskName == task.TaskName).OrderByDescending(c => c.Id).Take(3);
                        var isNotComplete = taskStatus.Any(c => !c.IsCompletedIndicator);

                        if (!isNotComplete)
                        {
                            var request = new CaseStatusDto
                            {
                                CaseId = task.Case.Id,
                                CaseStatusType = CaseStatusTypeEnum.ImplementationInProgress,
                                PlanDesignRequestStatusType = null,
                            };
                            _caseManager.SaveCaseStatusAndPDRStatus(request);

                            _caseManager.UpdatePDRStatusByCase(request.CaseId, PlanDesignRequestStatusTypeEnum.Sold);
                        }
                    }
                    else
                    {
                        var taskStatus = unitOfWork.Repository<CmsTask>().Linq().Where(c => c.Case.Id == task.Case.Id && c.TaskName == task.TaskName).OrderByDescending(c => c.Id).Take(2);
                        var isNotComplete = taskStatus.Any(c => !c.IsCompletedIndicator);

                        if (!isNotComplete)
                        {
                            var request = new CaseStatusDto
                            {
                                CaseId = task.Case.Id,
                                CaseStatusType = CaseStatusTypeEnum.ImplementationInProgress,
                                PlanDesignRequestStatusType = null,
                            };
                            _caseManager.SaveCaseStatusAndPDRStatus(request);

                            _caseManager.UpdatePDRStatusByCase(request.CaseId, PlanDesignRequestStatusTypeEnum.Sold);
                        }

                    }

                }
            }
            Log.TraceFormat("-CheckEnrollmentCensusReceivedTask");
        }

        public int? GetAssignedUserId(int caseId)
        {
            int? assignedUserId = null;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsTask = unitOfWork.Repository<CmsTask>().Linq().FirstOrDefault(c => c.Case.Id == caseId);

                if (cmsTask != null)
                {
                    assignedUserId = cmsTask.AssignedToUser != null ? (int?)cmsTask.AssignedToUser.Id : null;
                }
            }
            return assignedUserId;
        }

        public int? GetAssignedUserGroupId(int caseId)
        {
            int? assignedUserGroupId = null;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsTask = unitOfWork.Repository<CmsTask>().Linq().FirstOrDefault(c => c.Case.Id == caseId);

                if (cmsTask != null)
                {
                    assignedUserGroupId = cmsTask.AssignedToUserGroup != null ? (int?)cmsTask.AssignedToUserGroup.Id : null;
                }
            }
            return assignedUserGroupId;
        }

        public void SaveAdHocTask(TaskDto taskDto)
        {
            Log.TraceFormat("+SaveAdHocTask");

            _taskManagerValidator.ValidateAdHocData(taskDto);
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == taskDto.CaseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");

                CmsUser assignedUser = null;
                if (taskDto.UserId != null)
                {
                    assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == taskDto.UserId.Value);
                }
                UserGroup assignedUserGroup = null;
                int slaHours = 24;
                bool isSameDayResponseRequired = false;

                if (taskDto.UserGroupId != null)
                {
                    assignedUserGroup = unitOfWork.Repository<UserGroup>().Linq().FirstOrDefault(t => t.Id == taskDto.UserGroupId.Value);
                }

                var task = new CmsTask
                {
                    Case = cmsCase,
                    TaskName = taskDto.TaskName,
                    AssignedToUserGroup = assignedUserGroup,
                    AssignedToUser = assignedUser,
                    ClaimedByUser = null,
                    CreationDate = DateTime.Now,
                    Comments = taskDto.Comments,
                    FollowUpDate = null,
                    DueDate = GetDueDate(slaHours, isSameDayResponseRequired),
                    IsAdHocIndicator = true,
                    TaskStatusType = TaskStatusTypeEnum.Unclaimed,
                    CreatedBy = taskDto.CreatedBy
                };

                unitOfWork.Repository<CmsTask>().Save(task);
                SaveTaskActivityLog(task, unitOfWork);
                unitOfWork.Commit();
            }
            Log.TraceFormat("-SaveAdHocTask");
        }

        public List<TaskActivityLogDto> GetTaskActivityLogByCase(int caseId)
        {
            Log.TraceFormat("+GetTaskActivityLogByCase Case Id={0}", caseId);

            var activityTasks = new List<TaskActivityLogDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var activityTasksByTaskGroup = unitOfWork.Repository<TaskActivityLog>().Linq()
                    .Where(t => t.Case.Id == caseId)
                    .GroupBy(c => c.Task.Id)
                    .Select(group => group.Max(i => i.Id)).ToList();

                if (activityTasksByTaskGroup.Any())
                {
                    activityTasks = unitOfWork.Repository<TaskActivityLog>().Linq()
                    .Where(c => activityTasksByTaskGroup.Contains(c.Id))
                    .Select(ta => new TaskActivityLogDto
                    {
                        TaskId = ta.Task.Id,
                        TaskName = ta.Task.TaskName,
                        TaskStatus = ta.TaskStatusType != null ? ta.TaskStatusType.GetDescription() : string.Empty,
                        CreationDate = ta.CreationDate,
                        CreationDateFiltered = Convert.ToDateTime(ta.CreationDate.ToString("MM/dd/yyyy")),
                        DueDate = ta.DueDate,
                        DueDateFiltered = Convert.ToDateTime(ta.DueDate.ToString("MM/dd/yyyy")),
                        UpdatedDueDate = ta.UpdatedDueDate,
                        UpdatedDueDateFiltered = ta.UpdatedDueDate != null ? Convert.ToDateTime(ta.UpdatedDueDate.Value.ToString("MM/dd/yyyy")) : (DateTime?)null,
                        LastClaimedDate = ta.ClaimedDate,
                        LastClaimedDateFiltered = ta.ClaimedDate != null ? Convert.ToDateTime(ta.ClaimedDate.Value.ToString("MM/dd/yyyy")) : (DateTime?)null,
                        ClaimedBy = ta.ClaimedByUser != null ? ta.ClaimedByUser.FirstName + " " + ta.ClaimedByUser.LastName : string.Empty,
                        LastSuspendedDate = ta.SuspendedDate,
                        LastSuspendedDateFiltered = ta.SuspendedDate != null ? Convert.ToDateTime(ta.SuspendedDate.Value.ToString("MM/dd/yyyy")) : (DateTime?)null,
                        FollowUpDate = ta.FollowUpDate,
                        FollowUpDateFiltered = ta.FollowUpDate != null ? Convert.ToDateTime(ta.FollowUpDate.Value.ToString("MM/dd/yyyy")) : (DateTime?)null,
                        CompletedDate = ta.CompletedDate,
                        CompletedDateFiltered = ta.CompletedDate != null ? Convert.ToDateTime(ta.CompletedDate.Value.ToString("MM/dd/yyyy")) : (DateTime?)null,
                        CompletedBy = ta.CompletedByUser != null ? ta.CompletedByUser.FirstName + " " + ta.CompletedByUser.LastName : string.Empty,
                        Comments = ta.Comments != null ? ta.Comments : string.Empty,
                        CreatedBy = ta.CreatedBy != null ? ta.CreatedBy : string.Empty
                    }).ToList();
                }
            }

            Log.TraceFormat("-GetTaskActivityLogByCase");

            return activityTasks;
        }

        private void SaveTaskActivityLog(CmsTask task, IUnitOfWork unitOfWork)
        {
            Log.TraceFormat("+LogTaskActivity");
            var taskActivityLog = new TaskActivityLog
            {
                Task = task,
                TaskGroup = task.TaskGroup,
                Case = task.Case,
                CreationDate = task.CreationDate,
                DueDate = task.DueDate,
                AssignedToUser = task.AssignedToUser,
                AssignedToUserGroup = task.AssignedToUserGroup,
                ClaimedByUser = task.ClaimedByUser,
                CompletedDate = task.CompletedDate != null ? task.CompletedDate : null,
                UpdatedDueDate = task.UpdatedDueDate != null ? task.UpdatedDueDate : null,
                FollowUpDate = task.FollowUpDate != null ? task.FollowUpDate : null,
                Comments = task.Comments,
                TaskStatusType = task.TaskStatusType,
                IsAdHocIndicator = task.IsAdHocIndicator,
                ClaimedDate = task.ClaimedDate ?? null,
                SuspendedDate = task.SuspendedDate ?? null,
                CompletedByUser = task.CompletedByUser ?? null,
                CreatedBy = task.CreatedBy ?? null
            };
            unitOfWork.Repository<TaskActivityLog>().Save(taskActivityLog);
            Log.TraceFormat("-LogTaskActivity");
        }

        public void UpdateAssignedUsersFromQuickSearchResults(int caseId)
        {
            Log.TraceFormat("+UpateAssignedUsersFromQuickSearchResults");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                var cmsUsers = unitOfWork.Repository<CmsUser>().Linq().ToList();

                if (cmsCase != null)
                {
                    var cmsTasks = unitOfWork.Repository<CmsTask>().Linq().Where(c => c.Case.Id == cmsCase.Id &&
                    c.AssignedToUserGroup != null && c.AssignedToUser == null).ToList();

                    if (cmsTasks.Any())
                    {
                        var underWriterTasks = cmsTasks.Where(c => c.AssignedToUserGroup != null && c.AssignedToUserGroup.Id == UserGroup.Group_Underwriting);
                        if (underWriterTasks.Any())
                        {
                            foreach (var task in underWriterTasks)
                            {
                                UpdateAssignedUserForUnassignedCases(task, unitOfWork, cmsUsers);
                                unitOfWork.Repository<CmsTask>().Save(task);
                            }
                        }

                        var billingSpecialistTasks = cmsTasks.Where(c => c.AssignedToUserGroup != null && c.AssignedToUserGroup.Id == UserGroup.Group_BillingSpecialist);
                        if (billingSpecialistTasks.Any())
                        {
                            foreach (var task in billingSpecialistTasks)
                            {
                                UpdateAssignedUserForUnassignedCases(task, unitOfWork, cmsUsers);
                                unitOfWork.Repository<CmsTask>().Save(task);
                            }
                        }

                    }
                }
                unitOfWork.Commit();
            }

            Log.TraceFormat("+UpateAssignedUsersFromQuickSearchResults");
        }
    }

}
