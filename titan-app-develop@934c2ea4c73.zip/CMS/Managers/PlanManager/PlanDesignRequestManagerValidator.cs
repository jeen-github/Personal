﻿using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Model.Enums;
using Common.Exceptions;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using ITAdminManagers;
using CMS.Interfaces.Managers.ITAdminManagers;
using CMS.Interfaces.DataAccess;
using CMS.Model.Extensions;

namespace CMS.Managers.PlanManagers
{
    public class PlanDesignRequestManagerValidator
    {
        private const int defaultMinimumGSIAmount = 300;
        private bool isCaCase;
        private IStatePricingTypeManager _statePricingTypeManager;

        public void ValidatePlanDesignRequestData(PlanDesignDto request, EligibilityConfigurationDto eligibilityConfigurationDto, List<int> compactStateList, 
            List<int> nonCompactStateList, IStatePricingTypeManager statePricingTypeManager)
        {
            Log.TraceFormat("+ValidatePlanDesignRequestData");
            _statePricingTypeManager = statePricingTypeManager;
            var errorMessages = new List<string>();
            isCaCase = false;
            var validateSitusType = request.CaseUnderwritingRequest;
            ValidateSitusType(errorMessages, validateSitusType);
            ValidateCompactState(errorMessages, validateSitusType);
            ValidatePriceType(errorMessages, request.CaseUnderwritingRequest);
            var validateStateType = request.CaseUnderwritingRequest;

            if (request.CaseUnderwritingRequest.SitusTypeId != (int)SitusTypeEnum.Residence)
            {
                ValidateStateType(errorMessages, validateStateType);
            }

            if (request.CaseUnderwritingRequest.SitusTypeId == (int)SitusTypeEnum.Multi_State)
            {
                ValidateMultiState(errorMessages, request.CaseUnderwritingRequest);
                ValidateMultiStateCorporateSitusStateUnique(errorMessages, request.CaseUnderwritingRequest);
            }

            foreach (var casePlanDesignRequestDto in request.PlanDesignRequests)
            {
                if (casePlanDesignRequestDto.IllustrationEffectiveDate != casePlanDesignRequestDto.ExistingIllustrationEffectiveDate || casePlanDesignRequestDto.IllustrationEffectiveDate == null)
                {
                    ValidateIllustrationEffectiveDate(errorMessages, casePlanDesignRequestDto);
                }
                if (casePlanDesignRequestDto.SelectedClass != null && casePlanDesignRequestDto.IsActive && casePlanDesignRequestDto.SelectedClass.IsActive)
                {
                    var casePlanDesignRequestClassDto = casePlanDesignRequestDto.SelectedClass;
                    ValidateElgiblePopulation(errorMessages, casePlanDesignRequestClassDto);
                    ValidatePlanDesign(errorMessages, casePlanDesignRequestClassDto);
                    if (casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId != null)
                    {
                        ValidatePremiumPayerAndTaxabilityTypeId(errorMessages, casePlanDesignRequestClassDto);
                        ValidateEliminationPeriod(errorMessages, casePlanDesignRequestClassDto);
                        ValidateBenefitPeriod(errorMessages, casePlanDesignRequestClassDto);
                    }
                    if (casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.CombinationPlan)
                    {
                        ValidateLTDPercentage(errorMessages, casePlanDesignRequestClassDto);
                        ValidateIDIPercentage(errorMessages, casePlanDesignRequestClassDto);
                    }
                    if (casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.SupplementalPlan || casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.BonusOnlyPlan || casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.ReverseCombinationPlan || casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.StandAloneIDIPlan)
                    {
                        ValidateMaximumReplacementRatio(errorMessages, casePlanDesignRequestClassDto);
                    }

                    if (casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.ReverseCombinationPlan)
                    {
                        ValidateIDICovers1st(errorMessages, casePlanDesignRequestClassDto);
                        ValidateLTDCoversNext(errorMessages, casePlanDesignRequestClassDto);
                    }

                    if (casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.FlatBenefitPlan)
                    {
                        ValidateFlatBenefitPlans(errorMessages, casePlanDesignRequestClassDto);
                    }

                    if (casePlanDesignRequestClassDto.ApprovedRetirementContributionsTypeId == (int)RetirementContributionsTypeEnum.FlatContribution)
                    {
                        ValidateAnnualContributions(errorMessages, casePlanDesignRequestClassDto);
                    }

                    if (casePlanDesignRequestClassDto.ApprovedRetirementContributionsTypeId == (int)RetirementContributionsTypeEnum.PercentofCoveredEarnings)
                    {
                        if (casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId != (int)PlanDesignTypeEnum.StandAloneRPPPlan)
                        {
                            ValidateRPPRiderCoveredEarnings(errorMessages, casePlanDesignRequestClassDto);
                        }
                        else
                        {
                            ValidateCoveredEarningsType(errorMessages, casePlanDesignRequestClassDto);
                        }
                    }
                    if (casePlanDesignRequestClassDto.ApprovedRetirementContributionsTypeId == (int)RetirementContributionsTypeEnum.PercentofCoveredEarnings)
                    {
                        ValidateCoveredEarningsPercentage(errorMessages, casePlanDesignRequestClassDto);
                    }

                    ValidateTaxabilityType(errorMessages, casePlanDesignRequestClassDto);
                    ValidateVoluntaryGSIBuyUpPlanType(errorMessages, casePlanDesignRequestClassDto);
                    ValidateEmployerPaidPremium(errorMessages, casePlanDesignRequestClassDto);
                    ValidateCostShareTaxabilityType(errorMessages, casePlanDesignRequestClassDto);
                    if (casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId != (int)PlanDesignTypeEnum.StandAloneRPPPlan && casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId != null)
                    {
                        ValidateCoveredEarningsType(errorMessages, casePlanDesignRequestClassDto);
                    }
                    ValidateCoveredEarningsForBonusOnlyType(errorMessages, casePlanDesignRequestClassDto);
                    if (casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage != null && !(casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.StandAloneIDIPlan || casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.StandAloneRPPPlan))
                    {
                        ValidateElgiblePopulation(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        ValidateEliminationPeriod(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        ValidateBenefitPeriod(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        ValidateReplacementPercentage(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        ValidateLTDCap(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        ValidateCoveredEarnings(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        ValidatePremiumPayerAndTaxability(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        ValidateIsVoluntaryLTDBuyUpPlan(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        ValidateTypeOfPay(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        ValidateIsLTDPlanExistingIndicator(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);

                        if (casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator != null && casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator != false)
                        {
                            ValidateLTDBuyUpCoveredEarnings(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                            ValidateLTDBuyUpReplacementPercentage(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                            ValidateLTDBuyUpLTDCapAmount(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassLTDCoverage);
                        }
                    }

                    foreach (var planDesignRequestClassRider in casePlanDesignRequestClassDto.PlanDesignRequestClassRiders)
                    {
                        if (!planDesignRequestClassRider.IsGSIPlanIndicator)
                        {
                            ValidateOptionalRiders(errorMessages, planDesignRequestClassRider, eligibilityConfigurationDto);
                        }
                        else
                        {
                            ValidateOptionalRidersGSIBuyUpPlan(errorMessages, planDesignRequestClassRider, eligibilityConfigurationDto);
                        }
                    }

                    foreach (var planDesignRequestClassProductDto in casePlanDesignRequestClassDto.PlanDesignRequestClassProducts)
                    {
                        if (planDesignRequestClassProductDto.IsGSIPlanIndicator)
                        {
                            ValidateEmployerPaidDiscountForGSIBuyUpPlan(errorMessages, request.CaseUnderwritingRequest, planDesignRequestClassProductDto);
                            ValidateEliminationPeriodType(errorMessages, planDesignRequestClassProductDto);
                            ValidateBenefitPeriodType(errorMessages, planDesignRequestClassProductDto);
                            ValidateGSIAmountForGSIBuyUpPlan(errorMessages, planDesignRequestClassProductDto, eligibilityConfigurationDto);
                            ValidateTotalMaxGSIAmountForGSIBuyUpPlan(errorMessages, casePlanDesignRequestClassDto.PlanDesignRequestClassProducts.ToList());
                            ValidateParticipationPercentageForGSIBuyUpPlan(errorMessages, planDesignRequestClassProductDto);
                            ValidateDefinitionOfDisabilityTypeForGSIBuyUpPlan(errorMessages, planDesignRequestClassProductDto, casePlanDesignRequestClassDto.PlanDesignRequestClassRiders.Where(i => i.IsGSIPlanIndicator == true).ToList());
                            ValidateMentalSubstanceLimitationTypeForGSIBuyUpPlan(errorMessages, request.CaseUnderwritingRequest, planDesignRequestClassProductDto, compactStateList, nonCompactStateList);
                            ValidatePreExistingConditionLimitTypeForGSIBuyUpPlan(errorMessages, planDesignRequestClassProductDto);
                            ValidateDiscountForGSIBuyUpPlan(errorMessages, request.CaseUnderwritingRequest, planDesignRequestClassProductDto);
                            ValidateMinimumCaseLevelGSIAmountVGSIBuyup(errorMessages, planDesignRequestClassProductDto);
                        }
                        else
                        {
                            ValidateEmployerPaidDiscount(errorMessages, request.CaseUnderwritingRequest, planDesignRequestClassProductDto);
                            ValidateGSIAmount(errorMessages, planDesignRequestClassProductDto, eligibilityConfigurationDto);
                            ValidateParticipationPercentage(errorMessages, planDesignRequestClassProductDto);
                            ValidateDefinitionOfDisabilityType(errorMessages, planDesignRequestClassProductDto, casePlanDesignRequestClassDto.PlanDesignRequestClassRiders.Where(i=>i.IsGSIPlanIndicator == false).ToList());
                            ValidateMentalSubstanceLimitationType(errorMessages, request.CaseUnderwritingRequest, planDesignRequestClassProductDto, compactStateList, nonCompactStateList);
                            ValidatePreExistingConditionLimitType(errorMessages, planDesignRequestClassProductDto);
                            ValidateDiscountForPrimaryPlan(errorMessages, request.CaseUnderwritingRequest, planDesignRequestClassProductDto);
                            ValidateMinimumCaseLevelGSIAmount(errorMessages, planDesignRequestClassProductDto);
                        }
                    }
                }
            }
            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }

        public void ValidatePriceType(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequest, IStatePricingTypeManager statePricingTypeManager = null)
        {
            Log.TraceFormat("+ValidatePriceType");
            if (_statePricingTypeManager == null) _statePricingTypeManager = statePricingTypeManager;

            if (caseUnderwritingRequest.PricingTypeId == null)
            {
                errorMessages.Add("Please select a Product");
            }
            else
            {
                var approved = ValidateProductByState(caseUnderwritingRequest.PricingTypeId, (int)caseUnderwritingRequest.StateTypeId);
                if (!approved)
                {
                    PricingTypeEnum pricingType = (PricingTypeEnum)caseUnderwritingRequest.PricingTypeId;

                    errorMessages.Add($"The state selected is not approved for {pricingType.GetDescription()}");
                }

                // Validate state combos here
            }

            Log.TraceFormat("-ValidatePriceType");
        }

        private bool ValidateProductByState(int? pricingTypeId, int? stateTypeId)
        {
            bool approved = false;           

            approved = _statePricingTypeManager.IsStateApprovedforPricingType((int)stateTypeId, (int)pricingTypeId);

            return approved;
        }

        public void ValidateElgiblePopulation(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateElgiblePopulation");

            if (string.IsNullOrEmpty(casePlanDesignRequestClassDto.ApprovedEligiblePopulationText))
            {
                errorMessages.Add("Please enter Approved Eligible Population.");
            }
            Log.TraceFormat("-ValidateElgiblePopulation");
        }
        public void ValidateElgiblePopulation(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateExistingCoverageEligiblePopulation");

            if (string.IsNullOrEmpty(pdrLTDCoverageDto.EligiblePopulationText))
            {
                errorMessages.Add("Please enter Group LTD Eligible Population.");
            }
            Log.TraceFormat("-ValidateExistingCoverageEligiblePopulation.");
        }

        public void ValidateEliminationPeriod(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateExistingCoverageEliminationPeriod");

            if (pdrLTDCoverageDto.EliminationPeriodDays == 0)
            {
                errorMessages.Add("Please enter the Group LTD Elimination Period.");
            }
            else
            {
                if (pdrLTDCoverageDto.EliminationPeriodDays < 0)
                {
                    errorMessages.Add("Please enter a valid Group LTD Elimination Period.");
                }
            }
            Log.TraceFormat("-ValidateExistingCoverageEliminationPeriod");
        }

        public void ValidateBenefitPeriod(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateExistingCoverageBenefitPeriod.");

            if (pdrLTDCoverageDto.BenefitPeriodDays == 0)
            {
                errorMessages.Add("Please enter the Group LTD Benefit Period.");
            }
            if (pdrLTDCoverageDto.BenefitPeriodDays < 0)
            {
                errorMessages.Add("Please enter a valid Group LTD Benefit Period.");
            }
            Log.TraceFormat("-ValidateExistingCoverageBenefitPeriod");
        }

        public void ValidateReplacementPercentage(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateExistingCoverageReplacementPercentage");

            if (pdrLTDCoverageDto.GroupLTDReplacementPercentage == 0)
            {
                errorMessages.Add("Please enter the Group LTD Replacement Percentage.");
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(pdrLTDCoverageDto.GroupLTDReplacementPercentage))
                {
                    if (pdrLTDCoverageDto.GroupLTDReplacementPercentage <= 0 || pdrLTDCoverageDto.GroupLTDReplacementPercentage > 100)
                    {
                        errorMessages.Add("Please enter a valid Group LTD Replacement Percentage.");
                    }
                }
                else
                {
                    if (pdrLTDCoverageDto.GroupLTDReplacementPercentage > 0 && pdrLTDCoverageDto.GroupLTDReplacementPercentage < 100)
                    {
                        var match = Regex.Match(Convert.ToString(pdrLTDCoverageDto.GroupLTDReplacementPercentage), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid Group LTD Replacement Percentage.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid Group LTD Replacement Percentage.");
                    }
                }
            }
            Log.TraceFormat("-ValidateExistingCoverageReplacementPercentage");
        }

        public void ValidateSavePDRCustomizedIncomesData(PDRClassCustomizedIDIInsurableIncomeDto request)
        {
            Log.TraceFormat("+ValidateSavePDRCustomizedIncomesData");

            var errorMessages = new List<string>();

            ValidateCustomIncomePercentageandYear(errorMessages, "Base Salary", request.BaseSalaryPercentage);
            ValidateCustomIncomePercentageandYear(errorMessages, "Bonus", request.BonusPercentage, request.BonusNumberofYears);
            ValidateCustomIncomePercentageandYear(errorMessages, "Commission", request.CommissionPercentage, request.CommissionNumberofYears);
            ValidateCustomIncomePercentageandYear(errorMessages, "Other Income", request.OtherIncomePercentage);
            ValidateCustomIncomePercentageandYear(errorMessages, "K-1 Earnings", request.K1EarningsPercentage, request.K1EarningsNumberofYears);

            if (errorMessages.Any()) throw new ValidationException(errorMessages);
            Log.TraceFormat("-ValidateSavePDRCustomizedIncomesData");
        }

        private void ValidateCustomIncomePercentageandYear(List<string> errorMessages, string messageFor, decimal? percentage, int? numberOfYear)
        {
            if (percentage.HasValue && percentage.Value != 0)
            {
                if (percentage.Value > 0 && percentage.Value <= 1)
                {
                    if (!numberOfYear.HasValue)
                    {
                        errorMessages.Add("Please select the number of years for " + messageFor);
                    }
                }
                else
                {
                    errorMessages.Add("Please enter a valid " + messageFor + " Percentage.");
                }
            }
        }

        public void ValidateSavePDRLTDCustomizedIncomesData(PlanDesignRequestClassLTDCoverageDto request)
        {
            Log.TraceFormat("+ValidateSavePDRLTDCustomizedIncomesData");

            var errorMessages = new List<string>();

            ValidateCustomIncomePercentageandYear(errorMessages, "Base Salary", request.BaseSalaryPercentage);
            ValidateCustomIncomePercentageandYear(errorMessages, "Bonus", request.BonusPercentage, request.BonusNumberofYears);
            ValidateCustomIncomePercentageandYear(errorMessages, "Commission", request.CommissionPercentage, request.CommissionNumberofYears);
            ValidateCustomIncomePercentageandYear(errorMessages, "Other Income", request.OtherIncomePercentage);
            ValidateCustomIncomePercentageandYear(errorMessages, "K-1 Earnings", request.K1EarningsPercentage, request.K1EarningsNumberofYears);

            if (errorMessages.Any()) throw new ValidationException(errorMessages);
            Log.TraceFormat("-ValidateSavePDRLTDCustomizedIncomesData");
        }

        private void ValidateCustomIncomePercentageandYear(List<string> errorMessages, string messageFor, decimal? percentage)
        {
            if (percentage.HasValue && percentage.Value != 0)
            {
                if (!(percentage.Value > 0 && percentage.Value <= 1))
                {
                    errorMessages.Add("Please enter a valid " + messageFor + " Percentage.");
                }
            }
        }

        public void ValidateLTDCap(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateLTDCap");

            if (pdrLTDCoverageDto.GroupLTDCapAmount == 0)
            {
                errorMessages.Add("Please enter the Group LTD Cap.");
            }
            else if (pdrLTDCoverageDto.GroupLTDCapAmount < 0)
            {
                errorMessages.Add("Please enter a valid Group LTD Cap.");
            }
            Log.TraceFormat("-ValidateLTDCap");
        }

        public void ValidateCoveredEarnings(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateCoveredEarnings");

            if (!pdrLTDCoverageDto.HasCustomizedLTDInsurableIncome)
            {
                if (pdrLTDCoverageDto.GroupLTDCoveredEarningsTypeId == 0)
                {
                    errorMessages.Add("Please enter Group LTD Covered Earnings.");
                }
            }

            Log.TraceFormat("-ValidateCoveredEarnings.");
        }

        public void ValidatePremiumPayerAndTaxability(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidatePremiumPayerAndTaxability");

            if (pdrLTDCoverageDto.PremiumAndTaxpayerLiabilityTypeId == 0)
            {
                errorMessages.Add("Please enter Group LTD Premium Payer And Taxability.");
            }
            Log.TraceFormat("-ValidatePremiumPayerAndTaxability.");
        }

        public void ValidateIsVoluntaryLTDBuyUpPlan(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateIsVoluntaryLTDBuyUpPlan");

            if (pdrLTDCoverageDto.PremiumAndTaxpayerLiabilityTypeId != 0 && pdrLTDCoverageDto.PremiumAndTaxpayerLiabilityTypeId != (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable && pdrLTDCoverageDto.PremiumAndTaxpayerLiabilityTypeId != (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare
                && pdrLTDCoverageDto.IsVoluntaryLTDBuyUpIndicator == null)
            {
                errorMessages.Add("Please select Voluntary LTD Buy Up Plan.");
            }
            Log.TraceFormat("-ValidateIsVoluntaryLTDBuyUpPlan.");
        }

        public void ValidateTypeOfPay(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateTypeOfPay.");

            if (pdrLTDCoverageDto.PremiumAndTaxpayerLiabilityTypeId == 1 && pdrLTDCoverageDto.TypeOfPayTypeId == null)
            {
                errorMessages.Add("Please select the Type Of Pay.");
            }
            Log.TraceFormat("-ValidateTypeOfPay.");
        }

        public void ValidateIsLTDPlanExistingIndicator(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateIsLTDPlanExistingIndicator");

            if (pdrLTDCoverageDto.IsLTDPlanExistingIndicator == null)
            {
                errorMessages.Add("Please enter Group LTD Plan Existing Indicator.");
            }
            Log.TraceFormat("-ValidateIsLTDPlanExistingIndicator.");
        }

        public void ValidateLTDBuyUpCoveredEarnings(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateLTDBuyUpCoveredEarnings");

            if (pdrLTDCoverageDto.LTDBuyUpCoveredEarningsTypeId == null)
            {
                errorMessages.Add("Please select the Voluntary LTD Buy Up Plan Covered Earnings.");
            }
            Log.TraceFormat("-ValidateLTDBuyUpCoveredEarnings.");
        }

        public void ValidateLTDBuyUpReplacementPercentage(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateLTDbuyUpCoverageReplacementPercentage");

            if (pdrLTDCoverageDto.LTDBuyUpReplacementPercentage == null)
            {
                errorMessages.Add("Please enter Voluntary LTD Buy Up Replacement Percentage.");
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(pdrLTDCoverageDto.LTDBuyUpReplacementPercentage))
                {
                    if (pdrLTDCoverageDto.LTDBuyUpReplacementPercentage <= 0 || pdrLTDCoverageDto.LTDBuyUpReplacementPercentage > 100)
                    {
                        errorMessages.Add("Please enter a valid Voluntary LTD Buy Up Replacement Percentage.");
                    }
                }
                else
                {
                    if (pdrLTDCoverageDto.LTDBuyUpReplacementPercentage > 0 && pdrLTDCoverageDto.LTDBuyUpReplacementPercentage < 100)
                    {
                        var match = Regex.Match(Convert.ToString(pdrLTDCoverageDto.LTDBuyUpReplacementPercentage), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid Voluntary LTD Buy Up Replacement Percentage.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid Voluntary LTD Buy Up Replacement Percentage.");
                    }
                }
            }
            Log.TraceFormat("-ValidateLTDBuyUpReplacementPercentage");
        }

        public void ValidateLTDBuyUpLTDCapAmount(List<string> errorMessages, PlanDesignRequestClassLTDCoverageDto pdrLTDCoverageDto)
        {
            Log.TraceFormat("+ValidateLTDBuyUpLTDCapAmount");

            if (pdrLTDCoverageDto.LTDBuyUpLTDCapAmount == null)
            {
                errorMessages.Add("Please enter Voluntary LTD Buy Up LTD Cap.");
            }
            else if (pdrLTDCoverageDto.LTDBuyUpLTDCapAmount <= 0)
            {
                errorMessages.Add("Please enter a valid Voluntary Buy Up LTD Cap greater than zero.");
            }
            Log.TraceFormat("-ValidateLTDBuyUpLTDCapAmount");
        }

        public bool IsDecimalOrInteger(decimal? percentage)
        {
            return percentage % 1 == 0;
        }

        public void ValidateCompactState(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto)
        {
            Log.TraceFormat("+ValidateIsCompact");
            if (caseUnderwritingRequestDto.IsCompactState == null)
            {
                errorMessages.Add("Please select Compact State option.");
            }
            Log.TraceFormat("-ValidateIsCompact");
        }

        public void ValidateSitusType(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto)
        {
            Log.TraceFormat("+ValidateSitysType");
            if (caseUnderwritingRequestDto.SitusTypeId == null)
            {
                errorMessages.Add("Please select Situs Type.");
            }
            if (caseUnderwritingRequestDto.StateTypeId == (int)StateTypeEnum.CA)
            {
                isCaCase = true;
            }
            Log.TraceFormat("-ValidateSitysType");
        }

        public void ValidateStateType(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto)
        {
            Log.TraceFormat("+ValidateStateType");
            if (caseUnderwritingRequestDto.StateTypeId == null || caseUnderwritingRequestDto.StateTypeId == 0)
            {
                errorMessages.Add("Please select the Corporate Situs State.");
            }


            Log.TraceFormat("-ValidateStateType");
        }

        public void ValidatePlanDesign(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidatePlanDesign");
            if (casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == null)
            {
                if (!errorMessages.Contains("Please select Plan Design."))
                {
                    errorMessages.Add("Please select Plan Design.");
                }
            }
            //else
            //{
            //    if (isCaCase && casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int?)PlanDesignTypeEnum.StandAloneRPPPlan)
            //    {
            //        if (!errorMessages.Contains("Cannot save plan design 'Stand Alone Retirement Protection Plus (RPP) Plan' for a California case"))
            //        {
            //            errorMessages.Add("Cannot save plan design 'Stand Alone Retirement Protection Plus (RPP) Plan' for a California case");
            //        }
            //    }
            //}

            Log.TraceFormat("-ValidatePlanDesign");
        }
        public void ValidateIllustrationEffectiveDate(List<string> errorMessages, PlanDesignRequestDto casePlanDesignRequestDto)
        {
            Log.TraceFormat("+ValidateIllustrationEffectiveDate");
            if (casePlanDesignRequestDto.IllustrationEffectiveDate == null)
            {
                if (!errorMessages.Contains("Please enter the Effective Date."))
                {
                    errorMessages.Add("Please enter the Effective Date.");
                }
            }
            else if (casePlanDesignRequestDto.IllustrationEffectiveDate != null)
            {
                var illustrationEffectiveDate = DateTime.ParseExact(String.Format("{0:MM/dd/yyyy}", casePlanDesignRequestDto.IllustrationEffectiveDate), "MM/dd/yyyy", CultureInfo.InvariantCulture);
                var todaysDate = DateTime.Today;

                if (!(illustrationEffectiveDate == todaysDate) && !(illustrationEffectiveDate > todaysDate))
                {
                    if (!errorMessages.Contains("Illustration Effective Date must be greater or equal to today."))
                    {
                        errorMessages.Add("Illustration Effective Date must be greater or equal to today.");
                    }
                }
            }

            Log.TraceFormat("-ValidateIllustrationEffectiveDate");
        }

        public void ValidatePremiumPayerAndTaxabilityTypeId(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidatePremiumPayerAndTaxabilityTypeId");
            if (casePlanDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId == null)
            {
                if (!errorMessages.Contains("Please select Premium Payer and Taxability."))
                {
                    errorMessages.Add("Please select Premium Payer and Taxability.");
                }
            }
            Log.TraceFormat("-ValidatePremiumPayerAndTaxabilityTypeId");
        }

        public void ValidateMaximumReplacementRatio(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateMaximumReplacementRatio");
            if (casePlanDesignRequestClassDto.ApprovedMaximumReplacementRatio == null)
            {
                if (!errorMessages.Contains("Please enter Maximum Replacement Ratio Approved Value."))
                {
                    errorMessages.Add("Please enter Maximum Replacement Ratio Approved Value.");
                }
            }
            else if (casePlanDesignRequestClassDto.ApprovedMaximumReplacementRatio < 0 || casePlanDesignRequestClassDto.ApprovedMaximumReplacementRatio > 100)
            {
                if (!errorMessages.Contains("Please enter a valid Maximum Replacement Ratio Approved Value."))
                {
                    errorMessages.Add("Please enter a valid Maximum Replacement Ratio Approved Value.");
                }
            }
            Log.TraceFormat("-ValidateMaximumReplacementRatio");
        }

        public void ValidateEliminationPeriod(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateEliminationPeriod");
            if (casePlanDesignRequestClassDto.ApprovedEliminationPeriodTypeId == null || casePlanDesignRequestClassDto.ApprovedEliminationPeriodTypeId == 1)
            {
                if (!errorMessages.Contains("Please enter the Elimination Period Approved Value."))
                {
                    errorMessages.Add("Please enter the Elimination Period Approved Value.");
                }
            }
            Log.TraceFormat("-ValidateEliminationPeriod");
        }

        public void ValidateLTDPercentage(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateLTDPercentage");
            if (casePlanDesignRequestClassDto.ApprovedLTDPercentage == null)
            {
                if (!errorMessages.Contains("Please enter LTD Percentage Approved Value."))
                {
                    errorMessages.Add("Please enter LTD Percentage Approved Value.");
                }
            }

            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(casePlanDesignRequestClassDto.ApprovedLTDPercentage))
                {
                    if (casePlanDesignRequestClassDto.ApprovedLTDPercentage < 0 || casePlanDesignRequestClassDto.ApprovedLTDPercentage > 100)
                    {
                        errorMessages.Add("Please enter a valid LTD Percentage Approved Value.");
                    }
                }
                else
                {
                    if (casePlanDesignRequestClassDto.ApprovedLTDPercentage > 0 && casePlanDesignRequestClassDto.ApprovedLTDPercentage < 100)
                    {
                        var match = Regex.Match(Convert.ToString(casePlanDesignRequestClassDto.ApprovedLTDPercentage), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid LTD Percentage Approved Value.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid LTD Percentage Approved Value.");
                    }
                }
            }
            Log.TraceFormat("-ValidateLTDPercentage");
        }
        public void ValidateIDIPercentage(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateIDIPercentage");
            if (casePlanDesignRequestClassDto.ApprovedIDIPercentage == null)
            {
                if (!errorMessages.Contains("Please enter IDI Percentage Approved Value."))
                {
                    errorMessages.Add("Please enter IDI Percentage Approved Value.");
                }
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(casePlanDesignRequestClassDto.ApprovedIDIPercentage))
                {
                    if (casePlanDesignRequestClassDto.ApprovedIDIPercentage < 0 || casePlanDesignRequestClassDto.ApprovedIDIPercentage > 100)
                    {
                        errorMessages.Add("Please enter a valid IDI Percentage Approved Value.");
                    }
                }
                else
                {
                    if (casePlanDesignRequestClassDto.ApprovedIDIPercentage > 0 && casePlanDesignRequestClassDto.ApprovedIDIPercentage < 100)
                    {
                        var match = Regex.Match(Convert.ToString(casePlanDesignRequestClassDto.ApprovedIDIPercentage), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid IDI Percentage Approved Value.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid IDI Percentage Approved Value.");
                    }
                }
            }
            Log.TraceFormat("-ValidateIDIPercentage");
        }

        public void ValidateIDICovers1st(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateIDICovers1st");

            if (casePlanDesignRequestClassDto.ApprovedIDICovers1st == null)
            {
                errorMessages.Add("Please enter IDI Covers 1st Approved Value.");
            }
            else if (casePlanDesignRequestClassDto.ApprovedIDICovers1st < 0)
            {
                errorMessages.Add("Please enter a valid IDI Covers 1st Approved Value.");
            }
            Log.TraceFormat("-ValidateIDICovers1st");
        }
        public void ValidateLTDCoversNext(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateLTDCoversNext");

            if (casePlanDesignRequestClassDto.ApprovedLTDCoversNext == null)
            {
                errorMessages.Add("Please enter LTD Covers Next Approved Value.");
            }
            else if (casePlanDesignRequestClassDto.ApprovedLTDCoversNext < 0)
            {
                errorMessages.Add("Please enter a valid LTD Covers Next Approved Value.");
            }
            Log.TraceFormat("-ValidateLTDCoversNext");
        }
        public void ValidateAnnualContributions(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateAnnualContributions");

            if (casePlanDesignRequestClassDto.ApprovedAnnualContributions == null)
            {
                errorMessages.Add("Please enter Annual Contributions Approved Value.");
            }
            else if (casePlanDesignRequestClassDto.ApprovedAnnualContributions < 0)
            {
                errorMessages.Add("Please enter Annual Contributions Approved Value.");
            }
            Log.TraceFormat("-ValidateAnnualContributions");
        }

        public void ValidateRPPRiderCoveredEarnings(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateRPPRiderCoveredEarnings");

            if (casePlanDesignRequestClassDto.ApprovedRppRiderCoveredEarningsTypeId == null)
            {
                errorMessages.Add("Please enter RPP Rider Covered Earnings Approved Value.");
            }
            else if (casePlanDesignRequestClassDto.ApprovedAnnualContributions < 0)
            {
                errorMessages.Add("Please enter RPP Rider Covered Earnings Approved Value.");
            }
            Log.TraceFormat("-ValidateRPPRiderCoveredEarnings");
        }

        public void ValidateMultiState(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto)
        {
            Log.TraceFormat("+ValidateMultiState");
            if (caseUnderwritingRequestDto.SitusMultiState1TypeId == 0 || caseUnderwritingRequestDto.SitusMultiState1TypeId == null)
            {
                errorMessages.Add("Please select the Multi-State.");
            }
            Log.TraceFormat("-ValidateMultiState");
        }
        public void ValidateMultiStateCorporateSitusStateUnique(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto)
        {
            Log.TraceFormat("+ValidateMultiStateCorporateSitusStateUnique");

            List<int?> stateList = new List<int?>();
            if (caseUnderwritingRequestDto.StateTypeId != null && caseUnderwritingRequestDto.StateTypeId != 0)
            {
                stateList.Add(caseUnderwritingRequestDto.StateTypeId);
            }
            if (caseUnderwritingRequestDto.SitusMultiState1TypeId != null && caseUnderwritingRequestDto.SitusMultiState1TypeId != 0)
            {
                stateList.Add(caseUnderwritingRequestDto.SitusMultiState1TypeId);                
            }
            if (caseUnderwritingRequestDto.SitusMultiState2TypeId != null && caseUnderwritingRequestDto.SitusMultiState2TypeId != 0)
            {
                stateList.Add(caseUnderwritingRequestDto.SitusMultiState2TypeId);              
            }
            if (caseUnderwritingRequestDto.SitusMultiState3TypeId != null && caseUnderwritingRequestDto.SitusMultiState3TypeId != 0)
            {
                stateList.Add(caseUnderwritingRequestDto.SitusMultiState3TypeId);               
            }

            bool isUnique = stateList.Distinct().Count() == stateList.Count();
            if (!isUnique)
            {
                errorMessages.Add("Please select unique Multi-State and Corporate Situs State.");
            }

            Log.TraceFormat("-ValidateMultiStateCorporateSitusStateUnique");
        }

        private void ValidateFlatBenefitPlans(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateFlatBenefitPlans");
            if (casePlanDesignRequestClassDto.ApprovedFlatRateType_Id == null || (casePlanDesignRequestClassDto.ApprovedFlatRateType_Id == 99 && casePlanDesignRequestClassDto.ApprovedFlatRate_Other == null))
            {
                if (!errorMessages.Contains("Please enter the Flat Rate Approved Value."))
                {
                    errorMessages.Add("Please enter the Flat Rate Approved Value.");
                }
            }
            Log.TraceFormat("-ValidateFlatBenefitPlans");
        }

        public void ValidateCoveredEarningsPercentage(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateCoveredEarningsPercentage");
            if (casePlanDesignRequestClassDto.ApprovedCoveredEarningsPercentage == null)
            {
                if (!errorMessages.Contains("Please enter Requested Percentage Approved Value."))
                {
                    errorMessages.Add("Please enter Requested Percentage Approved Value.");
                }
            }

            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(casePlanDesignRequestClassDto.ApprovedCoveredEarningsPercentage))
                {
                    if (casePlanDesignRequestClassDto.ApprovedCoveredEarningsPercentage < 0 || casePlanDesignRequestClassDto.ApprovedCoveredEarningsPercentage > 100)
                    {
                        errorMessages.Add("Please enter a valid Requested Percentage Approved Value.");
                    }
                }
                else
                {
                    if (casePlanDesignRequestClassDto.ApprovedCoveredEarningsPercentage > 0 && casePlanDesignRequestClassDto.ApprovedCoveredEarningsPercentage < 100)
                    {
                        var match = Regex.Match(Convert.ToString(casePlanDesignRequestClassDto.ApprovedLTDPercentage), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid Requested Percentage Approved Value.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid Requested Percentage Approved Value.");
                    }
                }
            }
            Log.TraceFormat("-ValidateCoveredEarningsPercentage");
        }

        public void ValidateTaxabilityType(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateTaxabilityType");
            if (casePlanDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid && casePlanDesignRequestClassDto.ApprovedTaxabilityTypeId == null)
            {
                if (!errorMessages.Contains("Please select Approved Type Of Pay."))
                {
                    errorMessages.Add("Please select Approved Type Of Pay.");
                }
            }
            Log.TraceFormat("-ValidateTaxabilityType");

        }
        public void ValidateVoluntaryGSIBuyUpPlanType(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateVoluntaryGSIBuyUpPlanType");
            int insurableIncomescount = 0;
            if (casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count > 0)
            {
                if (casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault().IsSold)
                {
                    if (casePlanDesignRequestClassDto.PlanDesignRequestClassId != 0)
                    {
                        insurableIncomescount = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.PDRSoldClassId == casePlanDesignRequestClassDto.PlanDesignRequestClassId && c.IsGSIPlanIndicator == true);
                    }
                    else
                    {
                        insurableIncomescount = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.IsGSIPlanIndicator == true);
                    }
                }
                else
                {
                    if (casePlanDesignRequestClassDto.PlanDesignRequestClassId != 0)
                    {
                        insurableIncomescount = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.PlanDesignRequestClassId == casePlanDesignRequestClassDto.PlanDesignRequestClassId && c.IsGSIPlanIndicator == true);
                    }
                    else
                    {
                        insurableIncomescount = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.IsGSIPlanIndicator == true);
                    }
                }
            }


            if ((casePlanDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid || casePlanDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable) && casePlanDesignRequestClassDto.IsApprovedVoluntaryGSIBuyUpPlan == null)
            {
                if (!errorMessages.Contains("Please select Approved Voluntary GSI Buy Up Plan."))
                {
                    errorMessages.Add("Please select Approved Voluntary GSI Buy Up Plan.");
                }
            }
            else if ((casePlanDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid || casePlanDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable) && casePlanDesignRequestClassDto.IsApprovedVoluntaryGSIBuyUpPlan == true)
            {
                if (casePlanDesignRequestClassDto.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId == null)
                {
                    if (!errorMessages.Contains("Please select Approved Plan Design for GSI Buy Up Plan."))
                    {
                        errorMessages.Add("Please select Approved Plan Design for GSI Buy Up Plan.");
                    }
                }
                if (insurableIncomescount == 0)
                {
                    if (casePlanDesignRequestClassDto.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId == (int)PlanDesignGSITypeEnum.SupplementalPlan)
                    {
                        if (casePlanDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId == null)
                        {
                            if (!errorMessages.Contains("Please select Approved Covered Earnings for GSI Buy Up Plan."))
                            {
                                errorMessages.Add("Please select Approved Covered Earnings for GSI Buy Up Plan.");
                            }
                        }
                    }

                    if (casePlanDesignRequestClassDto.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId == (int)PlanDesignGSITypeEnum.BonusOnlyPlan)
                    {
                        if (casePlanDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId == null)
                        {
                            if (!errorMessages.Contains("Please select Approved Covered Earnings for GSI Buy Up Plan."))
                            {
                                errorMessages.Add("Please select Approved Covered Earnings for GSI Buy Up Plan.");
                            }
                        }
                    }
                }

                if (casePlanDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage == null)
                {
                    if (!errorMessages.Contains("Please enter Approved Replacement Percentage for GSI Buy Up Plan."))
                    {
                        errorMessages.Add("Please enter Approved Replacement Percentage for GSI Buy Up Plan.");
                    }
                }

                if (casePlanDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage != null)
                {
                    var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                    if (IsDecimalOrInteger(casePlanDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage))
                    {
                        if (casePlanDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage < 0 || casePlanDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage > 100)
                        {
                            errorMessages.Add("Please enter a valid Replacement Percentage Approved Value for GSI Buy Up Plan.");
                        }
                    }
                    else
                    {
                        if (casePlanDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage > 0 && casePlanDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage < 100)
                        {
                            var match = Regex.Match(Convert.ToString(casePlanDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage), regex, RegexOptions.IgnoreCase);
                            if (!match.Success)
                            {
                                errorMessages.Add("Please enter a valid Replacement Percentage Approved Value for GSI Buy Up Plan.");
                            }
                        }
                        else
                        {
                            errorMessages.Add("Please enter a valid Replacement Percentage Approved Value for GSI Buy Up Plan.");
                        }
                    }
                }
            }


            Log.TraceFormat("-ValidateVoluntaryGSIBuyUpPlanType");
        }

        public void ValidateOptionalRiders(List<string> errorMessages, PlanDesignRequestClassRiderDto PlanDesignRequestClassRiderDto, EligibilityConfigurationDto eligibilityConfigurationDto)
        {
            Log.TraceFormat("+ValidateOptionalRiders");
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.PartialDisability && PlanDesignRequestClassRiderDto.SelectedBenefitType.ToString() == string.Empty)
            {
                if (!errorMessages.Contains("Please select the Partial/Residual Disability for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Partial/Residual Disability for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.CatastrophicDisabilityBenefit && PlanDesignRequestClassRiderDto.SelectedBenefitType.ToString() == string.Empty)
            {
                if (!errorMessages.Contains("Please select the Catastrophic Disability (CAT) for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Catastrophic Disability (CAT) for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.CatastrophicDisabilityBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount > eligibilityConfigurationDto.CATLimitAmount || PlanDesignRequestClassRiderDto.ApprovedAmount <= 0))
            {
                if (!errorMessages.Contains("Please enter a valid Catastrophic Approved Amount for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please enter a valid Catastrophic Approved Amount for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.CatastrophicDisabilityBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount == null))
            {
                if (!errorMessages.Contains("Please enter the Catastrophic Approved Amount for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Catastrophic Approved Amount for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.CostOfLivingAdjustment && PlanDesignRequestClassRiderDto.SelectedBenefitType.ToString() == string.Empty)
            {
                if (!errorMessages.Contains("Please select the type of Cost of Living Adjustment for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the type of Cost of Living Adjustment for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit && PlanDesignRequestClassRiderDto.SelectedBenefitType.ToString() == string.Empty)
            {
                if (!errorMessages.Contains("Please select the Type of Retirement Protection Plus for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Type of Retirement Protection Plus for the Primary Plan Approvals.");
                }
            }


                if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount > eligibilityConfigurationDto.RPPMaximumIndemnityAmount || PlanDesignRequestClassRiderDto.ApprovedAmount <= 0))
                {
                    if (!errorMessages.Contains("Please enter a valid Retirement Protection Plus Amount for the Primary Plan Approvals."))
                    {
                        errorMessages.Add("Please enter a valid Retirement Protection Plus Amount for the Primary Plan Approvals.");
                    }
                }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount == null))
            {
                if (!errorMessages.Contains("Please enter the Retirement Protection Plus Amount for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Retirement Protection Plus Amount for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit && PlanDesignRequestClassRiderDto.SelectedEliminationPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Retirement Protection Plus Elimination Period for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Retirement Protection Plus Elimination Period for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.StudentLoanProtectionRider && (PlanDesignRequestClassRiderDto.ApprovedAmount > 2500 || PlanDesignRequestClassRiderDto.ApprovedAmount <= 0))
            {
                if (!errorMessages.Contains("Please enter a valid Student Loan Protection Indemnity amount for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please enter a valid Student Loan Protection Indemnity amount for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.StudentLoanProtectionRider && (PlanDesignRequestClassRiderDto.ApprovedAmount == null))
            {
                if (!errorMessages.Contains("Please enter the Student Loan Protection Indemnity amount for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Student Loan Protection Indemnity amount for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.StudentLoanProtectionRider && PlanDesignRequestClassRiderDto.SelectedEliminationPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Student Loan Protection Elimination Period for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Student Loan Protection Elimination Period for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.StudentLoanProtectionRider && PlanDesignRequestClassRiderDto.SelectedBenefitPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Student Loan Protection Elimination Term for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Student Loan Protection Elimination Term for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.SupplementalBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount > 2000 || PlanDesignRequestClassRiderDto.ApprovedAmount <= 0))
            {
                if (!errorMessages.Contains("Please enter a valid Supplemental Benefit Term Rider Indemnity amount for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please enter a valid Supplemental Benefit Term Rider Indemnity amount for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.SupplementalBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount == null))
            {
                if (!errorMessages.Contains("Please enter the Supplemental Benefit Term Rider Indemnity amount for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Supplemental Benefit Term Rider Indemnity amount for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.SupplementalBenefit && PlanDesignRequestClassRiderDto.SelectedEliminationPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Supplemental Benefit Term Rider Elimination Period for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Supplemental Benefit Term Rider Elimination Period for the Primary Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.SupplementalBenefit && PlanDesignRequestClassRiderDto.SelectedBenefitPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Supplemental Benefit Term Rider Elimination Term for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Supplemental Benefit Term Rider Elimination Term for the Primary Plan Approvals.");
                }
            }
            Log.TraceFormat("-ValidateOptionalRiders");
        }

        public void ValidateOptionalRidersGSIBuyUpPlan(List<string> errorMessages, PlanDesignRequestClassRiderDto PlanDesignRequestClassRiderDto, EligibilityConfigurationDto eligibilityConfigurationDto)
        {
            Log.TraceFormat("+ValidateOptionalRidersGSIBuyUpPlan");
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.PartialDisability && PlanDesignRequestClassRiderDto.SelectedBenefitType.ToString() == string.Empty)
            {
                if (!errorMessages.Contains("Please select the Partial/Residual Disability for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Partial/Residual Disability for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.CatastrophicDisabilityBenefit && PlanDesignRequestClassRiderDto.SelectedBenefitType.ToString() == string.Empty)
            {
                if (!errorMessages.Contains("Please select the Catastrophic Disability (CAT) for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Catastrophic Disability (CAT) for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.CatastrophicDisabilityBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount > eligibilityConfigurationDto.CATLimitAmount || PlanDesignRequestClassRiderDto.ApprovedAmount <= 0))
            {
                if (!errorMessages.Contains("Please enter a valid Catastrophic Approved Amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter a valid Catastrophic Approved Amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.CatastrophicDisabilityBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount == null))
            {
                if (!errorMessages.Contains("Please enter the Catastrophic Approved Amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Catastrophic Approved Amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.CostOfLivingAdjustment && PlanDesignRequestClassRiderDto.SelectedBenefitType.ToString() == string.Empty)
            {
                if (!errorMessages.Contains("Please select the type of Cost of Living Adjustment for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the type of Cost of Living Adjustment for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit && PlanDesignRequestClassRiderDto.SelectedBenefitType.ToString() == string.Empty)
            {
                if (!errorMessages.Contains("Please select the Type of Retirement Protection Plus for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Type of Retirement Protection Plus for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount > eligibilityConfigurationDto.RPPMaximumIndemnityAmount || PlanDesignRequestClassRiderDto.ApprovedAmount <= 0))
            {
                if (!errorMessages.Contains("Please enter a valid Retirement Protection Plus Amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter a valid Retirement Protection Plus Amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit && PlanDesignRequestClassRiderDto.SelectedEliminationPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Retirement Protection Plus Elimination Period for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Retirement Protection Plus Elimination Period for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount == null))
            {
                if (!errorMessages.Contains("Please enter the Retirement Protection Plus Amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Retirement Protection Plus Amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.StudentLoanProtectionRider && (PlanDesignRequestClassRiderDto.ApprovedAmount > 2500 || PlanDesignRequestClassRiderDto.ApprovedAmount <= 0))
            {
                if (!errorMessages.Contains("Please enter a valid Student Loan Protection Indemnity amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter a valid Student Loan Protection Indemnity amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.StudentLoanProtectionRider && (PlanDesignRequestClassRiderDto.ApprovedAmount == null))
            {
                if (!errorMessages.Contains("Please enter the Student Loan Protection Indemnity amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Student Loan Protection Indemnity amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.StudentLoanProtectionRider && PlanDesignRequestClassRiderDto.SelectedEliminationPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Student Loan Protection Elimination Period for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Student Loan Protection Elimination Period for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.StudentLoanProtectionRider && PlanDesignRequestClassRiderDto.SelectedBenefitPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Student Loan Protection Elimination Term for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Student Loan Protection Elimination Term for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.SupplementalBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount > 2000 || PlanDesignRequestClassRiderDto.ApprovedAmount <= 0))
            {
                if (!errorMessages.Contains("Please enter a valid Supplemental Benefit Term Rider Indemnity amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter a valid Supplemental Benefit Term Rider Indemnity amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.SupplementalBenefit && (PlanDesignRequestClassRiderDto.ApprovedAmount == null))
            {
                if (!errorMessages.Contains("Please enter the Supplemental Benefit Term Rider Indemnity amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Supplemental Benefit Term Rider Indemnity amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.SupplementalBenefit && PlanDesignRequestClassRiderDto.SelectedEliminationPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Supplemental Benefit Term Rider Elimination Period for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Supplemental Benefit Term Rider Elimination Period for the GSI Buy-Up Plan Approvals.");
                }
            }
            if (PlanDesignRequestClassRiderDto.SelectedBenefitGroup == (int)BenefitGroupTypeEnum.SupplementalBenefit && PlanDesignRequestClassRiderDto.SelectedBenefitPeriod == null)
            {
                if (!errorMessages.Contains("Please select the Supplemental Benefit Term Rider Elimination Term for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Supplemental Benefit Term Rider Elimination Term for the GSI Buy-Up Plan Approvals.");
                }
            }
            Log.TraceFormat("-ValidateOptionalRidersGSIBuyUpPlan");
        }

        public void ValidateGSIAmount(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto, EligibilityConfigurationDto eligibilityConfigurationDto)
        {
            Log.TraceFormat("+ValidateGSIAmount");
            if (planDesignRequestClassProductDto.GSIAmount == null)
            {
                if (!errorMessages.Contains("Please enter the GSI Amount for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please enter the GSI Amount for the Primary Plan Approvals.");
                }
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(planDesignRequestClassProductDto.GSIAmount))
                {
                    if (planDesignRequestClassProductDto.GSIAmount < (int?)eligibilityConfigurationDto.MinimumBenefitAmount 
                                                                    || planDesignRequestClassProductDto.GSIAmount > 50000)
                    {
                        errorMessages.Add("Please enter a valid GSI Amount for the Primary Plan Approvals.");
                    }
                }
                else
                {
                    if (planDesignRequestClassProductDto.GSIAmount > 0 && planDesignRequestClassProductDto.GSIAmount < 50000)
                    {
                        var match = Regex.Match(Convert.ToString(planDesignRequestClassProductDto.GSIAmount), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid GSI Amount for the Primary Plan Approvals.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid GSI Amount for the Primary Plan Approvals.");
                    }
                }
            }
            Log.TraceFormat("-ValidateGSIAmount");
        }

        public void ValidateMinimumCaseLevelGSIAmount(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateMinimumCaseLevelGSIAmount");
            if (planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount == null)
            {
                if (!errorMessages.Contains("Please enter the minimum case level GSI Amount for the Primary Plan Approvals.Should be greater than or equal to 300"))
                {
                    errorMessages.Add("Please enter the minimum case level GSI Amount for the Primary Plan Approvals.Should be greater than or equal to 300");
                }
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount))
                {
                    if (planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount < 0 || planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount < defaultMinimumGSIAmount)
                    {
                        errorMessages.Add("Please enter a valid Minimum Case Level GSI amount for the Primary Plan Approvals.Should be greater than or equal to 300");
                    }
                }
                else
                {
                    if (planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount > defaultMinimumGSIAmount)
                    {
                        var match = Regex.Match(Convert.ToString(planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid Minimum Case Level GSI Amount for the Primary Plan Approvals.Should be greater than or equal to 300");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid Minimum Case Level GSI Amount for the Primary Plan Approvals.Should be greater than or equal to 300");
                    }
                }
            }
            Log.TraceFormat("-ValidateMinimumCaseLevelGSIAmount");
        }
        public void ValidateParticipationPercentage(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateParticipationPercentage");
            if (planDesignRequestClassProductDto.ParticipationPercentage == null)
            {
                if (!errorMessages.Contains("Please enter the Participation Percentage for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Participation Percentage for the Primary Plan Approvals.");
                }
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(planDesignRequestClassProductDto.ParticipationPercentage))
                {
                    if (planDesignRequestClassProductDto.ParticipationPercentage < 0 || planDesignRequestClassProductDto.ParticipationPercentage > 100)
                    {
                        errorMessages.Add("Please enter a valid Participation Percentage for the Primary Plan Approvals.");
                    }
                }
                else
                {
                    if (planDesignRequestClassProductDto.ParticipationPercentage > 0 && planDesignRequestClassProductDto.ParticipationPercentage < 100)
                    {
                        var match = Regex.Match(Convert.ToString(planDesignRequestClassProductDto.ParticipationPercentage), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid Participation Percentage for the Primary Plan Approvals.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid Participation Percentage for the Primary Plan Approvals.");
                    }
                }
            }
            Log.TraceFormat("-ValidateParticipationPercentage");
        }

        public void ValidateDefinitionOfDisabilityType(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto, IList<PlanDesignRequestClassRiderDto> ridersDto)
        {
            Log.TraceFormat("+ValidateDefinitionOfDisabilityType");
            if (planDesignRequestClassProductDto.DefinitionOfDisabilityTypeId == 0)
            {
                if (!errorMessages.Contains("Please select Definition of Total Disability for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select Definition of Total Disability for the Primary Plan Approvals.");
                }
            }
            else
            {
                ValidateRidersPresent(errorMessages, planDesignRequestClassProductDto, ridersDto, false);
            }
            Log.TraceFormat("-ValidateDefinitionOfDisabilityType");
        }

        private void ValidateRidersPresent(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto,
            IList<PlanDesignRequestClassRiderDto> ridersDto, bool isBuyUp)
        {
            bool riderPresent = false;

            if (isCaCase && (planDesignRequestClassProductDto.DefinitionOfDisabilityTypeId ==
                              (int) DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc ||
                              planDesignRequestClassProductDto.DefinitionOfDisabilityTypeId ==
                              (int) DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation ||
                              planDesignRequestClassProductDto.DefinitionOfDisabilityTypeId ==
                              (int) DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc))
            {
                //require that one of the Partial/Residual Disability riders is selected (Enhanced Partial Disability, Basic Partial Disability, Short-Term Residual Disability) 
                riderPresent = ridersDto != null && ridersDto.Any(r =>
                                       r.SelectedBenefitType == (int)BenefitTypeEnum.EnhancedPartialDisabilityRider ||
                                       r.SelectedBenefitType == (int)BenefitTypeEnum.BasicPartialDisabilityRider ||
                                       r.SelectedBenefitType == (int)BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider);
                if (!riderPresent)
                {
                    if (isBuyUp)
                    {
                        if (!errorMessages.Contains("Please select one of the following riders in Buy-Up Plan: Enhanced Partial Disability, Basic Partial Disability, Short-Term Residual Disability"))
                        {
                            errorMessages.Add(
                                "Please select one of the following riders in Buy-Up Plan: Enhanced Partial Disability, Basic Partial Disability, Short-Term Residual Disability");
                        }
                    }
                    else
                    {
                        if (!errorMessages.Contains("Please select one of the following riders in Primary Plan: Enhanced Partial Disability, Basic Partial Disability, Short-Term Residual Disability"))
                        {
                            errorMessages.Add(
                                "Please select one of the following riders in Primary Plan: Enhanced Partial Disability, Basic Partial Disability, Short-Term Residual Disability");
                        }
                    }
                }
            }
        }

        public void ValidatePreExistingConditionLimitType(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidatePreExistingConditionLimitType");
            if (planDesignRequestClassProductDto.PreExistingConditionLimitTypeId == 0)
            {
                if (!errorMessages.Contains("Please select the Pre-existing Condition Limitation for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Pre-existing Condition Limitation for the Primary Plan Approvals.");
                }
            }
            Log.TraceFormat("-ValidatePreExistingConditionLimitType");
        }

        public void ValidateEliminationPeriodType(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateEliminationPeriodType");
            if (planDesignRequestClassProductDto.EliminationPeriodTypeId == null)
            {
                if (!errorMessages.Contains("Please select the Elimination Period for the GSI Buy-Up Plan Underwriting Approvals."))
                {
                    errorMessages.Add("Please select the Elimination Period for the GSI Buy-Up Plan Underwriting Approvals.");
                }
            }
            Log.TraceFormat("-ValidateEliminationPeriodType");
        }

        public void ValidateMinimumCaseLevelGSIAmountVGSIBuyup(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateMinimumCaseLevelGSIAmountVGSIBuyup");
            if (planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount == null)
            {
                if (!errorMessages.Contains("Please enter the minimum case level GSI Amount for the GSI Buy-Up Plan Approvals.Should be greater than or equal to 300"))
                {
                    errorMessages.Add("Please enter the minimum case level GSI Amount for the GSI Buy-Up Plan Approvals.Should be greater than or equal to 300");
                }
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount))
                {
                    if (planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount < 0 || planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount < defaultMinimumGSIAmount)
                    {
                        errorMessages.Add("Please enter a valid Minimum Case Level GSI amount for the GSI Buy-Up Plan Approvals.Should be greater than or equal to 300");
                    }
                }
                else
                {
                    if (planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount > defaultMinimumGSIAmount)
                    {
                        var match = Regex.Match(Convert.ToString(planDesignRequestClassProductDto.MinimumCaseLevelGSIAmount), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid Minimum Case Level GSI Amount for the GSI Buy-Up Plan Approvals.Should be greater than or equal to 300");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid Minimum Case Level GSI Amount for the GSI Buy-Up Plan Approvals.Should be greater than or equal to 300");
                    }
                }
            }
            Log.TraceFormat("-ValidateMinimumCaseLevelGSIAmountVGSIBuyup");
        }

        public void ValidateBenefitPeriodType(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateBenefitPeriodType");
            if (planDesignRequestClassProductDto.BenefitPeriodTypeId == null)
            {
                if (!errorMessages.Contains("Please select the Benefit Period for the GSI Buy-Up Plan Underwriting Approvals."))
                {
                    errorMessages.Add("Please select the Benefit Period for the GSI Buy-Up Plan Underwriting Approvals.");
                }
            }
            Log.TraceFormat("-ValidateBenefitPeriodType");

        }

        public void ValidateGSIAmountForGSIBuyUpPlan(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto, EligibilityConfigurationDto eligibilityConfigurationDto)
        {
            Log.TraceFormat("+ValidateGSIAmountForGSIBuyUpPlan");
            if (planDesignRequestClassProductDto.GSIAmount == null)
            {
                if (!errorMessages.Contains("Please enter the GSI Amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter the GSI Amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(planDesignRequestClassProductDto.GSIAmount))
                {
                    if (planDesignRequestClassProductDto.GSIAmount < (int?)eligibilityConfigurationDto.MinimumBenefitAmount || planDesignRequestClassProductDto.GSIAmount > 20000)
                    {
                        errorMessages.Add("Please enter a valid GSI Amount for the GSI Buy-Up Plan Approvals.");
                    }
                }
                else
                {
                    if (planDesignRequestClassProductDto.GSIAmount > 0 && planDesignRequestClassProductDto.GSIAmount < 20000)
                    {
                        var match = Regex.Match(Convert.ToString(planDesignRequestClassProductDto.GSIAmount), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid GSI Amount for the GSI Buy-Up Plan Approval.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid GSI Amount for the GSI Buy-Up Plan Approval.");
                    }
                }
            }
            Log.TraceFormat("-ValidateGSIAmountForGSIBuyUpPlan");
        }

        public void ValidateTotalMaxGSIAmountForGSIBuyUpPlan(List<string> errorMessages, List<PlanDesignRequestClassProductDto> planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateGSIAmountForGSIBuyUpPlan");
            var totalMaxGSIAmount = planDesignRequestClassProductDto.FirstOrDefault(c => c.IsGSIPlanIndicator == true).TotalMaxGSIAmount;
            var primaryGSIAmount = planDesignRequestClassProductDto.FirstOrDefault(c => c.IsGSIPlanIndicator == false).GSIAmount;
            var BuyUpGSIAmount = planDesignRequestClassProductDto.FirstOrDefault(c => c.IsGSIPlanIndicator == true).GSIAmount;
            if (totalMaxGSIAmount == null)
            {
                if (!errorMessages.Contains("Please enter the Total Max GSI Amount for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Total Max GSI Amount for the GSI Buy-Up Plan Approvals.");
                }
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (!IsDecimalOrInteger(totalMaxGSIAmount))
                {
                    var match = Regex.Match(Convert.ToString(totalMaxGSIAmount), regex, RegexOptions.IgnoreCase);
                    if (!match.Success)
                    {
                        errorMessages.Add("Please enter a valid Total Max GSI Amount for the GSI Buy-Up Plan Approvals.");
                    }
                }
            }
            Log.TraceFormat("-ValidateGSIAmountForGSIBuyUpPlan");
        }

        public void ValidateParticipationPercentageForGSIBuyUpPlan(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateParticipationPercentageForGSIBuyUpPlan");
            if (planDesignRequestClassProductDto.ParticipationPercentage == null)
            {
                if (!errorMessages.Contains("Please enter the Participation Percentage for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please enter the Participation Percentage for the GSI Buy-Up Plan Approvals.");
                }
            }
            else
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(planDesignRequestClassProductDto.ParticipationPercentage))
                {
                    if (planDesignRequestClassProductDto.ParticipationPercentage < 0 || planDesignRequestClassProductDto.ParticipationPercentage > 100)
                    {
                        errorMessages.Add("Please enter a valid Participation Percentage for the GSI Buy-Up Plan Approvals.");
                    }
                }
                else
                {
                    if (planDesignRequestClassProductDto.ParticipationPercentage > 0 && planDesignRequestClassProductDto.ParticipationPercentage < 100)
                    {
                        var match = Regex.Match(Convert.ToString(planDesignRequestClassProductDto.ParticipationPercentage), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid Participation Percentage for the GSI Buy-Up Plan Approvals.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid Participation Percentage for the GSI Buy-Up Plan Approvals.");
                    }
                }
            }
            Log.TraceFormat("-ValidateParticipationPercentageForGSIBuyUpPlan");
        }

        public void ValidateDefinitionOfDisabilityTypeForGSIBuyUpPlan(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto, IList<PlanDesignRequestClassRiderDto> ridersDto)
        {
            Log.TraceFormat("+ValidateDefinitionOfDisabilityTypeForGSIBuyUpPlan");
            if (planDesignRequestClassProductDto.DefinitionOfDisabilityTypeId == 0)
            {
                if (!errorMessages.Contains("Please select Definition of Total Disability for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select Definition of Total Disability for the GSI Buy-Up Plan Approvals.");
                }                
            }
            else
            {
                ValidateRidersPresent(errorMessages, planDesignRequestClassProductDto, ridersDto , true);
            }
            Log.TraceFormat("-ValidateDefinitionOfDisabilityTypeForGSIBuyUpPlan");
        }

        public void ValidateMentalSubstanceLimitationType(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto, PlanDesignRequestClassProductDto planDesignRequestClassProductDto, List<int> compactStateList, List<int> nonCompactStateList)
        {
            Log.TraceFormat("+ValidateMentalSubstanceLimitationType");
            if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == 0)
            {
                if (!errorMessages.Contains("Please select the Mental/Substance Limitation for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Please select the Mental/Substance Limitation for the Primary Plan Approvals.");
                }
            }
            else
            {
                if (caseUnderwritingRequestDto.SitusTypeId == (int?)SitusTypeEnum.Corporate)
                {
                    if (!nonCompactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                    {
                        if (caseUnderwritingRequestDto.IsCompactState == true)
                        {
                            if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == (int)MentalSubstanceLimitationEnum._12Month &&
                                !compactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                            {
                                if (!errorMessages.Contains("12 month Mental/Substance Limitation for the Primary plan approvals is only available to the compact state filing: ID, MA, MO, NM, RI, VA, VT,AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY."))
                                {
                                    errorMessages.Add("12 month Mental/Substance Limitation for the Primary plan approvals is only available to the compact state filing: ID, MA, MO, NM, RI, VA, VT,AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY.");
                                }
                            }
                            else if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == (int)MentalSubstanceLimitationEnum._6Month &&
                                compactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                            {
                                if (!errorMessages.Contains("6 month Mental/Substance Limitation for the Primary plan approvals is available to all states except the compact states: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY."))
                                {
                                    errorMessages.Add("6 month Mental/Substance Limitation for the Primary plan approvals is available to all states except the compact states: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY.");
                                }
                            }
                        }
                        else
                        {
                            if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == (int)MentalSubstanceLimitationEnum._12Month &&
                                compactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                            {
                                if (!errorMessages.Contains("12 month Mental/Substance Limitation for the Primary plan approvals is only available to the compact state filing: ID, MA, MO, NM, RI, VA, VT,AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY."))
                                {
                                    errorMessages.Add("12 month Mental/Substance Limitation for the Primary plan approvals is only available to the compact state filing: ID, MA, MO, NM, RI, VA, VT,AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY.");
                                }
                            }
                            else if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == (int)MentalSubstanceLimitationEnum._6Month &&
                                !compactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                            {
                                if (!errorMessages.Contains("6 month Mental/Substance Limitation for the Primary plan approvals is available to all states except the compact states: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY."))
                                {
                                    errorMessages.Add("6 month Mental/Substance Limitation for the Primary plan approvals is available to all states except the compact states: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY.");
                                }
                            }
                        }
                    }
                }
            }
            Log.TraceFormat("-ValidateMentalSubstanceLimitationType");
        }

        public void ValidateMentalSubstanceLimitationTypeForGSIBuyUpPlan(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto, PlanDesignRequestClassProductDto planDesignRequestClassProductDto, List<int> compactStateList, List<int> nonCompactStateList)
        {
            Log.TraceFormat("+ValidateMentalSubstanceLimitationTypeForGSIBuyUpPlan");
            if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == 0)
            {
                if (!errorMessages.Contains("Please select the Mental/Substance Limitation for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Mental/Substance Limitation for the GSI Buy-Up Plan Approvals.");
                }
            }
            else
            {
                if (caseUnderwritingRequestDto.SitusTypeId == (int?)SitusTypeEnum.Corporate)
                {
                    if (!nonCompactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                    {
                        if (caseUnderwritingRequestDto.IsCompactState == true)
                        {
                            if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == (int)MentalSubstanceLimitationEnum._12Month &&
                            !compactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                            {
                                if (!errorMessages.Contains("12 month Mental/Substance Limitation for the GSI Buy-Up plan approvals is only available to the compact state filing: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY."))
                                {
                                    errorMessages.Add("12 month Mental/Substance Limitation for the GSI Buy-Up plan approvals is only available to the compact state filing: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY.");
                                }
                            }
                            else if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == (int)MentalSubstanceLimitationEnum._6Month &&
                                compactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                            {
                                if (!errorMessages.Contains("6 month Mental/Substance Limitation for the GSI Buy-Up plan approvals is available to all states except the compact states: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY."))
                                {
                                    errorMessages.Add("6 month Mental/Substance Limitation for the GSI Buy-Up plan approvals is available to all states except the compact states: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY.");
                                }
                            }
                        }
                        else
                        {
                            if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == (int)MentalSubstanceLimitationEnum._12Month &&
                            compactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                            {
                                if (!errorMessages.Contains("12 month Mental/Substance Limitation for the GSI Buy-Up plan approvals is only available to the compact state filing: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY."))
                                {
                                    errorMessages.Add("12 month Mental/Substance Limitation for the GSI Buy-Up plan approvals is only available to the compact state filing: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY.");
                                }
                            }
                            else if (planDesignRequestClassProductDto.MentalSubstanceLimitationTypeId == (int)MentalSubstanceLimitationEnum._6Month &&
                                !compactStateList.Contains((int)caseUnderwritingRequestDto.StateTypeId))
                            {
                                if (!errorMessages.Contains("6 month Mental/Substance Limitation for the GSI Buy-Up plan approvals is available to all states except the compact states: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY."))
                                {
                                    errorMessages.Add("6 month Mental/Substance Limitation for the GSI Buy-Up plan approvals is available to all states except the compact states: ID, MA, MO, NM, RI, VA, VT, AL, AK, AR, AZ, CO, GA, HI, IL, IN, IA, KS, KY, LA, ME, MD, MI, MN, MS, NE, NV, NH, NJ, NC, OH, OK, OR, PA, SC, TN, TX, UT, WA, WV, WI, WY.");
                                }
                            }
                        }
                    }
                }
            }
            Log.TraceFormat("-ValidateMentalSubstanceLimitationTypeForGSIBuyUpPlan");
        }

        public void ValidatePreExistingConditionLimitTypeForGSIBuyUpPlan(List<string> errorMessages, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidatePreExistingConditionLimitTypeForGSIBuyUpPlan");
            if (planDesignRequestClassProductDto.PreExistingConditionLimitTypeId == 0)
            {
                if (!errorMessages.Contains("Please select the Pre-existing Condition Limitation for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Please select the Pre-existing Condition Limitation for the GSI Buy-Up Plan Approvals.");
                }
            }
            Log.TraceFormat("-ValidatePreExistingConditionLimitTypeForGSIBuyUpPlan");
        }

        public void ValidateEmployerPaidPremium(List<string> errorMessages, PlanDesignRequestClassDto planDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateEmployerPaidPremium");
            if (planDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare && planDesignRequestClassDto.ApprovedTypeOfShareTypeId == (int)TypeOfShareTypeEnum.PercentofPremium)
            {
                var regex = @"^(100\.00|100\.0|100)|([0-9]{1,2})(\.[0-9]{1,2})$";
                if (IsDecimalOrInteger(planDesignRequestClassDto.ApprovedEmployerPaidPremium))
                {
                    if (planDesignRequestClassDto.ApprovedEmployerPaidPremium < 0 || planDesignRequestClassDto.ApprovedEmployerPaidPremium > 100)
                    {
                        errorMessages.Add("Please enter a valid Employer Paid Premium.");
                    }
                }
                else
                {
                    if (planDesignRequestClassDto.ApprovedEmployerPaidPremium > 0 && planDesignRequestClassDto.ApprovedEmployerPaidPremium < 100)
                    {
                        var match = Regex.Match(Convert.ToString(planDesignRequestClassDto.ApprovedEmployerPaidPremium), regex, RegexOptions.IgnoreCase);
                        if (!match.Success)
                        {
                            errorMessages.Add("Please enter a valid Employer Paid Premium.");
                        }
                    }
                    else
                    {
                        errorMessages.Add("Please enter a valid Employer Paid Premium.");
                    }
                }
            }
            Log.TraceFormat("-ValidateEmployerPaidPremium");
        }

        public void ValidateCostShareTaxabilityType(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateCostShareTaxabilityType");
            if (casePlanDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare && casePlanDesignRequestClassDto.ApprovedCostShareTaxabilityTypeId == null)
            {
                if (!errorMessages.Contains("Please select Approved Type Of Pay."))
                {
                    errorMessages.Add("Please select Approved Type Of Pay.");
                }
            }
            Log.TraceFormat("-ValidateCostShareTaxabilityType");

        }

        public void ValidateCoveredEarningsType(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateCoveredEarningsType");
            int count = 0;
            if (casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count > 0)
            {
                if (casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault().IsSold)
                {
                    if (casePlanDesignRequestClassDto.PlanDesignRequestClassId != 0)
                    {
                        count = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.PDRSoldClassId == casePlanDesignRequestClassDto.PlanDesignRequestClassId && c.IsGSIPlanIndicator == false);
                    }
                    else
                    {
                        count = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.IsGSIPlanIndicator == false);
                    }
                }
                else
                {
                    if (casePlanDesignRequestClassDto.PlanDesignRequestClassId != 0)
                    {
                        count = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.PlanDesignRequestClassId == casePlanDesignRequestClassDto.PlanDesignRequestClassId && c.IsGSIPlanIndicator == false);
                    }
                    else
                    {
                        count = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.IsGSIPlanIndicator == false);
                    }
                }
            }
            if (count == 0)
            {
                if (casePlanDesignRequestClassDto.ApprovedCoveredEarningsTypeId == null && (casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId != (int)PlanDesignTypeEnum.BonusOnlyPlan && casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId != (int)PlanDesignTypeEnum.FlatBenefitPlan))
                {
                    if (!errorMessages.Contains("Please select Approved Covered Earnings."))
                    {
                        errorMessages.Add("Please select Approved Covered Earnings.");
                    }
                }
            }
            Log.TraceFormat("-ValidateCoveredEarningsType");

        }

        public void ValidateCoveredEarningsForBonusOnlyType(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateCoveredEarningsType");
            int count = 0;
            if (casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count > 0)
            {
                if (casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault().IsSold)
                    count = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.PDRSoldClassId == casePlanDesignRequestClassDto.PlanDesignRequestClassId);
                else
                    count = casePlanDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.PlanDesignRequestClassId == casePlanDesignRequestClassDto.PlanDesignRequestClassId);
            }
            if (count == 0)
            {
                if (casePlanDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId == null && casePlanDesignRequestClassDto.ApprovedPlanDesignTypeId == (int)PlanDesignTypeEnum.BonusOnlyPlan)
                {
                    if (!errorMessages.Contains("Please select Approved Covered Earnings."))
                    {
                        errorMessages.Add("Please select Approved Covered Earnings.");
                    }
                }
            }
            Log.TraceFormat("-ValidateCoveredEarningsType");

        }

        public void ValidateBenefitPeriod(List<string> errorMessages, PlanDesignRequestClassDto casePlanDesignRequestClassDto)
        {
            Log.TraceFormat("+ValidateBenefitPeriod");
            if (casePlanDesignRequestClassDto.ApprovedBenefitPeriodTypeId == null)
            {
                if (!errorMessages.Contains("Please enter the Benefit Period Approved Value."))
                {
                    errorMessages.Add("Please enter the Benefit Period Approved Value.");
                }
            }
            Log.TraceFormat("-ValidateBenefitPeriod");
        }

        public void ValidateDiscountForGSIBuyUpPlan(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateDiscountForGSIBuyUpPlan");
            if (caseUnderwritingRequestDto.StateTypeId == (int)StateTypeEnum.NH && caseUnderwritingRequestDto.IsCompactState == false)
            {
                if (planDesignRequestClassProductDto.VGSITotalDiscount > 35)
                {
                    if (!errorMessages.Contains("The discount percentage can not exceed the state maximum of 35% for BuyUp Plan."))
                    {
                        errorMessages.Add("The discount percentage can not exceed the state maximum of 35% for BuyUp Plan.");
                    }
                }
            }
            else if (planDesignRequestClassProductDto.VGSITotalDiscount > 60)
            {

                if (!errorMessages.Contains("The discount percentage can not exceed the state maximum of 60% for BuyUp Plan."))
                {
                    errorMessages.Add("The discount percentage can not exceed the state maximum of 60% for BuyUp Plan.");
                }

            }

            Log.TraceFormat("-ValidateDiscountForGSIBuyUpPlan");
        }

        public void ValidateDiscountForPrimaryPlan(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateDiscountForPrimaryPlan");
            if (caseUnderwritingRequestDto.StateTypeId == (int)StateTypeEnum.NH && caseUnderwritingRequestDto.IsCompactState == false)
            {
                if (planDesignRequestClassProductDto.PrimaryPlanTotalDiscount > 35)
                {
                    if (!errorMessages.Contains("The discount percentage can not exceed the state maximum of 35%."))
                    {
                        errorMessages.Add("The discount percentage can not exceed the state maximum of 35%.");
                    }
                }
            }
            else if (planDesignRequestClassProductDto.PrimaryPlanTotalDiscount > 60)
                {

                    if (!errorMessages.Contains("The discount percentage can not exceed the state maximum of 60%."))
                    {
                        errorMessages.Add("The discount percentage can not exceed the state maximum of 60%.");
                    }

               }
            Log.TraceFormat("-ValidateDiscountForPrimaryPlan");
        }
        public void ValidateEmployerPaidDiscount(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateEmployerPaidDiscount");
            if (caseUnderwritingRequestDto.PricingTypeId != null && caseUnderwritingRequestDto.PricingTypeId == 1 && planDesignRequestClassProductDto.EmployerPaidDiscountTypeId > 1)
            {
                if (!errorMessages.Contains("Employer Paid Discount is not allowed for the Provider Choice 2016 product for the Primary Plan Approvals."))
                {
                    errorMessages.Add("Employer Paid Discount is not allowed for the Provider Choice 2016 product for the Primary Plan Approvals.");
                }

            }
            Log.TraceFormat("-ValidateEmployerPaidDiscount");
        }
        public void ValidateEmployerPaidDiscountForGSIBuyUpPlan(List<string> errorMessages, CaseUnderwritingRequestDto caseUnderwritingRequestDto, PlanDesignRequestClassProductDto planDesignRequestClassProductDto)
        {
            Log.TraceFormat("+ValidateEmployerPaidDiscountForGSIBuyUpPlan");
            if (caseUnderwritingRequestDto.PricingTypeId != null && caseUnderwritingRequestDto.PricingTypeId == 1 && planDesignRequestClassProductDto.EmployerPaidDiscountTypeId > 1)
            {
                if (!errorMessages.Contains("Employer Paid Discount is not allowed for the Provider Choice 2016 product for the GSI Buy-Up Plan Approvals."))
                {
                    errorMessages.Add("Employer Paid Discount is not allowed for the Provider Choice 2016 product for the GSI Buy-Up Plan Approvals.");
                }

            }
            Log.TraceFormat("-ValidateEmployerPaidDiscountForGSIBuyUpPlan");
        }
    }
}

