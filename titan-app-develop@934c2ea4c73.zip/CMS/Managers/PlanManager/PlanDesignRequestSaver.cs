﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using CMS.Model.Extensions;
using Common.Exceptions;
using Common.Utilities;
using ITAdminManagers;
using CMS.Interfaces.Managers.ITAdminManagers;
using Guardian.Core.Entities.Product.Enums.EnumExtensions;

namespace CMS.Managers.PlanManagers
{
    internal class PlanDesignRequestSaver
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly PlanDesignRequestManagerValidator _planDesignRequestValidator;
        private readonly IProductLibraryManager _productLibraryManager;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;
        private readonly IStatePricingTypeManager _statePricingTypeManager;
        private readonly ICompactStateManager _compactStateManager;

        public PlanDesignRequestSaver(IUnitOfWorkFactory unitOfWorkFactory, IProductLibraryManager productLibraryManger, 
            IEligibilityConfigurationManager eligibilityConfigurationManager, IStatePricingTypeManager statePricingTypeManager,
            ICompactStateManager compactStateManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _planDesignRequestValidator = new PlanDesignRequestManagerValidator();
            _productLibraryManager = productLibraryManger;
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
            _statePricingTypeManager = statePricingTypeManager;
            _compactStateManager = compactStateManager;
        }
        public void SavePlanDesignRequest(PlanDesignDto request)
        {
            Log.TraceFormat("+SavePlanDesignRequest");

            var eligibilityConfigurationClassDto = new EligibilityConfigurationDto();
            eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);

            var compactStateList = _compactStateManager.GetCompactStates();
            var nonCompactStateList = _compactStateManager.GetNonCompactStates();

            _planDesignRequestValidator.ValidatePlanDesignRequestData(request, eligibilityConfigurationClassDto, compactStateList, nonCompactStateList, _statePricingTypeManager);

            SavePlanDesignRequestLocal(request);

            Log.TraceFormat("-SavePlanDesignRequest");
        }

        private void SavePlanDesignRequestLocal(PlanDesignDto request)
        {
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseUnderwritingRequest.CaseId);

                ProductValidationResult validateResult = _productLibraryManager.ValidatePDRProduct(request, cmsCase);
                if (validateResult.ValidationMessages.Any()) throw new ValidationException(validateResult.ValidationMessages);

                SaveUnderwritingRequest(request, unitOfWork, cmsCase);
                if (request.PlanDesignRequests.Count > 0)
                {
                    SaveSelectedPlanDesignRequest(request, unitOfWork, cmsCase);
                }
                unitOfWork.Commit();
            }
        }

        public int SavePlanDesignRequestFromGA(PlanDesignDto request, bool isSaveClass)
        {
            Log.TraceFormat("+SavePlanDesignRequestFromGA");

            var planDesignRequestId = 0;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseUnderwritingRequest.CaseId);

                SaveUnderwritingRequest(request, unitOfWork, cmsCase);
                if (request.PlanDesignRequests.Count > 0)
                {
                    var selectedPlanDesignRequest = request.PlanDesignRequests.First();

                    Log.TraceFormat("+SavePlanDesignRequestFromGA: CaseId:{0} PdrRequestId:{1} IsSaveClass:{2}", 
                        request.CaseUnderwritingRequest.CaseId, selectedPlanDesignRequest.PlanDesignRequestId, isSaveClass.ToString());

                    var planDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == selectedPlanDesignRequest.PlanDesignRequestId);
                    if (planDesignRequest == null)
                    {
                        planDesignRequest = new PlanDesignRequest();
                        planDesignRequest.Case = cmsCase;
                        planDesignRequest.CreationDate = DateTime.Now;
                    }

                    planDesignRequest.RequestHeaderName = selectedPlanDesignRequest.RequestHeaderName;
                    planDesignRequest.IsActive = selectedPlanDesignRequest.IsActive;
                    planDesignRequest.InactiveDate = !selectedPlanDesignRequest.IsActive ? DateTime.Now : planDesignRequest.InactiveDate;
                    planDesignRequest.IllustrationEffectiveDate = selectedPlanDesignRequest.IllustrationEffectiveDate;
                    planDesignRequest.IsApproved = selectedPlanDesignRequest.IsApproved;
                    planDesignRequest.GAPlanDesignRequestId = selectedPlanDesignRequest.GAPlanDesignRequestId ?? planDesignRequest.GAPlanDesignRequestId;
                    planDesignRequest.PDRName = selectedPlanDesignRequest.PDRName ?? planDesignRequest.PDRName;
                    planDesignRequest.PlanDesignRequestStatusType = selectedPlanDesignRequest.PlanDesignRequestStatusType;
                    if (planDesignRequest != null)
                    {
                        if (planDesignRequest.CreationDate == DateTime.MinValue)
                        {
                            planDesignRequest.CreationDate = DateTime.Now;
                        }
                    }
                    
                    if (!isSaveClass)
                    {
                        var planDesignRequestStatusHistory = unitOfWork.Repository<PlanDesignRequestStatusHistory>().Linq().FirstOrDefault(c => c.Id == selectedPlanDesignRequest.PlanDesignRequestId);
                        if (planDesignRequestStatusHistory == null)
                        {
                            planDesignRequestStatusHistory = new PlanDesignRequestStatusHistory();
                            planDesignRequestStatusHistory.PlanDesignRequest = planDesignRequest;
                            planDesignRequestStatusHistory.PlanDesignRequestStatusType = PlanDesignRequestStatusTypeEnum.Submitted;
                            planDesignRequestStatusHistory.DateOfChange = DateTime.Now;
                            planDesignRequest.PlanDesignRequestStatusHistories.Add(planDesignRequestStatusHistory);
                        }
                    }

                    if (isSaveClass && selectedPlanDesignRequest.SelectedClass != null)
                    {
                        SaveRequestClass(unitOfWork, selectedPlanDesignRequest, planDesignRequest);
                    }

                    unitOfWork.Repository<PlanDesignRequest>().Save(planDesignRequest);
                    unitOfWork.Commit();
                    planDesignRequestId = planDesignRequest.Id;
                }
            }
            Log.TraceFormat("-SavePlanDesignRequestFromGA : NewPdrRequestId: {0}", planDesignRequestId);

            return planDesignRequestId;
        }

        public void SaveBlankRequestClass(PlanDesignRequestClassDto request)
        {
            Log.TraceFormat("+SaveBlankClass");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == request.PlanDesignRequestId);
                var requestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.PlanDesignRequest.Id == request.PlanDesignRequestId);
                int index = 0;
                string classHeaderName = string.Empty;
                if (requestClass != null)
                {
                    string[] className = requestClass.PlanDesignRequestClassName.Split(' ');
                    index = Convert.ToInt32(className[1]);
                }
                classHeaderName = "Class " + (++index);

                var planDesignRequestClass = new PlanDesignRequestClass();
                planDesignRequestClass.PlanDesignRequest = planDesignRequest;
                planDesignRequestClass.RequestedEligiblePopulationText = request.RequestedEligiblePopulationText;
                planDesignRequestClass.PlanDesignRequestClassName = classHeaderName;
                planDesignRequestClass.IsActive = request.IsActive;
                planDesignRequestClass.RequestedFlatRateType = null;
                planDesignRequestClass.ApprovedFlatRateType = null;
                planDesignRequestClass.RequestedPremiumPayerAndTaxabilityType = null;
                planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType = null;
                unitOfWork.Repository<PlanDesignRequestClass>().Save(planDesignRequestClass);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveBlankClass");
        }       

        private void SaveSelectedPlanDesignRequest(PlanDesignDto request, IUnitOfWork unitOfWork, Case cmsCase)
        {
            Log.TraceFormat("+SaveSelectedPlanDesignRequest");
           
            var selectedPlanDesignRequest = request.PlanDesignRequests.FirstOrDefault();

            var planDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == selectedPlanDesignRequest.PlanDesignRequestId);
            if (planDesignRequest == null)
            {
                planDesignRequest = new PlanDesignRequest();
                planDesignRequest.Case = cmsCase;
                planDesignRequest.CreationDate = DateTime.Now;
            }

            planDesignRequest.RequestHeaderName = selectedPlanDesignRequest.RequestHeaderName;
            planDesignRequest.IsActive = selectedPlanDesignRequest.IsActive;
            planDesignRequest.InactiveDate = !selectedPlanDesignRequest.IsActive ? DateTime.Now : planDesignRequest.InactiveDate;
            planDesignRequest.IllustrationEffectiveDate = selectedPlanDesignRequest.IllustrationEffectiveDate;
            planDesignRequest.IsApproved = selectedPlanDesignRequest.IsApproved;
            planDesignRequest.GAPlanDesignRequestId = selectedPlanDesignRequest.GAPlanDesignRequestId ?? planDesignRequest.GAPlanDesignRequestId;
            planDesignRequest.PDRName = selectedPlanDesignRequest.PDRName ?? planDesignRequest.PDRName;
            if (planDesignRequest != null)
            {
                if (planDesignRequest.CreationDate == DateTime.MinValue)
                {
                    planDesignRequest.CreationDate = DateTime.Now;
                }
            }

            if (selectedPlanDesignRequest.SelectedClass != null)
            {
                SaveRequestClass(unitOfWork, selectedPlanDesignRequest, planDesignRequest);
            }

            unitOfWork.Repository<PlanDesignRequest>().Save(planDesignRequest);

            Log.TraceFormat("-SaveSelectedPlanDesignRequest");
        }

        private void SaveUnderwritingRequest(PlanDesignDto request, IUnitOfWork unitOfWork, Case cmsCase)
        {
            Log.TraceFormat("+SaveUnderwritingRequest");

            var cmsUnderwritingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseUnderwritingRequest.CaseId);
            if (cmsUnderwritingRequest == null)
            {
                cmsUnderwritingRequest = new CaseUnderwritingRequest();
                cmsUnderwritingRequest.Case = cmsCase;
            }

            cmsUnderwritingRequest.SitusType = (SitusTypeEnum?)request.CaseUnderwritingRequest.SitusTypeId;
            cmsUnderwritingRequest.StateType = (StateTypeEnum?)request.CaseUnderwritingRequest.StateTypeId;
            cmsUnderwritingRequest.SitusMultiState1Type = (StateTypeEnum?)request.CaseUnderwritingRequest.SitusMultiState1TypeId;
            cmsUnderwritingRequest.SitusMultiState2Type = (StateTypeEnum?)request.CaseUnderwritingRequest.SitusMultiState2TypeId;
            cmsUnderwritingRequest.SitusMultiState3Type = (StateTypeEnum?)request.CaseUnderwritingRequest.SitusMultiState3TypeId;
            cmsUnderwritingRequest.Notes = request.CaseUnderwritingRequest.Notes;
            cmsUnderwritingRequest.IsCompactState = request.CaseUnderwritingRequest.IsCompactState;

            if (request.CaseUnderwritingRequest.PricingTypeId == null)
            {
                // mst be a case from GA.  Need to default the pricing type accordingly
                bool stateApprovedPc = _statePricingTypeManager.IsStateApprovedforPricingType((int)request.CaseUnderwritingRequest.StateTypeId, (int)PricingTypeEnum.PC2023);

                if (stateApprovedPc)
                {
                    cmsUnderwritingRequest.PricingType = PricingTypeEnum.PC2023;
                }
                else
                {
                    cmsUnderwritingRequest.PricingType = PricingTypeEnum.PC2019;
                }

            }
            else
            {
                //Not a new case, save the pricing type that was sent in.
                cmsUnderwritingRequest.PricingType = (PricingTypeEnum?)request.CaseUnderwritingRequest.PricingTypeId;
            }


            unitOfWork.Repository<CaseUnderwritingRequest>().Save(cmsUnderwritingRequest);

            Log.TraceFormat("-SaveUnderwritingRequest");
        }

        public void SavePDRCustomizedIncomes(PDRClassCustomizedIDIInsurableIncomeDto request)
        {
            Log.TraceFormat("+SavePDRCustomizedIncomes");

            _planDesignRequestValidator.ValidateSavePDRCustomizedIncomesData(request);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrClassCustomizedIDIInsurableIncome = unitOfWork.Repository<PDRClassCustomizedIDIInsurableIncome>().Linq().FirstOrDefault(c => c.Id == request.PDRClassCustomizedIDIInsurableIncomeId);
                if (pdrClassCustomizedIDIInsurableIncome == null)
                {
                    var pdrClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == request.PlanDesignRequestClassId);
                    pdrClassCustomizedIDIInsurableIncome = new PDRClassCustomizedIDIInsurableIncome();
                    pdrClassCustomizedIDIInsurableIncome.PlanDesignRequestClass = pdrClass;
                }

                CreatePDRClassCustomizedIDIInsurableIncome(request, pdrClassCustomizedIDIInsurableIncome);

                unitOfWork.Repository<PDRClassCustomizedIDIInsurableIncome>().Save(pdrClassCustomizedIDIInsurableIncome);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SavePDRCustomizedIncomes");
        }

        public void SavePDRLTDCustomizedIncomes(PlanDesignRequestClassLTDCoverageDto request)
        {
            Log.TraceFormat("+SavePDRLTDCustomizedIncomes");

            _planDesignRequestValidator.ValidateSavePDRLTDCustomizedIncomesData(request);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {

                var planDesignRequestLTDCoverage = unitOfWork.Repository<PlanDesignRequestClassLTDCoverage>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == request.PlanDesignRequestClassId);
                if (planDesignRequestLTDCoverage == null)
                {
                    var planDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == request.PlanDesignRequestClassId);
                    planDesignRequestLTDCoverage = new PlanDesignRequestClassLTDCoverage();
                    planDesignRequestLTDCoverage.PlanDesignRequestClass = planDesignRequestClass;
                }
                planDesignRequestLTDCoverage.EligiblePopulationText = request.EligiblePopulationText;
                planDesignRequestLTDCoverage.CarrierText = request.CarrierText;
                planDesignRequestLTDCoverage.EliminationPeriodDays = request.EliminationPeriodDays;
                planDesignRequestLTDCoverage.BenefitPeriodDays = request.BenefitPeriodDays;
                planDesignRequestLTDCoverage.GroupLTDReplacementPercentage = request.GroupLTDReplacementPercentage;
                planDesignRequestLTDCoverage.GroupLTDCapAmount = request.GroupLTDCapAmount;
                planDesignRequestLTDCoverage.GroupLTDCoveredEarningsType = (CoveredEarningsTypeEnum)request.GroupLTDCoveredEarningsTypeId;
                planDesignRequestLTDCoverage.PremiumAndTaxpayerLiabilityType = unitOfWork.Repository<ExistingCoveragePremiumAndTaxpayerLiabilityType>().Linq().FirstOrDefault(c => c.Id == request.PremiumAndTaxpayerLiabilityTypeId);
                planDesignRequestLTDCoverage.TypeOfPayType = request.TypeOfPayTypeId != null ? (TaxabilityTypeEnum?)request.TypeOfPayTypeId : null;
                planDesignRequestLTDCoverage.IsVoluntaryLTDBuyUpIndicator = (GetIsVoluntaryLTDBuyUpIndicator(planDesignRequestLTDCoverage) == true) ? request.IsVoluntaryLTDBuyUpIndicator : null;
                planDesignRequestLTDCoverage.LTDBuyUpReplacementPercentage = (request.IsVoluntaryLTDBuyUpIndicator == null || false == request.IsVoluntaryLTDBuyUpIndicator) ? null : request.LTDBuyUpReplacementPercentage;
                planDesignRequestLTDCoverage.LTDBuyUpLTDCapAmount = (request.IsVoluntaryLTDBuyUpIndicator == null || false == request.IsVoluntaryLTDBuyUpIndicator) ? null : request.LTDBuyUpLTDCapAmount;
                planDesignRequestLTDCoverage.LTDBuyUpCoveredEarningsType = (request.IsVoluntaryLTDBuyUpIndicator == null || false == request.IsVoluntaryLTDBuyUpIndicator) ? null : (CoveredEarningsTypeEnum?)request.LTDBuyUpCoveredEarningsTypeId;
                planDesignRequestLTDCoverage.IsLTDPlanExistingIndicator = request.IsLTDPlanExistingIndicator;
                planDesignRequestLTDCoverage.AdditionalDetailsText = request.AdditionalDetailsText;
                planDesignRequestLTDCoverage.BaseSalaryPercentage = request.BaseSalaryPercentage ?? null;
                planDesignRequestLTDCoverage.BonusNumberofYears = request.BonusNumberofYears ?? null;
                planDesignRequestLTDCoverage.BonusPercentage = request.BonusPercentage ?? null;
                planDesignRequestLTDCoverage.CommissionNumberofYears = request.CommissionNumberofYears ?? null;
                planDesignRequestLTDCoverage.CommissionPercentage = request.CommissionPercentage ?? null;
                planDesignRequestLTDCoverage.K1EarningsNumberofYears = request.K1EarningsNumberofYears ?? null;
                planDesignRequestLTDCoverage.K1EarningsPercentage = request.K1EarningsPercentage ?? null;
                planDesignRequestLTDCoverage.OtherIncomePercentage = request.OtherIncomePercentage ?? null;

                unitOfWork.Repository<PlanDesignRequestClassLTDCoverage>().Save(planDesignRequestLTDCoverage);
                unitOfWork.Commit();
            }
            Log.TraceFormat("-SavePDRLTDCustomizedIncomes");
        }

        private void SaveRequestClass(IUnitOfWork unitOfWork, PlanDesignRequestDto planDesignRequestDto, PlanDesignRequest planDesignRequest)
        {
            Log.TraceFormat("+SaveRequestClass");

            var premiumPayerAndTaxabilityType = unitOfWork.Repository<ExistingCoveragePremiumAndTaxpayerLiabilityType>().Linq().ToList();
            var companyRetirementPlanTypes = unitOfWork.Repository<CompanyRetirementPlanType>().Linq().ToList();
            var planDesignRequestClassDto = planDesignRequestDto.SelectedClass;
            var casePlanDesignRequestClass = PopulatePlanDesignRequestClass(unitOfWork, planDesignRequest, planDesignRequestClassDto, premiumPayerAndTaxabilityType);

            SaveCaseCompanyRetirementPlans(unitOfWork, planDesignRequestClassDto, casePlanDesignRequestClass, companyRetirementPlanTypes);

            if (casePlanDesignRequestClass.IsActive)
            {
                if (planDesignRequestClassDto.PlanDesignRequestClassProducts.Any() && planDesignRequestClassDto.PlanDesignRequestClassProducts.Count > 0)
                {
                    SavePlanDesignProduct(unitOfWork, planDesignRequestClassDto, casePlanDesignRequestClass);
                }

                SaveRequestClassRiders(unitOfWork, planDesignRequestClassDto, casePlanDesignRequestClass);
                
                if (planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage != null && planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.PremiumAndTaxpayerLiabilityTypeId != 0)
                {
                    SaveRequestClassLTDCoverage(unitOfWork, planDesignRequestClassDto, casePlanDesignRequestClass);
                }

                SavePDRClassCustomizedIncomes(unitOfWork, planDesignRequestClassDto, casePlanDesignRequestClass);

                if (planDesignRequestClassDto.EligibilityConfiguration != null && planDesignRequestClassDto.PlanDesignRequestClassId > 0)
                {
                    if (planDesignRequestClassDto.EligibilityConfiguration.CaseId != null)
                    {
                        _eligibilityConfigurationManager.SaveEligibilityConfiguration(planDesignRequestClassDto.EligibilityConfiguration);
                    }
                }
            }
            Log.TraceFormat("-SaveRequestClass");
        }

        private void SaveCaseCompanyRetirementPlans(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PlanDesignRequestClass casePlanDesignRequestClass, List<CompanyRetirementPlanType> companyRetirementPlanTypes)
        {
            Log.TraceFormat("+SaveCaseCompanyRetirementPlans");
            var caseCompanyRetirementPlans = unitOfWork.Repository<CaseCompanyRetirementPlan>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId).ToList();
            foreach (var caseCompanyRetirementPlanDto in planDesignRequestClassDto.CaseCompanyRetirementPlans)
            {
                var caseCompanyRetirementPlan = caseCompanyRetirementPlans.FirstOrDefault(c => c.Id == caseCompanyRetirementPlanDto.CaseCompanyRetirementPlanId);
                if (caseCompanyRetirementPlan == null)
                {
                    caseCompanyRetirementPlan = new CaseCompanyRetirementPlan();
                    casePlanDesignRequestClass.CaseCompanyRetirementPlan.Add(caseCompanyRetirementPlan);
                }
                caseCompanyRetirementPlan.PlanDesignRequestClass = casePlanDesignRequestClass;
                caseCompanyRetirementPlan.IsChecked = caseCompanyRetirementPlanDto.IsChecked;
                caseCompanyRetirementPlan.CompanyRetirementPlanType = companyRetirementPlanTypes.FirstOrDefault(c => c.Id == caseCompanyRetirementPlanDto.CompanyRetirementPlanTypeId);
            }
            Log.TraceFormat("-SaveCaseCompanyRetirementPlans");
        }

        private PlanDesignRequestClass PopulatePlanDesignRequestClass(IUnitOfWork unitOfWork, PlanDesignRequest planDesignRequest, PlanDesignRequestClassDto planDesignRequestClassDto, List<ExistingCoveragePremiumAndTaxpayerLiabilityType> premiumPayerAndTaxabilityType)
        {
            Log.TraceFormat("+PopulatePlanDesignRequestClass");
            var casePlanDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassDto.PlanDesignRequestClassId);
            var costShareTaxabilityType = unitOfWork.Repository<CostShareTaxabilityType>().Linq();
            if (casePlanDesignRequestClass == null)
            {
                casePlanDesignRequestClass = new PlanDesignRequestClass();
                casePlanDesignRequestClass.PlanDesignRequest = planDesignRequest;
                casePlanDesignRequestClass.PlanDesignRequestClassName = planDesignRequestClassDto.PlanDesignRequestClassName;
                casePlanDesignRequestClass.IsActive = planDesignRequestClassDto.IsActive;
                planDesignRequest.PlanDesignRequestClass.Add(casePlanDesignRequestClass);
            }
            casePlanDesignRequestClass.PlanDesignRequestClassName = GetClassName(unitOfWork, planDesignRequest, planDesignRequestClassDto);
            casePlanDesignRequestClass.ApprovedBenefitPeriod = (BenefitPeriodTypeEnum?)planDesignRequestClassDto.ApprovedBenefitPeriodTypeId;
            casePlanDesignRequestClass.ApprovedEliminationPeriod = (EliminationPeriodTypeEnum?)planDesignRequestClassDto.ApprovedEliminationPeriodTypeId;
            casePlanDesignRequestClass.ApprovedMaximumReplacementRatio = planDesignRequestClassDto.ApprovedMaximumReplacementRatio;
            casePlanDesignRequestClass.BenefitPeriodNotes = planDesignRequestClassDto.BenefitPeriodNotes;
            casePlanDesignRequestClass.RequestedEligiblePopulationText = planDesignRequestClassDto.RequestedEligiblePopulationText;
            casePlanDesignRequestClass.ApprovedEligiblePopulationText = planDesignRequestClassDto.ApprovedEligiblePopulationText;
            casePlanDesignRequestClass.EligiblePopulationTextNotes = planDesignRequestClassDto.EligiblePopulationTextNotes;
            casePlanDesignRequestClass.EliminationPeriodNotes = planDesignRequestClassDto.EliminationPeriodNotes;
            casePlanDesignRequestClass.MaximumReplacementRatioNotes = planDesignRequestClassDto.MaximumReplacementRatioNotes;
            casePlanDesignRequestClass.PlanDesignNotes = planDesignRequestClassDto.PlanDesignNotes;
            casePlanDesignRequestClass.RequestedLTDPercentage = planDesignRequestClassDto.RequestedLTDPercentage;
            casePlanDesignRequestClass.ApprovedLTDPercentage = planDesignRequestClassDto.ApprovedLTDPercentage;
            casePlanDesignRequestClass.LTDPercentageNotes = planDesignRequestClassDto.LTDPercentageNotes;
            casePlanDesignRequestClass.RequestedIDIPercentage = planDesignRequestClassDto.RequestedIDIPercentage;
            casePlanDesignRequestClass.ApprovedIDIPercentage = planDesignRequestClassDto.ApprovedIDIPercentage;
            casePlanDesignRequestClass.IDIPercentageNotes = planDesignRequestClassDto.IDIPercentageNotes;
            casePlanDesignRequestClass.RequestedPremiumPayerAndTaxabilityType = premiumPayerAndTaxabilityType.FirstOrDefault(c => c.Id == planDesignRequestClassDto.RequestedPremiumPayerAndTaxabilityTypeId);
            casePlanDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType = premiumPayerAndTaxabilityType.FirstOrDefault(c => c.Id == planDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId);
            casePlanDesignRequestClass.PremiumPayerAndTaxabilityNotes = planDesignRequestClassDto.PremiumPayerAndTaxabilityNotes;
            casePlanDesignRequestClass.RequestedBenefitPeriod_Id = planDesignRequestClassDto.RequestedBenefitPeriodId;
            casePlanDesignRequestClass.RequestedEliminationPeriod_Id = planDesignRequestClassDto.RequestedEliminationPeriodId;
            casePlanDesignRequestClass.RequestedMaximumReplacementRatio = planDesignRequestClassDto.RequestedMaximumReplacementRatio;
            casePlanDesignRequestClass.RequestedPlanDesignType = planDesignRequestClassDto.RequestedPlanDesignTypeId != null ? (PlanDesignTypeEnum?)planDesignRequestClassDto.RequestedPlanDesignTypeId : null;
            casePlanDesignRequestClass.ApprovedPlanDesignType = planDesignRequestClassDto.ApprovedPlanDesignTypeId != null ? (PlanDesignTypeEnum?)planDesignRequestClassDto.ApprovedPlanDesignTypeId : null;
            casePlanDesignRequestClass.RequestedCoveredEarningsType = planDesignRequestClassDto.RequestedCoveredEarningsTypeId != null ? (CoveredEarningsTypeEnum?)planDesignRequestClassDto.RequestedCoveredEarningsTypeId : null;
            casePlanDesignRequestClass.ApprovedCoveredEarningsType = planDesignRequestClassDto.ApprovedCoveredEarningsTypeId != null ? (CoveredEarningsTypeEnum?)planDesignRequestClassDto.ApprovedCoveredEarningsTypeId : null;
            casePlanDesignRequestClass.CoveredEarningsTypeNotes = planDesignRequestClassDto.CoveredEarningsTypeNotes;
            casePlanDesignRequestClass.RequestedCoveredEarningsTypeOther = planDesignRequestClassDto.RequestedCoveredEarningsTypeOther ?? casePlanDesignRequestClass.RequestedCoveredEarningsTypeOther;
            casePlanDesignRequestClass.RequestedIDICovers1st = planDesignRequestClassDto.RequestedIDICovers1st;
            casePlanDesignRequestClass.ApprovedIDICovers1st = planDesignRequestClassDto.ApprovedIDICovers1st;
            casePlanDesignRequestClass.IDICovers1stNotes = planDesignRequestClassDto.IDICovers1stNotes;
            casePlanDesignRequestClass.RequestedLTDCoversNext = planDesignRequestClassDto.RequestedLTDCoversNext;
            casePlanDesignRequestClass.ApprovedLTDCoversNext = planDesignRequestClassDto.ApprovedLTDCoversNext;
            casePlanDesignRequestClass.LTDCoversNextNotes = planDesignRequestClassDto.LTDCoversNextNotes;
            casePlanDesignRequestClass.RequestedRetirementContributionsType = planDesignRequestClassDto.RequestedRetirementContributionsTypeId != null ? (RetirementContributionsTypeEnum?)planDesignRequestClassDto.RequestedRetirementContributionsTypeId : null;
            casePlanDesignRequestClass.ApprovedRetirementContributionsType = planDesignRequestClassDto.ApprovedRetirementContributionsTypeId != null ? (RetirementContributionsTypeEnum?)planDesignRequestClassDto.ApprovedRetirementContributionsTypeId : null;
            casePlanDesignRequestClass.RetirementContributionNotes = planDesignRequestClassDto.RetirementContributionNotes;
            casePlanDesignRequestClass.RequestedAnnualContributions = planDesignRequestClassDto.RequestedAnnualContributions;
            casePlanDesignRequestClass.ApprovedAnnualContributions = planDesignRequestClassDto.ApprovedAnnualContributions;
            casePlanDesignRequestClass.AnnualContributionsNotes = planDesignRequestClassDto.AnnualContributionsNotes;
            casePlanDesignRequestClass.RequestedCoveredEarningsPercentage = planDesignRequestClassDto.RequestedCoveredEarningsPercentage;
            casePlanDesignRequestClass.ApprovedCoveredEarningsPercentage = planDesignRequestClassDto.ApprovedCoveredEarningsPercentage;
            casePlanDesignRequestClass.CoveredEarningsPercentageNotes = planDesignRequestClassDto.CoveredEarningsPercentageNotes;
            casePlanDesignRequestClass.RequestedRppRiderCoveredEarningsType = planDesignRequestClassDto.RequestedRppRiderCoveredEarningsTypeId != null ? (CoveredEarningsTypeEnum?)planDesignRequestClassDto.RequestedRppRiderCoveredEarningsTypeId : null;
            casePlanDesignRequestClass.ApprovedRppRiderCoveredEarningsType = planDesignRequestClassDto.ApprovedRppRiderCoveredEarningsTypeId != null ? (CoveredEarningsTypeEnum?)planDesignRequestClassDto.ApprovedRppRiderCoveredEarningsTypeId : null;
            casePlanDesignRequestClass.RppRiderCoveredEarningsTypeNotes = planDesignRequestClassDto.RppRiderCoveredEarningsTypeNotes;
            casePlanDesignRequestClass.RequestedRppRiderCoveredEarningsTypeOther = planDesignRequestClassDto.RequestedRppRiderCoveredEarningsTypeOther ?? casePlanDesignRequestClass.RequestedRppRiderCoveredEarningsTypeOther;
            casePlanDesignRequestClass.RequestedFlatRateType = unitOfWork.Repository<FlatRateType>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassDto.RequestedFlatRateType_Id);
            casePlanDesignRequestClass.ApprovedFlatRateType = unitOfWork.Repository<FlatRateType>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassDto.ApprovedFlatRateType_Id);
            casePlanDesignRequestClass.RequestedFlatRate_Other = planDesignRequestClassDto.RequestedFlatRate_Other;
            casePlanDesignRequestClass.ApprovedFlatRate_Other = planDesignRequestClassDto.ApprovedFlatRate_Other;

            casePlanDesignRequestClass.IsRequestedVoluntaryGSIBuyUpPlan = planDesignRequestClassDto.IsRequestedVoluntaryGSIBuyUpPlan;
            casePlanDesignRequestClass.IsApprovedVoluntaryGSIBuyUpPlan = planDesignRequestClassDto.IsApprovedVoluntaryGSIBuyUpPlan;
            casePlanDesignRequestClass.RequestedVoluntaryGSIBuyUpPlanDesignType = (PlanDesignGSITypeEnum?)planDesignRequestClassDto.RequestedVoluntaryGSIBuyUpPlanDesignTypeId;
            casePlanDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType = planDesignRequestClassDto.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId != null ? (PlanDesignGSITypeEnum?)planDesignRequestClassDto.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId : null;
            casePlanDesignRequestClass.VoluntaryGSIBuyUpPlanDesignNotes = planDesignRequestClassDto.VoluntaryGSIBuyUpPlanDesignNotes;
            casePlanDesignRequestClass.RequestedGSIBuyUpCoveredEarningsType = planDesignRequestClassDto.RequestedGSIBuyUpCoveredEarningsTypeId != null ? (CoveredEarningsTypeEnum?)planDesignRequestClassDto.RequestedGSIBuyUpCoveredEarningsTypeId : null;
            casePlanDesignRequestClass.ApprovedGSIBuyUpCoveredEarningsType = planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId != null ? (CoveredEarningsTypeEnum?)planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId : null;
            casePlanDesignRequestClass.RequestedGSIBuyUpCoveredEarningsBonusOnlyType = planDesignRequestClassDto.RequestedGSIBuyUpCoveredEarningsBonusOnlyTypeId != null ? (CoveredEarningsBonusOnlyTypeEnum?)planDesignRequestClassDto.RequestedGSIBuyUpCoveredEarningsBonusOnlyTypeId : null;
            casePlanDesignRequestClass.ApprovedGSIBuyUpCoveredEarningsBonusOnlyType = planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId != null ? (CoveredEarningsBonusOnlyTypeEnum?)planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId : null;
            casePlanDesignRequestClass.GSIBuyUpCoveredEarningsTypeNotes = planDesignRequestClassDto.GSIBuyUpCoveredEarningsTypeNotes;
            casePlanDesignRequestClass.RequestedGSIBuyUpReplacementPercentage = planDesignRequestClassDto.RequestedGSIBuyUpReplacementPercentage;
            casePlanDesignRequestClass.ApprovedGSIBuyUpReplacementPercentage = planDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage;
            casePlanDesignRequestClass.GSIBuyUpReplacementPercentageNotes = planDesignRequestClassDto.GSIBuyUpReplacementPercentageNotes;

            casePlanDesignRequestClass.RequestedTaxabilityType = planDesignRequestClassDto.RequestedTaxabilityTypeId != null ? (TaxabilityTypeEnum?)planDesignRequestClassDto.RequestedTaxabilityTypeId : null;
            casePlanDesignRequestClass.ApprovedTaxabilityType = planDesignRequestClassDto.ApprovedTaxabilityTypeId != null ? (TaxabilityTypeEnum?)planDesignRequestClassDto.ApprovedTaxabilityTypeId : null;
            casePlanDesignRequestClass.TaxabilityTypeNotes = planDesignRequestClassDto.TaxabilityTypeNotes;

            casePlanDesignRequestClass.RequestedTypeOfShareType = planDesignRequestClassDto.RequestedTypeOfShareTypeId != null ? (TypeOfShareTypeEnum?)planDesignRequestClassDto.RequestedTypeOfShareTypeId : null;
            casePlanDesignRequestClass.ApprovedTypeOfShareType = planDesignRequestClassDto.ApprovedTypeOfShareTypeId != null ? (TypeOfShareTypeEnum?)planDesignRequestClassDto.ApprovedTypeOfShareTypeId : null;

            casePlanDesignRequestClass.RequestedEmployerPaidPremium = planDesignRequestClassDto.RequestedEmployerPaidPremium;
            casePlanDesignRequestClass.ApprovedEmployerPaidPremium = planDesignRequestClassDto.ApprovedEmployerPaidPremium;
            casePlanDesignRequestClass.EmployerPaidPremiumNotes = planDesignRequestClassDto.EmployerPaidPremiumNotes;

            casePlanDesignRequestClass.RequestedEmployeePaidPremium = planDesignRequestClassDto.RequestedEmployeePaidPremium;
            casePlanDesignRequestClass.ApprovedEmployeePaidPremium = planDesignRequestClassDto.ApprovedEmployeePaidPremium;

            casePlanDesignRequestClass.RequestedEmployerPaysupto = planDesignRequestClassDto.RequestedEmployerPaysupto;
            casePlanDesignRequestClass.ApprovedEmployerPaysupto = planDesignRequestClassDto.ApprovedEmployerPaysupto;
            casePlanDesignRequestClass.EmployerPaysuptoNotes = planDesignRequestClassDto.EmployerPaysuptoNotes;

            casePlanDesignRequestClass.IsRequestedVoluntaryGSIBuyUpPlan = planDesignRequestClassDto.IsRequestedVoluntaryGSIBuyUpPlan;
            casePlanDesignRequestClass.IsApprovedVoluntaryGSIBuyUpPlan = planDesignRequestClassDto.IsApprovedVoluntaryGSIBuyUpPlan;
            casePlanDesignRequestClass.VoluntaryGSIBuyUpPlanNotes = planDesignRequestClassDto.VoluntaryGSIBuyUpPlanNotes;
            casePlanDesignRequestClass.RequestedCoveredEarningsBonusOnlyType = planDesignRequestClassDto.RequestedCoveredEarningsBonusOnlyTypeId != null ? (CoveredEarningsBonusOnlyTypeEnum?)planDesignRequestClassDto.RequestedCoveredEarningsBonusOnlyTypeId : null;
            casePlanDesignRequestClass.ApprovedCoveredEarningsBonusOnlyType = planDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId != null ? (CoveredEarningsBonusOnlyTypeEnum?)planDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId : null;
            casePlanDesignRequestClass.GAPlanDesignRequestClassId = planDesignRequestClassDto.GAPlanDesignRequestClassId ?? casePlanDesignRequestClass.GAPlanDesignRequestClassId;
            if (costShareTaxabilityType != null)
            {
                casePlanDesignRequestClass.RequestedCostShareTaxabilityType = costShareTaxabilityType.FirstOrDefault(c => c.Id == planDesignRequestClassDto.RequestedCostShareTaxabilityTypeId);
                casePlanDesignRequestClass.ApprovedCostShareTaxabilityType = costShareTaxabilityType.FirstOrDefault(c => c.Id == planDesignRequestClassDto.ApprovedCostShareTaxabilityTypeId);
            }

            casePlanDesignRequestClass.InsurableIncomeDefinition = GetInsurableIncomeDefinition(planDesignRequestClassDto, false);
            casePlanDesignRequestClass.BuyUpInsurableIncomeDefinition = GetInsurableIncomeDefinition(planDesignRequestClassDto, true);

            Log.TraceFormat("-PopulatePlanDesignRequestClass");
            return casePlanDesignRequestClass;
        }

        public string GetInsurableIncomeDefinition(PlanDesignRequestClassDto planDesignRequestClassDto, bool isBuyUp)
        {
            StringBuilder insurableIncomeDefinition = new StringBuilder();

            if (planDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes != null && planDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Count > 0)
            {
                var primaryIdiInsurableIncome = planDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Where(c => c.IsGSIPlanIndicator == isBuyUp).FirstOrDefault();
                if (primaryIdiInsurableIncome != null)
                {
                    if (primaryIdiInsurableIncome.BaseSalaryPercentage != null || primaryIdiInsurableIncome.BonusPercentage != null
                    || primaryIdiInsurableIncome.CommissionPercentage != null || primaryIdiInsurableIncome.K1EarningsPercentage != null
                    || primaryIdiInsurableIncome.BonusNumberofYears != null || primaryIdiInsurableIncome.CommissionNumberofYears != null
                    || primaryIdiInsurableIncome.K1EarningsNumberofYears != null || primaryIdiInsurableIncome.OtherIncomePercentage != null)
                    {
                        if (primaryIdiInsurableIncome.BaseSalaryPercentage > 0)
                        {
                            if (primaryIdiInsurableIncome.BaseSalaryPercentage < 1)
                            {
                                insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of Salary ", primaryIdiInsurableIncome.BaseSalaryPercentage));
                            }
                            else
                            {
                                insurableIncomeDefinition.AppendLine(string.Format("Salary "));
                            }
                        }

                        if (primaryIdiInsurableIncome.BonusPercentage > 0 && primaryIdiInsurableIncome.BonusNumberofYears > 0)
                        {
                            if (primaryIdiInsurableIncome.BonusNumberofYears > 1)
                            {
                                if (insurableIncomeDefinition.Length > 0)
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} years average Bonus ", primaryIdiInsurableIncome.BonusPercentage, primaryIdiInsurableIncome.BonusNumberofYears));
                                }
                                else
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of {1} years average Bonus ", primaryIdiInsurableIncome.BonusPercentage, primaryIdiInsurableIncome.BonusNumberofYears));
                                }
                            }
                            else
                            {
                                if (insurableIncomeDefinition.Length > 0)
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} year Bonus ", primaryIdiInsurableIncome.BonusPercentage, primaryIdiInsurableIncome.BonusNumberofYears));
                                }
                                else
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of {1} year Bonus ", primaryIdiInsurableIncome.BonusPercentage, primaryIdiInsurableIncome.BonusNumberofYears));
                                }
                            }
                            
                        }

                        if (primaryIdiInsurableIncome.CommissionPercentage > 0 && primaryIdiInsurableIncome.CommissionNumberofYears > 0)
                        {
                            if (primaryIdiInsurableIncome.CommissionNumberofYears > 1)
                            {
                                if (insurableIncomeDefinition.Length > 0)
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} years average Commission ", primaryIdiInsurableIncome.CommissionPercentage, primaryIdiInsurableIncome.CommissionNumberofYears));
                                }
                                else
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of {1} years average Commission ", primaryIdiInsurableIncome.CommissionPercentage, primaryIdiInsurableIncome.CommissionNumberofYears));
                                }
                            }
                            else
                            {
                                if (insurableIncomeDefinition.Length > 0)
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} year Commission ", primaryIdiInsurableIncome.CommissionPercentage, primaryIdiInsurableIncome.CommissionNumberofYears));
                                }
                                else
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of {1} year Commission ", primaryIdiInsurableIncome.CommissionPercentage, primaryIdiInsurableIncome.CommissionNumberofYears));
                                }
                            }
                        }

                        if (primaryIdiInsurableIncome.K1EarningsPercentage > 0 && primaryIdiInsurableIncome.K1EarningsNumberofYears > 0)
                        {
                            if (primaryIdiInsurableIncome.K1EarningsNumberofYears > 1)
                            {
                                if (insurableIncomeDefinition.Length > 0)
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} years average K-1 Earnings ", primaryIdiInsurableIncome.K1EarningsPercentage, primaryIdiInsurableIncome.K1EarningsNumberofYears));
                                }
                                else
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of {1} years average K-1 Earnings ", primaryIdiInsurableIncome.K1EarningsPercentage, primaryIdiInsurableIncome.K1EarningsNumberofYears));
                                }
                            }
                            else
                            {
                                if (insurableIncomeDefinition.Length > 0)
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} year K-1 Earnings ", primaryIdiInsurableIncome.K1EarningsPercentage, primaryIdiInsurableIncome.K1EarningsNumberofYears));
                                }
                                else
                                {
                                    insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of {1} year K-1 Earnings ", primaryIdiInsurableIncome.K1EarningsPercentage, primaryIdiInsurableIncome.K1EarningsNumberofYears));
                                }
                            }
                            
                        }
                        if (primaryIdiInsurableIncome.OtherIncomePercentage > 0)
                        {
                            if (insurableIncomeDefinition.Length > 0)
                            {
                                insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of 1 year Other Income ", primaryIdiInsurableIncome.OtherIncomePercentage));
                            }
                            else
                            {
                                insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of 1 year Other Income ", primaryIdiInsurableIncome.OtherIncomePercentage));
                            }
                        }
                    }
                }
                if(!isBuyUp)
                {
                    if (planDesignRequestClassDto.ApprovedCoveredEarningsTypeId != null)
                    {
                        insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForCoveredEarnings((CoveredEarningsTypeEnum)planDesignRequestClassDto.ApprovedCoveredEarningsTypeId));
                    }
                    else if (planDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId != null)
                    {
                        insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForBonusOnlyCoveredEarnings((CoveredEarningsBonusOnlyTypeEnum)planDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId));
                    }
                }
                else
                {
                    if (planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId != null)
                    {
                        insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForCoveredEarnings((CoveredEarningsTypeEnum)planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId));
                    }
                    else if (planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId != null)
                    {
                        insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForBonusOnlyCoveredEarnings((CoveredEarningsBonusOnlyTypeEnum)planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId));
                    }
                }
            }
            else
            {
                if (!isBuyUp)
                {
                    if (planDesignRequestClassDto.ApprovedCoveredEarningsTypeId != null)
                    {
                        insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForCoveredEarnings((CoveredEarningsTypeEnum)planDesignRequestClassDto.ApprovedCoveredEarningsTypeId));
                    }
                    else if (planDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId != null)
                    {
                        insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForBonusOnlyCoveredEarnings((CoveredEarningsBonusOnlyTypeEnum)planDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId));
                    }
                }
                else
                {
                    if (planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId != null)
                    {
                        insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForCoveredEarnings((CoveredEarningsTypeEnum)planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId));
                    }
                    else if (planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId != null)
                    {
                        insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForBonusOnlyCoveredEarnings((CoveredEarningsBonusOnlyTypeEnum)planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId));
                    }
                }
            }

            return insurableIncomeDefinition.ToString();
        }

        private string GetInsurableIncomeDefinitionForCoveredEarnings(CoveredEarningsTypeEnum selectedCoveredEarningsType)
        {
            StringBuilder resultDefinition = new StringBuilder();

            switch ((CoveredEarningsTypeEnum)selectedCoveredEarningsType)
            {
                case CoveredEarningsTypeEnum.BaseSalaryOnly:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.BaseSalaryOnly.GetDescription());
                    break;

                case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                    resultDefinition.AppendLine("Salary plus:");
                    resultDefinition.AppendLine("	• Two years submitted Bonus, averaged, or");
                    resultDefinition.AppendLine("	• 75% of submitted One year bonus income");
                    break;

                case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                    resultDefinition.AppendLine("Salary plus:");
                    resultDefinition.AppendLine("	• Two years submitted Bonus and Commission income, averaged, or");
                    resultDefinition.AppendLine("	• 75% of submitted One year bonus and commission income");
                    break;

                case CoveredEarningsTypeEnum.BaseSalary_Commission:
                    resultDefinition.AppendLine("Salary plus:");
                    resultDefinition.AppendLine("	• Two years submitted Commission income, averaged, or");
                    resultDefinition.AppendLine("	• 75% of submitted One year commission income");
                    break;

                case CoveredEarningsTypeEnum.IDIInsurableIncome:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.IDIInsurableIncome.GetDescription());
                    break;

                case CoveredEarningsTypeEnum.K_1Earnings:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.K_1Earnings.GetDescription());
                    break;

                case CoveredEarningsTypeEnum.Other:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.Other.GetDescription());
                    break;

                case CoveredEarningsTypeEnum.TotalCompensation:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.TotalCompensation.GetDescription());
                    break;

                case CoveredEarningsTypeEnum.W_2Income:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.W_2Income.GetDescription());
                    break;
            }
            return resultDefinition.ToString();
        }

        private string GetInsurableIncomeDefinitionForBonusOnlyCoveredEarnings(CoveredEarningsBonusOnlyTypeEnum selectedCoveredEarningsType)
        {
            StringBuilder resultDefinition = new StringBuilder();

            switch ((CoveredEarningsBonusOnlyTypeEnum)selectedCoveredEarningsType)
            {
                case CoveredEarningsBonusOnlyTypeEnum.Bonus:
                    resultDefinition.AppendLine("Two years submitted Bonus, averaged, or");
                    resultDefinition.AppendLine("75% of current years bonus income");
                    break;

                case CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission:
                    resultDefinition.AppendLine("Two years submitted Bonus and Commission income, averaged, or");
                    resultDefinition.AppendLine("75% of current years bonus and commission income");
                    break;

                case CoveredEarningsBonusOnlyTypeEnum.Commissions:
                    resultDefinition.AppendLine("Two years submitted Commission income, averaged, or");
                    resultDefinition.AppendLine("75% of current years commission income");
                    break;

                case CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus:
                    resultDefinition.AppendLine(CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus.GetDescription());
                    break;

                case CoveredEarningsBonusOnlyTypeEnum.K_1Earnings:
                    resultDefinition.AppendLine("Two years submitted K-1 income, averaged, or");
                    resultDefinition.AppendLine("75% of current years K-1 income");
                    break;
            }
            return resultDefinition.ToString();
        }

        private string GetClassName(IUnitOfWork unitOfWork, PlanDesignRequest planDesignRequest, PlanDesignRequestClassDto planDesignRequestClassDto)
        {
            Log.TraceFormat("+GetClassName");
            string className = null;
            if (!String.IsNullOrEmpty(planDesignRequestClassDto.PlanDesignRequestClassName))
            {
                className = planDesignRequestClassDto.PlanDesignRequestClassName;
            }
            else
            {
                var cmsPlanDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.PlanDesignRequest.Id == planDesignRequest.Id);
                int classNo = 0;
                if (cmsPlanDesignRequestClass != null)
                {
                    if (!string.IsNullOrEmpty(cmsPlanDesignRequestClass.PlanDesignRequestClassName))
                    {
                        string[] headerName = cmsPlanDesignRequestClass.PlanDesignRequestClassName.Split(' ');
                        classNo = GetIntValue(headerName[1]);
                    }
                }
                className = "Class " + (++classNo);
            }
            Log.TraceFormat("-GetClassName");
            return className;
        }

        private void SaveRequestClassRiders(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PlanDesignRequestClass casePlanDesignRequestClass)
        {
            Log.TraceFormat("+SaveRequestClassRiders");

            var planDesignRequestClassRiders = unitOfWork.Repository<PlanDesignRequestClassRider>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId).ToList();
            foreach (var planDesignRequestClassRiderDto in planDesignRequestClassDto.PlanDesignRequestClassRiders)
            {
                var planDesignRequestClassRider = planDesignRequestClassRiders.FirstOrDefault(c => c.Id == planDesignRequestClassRiderDto.PlanDesignRequestClassRiderId);
                if (planDesignRequestClassRider == null)
                {
                    planDesignRequestClassRider = new PlanDesignRequestClassRider();
                    planDesignRequestClassRider.PlanDesignRequestClass = casePlanDesignRequestClass;
                    casePlanDesignRequestClass.PlanDesignRequestClassRiders.Add(planDesignRequestClassRider);
                }
                planDesignRequestClassRider.BenefitGroupType = (BenefitGroupTypeEnum)planDesignRequestClassRiderDto.SelectedBenefitGroup;
                if (planDesignRequestClassRiderDto.SelectedBenefitType != null) planDesignRequestClassRider.BenefitType = (BenefitTypeEnum)planDesignRequestClassRiderDto.SelectedBenefitType;
                planDesignRequestClassRider.BenefitPeriodType = planDesignRequestClassRiderDto.SelectedBenefitPeriod != null ? (BenefitPeriodTypeEnum?)planDesignRequestClassRiderDto.SelectedBenefitPeriod : null;
                planDesignRequestClassRider.EliminationPeriodType = planDesignRequestClassRiderDto.SelectedEliminationPeriod != null ? (EliminationPeriodTypeEnum?)planDesignRequestClassRiderDto.SelectedEliminationPeriod : null;
                planDesignRequestClassRider.ApprovedAmount = planDesignRequestClassRiderDto.ApprovedAmount;
                planDesignRequestClassRider.IsGSIPlanIndicator = planDesignRequestClassRiderDto.IsGSIPlanIndicator;
            }

            var newAndExistingRidersIds = planDesignRequestClassDto.PlanDesignRequestClassRiders.Select(d => d.PlanDesignRequestClassRiderId).ToList();
            var deletedRiders = planDesignRequestClassRiders.Where(l => !newAndExistingRidersIds.Contains(l.Id)).ToList();
            foreach (var deletedRider in deletedRiders)
            {
                casePlanDesignRequestClass.PlanDesignRequestClassRiders.Remove(deletedRider);
            }

            Log.TraceFormat("-SaveRequestClassRiders");
        }

        private void SavePDRClassCustomizedIncomes(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PlanDesignRequestClass casePlanDesignRequestClass)
        {
            Log.TraceFormat("+SavePDRClassCustomizedIncomes");

            var pdrClassCustomizedIncomes = unitOfWork.Repository<PDRClassCustomizedIDIInsurableIncome>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId).ToList();
            foreach (var pdrClassCustomizedIDIInsurableIncomeDto in planDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes)
            {
                var pdrClassCustomizedIDIInsurableIncome = pdrClassCustomizedIncomes.FirstOrDefault(c => c.Id == pdrClassCustomizedIDIInsurableIncomeDto.PDRClassCustomizedIDIInsurableIncomeId);
                if (pdrClassCustomizedIDIInsurableIncome == null)
                {
                    pdrClassCustomizedIDIInsurableIncome = new PDRClassCustomizedIDIInsurableIncome();
                    pdrClassCustomizedIDIInsurableIncome.PlanDesignRequestClass = casePlanDesignRequestClass;
                    casePlanDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.Add(pdrClassCustomizedIDIInsurableIncome);
                }
                CreatePDRClassCustomizedIDIInsurableIncome(pdrClassCustomizedIDIInsurableIncomeDto, pdrClassCustomizedIDIInsurableIncome);
            }

            var newAndExistingCustomizedIncomeIds = planDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Select(d => d.PDRClassCustomizedIDIInsurableIncomeId).ToList();
            var deletedIncomes = pdrClassCustomizedIncomes.Where(l => !newAndExistingCustomizedIncomeIds.Contains(l.Id)).ToList();
            foreach (var deletedIncome in deletedIncomes)
            {
                casePlanDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.Remove(deletedIncome);
            }
            Log.TraceFormat("-SavePDRClassCustomizedIncomes");
        }

        private void CreatePDRClassCustomizedIDIInsurableIncome(PDRClassCustomizedIDIInsurableIncomeDto pdrClassCustomizedIDIInsurableIncomeDto, PDRClassCustomizedIDIInsurableIncome pdrClassCustomizedIDIInsurableIncome)
        {
            pdrClassCustomizedIDIInsurableIncome.BaseSalaryPercentage = pdrClassCustomizedIDIInsurableIncomeDto.BaseSalaryPercentage;
            pdrClassCustomizedIDIInsurableIncome.BonusPercentage = pdrClassCustomizedIDIInsurableIncomeDto.BonusPercentage;
            pdrClassCustomizedIDIInsurableIncome.CommissionPercentage = pdrClassCustomizedIDIInsurableIncomeDto.CommissionPercentage;
            pdrClassCustomizedIDIInsurableIncome.OtherIncomePercentage = pdrClassCustomizedIDIInsurableIncomeDto.OtherIncomePercentage;
            pdrClassCustomizedIDIInsurableIncome.K1EarningsPercentage = pdrClassCustomizedIDIInsurableIncomeDto.K1EarningsPercentage;
            pdrClassCustomizedIDIInsurableIncome.BonusNumberofYears = pdrClassCustomizedIDIInsurableIncomeDto.BonusNumberofYears;
            pdrClassCustomizedIDIInsurableIncome.CommissionNumberofYears = pdrClassCustomizedIDIInsurableIncomeDto.CommissionNumberofYears;
            pdrClassCustomizedIDIInsurableIncome.K1EarningsNumberofYears = pdrClassCustomizedIDIInsurableIncomeDto.K1EarningsNumberofYears;
            pdrClassCustomizedIDIInsurableIncome.IsGSIPlanIndicator = pdrClassCustomizedIDIInsurableIncomeDto.IsGSIPlanIndicator;
        }

        private void SavePlanDesignProduct(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PlanDesignRequestClass casePlanDesignRequestClass)
        {
            Log.TraceFormat("+SavePlanDesignProduct");
            var planDesignRequestProducts = unitOfWork.Repository<PlanDesignRequestClassProduct>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId).ToList();
            foreach (var planDesignProductDto in planDesignRequestClassDto.PlanDesignRequestClassProducts)
            {
                var planDesignRequestProduct = planDesignRequestProducts.FirstOrDefault(c => c.Id == planDesignProductDto.PlanDesignRequestClassProductId);
                if (planDesignRequestProduct == null)
                {
                    planDesignRequestProduct = new PlanDesignRequestClassProduct();
                    planDesignRequestProduct.PlanDesignRequestClass = casePlanDesignRequestClass;
                    casePlanDesignRequestClass.PlanDesignRequestClassProducts.Add(planDesignRequestProduct);
                }
                if (planDesignProductDto.GSIAmount != null)
                {
                    planDesignRequestProduct.GSIAmount = (int)planDesignProductDto.GSIAmount;
                }
                if (planDesignProductDto.MinimumCaseLevelGSIAmount != null)
                {
                    planDesignRequestProduct.MinimumCaseLevelGSIAmount = (int)planDesignProductDto.MinimumCaseLevelGSIAmount;
                }
                if (planDesignProductDto.TotalMaxGSIAmount != null)
                {
                    planDesignRequestProduct.TotalMaxGSIAmount = (int)planDesignProductDto.TotalMaxGSIAmount;
                }
                planDesignRequestProduct.BaseDiscountType = unitOfWork.Repository<BaseDiscountType>().Linq().FirstOrDefault(c => c.Id == planDesignProductDto.BaseDiscountTypeId);
                planDesignRequestProduct.DemographicDiscountType = unitOfWork.Repository<DemographicDiscountType>().Linq().FirstOrDefault(c => c.Id == planDesignProductDto.DemographicDiscountTypeId);

                planDesignRequestProduct.EmployerPaidDiscountType = unitOfWork.Repository<EmployerPaidDiscountType>().Linq().FirstOrDefault(c => c.Id == planDesignProductDto.EmployerPaidDiscountTypeId);

                if (planDesignProductDto.ParticipationPercentage != null)
                {
                    planDesignRequestProduct.ParticipationPercentage = (int)planDesignProductDto.ParticipationPercentage;
                }
                planDesignRequestProduct.DefinitionOfDisabilityType = (DefinitionOfDisabilityTypeEnum)planDesignProductDto.DefinitionOfDisabilityTypeId;
                planDesignRequestProduct.MentalSubstanceLimitationType = (MentalSubstanceLimitationEnum)planDesignProductDto.MentalSubstanceLimitationTypeId;
                planDesignRequestProduct.PreExistingConditionLimitType = (PreExistingConditionLimitTypeEnum)planDesignProductDto.PreExistingConditionLimitTypeId;
                planDesignRequestProduct.BenefitPeriodType = (BenefitPeriodTypeEnum?)planDesignProductDto.BenefitPeriodTypeId;
                planDesignRequestProduct.EliminationPeriodType = (EliminationPeriodTypeEnum?)planDesignProductDto.EliminationPeriodTypeId;
                planDesignRequestProduct.IsGSIPlanIndicator = planDesignProductDto.IsGSIPlanIndicator;
                planDesignRequestProduct.DiscountOverride = planDesignProductDto.DiscountOverride;
                planDesignRequestProduct.IsOneStepEnrollmentIndicator= planDesignProductDto.IsOneStepEnrollmentIndicator;
                planDesignRequestProduct.IsDirectCoverageIndicator = planDesignProductDto.IsDirectCoverageIndicator;
            }

            var newAndExistingProductIds = planDesignRequestClassDto.PlanDesignRequestClassProducts.Select(d => d.PlanDesignRequestClassProductId).ToList();
            var deletedProductss = planDesignRequestProducts.Where(l => !newAndExistingProductIds.Contains(l.Id)).ToList();
            foreach (var deletedProduct in deletedProductss)
            {
                casePlanDesignRequestClass.PlanDesignRequestClassProducts.Remove(deletedProduct);
            }

            Log.TraceFormat("-SavePlanDesignProduct");
        }

        private void SaveRequestClassLTDCoverage(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PlanDesignRequestClass casePlanDesignRequestClass)
        {
            Log.TraceFormat("+SaveRequestClassLTDCoverage");

            var planDesignRequestLTDCoverage = unitOfWork.Repository<PlanDesignRequestClassLTDCoverage>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId);
            if (planDesignRequestLTDCoverage == null)
            {
                planDesignRequestLTDCoverage = new PlanDesignRequestClassLTDCoverage();
                planDesignRequestLTDCoverage.PlanDesignRequestClass = casePlanDesignRequestClass;
                casePlanDesignRequestClass.PlanDesignRequestClassLTDCoverage.Add(planDesignRequestLTDCoverage);
            }
            planDesignRequestLTDCoverage.EligiblePopulationText = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.EligiblePopulationText;
            planDesignRequestLTDCoverage.CarrierText = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.CarrierText;
            planDesignRequestLTDCoverage.EliminationPeriodDays = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.EliminationPeriodDays;
            planDesignRequestLTDCoverage.BenefitPeriodDays = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.BenefitPeriodDays;
            planDesignRequestLTDCoverage.GroupLTDReplacementPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.GroupLTDReplacementPercentage;
            planDesignRequestLTDCoverage.GroupLTDCapAmount = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.GroupLTDCapAmount;
            planDesignRequestLTDCoverage.GroupLTDCoveredEarningsType = (CoveredEarningsTypeEnum)planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.GroupLTDCoveredEarningsTypeId;
            planDesignRequestLTDCoverage.PremiumAndTaxpayerLiabilityType = unitOfWork.Repository<ExistingCoveragePremiumAndTaxpayerLiabilityType>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.PremiumAndTaxpayerLiabilityTypeId);
            planDesignRequestLTDCoverage.TypeOfPayType = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.TypeOfPayTypeId != null ? (TaxabilityTypeEnum?)planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.TypeOfPayTypeId : null;
            planDesignRequestLTDCoverage.IsVoluntaryLTDBuyUpIndicator = (GetIsVoluntaryLTDBuyUpIndicator(planDesignRequestLTDCoverage) == true) ? planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator : null;
            planDesignRequestLTDCoverage.LTDBuyUpReplacementPercentage = (planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator == null || false == planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator) ? null : planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.LTDBuyUpReplacementPercentage;
            planDesignRequestLTDCoverage.LTDBuyUpLTDCapAmount = (planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator == null || false == planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator) ? null : planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.LTDBuyUpLTDCapAmount;
            planDesignRequestLTDCoverage.LTDBuyUpCoveredEarningsType = (planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator == null || false == planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator) ? null : (CoveredEarningsTypeEnum?)planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.LTDBuyUpCoveredEarningsTypeId;
            planDesignRequestLTDCoverage.IsLTDPlanExistingIndicator = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsLTDPlanExistingIndicator;
            planDesignRequestLTDCoverage.AdditionalDetailsText = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.AdditionalDetailsText;
            planDesignRequestLTDCoverage.BaseSalaryPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.BaseSalaryPercentage ?? null;
            planDesignRequestLTDCoverage.BonusNumberofYears = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.BonusNumberofYears ?? null;
            planDesignRequestLTDCoverage.BonusPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.BonusPercentage ?? null;
            planDesignRequestLTDCoverage.CommissionNumberofYears = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.CommissionNumberofYears ?? null;
            planDesignRequestLTDCoverage.CommissionPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.CommissionPercentage ?? null;
            planDesignRequestLTDCoverage.K1EarningsNumberofYears = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.K1EarningsNumberofYears ?? null;
            planDesignRequestLTDCoverage.K1EarningsPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.K1EarningsPercentage ?? null;
            planDesignRequestLTDCoverage.OtherIncomePercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.OtherIncomePercentage ?? null;
            Log.TraceFormat("-SaveRequestClassLTDCoverage");
        }

        private bool? GetIsVoluntaryLTDBuyUpIndicator(PlanDesignRequestClassLTDCoverage ltdCoverage)
        {
            if (ltdCoverage.PremiumAndTaxpayerLiabilityType != null &&
                (ltdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid ||
                ltdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable))
            {
                return true;
            }
            return null;
        }

        private int GetIntValue(string inputValue)
        {
            int value = 0;
            int.TryParse(inputValue, out value);
            return value;
        }
    }
}
