﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Interfaces.Managers.LookupManagers;
using CMS.Interfaces.Managers.OfferLetterManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Managers.BusinessManagers;
using Common.Exceptions;
using CMS.Interfaces.Managers.ITAdminManagers;

namespace CMS.Managers.PlanManagers
{
    public class PlanDesignRequestSoldManager : IPlanDesignRequestSoldManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IProductLibraryManager _productLibraryManager;
        private readonly ILookupManager _lookupManager;
        private readonly PlanDesignRequestManagerValidator _planDesignRequestValidator;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;
        private readonly PlanDesignRequestGetter _planDesignRequestGetter;
        private readonly PlanDesignRequestSaver _planDesignRequestSaver;
        private readonly PlanDesignRequestSaveSoldManager _planDesignRequestSaveSoldManager;
        private readonly IStatePricingTypeManager _statePricingTypeManager;
        //private readonly ICompactStateManager _compactStateManager;
        private const int defaultMinimumGSIAmount = 300;

        public PlanDesignRequestSoldManager(IUnitOfWorkFactory unitOfWorkFactory, IProductLibraryManager productLibraryManager, ILookupManager lookupManager,
            IEligibilityConfigurationManager eligibilityConfigurationManager, PlanDesignRequestSaveSoldManager planDesignRequestSaveSoldManager, 
            IStatePricingTypeManager statePricingTypeManager, ICompactStateManager compactStateManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _productLibraryManager = productLibraryManager;
            _lookupManager = lookupManager;
            _planDesignRequestSaveSoldManager = planDesignRequestSaveSoldManager;
            //_compactStateManager = compactStateManager;
            _planDesignRequestValidator = new PlanDesignRequestManagerValidator();
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
            _statePricingTypeManager = statePricingTypeManager;
            _planDesignRequestGetter = new PlanDesignRequestGetter(_unitOfWorkFactory, _eligibilityConfigurationManager);
            _planDesignRequestSaver = new PlanDesignRequestSaver(_unitOfWorkFactory, _productLibraryManager, 
                _eligibilityConfigurationManager, _statePricingTypeManager, compactStateManager);
        }

        public void MarkPDRSold(int caseId, int planDesignRequestId)
        {
            Log.TraceFormat("+MarkPDRSold");

            var unSoldPDRIds = new List<int>();
            var unSoldClassIds = new List<int>();
            var pdrIds = new List<int>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(i => i.Id == caseId);
                var sourcePDR = cmsCase.PlanDesignRequests.FirstOrDefault(i => i.Id == planDesignRequestId && i.IsActive == true);
                var targetPDRSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(i => i.PlanDesignRequest.Id == planDesignRequestId);

                pdrIds.Add(planDesignRequestId);

                if (sourcePDR.PlanDesignRequestStatusType == PlanDesignRequestStatusTypeEnum.Approved || sourcePDR.PlanDesignRequestStatusType == PlanDesignRequestStatusTypeEnum.Released)
                {

                    unSoldPDRIds = cmsCase.PlanDesignRequests.Where(p => !pdrIds.Contains(p.Id) && p.PDRSoldClass.Count == 0).Select(pdr => pdr.Id).ToList();

                    foreach (int pdrId in unSoldPDRIds)
                    {
                        var unsoldPDR = cmsCase.PlanDesignRequests.Where(i => i.Id == pdrId);
                        var unsoldClassIds = unsoldPDR.SelectMany(p => p.PlanDesignRequestClass).Select(c => c.Id).ToList();
                        unSoldClassIds.AddRange(unsoldClassIds);
                    }

                    var riderGroups = _productLibraryManager.GetPlanDesignRiders();
                    var discountTypes = _lookupManager.GetValues<PDRDiscountType>();
                    var baseDiscountTypes = _lookupManager.GetValues<BaseDiscountType>();
                    var demographicDiscountTypes = _lookupManager.GetValues<DemographicDiscountType>();
                    var employerPaidDiscountTypes = _lookupManager.GetValues<EmployerPaidDiscountType>();

                    if (sourcePDR != null)
                    {
                        foreach (var sourcePDRClass in sourcePDR.PlanDesignRequestClass)
                        {
                            if (sourcePDRClass.ApprovedPlanDesignType != null && sourcePDRClass.IsActive == true)
                            {
                                PDRSoldClass soldClass = CreateSoldClassRequest(sourcePDR, sourcePDRClass);
                                var soldPlanRequest = CreateSoldClassPlan(soldClass, sourcePDRClass, false, riderGroups, discountTypes, baseDiscountTypes, demographicDiscountTypes,employerPaidDiscountTypes);

                                soldClass.PDRSoldClassPlan.Add(soldPlanRequest);
                                if (sourcePDRClass.IsApprovedVoluntaryGSIBuyUpPlan != null && (bool)sourcePDRClass.IsApprovedVoluntaryGSIBuyUpPlan)
                                {
                                    soldPlanRequest = CreateSoldClassPlan(soldClass, sourcePDRClass, true, riderGroups, discountTypes, baseDiscountTypes, demographicDiscountTypes,employerPaidDiscountTypes);
                                    soldClass.PDRSoldClassPlan.Add(soldPlanRequest);
                                }
                                unitOfWork.Repository<PDRSoldClass>().Save(soldClass);
                            }
                        }
                        unitOfWork.Commit();
                    }
                }
                else
                {
                    throw new ValidationException("Please select an Approved PDR");
                }

            }

            foreach (var pdrId in pdrIds)
            {
                _planDesignRequestSaveSoldManager.DeactivatePDRClassesNotSold(unSoldClassIds, pdrId, true);
            }
            _planDesignRequestSaveSoldManager.DeactivatePDRsNotSold(unSoldPDRIds);

            Log.TraceFormat("-MarkPDRSold");

        }

        private PDRSoldClassPlan CreateSoldClassPlan(PDRSoldClass targetSoldClass, PlanDesignRequestClass sourcePDRClass, bool hasBuyUp, List<PlanDesignRequestClassRiderGroupDto> riderGroups, List<PDRDiscountType> discountTypes, List<BaseDiscountType> baseDiscountTypes, List<DemographicDiscountType> demographicDiscountTypes, List<EmployerPaidDiscountType> employerPaidDiscountTypes)
        {
            Log.TraceFormat("+CreateSoldClassPlan");

            var sourcePDRClassProduct = sourcePDRClass.PlanDesignRequestClassProducts.FirstOrDefault(i => i.IsGSIPlanIndicator == hasBuyUp);


            PDRSoldClassPlan classPlan = new PDRSoldClassPlan
            {
                PDRSoldClass = targetSoldClass,
                PlanDesignType = sourcePDRClass.ApprovedPlanDesignType,
                PlanDesignNotes = sourcePDRClass.PlanDesignNotes,
                LTDPercentage = sourcePDRClass.ApprovedLTDPercentage,
                LTDPercentageNotes = sourcePDRClass.LTDPercentageNotes,
                IDIPercentage = sourcePDRClass.ApprovedIDIPercentage,
                IDIPercentageNotes = sourcePDRClass.IDIPercentageNotes,
                PremiumPayerAndTaxabilityType = sourcePDRClass.ApprovedPremiumPayerAndTaxabilityType,
                PremiumPayerAndTaxabilityNotes = sourcePDRClass.PremiumPayerAndTaxabilityNotes,
                MaximumReplacementRatio = sourcePDRClass.ApprovedMaximumReplacementRatio,
                MaximumReplacementRatioNotes = sourcePDRClass.MaximumReplacementRatioNotes,
                LTDCoversNext = sourcePDRClass.ApprovedLTDCoversNext,
                LTDCoversNextNotes = sourcePDRClass.LTDCoversNextNotes,
                IDICovers1st = sourcePDRClass.ApprovedIDICovers1st,
                IDICovers1stNotes = sourcePDRClass.IDICovers1stNotes,
                CoveredEarningsType = sourcePDRClass.ApprovedCoveredEarningsType,
                CoveredEarningsTypeNotes = sourcePDRClass.CoveredEarningsTypeNotes,
                FlatRateType = sourcePDRClass.ApprovedFlatRateType,
                FlatRate_Other = sourcePDRClass.ApprovedFlatRate_Other,
                RetirementContributionsType = sourcePDRClass.ApprovedRetirementContributionsType,
                RetirementContributionsNotes = sourcePDRClass.RetirementContributionNotes,
                AnnualContributions = sourcePDRClass.ApprovedAnnualContributions,
                AnnualContributionsNotes = sourcePDRClass.AnnualContributionsNotes,
                CoveredEarningsPercentage = sourcePDRClass.ApprovedCoveredEarningsPercentage,
                CoveredEarningsPercentageNotes = sourcePDRClass.CoveredEarningsPercentageNotes,
                RppRiderCoveredEarningsType = sourcePDRClass.ApprovedRppRiderCoveredEarningsType,
                RppRiderCoveredEarningsTypeNotes = sourcePDRClass.RppRiderCoveredEarningsTypeNotes,
                TaxabilityType = sourcePDRClass.ApprovedTaxabilityType,
                TaxabilityTypeNotes = sourcePDRClass.TaxabilityTypeNotes,
                CoveredEarningsBonusOnlyType = sourcePDRClass.ApprovedCoveredEarningsBonusOnlyType,
                TypeOfShareType = sourcePDRClass.ApprovedTypeOfShareType,
                EmployeePaidPremium = sourcePDRClass.ApprovedEmployeePaidPremium,
                EmployerPaidPremium = sourcePDRClass.ApprovedEmployerPaidPremium,
                EmployerPaidPremiumNotes = sourcePDRClass.EmployerPaidPremiumNotes,
                EmployerPaysupto = sourcePDRClass.ApprovedEmployerPaysupto,
                EmployerPaysuptoNotes = sourcePDRClass.EmployerPaysuptoNotes,
                CostShareTaxabilityType = sourcePDRClass.ApprovedCostShareTaxabilityType,
                BenefitPeriodNotes = sourcePDRClass.BenefitPeriodNotes,
                EliminationPeriodNotes = sourcePDRClass.EliminationPeriodNotes,
                ParticipationPercentage = sourcePDRClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).ParticipationPercentage,
                BaseDiscountType = sourcePDRClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).BaseDiscountType,
                DemographicDiscountType = sourcePDRClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).DemographicDiscountType,


                EmployerPaidDiscountType  = sourcePDRClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).EmployerPaidDiscountType,


                TotalMaxGSIAmount = sourcePDRClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).TotalMaxGSIAmount,
                InsurableIncomeDefinition = sourcePDRClass.InsurableIncomeDefinition,
                BenefitPeriod = sourcePDRClass.ApprovedBenefitPeriod,
                EliminationPeriod = sourcePDRClass.ApprovedEliminationPeriod,
                MinimumCaseLevelGSIAmount = (sourcePDRClassProduct.MinimumCaseLevelGSIAmount == 0 || sourcePDRClassProduct.MinimumCaseLevelGSIAmount == null) ? defaultMinimumGSIAmount : (int)sourcePDRClassProduct.MinimumCaseLevelGSIAmount,
                DiscountOverride = sourcePDRClassProduct.DiscountOverride,
                GSIAmount = (int)sourcePDRClassProduct.GSIAmount,
                DefinitionOfDisabilityType = (DefinitionOfDisabilityTypeEnum)sourcePDRClassProduct.DefinitionOfDisabilityType,
                MentalSubstanceLimitationType = (MentalSubstanceLimitationEnum)sourcePDRClassProduct.MentalSubstanceLimitationType,
                PreExistingConditionLimitType = (PreExistingConditionLimitTypeEnum)sourcePDRClassProduct.PreExistingConditionLimitType,
                IsOneStepEnrollmentIndicator = sourcePDRClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).IsOneStepEnrollmentIndicator,
                IsDirectCoverageIndicator = sourcePDRClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).IsDirectCoverageIndicator

            };

            classPlan.PDRSoldClassPlanRiders = sourcePDRClass.PlanDesignRequestClassRiders.Where(i => i.IsGSIPlanIndicator == hasBuyUp).Select(b => new PDRSoldClassPlanRiders
            {
                PDRSoldClassPlan = classPlan,
                BenefitType = (BenefitTypeEnum)b.BenefitType,
                BenefitPeriodType = b.BenefitPeriodType != null ? (BenefitPeriodTypeEnum?)b.BenefitPeriodType : null,
                EliminationPeriodType = b.EliminationPeriodType != null ? (EliminationPeriodTypeEnum?)b.EliminationPeriodType : null,
                ApprovedAmount = b.ApprovedAmount ?? null,
                BenefitGroupType = (BenefitGroupTypeEnum)riderGroups.FirstOrDefault(rg => rg.Riders.Where(r => r.BenefitTypes.Contains((BenefitTypeEnum)b.BenefitType)).Any()).BenefitGroup.Id
            }).ToList();

            classPlan.PDRSoldClassPlanCustomizedIDIInsurableIncomes = sourcePDRClass.PDRClassCustomizedIDIInsurableIncomes.Where(c => c.IsGSIPlanIndicator == hasBuyUp).Select(c => new PDRSoldClassPlanCustomizedIDIInsurableIncome
            {
                BaseSalaryPercentage = c.BaseSalaryPercentage ?? null,
                BonusNumberofYears = c.BonusNumberofYears ?? null,
                BonusPercentage = c.BonusPercentage ?? null,
                CommissionNumberofYears = c.CommissionNumberofYears ?? null,
                CommissionPercentage = c.CommissionPercentage ?? null,
                K1EarningsNumberofYears = c.K1EarningsNumberofYears ?? null,
                K1EarningsPercentage = c.K1EarningsPercentage ?? null,
                OtherIncomePercentage = c.OtherIncomePercentage ?? null,
                PDRSoldClassPlan = classPlan
            }).ToList();

            classPlan.GSIBuyUpPlanNotes = sourcePDRClass.VoluntaryGSIBuyUpPlanNotes;

            if (hasBuyUp)
            {
                classPlan.PDRClassPlanType = PDRClassPlanTypeEnum.VoluntaryGSIBuyUp;
                classPlan.PlanDesignType = (PlanDesignTypeEnum)sourcePDRClass.ApprovedVoluntaryGSIBuyUpPlanDesignType;
                classPlan.GSIBuyUpPlanNotes = sourcePDRClass.VoluntaryGSIBuyUpPlanNotes;
                classPlan.GSIBuyUpPlanDesignNotes = sourcePDRClass.VoluntaryGSIBuyUpPlanDesignNotes;
                classPlan.CoveredEarningsType = sourcePDRClass.ApprovedGSIBuyUpCoveredEarningsType;
                classPlan.GSIBuyUpCoveredEarningsTypeNotes = sourcePDRClass.GSIBuyUpCoveredEarningsTypeNotes;
                classPlan.ReplacementPercentage = sourcePDRClass.ApprovedGSIBuyUpReplacementPercentage;
                classPlan.GSIBuyUpReplacementPercentageNotes = sourcePDRClass.GSIBuyUpReplacementPercentageNotes;
                classPlan.CoveredEarningsBonusOnlyType = sourcePDRClass.ApprovedGSIBuyUpCoveredEarningsBonusOnlyType;
                classPlan.IsOneStepEnrollmentIndicator = false;
            }
            else
            {
                classPlan.PDRClassPlanType = PDRClassPlanTypeEnum.Primary;
            }
            Log.TraceFormat("-CreateSoldClassPlan");

            return classPlan;
        }

        private PDRSoldClass CreateSoldClassRequest(PlanDesignRequest sourcePlanDesignRequest, PlanDesignRequestClass sourcePlanDesignClass)
        {
            PDRSoldClass soldClass = new PDRSoldClass
            {
                PlanDesignRequest = sourcePlanDesignRequest,
                PlanDesignRequestClass = sourcePlanDesignClass,
                EligiblePopulationText = sourcePlanDesignClass.ApprovedEligiblePopulationText,
                EligiblePopulationTextNotes = sourcePlanDesignClass.EligiblePopulationTextNotes,
                IsActive = true
            };
            soldClass.PDRSoldClassLTDCoverage = sourcePlanDesignClass.PlanDesignRequestClassLTDCoverage.Select(
                                                l => new PDRSoldClassLTDCoverage
                                                {
                                                    PDRSoldClass = soldClass,
                                                    AdditionalDetailsText = l.AdditionalDetailsText,
                                                    BenefitPeriodDays = l.BenefitPeriodDays,
                                                    CarrierText = l.CarrierText,
                                                    EligiblePopulationText = l.EligiblePopulationText,
                                                    EliminationPeriodDays = l.EliminationPeriodDays,
                                                    GroupLTDCapAmount = l.GroupLTDCapAmount,
                                                    GroupLTDCoveredEarningsType = l.GroupLTDCoveredEarningsType,
                                                    GroupLTDCoveredEarningsType_Other = l.GroupLTDCoveredEarningsType_Other,
                                                    GroupLTDReplacementPercentage = l.GroupLTDReplacementPercentage,
                                                    IsLTDPlanExistingIndicator = l.IsLTDPlanExistingIndicator,
                                                    IsVoluntaryLTDBuyUpIndicator = l.IsVoluntaryLTDBuyUpIndicator,
                                                    LTDBuyUpCoveredEarningsType = l.LTDBuyUpCoveredEarningsType,
                                                    LTDBuyUpCoveredEarningsType_Other = l.LTDBuyUpCoveredEarningsType_Other,
                                                    LTDBuyUpLTDCapAmount = l.LTDBuyUpLTDCapAmount,
                                                    LTDBuyUpReplacementPercentage = l.LTDBuyUpReplacementPercentage,
                                                    PremiumAndTaxpayerLiabilityType = l.PremiumAndTaxpayerLiabilityType,
                                                    TypeOfPayType = l.TypeOfPayType,
                                                    BaseSalaryPercentage = l.BaseSalaryPercentage ?? null,
                                                    BonusNumberofYears = l.BonusNumberofYears ?? null,
                                                    BonusPercentage = l.BonusPercentage ?? null,
                                                    CommissionNumberofYears = l.CommissionNumberofYears ?? null,
                                                    CommissionPercentage = l.CommissionPercentage ?? null,
                                                    K1EarningsNumberofYears = l.K1EarningsNumberofYears ?? null,
                                                    K1EarningsPercentage = l.K1EarningsPercentage ?? null,
                                                    OtherIncomePercentage = l.OtherIncomePercentage ?? null
                                                }).ToList();

            soldClass.PDRSoldClassCompanyRetirementPlan = sourcePlanDesignClass.CaseCompanyRetirementPlan.
                                            Select(l => new PDRSoldClassCompanyRetirementPlan
                                            {
                                                PDRSoldClass = soldClass,
                                                CompanyRetirementPlanType = l.CompanyRetirementPlanType,
                                                CompanyRetirementPlanType_Other = l.CompanyRetirementPlanType_Other,
                                                IsChecked = l.IsChecked,
                                            }).ToList();

            return soldClass;
        }

        private IList<CaseCompanyRetirementPlanDto> GetPDRSoldClassCompanyRetirementPlan(int pdrSoldClassId)
        {
            Log.TraceFormat("+GetPDRSoldClassCompanyRetirementPlan");
            var caseCompanyRetirementPlanDto = new List<CaseCompanyRetirementPlanDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrSoldClassCompanyRetirementPlan = unitOfWork.Repository<PDRSoldClassCompanyRetirementPlan>().Linq().Where(c => c.PDRSoldClass.Id == pdrSoldClassId).ToList();
                caseCompanyRetirementPlanDto = pdrSoldClassCompanyRetirementPlan.Select(c => new CaseCompanyRetirementPlanDto
                {
                    CaseCompanyRetirementPlanId = c.Id,
                    PlanDesignRequestClassId = c.PDRSoldClass.Id,
                    CompanyRetirementPlanTypeId = c.CompanyRetirementPlanType != null ? (int?)c.CompanyRetirementPlanType.Id : null,
                    IsChecked = c.IsChecked
                }).ToList();
            }
            Log.TraceFormat("-GetPDRSoldClassCompanyRetirementPlan");
            return caseCompanyRetirementPlanDto;
        }

        public PlanDesignRequestClassDto GetSoldPlanDesignRequestClass(int pdrSoldClassId)
        {
            Log.TraceFormat("+GetSoldPlanDesignRequestClass");

            var planDesignRequestClassDto = new PlanDesignRequestClassDto();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                // var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.Id == pdrSoldClassId && c.IsActive);
                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.Id == pdrSoldClassId);
                if (pdrSoldClass != null)
                {
                    var planDesignRequestClassProductsList = new List<PlanDesignRequestClassProductDto>();
                    var planDesignRequestClassRidersList = new List<PlanDesignRequestClassRiderDto>();
                    var pdrClassCustomizedIDIInsurableIncomeList = new List<PDRClassCustomizedIDIInsurableIncomeDto>();
                    planDesignRequestClassDto.PlanDesignRequestId = pdrSoldClass.PlanDesignRequest.Id;
                    planDesignRequestClassDto.PlanDesignRequestClassId = pdrSoldClass.Id;
                    planDesignRequestClassDto.IsActive = pdrSoldClass.PlanDesignRequestClass.IsActive;
                    planDesignRequestClassDto.ApprovedEligiblePopulationText = pdrSoldClass.EligiblePopulationText;
                    planDesignRequestClassDto.EligiblePopulationTextNotes = pdrSoldClass.EligiblePopulationTextNotes;
                    var primaryPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    var buyUpPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                    if (buyUpPlan != null)
                    {
                        planDesignRequestClassDto.IsApprovedVoluntaryGSIBuyUpPlan = true;
                        planDesignRequestClassDto.VoluntaryGSIBuyUpPlanNotes = buyUpPlan.GSIBuyUpPlanNotes;
                        planDesignRequestClassDto.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId = (int?)buyUpPlan.PlanDesignType;
                        planDesignRequestClassDto.VoluntaryGSIBuyUpPlanDesignNotes = buyUpPlan.GSIBuyUpPlanDesignNotes;
                        planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId = (int?)buyUpPlan.CoveredEarningsBonusOnlyType;
                        planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId = (int?)buyUpPlan.CoveredEarningsType;
                        planDesignRequestClassDto.GSIBuyUpCoveredEarningsTypeNotes = buyUpPlan.GSIBuyUpCoveredEarningsTypeNotes;
                        planDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage = buyUpPlan.ReplacementPercentage;
                        planDesignRequestClassDto.GSIBuyUpReplacementPercentageNotes = buyUpPlan.GSIBuyUpReplacementPercentageNotes;

                        //GSIBuyUp Products
                        var planDesignRequestClassProducts = new PlanDesignRequestClassProductDto();
                        planDesignRequestClassProducts.EliminationPeriodTypeId = (buyUpPlan.EliminationPeriod != null) ? (int?)buyUpPlan.EliminationPeriod : null;
                        planDesignRequestClassProducts.BenefitPeriodTypeId = buyUpPlan.BenefitPeriod != null ? (int?)buyUpPlan.BenefitPeriod : null;
                        planDesignRequestClassProducts.GSIAmount = buyUpPlan.GSIAmount;
                        planDesignRequestClassProducts.MinimumCaseLevelGSIAmount = (buyUpPlan.MinimumCaseLevelGSIAmount == 0 || buyUpPlan.MinimumCaseLevelGSIAmount == null) ? defaultMinimumGSIAmount: buyUpPlan.MinimumCaseLevelGSIAmount;
                        planDesignRequestClassProducts.TotalMaxGSIAmount = buyUpPlan.TotalMaxGSIAmount;
                        planDesignRequestClassProducts.ParticipationPercentage = buyUpPlan.ParticipationPercentage;
                        //planDesignRequestClassProducts.PDRDiscountTypeId = buyUpPlan.PDRDiscountType != null ? buyUpPlan.PDRDiscountType.Id : 0; TODO-Joshua

                        planDesignRequestClassProducts.BaseDiscountTypeId = buyUpPlan.BaseDiscountType != null ? (int?)buyUpPlan.BaseDiscountType.Id : null;
                        planDesignRequestClassProducts.DemographicDiscountTypeId = buyUpPlan.DemographicDiscountType != null ? (int?)buyUpPlan.DemographicDiscountType.Id : null;

                        planDesignRequestClassProducts.EmployerPaidDiscountTypeId = buyUpPlan.EmployerPaidDiscountType != null ? (int?)buyUpPlan.EmployerPaidDiscountType.Id : null;


                        planDesignRequestClassProducts.DiscountOverride = buyUpPlan.DiscountOverride != null ? buyUpPlan.DiscountOverride.GetValueOrDefault() : false;
                        planDesignRequestClassProducts.PreExistingConditionLimitTypeId = (int)buyUpPlan.PreExistingConditionLimitType;
                        planDesignRequestClassProducts.MentalSubstanceLimitationTypeId = (int)buyUpPlan.MentalSubstanceLimitationType;
                        planDesignRequestClassProducts.DefinitionOfDisabilityTypeId = (int)buyUpPlan.DefinitionOfDisabilityType;
                        planDesignRequestClassProducts.IsGSIPlanIndicator = true;
                        planDesignRequestClassProductsList.Add(planDesignRequestClassProducts);

                        //GSIBuyUp Riders
                        var buyUpPlanRiders = buyUpPlan.PDRSoldClassPlanRiders
                                .Select(p => new PlanDesignRequestClassRiderDto
                                {
                                    PlanDesignRequestClassRiderId = p.Id,
                                    PlanDesignRequestClassId = pdrSoldClass.Id,
                                    SelectedBenefitGroup = (int)p.BenefitGroupType,
                                    SelectedBenefitType = (int)p.BenefitType,
                                    SelectedEliminationPeriod = p.EliminationPeriodType != null ? (int?)p.EliminationPeriodType : null,
                                    SelectedBenefitPeriod = p.BenefitPeriodType != null ? (int?)p.BenefitPeriodType : null,
                                    ApprovedAmount = p.ApprovedAmount,
                                    IsGSIPlanIndicator = true
                                }).ToList();

                        planDesignRequestClassRidersList.AddRange(buyUpPlanRiders);

                        var pdrSoldClassPlanCustomizedIDIInsurableIncome = unitOfWork.Repository<PDRSoldClassPlanCustomizedIDIInsurableIncome>().Linq().FirstOrDefault(c => c.PDRSoldClassPlan.Id == buyUpPlan.Id);

                        if (pdrSoldClassPlanCustomizedIDIInsurableIncome != null)
                        {
                            var pdrClassCustomizedIDIInsurableIncomeDto = new PDRClassCustomizedIDIInsurableIncomeDto();
                            pdrClassCustomizedIDIInsurableIncomeDto.PDRSoldClassId = pdrSoldClassId;
                            pdrClassCustomizedIDIInsurableIncomeDto.PDRSoldClassPlanCustomizedIDIInsurableIncomeId = pdrSoldClassPlanCustomizedIDIInsurableIncome.Id;
                            pdrClassCustomizedIDIInsurableIncomeDto.BaseSalaryPercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.BaseSalaryPercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.BonusPercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.BonusPercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.CommissionPercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.CommissionPercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.OtherIncomePercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.OtherIncomePercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.K1EarningsPercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.K1EarningsPercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.BonusNumberofYears = pdrSoldClassPlanCustomizedIDIInsurableIncome.BonusNumberofYears;
                            pdrClassCustomizedIDIInsurableIncomeDto.CommissionNumberofYears = pdrSoldClassPlanCustomizedIDIInsurableIncome.CommissionNumberofYears;
                            pdrClassCustomizedIDIInsurableIncomeDto.K1EarningsNumberofYears = pdrSoldClassPlanCustomizedIDIInsurableIncome.K1EarningsNumberofYears;
                            pdrClassCustomizedIDIInsurableIncomeDto.IsGSIPlanIndicator = true;
                            pdrClassCustomizedIDIInsurableIncomeDto.IsSold = true;
                            pdrClassCustomizedIDIInsurableIncomeList.Add(pdrClassCustomizedIDIInsurableIncomeDto);
                        }

                    }
                    else
                    {
                        planDesignRequestClassDto.IsApprovedVoluntaryGSIBuyUpPlan = false;
                    }

                    if (primaryPlan != null)
                    {
                        planDesignRequestClassDto.ApprovedPlanDesignTypeId = (int?)primaryPlan.PlanDesignType;
                        planDesignRequestClassDto.PlanDesignNotes = primaryPlan.PlanDesignNotes;
                        planDesignRequestClassDto.ApprovedBenefitPeriodTypeId = primaryPlan.BenefitPeriod != null ? (int?)primaryPlan.BenefitPeriod : null;
                        planDesignRequestClassDto.BenefitPeriodNotes = primaryPlan.BenefitPeriodNotes;
                        planDesignRequestClassDto.ApprovedEliminationPeriodTypeId = (primaryPlan.EliminationPeriod != null) ? (int?)primaryPlan.EliminationPeriod : null;
                        planDesignRequestClassDto.EliminationPeriodNotes = primaryPlan.EliminationPeriodNotes;
                        planDesignRequestClassDto.ApprovedLTDPercentage = primaryPlan.LTDPercentage;
                        planDesignRequestClassDto.LTDPercentageNotes = primaryPlan.LTDPercentageNotes;
                        planDesignRequestClassDto.ApprovedIDIPercentage = primaryPlan.IDIPercentage;
                        planDesignRequestClassDto.IDIPercentageNotes = primaryPlan.IDIPercentageNotes;
                        planDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId = (primaryPlan.PremiumPayerAndTaxabilityType != null) ? (int?)primaryPlan.PremiumPayerAndTaxabilityType.Id : null;
                        planDesignRequestClassDto.PremiumPayerAndTaxabilityNotes = primaryPlan.PremiumPayerAndTaxabilityNotes;
                        planDesignRequestClassDto.ApprovedMaximumReplacementRatio = primaryPlan.MaximumReplacementRatio;
                        planDesignRequestClassDto.MaximumReplacementRatioNotes = primaryPlan.MaximumReplacementRatioNotes;
                        planDesignRequestClassDto.ApprovedLTDCoversNext = primaryPlan.LTDCoversNext;
                        planDesignRequestClassDto.LTDCoversNextNotes = primaryPlan.LTDCoversNextNotes;
                        planDesignRequestClassDto.ApprovedIDICovers1st = primaryPlan.IDICovers1st;
                        planDesignRequestClassDto.IDICovers1stNotes = primaryPlan.IDICovers1stNotes;
                        planDesignRequestClassDto.ApprovedCoveredEarningsTypeId = primaryPlan.CoveredEarningsType != null ? (int?)primaryPlan.CoveredEarningsType : null;
                        planDesignRequestClassDto.CoveredEarningsTypeNotes = primaryPlan.CoveredEarningsTypeNotes;
                        planDesignRequestClassDto.ApprovedFlatRateType_Id = primaryPlan.FlatRateType != null ? primaryPlan.FlatRateType.Id : 0;
                        planDesignRequestClassDto.ApprovedFlatRate_Other = primaryPlan.FlatRate_Other;
                        planDesignRequestClassDto.ApprovedRetirementContributionsTypeId = primaryPlan.RetirementContributionsType != null ? (int?)primaryPlan.RetirementContributionsType : null;
                        planDesignRequestClassDto.RetirementContributionNotes = primaryPlan.RetirementContributionsNotes;
                        planDesignRequestClassDto.ApprovedAnnualContributions = primaryPlan.AnnualContributions;
                        planDesignRequestClassDto.AnnualContributionsNotes = primaryPlan.AnnualContributionsNotes;
                        planDesignRequestClassDto.ApprovedCoveredEarningsPercentage = primaryPlan.CoveredEarningsPercentage;
                        planDesignRequestClassDto.CoveredEarningsPercentageNotes = primaryPlan.CoveredEarningsPercentageNotes;
                        planDesignRequestClassDto.ApprovedRppRiderCoveredEarningsTypeId = primaryPlan.RppRiderCoveredEarningsType != null ? (int?)primaryPlan.RppRiderCoveredEarningsType : null;
                        planDesignRequestClassDto.RppRiderCoveredEarningsTypeNotes = primaryPlan.RppRiderCoveredEarningsTypeNotes;
                        planDesignRequestClassDto.ApprovedTaxabilityTypeId = primaryPlan.TaxabilityType != null ? (int?)primaryPlan.TaxabilityType : null;
                        planDesignRequestClassDto.TaxabilityTypeNotes = primaryPlan.TaxabilityTypeNotes;
                        planDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId = (primaryPlan.CoveredEarningsBonusOnlyType != null) ? (int?)primaryPlan.CoveredEarningsBonusOnlyType : null;
                        planDesignRequestClassDto.ApprovedTypeOfShareTypeId = (primaryPlan.TypeOfShareType != null) ? (int?)primaryPlan.TypeOfShareType : null;
                        planDesignRequestClassDto.ApprovedEmployerPaidPremium = primaryPlan.EmployerPaidPremium;
                        planDesignRequestClassDto.EmployerPaidPremiumNotes = primaryPlan.EmployerPaidPremiumNotes;
                        planDesignRequestClassDto.ApprovedEmployeePaidPremium = primaryPlan.EmployeePaidPremium;
                        planDesignRequestClassDto.ApprovedEmployerPaysupto = primaryPlan.EmployerPaysupto;
                        planDesignRequestClassDto.EmployerPaysuptoNotes = primaryPlan.EmployerPaysuptoNotes;
                        planDesignRequestClassDto.ApprovedCostShareTaxabilityTypeId = primaryPlan.CostShareTaxabilityType != null ? primaryPlan.CostShareTaxabilityType.Id : 0;
                        planDesignRequestClassDto.VoluntaryGSIBuyUpPlanNotes = primaryPlan.GSIBuyUpPlanNotes;

                        //PrimaryPlan products
                        var planDesignRequestClassProducts = new PlanDesignRequestClassProductDto();
                        planDesignRequestClassProducts.GSIAmount = primaryPlan.GSIAmount;
                        planDesignRequestClassProducts.MinimumCaseLevelGSIAmount = (primaryPlan.MinimumCaseLevelGSIAmount == 0 || primaryPlan.MinimumCaseLevelGSIAmount == null ) ? defaultMinimumGSIAmount : primaryPlan.MinimumCaseLevelGSIAmount;
                        planDesignRequestClassProducts.ParticipationPercentage = primaryPlan.ParticipationPercentage;
                        //planDesignRequestClassProducts.PDRDiscountTypeId = primaryPlan.PDRDiscountType != null ? primaryPlan.PDRDiscountType.Id : 0; TODO-Joshua
                        planDesignRequestClassProducts.PreExistingConditionLimitTypeId = (int)primaryPlan.PreExistingConditionLimitType;
                        planDesignRequestClassProducts.MentalSubstanceLimitationTypeId = (int)primaryPlan.MentalSubstanceLimitationType;
                        planDesignRequestClassProducts.DefinitionOfDisabilityTypeId = (int)primaryPlan.DefinitionOfDisabilityType;
                        planDesignRequestClassProducts.IsGSIPlanIndicator = false;
                        planDesignRequestClassProducts.BaseDiscountTypeId = (primaryPlan.BaseDiscountType != null) ? (int?)primaryPlan.BaseDiscountType.Id : null;
                        planDesignRequestClassProducts.DemographicDiscountTypeId = (primaryPlan.DemographicDiscountType != null) ? (int?)primaryPlan.DemographicDiscountType.Id : null;


                        planDesignRequestClassProducts.EmployerPaidDiscountTypeId = (primaryPlan.EmployerPaidDiscountType != null) ? (int?)primaryPlan.EmployerPaidDiscountType.Id : null;


                        planDesignRequestClassProducts.DiscountOverride = primaryPlan.DiscountOverride != null ? primaryPlan.DiscountOverride.GetValueOrDefault() : false;
                        planDesignRequestClassProducts.IsOneStepEnrollmentIndicator = primaryPlan.IsOneStepEnrollmentIndicator;
                        planDesignRequestClassProducts.IsDirectCoverageIndicator = primaryPlan.IsDirectCoverageIndicator;
                        planDesignRequestClassProductsList.Add(planDesignRequestClassProducts);

                        //PrimaryPlan Riders
                        var primaryPlanRiders = primaryPlan.PDRSoldClassPlanRiders
                                .Select(p => new PlanDesignRequestClassRiderDto
                                {
                                    PlanDesignRequestClassRiderId = p.Id,
                                    PlanDesignRequestClassId = pdrSoldClass.Id,
                                    SelectedBenefitGroup = (int)p.BenefitGroupType,
                                    SelectedBenefitType = (int)p.BenefitType,
                                    SelectedEliminationPeriod = p.EliminationPeriodType != null ? (int?)p.EliminationPeriodType : null,
                                    SelectedBenefitPeriod = p.BenefitPeriodType != null ? (int?)p.BenefitPeriodType : null,
                                    ApprovedAmount = p.ApprovedAmount,
                                    IsGSIPlanIndicator = false
                                }).ToList();

                        planDesignRequestClassRidersList.AddRange(primaryPlanRiders);

                        var pdrSoldClassPlanCustomizedIDIInsurableIncome = unitOfWork.Repository<PDRSoldClassPlanCustomizedIDIInsurableIncome>().Linq().FirstOrDefault(c => c.PDRSoldClassPlan.Id == primaryPlan.Id);

                        if (pdrSoldClassPlanCustomizedIDIInsurableIncome != null)
                        {
                            var pdrClassCustomizedIDIInsurableIncomeDto = new PDRClassCustomizedIDIInsurableIncomeDto();
                            pdrClassCustomizedIDIInsurableIncomeDto.PDRSoldClassId = pdrSoldClassId;
                            pdrClassCustomizedIDIInsurableIncomeDto.PDRSoldClassPlanCustomizedIDIInsurableIncomeId = pdrSoldClassPlanCustomizedIDIInsurableIncome.Id;
                            pdrClassCustomizedIDIInsurableIncomeDto.BaseSalaryPercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.BaseSalaryPercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.BonusPercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.BonusPercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.CommissionPercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.CommissionPercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.OtherIncomePercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.OtherIncomePercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.K1EarningsPercentage = pdrSoldClassPlanCustomizedIDIInsurableIncome.K1EarningsPercentage;
                            pdrClassCustomizedIDIInsurableIncomeDto.BonusNumberofYears = pdrSoldClassPlanCustomizedIDIInsurableIncome.BonusNumberofYears;
                            pdrClassCustomizedIDIInsurableIncomeDto.CommissionNumberofYears = pdrSoldClassPlanCustomizedIDIInsurableIncome.CommissionNumberofYears;
                            pdrClassCustomizedIDIInsurableIncomeDto.K1EarningsNumberofYears = pdrSoldClassPlanCustomizedIDIInsurableIncome.K1EarningsNumberofYears;
                            pdrClassCustomizedIDIInsurableIncomeDto.IsGSIPlanIndicator = false;
                            pdrClassCustomizedIDIInsurableIncomeDto.IsSold = true;
                            pdrClassCustomizedIDIInsurableIncomeList.Add(pdrClassCustomizedIDIInsurableIncomeDto);
                        }
                    }

                    planDesignRequestClassDto.PlanDesignRequestClassRiders = planDesignRequestClassRidersList;
                    planDesignRequestClassDto.PlanDesignRequestClassProducts = planDesignRequestClassProductsList;
                    planDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes = pdrClassCustomizedIDIInsurableIncomeList;
                    planDesignRequestClassDto.CaseCompanyRetirementPlans = GetPDRSoldClassCompanyRetirementPlan(pdrSoldClassId);
                    planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage = pdrSoldClass.PDRSoldClassLTDCoverage
                        .Select(p => new PlanDesignRequestClassLTDCoverageDto
                        {
                            PlanDesignRequestClassLTDCoverageId = p.Id,
                            PlanDesignRequestClassId = p.PDRSoldClass.PlanDesignRequestClass.Id,
                            PDRSoldClassId = p.PDRSoldClass.Id,
                            EligiblePopulationText = p.EligiblePopulationText,
                            CarrierText = p.CarrierText,
                            EliminationPeriodDays = p.EliminationPeriodDays,
                            BenefitPeriodDays = p.BenefitPeriodDays,
                            GroupLTDReplacementPercentage = p.GroupLTDReplacementPercentage,
                            GroupLTDCapAmount = p.GroupLTDCapAmount,
                            GroupLTDCoveredEarningsTypeId = (int)p.GroupLTDCoveredEarningsType,
                            PremiumAndTaxpayerLiabilityTypeId = p.PremiumAndTaxpayerLiabilityType.Id,
                            TypeOfPayTypeId = p.TypeOfPayType != null ? (int?)p.TypeOfPayType : null,
                            IsVoluntaryLTDBuyUpIndicator = p.IsVoluntaryLTDBuyUpIndicator,
                            LTDBuyUpReplacementPercentage = p.LTDBuyUpReplacementPercentage,
                            LTDBuyUpLTDCapAmount = p.LTDBuyUpLTDCapAmount,
                            LTDBuyUpCoveredEarningsTypeId = p.LTDBuyUpCoveredEarningsType != null ? (int?)p.LTDBuyUpCoveredEarningsType : null,
                            IsLTDPlanExistingIndicator = p.IsLTDPlanExistingIndicator,
                            AdditionalDetailsText = p.AdditionalDetailsText,
                            BaseSalaryPercentage = p.BaseSalaryPercentage ?? null,
                            BonusNumberofYears = p.BonusNumberofYears ?? null,
                            BonusPercentage = p.BonusPercentage ?? null,
                            CommissionNumberofYears = p.CommissionNumberofYears ?? null,
                            CommissionPercentage = p.CommissionPercentage ?? null,
                            K1EarningsNumberofYears = p.K1EarningsNumberofYears ?? null,
                            K1EarningsPercentage = p.K1EarningsPercentage ?? null,
                            OtherIncomePercentage = p.OtherIncomePercentage ?? null,
                            IsLTDIncomes = true,
                            IsSold = true
                        }).FirstOrDefault();
                    planDesignRequestClassDto.EligibilityConfiguration = _planDesignRequestGetter.GetEligibiltyConfiguration(pdrSoldClass.PlanDesignRequestClass.Id, planDesignRequestClassDto.PlanDesignRequestId);
                    planDesignRequestClassDto.DefaultEligibilityConfiguration = _planDesignRequestGetter.GetDefaultEligibiltyConfiguration();
                }
            }
            Log.TraceFormat("-GetSoldPlanDesignRequestClass");
            return planDesignRequestClassDto;
        }

        public PlanDesignRequestClassDto GetSoldIllustrationPlanDesignRequestClass(int planDesignRequestClassId)
        {
            Log.TraceFormat("+GetSoldIllustrationPlanDesignRequestClass");

            var planDesignRequestClassDto = new PlanDesignRequestClassDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignSoldRequestClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassId && c.IsActive);

                var planDesignRequestClassProductsList = new List<PlanDesignRequestClassProductDto>();
                var planDesignRequestClassRidersList = new List<PlanDesignRequestClassRiderDto>();
                if (planDesignSoldRequestClass != null)
                {
                    planDesignRequestClassDto.IsSold = true;
                    planDesignRequestClassDto.PlanDesignRequestId = planDesignSoldRequestClass.PlanDesignRequest.Id;
                    planDesignRequestClassDto.PlanDesignRequestClassId = planDesignSoldRequestClass.PlanDesignRequestClass.Id;
                    planDesignRequestClassDto.PlanDesignRequestClassName = planDesignSoldRequestClass.PlanDesignRequestClass.PlanDesignRequestClassName;

                    var primaryPlan = planDesignSoldRequestClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    if (primaryPlan != null)
                    {
                        planDesignRequestClassDto.ApprovedPlanDesignTypeId = primaryPlan.PlanDesignType != null ? (int?)primaryPlan.PlanDesignType : null;
                        planDesignRequestClassDto.ApprovedMaximumReplacementRatio = primaryPlan.MaximumReplacementRatio;
                        planDesignRequestClassDto.ApprovedBenefitPeriodTypeId = primaryPlan.BenefitPeriod != null ? (int?)primaryPlan.BenefitPeriod : null;
                        planDesignRequestClassDto.ApprovedEliminationPeriodTypeId = primaryPlan.EliminationPeriod != null ? (int?)primaryPlan.EliminationPeriod : null;

                        var planDesignRequestClassProductDto = new PlanDesignRequestClassProductDto
                        {
                            PlanDesignRequestClassProductId = primaryPlan.Id,
                            PlanDesignRequestClassId = planDesignSoldRequestClass.Id,
                            GSIAmount = primaryPlan.GSIAmount,
                            MinimumCaseLevelGSIAmount=(primaryPlan.MinimumCaseLevelGSIAmount ==0 || primaryPlan.MinimumCaseLevelGSIAmount== null) ? defaultMinimumGSIAmount:primaryPlan.MinimumCaseLevelGSIAmount,
                            //PDRDiscountTypeId = (primaryPlan.PDRDiscountType != null) ? primaryPlan.PDRDiscountType.Id : 0, TODO-Joshua
                            BaseDiscountTypeId = (primaryPlan.BaseDiscountType != null) ? (int?)primaryPlan.BaseDiscountType.Id : null,
                            DemographicDiscountTypeId = (primaryPlan.DemographicDiscountType != null) ? (int?)primaryPlan.DemographicDiscountType.Id : null,

                            EmployerPaidDiscountTypeId = (primaryPlan.EmployerPaidDiscountType != null) ? (int?)primaryPlan.EmployerPaidDiscountType.Id : null,
                            

                            ParticipationPercentage = primaryPlan.ParticipationPercentage,
                            DefinitionOfDisabilityTypeId = (int)primaryPlan.DefinitionOfDisabilityType,
                            MentalSubstanceLimitationTypeId = (int)primaryPlan.MentalSubstanceLimitationType,
                            PreExistingConditionLimitTypeId = (int)primaryPlan.PreExistingConditionLimitType,
                            EliminationPeriodTypeId = (int?)primaryPlan.EliminationPeriod,
                            BenefitPeriodTypeId = (int?)primaryPlan.BenefitPeriod,
                            IsGSIPlanIndicator = false
                        };
                        planDesignRequestClassProductsList.Add(planDesignRequestClassProductDto);

                        var primaryPlanRiders = primaryPlan.PDRSoldClassPlanRiders
                               .Select(p => new PlanDesignRequestClassRiderDto
                               {
                                   PlanDesignRequestClassRiderId = p.Id,
                                   PlanDesignRequestClassId = planDesignSoldRequestClass.Id,
                                   SelectedBenefitGroup = (int)p.BenefitGroupType,
                                   SelectedBenefitType = (int)p.BenefitType,
                                   SelectedEliminationPeriod = p.EliminationPeriodType != null ? (int?)p.EliminationPeriodType : null,
                                   SelectedBenefitPeriod = p.BenefitPeriodType != null ? (int?)p.BenefitPeriodType : null,
                                   ApprovedAmount = p.ApprovedAmount,
                                   IsGSIPlanIndicator = false
                               })
                               .ToList();
                        planDesignRequestClassRidersList.AddRange(primaryPlanRiders);
                    }

                    var buyUpPlan = planDesignSoldRequestClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                    if (buyUpPlan != null)
                    {
                        planDesignRequestClassDto.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId = buyUpPlan.PlanDesignType != null ? (int?)buyUpPlan.PlanDesignType : null;
                        planDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage = buyUpPlan.ReplacementPercentage;

                        var planDesignRequestClassProductDto = new PlanDesignRequestClassProductDto
                        {
                            PlanDesignRequestClassProductId = buyUpPlan.Id,
                            PlanDesignRequestClassId = planDesignSoldRequestClass.Id,
                            GSIAmount = buyUpPlan.GSIAmount,
                            MinimumCaseLevelGSIAmount = (buyUpPlan.MinimumCaseLevelGSIAmount == 0 || buyUpPlan.MinimumCaseLevelGSIAmount == null) ? defaultMinimumGSIAmount: buyUpPlan.MinimumCaseLevelGSIAmount,
                            TotalMaxGSIAmount = buyUpPlan.TotalMaxGSIAmount,
                            //PDRDiscountTypeId = (buyUpPlan.PDRDiscountType != null) ? buyUpPlan.PDRDiscountType.Id : 0, TODO-Joshua
                            BaseDiscountTypeId = (buyUpPlan.BaseDiscountType != null) ? (int?)buyUpPlan.BaseDiscountType.Id : null,
                            DemographicDiscountTypeId = (buyUpPlan.DemographicDiscountType != null) ? (int?)buyUpPlan.DemographicDiscountType.Id : null,


                            EmployerPaidDiscountTypeId = (buyUpPlan.EmployerPaidDiscountType != null) ? (int?)buyUpPlan.EmployerPaidDiscountType.Id : null,



                            ParticipationPercentage = buyUpPlan.ParticipationPercentage,
                            DefinitionOfDisabilityTypeId = (int)buyUpPlan.DefinitionOfDisabilityType,
                            MentalSubstanceLimitationTypeId = (int)buyUpPlan.MentalSubstanceLimitationType,
                            PreExistingConditionLimitTypeId = (int)buyUpPlan.PreExistingConditionLimitType,
                            EliminationPeriodTypeId = (int)buyUpPlan.EliminationPeriod,
                            BenefitPeriodTypeId = (int)buyUpPlan.BenefitPeriod,
                            IsGSIPlanIndicator = true
                        };
                        planDesignRequestClassProductsList.Add(planDesignRequestClassProductDto);

                        var buyUpPlanRiders = buyUpPlan.PDRSoldClassPlanRiders
                               .Select(p => new PlanDesignRequestClassRiderDto
                               {
                                   PlanDesignRequestClassRiderId = p.Id,
                                   PlanDesignRequestClassId = planDesignSoldRequestClass.Id,
                                   SelectedBenefitGroup = (int)p.BenefitGroupType,
                                   SelectedBenefitType = (int)p.BenefitType,
                                   SelectedEliminationPeriod = p.EliminationPeriodType != null ? (int?)p.EliminationPeriodType : null,
                                   SelectedBenefitPeriod = p.BenefitPeriodType != null ? (int?)p.BenefitPeriodType : null,
                                   ApprovedAmount = p.ApprovedAmount,
                                   IsGSIPlanIndicator = true
                               })
                               .ToList();
                        planDesignRequestClassRidersList.AddRange(buyUpPlanRiders);
                    }

                    planDesignRequestClassDto.PlanDesignRequestClassRiders = planDesignRequestClassRidersList;
                    planDesignRequestClassDto.PlanDesignRequestClassProducts = planDesignRequestClassProductsList;
                }
            }

            Log.TraceFormat("-GetSoldIllustrationPlanDesignRequestClass");
            return planDesignRequestClassDto;
        }

        public List<PlanDesignRequestClassDto> GetSoldPlanDesignRequestClassHeaders(int planDesignRequestId)
        {
            Log.TraceFormat("+GetSoldPlanDesignRequestClassHeaders");

            var soldPlanDesignRequestClassDtos = new List<PlanDesignRequestClassDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignSoldRequestClassses = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Id == planDesignRequestId && c.IsActive == true).ToList();
                if (planDesignSoldRequestClassses == null) return soldPlanDesignRequestClassDtos;

                int caseId = planDesignSoldRequestClassses.Select(i => i.PlanDesignRequest.Case.Id).FirstOrDefault();
                var participants = unitOfWork.Repository<Participant>().LinqWithTimeOut().Where(i => i.Census.Case.Id == caseId && (i.IsError == false || i.IsError == null) && (i.IsEligible == true || i.IsEligible == null) && i.IsActive == true);

                foreach (var planDesignSoldRequestClass in planDesignSoldRequestClassses)
                {
                    var primaryPlan = planDesignSoldRequestClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);

                    int participantCount = participants != null ? participants.Where(i => i.PlanDesignRequestClass.Id == planDesignSoldRequestClass.PlanDesignRequestClass.Id).Count() : 0;

                    if (primaryPlan != null)
                    {
                        var planDesignRequestClassDto = new PlanDesignRequestClassDto
                        {
                            PlanDesignRequestId = planDesignSoldRequestClass.PlanDesignRequest.Id,
                            IsSold = true,
                            PlanDesignRequestClassId = planDesignSoldRequestClass.Id,
                            //EligibleParticipantsCount = (planDesignSoldRequestClass.PlanDesignRequestClass.CensusParticipants != null) ? planDesignSoldRequestClass.PlanDesignRequestClass.CensusParticipants.Count(p => (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null)) : 0,
                            EligibleParticipantsCount = participantCount,
                            PlanDesignRequestClassName = planDesignSoldRequestClass.PlanDesignRequestClass.PlanDesignRequestClassName,
                            ApprovedEligiblePopulationText = planDesignSoldRequestClass.EligiblePopulationText,
                            ApprovedPremiumPayerAndTaxabilityTypeId = primaryPlan.PremiumPayerAndTaxabilityType != null ? (int?)primaryPlan.PremiumPayerAndTaxabilityType.Id : null,
                            IsActive = planDesignSoldRequestClass.PlanDesignRequestClass.IsActive,
                            IsApprovedVoluntaryGSIBuyUpPlan = false
                        };

                        var planDesignRequestClassProductDto = new PlanDesignRequestClassProductDto
                        {
                            PlanDesignRequestClassProductId = primaryPlan.Id,
                            PlanDesignRequestClassId = planDesignSoldRequestClass.Id,
                            GSIAmount = primaryPlan.GSIAmount,
                            MinimumCaseLevelGSIAmount = (primaryPlan.MinimumCaseLevelGSIAmount == 0 || primaryPlan.MinimumCaseLevelGSIAmount == null) ? defaultMinimumGSIAmount: primaryPlan.MinimumCaseLevelGSIAmount,
                            BaseDiscountTypeId = (primaryPlan.BaseDiscountType != null) ? (int?)primaryPlan.BaseDiscountType.Id : null,
                            DemographicDiscountTypeId = (primaryPlan.DemographicDiscountType != null) ? (int?)primaryPlan.DemographicDiscountType.Id : null,

                            EmployerPaidDiscountTypeId = (primaryPlan.EmployerPaidDiscountType != null) ? (int?)primaryPlan.EmployerPaidDiscountType.Id : null,

                            ParticipationPercentage = primaryPlan.ParticipationPercentage,
                            IsGSIPlanIndicator = false
                        };
                        planDesignRequestClassDto.PlanDesignRequestClassProducts.Add(planDesignRequestClassProductDto);
                        soldPlanDesignRequestClassDtos.Add(planDesignRequestClassDto);
                    }
                }
            }
            Log.TraceFormat("-GetSoldPlanDesignRequestClassHeaders");
            return soldPlanDesignRequestClassDtos;
        }

        public bool IsVoluntaryPremiumPayerClass(int caseId)
        {
            Log.TraceFormat("+IsVoluntaryPremiumPayerClass");

            bool isVoluntaryPremiumPayer = false;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrSoldClassPlans = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(e => e.PDRSoldClass.PlanDesignRequest.Case.Id == caseId
                && e.PDRClassPlanType == PDRClassPlanTypeEnum.Primary
                && (e.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare
                    || e.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable));

                if (pdrSoldClassPlans != null)
                {
                    if (pdrSoldClassPlans.Count() > 0)
                    {
                        isVoluntaryPremiumPayer = true;
                    }
                }
            }
            Log.TraceFormat("-IsVoluntaryPremiumPayerClass");
            return isVoluntaryPremiumPayer;
        }

        public void DeleteSoldPlanDesignRequestClass(int pdrSoldClassId)
        {
            Log.TraceFormat("+DeleteSoldPlanDesignRequestClass");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.Id == pdrSoldClassId);
                if (pdrSoldClass != null)
                {
                    unitOfWork.Repository<PDRSoldClass>().Delete(pdrSoldClass);
                    unitOfWork.Commit();

                    DeleteAssociatedPlanDesignRequestClass(pdrSoldClass.PlanDesignRequestClass.Id);
                }
            }
            Log.TraceFormat("-DeleteSoldPlanDesignRequestClass");
        }

        private void DeleteAssociatedPlanDesignRequestClass(int planDesignRequestClassId)
        {
            Log.TraceFormat("+DeleteAssociatedPlanDesignRequestClass");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsParticipant = unitOfWork.Repository<Participant>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId).ToList();
                if (cmsParticipant != null)
                {
                    foreach (var participant in cmsParticipant)
                    {
                        participant.PlanDesignRequestClass = null;
                        unitOfWork.Repository<Participant>().Save(participant);
                    }
                }

                var cmsEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId);
                if (cmsEligibilityConfiguration != null)
                {
                    unitOfWork.Repository<EligibilityConfiguration>().Delete(cmsEligibilityConfiguration);
                }

                var cmsEnrollmentPDRClass = unitOfWork.Repository<EnrollmentPDRClass>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId).ToList();
                if (cmsEnrollmentPDRClass.Any())
                {
                    foreach (var enrollmentPDRClass in cmsEnrollmentPDRClass)
                    {
                        enrollmentPDRClass.PlanDesignRequestClass = null;
                        unitOfWork.Repository<EnrollmentPDRClass>().Save(enrollmentPDRClass);
                    }
                }

                var cmsPlanDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassId);
                if (cmsPlanDesignRequestClass != null)
                {
                    cmsPlanDesignRequestClass.CensusParticipants = new List<Participant>();
                    unitOfWork.Repository<PlanDesignRequestClass>().Delete(cmsPlanDesignRequestClass);
                }

                unitOfWork.Commit();
            }
            Log.TraceFormat("-DeleteAssociatedPlanDesignRequestClass");
        }

        public void SoldPlanDesignRequestClassActivation(int soldPDRClassId)
        {
            Log.TraceFormat("+SoldPlanDesignRequestClassActivation");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsSoldPlanDesignRequestClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.Id == soldPDRClassId);
                if (cmsSoldPlanDesignRequestClass == null) return;

                cmsSoldPlanDesignRequestClass.IsActive = !cmsSoldPlanDesignRequestClass.IsActive;
                cmsSoldPlanDesignRequestClass.PlanDesignRequestClass.IsActive = !cmsSoldPlanDesignRequestClass.PlanDesignRequestClass.IsActive;

                if (cmsSoldPlanDesignRequestClass.PlanDesignRequestClass.CensusParticipants.Any())
                {
                    cmsSoldPlanDesignRequestClass.PlanDesignRequestClass.CensusParticipants.ToList().ForEach(c => { c.PlanDesignRequestClass = null; });
                }

                unitOfWork.Repository<PDRSoldClass>().Save(cmsSoldPlanDesignRequestClass);

                unitOfWork.Commit();
            }

            Log.TraceFormat("-SoldPlanDesignRequestClassActivation");
        }

        public void SoldPlanDesignRequestActivation(int planDesignRequestId)
        {
            Log.TraceFormat("+SoldPlanDesignRequestActivation");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsSoldPlanDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == planDesignRequestId);
                if (cmsSoldPlanDesignRequest == null) return;

                bool isActivePDR = !cmsSoldPlanDesignRequest.IsActive;
                unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.PlanDesignRequest.Id == cmsSoldPlanDesignRequest.Id).ToList().ForEach(c => { c.IsActive = isActivePDR; });

                unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Id == cmsSoldPlanDesignRequest.Id).ToList().ForEach(c => { c.IsActive = isActivePDR; });

                cmsSoldPlanDesignRequest.IsActive = isActivePDR;
                cmsSoldPlanDesignRequest.InactiveDate = DateTime.Now;

                unitOfWork.Repository<PlanDesignRequest>().Save(cmsSoldPlanDesignRequest);

                unitOfWork.Commit();
            }
            Log.TraceFormat("-SoldPlanDesignRequestActivation");
        }

        public List<PlanDesignRequestClassDto> GetSoldPlanDesignRequestClassHeadersForInactive(int planDesignRequestId)
        {
            Log.TraceFormat("+GetSoldPlanDesignRequestClassHeaders");

            var soldPlanDesignRequestClassDtos = new List<PlanDesignRequestClassDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignSoldRequestClassses = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Id == planDesignRequestId && c.IsActive == false).ToList();
                if (planDesignSoldRequestClassses == null) return soldPlanDesignRequestClassDtos;

                foreach (var planDesignSoldRequestClass in planDesignSoldRequestClassses)
                {
                    var primaryPlan = planDesignSoldRequestClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    if (primaryPlan != null)
                    {
                        var planDesignRequestClassDto = new PlanDesignRequestClassDto
                        {
                            PlanDesignRequestId = planDesignSoldRequestClass.PlanDesignRequest.Id,
                            IsSold = true,
                            PlanDesignRequestClassId = planDesignSoldRequestClass.Id,
                            EligibleParticipantsCount = (planDesignSoldRequestClass.PlanDesignRequestClass.CensusParticipants != null) ? planDesignSoldRequestClass.PlanDesignRequestClass.CensusParticipants.Count(p => (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null)) : 0,
                            PlanDesignRequestClassName = planDesignSoldRequestClass.PlanDesignRequestClass.PlanDesignRequestClassName,
                            ApprovedEligiblePopulationText = planDesignSoldRequestClass.EligiblePopulationText,
                            ApprovedPremiumPayerAndTaxabilityTypeId = primaryPlan.PremiumPayerAndTaxabilityType != null ? (int?)primaryPlan.PremiumPayerAndTaxabilityType.Id : null,
                            IsActive = planDesignSoldRequestClass.PlanDesignRequestClass.IsActive,
                            IsApprovedVoluntaryGSIBuyUpPlan = false
                        };

                        var planDesignRequestClassProductDto = new PlanDesignRequestClassProductDto
                        {
                            PlanDesignRequestClassProductId = primaryPlan.Id,
                            PlanDesignRequestClassId = planDesignSoldRequestClass.Id,
                            GSIAmount = primaryPlan.GSIAmount,
                            MinimumCaseLevelGSIAmount = (primaryPlan.MinimumCaseLevelGSIAmount == 0 || primaryPlan.MinimumCaseLevelGSIAmount == null)? defaultMinimumGSIAmount: primaryPlan.MinimumCaseLevelGSIAmount,
                            BaseDiscountTypeId = (primaryPlan.BaseDiscountType != null) ? (int?)primaryPlan.BaseDiscountType.Id : null,
                            DemographicDiscountTypeId = (primaryPlan.DemographicDiscountType != null) ? (int?)primaryPlan.DemographicDiscountType.Id : null,

                            EmployerPaidDiscountTypeId = (primaryPlan.EmployerPaidDiscountType != null) ? (int?)primaryPlan.EmployerPaidDiscountType.Id : null,

                            ParticipationPercentage = primaryPlan.ParticipationPercentage,
                            IsGSIPlanIndicator = false
                        };
                        planDesignRequestClassDto.PlanDesignRequestClassProducts.Add(planDesignRequestClassProductDto);
                        soldPlanDesignRequestClassDtos.Add(planDesignRequestClassDto);
                    }
                }
            }
            Log.TraceFormat("-GetSoldPlanDesignRequestClassHeaders");
            return soldPlanDesignRequestClassDtos;
        }
    }
}
