﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Interfaces.Managers.LookupManagers;
using CMS.Interfaces.Managers.OfferLetterManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Managers.BusinessManagers;
using Common.Exceptions;
using Common.Utilities;
using CMS.Interfaces.Managers.ITAdminManagers;

namespace CMS.Managers.PlanManagers
{
    public class PlanDesignRequestSaveSoldManager : IPlanDesignRequestSaveSoldManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IProductLibraryManager _productLibraryManager;
        private readonly ILookupManager _lookupManager;
        private readonly PlanDesignRequestManagerValidator _planDesignRequestValidator;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;
        private readonly PlanDesignRequestGetter _planDesignRequestGetter;
        private readonly PlanDesignRequestSaver _planDesignRequestSaver;
        private readonly IStatePricingTypeManager _statePricingTypeManager;
        private readonly ICompactStateManager _compactStateManager;

        public PlanDesignRequestSaveSoldManager(IUnitOfWorkFactory unitOfWorkFactory, IProductLibraryManager productLibraryManager, ILookupManager lookupManager,
           IEligibilityConfigurationManager eligibilityConfigurationManager, IStatePricingTypeManager statePricingTypeManager
            , ICompactStateManager compactStateManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _productLibraryManager = productLibraryManager;
            _lookupManager = lookupManager;
            _statePricingTypeManager = statePricingTypeManager;
            _compactStateManager = compactStateManager;
            _planDesignRequestValidator = new PlanDesignRequestManagerValidator();
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
            _planDesignRequestGetter = new PlanDesignRequestGetter(_unitOfWorkFactory, _eligibilityConfigurationManager);
            _planDesignRequestSaver = new PlanDesignRequestSaver(_unitOfWorkFactory, _productLibraryManager, 
                _eligibilityConfigurationManager, _statePricingTypeManager, _compactStateManager);
        }
        public void SaveSoldPDRInformation(IList<OfferLetterIllustrationDto> requests)
        {
            Log.TraceFormat("+CaptureSoldPDRInformation");
            var unSoldPDRIds = new List<int>();
            var unSoldClassIds = new List<int>();
            var soldClassIds = new List<int>();
            var pdrIds = new List<int>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var illustraionIds = requests.Select(d => d.IllustrationId).ToList();
                var illustrations = unitOfWork.Repository<Illustration>().Linq().Where(c => illustraionIds.Contains(c.Id));
                if (illustrations.Any())
                {
                    pdrIds = illustrations.Select(i => i.PlanDesignRequest.Id).ToList();
                    var cmsCase = illustrations.Select(i => i.PlanDesignRequest.Case).FirstOrDefault();
                    unSoldPDRIds = cmsCase.PlanDesignRequests.Where(p => !pdrIds.Contains(p.Id) && p.PDRSoldClass.Count == 0).Select(pdr => pdr.Id).ToList();

                    var riderGroups = _productLibraryManager.GetPlanDesignRiders();
                    var discountTypes = _lookupManager.GetValues<PDRDiscountType>();
                    var baseDiscountTypes = _lookupManager.GetValues<BaseDiscountType>();
                    var demographicDiscountTypes = _lookupManager.GetValues<DemographicDiscountType>();
                   

                    var employerPaidDiscountTypes = _lookupManager.GetValues<EmployerPaidDiscountType>();

                    foreach (var illustration in illustrations)
                    {
                        var illustrationRequest = JsonConvert.DeserializeObject<IllustrationRequest>(illustration.RequestJsonText);
                        if (illustrationRequest != null)
                        {
                            var soldIds = illustrationRequest.Classes.Select(c => c.TitanClassId).ToList();
                            if (soldIds.Any())
                            {
                                soldClassIds.AddRange(soldIds);
                            } 
                            foreach (var illustrationClass in illustrationRequest.Classes)
                            {
                                var basicPlanDesignClass = illustration.PlanDesignRequest.PlanDesignRequestClass.FirstOrDefault(c => c.Id == illustrationClass.TitanClassId);
                                
                                PDRSoldClass soldClass = CreateSoldClassRequest(illustration, basicPlanDesignClass);
                                var soldPlanRequest = CreateSoldClassPlan(soldClass, illustrationClass.PrimaryPlan, basicPlanDesignClass, false, riderGroups, discountTypes, baseDiscountTypes, demographicDiscountTypes, employerPaidDiscountTypes);

                                soldClass.PDRSoldClassPlan.Add(soldPlanRequest);

                                if (illustrationClass.HasBuyUpPlan)
                                {
                                    soldPlanRequest = CreateSoldClassPlan(soldClass, illustrationClass.BuyUpPlan, basicPlanDesignClass, true, riderGroups, discountTypes, baseDiscountTypes, demographicDiscountTypes, employerPaidDiscountTypes);
                                    soldClass.PDRSoldClassPlan.Add(soldPlanRequest);
                                }
                                unitOfWork.Repository<PDRSoldClass>().Save(soldClass);
                            }

                        }
                    }
                    unSoldClassIds = cmsCase.PlanDesignRequests.SelectMany(p => p.PlanDesignRequestClass).Where(c => !soldClassIds.Contains(c.Id)).Select(c => c.Id).ToList();
                    foreach (var pdrId in pdrIds)
                    {
                        DeactivatePDRClassesNotSold(unSoldClassIds, pdrId, true);
                    }
                    DeactivatePDRsNotSold(unSoldPDRIds);
                    unitOfWork.Commit();
                }
            }

            //foreach (var pdrId in pdrIds)
            //{
            //    DeactivatePDRClassesNotSold(unSoldClassIds, pdrId, true);
            //}
            //DeactivatePDRsNotSold(unSoldPDRIds);
            Log.TraceFormat("-CaptureSoldPDRInformation");
        }

        public void DeactivatePDRsNotSold(List<int> unSoldPDRIds)
        {
            Log.TraceFormat("+DeactivatePDRsNotSold");
            foreach (var pdrId in unSoldPDRIds)
            {
                DeactivatePDRClassesNotSold(null, pdrId, false);
            }
            Log.TraceFormat("-DeactivatePDRsNotSold");
        }

        public void DeactivatePDRClassesNotSold(List<int> unSoldPDRClassIds, int pdrId, bool isSoldPDR)
        {
            Log.TraceFormat("+DeactivatePDRandClassesNotSold");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdr = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == pdrId);
                if (pdr == null) return;

                var pdrClasses = isSoldPDR ? unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.PlanDesignRequest.Id == pdr.Id && unSoldPDRClassIds.Contains(c.Id)).ToList() :
                                             unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.PlanDesignRequest.Id == pdr.Id).ToList();

                foreach (var pdrClass in pdrClasses)
                {
                    pdrClass.IsActive = false;
                    if (pdrClass.CensusParticipants == null) continue;
                    if (pdrClass.CensusParticipants.Any())
                    {
                        pdrClass.CensusParticipants.ToList().ForEach(p => { p.PlanDesignRequestClass = null; });
                    }
                }

                pdr.IsActive = isSoldPDR;
                pdr.InactiveDate = DateTime.Now;

                unitOfWork.Repository<PlanDesignRequest>().Save(pdr);

                unitOfWork.Commit();
            }
            Log.TraceFormat("+DeactivatePDRandClassesNotSold");
        }

        public void SaveSoldPlanDesignRequest(PlanDesignDto request)
        {
            Log.TraceFormat("+SaveSoldPlanDesignRequest");

            var selectedPlanDesignRequest = request.PlanDesignRequests.First();

            int planDesignRequestClassId = 0;
            if (selectedPlanDesignRequest.SelectedClass != null)
            {
                planDesignRequestClassId = selectedPlanDesignRequest.SelectedClass.PlanDesignRequestClassId;
            }

            if (planDesignRequestClassId > 0)
            {
                var eligibilityConfigurationClassDto = new EligibilityConfigurationDto();
                eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
                               
                var compactStateList = _compactStateManager.GetCompactStates();
                var nonCompactStateList = _compactStateManager.GetNonCompactStates();

                _planDesignRequestValidator.ValidatePlanDesignRequestData(request, eligibilityConfigurationClassDto, compactStateList, nonCompactStateList, _statePricingTypeManager);

                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseUnderwritingRequest.CaseId);

                    SaveUnderwritingRequest(request, unitOfWork, cmsCase);

                    if (request.PlanDesignRequests.Count > 0)
                    {
                        SaveSelectedSoldPlanDesignRequest(request, unitOfWork, cmsCase);
                    }
                    unitOfWork.Commit();
                }
            }
            else
            {
                SaveNewSoldClass(request);
            }

            Log.TraceFormat("-SaveSoldPlanDesignRequest");
        }

        private void SaveNewSoldClass(PlanDesignDto request)
        {
            Log.TraceFormat("+SaveNewSoldClass");

            _planDesignRequestSaver.SavePlanDesignRequest(request);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var selectedPlanDesignRequest = request.PlanDesignRequests.First();
                var selectedClass = selectedPlanDesignRequest.SelectedClass;
                if (selectedClass != null)
                {
                    var newRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq()
                        .FirstOrDefault(c => c.PlanDesignRequest.Id == selectedPlanDesignRequest.PlanDesignRequestId
                        && c.ApprovedEligiblePopulationText == selectedClass.ApprovedEligiblePopulationText);

                    if (newRequestClass != null)
                    {
                        selectedPlanDesignRequest.SelectedClass.PlanDesignRequestClassId = newRequestClass.Id;
                        SaveSoldPlanDesignRequestClass(unitOfWork, selectedPlanDesignRequest.SelectedClass, newRequestClass.PlanDesignRequest);
                        unitOfWork.Commit();
                    }
                }
            }

            Log.TraceFormat("-SaveNewSoldClass");
        }
        private void SaveSelectedSoldPlanDesignRequest(PlanDesignDto request, IUnitOfWork unitOfWork, Case cmsCase)
        {
            Log.TraceFormat("+SaveSelectedSoldPlanDesignRequest");
            
            ProductValidationResult validateResult = _productLibraryManager.ValidatePDRProduct(request, cmsCase);
            if (validateResult.ValidationMessages.Any()) throw new ValidationException(validateResult.ValidationMessages);
                        
            var selectedPlanDesignRequest = request.PlanDesignRequests.FirstOrDefault();

            var planDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == selectedPlanDesignRequest.PlanDesignRequestId);
            if (planDesignRequest == null)
            {
                planDesignRequest = new PlanDesignRequest();
                planDesignRequest.Case = cmsCase;
                planDesignRequest.CreationDate = DateTime.Now;
            }

            planDesignRequest.IllustrationEffectiveDate = selectedPlanDesignRequest.IllustrationEffectiveDate;

            if (planDesignRequest.CreationDate == DateTime.MinValue)
            {
                planDesignRequest.CreationDate = DateTime.Now;
            }

            if (selectedPlanDesignRequest.SelectedClass != null)
            {
                SaveSoldPlanDesignRequestClass(unitOfWork, selectedPlanDesignRequest.SelectedClass, planDesignRequest);
            }

            unitOfWork.Repository<PlanDesignRequest>().Save(planDesignRequest);

            Log.TraceFormat("-SaveSelectedSoldPlanDesignRequest");
        }

        private void SaveUnderwritingRequest(PlanDesignDto request, IUnitOfWork unitOfWork, Case cmsCase)
        {
            Log.TraceFormat("+SaveUnderwritingRequest");

            var cmsUnderwritingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseUnderwritingRequest.CaseId);
            if (cmsUnderwritingRequest == null)
            {
                cmsUnderwritingRequest = new CaseUnderwritingRequest();
                cmsUnderwritingRequest.Case = cmsCase;
            }

            cmsUnderwritingRequest.SitusType = (SitusTypeEnum?)request.CaseUnderwritingRequest.SitusTypeId;
            cmsUnderwritingRequest.StateType = (StateTypeEnum?)request.CaseUnderwritingRequest.StateTypeId;
            cmsUnderwritingRequest.SitusMultiState1Type = (StateTypeEnum?)request.CaseUnderwritingRequest.SitusMultiState1TypeId;
            cmsUnderwritingRequest.SitusMultiState2Type = (StateTypeEnum?)request.CaseUnderwritingRequest.SitusMultiState2TypeId;
            cmsUnderwritingRequest.SitusMultiState3Type = (StateTypeEnum?)request.CaseUnderwritingRequest.SitusMultiState3TypeId;
            cmsUnderwritingRequest.Notes = request.CaseUnderwritingRequest.Notes;
            cmsUnderwritingRequest.IsCompactState = request.CaseUnderwritingRequest.IsCompactState;
            cmsUnderwritingRequest.PricingType = (PricingTypeEnum?)request.CaseUnderwritingRequest.PricingTypeId;

            unitOfWork.Repository<CaseUnderwritingRequest>().Save(cmsUnderwritingRequest);

            Log.TraceFormat("-SaveUnderwritingRequest");
        }

        private void SaveSoldPlanDesignRequestClass(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PlanDesignRequest planDesignRequest)
        {
            Log.TraceFormat("+SaveSoldPlanDesignRequestClass");

            var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassDto.PlanDesignRequestClassId && c.IsActive);
            if (pdrSoldClass == null)
            {
                pdrSoldClass = new PDRSoldClass();
                pdrSoldClass.PlanDesignRequestClass = planDesignRequest.PlanDesignRequestClass.FirstOrDefault(c => c.Id == planDesignRequestClassDto.PlanDesignRequestClassId);
                planDesignRequest.PDRSoldClass.Add(pdrSoldClass);
            }

            pdrSoldClass.PlanDesignRequest = planDesignRequest;
            pdrSoldClass.EligiblePopulationText = planDesignRequestClassDto.ApprovedEligiblePopulationText;
            pdrSoldClass.EligiblePopulationTextNotes = planDesignRequestClassDto.EligiblePopulationTextNotes;
            pdrSoldClass.IsActive = true;
            SaveSoldClassPlan(unitOfWork, planDesignRequestClassDto, pdrSoldClass, false);

            if (planDesignRequestClassDto.IsApprovedVoluntaryGSIBuyUpPlan == true)
            {
                SaveSoldClassPlan(unitOfWork, planDesignRequestClassDto, pdrSoldClass, true);
            }
            else
            {
                var classPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().FirstOrDefault(c => c.PDRSoldClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId && c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                if (classPlan != null)
                {
                    pdrSoldClass.PDRSoldClassPlan.Remove(classPlan);
                }
            }
            if (planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage != null && planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.PremiumAndTaxpayerLiabilityTypeId != 0)
            {
                SaveSoldPlanDesignRequestClassLTDCoverage(unitOfWork, planDesignRequestClassDto, pdrSoldClass);
            }

            SaveSoldClassRetirementPlans(unitOfWork, planDesignRequestClassDto, pdrSoldClass);
            if (planDesignRequestClassDto.EligibilityConfiguration != null && planDesignRequestClassDto.PlanDesignRequestClassId > 0)
            {
                if (planDesignRequestClassDto.EligibilityConfiguration.CaseId != null)
                {
                    planDesignRequestClassDto.EligibilityConfiguration.PlanDesignRequestClassId = (pdrSoldClass.PlanDesignRequestClass != null) ? pdrSoldClass.PlanDesignRequestClass.Id : planDesignRequestClassDto.PlanDesignRequestClassId;
                    _eligibilityConfigurationManager.SaveEligibilityConfiguration(planDesignRequestClassDto.EligibilityConfiguration);
                }
            }

            Log.TraceFormat("-SaveSoldPlanDesignRequestClass");
        }

        private void SaveSoldPlanDesignRequestClassLTDCoverage(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PDRSoldClass pdrSoldClass)
        {
            Log.TraceFormat("+SaveSoldPlanDesignRequestClassLTDCoverage");

            var pdrSoldClassLTDCoverage = unitOfWork.Repository<PDRSoldClassLTDCoverage>().Linq().FirstOrDefault(c => c.PDRSoldClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId);
            if (pdrSoldClassLTDCoverage == null)
            {
                pdrSoldClassLTDCoverage = new PDRSoldClassLTDCoverage();
                pdrSoldClassLTDCoverage.PDRSoldClass = pdrSoldClass;
                pdrSoldClass.PDRSoldClassLTDCoverage.Add(pdrSoldClassLTDCoverage);
            }
            pdrSoldClassLTDCoverage.EligiblePopulationText = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.EligiblePopulationText;
            pdrSoldClassLTDCoverage.CarrierText = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.CarrierText;
            pdrSoldClassLTDCoverage.EliminationPeriodDays = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.EliminationPeriodDays;
            pdrSoldClassLTDCoverage.BenefitPeriodDays = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.BenefitPeriodDays;
            pdrSoldClassLTDCoverage.GroupLTDReplacementPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.GroupLTDReplacementPercentage;
            pdrSoldClassLTDCoverage.GroupLTDCapAmount = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.GroupLTDCapAmount;
            pdrSoldClassLTDCoverage.GroupLTDCoveredEarningsType = (CoveredEarningsTypeEnum)planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.GroupLTDCoveredEarningsTypeId;
            pdrSoldClassLTDCoverage.PremiumAndTaxpayerLiabilityType = unitOfWork.Repository<ExistingCoveragePremiumAndTaxpayerLiabilityType>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.PremiumAndTaxpayerLiabilityTypeId);
            pdrSoldClassLTDCoverage.TypeOfPayType = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.TypeOfPayTypeId != null ? (TaxabilityTypeEnum?)planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.TypeOfPayTypeId : null;
            pdrSoldClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator = (GetIsVoluntaryLTDBuyUpIndicator(pdrSoldClassLTDCoverage) == true) ? planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator : null;
            pdrSoldClassLTDCoverage.LTDBuyUpReplacementPercentage = (planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator == null || false == planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator) ? null : planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.LTDBuyUpReplacementPercentage;
            pdrSoldClassLTDCoverage.LTDBuyUpLTDCapAmount = (planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator == null || false == planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator) ? null : planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.LTDBuyUpLTDCapAmount;
            pdrSoldClassLTDCoverage.LTDBuyUpCoveredEarningsType = (planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator == null || false == planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator) ? null : (CoveredEarningsTypeEnum?)planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.LTDBuyUpCoveredEarningsTypeId;
            pdrSoldClassLTDCoverage.IsLTDPlanExistingIndicator = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.IsLTDPlanExistingIndicator;
            pdrSoldClassLTDCoverage.AdditionalDetailsText = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.AdditionalDetailsText;
            pdrSoldClassLTDCoverage.BaseSalaryPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.BaseSalaryPercentage ?? null;
            pdrSoldClassLTDCoverage.BonusNumberofYears = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.BonusNumberofYears ?? null;
            pdrSoldClassLTDCoverage.BonusPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.BonusPercentage ?? null;
            pdrSoldClassLTDCoverage.CommissionNumberofYears = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.CommissionNumberofYears ?? null;
            pdrSoldClassLTDCoverage.CommissionPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.CommissionPercentage ?? null;
            pdrSoldClassLTDCoverage.K1EarningsNumberofYears = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.K1EarningsNumberofYears ?? null;
            pdrSoldClassLTDCoverage.K1EarningsPercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.K1EarningsPercentage ?? null;
            pdrSoldClassLTDCoverage.OtherIncomePercentage = planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage.OtherIncomePercentage ?? null;

            Log.TraceFormat("-SaveSoldPlanDesignRequestClassLTDCoverage");
        }

        private void SaveSoldClassPlan(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PDRSoldClass pdrSoldClass, bool isBuyUp)
        {
            Log.TraceFormat("+SaveSoldClassPlan");

            Func<PDRSoldClassPlan, bool> pdrSoldClassPlanQuery;

            if (isBuyUp)
            {
                pdrSoldClassPlanQuery = c => c.PDRSoldClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId && c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp;
            }
            else
            {
                pdrSoldClassPlanQuery = c => c.PDRSoldClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId && c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary;
            }

            var classPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().FirstOrDefault(pdrSoldClassPlanQuery);

            if (classPlan == null)
            {
                classPlan = new PDRSoldClassPlan();
                classPlan.PDRSoldClass = pdrSoldClass;
                pdrSoldClass.PDRSoldClassPlan.Add(classPlan);
            }
            if (isBuyUp)
            {
                classPlan.PDRClassPlanType = PDRClassPlanTypeEnum.VoluntaryGSIBuyUp;
                classPlan.PlanDesignType = (PlanDesignTypeEnum?)planDesignRequestClassDto.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId;
                classPlan.GSIBuyUpPlanDesignNotes = planDesignRequestClassDto.VoluntaryGSIBuyUpPlanDesignNotes;
                classPlan.CoveredEarningsType = (CoveredEarningsTypeEnum?)planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId;
                classPlan.GSIBuyUpCoveredEarningsTypeNotes = planDesignRequestClassDto.GSIBuyUpCoveredEarningsTypeNotes;
                classPlan.ReplacementPercentage = planDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage;
                classPlan.GSIBuyUpReplacementPercentageNotes = planDesignRequestClassDto.GSIBuyUpReplacementPercentageNotes;
                classPlan.CoveredEarningsBonusOnlyType = (CoveredEarningsBonusOnlyTypeEnum?)planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId;
                classPlan.InsurableIncomeDefinition = _planDesignRequestSaver.GetInsurableIncomeDefinition(planDesignRequestClassDto, true);
            }
            else
            {
                var premiumPayerAndTaxabilityType = unitOfWork.Repository<ExistingCoveragePremiumAndTaxpayerLiabilityType>().Linq().ToList();
                var costShareTaxabilityType = unitOfWork.Repository<CostShareTaxabilityType>().Linq();
                classPlan.PDRClassPlanType = PDRClassPlanTypeEnum.Primary;
                classPlan.PlanDesignType = (PlanDesignTypeEnum?)planDesignRequestClassDto.ApprovedPlanDesignTypeId;
                classPlan.PlanDesignNotes = planDesignRequestClassDto.PlanDesignNotes;
                classPlan.LTDPercentage = planDesignRequestClassDto.ApprovedLTDPercentage;
                classPlan.LTDPercentageNotes = planDesignRequestClassDto.LTDPercentageNotes;
                classPlan.IDIPercentage = planDesignRequestClassDto.ApprovedIDIPercentage;
                classPlan.IDIPercentageNotes = planDesignRequestClassDto.IDIPercentageNotes;
                classPlan.PremiumPayerAndTaxabilityType = premiumPayerAndTaxabilityType.FirstOrDefault(c => c.Id == planDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId);
                classPlan.PremiumPayerAndTaxabilityNotes = planDesignRequestClassDto.PremiumPayerAndTaxabilityNotes;
                classPlan.LTDCoversNext = planDesignRequestClassDto.ApprovedLTDCoversNext;
                classPlan.LTDCoversNextNotes = planDesignRequestClassDto.LTDCoversNextNotes;
                classPlan.IDICovers1st = planDesignRequestClassDto.ApprovedIDICovers1st;
                classPlan.IDICovers1stNotes = planDesignRequestClassDto.IDICovers1stNotes;
                classPlan.CoveredEarningsType = (CoveredEarningsTypeEnum?)planDesignRequestClassDto.ApprovedCoveredEarningsTypeId;
                classPlan.CoveredEarningsTypeNotes = planDesignRequestClassDto.CoveredEarningsTypeNotes;
                classPlan.FlatRateType = unitOfWork.Repository<FlatRateType>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassDto.ApprovedFlatRateType_Id);
                classPlan.FlatRate_Other = planDesignRequestClassDto.ApprovedFlatRate_Other;
                classPlan.RetirementContributionsType = (RetirementContributionsTypeEnum?)planDesignRequestClassDto.ApprovedRetirementContributionsTypeId;
                classPlan.RetirementContributionsNotes = planDesignRequestClassDto.RetirementContributionNotes;
                classPlan.AnnualContributions = planDesignRequestClassDto.ApprovedAnnualContributions;
                classPlan.AnnualContributionsNotes = planDesignRequestClassDto.AnnualContributionsNotes;
                classPlan.RppRiderCoveredEarningsType = (CoveredEarningsTypeEnum?)planDesignRequestClassDto.ApprovedRppRiderCoveredEarningsTypeId;
                classPlan.RppRiderCoveredEarningsTypeNotes = planDesignRequestClassDto.RppRiderCoveredEarningsTypeNotes;
                classPlan.TaxabilityType = (TaxabilityTypeEnum?)planDesignRequestClassDto.ApprovedTaxabilityTypeId;
                classPlan.TaxabilityTypeNotes = planDesignRequestClassDto.TaxabilityTypeNotes;
                classPlan.CoveredEarningsBonusOnlyType = (CoveredEarningsBonusOnlyTypeEnum?)planDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId;
                classPlan.TypeOfShareType = (TypeOfShareTypeEnum?)planDesignRequestClassDto.ApprovedTypeOfShareTypeId;
                classPlan.EmployerPaidPremium = planDesignRequestClassDto.ApprovedEmployerPaidPremium;
                classPlan.EmployeePaidPremium = planDesignRequestClassDto.ApprovedEmployeePaidPremium;
                classPlan.EmployerPaidPremiumNotes = planDesignRequestClassDto.EmployerPaidPremiumNotes;
                classPlan.EmployerPaysupto = planDesignRequestClassDto.ApprovedEmployerPaysupto;
                classPlan.EmployerPaysuptoNotes = planDesignRequestClassDto.EmployerPaysuptoNotes;
                classPlan.CostShareTaxabilityType = costShareTaxabilityType.FirstOrDefault(c => c.Id == planDesignRequestClassDto.ApprovedCostShareTaxabilityTypeId);
                classPlan.BenefitPeriod = (BenefitPeriodTypeEnum?)planDesignRequestClassDto.ApprovedBenefitPeriodTypeId;
                classPlan.BenefitPeriodNotes = planDesignRequestClassDto.BenefitPeriodNotes;
                classPlan.EliminationPeriod = (EliminationPeriodTypeEnum?)planDesignRequestClassDto.ApprovedEliminationPeriodTypeId;
                classPlan.EliminationPeriodNotes = planDesignRequestClassDto.EliminationPeriodNotes;
                classPlan.InsurableIncomeDefinition = _planDesignRequestSaver.GetInsurableIncomeDefinition(planDesignRequestClassDto, false);
            }

            classPlan.MaximumReplacementRatio = planDesignRequestClassDto.ApprovedMaximumReplacementRatio;
            classPlan.MaximumReplacementRatioNotes = planDesignRequestClassDto.MaximumReplacementRatioNotes;
            classPlan.CoveredEarningsPercentage = planDesignRequestClassDto.ApprovedCoveredEarningsPercentage;
            classPlan.CoveredEarningsPercentageNotes = planDesignRequestClassDto.CoveredEarningsPercentageNotes;
            classPlan.GSIBuyUpPlanNotes = planDesignRequestClassDto.VoluntaryGSIBuyUpPlanNotes;

            var classProductDto = planDesignRequestClassDto.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == isBuyUp);

            if (classProductDto != null)
            {
                classPlan.GSIAmount = (int)classProductDto.GSIAmount;
                classPlan.MinimumCaseLevelGSIAmount = (int)classProductDto.MinimumCaseLevelGSIAmount; 
                classPlan.ParticipationPercentage = (int)classProductDto.ParticipationPercentage;
                classPlan.DefinitionOfDisabilityType = (DefinitionOfDisabilityTypeEnum)classProductDto.DefinitionOfDisabilityTypeId;
                classPlan.MentalSubstanceLimitationType = (MentalSubstanceLimitationEnum)classProductDto.MentalSubstanceLimitationTypeId;
                classPlan.PreExistingConditionLimitType = (PreExistingConditionLimitTypeEnum)classProductDto.PreExistingConditionLimitTypeId;
                classPlan.DiscountOverride = classProductDto.DiscountOverride;
                classPlan.IsOneStepEnrollmentIndicator = classProductDto.IsOneStepEnrollmentIndicator;
                classPlan.IsDirectCoverageIndicator = classProductDto.IsDirectCoverageIndicator;
                if (isBuyUp)
                {
                    classPlan.BenefitPeriod = (BenefitPeriodTypeEnum)classProductDto.BenefitPeriodTypeId;
                    classPlan.EliminationPeriod = (EliminationPeriodTypeEnum)classProductDto.EliminationPeriodTypeId;
                    classPlan.TotalMaxGSIAmount = (int)classProductDto.TotalMaxGSIAmount;
                }

                //var discountTypes = _lookupManager.GetValues<PDRDiscountType>();
                //classPlan.PDRDiscountType = discountTypes.FirstOrDefault(d => d.Id == classProductDto.PDRDiscountTypeId); TODO-Joshua

                var baseDiscountTypes = _lookupManager.GetValues<BaseDiscountType>();
                classPlan.BaseDiscountType = baseDiscountTypes.FirstOrDefault(d => d.Id == classProductDto.BaseDiscountTypeId);

                var demographicDiscountTypes = _lookupManager.GetValues<DemographicDiscountType>();
                classPlan.DemographicDiscountType = demographicDiscountTypes.FirstOrDefault(d => d.Id == classProductDto.DemographicDiscountTypeId);

                var EmployerPaidDiscountTypes = _lookupManager.GetValues<EmployerPaidDiscountType>();
                classPlan.EmployerPaidDiscountType = EmployerPaidDiscountTypes.FirstOrDefault(d => d.Id == classProductDto.EmployerPaidDiscountTypeId);
            }

            SaveSoldClassPlanRiders(unitOfWork, planDesignRequestClassDto, classPlan, isBuyUp);

            SaveSoldClassPlanCustomIDIIncomes(unitOfWork, planDesignRequestClassDto, classPlan, isBuyUp);

            Log.TraceFormat("-SaveSoldClassPlan");
        }

        private void SaveSoldClassPlanRiders(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PDRSoldClassPlan pdrSoldClassPlan, bool isBuyUp)
        {
            Log.TraceFormat("+SaveSoldClassPlanRiders");

            var pdrSoldClassPlanRiders = unitOfWork.Repository<PDRSoldClassPlanRiders>().Linq().Where(c => c.PDRSoldClassPlan.Id == pdrSoldClassPlan.Id).ToList();

            foreach (var planDesignRequestClassRiderDto in planDesignRequestClassDto.PlanDesignRequestClassRiders.Where(r => r.IsGSIPlanIndicator == isBuyUp))
            {
                var pdrSoldClassPlanRider = pdrSoldClassPlanRiders.FirstOrDefault(c => c.Id == planDesignRequestClassRiderDto.PlanDesignRequestClassRiderId);
                if (pdrSoldClassPlanRider == null)
                {
                    pdrSoldClassPlanRider = new PDRSoldClassPlanRiders();
                    pdrSoldClassPlanRider.PDRSoldClassPlan = pdrSoldClassPlan;
                    pdrSoldClassPlan.PDRSoldClassPlanRiders.Add(pdrSoldClassPlanRider);
                }
                pdrSoldClassPlanRider.BenefitGroupType = (BenefitGroupTypeEnum)planDesignRequestClassRiderDto.SelectedBenefitGroup;
                if (planDesignRequestClassRiderDto.SelectedBenefitType != null) pdrSoldClassPlanRider.BenefitType = (BenefitTypeEnum)planDesignRequestClassRiderDto.SelectedBenefitType;
                pdrSoldClassPlanRider.BenefitPeriodType = planDesignRequestClassRiderDto.SelectedBenefitPeriod != null ? (BenefitPeriodTypeEnum?)planDesignRequestClassRiderDto.SelectedBenefitPeriod : null;
                pdrSoldClassPlanRider.EliminationPeriodType = planDesignRequestClassRiderDto.SelectedEliminationPeriod != null ? (EliminationPeriodTypeEnum?)planDesignRequestClassRiderDto.SelectedEliminationPeriod : null;
                pdrSoldClassPlanRider.ApprovedAmount = planDesignRequestClassRiderDto.ApprovedAmount;
            }

            var newAndExistingRidersIds = planDesignRequestClassDto.PlanDesignRequestClassRiders.Where(r => r.IsGSIPlanIndicator == isBuyUp).Select(d => d.PlanDesignRequestClassRiderId).ToList();
            var deletedRiders = pdrSoldClassPlanRiders.Where(l => !newAndExistingRidersIds.Contains(l.Id)).ToList();
            foreach (var deletedRider in deletedRiders)
            {
                pdrSoldClassPlan.PDRSoldClassPlanRiders.Remove(deletedRider);
            }
            Log.TraceFormat("-SaveSoldClassPlanRiders");
        }

        private void SaveSoldClassPlanCustomIDIIncomes(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PDRSoldClassPlan pdrSoldClassPlan, bool isBuyUp)
        {
            Log.TraceFormat("+SaveSoldClassPlanCustomIDIIncomes");

            var pdrSoldClassPlanCustomIDIIncomes = unitOfWork.Repository<PDRSoldClassPlanCustomizedIDIInsurableIncome>().Linq().Where(c => c.PDRSoldClassPlan.Id == pdrSoldClassPlan.Id).ToList();

            foreach (var planDesignRequestClassCustomIncomeDto in planDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Where(r => r.IsGSIPlanIndicator == isBuyUp))
            {
                var pdrSoldClassPlanCustomIDIIncome = pdrSoldClassPlanCustomIDIIncomes.FirstOrDefault(c => c.Id == planDesignRequestClassCustomIncomeDto.PDRSoldClassPlanCustomizedIDIInsurableIncomeId);
                if (pdrSoldClassPlanCustomIDIIncome == null)
                {
                    pdrSoldClassPlanCustomIDIIncome = new PDRSoldClassPlanCustomizedIDIInsurableIncome();
                    pdrSoldClassPlanCustomIDIIncome.PDRSoldClassPlan = pdrSoldClassPlan;
                    pdrSoldClassPlan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.Add(pdrSoldClassPlanCustomIDIIncome);
                }
                pdrSoldClassPlanCustomIDIIncome.BaseSalaryPercentage = planDesignRequestClassCustomIncomeDto.BaseSalaryPercentage;
                pdrSoldClassPlanCustomIDIIncome.BonusPercentage = planDesignRequestClassCustomIncomeDto.BonusPercentage;
                pdrSoldClassPlanCustomIDIIncome.CommissionPercentage = planDesignRequestClassCustomIncomeDto.CommissionPercentage;
                pdrSoldClassPlanCustomIDIIncome.OtherIncomePercentage = planDesignRequestClassCustomIncomeDto.OtherIncomePercentage;
                pdrSoldClassPlanCustomIDIIncome.K1EarningsPercentage = planDesignRequestClassCustomIncomeDto.K1EarningsPercentage;
                pdrSoldClassPlanCustomIDIIncome.BonusNumberofYears = planDesignRequestClassCustomIncomeDto.BonusNumberofYears;
                pdrSoldClassPlanCustomIDIIncome.CommissionNumberofYears = planDesignRequestClassCustomIncomeDto.CommissionNumberofYears;
                pdrSoldClassPlanCustomIDIIncome.K1EarningsNumberofYears = planDesignRequestClassCustomIncomeDto.K1EarningsNumberofYears;

            }

            var newAndExistingIncomeIds = planDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes.Where(r => r.IsGSIPlanIndicator == isBuyUp).Select(d => d.PDRSoldClassPlanCustomizedIDIInsurableIncomeId).ToList();
            var deletedIncomes = pdrSoldClassPlanCustomIDIIncomes.Where(l => !newAndExistingIncomeIds.Contains(l.Id)).ToList();
            foreach (var deletedIncome in deletedIncomes)
            {
                pdrSoldClassPlan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.Remove(deletedIncome);
            }
            Log.TraceFormat("-SaveSoldClassPlanCustomIDIIncomes");
        }

        private void SaveSoldClassRetirementPlans(IUnitOfWork unitOfWork, PlanDesignRequestClassDto planDesignRequestClassDto, PDRSoldClass pdrSoldClass)
        {
            Log.TraceFormat("+SaveSoldClassRetirementPlans");
            var companyRetirementPlanTypes = unitOfWork.Repository<CompanyRetirementPlanType>().Linq().ToList();
            var soldClassRetirementPlans = unitOfWork.Repository<PDRSoldClassCompanyRetirementPlan>().Linq().Where(c => c.PDRSoldClass.Id == planDesignRequestClassDto.PlanDesignRequestClassId).ToList();
            foreach (var caseCompanyRetirementPlanDto in planDesignRequestClassDto.CaseCompanyRetirementPlans)
            {
                var soldClassRetirementPlan = soldClassRetirementPlans.FirstOrDefault(c => c.Id == caseCompanyRetirementPlanDto.CaseCompanyRetirementPlanId);
                if (soldClassRetirementPlan == null)
                {
                    soldClassRetirementPlan = new PDRSoldClassCompanyRetirementPlan();
                    pdrSoldClass.PDRSoldClassCompanyRetirementPlan.Add(soldClassRetirementPlan);
                }
                soldClassRetirementPlan.PDRSoldClass = pdrSoldClass;
                soldClassRetirementPlan.IsChecked = caseCompanyRetirementPlanDto.IsChecked;
                soldClassRetirementPlan.CompanyRetirementPlanType = companyRetirementPlanTypes.FirstOrDefault(c => c.Id == caseCompanyRetirementPlanDto.CompanyRetirementPlanTypeId);
            }
            Log.TraceFormat("-SaveSoldClassRetirementPlans");
        }

        public void SaveSoldPDRCustomizedIncomes(PDRClassCustomizedIDIInsurableIncomeDto request)
        {
            Log.TraceFormat("+SavePDRCustomizedIncomes");

            _planDesignRequestValidator.ValidateSavePDRCustomizedIncomesData(request);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrClassCustomizedIDIInsurableIncome = unitOfWork.Repository<PDRSoldClassPlanCustomizedIDIInsurableIncome>().Linq().FirstOrDefault(c => c.Id == request.PDRSoldClassPlanCustomizedIDIInsurableIncomeId);
                if (pdrClassCustomizedIDIInsurableIncome == null)
                {
                    var pdrClassPlanTypeEnum = PDRClassPlanTypeEnum.Primary;
                    if (request.IsGSIPlanIndicator)
                    {
                        pdrClassPlanTypeEnum = PDRClassPlanTypeEnum.VoluntaryGSIBuyUp;
                    }
                    var pdrClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().FirstOrDefault(c => c.PDRSoldClass.Id == request.PDRSoldClassId && c.PDRClassPlanType == pdrClassPlanTypeEnum);
                    if (pdrClassPlan == null)
                    {
                        var pdrClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.Id == request.PDRSoldClassId && c.IsActive);
                        pdrClassPlan = new PDRSoldClassPlan();
                        pdrClassPlan.PDRClassPlanType = pdrClassPlanTypeEnum;
                        pdrClassPlan.PDRSoldClass = pdrClass;
                        unitOfWork.Repository<PDRSoldClassPlan>().Save(pdrClassPlan);
                    }
                    pdrClassCustomizedIDIInsurableIncome = new PDRSoldClassPlanCustomizedIDIInsurableIncome();
                    pdrClassCustomizedIDIInsurableIncome.PDRSoldClassPlan = pdrClassPlan;
                }
                pdrClassCustomizedIDIInsurableIncome.BaseSalaryPercentage = request.BaseSalaryPercentage;
                pdrClassCustomizedIDIInsurableIncome.BonusPercentage = request.BonusPercentage;
                pdrClassCustomizedIDIInsurableIncome.CommissionPercentage = request.CommissionPercentage;
                pdrClassCustomizedIDIInsurableIncome.OtherIncomePercentage = request.OtherIncomePercentage;
                pdrClassCustomizedIDIInsurableIncome.K1EarningsPercentage = request.K1EarningsPercentage;
                pdrClassCustomizedIDIInsurableIncome.BonusNumberofYears = request.BonusNumberofYears;
                pdrClassCustomizedIDIInsurableIncome.CommissionNumberofYears = request.CommissionNumberofYears;
                pdrClassCustomizedIDIInsurableIncome.K1EarningsNumberofYears = request.K1EarningsNumberofYears;

                unitOfWork.Repository<PDRSoldClassPlanCustomizedIDIInsurableIncome>().Save(pdrClassCustomizedIDIInsurableIncome);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SavePDRCustomizedIncomes");
        }

        public void SaveSoldPDRLTDCustomizedIncomes(PlanDesignRequestClassLTDCoverageDto request)
        {
            Log.TraceFormat("+SaveSoldPDRLTDCustomizedIncomes");

            _planDesignRequestValidator.ValidateSavePDRLTDCustomizedIncomesData(request);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrSoldClassLTDCoverage = unitOfWork.Repository<PDRSoldClassLTDCoverage>().Linq().FirstOrDefault(c => c.PDRSoldClass.Id == request.PDRSoldClassId);
                if (pdrSoldClassLTDCoverage == null)
                {
                    var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.Id == request.PDRSoldClassId && c.IsActive);
                    pdrSoldClassLTDCoverage = new PDRSoldClassLTDCoverage();
                    pdrSoldClassLTDCoverage.PDRSoldClass = pdrSoldClass;
                }
                pdrSoldClassLTDCoverage.EligiblePopulationText = request.EligiblePopulationText;
                pdrSoldClassLTDCoverage.CarrierText = request.CarrierText;
                pdrSoldClassLTDCoverage.EliminationPeriodDays = request.EliminationPeriodDays;
                pdrSoldClassLTDCoverage.BenefitPeriodDays = request.BenefitPeriodDays;
                pdrSoldClassLTDCoverage.GroupLTDReplacementPercentage = request.GroupLTDReplacementPercentage;
                pdrSoldClassLTDCoverage.GroupLTDCapAmount = request.GroupLTDCapAmount;
                pdrSoldClassLTDCoverage.GroupLTDCoveredEarningsType = (CoveredEarningsTypeEnum)request.GroupLTDCoveredEarningsTypeId;
                pdrSoldClassLTDCoverage.PremiumAndTaxpayerLiabilityType = unitOfWork.Repository<ExistingCoveragePremiumAndTaxpayerLiabilityType>().Linq().FirstOrDefault(c => c.Id == request.PremiumAndTaxpayerLiabilityTypeId);
                pdrSoldClassLTDCoverage.TypeOfPayType = request.TypeOfPayTypeId != null ? (TaxabilityTypeEnum?)request.TypeOfPayTypeId : null;
                pdrSoldClassLTDCoverage.IsVoluntaryLTDBuyUpIndicator = (GetIsVoluntaryLTDBuyUpIndicator(pdrSoldClassLTDCoverage) == true) ? request.IsVoluntaryLTDBuyUpIndicator : null;
                pdrSoldClassLTDCoverage.LTDBuyUpReplacementPercentage = (request.IsVoluntaryLTDBuyUpIndicator == null || false == request.IsVoluntaryLTDBuyUpIndicator) ? null : request.LTDBuyUpReplacementPercentage;
                pdrSoldClassLTDCoverage.LTDBuyUpLTDCapAmount = (request.IsVoluntaryLTDBuyUpIndicator == null || false == request.IsVoluntaryLTDBuyUpIndicator) ? null : request.LTDBuyUpLTDCapAmount;
                pdrSoldClassLTDCoverage.LTDBuyUpCoveredEarningsType = (request.IsVoluntaryLTDBuyUpIndicator == null || false == request.IsVoluntaryLTDBuyUpIndicator) ? null : (CoveredEarningsTypeEnum?)request.LTDBuyUpCoveredEarningsTypeId;
                pdrSoldClassLTDCoverage.IsLTDPlanExistingIndicator = request.IsLTDPlanExistingIndicator;
                pdrSoldClassLTDCoverage.AdditionalDetailsText = request.AdditionalDetailsText;
                pdrSoldClassLTDCoverage.BaseSalaryPercentage = request.BaseSalaryPercentage ?? null;
                pdrSoldClassLTDCoverage.BonusNumberofYears = request.BonusNumberofYears ?? null;
                pdrSoldClassLTDCoverage.BonusPercentage = request.BonusPercentage ?? null;
                pdrSoldClassLTDCoverage.CommissionNumberofYears = request.CommissionNumberofYears ?? null;
                pdrSoldClassLTDCoverage.CommissionPercentage = request.CommissionPercentage ?? null;
                pdrSoldClassLTDCoverage.K1EarningsNumberofYears = request.K1EarningsNumberofYears ?? null;
                pdrSoldClassLTDCoverage.K1EarningsPercentage = request.K1EarningsPercentage ?? null;
                pdrSoldClassLTDCoverage.OtherIncomePercentage = request.OtherIncomePercentage ?? null;

                unitOfWork.Repository<PDRSoldClassLTDCoverage>().Save(pdrSoldClassLTDCoverage);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveSoldPDRLTDCustomizedIncomes");
        }

        private PDRSoldClass CreateSoldClassRequest(Illustration illustration, PlanDesignRequestClass basicPlanDesignClass)
        {
            Log.TraceFormat("+CreateSoldClassRequest");
            PDRSoldClass soldClass = new PDRSoldClass
            {
                PlanDesignRequest = illustration.PlanDesignRequest,
                PlanDesignRequestClass = basicPlanDesignClass,
                EligiblePopulationText = basicPlanDesignClass.ApprovedEligiblePopulationText,
                EligiblePopulationTextNotes = basicPlanDesignClass.EligiblePopulationTextNotes,
                IsActive = true
            };
            soldClass.PDRSoldClassLTDCoverage = basicPlanDesignClass.PlanDesignRequestClassLTDCoverage.Select(
                                                l => new PDRSoldClassLTDCoverage
                                                {
                                                    PDRSoldClass = soldClass,
                                                    AdditionalDetailsText = l.AdditionalDetailsText,
                                                    BenefitPeriodDays = l.BenefitPeriodDays,
                                                    CarrierText = l.CarrierText,
                                                    EligiblePopulationText = l.EligiblePopulationText,
                                                    EliminationPeriodDays = l.EliminationPeriodDays,
                                                    GroupLTDCapAmount = l.GroupLTDCapAmount,
                                                    GroupLTDCoveredEarningsType = l.GroupLTDCoveredEarningsType,
                                                    GroupLTDCoveredEarningsType_Other = l.GroupLTDCoveredEarningsType_Other,
                                                    GroupLTDReplacementPercentage = l.GroupLTDReplacementPercentage,
                                                    IsLTDPlanExistingIndicator = l.IsLTDPlanExistingIndicator,
                                                    IsVoluntaryLTDBuyUpIndicator = l.IsVoluntaryLTDBuyUpIndicator,
                                                    LTDBuyUpCoveredEarningsType = l.LTDBuyUpCoveredEarningsType,
                                                    LTDBuyUpCoveredEarningsType_Other = l.LTDBuyUpCoveredEarningsType_Other,
                                                    LTDBuyUpLTDCapAmount = l.LTDBuyUpLTDCapAmount,
                                                    LTDBuyUpReplacementPercentage = l.LTDBuyUpReplacementPercentage,
                                                    PremiumAndTaxpayerLiabilityType = l.PremiumAndTaxpayerLiabilityType,
                                                    TypeOfPayType = l.TypeOfPayType,
                                                    BaseSalaryPercentage = l.BaseSalaryPercentage ?? null,
                                                    BonusNumberofYears = l.BonusNumberofYears ?? null,
                                                    BonusPercentage = l.BonusPercentage ?? null,
                                                    CommissionNumberofYears = l.CommissionNumberofYears ?? null,
                                                    CommissionPercentage = l.CommissionPercentage ?? null,
                                                    K1EarningsNumberofYears = l.K1EarningsNumberofYears ?? null,
                                                    K1EarningsPercentage = l.K1EarningsPercentage ?? null,
                                                    OtherIncomePercentage = l.OtherIncomePercentage ?? null
                                                }).ToList();

            soldClass.PDRSoldClassCompanyRetirementPlan = basicPlanDesignClass.CaseCompanyRetirementPlan.
                                            Select(l => new PDRSoldClassCompanyRetirementPlan
                                            {
                                                PDRSoldClass = soldClass,
                                                CompanyRetirementPlanType = l.CompanyRetirementPlanType,
                                                CompanyRetirementPlanType_Other = l.CompanyRetirementPlanType_Other,
                                                IsChecked = l.IsChecked,
                                            }).ToList();

            Log.TraceFormat("-CreateSoldClassRequest");
            return soldClass;
        }

        private PDRSoldClassPlan CreateSoldClassPlan(PDRSoldClass soldClass, IllustrationRequestClassPlan soldClassPlan, PlanDesignRequestClass basicPlanDesignClass, bool hasBuyUp, List<PlanDesignRequestClassRiderGroupDto> riderGroups, List<PDRDiscountType> discountTypes, List<BaseDiscountType> baseDiscountTypes, List<DemographicDiscountType> demographicDiscountTypes, List<EmployerPaidDiscountType> employerPaidDiscountTypes)
        {
            Log.TraceFormat("+CreateSoldClassPlan");
            PDRSoldClassPlan classPlan = new PDRSoldClassPlan
            {
                PDRSoldClass = soldClass,
                PlanDesignType = basicPlanDesignClass.ApprovedPlanDesignType,
                PlanDesignNotes = basicPlanDesignClass.PlanDesignNotes,
                LTDPercentage = basicPlanDesignClass.ApprovedLTDPercentage,
                LTDPercentageNotes = basicPlanDesignClass.LTDPercentageNotes,
                IDIPercentage = basicPlanDesignClass.ApprovedIDIPercentage,
                IDIPercentageNotes = basicPlanDesignClass.IDIPercentageNotes,
                PremiumPayerAndTaxabilityType = basicPlanDesignClass.ApprovedPremiumPayerAndTaxabilityType,
                PremiumPayerAndTaxabilityNotes = basicPlanDesignClass.PremiumPayerAndTaxabilityNotes,
                MaximumReplacementRatio = basicPlanDesignClass.ApprovedMaximumReplacementRatio,
                MaximumReplacementRatioNotes = basicPlanDesignClass.MaximumReplacementRatioNotes,
                LTDCoversNext = basicPlanDesignClass.ApprovedLTDCoversNext,
                LTDCoversNextNotes = basicPlanDesignClass.LTDCoversNextNotes,
                IDICovers1st = basicPlanDesignClass.ApprovedIDICovers1st,
                IDICovers1stNotes = basicPlanDesignClass.IDICovers1stNotes,
                CoveredEarningsType = basicPlanDesignClass.ApprovedCoveredEarningsType,
                CoveredEarningsTypeNotes = basicPlanDesignClass.CoveredEarningsTypeNotes,
                FlatRateType = basicPlanDesignClass.ApprovedFlatRateType,
                FlatRate_Other = basicPlanDesignClass.ApprovedFlatRate_Other,
                RetirementContributionsType = basicPlanDesignClass.ApprovedRetirementContributionsType,
                RetirementContributionsNotes = basicPlanDesignClass.RetirementContributionNotes,
                AnnualContributions = basicPlanDesignClass.ApprovedAnnualContributions,
                AnnualContributionsNotes = basicPlanDesignClass.AnnualContributionsNotes,
                CoveredEarningsPercentage = basicPlanDesignClass.ApprovedCoveredEarningsPercentage,
                CoveredEarningsPercentageNotes = basicPlanDesignClass.CoveredEarningsPercentageNotes,
                RppRiderCoveredEarningsType = basicPlanDesignClass.ApprovedRppRiderCoveredEarningsType,
                RppRiderCoveredEarningsTypeNotes = basicPlanDesignClass.RppRiderCoveredEarningsTypeNotes,
                TaxabilityType = basicPlanDesignClass.ApprovedTaxabilityType,
                TaxabilityTypeNotes = basicPlanDesignClass.TaxabilityTypeNotes,
                CoveredEarningsBonusOnlyType = basicPlanDesignClass.ApprovedCoveredEarningsBonusOnlyType,
                TypeOfShareType = basicPlanDesignClass.ApprovedTypeOfShareType,
                EmployeePaidPremium = basicPlanDesignClass.ApprovedEmployeePaidPremium,
                EmployerPaidPremium = basicPlanDesignClass.ApprovedEmployerPaidPremium,
                EmployerPaidPremiumNotes = basicPlanDesignClass.EmployerPaidPremiumNotes,
                EmployerPaysupto = basicPlanDesignClass.ApprovedEmployerPaysupto,
                EmployerPaysuptoNotes = basicPlanDesignClass.EmployerPaysuptoNotes,
                CostShareTaxabilityType = basicPlanDesignClass.ApprovedCostShareTaxabilityType,
                BenefitPeriod = (BenefitPeriodTypeEnum)soldClassPlan.BenefitPeriodId,
                BenefitPeriodNotes = basicPlanDesignClass.BenefitPeriodNotes,
                EliminationPeriod = (EliminationPeriodTypeEnum)soldClassPlan.EliminationPeriodId,
                EliminationPeriodNotes = basicPlanDesignClass.EliminationPeriodNotes,
                GSIAmount = (int)soldClassPlan.GSIAmount,
                ParticipationPercentage = basicPlanDesignClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).ParticipationPercentage,
                BaseDiscountType = basicPlanDesignClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).BaseDiscountType,
                DemographicDiscountType = basicPlanDesignClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).DemographicDiscountType,


                EmployerPaidDiscountType = basicPlanDesignClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).EmployerPaidDiscountType,


                DefinitionOfDisabilityType = (DefinitionOfDisabilityTypeEnum)soldClassPlan.DefinitionOfDisabilityId,
                MentalSubstanceLimitationType = (MentalSubstanceLimitationEnum)soldClassPlan.MentalSubstanceId,
                PreExistingConditionLimitType = (PreExistingConditionLimitTypeEnum)soldClassPlan.PreExistingConditionLimitationId,
                TotalMaxGSIAmount = basicPlanDesignClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).TotalMaxGSIAmount,
                MinimumCaseLevelGSIAmount=basicPlanDesignClass.PlanDesignRequestClassProducts.FirstOrDefault(c=>c.IsGSIPlanIndicator == hasBuyUp).MinimumCaseLevelGSIAmount,
                DiscountOverride = basicPlanDesignClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).DiscountOverride,
                InsurableIncomeDefinition = basicPlanDesignClass.InsurableIncomeDefinition,
                IsOneStepEnrollmentIndicator = basicPlanDesignClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).IsOneStepEnrollmentIndicator,
                IsDirectCoverageIndicator = basicPlanDesignClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == hasBuyUp).IsDirectCoverageIndicator,

            };

            classPlan.PDRSoldClassPlanRiders = soldClassPlan.Benefits.Select(b => new PDRSoldClassPlanRiders
            {
                PDRSoldClassPlan = classPlan,
                BenefitType = (BenefitTypeEnum)b.BenefitId,
                BenefitPeriodType = b.BenefitPeriodId != null ? (BenefitPeriodTypeEnum?)b.BenefitPeriodId : null,
                EliminationPeriodType = b.EliminationPeriodId != null ? (EliminationPeriodTypeEnum?)b.EliminationPeriodId : null,
                ApprovedAmount = b.Amount ?? null,
                BenefitGroupType = (BenefitGroupTypeEnum)riderGroups.FirstOrDefault(rg => rg.Riders.Where(r => r.BenefitTypes.Contains((BenefitTypeEnum)b.BenefitId)).Any()).BenefitGroup.Id
            }).ToList();

            classPlan.PDRSoldClassPlanCustomizedIDIInsurableIncomes = basicPlanDesignClass.PDRClassCustomizedIDIInsurableIncomes.Where(c => c.IsGSIPlanIndicator == hasBuyUp).Select(c => new PDRSoldClassPlanCustomizedIDIInsurableIncome
            {
                BaseSalaryPercentage = c.BaseSalaryPercentage ?? null,
                BonusNumberofYears = c.BonusNumberofYears ?? null,
                BonusPercentage = c.BonusPercentage ?? null,
                CommissionNumberofYears = c.CommissionNumberofYears ?? null,
                CommissionPercentage = c.CommissionPercentage ?? null,
                K1EarningsNumberofYears = c.K1EarningsNumberofYears ?? null,
                K1EarningsPercentage = c.K1EarningsPercentage ?? null,
                OtherIncomePercentage = c.OtherIncomePercentage ?? null,
                PDRSoldClassPlan = classPlan
            }).ToList();

            classPlan.GSIBuyUpPlanNotes = basicPlanDesignClass.VoluntaryGSIBuyUpPlanNotes;

            if (hasBuyUp)
            {
                classPlan.PDRClassPlanType = PDRClassPlanTypeEnum.VoluntaryGSIBuyUp;
                classPlan.PlanDesignType = (PlanDesignTypeEnum)basicPlanDesignClass.ApprovedVoluntaryGSIBuyUpPlanDesignType;
                classPlan.GSIBuyUpPlanNotes = basicPlanDesignClass.VoluntaryGSIBuyUpPlanNotes;
                classPlan.GSIBuyUpPlanDesignNotes = basicPlanDesignClass.VoluntaryGSIBuyUpPlanDesignNotes;
                classPlan.CoveredEarningsType = basicPlanDesignClass.ApprovedGSIBuyUpCoveredEarningsType;
                classPlan.GSIBuyUpCoveredEarningsTypeNotes = basicPlanDesignClass.GSIBuyUpCoveredEarningsTypeNotes;
                classPlan.ReplacementPercentage = basicPlanDesignClass.ApprovedGSIBuyUpReplacementPercentage;
                classPlan.GSIBuyUpReplacementPercentageNotes = basicPlanDesignClass.GSIBuyUpReplacementPercentageNotes;
                classPlan.CoveredEarningsBonusOnlyType = basicPlanDesignClass.ApprovedGSIBuyUpCoveredEarningsBonusOnlyType;
            }
            else
            {
                classPlan.PDRClassPlanType = PDRClassPlanTypeEnum.Primary;
            }
            Log.TraceFormat("-CreateSoldClassPlan");

            return classPlan;
        }

        private bool? GetIsVoluntaryLTDBuyUpIndicator(PDRSoldClassLTDCoverage ltdCoverage)
        {
            if (ltdCoverage.PremiumAndTaxpayerLiabilityType != null &&
               (ltdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid ||
               ltdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable))
            {
                return true;
            }
            return null;
        }
    }
}
