﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using System.Collections.Generic;
using System.Linq;

namespace CMS.Managers.PlanManagers
{
    internal class PlanDesignRequestGetter
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;
        private const int defaultMinimumGSIAmount = 300;
        public PlanDesignRequestGetter(IUnitOfWorkFactory unitOfWorkFactory, IEligibilityConfigurationManager eligibilityConfigurationManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
        }
        public PlanDesignDto GetPlanDesignByCaseId(int caseId)
        {
            Log.TraceFormat("+GetPlanDesignByCaseId caseId={0}", caseId);

            var planDesign = new PlanDesignDto();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseUnderWrittingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == caseId);
                var caseUnderWrittingRequestDto = new CaseUnderwritingRequestDto();

                if (caseUnderWrittingRequest != null)
                {
                    caseUnderWrittingRequestDto.CaseId = caseId;
                    caseUnderWrittingRequestDto.SitusTypeId = caseUnderWrittingRequest.SitusType != null ? (int?)caseUnderWrittingRequest.SitusType.Value : null;
                    caseUnderWrittingRequestDto.StateTypeId = caseUnderWrittingRequest.StateType != null ? (int?)caseUnderWrittingRequest.StateType.Value : null;
                    caseUnderWrittingRequestDto.SitusMultiState1TypeId = caseUnderWrittingRequest.SitusMultiState1Type != null ? (int?)caseUnderWrittingRequest.SitusMultiState1Type.Value : null;
                    caseUnderWrittingRequestDto.SitusMultiState2TypeId = caseUnderWrittingRequest.SitusMultiState2Type != null ? (int?)caseUnderWrittingRequest.SitusMultiState2Type.Value : null;
                    caseUnderWrittingRequestDto.SitusMultiState3TypeId = caseUnderWrittingRequest.SitusMultiState3Type != null ? (int?)caseUnderWrittingRequest.SitusMultiState3Type.Value : null;
                    caseUnderWrittingRequestDto.IsCompactState = caseUnderWrittingRequest.IsCompactState != null ? caseUnderWrittingRequest.IsCompactState : null;
                    caseUnderWrittingRequestDto.Notes = caseUnderWrittingRequest.Notes;
                    caseUnderWrittingRequestDto.PricingTypeId = caseUnderWrittingRequest.PricingType != null ? (int?)caseUnderWrittingRequest.PricingType : null;
                }

                planDesign.CaseUnderwritingRequest = caseUnderWrittingRequestDto;
                planDesign.PlanDesignRequests = GetPlanDesignRequests(caseId);
            }

            Log.TraceFormat("-GetPlanDesignByCaseId");
            return planDesign;
        }

        public List<PlanDesignRequestDto> GetPlanDesignRequests(int caseId)
        {
            Log.TraceFormat("+GetPlanDesignRequests");
            var planDesignRequestDtos = new List<PlanDesignRequestDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignRequests = unitOfWork.Repository<PlanDesignRequest>().Linq().Where(c => c.Case.Id == caseId).ToList();

                if (planDesignRequests.Any())
                {


                    planDesignRequestDtos = planDesignRequests.Select(t => new PlanDesignRequestDto
                    {
                        PlanDesignRequestId = t.Id,
                        CaseId = t.Case.Id,
                        RequestHeaderName = t.GAPlanDesignRequestId != null ? t.GAPlanDesignRequestId : t.RequestHeaderName,
                        IsActive = t.IsActive,
                        InactiveDate = t.InactiveDate,
                        IsApproved = t.IsApproved,
                        IllustrationEffectiveDate = t.IllustrationEffectiveDate,
                        ExistingIllustrationEffectiveDate = t.IllustrationEffectiveDate,
                        IsSold = GetSoldIndicator(t),
                        PriorCoverageStatus = t.PriorCoverageStatus
                    }).ToList();
                }
            }
            Log.TraceFormat("-GetPlanDesignRequests");
            return planDesignRequestDtos;
        }

        public PlanDesignRequestClassDto GetPlanDesignRequestClass(int planDesignRequestClassId)
        {
            Log.TraceFormat("+GetPlanDesignRequestClass");

            var planDesignRequestClassDto = new PlanDesignRequestClassDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.Id == planDesignRequestClassId).First();
                var annualReviewStatus = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId && c.IsAnnualReviewComplete);
                //var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId);

                if (planDesignRequestClass != null)
                {
                    planDesignRequestClassDto.IsSold = false;
                    planDesignRequestClassDto.AnnualReviewCompleted = annualReviewStatus == null ? false : annualReviewStatus.IsAnnualReviewComplete;
                    planDesignRequestClassDto.PlanDesignRequestId = planDesignRequestClass.PlanDesignRequest.Id;
                    planDesignRequestClassDto.PlanDesignRequestClassId = planDesignRequestClass.Id;
                    planDesignRequestClassDto.PlanDesignRequestClassName = planDesignRequestClass.PlanDesignRequestClassName;
                    planDesignRequestClassDto.RequestedPlanDesignTypeId = planDesignRequestClass.RequestedPlanDesignType != null ? (int?)planDesignRequestClass.RequestedPlanDesignType : null;
                    planDesignRequestClassDto.ApprovedPlanDesignTypeId = planDesignRequestClass.ApprovedPlanDesignType != null ? (int?)planDesignRequestClass.ApprovedPlanDesignType : null;
                    planDesignRequestClassDto.ApprovedMaximumReplacementRatio = planDesignRequestClass.ApprovedMaximumReplacementRatio;
                    planDesignRequestClassDto.BenefitPeriodNotes = planDesignRequestClass.BenefitPeriodNotes;
                    planDesignRequestClassDto.RequestedEligiblePopulationText = planDesignRequestClass.RequestedEligiblePopulationText;
                    planDesignRequestClassDto.ApprovedEligiblePopulationText = planDesignRequestClass.ApprovedEligiblePopulationText;
                    planDesignRequestClassDto.EligiblePopulationTextNotes = planDesignRequestClass.EligiblePopulationTextNotes;
                    planDesignRequestClassDto.EliminationPeriodNotes = planDesignRequestClass.EliminationPeriodNotes;
                    planDesignRequestClassDto.MaximumReplacementRatioNotes = planDesignRequestClass.MaximumReplacementRatioNotes;
                    planDesignRequestClassDto.PlanDesignNotes = planDesignRequestClass.PlanDesignNotes;
                    planDesignRequestClassDto.RequestedLTDPercentage = planDesignRequestClass.RequestedLTDPercentage;
                    planDesignRequestClassDto.ApprovedLTDPercentage = planDesignRequestClass.ApprovedLTDPercentage;
                    planDesignRequestClassDto.LTDPercentageNotes = planDesignRequestClass.LTDPercentageNotes;
                    planDesignRequestClassDto.RequestedIDIPercentage = planDesignRequestClass.RequestedIDIPercentage;
                    planDesignRequestClassDto.ApprovedIDIPercentage = planDesignRequestClass.ApprovedIDIPercentage;
                    planDesignRequestClassDto.IDIPercentageNotes = planDesignRequestClass.IDIPercentageNotes;
                    planDesignRequestClassDto.RequestedPremiumPayerAndTaxabilityTypeId = planDesignRequestClass.RequestedPremiumPayerAndTaxabilityType != null ? (int?)planDesignRequestClass.RequestedPremiumPayerAndTaxabilityType.Id : null;
                    planDesignRequestClassDto.ApprovedPremiumPayerAndTaxabilityTypeId = planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType != null ? (int?)planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Id : null;
                    planDesignRequestClassDto.PremiumPayerAndTaxabilityNotes = planDesignRequestClass.PremiumPayerAndTaxabilityNotes;
                    planDesignRequestClassDto.RequestedCoveredEarningsTypeId = planDesignRequestClass.RequestedCoveredEarningsType != null ? (int?)planDesignRequestClass.RequestedCoveredEarningsType : null;
                    planDesignRequestClassDto.ApprovedCoveredEarningsTypeId = planDesignRequestClass.ApprovedCoveredEarningsType != null ? (int?)planDesignRequestClass.ApprovedCoveredEarningsType : null;
                    planDesignRequestClassDto.CoveredEarningsTypeNotes = planDesignRequestClass.CoveredEarningsTypeNotes;
                    planDesignRequestClassDto.RequestedCoveredEarningsTypeOther = planDesignRequestClass.RequestedCoveredEarningsTypeOther;
                    planDesignRequestClassDto.RequestedEliminationPeriodId = planDesignRequestClass.RequestedEliminationPeriod_Id != null ? (int?)planDesignRequestClass.RequestedEliminationPeriod_Id : null;
                    planDesignRequestClassDto.ApprovedEliminationPeriodTypeId = planDesignRequestClass.ApprovedEliminationPeriod != null ? (int?)planDesignRequestClass.ApprovedEliminationPeriod : null;
                    planDesignRequestClassDto.ApprovedEliminationPeriodTypeName = planDesignRequestClass.ApprovedEliminationPeriod != null ? planDesignRequestClass.ApprovedEliminationPeriod.ToString() : string.Empty;
                    planDesignRequestClassDto.RequestedBenefitPeriodId = planDesignRequestClass.RequestedBenefitPeriod_Id != null ? planDesignRequestClass.RequestedBenefitPeriod_Id : null;
                    planDesignRequestClassDto.ApprovedBenefitPeriodTypeId = planDesignRequestClass.ApprovedBenefitPeriod != null ? (int?)planDesignRequestClass.ApprovedBenefitPeriod : null;
                    planDesignRequestClassDto.ApprovedBenefitPeriodTypeName = planDesignRequestClass.ApprovedBenefitPeriod != null ? planDesignRequestClass.ApprovedBenefitPeriod.ToString() : string.Empty;
                    planDesignRequestClassDto.RequestedMaximumReplacementRatio = planDesignRequestClass.RequestedMaximumReplacementRatio;
                    planDesignRequestClassDto.RequestedIDICovers1st = planDesignRequestClass.RequestedIDICovers1st ?? null;
                    planDesignRequestClassDto.ApprovedIDICovers1st = planDesignRequestClass.ApprovedIDICovers1st ?? null;
                    planDesignRequestClassDto.IDICovers1stNotes = planDesignRequestClass.IDICovers1stNotes;
                    planDesignRequestClassDto.RequestedLTDCoversNext = planDesignRequestClass.RequestedLTDCoversNext ?? null;
                    planDesignRequestClassDto.ApprovedLTDCoversNext = planDesignRequestClass.ApprovedLTDCoversNext ?? null;
                    planDesignRequestClassDto.LTDCoversNextNotes = planDesignRequestClass.LTDCoversNextNotes;
                    planDesignRequestClassDto.RequestedFlatRateType_Id = planDesignRequestClass.RequestedFlatRateType != null ? (int?)planDesignRequestClass.RequestedFlatRateType.Id : null;
                    planDesignRequestClassDto.ApprovedFlatRateType_Id = planDesignRequestClass.ApprovedFlatRateType != null ? (int?)planDesignRequestClass.ApprovedFlatRateType.Id : null;
                    planDesignRequestClassDto.RequestedFlatRate_Other = planDesignRequestClass.RequestedFlatRate_Other;
                    planDesignRequestClassDto.ApprovedFlatRate_Other = planDesignRequestClass.ApprovedFlatRate_Other;
                    planDesignRequestClassDto.IsActive = planDesignRequestClass.IsActive;
                    planDesignRequestClassDto.CaseCompanyRetirementPlans = GetCaseCompanyRetirementPlan(planDesignRequestClass.Id);
                    planDesignRequestClassDto.RequestedRetirementContributionsTypeId = planDesignRequestClass.RequestedRetirementContributionsType != null ? (int?)planDesignRequestClass.RequestedRetirementContributionsType : null;
                    planDesignRequestClassDto.ApprovedRetirementContributionsTypeId = planDesignRequestClass.ApprovedRetirementContributionsType != null ? (int?)planDesignRequestClass.ApprovedRetirementContributionsType : null;
                    planDesignRequestClassDto.RetirementContributionNotes = planDesignRequestClass.RetirementContributionNotes;
                    planDesignRequestClassDto.RequestedAnnualContributions = planDesignRequestClass.RequestedAnnualContributions;
                    planDesignRequestClassDto.ApprovedAnnualContributions = planDesignRequestClass.ApprovedAnnualContributions;
                    planDesignRequestClassDto.AnnualContributionsNotes = planDesignRequestClass.AnnualContributionsNotes;
                    planDesignRequestClassDto.RequestedCoveredEarningsPercentage = planDesignRequestClass.RequestedCoveredEarningsPercentage ?? null;
                    planDesignRequestClassDto.ApprovedCoveredEarningsPercentage = planDesignRequestClass.ApprovedCoveredEarningsPercentage ?? null;
                    planDesignRequestClassDto.CoveredEarningsPercentageNotes = planDesignRequestClass.CoveredEarningsPercentageNotes;
                    planDesignRequestClassDto.RequestedRppRiderCoveredEarningsTypeId = planDesignRequestClass.RequestedRppRiderCoveredEarningsType != null ? (int?)planDesignRequestClass.RequestedRppRiderCoveredEarningsType : null;
                    planDesignRequestClassDto.ApprovedRppRiderCoveredEarningsTypeId = planDesignRequestClass.ApprovedRppRiderCoveredEarningsType != null ? (int?)planDesignRequestClass.ApprovedRppRiderCoveredEarningsType : null;
                    planDesignRequestClassDto.RppRiderCoveredEarningsTypeNotes = planDesignRequestClass.RppRiderCoveredEarningsTypeNotes;
                    planDesignRequestClassDto.RequestedRppRiderCoveredEarningsTypeOther = planDesignRequestClass.RequestedRppRiderCoveredEarningsTypeOther;
                    planDesignRequestClassDto.RequestedTaxabilityTypeId = planDesignRequestClass.RequestedTaxabilityType != null ? (int?)planDesignRequestClass.RequestedTaxabilityType : null;
                    planDesignRequestClassDto.ApprovedTaxabilityTypeId = planDesignRequestClass.ApprovedTaxabilityType != null ? (int?)planDesignRequestClass.ApprovedTaxabilityType : null;
                    planDesignRequestClassDto.TaxabilityTypeNotes = planDesignRequestClass.TaxabilityTypeNotes;
                    planDesignRequestClassDto.RequestedTypeOfShareTypeId = planDesignRequestClass.RequestedTypeOfShareType != null ? (int?)planDesignRequestClass.RequestedTypeOfShareType : null;
                    planDesignRequestClassDto.ApprovedTypeOfShareTypeId = planDesignRequestClass.ApprovedTypeOfShareType != null ? (int?)planDesignRequestClass.ApprovedTypeOfShareType : null;
                    planDesignRequestClassDto.RequestedEmployerPaidPremium = planDesignRequestClass.RequestedEmployerPaidPremium;
                    planDesignRequestClassDto.ApprovedEmployerPaidPremium = planDesignRequestClass.ApprovedEmployerPaidPremium;
                    planDesignRequestClassDto.EmployerPaidPremiumNotes = planDesignRequestClass.EmployerPaidPremiumNotes;
                    planDesignRequestClassDto.RequestedEmployeePaidPremium = planDesignRequestClass.RequestedEmployeePaidPremium;
                    planDesignRequestClassDto.ApprovedEmployeePaidPremium = planDesignRequestClass.ApprovedEmployeePaidPremium;
                    planDesignRequestClassDto.RequestedEmployerPaysupto = planDesignRequestClass.RequestedEmployerPaysupto;
                    planDesignRequestClassDto.ApprovedEmployerPaysupto = planDesignRequestClass.ApprovedEmployerPaysupto;
                    planDesignRequestClassDto.EmployerPaysuptoNotes = planDesignRequestClass.EmployerPaysuptoNotes;
                    planDesignRequestClassDto.IsRequestedVoluntaryGSIBuyUpPlan = planDesignRequestClass.IsRequestedVoluntaryGSIBuyUpPlan;
                    planDesignRequestClassDto.IsApprovedVoluntaryGSIBuyUpPlan = planDesignRequestClass.IsApprovedVoluntaryGSIBuyUpPlan;
                    planDesignRequestClassDto.VoluntaryGSIBuyUpPlanNotes = planDesignRequestClass.VoluntaryGSIBuyUpPlanNotes;
                    planDesignRequestClassDto.RequestedVoluntaryGSIBuyUpPlanDesignTypeId = planDesignRequestClass.RequestedVoluntaryGSIBuyUpPlanDesignType != null ? (int?)planDesignRequestClass.RequestedVoluntaryGSIBuyUpPlanDesignType : null;
                    planDesignRequestClassDto.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId = planDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType != null ? (int?)planDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType : null;
                    planDesignRequestClassDto.VoluntaryGSIBuyUpPlanDesignNotes = planDesignRequestClass.VoluntaryGSIBuyUpPlanDesignNotes;
                    planDesignRequestClassDto.RequestedGSIBuyUpCoveredEarningsTypeId = (int?)planDesignRequestClass.RequestedGSIBuyUpCoveredEarningsType;
                    planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsTypeId = planDesignRequestClass.ApprovedGSIBuyUpCoveredEarningsType != null ? (int?)planDesignRequestClass.ApprovedGSIBuyUpCoveredEarningsType : null;
                    planDesignRequestClassDto.RequestedGSIBuyUpCoveredEarningsBonusOnlyTypeId = (int?)planDesignRequestClass.RequestedGSIBuyUpCoveredEarningsBonusOnlyType;
                    planDesignRequestClassDto.ApprovedGSIBuyUpCoveredEarningsBonusOnlyTypeId = planDesignRequestClass.ApprovedGSIBuyUpCoveredEarningsBonusOnlyType != null ? (int?)planDesignRequestClass.ApprovedGSIBuyUpCoveredEarningsBonusOnlyType : null;
                    planDesignRequestClassDto.GSIBuyUpCoveredEarningsTypeNotes = planDesignRequestClass.GSIBuyUpCoveredEarningsTypeNotes;
                    planDesignRequestClassDto.RequestedGSIBuyUpReplacementPercentage = planDesignRequestClass.RequestedGSIBuyUpReplacementPercentage;
                    planDesignRequestClassDto.ApprovedGSIBuyUpReplacementPercentage = planDesignRequestClass.ApprovedGSIBuyUpReplacementPercentage;
                    planDesignRequestClassDto.GSIBuyUpReplacementPercentageNotes = planDesignRequestClass.GSIBuyUpReplacementPercentageNotes;
                    planDesignRequestClassDto.RequestedCoveredEarningsBonusOnlyTypeId = planDesignRequestClass.RequestedCoveredEarningsBonusOnlyType != null ? (int?)planDesignRequestClass.RequestedCoveredEarningsBonusOnlyType : null;
                    planDesignRequestClassDto.ApprovedCoveredEarningsBonusOnlyTypeId = planDesignRequestClass.ApprovedCoveredEarningsBonusOnlyType != null ? (int?)planDesignRequestClass.ApprovedCoveredEarningsBonusOnlyType : null;
                    planDesignRequestClassDto.GAPlanDesignRequestClassId = planDesignRequestClass.GAPlanDesignRequestClassId;
                    planDesignRequestClassDto.RequestedCostShareTaxabilityTypeId = planDesignRequestClass.RequestedCostShareTaxabilityType != null ? (int?)planDesignRequestClass.RequestedCostShareTaxabilityType.Id : null;
                    planDesignRequestClassDto.ApprovedCostShareTaxabilityTypeId = planDesignRequestClass.ApprovedCostShareTaxabilityType != null ? (int?)planDesignRequestClass.ApprovedCostShareTaxabilityType.Id : null;
                    planDesignRequestClassDto.PlanDesignRequestClassProducts = planDesignRequestClass.PlanDesignRequestClassProducts
                                .Select(p => new PlanDesignRequestClassProductDto
                                {
                                    PlanDesignRequestClassProductId = p.Id,
                                    PlanDesignRequestClassId = planDesignRequestClass.Id,
                                    GSIAmount = p.GSIAmount,
                                    BaseDiscountTypeId = (p.BaseDiscountType != null) ? (int?)p.BaseDiscountType.Id : null,
                                    DemographicDiscountTypeId = (p.DemographicDiscountType != null) ? (int?)p.DemographicDiscountType.Id : null,

                                    EmployerPaidDiscountTypeId = (p.EmployerPaidDiscountType != null) ? (int?)p.EmployerPaidDiscountType.Id : null,


                                    ParticipationPercentage = p.ParticipationPercentage,
                                    DefinitionOfDisabilityTypeId = (int)p.DefinitionOfDisabilityType,
                                    MentalSubstanceLimitationTypeId = (int)p.MentalSubstanceLimitationType,
                                    PreExistingConditionLimitTypeId = (int)p.PreExistingConditionLimitType,
                                    EliminationPeriodTypeId = p.EliminationPeriodType != null ? (int?)p.EliminationPeriodType : null,
                                    BenefitPeriodTypeId = p.BenefitPeriodType != null ? (int?)p.BenefitPeriodType : null,
                                    IsGSIPlanIndicator = p.IsGSIPlanIndicator,
                                    TotalMaxGSIAmount = p.TotalMaxGSIAmount,
                                    MinimumCaseLevelGSIAmount = (p.MinimumCaseLevelGSIAmount == 0 || p.MinimumCaseLevelGSIAmount == null) ?  defaultMinimumGSIAmount: p.MinimumCaseLevelGSIAmount,
                                    DiscountOverride = p.DiscountOverride,
                                    IsOneStepEnrollmentIndicator=p.IsOneStepEnrollmentIndicator,
                                    IsDirectCoverageIndicator = p.IsDirectCoverageIndicator

                                })
                                .ToList();
                    planDesignRequestClassDto.PlanDesignRequestClassRiders = planDesignRequestClass.PlanDesignRequestClassRiders
                                .Select(p => new PlanDesignRequestClassRiderDto
                                {
                                    PlanDesignRequestClassRiderId = p.Id,
                                    PlanDesignRequestClassId = planDesignRequestClass.Id,
                                    SelectedBenefitGroup = (int)p.BenefitGroupType,
                                    SelectedBenefitType = (int)p.BenefitType,
                                    SelectedEliminationPeriod = p.EliminationPeriodType != null ? (int?)p.EliminationPeriodType : null,
                                    SelectedBenefitPeriod = p.BenefitPeriodType != null ? (int?)p.BenefitPeriodType : null,
                                    ApprovedAmount = p.ApprovedAmount,
                                    IsGSIPlanIndicator = p.IsGSIPlanIndicator
                                })
                                .ToList();
                    planDesignRequestClassDto.PlanDesignRequestClassLTDCoverage = planDesignRequestClass.PlanDesignRequestClassLTDCoverage
                        .Select(p => new PlanDesignRequestClassLTDCoverageDto
                        {
                            PlanDesignRequestClassLTDCoverageId = p.Id,
                            PlanDesignRequestClassId = p.PlanDesignRequestClass.Id,
                            EligiblePopulationText = p.EligiblePopulationText,
                            CarrierText = p.CarrierText,
                            EliminationPeriodDays = p.EliminationPeriodDays,
                            BenefitPeriodDays = p.BenefitPeriodDays,
                            GroupLTDReplacementPercentage = p.GroupLTDReplacementPercentage,
                            GroupLTDCapAmount = p.GroupLTDCapAmount,
                            GroupLTDCoveredEarningsTypeId = (int)p.GroupLTDCoveredEarningsType,
                            PremiumAndTaxpayerLiabilityTypeId = (int)p.PremiumAndTaxpayerLiabilityType.Id,
                            TypeOfPayTypeId = p.TypeOfPayType != null ? (int?)p.TypeOfPayType : null,
                            IsVoluntaryLTDBuyUpIndicator = p.IsVoluntaryLTDBuyUpIndicator,
                            LTDBuyUpReplacementPercentage = p.LTDBuyUpReplacementPercentage,
                            LTDBuyUpLTDCapAmount = p.LTDBuyUpLTDCapAmount,
                            LTDBuyUpCoveredEarningsTypeId = p.LTDBuyUpCoveredEarningsType != null ? (int?)p.LTDBuyUpCoveredEarningsType : null,
                            IsLTDPlanExistingIndicator = p.IsLTDPlanExistingIndicator,
                            AdditionalDetailsText = p.AdditionalDetailsText,
                            BaseSalaryPercentage = p.BaseSalaryPercentage ?? null,
                            BonusNumberofYears = p.BonusNumberofYears ?? null,
                            BonusPercentage = p.BonusPercentage ?? null,
                            CommissionNumberofYears = p.CommissionNumberofYears ?? null,
                            CommissionPercentage = p.CommissionPercentage ?? null,
                            K1EarningsNumberofYears = p.K1EarningsNumberofYears ?? null,
                            K1EarningsPercentage = p.K1EarningsPercentage ?? null,
                            OtherIncomePercentage = p.OtherIncomePercentage ?? null,
                            IsLTDIncomes = true,
                            IsSold = false
                        }).FirstOrDefault();
                    planDesignRequestClassDto.PDRClassCustomizedIDIInsurableIncomes = planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes
                        .Select(c => new PDRClassCustomizedIDIInsurableIncomeDto
                        {
                            PDRClassCustomizedIDIInsurableIncomeId = c.Id,
                            PlanDesignRequestClassId = planDesignRequestClass.Id,
                            CaseId = planDesignRequestClass.PlanDesignRequest.Case.Id,
                            BaseSalaryPercentage = c.BaseSalaryPercentage,
                            BonusPercentage = c.BonusPercentage,
                            CommissionPercentage = c.CommissionPercentage,
                            K1EarningsPercentage = c.K1EarningsPercentage,
                            OtherIncomePercentage = c.OtherIncomePercentage,
                            BonusNumberofYears = c.BonusNumberofYears,
                            CommissionNumberofYears = c.CommissionNumberofYears,
                            K1EarningsNumberofYears = c.K1EarningsNumberofYears,
                            IsGSIPlanIndicator = c.IsGSIPlanIndicator
                        }).ToList();
                    planDesignRequestClassDto.EligibilityConfiguration = GetEligibiltyConfiguration(planDesignRequestClassDto.PlanDesignRequestClassId, planDesignRequestClassDto.PlanDesignRequestId);
                    planDesignRequestClassDto.DefaultEligibilityConfiguration = GetDefaultEligibiltyConfiguration();
                }
            }
            Log.TraceFormat("-GetPlanDesignRequestClass");
            return planDesignRequestClassDto;
        }

        public List<PlanDesignRequestClassDto> GetPlanDesignRequestClassHeaders(int planDesignRequestId)
        {
            Log.TraceFormat("+GetPlanDesignRequestClassHeaders");
            List<PlanDesignRequestClassDto> planDesignRequestClassDtos = new List<PlanDesignRequestClassDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().LinqWithTimeOut().Where(c => c.PlanDesignRequest.Id == planDesignRequestId);
                foreach (var obj in planDesignRequestClass)
                {
                    var objDto = new PlanDesignRequestClassDto();
                    objDto.PlanDesignRequestId = obj.PlanDesignRequest.Id;
                    objDto.PlanDesignRequestClassId = obj.Id;
                    objDto.PlanDesignRequestClassName = obj.PlanDesignRequestClassName;
                    objDto.RequestedEligiblePopulationText = obj.RequestedEligiblePopulationText;
                    objDto.ApprovedEligiblePopulationText = GetApprovedEligibleText(obj.PlanDesignRequest.Id, obj.Id, obj.ApprovedEligiblePopulationText, obj.RequestedEligiblePopulationText);
                    objDto.RequestedPremiumPayerAndTaxabilityTypeId = obj.RequestedPremiumPayerAndTaxabilityType != null ? (int?)obj.RequestedPremiumPayerAndTaxabilityType.Id : null;
                    objDto.ApprovedPremiumPayerAndTaxabilityTypeId = obj.ApprovedPremiumPayerAndTaxabilityType != null ? (int?)obj.ApprovedPremiumPayerAndTaxabilityType.Id : null;
                    objDto.EligibleParticipantsCount = (obj.CensusParticipants != null) ? obj.CensusParticipants.Where(p=> (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null)).Select(i=>i.Id).Count() : 0;
                    objDto.IsActive = obj.IsActive;
                    objDto.IsRequestedVoluntaryGSIBuyUpPlan = obj.IsRequestedVoluntaryGSIBuyUpPlan;
                    objDto.IsApprovedVoluntaryGSIBuyUpPlan = obj.IsApprovedVoluntaryGSIBuyUpPlan;
                    foreach (var objProd in obj.PlanDesignRequestClassProducts)
                    {
                        var objProductDto = new PlanDesignRequestClassProductDto();
                        objProductDto. PlanDesignRequestClassProductId = objProd.Id;
                        objProductDto.PlanDesignRequestClassId = obj.Id;
                        objProductDto.GSIAmount = objProd.GSIAmount;
                        objProductDto.BaseDiscountTypeId = (objProd.BaseDiscountType != null) ? (int?)objProd.BaseDiscountType.Id : null;
                        objProductDto.DemographicDiscountTypeId = (objProd.DemographicDiscountType != null) ? (int?)objProd.DemographicDiscountType.Id : null;

                        objProductDto.EmployerPaidDiscountTypeId = (objProd.EmployerPaidDiscountType != null) ? (int?)objProd.EmployerPaidDiscountType.Id : null;

                        objProductDto.ParticipationPercentage = objProd.ParticipationPercentage;
                        objProductDto.IsGSIPlanIndicator = objProd.IsGSIPlanIndicator;
                        objProductDto.MinimumCaseLevelGSIAmount = (objProd.MinimumCaseLevelGSIAmount == 0 || objProd.MinimumCaseLevelGSIAmount == null) ? defaultMinimumGSIAmount : objProd.MinimumCaseLevelGSIAmount;
                        objDto.PlanDesignRequestClassProducts.Add(objProductDto);
                    }
                    planDesignRequestClassDtos.Add(objDto);
                }
            }
            Log.TraceFormat("-GetPlanDesignRequestClassHeaders");
            return planDesignRequestClassDtos;
        }

        public EligibilityConfigurationDto GetEligibiltyConfiguration(int selectedRequestClassId, int planDesignRequestId)
        {
            var eligibilityConfigurationClassDto = new EligibilityConfigurationDto();
            eligibilityConfigurationClassDto.PlanDesignRequestClassId = selectedRequestClassId;
            eligibilityConfigurationClassDto.PlanDesignRequestId = planDesignRequestId;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().Where(c => c.Id == planDesignRequestId).FirstOrDefault();
                eligibilityConfigurationClassDto.CaseId = planDesignRequest.Case.Id;
            }
            eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
            return eligibilityConfigurationClassDto;
        }

        public EligibilityConfigurationDto GetDefaultEligibiltyConfiguration()
        {
            var eligibilityConfigurationClassDto = new EligibilityConfigurationDto();
            eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
            return eligibilityConfigurationClassDto;
        }

        public List<PlanDesignRequestClassDto> GetPlanDesignRequestClassesByCaseId(int caseId)
        {
            Log.TraceFormat("+GetPlanDesignRequestsByCaseId");
            var planDesignRequestClassDtos = new List<PlanDesignRequestClassDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var soldPdrClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Case.Id == caseId && c.IsActive).Select(d => d.PlanDesignRequestClass.Id).ToList();
                var planDesignRequestClasses = unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.IsActive && soldPdrClass.Contains(c.Id)).ToList();
                var participants = unitOfWork.Repository<Participant>().LinqWithTimeOut().Where(c => c.Census.Case.Id == caseId && (c.IsError == false || c.IsError == null) && (c.IsEligible == true || c.IsEligible == null) && c.IsActive == true);

                if (planDesignRequestClasses.Any())
                {
                    foreach (PlanDesignRequestClass planDesignRequestClass in planDesignRequestClasses)
                    {
                        PlanDesignRequestClassDto pdrcDto = new PlanDesignRequestClassDto();
                        pdrcDto.PlanDesignRequestId = planDesignRequestClass.PlanDesignRequest.Id;
                        pdrcDto.PlanDesignRequestHeaderName = planDesignRequestClass.PlanDesignRequest.RequestHeaderName;
                        pdrcDto.PlanDesignRequestClassId = planDesignRequestClass.Id;
                        pdrcDto.PlanDesignRequestClassName = planDesignRequestClass.PlanDesignRequestClassName;
                        pdrcDto.ApprovedEligiblePopulationText = GetApprovedEligibleText(planDesignRequestClass.PlanDesignRequest.Id, planDesignRequestClass.Id, planDesignRequestClass.ApprovedEligiblePopulationText, planDesignRequestClass.RequestedEligiblePopulationText);
                        pdrcDto.ApprovedPremiumPayerAndTaxabilityTypeId = planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType != null ? (int?)planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Id : null;

                        if (planDesignRequestClass.CensusParticipants != null)
                        {
                            participants = participants.Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClass.Id);
                            pdrcDto.EligibleParticipantsCount = (participants != null) ? participants.Count() : 0;
                        }

                        planDesignRequestClassDtos.Add(pdrcDto);
                    }
                }
            }
            Log.TraceFormat("-GetPlanDesignRequestsByCaseId");
            return planDesignRequestClassDtos;
        }
        private string GetApprovedEligibleText(int planDesignRquestId, int planDesignRequestclassId, string approvedEligiblePopulationText, string requestedEligiblePopulationText)
        {
            Log.TraceFormat("+GetApprovedEligibleText");
            string approvedText = string.Empty;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                approvedText = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Id == planDesignRquestId && c.PlanDesignRequestClass.Id == planDesignRequestclassId).Select(i => i.EligiblePopulationText).FirstOrDefault();
                if (string.IsNullOrEmpty(approvedText))
                {
                    approvedText = approvedEligiblePopulationText != null ? approvedEligiblePopulationText : requestedEligiblePopulationText;
                }
            }
            Log.TraceFormat("-GetApprovedEligibleText");
            return approvedText;
        }
        public int GetCorporateSitusStateByCaseId(int caseId)
        {
            Log.TraceFormat("+GetCorporateSitusStateByCaseId caseId={0}", caseId);
            int stateId = 0;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                var caseUnderWrittingRequest = cmsCase.CaseUnderwritingRequests.FirstOrDefault(c => c.Case.Id == caseId);

                if (caseUnderWrittingRequest != null)
                {
                    if (caseUnderWrittingRequest.SitusType == SitusTypeEnum.Corporate || caseUnderWrittingRequest.SitusType == SitusTypeEnum.Multi_State)
                    {
                        stateId = caseUnderWrittingRequest.StateType != null ? (int)caseUnderWrittingRequest.StateType : (int)StateTypeEnum.UN;
                    }
                    else
                    {
                        var caseCompanyLocation = cmsCase.CaseCompanyLocations.OrderByDescending(i => i.Id).FirstOrDefault();
                        stateId = caseCompanyLocation != null ? (int)caseCompanyLocation.StateType : (int)StateTypeEnum.UN;
                    }
                } 
            }

            Log.TraceFormat("-GetCorporateSitusStateByCaseId caseId={0}", caseId);
            return stateId;
        }

        private IList<CaseCompanyRetirementPlanDto> GetCaseCompanyRetirementPlan(int planDesignRequestClassId)
        {
            Log.TraceFormat("+GetCaseCompanyRetirementPlan");
            var caseCompanyRetirementPlanDto = new List<CaseCompanyRetirementPlanDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseCompanyRetirementPlan = unitOfWork.Repository<CaseCompanyRetirementPlan>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId).ToList();
                caseCompanyRetirementPlanDto = caseCompanyRetirementPlan.Select(c => new CaseCompanyRetirementPlanDto
                {
                    CaseCompanyRetirementPlanId = c.Id,
                    PlanDesignRequestClassId = c.PlanDesignRequestClass.Id,
                    CompanyRetirementPlanTypeId = c.CompanyRetirementPlanType != null ? (int?)c.CompanyRetirementPlanType.Id : null,
                    IsChecked = c.IsChecked
                }).ToList();
            }
            Log.TraceFormat("-GetCaseCompanyRetirementPlan");
            return caseCompanyRetirementPlanDto;
        }

        private bool GetSoldIndicator(PlanDesignRequest plandesignrequest)
        {
            Log.TraceFormat("+GetSoldIndicator");
            bool isSold = false;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Id == plandesignrequest.Id).ToList();
                if (pdrSoldClass != null && pdrSoldClass.Count > 0)
                    isSold = true;
            }

            Log.TraceFormat("-GetSoldIndicator");
            return isSold;
        }

    }
}
