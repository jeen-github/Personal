﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.ReleaseManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using Guardian.Core.Entities.Product.Enums;
using Common.Exceptions;
using CMS.Interfaces.Managers.ITAdminManagers;

namespace CMS.Managers.PlanManagers
{
    public class PlanDesignRequestManager : IPlanDesignRequestManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly PlanDesignRequestGetter _planDesignRequestGetter;
        private readonly PlanDesignRequestSaver _planDesignRequestSaver;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;
        private readonly ICompactStateManager _compactStateManager;

        public PlanDesignRequestManager(IUnitOfWorkFactory unitOfWorkFactory, IProductLibraryManager productLibraryManger, 
            IEligibilityConfigurationManager eligibilityConfigurationManager, IStatePricingTypeManager statePricingTypeManager
            ,ICompactStateManager compactStateManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
            _compactStateManager = compactStateManager;
            _planDesignRequestGetter = new PlanDesignRequestGetter(_unitOfWorkFactory, _eligibilityConfigurationManager);

            _planDesignRequestSaver = new PlanDesignRequestSaver
                (_unitOfWorkFactory, productLibraryManger, 
                _eligibilityConfigurationManager, statePricingTypeManager, _compactStateManager);
        }

        public PlanDesignDto GetPlanDesignByCaseId(int caseId)
        {
            return _planDesignRequestGetter.GetPlanDesignByCaseId(caseId);
        }

        public void SavePlanDesignRequest(PlanDesignDto request)
        {
            _planDesignRequestSaver.SavePlanDesignRequest(request);
        }

        public int SavePlanDesignRequestFromGA(PlanDesignDto request, bool isSaveClass)
        {
            return _planDesignRequestSaver.SavePlanDesignRequestFromGA(request, isSaveClass);
        }

        public void SaveBlankRequestClass(PlanDesignRequestClassDto request)
        {
            _planDesignRequestSaver.SaveBlankRequestClass(request);
        }

        public List<PlanDesignRequestDto> GetPlanDesignRequests(int caseId)
        {
            return _planDesignRequestGetter.GetPlanDesignRequests(caseId);
        }
        public List<PlanDesignRequestClassDto> GetPlanDesignRequestClassesByCaseId(int caseId)
        {
            return _planDesignRequestGetter.GetPlanDesignRequestClassesByCaseId(caseId);
        }

        public PlanDesignRequestClassDto GetPlanDesignRequestClass(int planDesignRequestClassId)
        {
            return _planDesignRequestGetter.GetPlanDesignRequestClass(planDesignRequestClassId);
        }

        public List<PlanDesignRequestClassDto> GetPlanDesignRequestClassHeaders(int planDesignRequestId)
        {
            return _planDesignRequestGetter.GetPlanDesignRequestClassHeaders(planDesignRequestId);
        }


        public void TogglePlanDesignRequestActivation(int planDesignRequestId)
        {
            Log.TraceFormat("+TogglePlanDesignRequest");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsPlanDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == planDesignRequestId);
                if (cmsPlanDesignRequest == null) return;

                bool activatePDR = !cmsPlanDesignRequest.IsActive;
                unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.PlanDesignRequest.Id == cmsPlanDesignRequest.Id).ToList().ForEach(c => { c.IsActive = activatePDR; });

                cmsPlanDesignRequest.IsActive = activatePDR;
                cmsPlanDesignRequest.InactiveDate = DateTime.Now;

                unitOfWork.Repository<PlanDesignRequest>().Save(cmsPlanDesignRequest);

                unitOfWork.Commit();
            }
            Log.TraceFormat("-TogglePlanDesignRequest");
        }

        public void TogglePlanDesignRequestClassActivation(int planDesignRequestClassId)
        {
            Log.TraceFormat("+TogglePlanDesignRequestClassActivation");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsPlanDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassId);
                if (cmsPlanDesignRequestClass == null) return;

                cmsPlanDesignRequestClass.IsActive = !cmsPlanDesignRequestClass.IsActive;

                if (cmsPlanDesignRequestClass.CensusParticipants != null)
                {
                    if (cmsPlanDesignRequestClass.CensusParticipants.Any())
                    {
                        cmsPlanDesignRequestClass.CensusParticipants.ToList().ForEach(c => { c.PlanDesignRequestClass = null; });
                    }
                }

                unitOfWork.Repository<PlanDesignRequestClass>().Save(cmsPlanDesignRequestClass);

                unitOfWork.Commit();
            }
            Log.TraceFormat("-TogglePlanDesignRequestClassActivation");
        }

        public void DeletePlanDesignRequestClass(int planDesignRequestClassId)
        {
            Log.TraceFormat("+DeletePlanDesignRequestClass");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsParticipant = unitOfWork.Repository<Participant>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId).ToList();
                if (cmsParticipant != null)
                {
                    foreach (var participant in cmsParticipant)
                    {
                        participant.PlanDesignRequestClass = null;
                        unitOfWork.Repository<Participant>().Save(participant);
                    }
                }

                var cmsPlanDesignRequestClassProduct = unitOfWork.Repository<PlanDesignRequestClassProduct>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId).ToList();
                if (cmsPlanDesignRequestClassProduct.Any())
                {
                    foreach (var product in cmsPlanDesignRequestClassProduct)
                    {
                        unitOfWork.Repository<PlanDesignRequestClassProduct>().Delete(product);
                    }
                }

                var cmsPlanDesignRequestClassRiders = unitOfWork.Repository<PlanDesignRequestClassRider>().Linq().Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId).ToList();
                if (cmsPlanDesignRequestClassRiders.Any())
                {
                    foreach (var riders in cmsPlanDesignRequestClassRiders)
                    {
                        unitOfWork.Repository<PlanDesignRequestClassRider>().Delete(riders);
                    }
                }

                var cmsEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId);
                if (cmsEligibilityConfiguration != null)
                {
                    unitOfWork.Repository<EligibilityConfiguration>().Delete(cmsEligibilityConfiguration);
                }
                var cmsPlanDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == planDesignRequestClassId);
                if (cmsPlanDesignRequestClass != null)
                {
                    cmsPlanDesignRequestClass.CensusParticipants = new List<Participant>();
                    unitOfWork.Repository<PlanDesignRequestClass>().Delete(cmsPlanDesignRequestClass);
                }

                unitOfWork.Commit();
            }
            Log.TraceFormat("-DeletePlanDesignRequestClass");
        }

        public void SavePDRStatusHistory(List<PDRReleaseDto> pdrReleaseDtoRequestList)
        {
            Log.TraceFormat("+SavePDRStatusHistory");
            int caseId = 0;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                foreach (var request in pdrReleaseDtoRequestList)
                {
                    var cmsplanDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == request.PDRId);
                    var cmsPlanDesignRequestStatusHistory = new PlanDesignRequestStatusHistory();
                    if (cmsplanDesignRequest != null)
                    {
                        cmsplanDesignRequest.PlanDesignRequestStatusType = (PlanDesignRequestStatusTypeEnum?)request.PlanDesignRequestStatusTypeId;
                        cmsPlanDesignRequestStatusHistory.PlanDesignRequest = cmsplanDesignRequest;
                        caseId = cmsplanDesignRequest.Case.Id;
                    }

                    cmsPlanDesignRequestStatusHistory.DateOfChange = DateTime.Now;
                    cmsPlanDesignRequestStatusHistory.ApprovedByUser_Id = request.LdapUserId;
                    cmsPlanDesignRequestStatusHistory.TitanUserUser_id = request.LdapUserId;
                    cmsPlanDesignRequestStatusHistory.PlanDesignRequestStatusType = (PlanDesignRequestStatusTypeEnum)request.PlanDesignRequestStatusTypeId;
                    cmsPlanDesignRequestStatusHistory.DeclinedByUser_Id = request.DeclinedByUserId;
                    cmsPlanDesignRequestStatusHistory.SecondSignature_Id = request.SecondSignatureId;
                    cmsPlanDesignRequestStatusHistory.DeclineReason = request.DeclineReason;

                    if (cmsplanDesignRequest.Illustrations != null)
                    {
                        if (request.PlanDesignRequestStatusTypeId == (int)PlanDesignRequestStatusTypeEnum.Withdrawn)
                        {
                            foreach (var illustraion in cmsplanDesignRequest.Illustrations)
                            {
                                illustraion.IsActiveIndicator = false;
                                illustraion.IsWithdrawnIndicator = true;
                                illustraion.WithdrawnBy = request.LdapUserId;
                                illustraion.WithdrawnDateTime = DateTime.Now;
                            }
                        }
                    }

                    unitOfWork.Repository<PlanDesignRequest>().Save(cmsplanDesignRequest);
                    unitOfWork.Repository<PlanDesignRequestStatusHistory>().Save(cmsPlanDesignRequestStatusHistory);
                }
                unitOfWork.Commit();
            }

            SaveCaseStatus(caseId);

            Log.TraceFormat("-SavePDRStatusHistory");
        }
        public List<PlanDesignRequestDto> GetPlanDesignRequestsByTitanCasenumber(string titancasenumber)
        {
            Log.TraceFormat("+GetPlanDesignRequestsByTitanCasenumber");
            List<PlanDesignRequestDto> planDesignRequestDtos;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                planDesignRequestDtos = unitOfWork.Repository<PlanDesignRequest>().Linq().Where(c => c.Case.CaseNumber == titancasenumber && c.IsActive)
                    .Select(t => new PlanDesignRequestDto
                    {
                        PlanDesignRequestId = t.Id,
                        GAPlanDesignRequestId = t.GAPlanDesignRequestId ?? Convert.ToString(t.Id),
                        GAPDRName = !string.IsNullOrEmpty(t.PDRName) ? t.PDRName : t.RequestHeaderName,
                        PlanDesignRequestStatusType = t.PlanDesignRequestStatusType ?? PlanDesignRequestStatusTypeEnum.UnderwritingReview,
                        Illustrations = t.Illustrations.Where(i => i.IsActiveIndicator && i.IsWithdrawnIndicator != true && i.IsReleased == true)
                        .Select(c => new IllustrationDto
                        {
                            IllustrationId = c.Id,
                            QuoteName = c.QuoteName,
                            LikelyToSellIndicator = c.LikelyToSellIndicator,
                            PdfFileNetDocumentId = c.RateSheetPdfDocument != null && c.RateSheetPdfDocument.IsDocumentReady() ? c.RateSheetPdfDocument.Id : (long?)null,
                            ExcelFileNetDocumentId = c.RateSheetExcelDocument != null && c.RateSheetExcelDocument.IsDocumentReady() ? c.RateSheetExcelDocument.Id : (long?)null,
                            ProductSummaryId = c.ProductSummaryDocument != null && c.ProductSummaryDocument.IsDocumentReady() ? c.ProductSummaryDocument.Id : (long?)null,
                            ProgramSummaryId = c.ProgramSummaryDocument != null && c.ProgramSummaryDocument.IsDocumentReady() ? c.ProgramSummaryDocument.Id : (long?)null,
                            RequestJsonText = c.RequestJsonText,
                            GAStatusType = c.IllustrationGAStatusType,
                            GaStatusId = c.IllustrationGAStatusType != null ? (int)c.IllustrationGAStatusType : 0,
                            GaStatusName = c.IllustrationGAStatusType != null ? c.IllustrationGAStatusType.GetDescription() : ""
                        }).ToList()
                    }).ToList();

                SetGaStatuses(planDesignRequestDtos, unitOfWork);
            }

            Log.TraceFormat("-GetPlanDesignRequestsByTitanCasenumber");
            return planDesignRequestDtos;
        }

        private void SetGaStatuses(List<PlanDesignRequestDto> planDesignRequestDtos, IUnitOfWork unitOfWork)
        {
            var pdrGaStatusMap = unitOfWork.Repository<PlanDesignRequestGAStatusMap>().Linq().ToDictionary(m => m.PlanDesignRequestStatusType, s => s.GAStatusName);

            foreach (var planDesignRequestDto in planDesignRequestDtos)
            {
                var pdrStatusType = planDesignRequestDto.PlanDesignRequestStatusType;
                var pdrHistory = unitOfWork.Repository<PlanDesignRequestStatusHistory>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.PlanDesignRequest.Id == planDesignRequestDto.PlanDesignRequestId);
                if (pdrHistory != null)
                {
                    pdrStatusType = pdrHistory.PlanDesignRequestStatusType;
                }
                planDesignRequestDto.GAPDRStatus = pdrGaStatusMap[pdrStatusType];
                foreach (var illustrationDto in planDesignRequestDto.Illustrations)
                {
                    illustrationDto.GaStatusId = illustrationDto.GAStatusType != null ? (int)illustrationDto.GAStatusType : 0;
                    illustrationDto.GaStatusName = illustrationDto.GAStatusType != null ? illustrationDto.GAStatusType.GetDescription() : string.Empty;

                    if (illustrationDto.GAStatusType == IllustrationGAStatusTypeEnum.QuoteRequested
                        && illustrationDto.PdfFileNetDocumentId != null
                        //&& illustrationDto.ExcelFileNetDocumentId != null
                        //&& illustrationDto.ProductSummaryId != null  // Uncomment when Product Summary is available from Exstream.
                        //&& illustrationDto.ProgramSummaryId != null  // Uncomment when Program Summary is available from Exstream.
                        )
                    {
                        illustrationDto.GaStatusId = (int)IllustrationGAStatusTypeEnum.QuoteAvailable;
                        illustrationDto.GaStatusName = IllustrationGAStatusTypeEnum.QuoteAvailable.GetDescription();
                    }
                }
            }
        }

        public void SavePDRCustomizedIncomes(PDRClassCustomizedIDIInsurableIncomeDto request)
        {
            _planDesignRequestSaver.SavePDRCustomizedIncomes(request);
        }

        public void SavePDRLTDCustomizedIncomes(PlanDesignRequestClassLTDCoverageDto request)
        {
            _planDesignRequestSaver.SavePDRLTDCustomizedIncomes(request);
        }

        public int GetCorporateSitusStateByCaseId(int caseId)
        {
            return _planDesignRequestGetter.GetCorporateSitusStateByCaseId(caseId);
        }

        private void SaveCaseStatus(int caseId)
        {
            Log.TraceFormat("+SaveCaseStatus from release tab Case Id : {0} ", caseId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);

                if(cmsCase == null) throw new ValidationException("Case not found!");

                var plandesignRequests = cmsCase.PlanDesignRequests.Where(c => c.IsActive);

                bool blnStatusChanged = false;

                var hasApprovedAndReleased = plandesignRequests.Any(c => c.PlanDesignRequestStatusType == PlanDesignRequestStatusTypeEnum.Released);// No need to check for Approved. because Released status appears after approval

                if (hasApprovedAndReleased)
                {
                    blnStatusChanged = true;
                    cmsCase.CaseStatusType = CaseStatusTypeEnum.InitialOfferApproved;
                }
                else
                {
                    var hasDeclined = plandesignRequests.Any(c => c.PlanDesignRequestStatusType == PlanDesignRequestStatusTypeEnum.Declined);

                    if (hasDeclined)
                    {
                        blnStatusChanged = true;
                        cmsCase.CaseStatusType = CaseStatusTypeEnum.InitialOfferDeclined;
                    }
                    else // No decline and no approval
                    {
                        var hasWithdrawn = plandesignRequests.Any(c => c.PlanDesignRequestStatusType == PlanDesignRequestStatusTypeEnum.Withdrawn);

                        if (hasWithdrawn)
                        {
                            blnStatusChanged = true;
                            cmsCase.CaseStatusType = CaseStatusTypeEnum.InitialOfferWithdrawn;
                        }
                    }
                }
                if (blnStatusChanged)
                {
                    unitOfWork.Repository<Case>().Save(cmsCase);
                    unitOfWork.Commit();
                }
            }

            Log.TraceFormat("-SaveCaseStatus from release tab Case Id : {0} ", caseId);
        }
    }
}
