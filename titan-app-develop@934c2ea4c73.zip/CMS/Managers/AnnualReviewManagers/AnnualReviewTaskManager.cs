﻿using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Interfaces.Managers.TaskManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.DataAccess;
using Logger.Static;
using CMS.Model.Entities;
using System.Linq;
using System;

namespace CMS.Managers.AnnualReviewManagers
{
    public class AnnualReviewTaskManager : IWorkUnitHandler
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly ITaskManager _taskManager;
        private readonly IPlanDesignRequestSoldManager _planDesignRequestSoldManager;
        public AnnualReviewTaskManager(IUnitOfWorkFactory unitOfWorkFactory, ITaskManager taskManager, IPlanDesignRequestSoldManager planDesignRequestSoldManager)
        {
            _taskManager = taskManager;
            _unitOfWorkFactory = unitOfWorkFactory;
            _planDesignRequestSoldManager = planDesignRequestSoldManager;
        }

        public void Execute(WorkUnit workUnit)
        {

        }
    }
}