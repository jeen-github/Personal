﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.AnnualReviewManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using Common.Exceptions;
using Logger.Static;
using System.Linq;
using CMS.Interfaces.Managers.TaskManagers;
using System;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using CMS.Interfaces.Managers.CaseManagers;

namespace CMS.Managers.AnnualReviewManagers
{
    public class AnnualReviewManager : IAnnualReviewManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IPlanDesignRequestSoldManager _planDesignRequestSoldManager;
        private readonly IWorkUnitManager _workUnitManager;
        private readonly ICaseManager _caseManager;

        public AnnualReviewManager(IUnitOfWorkFactory unitOfWorkFactory, IPlanDesignRequestSoldManager planDesignRequestSoldManager, 
            IWorkUnitManager workUnitManager, ICaseManager caseManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _planDesignRequestSoldManager = planDesignRequestSoldManager;
            _workUnitManager = workUnitManager;
            _caseManager = caseManager;
        }

        public ReviewDto GetAnnualReviewsByCaseId(int caseId)
        {
            Log.TraceFormat("+GetAnnualReviewsByCaseId");

            var reviewDto = new ReviewDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollments = unitOfWork.Repository<Enrollment>().Linq().Where(e => e.Case.Id == caseId);
                if (enrollments.Any())
                {
                    var enrollment = enrollments.OrderByDescending(t => t.Id).FirstOrDefault();

                    reviewDto.CaseId = caseId;
                    reviewDto.OriginalEffectiveDate = enrollment.EffectiveDate;
                }
                var annualReview = unitOfWork.Repository<AnnualReview>().Linq().Where(e => e.Case.Id == caseId).OrderByDescending(a => a.CreatedDate).ToList();
                if (annualReview.Any())
                {
                    var isVoluntary = _planDesignRequestSoldManager.IsVoluntaryPremiumPayerClass(caseId);

                    reviewDto.AnnualReviews = annualReview.Select(a => new AnnualReviewDto
                    {
                        AnnualReviewId = a.Id,
                        AnnualReviewDate = a.AnnualReviewDate,
                        CreatedDate = a.CreatedDate,
                        AnnualReviewStatusTypeId = a.AnnualReviewStatusType != null ? (int?)a.AnnualReviewStatusType : null,
                        AnnualReviewStatusTypeDescription = a.AnnualReviewStatusType != null ? a.AnnualReviewStatusType.GetDescription() : null,
                        ReviewerId = a.Reviewer_Id,
                        NextAnniversaryDate = a.NextAnniversaryDate,
                        CalendarYear = a.CalendarYear,
                        CaseYear = a.CaseYear,
                        OriginalEffectiveDate = reviewDto.OriginalEffectiveDate == null ? DateTime.Now : reviewDto.OriginalEffectiveDate.Value,
                        AnnualReviewTaskWorkUnitId = a.AnnualReviewTaskWorkUnit != null ? (int?)a.AnnualReviewTaskWorkUnit.Id : null,
                        IsVoluntary = isVoluntary
                    }).ToList();
                }

            }
            Log.TraceFormat("-GetAnnualReviewsByCaseId");
            return reviewDto;
        }

        public void UpdateAnnualReviewInformation(AnnualReviewDto annualReviewDto, bool fromBeginAnnualReview = false)
        {
            Log.TraceFormat("+SaveAnnualReviewInformation");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var annualReview = unitOfWork.Repository<AnnualReview>().Linq().FirstOrDefault(c => c.Id == annualReviewDto.AnnualReviewId);
                if (annualReview == null)
                {
                    throw new ValidationException("Annual review not found!");
                }
                annualReview.Id = annualReviewDto.AnnualReviewId;
                annualReview.AnnualReviewDate = annualReviewDto.AnnualReviewDate;
                annualReview.NextAnniversaryDate = annualReviewDto.NextAnniversaryDate;
                annualReview.CalendarYear = annualReviewDto.CalendarYear;
                annualReview.CaseYear = annualReviewDto.CaseYear;
                annualReview.AnnualReviewStatusType = annualReviewDto.AnnualReviewStatusTypeId != null ? (AnnualReviewStatusTypeEnum?)annualReviewDto.AnnualReviewStatusTypeId : null;
                if (fromBeginAnnualReview)
                {
                    annualReview.AnnualReviewTaskWorkUnit = unitOfWork.Repository<WorkUnit>().Linq().FirstOrDefault(c => c.Id == annualReviewDto.AnnualReviewTaskWorkUnitId);
                }
                else
                {
                    UpdateAnnualReviewTaskWorkUnit(annualReviewDto);
                }
                unitOfWork.Repository<AnnualReview>().Save(annualReview);

                unitOfWork.Commit();
            }

            if(annualReviewDto.AnnualReviewStatusTypeId != null)
            {
                if(annualReviewDto.AnnualReviewStatusTypeId == (int)AnnualReviewStatusTypeEnum.Annual_Review_Approved)
                {
                    var request = new CaseStatusDto
                    {
                        CaseId = annualReviewDto.CaseId,
                        CaseStatusType = CaseStatusTypeEnum.Active,
                        PlanDesignRequestStatusType = null,
                    };
                    _caseManager.SaveCaseStatusAndPDRStatus(request);
                }
                else if (annualReviewDto.AnnualReviewStatusTypeId == (int)AnnualReviewStatusTypeEnum.Withdraw_Case)
                {
                    var request = new CaseStatusDto
                    {
                        CaseId = annualReviewDto.CaseId,
                        CaseStatusType = CaseStatusTypeEnum.Withdrawn,
                        PlanDesignRequestStatusType = null,
                    };
                    _caseManager.SaveCaseStatusAndPDRStatus(request);

                    _caseManager.UpdatePDRStatusByCase(request.CaseId, PlanDesignRequestStatusTypeEnum.Withdrawn);
                }
            }

            Log.TraceFormat("-SaveAnnualReviewInformation");
        }

        public void BeginAnnualReview(AnnualReviewDto annualReviewDto)
        {
            Log.TraceFormat("+BeginAnnualReview");

            try
            {
                annualReviewDto.NotesId = SaveAnnualReviewNotes(annualReviewDto);
                annualReviewDto.AnnualReviewId = GenerateAnnualReviewId(annualReviewDto);
                TimeSpan timeSpan = annualReviewDto.NextAnniversaryDate.Value - DateTime.UtcNow;

                annualReviewDto.AnnualReviewTaskWorkUnitId = _workUnitManager.CreateWorkUnit(WorkUnitType.AnnualReviewTask, annualReviewDto.AnnualReviewId.ToString(), timeSpan);

                UpdateAnnualReviewInformation(annualReviewDto, true);

                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    object[] parameters = new object[5];
                    parameters[0] = annualReviewDto.CaseId;
                    parameters[1] = annualReviewDto.AnnualReviewId;
                    parameters[2] = annualReviewDto.CalendarYear;
                    parameters[3] = annualReviewDto.CaseYear;
                    parameters[4] = annualReviewDto.ReviewerId;

                    unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_AnnualReviewCaseCopySnapshot] :@CaseId, :@AnnualReviewId, :@CalendarYear, :@CaseYear, :@TitanUserid", parameters);
                    unitOfWork.Commit();

                }

                var request = new CaseStatusDto
                {
                    CaseId = annualReviewDto.CaseId,
                    CaseStatusType = CaseStatusTypeEnum.AnnualReviewPending,
                    PlanDesignRequestStatusType = null,
                };

                _caseManager.SaveCaseStatusAndPDRStatus(request);
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR on generating Annual Review CaseCopy snapshot", ex);
                throw;
            }

            Log.TraceFormat("-BeginAnnualReview");
        }

        private int GenerateAnnualReviewId(AnnualReviewDto annualReviewDto)
        {
            Log.TraceFormat("+GenerateAnnualReviewId");

            int annualReviewId;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var annualReview = unitOfWork.Repository<AnnualReview>().Linq().FirstOrDefault(c => c.Id == annualReviewDto.AnnualReviewId);

                if (annualReview == null)
                {
                    annualReview = new AnnualReview();
                    annualReview.Case = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == annualReviewDto.CaseId);
                    annualReview.Notes = unitOfWork.Repository<Notes>().Linq().FirstOrDefault(c => c.Id == annualReviewDto.NotesId);
                    annualReview.CreatedDate = annualReviewDto.CreatedDate;
                }

                annualReview.Case.Id = annualReviewDto.CaseId;
                annualReview.AnnualReviewDate = annualReviewDto.AnnualReviewDate;
                annualReview.NextAnniversaryDate = annualReviewDto.NextAnniversaryDate;
                annualReview.CalendarYear = annualReviewDto.CalendarYear;
                annualReview.CaseYear = annualReviewDto.CaseYear;
                annualReview.AnnualReviewStatusType = (AnnualReviewStatusTypeEnum?)annualReviewDto.AnnualReviewStatusTypeId;

                unitOfWork.Repository<AnnualReview>().Save(annualReview);
                unitOfWork.Commit();

                annualReviewId = annualReview.Id;
            }

            Log.TraceFormat("-GenerateAnnualReviewId");

            return annualReviewId;

        }

        private int SaveAnnualReviewNotes(AnnualReviewDto annualReviewDto)
        {

            Log.TraceFormat("+SaveAnnualReviewNotes");

            int notesId;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var notes = unitOfWork.Repository<Notes>().Linq().FirstOrDefault(c => c.Id == annualReviewDto.NotesId);

                if (notes == null)
                {
                    notes = new Notes();
                    notes.Case = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == annualReviewDto.CaseId);
                }

                notes.NotesCategoryType = NotesCategoryTypeEnum.AnnualReview_Tab;
                notes.NotesText = annualReviewDto.NotesText;

                unitOfWork.Repository<Notes>().Save(notes);
                unitOfWork.Commit();

                notesId = notes.Id;
            }

            Log.TraceFormat("-SaveAnnualReviewNotes");

            return notesId;
        }

        private void UpdateAnnualReviewTaskWorkUnit(AnnualReviewDto annualReviewDto)
        {
            Log.TraceFormat("+UpdateAnnualReviewTaskWorkUnit");

            WorkUnitDto workUnitDto = new WorkUnitDto();
            workUnitDto.WorkUnitId = annualReviewDto.AnnualReviewTaskWorkUnitId.HasValue ? annualReviewDto.AnnualReviewTaskWorkUnitId.Value : 0;
            workUnitDto.StartDate = annualReviewDto.AnnualReviewDate;
            workUnitDto.HandlerName = WorkUnitType.AnnualReviewTask.ToString();
            workUnitDto.InputData = annualReviewDto.AnnualReviewId.ToString();
            _workUnitManager.UpdateWorkUnit(workUnitDto);

            Log.TraceFormat("-UpdateAnnualReviewTaskWorkUnit");
        }
    }
}
