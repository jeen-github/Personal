﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.ContactAddressManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Exceptions;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using System.Collections.Generic;
using System.Linq;


namespace CMS.Managers.ContactAddressManagers
{
    public class ContactAddressManager : IContactAddressManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly ContactAddressManagerValidator _contactAddressManagerValidatorValidator;

        public ContactAddressManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _contactAddressManagerValidatorValidator = new ContactAddressManagerValidator();
        }
        public List<ContactAddressDto> GetContactAddressDetailsByCaseId(int caseId)
        {
            Log.TraceFormat("+GetContactAddressDetailsByCaseId caseId={0}", caseId);

            var contactAddressDtoList = new List<ContactAddressDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var contactAddress = unitOfWork.Repository<ContactAddress>().Linq().Where(c => c.Case.Id == caseId);
                if (contactAddress == null) throw new ValidationException("Address not found!");
                contactAddressDtoList = contactAddress.Select(c => new ContactAddressDto
                {
                    ContactAddressId = c.Id,
                    CaseId = c.Case.Id,
                    ContactRoleTypeId = (int)c.ContactRoleType,
                    ContactName = c.ContactName,
                    Email = c.Email,
                    Phone = c.Phone,
                    IsPrimary = c.IsPrimary
                }).ToList();

            }
            Log.TraceFormat("-GetContactAddressDetailsByCaseId caseId={0}", caseId);
            return contactAddressDtoList;
        }

        public ContactAddressDto GetContactAddressDetailsByAddressId(int contactAddressId)
        {
            Log.TraceFormat("+GetContactAddressDetailsByAddressId");
            var contactAddressDto = new ContactAddressDto();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var contactAddress = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Id == contactAddressId);
                if (contactAddress != null)
                {
                    contactAddressDto.ContactAddressId = contactAddress.Id;
                    contactAddressDto.CaseId = contactAddress.Case.Id;
                    contactAddressDto.ContactRoleTypeId = (int)contactAddress.ContactRoleType;
                    contactAddressDto.DISCode = contactAddress.DISCode;
                    contactAddressDto.ProducerNumber = contactAddress.ProducerNumber;
                    contactAddressDto.OtherRole = contactAddress.OtherRole;
                    contactAddressDto.ContactName = contactAddress.ContactName;
                    contactAddressDto.IsPrimary = contactAddress.IsPrimary;
                    contactAddressDto.CompanyName = contactAddress.CompanyName;
                    contactAddressDto.AddressLine1 = contactAddress.AddressLine1;
                    contactAddressDto.AddressLine2 = contactAddress.AddressLine2;
                    contactAddressDto.City = contactAddress.City;
                    contactAddressDto.StateTypeId = (int?)contactAddress.StateType;
                    contactAddressDto.ZipCode = contactAddress.ZipCode;
                    contactAddressDto.Email = contactAddress.Email;
                    contactAddressDto.WebPage = contactAddress.WebPage;
                    contactAddressDto.Phone = contactAddress.Phone;
                    contactAddressDto.Extention = contactAddress.Extention;
                    contactAddressDto.Mobile = contactAddress.Mobile;
                    contactAddressDto.Fax = contactAddress.Fax;
                    contactAddressDto.Preferences = contactAddress.Preferences;
                    contactAddressDto.JobTitle = contactAddress.JobTitle;
                    contactAddressDto.ContactAddressCategory = contactAddress.ContactAddressCategories.Select(x => new ContactAddressCategoryDto
                    {
                        ContactAddressCategoryId = x.Id,
                        IsPrimary = x.IsPrimary,
                        ContactAddressId = contactAddress.Id,
                        IsSelected = x.IsSelect,
                        ContactAddressCategoryTypeId = x.ContactAddressCategoryType != null ? x.ContactAddressCategoryType.Id : 0
                    }).ToList();
                }
            }
            Log.TraceFormat("+GetContactAddressDetailsByAddressId");
            return contactAddressDto;
        }

        public void RemoveContactAddressDetails(int contactAddressId)
        {
            Log.TraceFormat("+RemoveContactAddressDetails contactAddressId={0}", contactAddressId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var contactAddress = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Id == contactAddressId);
                if (contactAddress != null)
                {
                    unitOfWork.Repository<ContactAddress>().Delete(contactAddress);
                }
                unitOfWork.Commit();
            }
            Log.TraceFormat("-RemoveContactAddressDetails contactAddressId={0}", contactAddressId);
        }

        public void SaveEditContactAddressDetails(ContactAddressDto contactAddressDto)
        {
            Log.TraceFormat("+SaveEditContactAddressDetails");
            _contactAddressManagerValidatorValidator.ValidateEditSaveContactAddressInformation(contactAddressDto);
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var contactAddress = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Id == contactAddressDto.ContactAddressId);
                if (contactAddress == null)
                {
                    contactAddress = new ContactAddress();
                    contactAddress.Case = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == contactAddressDto.CaseId);
                }

                contactAddress.ContactRoleType = (ContactRoleTypeEnum)contactAddressDto.ContactRoleTypeId;
                contactAddress.DISCode = contactAddressDto.DISCode;
                contactAddress.ProducerNumber = contactAddressDto.ProducerNumber;
                contactAddress.OtherRole = contactAddressDto.OtherRole;
                contactAddress.ContactName = contactAddressDto.ContactName;
                contactAddress.IsPrimary = contactAddressDto.IsPrimary;
                contactAddress.CompanyName = contactAddressDto.CompanyName;
                contactAddress.AddressLine1 = contactAddressDto.AddressLine1;
                contactAddress.AddressLine2 = contactAddressDto.AddressLine2;
                contactAddress.City = contactAddressDto.City;
                contactAddress.StateType = (StateTypeEnum?)contactAddressDto.StateTypeId;
                contactAddress.ZipCode = contactAddressDto.ZipCode;
                contactAddress.Email = contactAddressDto.Email;
                contactAddress.WebPage = contactAddressDto.WebPage;
                contactAddress.Phone = contactAddressDto.Phone;
                contactAddress.Extention = contactAddressDto.Extention;
                contactAddress.Mobile = contactAddressDto.Mobile;
                contactAddress.Fax = contactAddressDto.Fax;
                contactAddress.Preferences = contactAddressDto.Preferences;
                contactAddress.JobTitle = contactAddressDto.JobTitle;
                if (contactAddressDto.ContactAddressCategory != null)
                {
                    UpdateContactAddressCategories(contactAddressDto, unitOfWork, contactAddress);
                }
                unitOfWork.Repository<ContactAddress>().Save(contactAddress);

                unitOfWork.Commit();
            }
            Log.TraceFormat("-SaveEditContactAddressDetails");
        }

        private void UpdateContactAddressCategories(ContactAddressDto request, IUnitOfWork unitOfWork, ContactAddress contactAddress)
        {
            Log.TraceFormat("+UpdateContactAddressCategories");
            var caseContactAddressCategories = unitOfWork.Repository<ContactAddressCategory>().Linq().Where(c => c.ContactAddress.Id == request.ContactAddressId).ToList();
            var contactAddressCategoryTypes = unitOfWork.Repository<ContactAddressCategoryType>().Linq().ToList();

            foreach (var contactAddressCategoryDto in request.ContactAddressCategory)
            {
                var contactAddressCategory = caseContactAddressCategories.FirstOrDefault(c => c.Id == contactAddressCategoryDto.ContactAddressCategoryId);
                if (contactAddressCategory == null)
                {
                    contactAddressCategory = new ContactAddressCategory();
                    contactAddressCategory.ContactAddress = contactAddress;
                    contactAddress.ContactAddressCategories.Add(contactAddressCategory);
                }
                var contactAddressCategoryType = contactAddressCategoryTypes.FirstOrDefault(c => c.Id == contactAddressCategoryDto.ContactAddressCategoryTypeId);
                contactAddressCategory.ContactAddressCategoryType = contactAddressCategoryType;
                contactAddressCategory.IsSelect = contactAddressCategoryDto.IsSelected;
                contactAddressCategory.IsPrimary = contactAddressCategoryDto.IsPrimary;
            }

            var newAndExistingContactAddressCategoryIds = request.ContactAddressCategory.Select(d => d.ContactAddressCategoryId).ToList();
            var deletedContactAddressCategories = caseContactAddressCategories.Where(x => !newAndExistingContactAddressCategoryIds.Contains(x.Id)).ToList();
            foreach (var deletedContactAddressCategory in deletedContactAddressCategories)
            {
                contactAddress.ContactAddressCategories.Remove(deletedContactAddressCategory);
            }
            Log.TraceFormat("-UpdateContactAddressCategories");
        }
    }
}
