﻿using CMS.Interfaces.Managers.ContactAddressManagers;
using Common.Exceptions;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CMS.Managers.ContactAddressManagers
{
    public class ContactAddressManagerValidator
    {
        public void ValidateEditSaveContactAddressInformation(ContactAddressDto contactAddressDto)
        {
            Log.TraceFormat("+ValidateEditSaveContactAddressInformation");

            var errorMessages = new List<string>();

            ValidateContactRoleType(contactAddressDto, errorMessages);

            ValidateContactName(contactAddressDto, errorMessages);

            ValidateZipCode(contactAddressDto, errorMessages);

            ValidatePhoneNumber(contactAddressDto, errorMessages);

            ValidateMobileNumber(contactAddressDto, errorMessages);

            ValidateFaxNumber(contactAddressDto, errorMessages);

            Log.TraceFormat("-ValidateEditSaveContactAddressInformation");

            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }

        public void ValidateContactRoleType(ContactAddressDto contactAddressDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateContactRoleType");

            if (contactAddressDto.ContactRoleTypeId == 0)
            {
                errorMessages.Add("Please select Contact Role.");
            }
            Log.TraceFormat("-ValidateContactRoleType");
        }

        public void ValidateContactName(ContactAddressDto contactAddressDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateContactName");

            if (string.IsNullOrEmpty(contactAddressDto.ContactName))
            {
                errorMessages.Add("Please enter Contact Name.");
            }
            Log.TraceFormat("-ValidateContactName");
        }
        public void ValidateZipCode(ContactAddressDto contactAddressDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateZipCode");

            if (!string.IsNullOrEmpty(contactAddressDto.ZipCode))
            {
                bool isUsZipCode = IsUsZipCode(contactAddressDto.ZipCode);
                Log.DebugFormat("IsUsZipCode={0}", isUsZipCode);
                if (!isUsZipCode) errorMessages.Add("Zip Code is invalid");
            }

            Log.TraceFormat("-ValidateZipCode");
        }
        private bool IsUsZipCode(string zipCode)
        {
            Log.TraceFormat("+IsUsZipCode");

            bool validZipCode = false;
            string _usZipRegEx = @"^\d{5}(?:[-\s]\d{4})?$";
            if (Regex.Match(zipCode, _usZipRegEx).Success)
            {
                validZipCode = true;
            }

            Log.TraceFormat("-IsUsZipCode");

            return validZipCode;
        }

        public void ValidatePhoneNumber(ContactAddressDto contactAddressDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidatePhoneNumber");
            if (!string.IsNullOrEmpty(contactAddressDto.Phone))
            {
                string phone;
                phone = contactAddressDto.Phone;
                bool isUsPhone = IsUsNumberFormat(phone);
                Log.DebugFormat("IsUsPhone={0}", isUsPhone);
                if (!isUsPhone) errorMessages.Add("Phone Number is invalid.");
            }
            Log.TraceFormat("-ValidatePhoneNumber");
        }

        public void ValidateMobileNumber(ContactAddressDto contactAddressDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateMobileNumber");
            if (!string.IsNullOrEmpty(contactAddressDto.Mobile))
            {
                string mobile;
                mobile = contactAddressDto.Mobile;
                bool isUsMobile = IsUsNumberFormat(mobile);
                Log.DebugFormat("isUsMobile={0}", isUsMobile);
                if (!isUsMobile) errorMessages.Add("Mobile Number is invalid.");
            }
            Log.TraceFormat("-ValidateMobileNumber");
        }

        public void ValidateFaxNumber(ContactAddressDto contactAddressDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateFaxNumber");
            if (!string.IsNullOrEmpty(contactAddressDto.Fax))
            {
                string fax;
                fax = contactAddressDto.Fax;
                bool isUsFax = IsUsNumberFormat(fax);
                Log.DebugFormat("IsUsFix={0}", isUsFax);
                if (!isUsFax) errorMessages.Add("Fax Number is invalid.");
            }
            Log.TraceFormat("-ValidateFaxNumber");
        }
        private bool IsUsNumberFormat(string phone)
        {

            Log.TraceFormat("+IsUsNumberFormat");

            bool validNumberFormat = false;
            string _usPhoneRegEx = @"\(?\d{3}\)?-? *\d{3}-? *-?\d{4}";
            if (Regex.Match(phone, _usPhoneRegEx).Success)
            {
                validNumberFormat = true;
            }

            Log.TraceFormat("-IsUsNumberFormat");

            return validNumberFormat;
        }
    }
}
