﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using CMS.Interfaces.Managers.BusinessManagers;
using Logger.Static;

namespace CMS.Managers.BenefitAmountsCalculationManagers
{
    public class BenefitAmountsCalculationRequestBuilder
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;
        private readonly IBenefitAmountsCalculationManager _benefitAmountsCalculationManager;

        public BenefitAmountsCalculationRequestBuilder(
            IUnitOfWorkFactory unitOfWorkFactory,
            IEligibilityConfigurationManager eligibilityConfigurationManager,
            IBenefitAmountsCalculationManager benefitAmountsCalculationManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
            _benefitAmountsCalculationManager = benefitAmountsCalculationManager;
        }

        public void BuildRequestFromPDRClass(PlanDesignRequestClass participantPDRClass, BenefitAmountsClassCalculationRequest preQuoteCalculationRequest, DateTime? illustrationEffectiveDate = null)
        {
            var eligibilityConfigurationClassDto = new EligibilityConfigurationDto { PlanDesignRequestClassId = participantPDRClass.Id };
            eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);

            preQuoteCalculationRequest.RPPMaximumIndemnityAmount = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmount;
            preQuoteCalculationRequest.RPPMaximumIndemnityAmountUnderAge49 = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmountUnderAge49;
            preQuoteCalculationRequest.EligibilityConfigIssueLimitMaximum = eligibilityConfigurationClassDto.IssueLimitMaximum;
            preQuoteCalculationRequest.EligibilityConfigParticipationLimit = eligibilityConfigurationClassDto.ParticipationLimit;
            preQuoteCalculationRequest.EligibilityConfigCAIssueLimitMaximum = eligibilityConfigurationClassDto.CAIssueLimitMaximum;
            preQuoteCalculationRequest.EligibilityConfigCAParticipationLimit = eligibilityConfigurationClassDto.CAParticipationLimit;

            preQuoteCalculationRequest.EligibilityConfigurationDto = eligibilityConfigurationClassDto;

            var pdrClassProducts = participantPDRClass.PlanDesignRequestClassProducts.ToList();

            var primarPlanProduct = pdrClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == false);
            if (primarPlanProduct != null)
            {
                preQuoteCalculationRequest.PrimaryGSIAmount = primarPlanProduct.GSIAmount;
                preQuoteCalculationRequest.ApprovedTotalGSIAmount = primarPlanProduct.GSIAmount;
                preQuoteCalculationRequest.IsVGSIBuyUp = false;

                var baseDiscountCode = (primarPlanProduct.BaseDiscountType != null) ? primarPlanProduct.BaseDiscountType.Code : string.Empty;
                int baseDiscount = 0;
                int.TryParse(baseDiscountCode, out baseDiscount);

                var demographicDiscountCode = (primarPlanProduct.DemographicDiscountType != null) ? primarPlanProduct.DemographicDiscountType.Code : string.Empty;
                int demographicDiscount = 0;
                int.TryParse(demographicDiscountCode, out demographicDiscount);



                var employerPaidDiscountCode = (primarPlanProduct.EmployerPaidDiscountType != null) ? primarPlanProduct.EmployerPaidDiscountType.Code : string.Empty;
                int employerPaidDiscount = 0;
                int.TryParse(employerPaidDiscountCode, out employerPaidDiscount);



                preQuoteCalculationRequest.TotalDiscountBase = baseDiscount + demographicDiscount + employerPaidDiscount;
            }

            var vgsiBuyUpPlanProduct = pdrClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == true);
            if (vgsiBuyUpPlanProduct != null)
            {
                preQuoteCalculationRequest.TotalMaxGSIAmount = vgsiBuyUpPlanProduct.TotalMaxGSIAmount;
                preQuoteCalculationRequest.ApprovedTotalGSIAmount = vgsiBuyUpPlanProduct.TotalMaxGSIAmount;
                preQuoteCalculationRequest.VoluntaryGSIAmount = vgsiBuyUpPlanProduct.GSIAmount;
                preQuoteCalculationRequest.IsVGSIBuyUp = true;

                var baseDiscountCode = (primarPlanProduct.BaseDiscountType != null) ? primarPlanProduct.BaseDiscountType.Code : string.Empty;
                int baseDiscount = 0;
                int.TryParse(baseDiscountCode, out baseDiscount);

                var demographicDiscountCode = (primarPlanProduct.DemographicDiscountType != null) ? primarPlanProduct.DemographicDiscountType.Code : string.Empty;
                int demographicDiscount = 0;
                int.TryParse(demographicDiscountCode, out demographicDiscount);



                var employerPaidDiscountCode = (primarPlanProduct.EmployerPaidDiscountType != null) ? primarPlanProduct.EmployerPaidDiscountType.Code : string.Empty;
                int employerPaidDiscount = 0;
                int.TryParse(employerPaidDiscountCode, out employerPaidDiscount);



                preQuoteCalculationRequest.TotalDiscountBuyUp = baseDiscount + demographicDiscount + employerPaidDiscount;
            }

            preQuoteCalculationRequest.MaximumReplacementRatio = participantPDRClass.ApprovedMaximumReplacementRatio;

            preQuoteCalculationRequest.PlanDesignType = participantPDRClass.ApprovedPlanDesignType;
            preQuoteCalculationRequest.PDRClassCoveredEarnings = participantPDRClass.ApprovedCoveredEarningsType;
            preQuoteCalculationRequest.PDRClassCoveredEarningsBonusOnly = participantPDRClass.ApprovedCoveredEarningsBonusOnlyType;
            preQuoteCalculationRequest.VGSIBuyUpCoveredEarnings = participantPDRClass.ApprovedGSIBuyUpCoveredEarningsType;
            preQuoteCalculationRequest.VGSIBuyUpCoveredEarningsBonusOnly = participantPDRClass.ApprovedGSIBuyUpCoveredEarningsBonusOnlyType;
            preQuoteCalculationRequest.VGSIMaximumReplacementRatio = participantPDRClass.ApprovedGSIBuyUpReplacementPercentage;
            preQuoteCalculationRequest.RetirementContributionsType = participantPDRClass.ApprovedRetirementContributionsType;
            preQuoteCalculationRequest.RetirementContributionAmount = participantPDRClass.ApprovedAnnualContributions;
            preQuoteCalculationRequest.RequestedPercentage = participantPDRClass.ApprovedCoveredEarningsPercentage;
            preQuoteCalculationRequest.RPPRiderCoveredEarnings = participantPDRClass.ApprovedRppRiderCoveredEarningsType;

            if (!string.IsNullOrEmpty(participantPDRClass.PlanDesignRequest.Case.CompanyRevisionSicCode))
            {
                int value = 0;
                int.TryParse(participantPDRClass.PlanDesignRequest.Case.CompanyRevisionSicCode.Substring(0, 4), out value);
                preQuoteCalculationRequest.CompanySICCode = value;
            }

            if (participantPDRClass.IsApprovedVoluntaryGSIBuyUpPlan != null)
            {
                if (Convert.ToBoolean(participantPDRClass.IsApprovedVoluntaryGSIBuyUpPlan))
                {
                    preQuoteCalculationRequest.VoluntaryGSIBuyUpPlanDesignType = participantPDRClass.ApprovedVoluntaryGSIBuyUpPlanDesignType;
                }
            }


            if (participantPDRClass.ApprovedFlatRateType != null)
            {
                preQuoteCalculationRequest.FlatRateTypeId = participantPDRClass.ApprovedFlatRateType.Id;
                preQuoteCalculationRequest.FlatRateOther = participantPDRClass.ApprovedFlatRate_Other;
            }


            if (participantPDRClass.PlanDesignRequestClassLTDCoverage != null)
            {
                var ltdCoverageInfo = participantPDRClass.PlanDesignRequestClassLTDCoverage.FirstOrDefault();
                if (ltdCoverageInfo != null)
                {
                    preQuoteCalculationRequest.GroupLTDCoveredEarnings = ltdCoverageInfo.GroupLTDCoveredEarningsType;
                    preQuoteCalculationRequest.GroupLTDCapAmount = ltdCoverageInfo.GroupLTDCapAmount;
                    preQuoteCalculationRequest.GroupLTDReplacementPercentage = ltdCoverageInfo.GroupLTDReplacementPercentage;
                    preQuoteCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage = ltdCoverageInfo.BaseSalaryPercentage;
                    preQuoteCalculationRequest.CustomLTDInsurableClassBonusPercentage = ltdCoverageInfo.BonusPercentage;
                    preQuoteCalculationRequest.CustomLTDInsurableClassBonusNoOfYear = ltdCoverageInfo.BonusNumberofYears;
                    preQuoteCalculationRequest.CustomLTDInsurableClassCommissionPercentage = ltdCoverageInfo.CommissionPercentage;
                    preQuoteCalculationRequest.CustomLTDInsurableClassCommissionsNoOfYear = ltdCoverageInfo.CommissionNumberofYears;
                    preQuoteCalculationRequest.CustomLTDInsurableClassK1EarningsPercentage = ltdCoverageInfo.K1EarningsPercentage;
                    preQuoteCalculationRequest.CustomLTDInsurableClassK1EarningsNoOfYear = ltdCoverageInfo.K1EarningsNumberofYears;
                    preQuoteCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage = ltdCoverageInfo.OtherIncomePercentage;
                }
            }

            preQuoteCalculationRequest.IDIPercentage = participantPDRClass.ApprovedIDIPercentage;
            preQuoteCalculationRequest.LTDPercentage = participantPDRClass.ApprovedLTDPercentage;
            preQuoteCalculationRequest.IDICoversFirst = participantPDRClass.ApprovedIDICovers1st;
            preQuoteCalculationRequest.LTDCoversNext = participantPDRClass.ApprovedLTDCoversNext;
            preQuoteCalculationRequest.AnnualContribution = participantPDRClass.ApprovedAnnualContributions;


            var caseUnderwritingRequest = participantPDRClass.PlanDesignRequest.Case.CaseUnderwritingRequests.LastOrDefault();
            if (caseUnderwritingRequest != null)
            {
                preQuoteCalculationRequest.SitusType = caseUnderwritingRequest.SitusType;
                preQuoteCalculationRequest.CorporateSitusState = caseUnderwritingRequest.StateType;
                preQuoteCalculationRequest.SitusMultiState1Type = caseUnderwritingRequest.SitusMultiState1Type;
                preQuoteCalculationRequest.SitusMultiState2Type = caseUnderwritingRequest.SitusMultiState2Type;
                preQuoteCalculationRequest.SitusMultiState3Type = caseUnderwritingRequest.SitusMultiState3Type;
            }

            preQuoteCalculationRequest.IllustrationEffectiveDate = illustrationEffectiveDate == null ? participantPDRClass.PlanDesignRequest.IllustrationEffectiveDate : illustrationEffectiveDate;

            var baseRiders = participantPDRClass.PlanDesignRequestClassRiders.Where(c => c.IsGSIPlanIndicator == false).ToList();
            var buyUpRiders = participantPDRClass.PlanDesignRequestClassRiders.Where(c => c.IsGSIPlanIndicator == true).ToList();

            var baseCatRider = baseRiders.FirstOrDefault(p => (p.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider || p.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider));
            var buyUpCatRider = buyUpRiders.FirstOrDefault(p => (p.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider || p.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider));

            if (baseCatRider != null)
            {
                preQuoteCalculationRequest.CATAmount = baseCatRider.ApprovedAmount;
            }
            else if (buyUpCatRider != null)
            {
                preQuoteCalculationRequest.CATAmount = buyUpCatRider.ApprovedAmount;
            }
            else
            {
                preQuoteCalculationRequest.CATAmount = 0.0m;
            }

            var baseRppRider = baseRiders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
            var buyUpRppRider = buyUpRiders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
            if (baseRppRider != null)
            {
                preQuoteCalculationRequest.RPPBenefitAmount = baseRppRider.ApprovedAmount;
            }
            else if (buyUpRppRider != null)
            {
                preQuoteCalculationRequest.RPPBenefitAmount = buyUpRppRider.ApprovedAmount;
            }
            else
            {
                preQuoteCalculationRequest.RPPBenefitAmount = 0.0m;
            }

            var customizeIDIInsurableIncome = participantPDRClass.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault(c => c.IsGSIPlanIndicator == false);
            GetCustomizedIDIInsurableIncome(preQuoteCalculationRequest, customizeIDIInsurableIncome, false);

            var customizeVGSIBuyUpIDIInsurableIncome = participantPDRClass.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault(c => c.IsGSIPlanIndicator == true);
            GetCustomizedIDIInsurableIncome(preQuoteCalculationRequest, customizeVGSIBuyUpIDIInsurableIncome, true);

            preQuoteCalculationRequest.BasePlanGSIPercentage = 1.0m;
            preQuoteCalculationRequest.BuyUpPlanGSIPercentage = 1.0m;
        }

        public void BuildRequestFromSoldPDRClass(PDRSoldClass pdrSoldClass, BenefitAmountsClassCalculationRequest preQuoteCalculationRequest, int? enrollmentId=null)
        {
            var eligibilityConfigurationClassDto = new EligibilityConfigurationDto { PlanDesignRequestClassId = pdrSoldClass.PlanDesignRequestClass.Id };
            eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);

            preQuoteCalculationRequest.RPPMaximumIndemnityAmount = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmount;
            preQuoteCalculationRequest.RPPMaximumIndemnityAmountUnderAge49 = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmountUnderAge49;
            preQuoteCalculationRequest.EligibilityConfigIssueLimitMaximum = eligibilityConfigurationClassDto.IssueLimitMaximum;
            preQuoteCalculationRequest.EligibilityConfigParticipationLimit = eligibilityConfigurationClassDto.ParticipationLimit;

            preQuoteCalculationRequest.EligibilityConfigCAIssueLimitMaximum = eligibilityConfigurationClassDto.CAIssueLimitMaximum;
            preQuoteCalculationRequest.EligibilityConfigCAParticipationLimit = eligibilityConfigurationClassDto.CAParticipationLimit;

            preQuoteCalculationRequest.EligibilityConfigurationDto = eligibilityConfigurationClassDto;

            var pdrSoldClassPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
            var pdrSoldClassBuyUpPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

            if (pdrSoldClassPlan == null) return;

            var baseDiscountCode = (pdrSoldClassPlan.BaseDiscountType != null) ? pdrSoldClassPlan.BaseDiscountType.Code : string.Empty;
            int baseDiscount = 0;
            int.TryParse(baseDiscountCode, out baseDiscount);

            var demographicDiscountCode = (pdrSoldClassPlan.DemographicDiscountType != null) ? pdrSoldClassPlan.DemographicDiscountType.Code : string.Empty;
            int demographicDiscount = 0;
            int.TryParse(demographicDiscountCode, out demographicDiscount);



            var employerPaidDiscountCode = (pdrSoldClassPlan.EmployerPaidDiscountType != null) ? pdrSoldClassPlan.EmployerPaidDiscountType.Code : string.Empty;
            int employerPaidDiscount = 0;
            int.TryParse(employerPaidDiscountCode, out employerPaidDiscount);



            preQuoteCalculationRequest.TotalDiscountBase = baseDiscount + demographicDiscount + employerPaidDiscount ;

            preQuoteCalculationRequest.PrimaryGSIAmount = pdrSoldClassPlan.GSIAmount;
            preQuoteCalculationRequest.ApprovedTotalGSIAmount = pdrSoldClassPlan.GSIAmount;

            preQuoteCalculationRequest.MaximumReplacementRatio = pdrSoldClassPlan.MaximumReplacementRatio;

            var catRider = pdrSoldClassPlan.PDRSoldClassPlanRiders
                .FirstOrDefault(p => (p.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider ||
                                      p.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider));
            if (catRider != null)
            {
                preQuoteCalculationRequest.CATAmount = catRider != null ? catRider.ApprovedAmount : 0.0m;
            }
            else
            {
                if (pdrSoldClassBuyUpPlan != null)
                {
                    var buyUpcatRider = pdrSoldClassBuyUpPlan.PDRSoldClassPlanRiders
                    .FirstOrDefault(p => (p.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider ||
                                          p.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider));

                    preQuoteCalculationRequest.CATAmount = buyUpcatRider != null ? buyUpcatRider.ApprovedAmount : 0.0m;
                }
            }
            preQuoteCalculationRequest.RPPRiderCoveredEarnings = pdrSoldClassPlan.RppRiderCoveredEarningsType;
            preQuoteCalculationRequest.RetirementContributionsType = pdrSoldClassPlan.RetirementContributionsType;
            preQuoteCalculationRequest.PDRClassCoveredEarnings = pdrSoldClassPlan.CoveredEarningsType;
            preQuoteCalculationRequest.PDRClassCoveredEarningsBonusOnly = pdrSoldClassPlan.CoveredEarningsBonusOnlyType;
            preQuoteCalculationRequest.RetirementContributionAmount = pdrSoldClassPlan.AnnualContributions;
            preQuoteCalculationRequest.RequestedPercentage = pdrSoldClassPlan.CoveredEarningsPercentage;
            preQuoteCalculationRequest.PlanDesignType = pdrSoldClassPlan.PlanDesignType;
            preQuoteCalculationRequest.IsVGSIBuyUp = false;
            preQuoteCalculationRequest.BasePlanGSIPercentage = 1.0m;
            
            if (!string.IsNullOrEmpty(pdrSoldClass.PlanDesignRequest.Case.CompanyRevisionSicCode))
            {
                int value = 0;
                int.TryParse(pdrSoldClass.PlanDesignRequest.Case.CompanyRevisionSicCode.Substring(0, 4), out value);
                preQuoteCalculationRequest.CompanySICCode = value;
            }

            if (pdrSoldClassPlan.FlatRateType != null)
            {
                preQuoteCalculationRequest.FlatRateTypeId = pdrSoldClassPlan.FlatRateType.Id;
            }
            preQuoteCalculationRequest.FlatRateOther = pdrSoldClassPlan.FlatRate_Other;

            if (pdrSoldClass.PDRSoldClassLTDCoverage != null)
            {
                var ltdCoverageInfo = pdrSoldClass.PDRSoldClassLTDCoverage.FirstOrDefault();
                if (ltdCoverageInfo != null)
                {
                    preQuoteCalculationRequest.GroupLTDCapAmount = ltdCoverageInfo.GroupLTDCapAmount;
                    preQuoteCalculationRequest.GroupLTDReplacementPercentage = ltdCoverageInfo.GroupLTDReplacementPercentage;
                    preQuoteCalculationRequest.GroupLTDCoveredEarnings = ltdCoverageInfo.GroupLTDCoveredEarningsType;
                    preQuoteCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage = ltdCoverageInfo.BaseSalaryPercentage;
                    preQuoteCalculationRequest.CustomLTDInsurableClassBonusPercentage = ltdCoverageInfo.BonusPercentage;
                    preQuoteCalculationRequest.CustomLTDInsurableClassBonusNoOfYear = ltdCoverageInfo.BonusNumberofYears;
                    preQuoteCalculationRequest.CustomLTDInsurableClassCommissionPercentage = ltdCoverageInfo.CommissionPercentage;
                    preQuoteCalculationRequest.CustomLTDInsurableClassCommissionsNoOfYear = ltdCoverageInfo.CommissionNumberofYears;
                    preQuoteCalculationRequest.CustomLTDInsurableClassK1EarningsPercentage = ltdCoverageInfo.K1EarningsPercentage;
                    preQuoteCalculationRequest.CustomLTDInsurableClassK1EarningsNoOfYear = ltdCoverageInfo.K1EarningsNumberofYears;
                    preQuoteCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage = ltdCoverageInfo.OtherIncomePercentage;
                }

            }

            preQuoteCalculationRequest.IDIPercentage = pdrSoldClassPlan.IDIPercentage;
            preQuoteCalculationRequest.LTDPercentage = pdrSoldClassPlan.LTDPercentage;
            preQuoteCalculationRequest.IDICoversFirst = pdrSoldClassPlan.IDICovers1st;
            preQuoteCalculationRequest.LTDCoversNext = pdrSoldClassPlan.LTDCoversNext;

            preQuoteCalculationRequest.AnnualContribution = pdrSoldClassPlan.AnnualContributions;

            var riders = pdrSoldClassPlan.PDRSoldClassPlanRiders.Where(c => c.PDRSoldClassPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);

            var rppRider = riders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
            if (rppRider != null)
            {
                preQuoteCalculationRequest.RPPBenefitAmount = rppRider.ApprovedAmount;
            }
            else
            {
                var buyUpriders = pdrSoldClassBuyUpPlan != null ? pdrSoldClassBuyUpPlan.PDRSoldClassPlanRiders.Where(c => c.PDRSoldClassPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp) : null;

                if (buyUpriders != null)
                {
                    var buyUpRppRider = buyUpriders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);

                    preQuoteCalculationRequest.RPPBenefitAmount = buyUpRppRider != null ? buyUpRppRider.ApprovedAmount : 0.0m;
                }
            }

            var customizeIDIInsurableIncome = pdrSoldClassPlan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.FirstOrDefault();
            if (customizeIDIInsurableIncome != null)
            {
                preQuoteCalculationRequest.CustomIDIInsurableBaseSalaryPercentage = customizeIDIInsurableIncome.BaseSalaryPercentage;
                preQuoteCalculationRequest.CustomIDIInsurableBonusPercentage = customizeIDIInsurableIncome.BonusPercentage;
                preQuoteCalculationRequest.CustomIDIInsurableBonusNoOfYear = customizeIDIInsurableIncome.BonusNumberofYears;
                preQuoteCalculationRequest.CustomIDIInsurableCommissionPercentage = customizeIDIInsurableIncome.CommissionPercentage;
                preQuoteCalculationRequest.CustomIDIInsurableCommissionsNoOfYear = customizeIDIInsurableIncome.CommissionNumberofYears;
                preQuoteCalculationRequest.CustomIDIInsurableK1EarningsPercentage = customizeIDIInsurableIncome.K1EarningsPercentage;
                preQuoteCalculationRequest.CustomIDIInsurableK1EarningsNoOfYear = customizeIDIInsurableIncome.K1EarningsNumberofYears;
                preQuoteCalculationRequest.CustomIDIInsurableOtherIncomePercentage = customizeIDIInsurableIncome.OtherIncomePercentage;
            }

            var pdrSoldClassVgsiBuyUpPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
            if (pdrSoldClassVgsiBuyUpPlan != null)
            {
                preQuoteCalculationRequest.VoluntaryGSIBuyUpPlanDesignType = (PlanDesignGSITypeEnum?)pdrSoldClassVgsiBuyUpPlan.PlanDesignType;
                preQuoteCalculationRequest.VGSIBuyUpCoveredEarnings = pdrSoldClassVgsiBuyUpPlan.CoveredEarningsType;
                preQuoteCalculationRequest.VGSIBuyUpCoveredEarningsBonusOnly = pdrSoldClassVgsiBuyUpPlan.CoveredEarningsBonusOnlyType;
                preQuoteCalculationRequest.TotalMaxGSIAmount = pdrSoldClassVgsiBuyUpPlan.TotalMaxGSIAmount;
                preQuoteCalculationRequest.ApprovedTotalGSIAmount = pdrSoldClassVgsiBuyUpPlan.TotalMaxGSIAmount;

                preQuoteCalculationRequest.VoluntaryGSIAmount = pdrSoldClassVgsiBuyUpPlan.GSIAmount;
                preQuoteCalculationRequest.VGSIMaximumReplacementRatio = pdrSoldClassVgsiBuyUpPlan.ReplacementPercentage;
                preQuoteCalculationRequest.IsVGSIBuyUp = true;
                preQuoteCalculationRequest.BuyUpPlanGSIPercentage = 1.0m;

                var buyUpBaseDiscountCode = (pdrSoldClassPlan.BaseDiscountType != null) ? pdrSoldClassPlan.BaseDiscountType.Code : string.Empty;
                int buyUpbaseDiscount = 0;
                int.TryParse(buyUpBaseDiscountCode, out buyUpbaseDiscount);

                var buyUpdemographicDiscountCode = (pdrSoldClassPlan.DemographicDiscountType != null) ? pdrSoldClassPlan.DemographicDiscountType.Code : string.Empty;
                int buyUpdemographicDiscount = 0;
                int.TryParse(buyUpdemographicDiscountCode, out buyUpdemographicDiscount);

                var buyUpemployerPaidDiscountCode = (pdrSoldClassPlan.EmployerPaidDiscountType != null) ? pdrSoldClassPlan.EmployerPaidDiscountType.Code : string.Empty;
                int buyUpemployerPaidDiscount = 0;
                int.TryParse(buyUpemployerPaidDiscountCode, out buyUpemployerPaidDiscount);



                preQuoteCalculationRequest.TotalDiscountBuyUp = buyUpbaseDiscount + buyUpdemographicDiscount + buyUpemployerPaidDiscount;

                var customizeVgsiBuyUpIDIInsurableIncome = pdrSoldClassVgsiBuyUpPlan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.FirstOrDefault();
                if (customizeVgsiBuyUpIDIInsurableIncome != null)
                {
                    preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeBaseSalaryPercentage = customizeVgsiBuyUpIDIInsurableIncome.BaseSalaryPercentage;
                    preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusPercentage = customizeVgsiBuyUpIDIInsurableIncome.BonusPercentage;
                    preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusNoOfYear = customizeVgsiBuyUpIDIInsurableIncome.BonusNumberofYears;
                    preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionPercentage = customizeVgsiBuyUpIDIInsurableIncome.CommissionPercentage;
                    preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionsNoOfYear = customizeVgsiBuyUpIDIInsurableIncome.CommissionNumberofYears;
                    preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsPercentage = customizeVgsiBuyUpIDIInsurableIncome.K1EarningsPercentage;
                    preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsNoOfYear = customizeVgsiBuyUpIDIInsurableIncome.K1EarningsNumberofYears;
                    preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeOtherIncomePercentage = customizeVgsiBuyUpIDIInsurableIncome.OtherIncomePercentage;
                }
            }

            var caseUnderwritingRequest = pdrSoldClass.PlanDesignRequest.Case.CaseUnderwritingRequests.LastOrDefault();
            if (caseUnderwritingRequest != null)
            {
                preQuoteCalculationRequest.SitusType = caseUnderwritingRequest.SitusType;
                preQuoteCalculationRequest.CorporateSitusState = caseUnderwritingRequest.StateType;
                preQuoteCalculationRequest.SitusMultiState1Type = caseUnderwritingRequest.SitusMultiState1Type;
                preQuoteCalculationRequest.SitusMultiState2Type = caseUnderwritingRequest.SitusMultiState2Type;
                preQuoteCalculationRequest.SitusMultiState3Type = caseUnderwritingRequest.SitusMultiState3Type;
            }

            preQuoteCalculationRequest.IllustrationEffectiveDate = GetIllustrationEffectiveDate(pdrSoldClass.PlanDesignRequestClass, enrollmentId);

            preQuoteCalculationRequest.PremiumPayerType = pdrSoldClassPlan.PremiumPayerAndTaxabilityType != null ? (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum?)pdrSoldClassPlan.PremiumPayerAndTaxabilityType.Id : null;
            preQuoteCalculationRequest.TypeOfShareType = pdrSoldClassPlan.TypeOfShareType;
            preQuoteCalculationRequest.EmployerPaidPremiumPercent = pdrSoldClassPlan.EmployerPaidPremium != null ? pdrSoldClassPlan.EmployerPaidPremium / 100 : null;
            preQuoteCalculationRequest.EmployerPaysUptoAmount = pdrSoldClassPlan.EmployerPaysupto;
        }

        public BenefitAmountsCalculationRequest BuildRequestFromEnrollmentParticipantOptionPlan(EnrollmentParticipantOptionPlan plan, Participant participant,
            BenefitAmountsClassCalculationRequest classCalculationRequest)
        {
            var request = BuildRequestFromParticipant(participant);

            request.ClassCalculationRequest = classCalculationRequest.DeepCopy();

            var optionPlanType = plan.PDRClassPlanType;

            if (optionPlanType == PDRClassPlanTypeEnum.Primary)
            {
                request.ClassCalculationRequest.PDRClassCoveredEarnings = plan.CoveredEarningsType;
                request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly = plan.CoveredEarningsBonusOnlyType;
                request.ClassCalculationRequest.IsVoluntaryBuyUpPlan = false;
                request.ClassCalculationRequest.BasePlanGSIPercentage = (plan.GSIPercentage / 100);
                request.ClassCalculationRequest.NotToIncludeGSIBuyUpAmount = true;
                plan.PlanDesignType = request.ClassCalculationRequest.PlanDesignType;
                request.ClassCalculationRequest.MaximumReplacementRatio = plan.ReplacementRatio;
            }

            if (optionPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp)
            {
                request.ClassCalculationRequest.VGSIBuyUpCoveredEarnings = plan.CoveredEarningsType;
                request.ClassCalculationRequest.VGSIBuyUpCoveredEarningsBonusOnly = plan.CoveredEarningsBonusOnlyType;
                request.ClassCalculationRequest.IsVoluntaryBuyUpPlan = true;
                request.ClassCalculationRequest.BuyUpPlanGSIPercentage = (plan.GSIPercentage / 100);
                request.ClassCalculationRequest.NotToIncludeGSIBuyUpAmount = false;
                plan.PlanDesignType = (PlanDesignTypeEnum) request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType;
                request.ClassCalculationRequest.VGSIMaximumReplacementRatio = plan.ReplacementRatio;
            }            

            var rppRider = plan.Riders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
            if (rppRider != null)
            {
                request.ClassCalculationRequest.RPPBenefitAmount = rppRider.BenefitAmountMonthly;
                request.ClassCalculationRequest.PrimaryPlanRPPRider = rppRider.BenefitType;
            }

            var catRider = plan.Riders.FirstOrDefault(p => (p.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider || p.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider));
            request.ClassCalculationRequest.CATAmount = catRider != null ? catRider.BenefitAmountMonthly : 0.0m;

            return request;
        }

        public BenefitAmountsCalculationRequest BuildRequestFromIllustrationParticipantPlan(IllustrationRequestClassPlan plan, IllustrationRequestClassPlan basePlan, Participant participant,
            BenefitAmountsClassCalculationRequest classCalculationRequest)
        {
            var request = BuildRequestFromParticipant(participant);

            request.ClassCalculationRequest = classCalculationRequest.DeepCopy();

            if (plan.IsBuyUpPlan)
            {
                request.ClassCalculationRequest.VoluntaryGSIAmount = plan.GSIAmount;
                request.ClassCalculationRequest.TotalDiscountBuyUp = plan.DiscountPercentage;
                request.ClassCalculationRequest.IsVoluntaryBuyUpPlan = true;
                request.ClassCalculationRequest.BuyUpPlanGSIPercentage = 1.0m;               
                if (basePlan != null)
                {
                    request.ClassCalculationRequest.PrimaryGSIAmount = basePlan.GSIAmount;                    
                    request.ClassCalculationRequest.TotalDiscountBase = basePlan.DiscountPercentage;
                    request.ClassCalculationRequest.BasePlanGSIPercentage = 1.0m;
                }
            }
            else
            {
                request.ClassCalculationRequest.PrimaryGSIAmount = plan.GSIAmount;
                request.ClassCalculationRequest.TotalDiscountBase = plan.DiscountPercentage;
                request.ClassCalculationRequest.IsVoluntaryBuyUpPlan = false;
                request.ClassCalculationRequest.BasePlanGSIPercentage = 1.0m;
                if (plan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                {
                    request.ClassCalculationRequest.RPPBenefitAmount = plan.GSIAmount; //should take the amount from the Illustration GsiAmount text box not frm PDR GSI text box for RPP
                }
            }


            request.ClassCalculationRequest.MaximumReplacementRatio = plan.ReplacementRatio;

            var rppRider = plan.Benefits.FirstOrDefault(c => c.BenefitId == (int)BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
            if (rppRider != null)
            {
                request.ClassCalculationRequest.RPPBenefitAmount = rppRider.Amount;
                request.ClassCalculationRequest.PrimaryPlanRPPRider = BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit;
            }

            var catRider = plan.Benefits.FirstOrDefault(p => (p.BenefitId == (int)BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider || p.BenefitId == (int)BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider));
            request.ClassCalculationRequest.CATAmount = catRider != null ? catRider.Amount : 0.0m;

            return request;
        }
        public BenefitAmountsCalculationRequest BuildRequestFromParticipant(Participant participant)
        {
            var request = new BenefitAmountsCalculationRequest();

            request.MostRecentSalaryAmount = participant.MostRecentSalaryAmount;
            request.MostRecentPaidBonusAmount = participant.MostRecentPaidBonusAmount;
            request.PriorPaidBonusAmount = participant.PriorPaidBonusAmount;
            request.AdditionalPriorPaidBonusAmount = participant.AdditionalPriorPaidBonusAmount;
            request.MostRecentPaidCommissionAmount = participant.MostRecentPaidCommissionAmount;
            request.PriorPaidCommissionAmount = participant.PriorPaidCommissionAmount;
            request.AdditionalPriorPaidCommissionAmount = participant.AdditionalPriorPaidCommissionAmount;
            request.MostRecentPaidK1IncomeAmount = participant.MostRecentPaidK1IncomeAmount;
            request.PriorPaidK1IncomeAmount = participant.PriorPaidK1IncomeAmount;
            request.AdditionalPriorPaidK1IncomeAmount = participant.AdditionalPriorPaidK1IncomeAmount;
            request.OtherIncomeAmount = participant.OtherIncomeAmount;
            request.IDIInsurableIncomeAmount = participant.IDIInsurableIncomeCalculatedAmount;
            request.TotalEmployerOrEmployeeRetirementContributionAmount = participant.TotalEmployerOrEmployeeRetirementContributionAmount;
            request.MostRecentW2IncomeAmount = participant.MostRecentYearPaidW2Income;

            request.IDIReplacementPercentRequests = new List<IDIReplacementPercentRequest>
            {
                AssignReplacementPercentRequest(participant.IDIBenefitAmount1, participant.IDIToBeReplaced1, participant.IDICarrier1, participant.IDIToBeReplacedAmount1),
                AssignReplacementPercentRequest(participant.IDIBenefitAmount2, participant.IDIToBeReplaced2, participant.IDICarrier2, participant.IDIToBeReplacedAmount2),
                AssignReplacementPercentRequest(participant.IDIBenefitAmount3, participant.IDIToBeReplaced3, participant.IDICarrier3, participant.IDIToBeReplacedAmount3),
                AssignReplacementPercentRequest(participant.IDIBenefitAmount4, participant.IDIToBeReplaced4, participant.IDICarrier4, participant.IDIToBeReplacedAmount4)
            };

            request.HomeState = participant.HomeState;
            request.ManualBenefitAmount = participant.ManualBenefitAmount;
            request.ManualBenefitAMBIncreaseAmount = participant.ManualBenefitAMBIncreaseAmount;
            request.ManualRPPAmount = participant.ManualRPPAmount;
            request.ManualRPPAMBIncreaseAmount = participant.ManualRPPAMBIncreaseAmount;
            request.ManualVGSIBuyUpAMBIncreaseAmount=participant.ManualVGSIBuyUpAMBIncreaseAmount;
            request.LTDCalculatedAmount = participant.LTDCalculatedAmount;
            request.GuardianExistingIDICoverageAmount = participant.GuardianExistingIDICoverageTotalCalculatedAmount;
            request.OtherExistingIDICoverageAmount = participant.OtherExistingIDICoverageTotalCalculatedAmount;
            request.IDIInsurableIncomeAmount = participant.IDIInsurableIncomeCalculatedAmount;

            request.CustomLTDInsurableIncomeBaseSalaryPercentage = participant.CustomLTDInsurableIncomeBaseSalaryPercentage;
            request.CustomLTDInsurableIncomeBonusPercentage = participant.CustomLTDInsurableIncomeBonusPercentage;
            request.CustomLTDInsurableIncomeCommissionPercentage = participant.CustomLTDInsurableIncomeCommissionPercentage;
            request.CustomLTDInsurableIncomeOtherIncomePercentage = participant.CustomLTDInsurableIncomeOtherIncomePercentage;

            request.ParticipantDateOfBirth = participant.DateOfBirth;

            if (participant.ParticipantExistingPolicies.Any())
            {
                var cmsCase = participant.PlanDesignRequestClass.PlanDesignRequest.Case;
                var participantExistingPolicy = participant.ParticipantExistingPolicies.FirstOrDefault();
                if (request.IDIReplacementPercentRequests.Any())
                {
                    decimal? idiGuardianBenefitAmount = request.IDIReplacementPercentRequests.Where(i => i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Berkshire || i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Guardian)
                                                                                     .Sum(j => j.IDIBenefitAmount);
                    decimal? idiGuardianReplacementAmount = request.IDIReplacementPercentRequests.Where(i => i.IsReplaceCoverage == true && (i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Berkshire || i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Guardian))
                                                                                        .Sum(j => j.IDIReplacementAmount);

                    decimal? idiOtherBenefitAmount = request.IDIReplacementPercentRequests.Where(i => i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Berkshire && i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Guardian)
                                                                                     .Sum(j => j.IDIBenefitAmount);
                    decimal? idiOtherReplacementAmount = request.IDIReplacementPercentRequests.Where(i => i.IsReplaceCoverage == true && (i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Berkshire && i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Guardian))
                                                                                        .Sum(j => j.IDIReplacementAmount);

                    request.GSIIDIBaseAMBAmount = (idiGuardianBenefitAmount.HasValue ? idiGuardianBenefitAmount : 0.0m) - (idiGuardianReplacementAmount.HasValue ? idiGuardianReplacementAmount : 0.0m);
                    //Below line is not required as per NBTC-3088
                    //request.FullyUnderWrittenIDIAmount = (idiOtherBenefitAmount.HasValue ? idiOtherBenefitAmount : 0.0m) - (idiOtherReplacementAmount.HasValue ? idiOtherReplacementAmount : 0.0m);
                }

                if (participantExistingPolicy.ParticipantExistingPolicyDetails.Any())
                {
                    var policyDetails = participantExistingPolicy.ParticipantExistingPolicyDetails;
                    request.BaseGSIMaxAmount = policyDetails.Where(i => i.PremiumPayer != null && i.PremiumPayer.ToUpper() == "EMPLOYER" && i.IsTerminateAndReplace == false).Sum(j => j.MonthlyIndemnity);
                    request.VGSIBuyUpMaxAmount = policyDetails.Where(i => i.PremiumPayer != null && i.PremiumPayer.ToUpper() == "EMPLOYEE" && i.IsTerminateAndReplace == false).Sum(j => j.MonthlyIndemnity);
                }

                //request.GSIIDIBaseAMBAmount = participantExistingPolicy.GSIIDIBaseAMB;
                if (participantExistingPolicy.FullyUnderwrittenIDI != null && participantExistingPolicy.FullyUnderwrittenIDI > 0)
                {
                    request.FullyUnderWrittenIDIAmount = participantExistingPolicy.FullyUnderwrittenIDI;
                }

                if (participantExistingPolicy.GSIIDIBaseAMB != null && participantExistingPolicy.GSIIDIBaseAMB > 0)
                {
                    request.GSIIDIBaseAMBAmount = participantExistingPolicy.GSIIDIBaseAMB;
                }

                //Fixing INC2412851 - Fully Underwriten coverage  FUW not calculating correctly in Production - DFCT0051077
                if (participantExistingPolicy.GSIIDIBaseAMB == null && (participantExistingPolicy.FullyUnderwrittenIDI != null && participantExistingPolicy.FullyUnderwrittenIDI > 0))
                {
                    request.GSIIDIBaseAMBAmount = 0;
                }

                request.GSIRPPBaseAMBAmount = participantExistingPolicy.GSIRPPBaseAMB;
                request.FullyUnderWrittenRPPAmount = participantExistingPolicy.FullyUnderwrittenRPP;
                _benefitAmountsCalculationManager.GetParticipantExistingPolicyRequest(participantExistingPolicy.ParticipantExistingPolicyDetails, cmsCase, participantExistingPolicy, request);
            }
            request.ManualVGSIBuyUpBenefitAmount = participant.ManualVGSIBuyUpBenefitAmount;
            request.IsAMBPolicy = participant.IsPushtoNewProviderChoicePolicyIndicator;
            request.IsAMBIncreasePolicy = participant.IsAMBIncreaseIndicator ?? false;
            request.IsBuyUpAMBIncreaseIndicator = participant.IsBuyUpAMBIncreaseIndicator ?? false;
            return request;
        }

        private IDIReplacementPercentRequest AssignReplacementPercentRequest(decimal? idiBenefitAmount, bool? isReplaceCoverage, IDICoverageCarrierTypeEnum? idiCoverageCarrier_Id, decimal? idiReplacementAmount)
        {
            var idiReplacementPercentRequest = new IDIReplacementPercentRequest
            {
                IDIBenefitAmount = idiBenefitAmount ?? 0.0m,
                IsReplaceCoverage = isReplaceCoverage,
                IDICarrier_Id = idiCoverageCarrier_Id,
                IDIReplacementAmount = idiReplacementAmount.HasValue ? idiReplacementAmount : 0.0m
        };
            return idiReplacementPercentRequest;
        }


        /*BusinessRule for calculating Effective date-
        1. The Illustration will operate based on the Illustration Effective Date displayed on the PDR screen, irrespective of whether an enrollment is available or not.
        2. B & P will operate based on the effective date of the selected enrollment.*/
        private DateTime? GetIllustrationEffectiveDate(PlanDesignRequestClass planDesignRequestClass, int? enrollmentId = null)
        {           
               DateTime? illustrationEffectiveDate = planDesignRequestClass.PlanDesignRequest.IllustrationEffectiveDate;                     
                if (enrollmentId != null)
                {
                    using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                    {
                        var enrollmentPdrClass = unitOfWork.Repository<EnrollmentPDRClass>().Linq()
                                           .Where(enrollmentPDRClass => enrollmentPDRClass.PlanDesignRequestClass.Id == planDesignRequestClass.Id && enrollmentPDRClass.Enrollment.Id == enrollmentId)
                                           .OrderByDescending(enrollmentPDRClass => enrollmentPDRClass.Enrollment)
                                            .FirstOrDefault();

                        Log.TraceFormat($"Participant: GetIllustrationEffectiveDate: EnrollmentId is {enrollmentId}");

                        if (enrollmentPdrClass != null)
                        {
                            illustrationEffectiveDate = enrollmentPdrClass.Enrollment.EffectiveDate;
                            Log.TraceFormat($"Participant: GetIllustrationEffectiveDate : Pulled Effective date from this EnrollmentID: '{enrollmentPdrClass.Enrollment.Id}' Effective Date :'{illustrationEffectiveDate}'");
                        }
                    }
                }
                else
                {
                    Log.TraceFormat($"Participant: GetIllustrationEffectiveDate : Pulled Effective date from the PDR screen Illustration Effective Date :'{illustrationEffectiveDate}'");
                }    
                
                return illustrationEffectiveDate;
        }

        private void GetCustomizedIDIInsurableIncome(BenefitAmountsClassCalculationRequest preQuoteCalculationRequest, PDRClassCustomizedIDIInsurableIncome customizeIDIInsurableIncome, bool isVGSIBuyUp)
        {
            if (isVGSIBuyUp && customizeIDIInsurableIncome != null)
            {
                preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeBaseSalaryPercentage = customizeIDIInsurableIncome.BaseSalaryPercentage;
                preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusPercentage = customizeIDIInsurableIncome.BonusPercentage;
                preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusNoOfYear = customizeIDIInsurableIncome.BonusNumberofYears;
                preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionPercentage = customizeIDIInsurableIncome.CommissionPercentage;
                preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionsNoOfYear = customizeIDIInsurableIncome.CommissionNumberofYears;
                preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsPercentage = customizeIDIInsurableIncome.K1EarningsPercentage;
                preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsNoOfYear = customizeIDIInsurableIncome.K1EarningsNumberofYears;
                preQuoteCalculationRequest.CustomVGSIBuyUPInsurableIncomeOtherIncomePercentage = customizeIDIInsurableIncome.OtherIncomePercentage;
            }
            else if (customizeIDIInsurableIncome != null)
            {
                preQuoteCalculationRequest.CustomIDIInsurableBaseSalaryPercentage = customizeIDIInsurableIncome.BaseSalaryPercentage;
                preQuoteCalculationRequest.CustomIDIInsurableBonusPercentage = customizeIDIInsurableIncome.BonusPercentage;
                preQuoteCalculationRequest.CustomIDIInsurableBonusNoOfYear = customizeIDIInsurableIncome.BonusNumberofYears;
                preQuoteCalculationRequest.CustomIDIInsurableCommissionPercentage = customizeIDIInsurableIncome.CommissionPercentage;
                preQuoteCalculationRequest.CustomIDIInsurableCommissionsNoOfYear = customizeIDIInsurableIncome.CommissionNumberofYears;
                preQuoteCalculationRequest.CustomIDIInsurableK1EarningsPercentage = customizeIDIInsurableIncome.K1EarningsPercentage;
                preQuoteCalculationRequest.CustomIDIInsurableK1EarningsNoOfYear = customizeIDIInsurableIncome.K1EarningsNumberofYears;
                preQuoteCalculationRequest.CustomIDIInsurableOtherIncomePercentage = customizeIDIInsurableIncome.OtherIncomePercentage;
            }
        }
    }
}