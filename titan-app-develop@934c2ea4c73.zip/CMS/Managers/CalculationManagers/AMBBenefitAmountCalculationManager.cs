﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Managers.PreQuoteCalculationManagers.Calculators;
using CMS.Model.Entities;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.DataAccess;
using Logger.Static;
using System.Linq;
using CMS.Model.Enums;
using System.Collections.Generic;

namespace CMS.Managers.BenefitAmountsCalculationManagers
{
    public class AMBBenefitAmountCalculationManager : IAMBBenefitAmountsCalculationManager
    {
        private readonly EEPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator _eEPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator;
        private readonly ERPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator _eRPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator;
        private readonly EEPaidIDIGSIBasePlusAMBInForceModalAmountCalculator _eEPaidIDIGSIBasePlusAMBInForceModalAmountCalculator;
        private readonly ERPaidIDIGSIBasePlusAMBInForceModalAmountCalculator _eRPaidIDIGSIBasePlusAMBInForceModalAmountCalculator;
        private readonly EEPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator _eEPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator;
        private readonly ERPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator _eRPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator;
        private readonly EEPaidRPPGSIBasePlusAMBInForceModalAmountCalculator _eEPaidRPPGSIBasePlusAMBInForceModalAmountCalculator;
        private readonly ERPaidRPPGSIBasePlusAMBInForceModalAmountCalculator _eRPaidRPPGSIBasePlusAMBInForceModalAmountCalculator;
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public AMBBenefitAmountCalculationManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _eEPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator = new EEPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator();
            _eRPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator = new ERPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator();
            _eEPaidIDIGSIBasePlusAMBInForceModalAmountCalculator = new EEPaidIDIGSIBasePlusAMBInForceModalAmountCalculator();
            _eRPaidIDIGSIBasePlusAMBInForceModalAmountCalculator = new ERPaidIDIGSIBasePlusAMBInForceModalAmountCalculator();
            _eEPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator = new EEPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator();
            _eRPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator = new ERPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator();
            _eEPaidRPPGSIBasePlusAMBInForceModalAmountCalculator = new EEPaidRPPGSIBasePlusAMBInForceModalAmountCalculator();
            _eRPaidRPPGSIBasePlusAMBInForceModalAmountCalculator = new ERPaidRPPGSIBasePlusAMBInForceModalAmountCalculator();
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public void CalculateInforceAmounts(PriorCoverageRequest request)
        {
            Log.TraceFormat("+CalculateInforceAmounts");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var planDesignRequestClasses = unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(i => i.PlanDesignRequest.Id == request.PDRId);
                var censusParticipants = unitOfWork.Repository<Participant>().Linq().Where(c => request.ParticipantIds.Contains(c.Id) && (c.IsEligible == true || c.IsEligible == null) && c.IsActive == true).ToList();
                var distinctClasses = censusParticipants.GroupBy(c => c.PlanDesignRequestClass).Where(gr => gr.Key != null).Select(gr => gr.Key);

                if (distinctClasses != null)
                {
                    foreach (var pdrC in distinctClasses)
                    {
                        var planDesignRequestClass = distinctClasses.FirstOrDefault(c => c.Id == pdrC.Id);
                        if (planDesignRequestClass != null && censusParticipants.Any())
                        {
                            CalculateAMBBenefitAmounts(unitOfWork, planDesignRequestClass, cmsCase, censusParticipants);
                        }
                    }
                }
                unitOfWork.Commit();
            }

            Log.TraceFormat("-CalculateInforceAmounts");
        }

        private void CalculateAMBBenefitAmounts(IUnitOfWork unitOfWork, PlanDesignRequestClass planDesignRequestClass, Case cmsCase, List<Participant> participants)
        {
            Log.TraceFormat("+ApplyRecalculationForInforceAmounts");

            var ambBenefitAmountCalculationRequest = new AMBBenefitAmountCalculationRequest();

            var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(p => p.PlanDesignRequestClass.Id == planDesignRequestClass.Id && p.IsActive);
            if (pdrSoldClass != null && pdrSoldClass.PlanDesignRequestClass.CensusParticipants.Any())
            {
                BuildAMBCalculationRequestForSoldClass(pdrSoldClass, ambBenefitAmountCalculationRequest, cmsCase);
            }
            else
            {
                BuildAMBCalculationRequestForPreSoldClass(planDesignRequestClass, ambBenefitAmountCalculationRequest, cmsCase);
            }

            foreach (var selectedParticipant in participants)
            {
                ambBenefitAmountCalculationRequest.PolicyDetails = new List<ParticipantExistingPolicyDetailRequest>();

                var participantPolicy = selectedParticipant.ParticipantExistingPolicies != null ? selectedParticipant.ParticipantExistingPolicies.FirstOrDefault() : null;
                var policyDetails = selectedParticipant.ParticipantExistingPolicies.SelectMany(c => c.ParticipantExistingPolicyDetails).ToList();

                if (policyDetails != null)
                {
                    foreach (var policy in policyDetails)
                    {
                        var ambPolicyDetail = new ParticipantExistingPolicyDetailRequest();
                        ambPolicyDetail.AnnualizedPremium = policy.AnnualizedPremium ?? 0;
                        ambPolicyDetail.ModalPremium = policy.ModalPremium ?? 0;
                        ambPolicyDetail.CaseNumber = policy.CaseNumber != null? policy.CaseNumber.Trim() : string.Empty;
                        ambPolicyDetail.CLOASPolicyStatus = policy.CLOASPolicyStatus;
                        ambPolicyDetail.PremiumPayer = policy.PremiumPayer;
                        ambPolicyDetail.BillingMode = policy.BillingModeTypeDescription;

                        ambBenefitAmountCalculationRequest.PolicyDetails.Add(ambPolicyDetail);
                    }
                }

                AMBBenefitAmountCalculate(ambBenefitAmountCalculationRequest, selectedParticipant);

                unitOfWork.Repository<Participant>().Save(selectedParticipant);
            }

            Log.TraceFormat("-ApplyRecalculationForInforceAmounts");
        }

        private void BuildAMBCalculationRequestForSoldClass(PDRSoldClass pdrSoldClass, AMBBenefitAmountCalculationRequest ambBenefitAmountCalculationRequest, Case cmsCase)
        {
            var pdrSoldClassPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
            ambBenefitAmountCalculationRequest.PremiumPayerType = pdrSoldClassPlan.PremiumPayerAndTaxabilityType != null ? (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum?)pdrSoldClassPlan.PremiumPayerAndTaxabilityType.Id : null;
            ambBenefitAmountCalculationRequest.CostShareTypeOfShare = pdrSoldClassPlan.TypeOfShareType != null ? pdrSoldClassPlan.TypeOfShareType : null;
            ambBenefitAmountCalculationRequest.EmployeePaidPremium = (pdrSoldClassPlan.EmployeePaidPremium / 100) ?? 0;
            ambBenefitAmountCalculationRequest.EmployerPaysUpto = pdrSoldClassPlan.EmployerPaysupto ?? 0;
            ambBenefitAmountCalculationRequest.EmployerPaidPremium = (pdrSoldClassPlan.EmployerPaidPremium / 100) ?? 0;
            ambBenefitAmountCalculationRequest.CaseNumber = cmsCase.CaseNumber;
            ambBenefitAmountCalculationRequest.PlanDesignType = pdrSoldClassPlan.PlanDesignType;
        }

        private void BuildAMBCalculationRequestForPreSoldClass(PlanDesignRequestClass pdrClass, AMBBenefitAmountCalculationRequest ambBenefitAmountCalculationRequest, Case cmsCase)
        {
            ambBenefitAmountCalculationRequest.PremiumPayerType = pdrClass.ApprovedPremiumPayerAndTaxabilityType != null ? (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum?)pdrClass.ApprovedPremiumPayerAndTaxabilityType.Id : null;
            ambBenefitAmountCalculationRequest.CostShareTypeOfShare = pdrClass.ApprovedTypeOfShareType != null ? pdrClass.ApprovedTypeOfShareType : null;
            ambBenefitAmountCalculationRequest.EmployeePaidPremium = (pdrClass.ApprovedEmployeePaidPremium / 100) ?? 0;
            ambBenefitAmountCalculationRequest.EmployerPaysUpto = pdrClass.ApprovedEmployerPaysupto ?? 0;
            ambBenefitAmountCalculationRequest.EmployerPaidPremium = (pdrClass.ApprovedEmployerPaidPremium / 100) ?? 0;
            ambBenefitAmountCalculationRequest.CaseNumber = cmsCase.CaseNumber;
            ambBenefitAmountCalculationRequest.PlanDesignType = pdrClass.ApprovedPlanDesignType;
        }

        public void AMBBenefitAmountCalculate(AMBBenefitAmountCalculationRequest request, Participant participant)
        {
            var response = new AMBBenefitAmountCalculationResponse();

            if (request.PlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                response.EEPaidIDIGSIBasePlusAMBInForceAnnualAmount = _eEPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator.AMBCalculate(request);
                response.ERPaidIDIGSIBasePlusAMBInForceAnnualAmount = _eRPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator.AMBCalculate(request);
                response.EEPaidIDIGSIBasePlusAMBInForceModalAmount = _eEPaidIDIGSIBasePlusAMBInForceModalAmountCalculator.AMBCalculate(request);
                response.ERPaidIDIGSIBasePlusAMBInForceModalAmount = _eRPaidIDIGSIBasePlusAMBInForceModalAmountCalculator.AMBCalculate(request);
            }

            else
            {
                if(participant.ParticipantExistingPolicies != null 
                    && (participant.ParticipantExistingPolicies.Any(c => (c.FullyUnderwrittenRPP != null && c.FullyUnderwrittenRPP > 0) 
                    || (c.GSIRPPBaseAMB != null && c.GSIRPPBaseAMB > 0))))
                {
                    response.ERPaidRPPGSIBasePlusAMBInForceAnnualAmount = _eRPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator.AMBCalculate(request);
                    response.EEPaidRPPGSIBasePlusAMBInForceAnnualAmount = _eEPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator.AMBCalculate(request);
                    response.ERPaidRPPGSIBasePlusAMBInForceModalAmount = _eRPaidRPPGSIBasePlusAMBInForceModalAmountCalculator.AMBCalculate(request);
                    response.EEPaidRPPGSIBasePlusAMBInForceModalAmount = _eEPaidRPPGSIBasePlusAMBInForceModalAmountCalculator.AMBCalculate(request);
                }
            }

            CopyAMBCalculationResponseToParticipant(response, participant);
        }

        private static void CopyAMBCalculationResponseToParticipant(AMBBenefitAmountCalculationResponse calcResponse, Participant participant)
        {
            participant.EEPaidIDIGSIBasePlusAMBInForceAnnualAmount = calcResponse.EEPaidIDIGSIBasePlusAMBInForceAnnualAmount;
            participant.ERPaidIDIGSIBasePlusAMBInForceAnnualAmount = calcResponse.ERPaidIDIGSIBasePlusAMBInForceAnnualAmount;
            participant.EEPaidIDIGSIBasePlusAMBInForceModalAmount = calcResponse.EEPaidIDIGSIBasePlusAMBInForceModalAmount;
            participant.ERPaidIDIGSIBasePlusAMBInForceModalAmount = calcResponse.ERPaidIDIGSIBasePlusAMBInForceModalAmount;

            participant.ERPaidRPPGSIBasePlusAMBInForceAnnualAmount = calcResponse.ERPaidRPPGSIBasePlusAMBInForceAnnualAmount;
            participant.EEPaidRPPGSIBasePlusAMBInForceAnnualAmount = calcResponse.EEPaidRPPGSIBasePlusAMBInForceAnnualAmount;
            participant.ERPaidRPPGSIBasePlusAMBInForceModalAmount = calcResponse.ERPaidRPPGSIBasePlusAMBInForceModalAmount;
            participant.EEPaidRPPGSIBasePlusAMBInForceModalAmount = calcResponse.EEPaidRPPGSIBasePlusAMBInForceModalAmount;
        }
    }
}