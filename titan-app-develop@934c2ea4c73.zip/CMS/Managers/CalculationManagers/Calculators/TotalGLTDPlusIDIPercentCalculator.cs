﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Logger.Static;
using Common.Utilities;
using CMS.Model.Enums;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class TotalGLTDPlusIDIPercentCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;

            if (request == null)
            {
                return 0.0m;
            }

            //if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan && request.ClassCalculationRequest.IsVoluntaryBuyUpPlan)
            if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan)
            {
                request.IDIInsurableIncomeAmount = request.VGSIBuyUpIDIInsurableIncomeAmount;
            }

            request.TotalGLTDPlusIDIAmount = request.TotalGLTDPlusIDIAmount.HasValue ? request.TotalGLTDPlusIDIAmount : 0.0m;
            request.IDIInsurableIncomeAmount = request.IDIInsurableIncomeAmount.HasValue ? request.IDIInsurableIncomeAmount : 0.0m;
            if (request.IDIInsurableIncomeAmount.Value == 0.0m)
            {
                return null;
            }

            result = ((request.TotalGLTDPlusIDIAmount * 12) / request.IDIInsurableIncomeAmount).Value.Roundoff(4);

            return result;
        }
    }
}
