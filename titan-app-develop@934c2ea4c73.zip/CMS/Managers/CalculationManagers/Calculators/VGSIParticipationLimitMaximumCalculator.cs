﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class VGSIParticipationLimitMaximumCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            decimal? applicableMaximumParticipationLimit = 0.0m;
            if (request == null)
            {
                return result;
            }

            applicableMaximumParticipationLimit = request.ClassCalculationRequest.ContractState == StateTypeEnum.CA ? 
                request.ClassCalculationRequest.EligibilityConfigCAParticipationLimit : request.ClassCalculationRequest.EligibilityConfigParticipationLimit;

            request.LTDCalculatedAmount = request.LTDCalculatedAmount.HasValue ? request.LTDCalculatedAmount : 0.0m;
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;
            request.GSICalculatedAmountResponse = request.GSICalculatedAmountResponse.HasValue ? request.GSICalculatedAmountResponse : 0.0m;

            if (request.ClassCalculationRequest.EligibilityConfigParticipationLimit.HasValue && request.ClassCalculationRequest.ContractState != StateTypeEnum.CA)
            {
                result = request.ClassCalculationRequest.EligibilityConfigParticipationLimit;
            }
            else
            {
                result = applicableMaximumParticipationLimit;
            }

            result = result - request.LTDCalculatedAmount.Value - request.ExistingIDIAmount.Value - request.GSICalculatedAmountResponse.Value;
            return result;
        }
    }
}
