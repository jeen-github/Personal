﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Logger.Static;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class TotalGLTDPlusIDICalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;
            if (request == null)
            {
                return 0.0m;
            }
            request.LTDCalculatedAmount = request.LTDCalculatedAmount.HasValue ? request.LTDCalculatedAmount : 0.0m;
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;
            request.GSICalculatedAmountResponse = request.GSICalculatedAmountResponse.HasValue ? request.GSICalculatedAmountResponse : 0.0m;
            request.VGSIBuyUpBenefitAmount = request.VGSIBuyUpBenefitAmount.HasValue ? request.VGSIBuyUpBenefitAmount : 0.0m;
            request.BaseAMBCalculatedAmountResponse = request.BaseAMBCalculatedAmountResponse.HasValue ? request.BaseAMBCalculatedAmountResponse : 0.0m;
            request.VGSIAMBCalculatedAmountResponse = request.VGSIAMBCalculatedAmountResponse.HasValue ? request.VGSIAMBCalculatedAmountResponse : 0.0m;

            if (request.ClassCalculationRequest.NotToIncludeGSIBuyUpAmount)
            {
                result = request.LTDCalculatedAmount.Value + request.ExistingIDIAmount.Value + request.GSICalculatedAmountResponse + request.BaseAMBCalculatedAmountResponse;
            }
            else
            {
                result = request.LTDCalculatedAmount.Value + request.ExistingIDIAmount.Value + request.GSICalculatedAmountResponse + request.VGSIBuyUpBenefitAmount + request.BaseAMBCalculatedAmountResponse + request.VGSIAMBCalculatedAmountResponse;
            }

            return result;
        }
    }
}
