﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IDIOtherIncomeCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            if (request == null)
            {
                return result;
            }

            request.OtherIncomeAmount = request.OtherIncomeAmount.HasValue ? request.OtherIncomeAmount : 0.0m;

            if (request.ClassCalculationRequest.CustomIDIInsurableOtherIncomePercentage.HasValue)
            {
                result = request.OtherIncomeAmount * request.ClassCalculationRequest.CustomIDIInsurableOtherIncomePercentage;
            }
            else
            {
                return request.OtherIncomeAmount;
            }
            return result;
        }
    }
}
