﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Common.Utilities;
using CMS.Model.Enums;


namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class LTDInsurableIncomeCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;
            if (request == null)
            {
                return 0.0m;
            }
            request.MostRecentSalaryAmount = request.MostRecentSalaryAmount.HasValue ? request.MostRecentSalaryAmount : 0.0m;
            request.MostRecentPaidBonusAmount = request.MostRecentPaidBonusAmount.HasValue ? request.MostRecentPaidBonusAmount : 0.0m;
            request.MostRecentPaidCommissionAmount = request.MostRecentPaidCommissionAmount.HasValue ? request.MostRecentPaidCommissionAmount : 0.0m;
            request.MostRecentPaidK1IncomeAmount = request.MostRecentPaidK1IncomeAmount.HasValue ? request.MostRecentPaidK1IncomeAmount : 0.0m;
            request.OtherIncomeAmount = request.OtherIncomeAmount.HasValue ? request.OtherIncomeAmount : 0.0m;
            request.AdditionalPriorPaidCommissionAmount = request.AdditionalPriorPaidCommissionAmount.HasValue ? request.AdditionalPriorPaidCommissionAmount : 0.0m;
            request.AdditionalPriorPaidBonusAmount = request.AdditionalPriorPaidBonusAmount.HasValue ? request.AdditionalPriorPaidBonusAmount : 0.0m;
            request.AdditionalPriorPaidK1IncomeAmount = request.AdditionalPriorPaidK1IncomeAmount.HasValue ? request.AdditionalPriorPaidK1IncomeAmount : 0.0m;
            request.MostRecentW2IncomeAmount = request.MostRecentW2IncomeAmount.HasValue ? request.MostRecentW2IncomeAmount : 0.0m;

            if (request.ClassCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage.HasValue
                || request.ClassCalculationRequest.CustomLTDInsurableClassBonusPercentage.HasValue
                || request.ClassCalculationRequest.CustomLTDInsurableClassCommissionPercentage.HasValue
                || request.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsPercentage.HasValue
                || request.ClassCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage.HasValue)
            {
                result = CustomLTDClassLevelBaseSalaryCalculate(request) + CustomLTDClassLevelBonusCalculate(request)
                        + CustomLTDClassLevelCommisionCalculate(request) + CustomLTDClassLevelK1EarningsCalculate(request)
                        + CustomLTDClassLevelOtherIncomeCalculate(request);
            }
            else
            {
                switch (request.ClassCalculationRequest.GroupLTDCoveredEarnings)
                {
                    case CoveredEarningsTypeEnum.BaseSalaryOnly:
                        result = request.MostRecentSalaryAmount;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                        result = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                        result = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount
                            + request.MostRecentPaidCommissionAmount;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Commission:
                        result = request.MostRecentSalaryAmount + request.MostRecentPaidCommissionAmount;
                        break;
                    case CoveredEarningsTypeEnum.W_2Income:
                        result = request.MostRecentW2IncomeAmount;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings:
                        result = request.MostRecentPaidK1IncomeAmount;
                        break;
                    case CoveredEarningsTypeEnum.TotalCompensation:
                        result = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount
                            + request.MostRecentPaidCommissionAmount + request.MostRecentPaidK1IncomeAmount
                            + request.OtherIncomeAmount;
                        break;
                }
            }

            return result != null ? result.Value.Roundoff(2) : result;
        }

        private decimal? CustomLTDClassLevelBaseSalaryCalculate(BenefitAmountsCalculationRequest request)
        {
            request.ClassCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage = request.ClassCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage.HasValue ? request.ClassCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage : 0.0m;
            return request.MostRecentSalaryAmount * request.ClassCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage;
        }

        private decimal? CustomLTDClassLevelBonusCalculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            switch (request.ClassCalculationRequest.CustomLTDInsurableClassBonusNoOfYear.ToString())
            {
                case "1":
                    result = (request.MostRecentPaidBonusAmount * request.ClassCalculationRequest.CustomLTDInsurableClassBonusPercentage);
                    break;
                case "2":
                    result = (((request.MostRecentPaidBonusAmount + request.PriorPaidBonusAmount) / request.ClassCalculationRequest.CustomLTDInsurableClassBonusNoOfYear) * request.ClassCalculationRequest.CustomLTDInsurableClassBonusPercentage);
                    break;
                case "3":
                    result = (((request.MostRecentPaidBonusAmount + request.PriorPaidBonusAmount + request.AdditionalPriorPaidBonusAmount) / request.ClassCalculationRequest.CustomLTDInsurableClassBonusNoOfYear) * request.ClassCalculationRequest.CustomLTDInsurableClassBonusPercentage);
                    break;
            }

            return result;
        }

        private decimal? CustomLTDClassLevelCommisionCalculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            switch (request.ClassCalculationRequest.CustomLTDInsurableClassCommissionsNoOfYear.ToString())
            {
                case "1":
                    result = (request.MostRecentPaidCommissionAmount * request.ClassCalculationRequest.CustomLTDInsurableClassCommissionPercentage);
                    break;
                case "2":
                    result = (((request.MostRecentPaidCommissionAmount + request.PriorPaidCommissionAmount) / request.ClassCalculationRequest.CustomLTDInsurableClassCommissionsNoOfYear) * request.ClassCalculationRequest.CustomLTDInsurableClassCommissionPercentage);
                    break;
                case "3":
                    result = (((request.MostRecentPaidCommissionAmount + request.PriorPaidCommissionAmount + request.AdditionalPriorPaidCommissionAmount) / request.ClassCalculationRequest.CustomLTDInsurableClassCommissionsNoOfYear) * request.ClassCalculationRequest.CustomLTDInsurableClassCommissionPercentage);
                    break;
            }

            return result;
        }

        private decimal? CustomLTDClassLevelK1EarningsCalculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            switch (request.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsNoOfYear.ToString())
            {
                case "1":
                    result = (request.MostRecentPaidK1IncomeAmount * request.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsPercentage);
                    break;
                case "2":
                    result = (((request.MostRecentPaidK1IncomeAmount + request.PriorPaidK1IncomeAmount) / request.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsNoOfYear) * request.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsPercentage);
                    break;
                case "3":
                    result = (((request.MostRecentPaidK1IncomeAmount + request.PriorPaidK1IncomeAmount + request.AdditionalPriorPaidK1IncomeAmount) / request.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsNoOfYear) * request.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsPercentage);
                    break;
            }

            return result;
        }

        private decimal? CustomLTDClassLevelOtherIncomeCalculate(BenefitAmountsCalculationRequest request)
        {
            request.ClassCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage = request.ClassCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage.HasValue ? request.ClassCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage : 0.0m;
            return request.OtherIncomeAmount * request.ClassCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage;
        }
    }
}