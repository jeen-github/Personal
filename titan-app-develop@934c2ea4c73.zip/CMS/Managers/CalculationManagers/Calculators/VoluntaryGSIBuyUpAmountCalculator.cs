﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class VoluntaryGSIBuyUpAmountCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            if (request == null)
            {
                return 0.0m;
            }
            if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == null)
            {
                return 0.0m;
            }

            request.IDIInsurableIncomeAmount = request.IDIInsurableIncomeAmount.HasValue ? request.IDIInsurableIncomeAmount : 0m;
            request.IDIReplacementPercent = request.IDIReplacementPercent.HasValue ? request.IDIReplacementPercent : 0m;
            request.LTDCalculatedAmount = request.LTDCalculatedAmount.HasValue ? request.LTDCalculatedAmount : 0m;

            switch (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType)
            {
                case PlanDesignGSITypeEnum.SupplementalPlan:
                    result = ((request.IDIInsurableIncomeAmount.Value * (request.IDIReplacementPercent.Value)) / 12 - request.LTDCalculatedAmount.Value).Roundoff(2);
                    break;
                case PlanDesignGSITypeEnum.BonusOnlyPlan:
                    result = ((request.IDIInsurableIncomeAmount.Value * (request.IDIReplacementPercent.Value)) / 12).Roundoff(2);
                    break;
            }

            return result = result < 0 ? 0.0m : result.Value.NearestRoundoff(10);
        }
    }
}
