﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IDIK1IncomeCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            if (request == null)
            {
                return result;
            }

            if (request.ClassCalculationRequest.PlanDesignType == null)
            {
                return 0.0m;
            }

            if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan 
                || (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan 
                && request.ClassCalculationRequest.RetirementContributionsType != RetirementContributionsTypeEnum.PercentofCoveredEarnings))
            {
                return 0.0m;
            }

            request.PriorPaidK1IncomeAmount = request.PriorPaidK1IncomeAmount.HasValue ? request.PriorPaidK1IncomeAmount : 0.0m;
            request.MostRecentPaidK1IncomeAmount = request.MostRecentPaidK1IncomeAmount.HasValue ? request.MostRecentPaidK1IncomeAmount : 0.0m;
            request.AdditionalPriorPaidK1IncomeAmount = request.AdditionalPriorPaidK1IncomeAmount.HasValue ? request.AdditionalPriorPaidK1IncomeAmount : 0.0m;

            if (request.ClassCalculationRequest.PlanDesignType != PlanDesignTypeEnum.BonusOnlyPlan)
            {
                if (request.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage.HasValue)
                {
                    result = CustomIDIK1EarningsCalculation(request, result);
                }
                else if (request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.K_1Earnings || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.TotalCompensation)
                {
                    result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount);
                }
            }
            else
            {
                if (request.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage.HasValue)
                {
                    result = CustomIDIK1EarningsCalculation(request, result);
                }
                else if (request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly == CoveredEarningsBonusOnlyTypeEnum.K_1Earnings
                    || request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly == CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus)
                {
                    result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount);
                }
            }
            return result;
        }
        
        private decimal? CustomIDIK1EarningsCalculation(BenefitAmountsCalculationRequest request, decimal? result)
        {
            switch (request.ClassCalculationRequest.CustomIDIInsurableK1EarningsNoOfYear.ToString())
            {
                case "1":
                    result = (request.MostRecentPaidK1IncomeAmount * request.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage);
                    break;
                case "2":
                    result = (((request.MostRecentPaidK1IncomeAmount + request.PriorPaidK1IncomeAmount) / request.ClassCalculationRequest.CustomIDIInsurableK1EarningsNoOfYear) * request.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage);
                    break;
                case "3":
                    result = (((request.MostRecentPaidK1IncomeAmount + request.PriorPaidK1IncomeAmount + request.AdditionalPriorPaidK1IncomeAmount) / request.ClassCalculationRequest.CustomIDIInsurableK1EarningsNoOfYear) * request.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage);
                    break;
            }

            return result;
        }
    }
}
