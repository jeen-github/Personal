﻿using CMS.Interfaces.Managers.PreQuoteCalculationManagers;
using Logger.Static;
using CMS.Model.Enums;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IDIAmountCalculator
    {
        public decimal? Calculate(PreQuoteCalculationRequest request)
        {
            if (request == null)
            {
                return 0.0m;
            }

            request.IDIInsurableIncomeAmount = request.IDIInsurableIncomeAmount.HasValue ? request.IDIInsurableIncomeAmount : 0m;
            request.IDIReplacementPercent = request.IDIReplacementPercent.HasValue ? request.IDIReplacementPercent : 0m;
            request.LTDCalculatedAmount = request.LTDCalculatedAmount.HasValue ? request.LTDCalculatedAmount : 0m;
            request.LTDPercentage = request.LTDPercentage.HasValue ? request.LTDPercentage : 0m;
            request.IDIPercentage = request.IDIPercentage.HasValue ? request.IDIPercentage : 0m;
            request.MaximumReplacementRatio = request.MaximumReplacementRatio.HasValue ? request.MaximumReplacementRatio : 0m;
            request.IDICoversFirst = request.IDICoversFirst.HasValue ? request.IDICoversFirst : 0m;
            request.LTDCoversNext = request.LTDCoversNext.HasValue ? request.LTDCoversNext : 0m;
            request.AnnualContribution = request.AnnualContribution.HasValue ? request.AnnualContribution : 0m;

            decimal? result = null;
            decimal? result1 = 0m;
            decimal? result2 = 0m;
            switch (request.PlanDesignType)
            {
                case PlanDesignTypeEnum.SupplementalPlan:
                    result = ((request.IDIInsurableIncomeAmount.Value * (request.IDIReplacementPercent.Value / 100)) / 12 - request.LTDCalculatedAmount.Value).Roundoff();
                    break;

                case PlanDesignTypeEnum.BonusOnlyPlan:
                case PlanDesignTypeEnum.StandAloneIDIPlan:
                    result = ((request.IDIInsurableIncomeAmount.Value * (request.IDIReplacementPercent.Value / 100)) / 12).Roundoff();
                    break;

                case PlanDesignTypeEnum.CombinationPlan:
                    if (request.LTDPercentage.HasValue && request.LTDPercentage != 0m)
                    {
                        result1 = (((request.LTDPercentage.Value / 100) * request.IDIInsurableIncomeAmount.Value) / 12).Roundoff();
                    }
                    if (request.IDIPercentage.HasValue && request.IDIPercentage != 0m)
                    {
                        result2 = (((request.IDIPercentage.Value / 100) * request.IDIInsurableIncomeAmount.Value) / 12).Roundoff();
                    }
                    result = result1 + result2;
                    break;

                case PlanDesignTypeEnum.ReverseCombinationPlan:
                    if (request.IDICoversFirst.HasValue && request.IDICoversFirst != 0m)
                    {
                        result1 = ((request.MaximumReplacementRatio.Value / 100 * request.IDICoversFirst.Value) / 12).Roundoff();
                    }
                    if (request.LTDCoversNext.HasValue && request.LTDCoversNext != 0m)
                    {
                        result2 = ((request.MaximumReplacementRatio.Value / 100 * request.LTDCoversNext.Value) / 12).Roundoff();
                    }
                    result = result1 + result2;
                    break;

                case PlanDesignTypeEnum.FlatBenefitPlan:
                    if (request.FlatRateOther != null)
                    {
                        result = (decimal)request.FlatRateOther;
                    }
                    else
                    {
                        result = (decimal)request.FlatRateTypeId;
                    }
                    break;

                case PlanDesignTypeEnum.StandAloneRPPPlan:
                    if (request.RetirementContributionsType == RetirementContributionsTypeEnum.FlatContribution)
                    {
                        result = (request.AnnualContribution.Value / 12).Roundoff();
                    }
                    break;
            }
            return result;
        }
    }
}
