﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class VGSIBuyUpBenefitCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;
            decimal? coverageAgainstTotalMaxGSI = 0.0m;
            decimal? newVGSIWithAmbAmount = 0.0m;
            decimal? eligibleCoverageAmount = 0.0m;

            if (request == null)
            {
                return result;
            }
            request.VGSICoveragePossibleBeforeIandPMaximumAmount = request.VGSICoveragePossibleBeforeIandPMaximumAmount.HasValue ? request.VGSICoveragePossibleBeforeIandPMaximumAmount : 0.0m;            
            request.VGSIIssueLimitMaximumAmount = request.VGSIIssueLimitMaximumAmount.HasValue ? request.VGSIIssueLimitMaximumAmount : 0.0m;
            request.ParticipationLimitMaximumAmount = request.ParticipationLimitMaximumAmount.HasValue ? request.ParticipationLimitMaximumAmount : 0.0m;
            request.ClassCalculationRequest.TotalMaxGSIAmount = request.ClassCalculationRequest.TotalMaxGSIAmount.HasValue ? request.ClassCalculationRequest.TotalMaxGSIAmount : 0.0m;
            request.GSICalculatedAmountResponse = request.GSICalculatedAmountResponse.HasValue ? request.GSICalculatedAmountResponse : 0.0m;
            request.VGSIBuyUpMaxAmount = request.VGSIBuyUpMaxAmount.HasValue ? request.VGSIBuyUpMaxAmount : 0.0m;
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;

            coverageAgainstTotalMaxGSI = request.ClassCalculationRequest.TotalMaxGSIAmount.Value - request.GSICalculatedAmountResponse.Value;
            request.ClassCalculationRequest.BuyUpPlanGSIPercentage = request.ClassCalculationRequest.BuyUpPlanGSIPercentage.HasValue ? request.ClassCalculationRequest.BuyUpPlanGSIPercentage : 1.0m;
            request.ManualVGSIBuyUpBenefitAmount = request.ManualVGSIBuyUpBenefitAmount.HasValue ? request.ManualVGSIBuyUpBenefitAmount : 0.0m;
            request.ManualVGSIBuyUpAMBIncreaseAmount = request.ManualVGSIBuyUpAMBIncreaseAmount.HasValue ? request.ManualVGSIBuyUpAMBIncreaseAmount : 0.0m;
            if (request.IsBuyUpAMBIncreaseIndicator)
            {
                eligibleCoverageAmount = ((request.VGSIBuyUpIDIInsurableIncomeAmount * (request.ClassCalculationRequest.VGSIMaximumReplacementRatio / 100)) / 12).Value.Roundoff(2)
                                        - request.LTDCalculatedAmount - request.ExistingIDIAmount - request.GSICalculatedAmountResponse;                

                newVGSIWithAmbAmount = eligibleCoverageAmount.Value.GetMinVal(request.ClassCalculationRequest.VoluntaryGSIAmount.Value - request.VGSIBuyUpMaxAmount.Value); // determining similar to BaseAmb calculation
            }


            if (request.ManualVGSIBuyUpBenefitAmount > 0)
            {
                result = request.ManualVGSIBuyUpBenefitAmount;
            }
            else if (request.ManualVGSIBuyUpAMBIncreaseAmount > 0)
            {
                result = request.ManualVGSIBuyUpAMBIncreaseAmount;
            }
            else
            {
                result = request.VGSICoveragePossibleBeforeIandPMaximumAmount.Value.GetMinVal(request.VGSICoveragePossibleBeforeIandPMaximumAmount.Value, request.VGSIIssueLimitMaximumAmount.Value, request.ParticipationLimitMaximumAmount, coverageAgainstTotalMaxGSI, request.ClassCalculationRequest.VoluntaryGSIAmount);
                if (result > 0)
                {
                    if (request.IsBuyUpAMBIncreaseIndicator)
                    {
                        result = result.Value.GetMinVal((decimal)newVGSIWithAmbAmount);
                    }                    
                }
                if (newVGSIWithAmbAmount > 0)
                {
                    result = newVGSIWithAmbAmount.Value.GetMinVal(result.Value);
                }
                if (result != null)
                {
                    result = result * request.ClassCalculationRequest.BuyUpPlanGSIPercentage;
                }
            }
            return result < 0.0m ? 0.0m : result.Value.NearestRoundoff(10);
        }
    }
}
