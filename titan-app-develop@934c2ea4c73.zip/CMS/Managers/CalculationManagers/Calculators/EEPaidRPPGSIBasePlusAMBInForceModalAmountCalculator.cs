﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using System.Linq;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class EEPaidRPPGSIBasePlusAMBInForceModalAmountCalculator
    {
        public decimal? AMBCalculate(AMBBenefitAmountCalculationRequest request)
        {
            decimal? eEPaidRPPGSIBasePlusAMBInForceModalAmount = 0.0m;

            if (request == null)
            {
                return 0.0m;
            }

            if (request.PremiumPayerType != null)
            {
                if (request.PremiumPayerType == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                {
                    var costSharePolicyInfo = request.PolicyDetails.Where(c => c.CaseNumber == request.CaseNumber
                            && c.CLOASPolicyStatus == "Inforce").ToList();

                    var modalPremiums = costSharePolicyInfo.Sum(c => c.ModalPremium);
                    modalPremiums = modalPremiums != null ? modalPremiums : 0;

                    if (costSharePolicyInfo.Any())
                    {
                        if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PercentofPremium)
                        {
                            eEPaidRPPGSIBasePlusAMBInForceModalAmount = modalPremiums * request.EmployeePaidPremium;
                        }
                        else if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PremiumAmount)
                        {
                            var policy = costSharePolicyInfo.FirstOrDefault();
                            if (policy != null && policy.BillingMode != null)
                            {
                                switch (policy.BillingMode)
                                {
                                    case "Monthly":
                                        eEPaidRPPGSIBasePlusAMBInForceModalAmount = modalPremiums - request.EmployerPaysUpto;
                                        break;
                                    case "Quarterly":
                                        eEPaidRPPGSIBasePlusAMBInForceModalAmount = modalPremiums - (request.EmployerPaysUpto * 3);
                                        break;
                                    case "Semi Annual":
                                    case "Half Yearly":
                                        eEPaidRPPGSIBasePlusAMBInForceModalAmount = modalPremiums - (request.EmployerPaysUpto * 6);
                                        break;
                                    case "Annual":
                                    case "Yearly":
                                        eEPaidRPPGSIBasePlusAMBInForceModalAmount = modalPremiums - (request.EmployerPaysUpto * 12);
                                        break;
                                }
                            }
                        }
                    }
                }
            }

            if (eEPaidRPPGSIBasePlusAMBInForceModalAmount.HasValue)
            {
                eEPaidRPPGSIBasePlusAMBInForceModalAmount = eEPaidRPPGSIBasePlusAMBInForceModalAmount < 0 ? 0.0m : eEPaidRPPGSIBasePlusAMBInForceModalAmount.Value.Roundoff(2);
            }

            return eEPaidRPPGSIBasePlusAMBInForceModalAmount;
        }
    }
}
