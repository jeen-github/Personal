﻿using CMS.Model.Enums;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class GuardianExistingIDICoverageTotalAmountCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;
            decimal? idiReplacementAmount = null;
            decimal? idiBenefitAmount = null;
            decimal? idiBenefitAmountForIgnore = null;

            if (request == null)
            {
                return 0.0m;
            }

            if (request.IDIReplacementPercentRequests.Any())
            {                
                idiBenefitAmount = request.IDIReplacementPercentRequests.Where(c => (c.IDICarrier_Id == IDICoverageCarrierTypeEnum.Berkshire || c.IDICarrier_Id == IDICoverageCarrierTypeEnum.Guardian)).Sum(c => c.IDIBenefitAmount);
                idiReplacementAmount = request.IDIReplacementPercentRequests.Where(c => c.IsReplaceCoverage == true && (c.IDICarrier_Id == IDICoverageCarrierTypeEnum.Berkshire || c.IDICarrier_Id == IDICoverageCarrierTypeEnum.Guardian)).Sum(c => c.IDIReplacementAmount);
                idiBenefitAmountForIgnore = request.IDIReplacementPercentRequests
                   .Where(c => c.IsIgnoreCoverage == true && c.IsReplaceCoverage == true && (c.IDICarrier_Id == IDICoverageCarrierTypeEnum.Berkshire || c.IDICarrier_Id == IDICoverageCarrierTypeEnum.Guardian)).Sum(c => c.IDIReplacementAmount);
                if (idiBenefitAmountForIgnore != null && idiBenefitAmountForIgnore!=0)
                {
                    result = (idiBenefitAmount- idiReplacementAmount)+ idiBenefitAmountForIgnore;
                }

                else
                {
                    if (idiBenefitAmount != null && idiReplacementAmount != null)
                    {
                        result = idiBenefitAmount - idiReplacementAmount;
                    }
                }
            }
            return result;
        }
    }
}
