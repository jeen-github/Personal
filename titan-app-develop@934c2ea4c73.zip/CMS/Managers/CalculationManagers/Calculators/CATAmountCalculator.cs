﻿using System;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Logger.Static;
using Common.Utilities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class CATAmountCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {

            decimal? result = null;

            if (request == null)
            {
                return 0.0m;
            }

            request.ClassCalculationRequest.CATAmount = request.ClassCalculationRequest.CATAmount.HasValue ? request.ClassCalculationRequest.CATAmount : 0.0m;

            //if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan && request.ClassCalculationRequest.IsVoluntaryBuyUpPlan)
            if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan)
            {
                request.IDIInsurableIncomeAmount = request.VGSIBuyUpIDIInsurableIncomeAmount;
            }

            request.IDIInsurableIncomeAmount = request.IDIInsurableIncomeAmount.HasValue ? request.IDIInsurableIncomeAmount : 0.0m;

            //if (request.ClassCalculationRequest.ContractState != StateTypeEnum.NJ)
            //{
                result = (request.ClassCalculationRequest.CATAmount).Value.GetMinVal(((request.IDIInsurableIncomeAmount / 12) - request.TotalGLTDPlusIDIAmount).Value.Roundoff(2), ((request.IDIInsurableIncomeAmount / 12).Value * 0.4m).Roundoff(2));
            //}
            //else
            //{
                //result = (request.GSICalculatedAmountResponse.Value.GetMinVal(request.ClassCalculationRequest.CATAmount.Value, ((request.IDIInsurableIncomeAmount.Value / 12) * 0.4m), ((request.IDIInsurableIncomeAmount.Value / 12) - request.TotalGLTDPlusIDIAmount.Value))).Value.Roundoff(2);
            //}

            if (result.HasValue)
            {
                result = result < 0 ? 0.0m : result.Value.NearestRoundoff(10);
            }
            return result;
        }
    }
}
