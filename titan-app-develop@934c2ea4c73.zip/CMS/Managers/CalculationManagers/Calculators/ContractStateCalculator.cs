﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Logger.Static;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class ContractStateCalculator
    {
        public StateTypeEnum? Calculate(BenefitAmountsCalculationRequest request)
        {
            StateTypeEnum? result = null;

            if (request == null)
            {
                return null;
            }

            if (request.ClassCalculationRequest.SitusType == Model.Enums.SitusTypeEnum.Corporate)
            {
                result = request.ClassCalculationRequest.CorporateSitusState;
            }
            else if (request.ClassCalculationRequest.SitusType == Model.Enums.SitusTypeEnum.Residence)
            {
                result = request.HomeState;
            }
            else if (request.ClassCalculationRequest.SitusType == Model.Enums.SitusTypeEnum.Multi_State)
            {
                if (request.HomeState.HasValue && request.HomeState == request.ClassCalculationRequest.SitusMultiState1Type)
                {
                    result = request.HomeState;
                }
                else if (request.HomeState.HasValue && request.HomeState == request.ClassCalculationRequest.SitusMultiState2Type)
                {
                    result = request.HomeState;
                }
                else if (request.HomeState.HasValue && request.HomeState == request.ClassCalculationRequest.SitusMultiState3Type)
                {
                    result = request.HomeState;
                }
                else
                {
                    result = request.ClassCalculationRequest.CorporateSitusState;
                }
            }
            return result;
        }
    }
}
