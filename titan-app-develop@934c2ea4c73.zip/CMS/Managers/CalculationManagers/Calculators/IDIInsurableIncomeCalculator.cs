﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IDIInsurableIncomeCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            if (request == null)
            {
                return 0.0m;
            }
            if (request.ClassCalculationRequest.PlanDesignType == null)
            {
                return 0.0m;
            }
            if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan || (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan && request.ClassCalculationRequest.RetirementContributionsType != RetirementContributionsTypeEnum.PercentofCoveredEarnings))
            {
                return 0.0m;
            }
            decimal? result = null;
            request.MostRecentSalaryAmount = request.MostRecentSalaryAmount.HasValue ? request.MostRecentSalaryAmount : 0.0m;
            request.MostRecentPaidBonusAmount = request.MostRecentPaidBonusAmount.HasValue ? request.MostRecentPaidBonusAmount : 0.0m;
            request.PriorPaidBonusAmount = request.PriorPaidBonusAmount.HasValue ? request.PriorPaidBonusAmount : 0.0m;
            request.MostRecentPaidCommissionAmount = request.MostRecentPaidCommissionAmount.HasValue ? request.MostRecentPaidCommissionAmount : 0.0m;
            request.PriorPaidCommissionAmount = request.PriorPaidCommissionAmount.HasValue ? request.PriorPaidCommissionAmount : 0.0m;
            request.MostRecentPaidK1IncomeAmount = request.MostRecentPaidK1IncomeAmount.HasValue ? request.MostRecentPaidK1IncomeAmount : 0.0m;
            request.PriorPaidK1IncomeAmount = request.PriorPaidK1IncomeAmount.HasValue ? request.PriorPaidK1IncomeAmount : 0.0m;
            request.OtherIncomeAmount = request.OtherIncomeAmount.HasValue ? request.OtherIncomeAmount : 0.0m;
            request.MostRecentW2IncomeAmount = request.MostRecentW2IncomeAmount.HasValue ? request.MostRecentW2IncomeAmount : 0.0m;

            request.CustomLTDInsurableIncomeBaseSalaryPercentage = request.CustomLTDInsurableIncomeBaseSalaryPercentage.HasValue ? request.CustomLTDInsurableIncomeBaseSalaryPercentage / 100 : 0.0m;
            request.CustomLTDInsurableIncomeBonusPercentage = request.CustomLTDInsurableIncomeBonusPercentage.HasValue ? request.CustomLTDInsurableIncomeBonusPercentage / 100 : 0.0m;
            request.CustomLTDInsurableIncomeCommissionPercentage = request.CustomLTDInsurableIncomeCommissionPercentage.HasValue ? request.CustomLTDInsurableIncomeCommissionPercentage / 100 : 0.0m;
            request.CustomLTDInsurableIncomeOtherIncomePercentage = request.CustomLTDInsurableIncomeOtherIncomePercentage.HasValue ? request.CustomLTDInsurableIncomeOtherIncomePercentage / 100 : 0.0m;

            if (request.CustomLTDInsurableIncomeBaseSalaryPercentage > 0.0m
                || request.CustomLTDInsurableIncomeBonusPercentage > 0.0m
                || request.CustomLTDInsurableIncomeCommissionPercentage > 0.0m
                || request.CustomLTDInsurableIncomeOtherIncomePercentage > 0.0m)
            {
                result = request.MostRecentSalaryAmount * request.CustomLTDInsurableIncomeBaseSalaryPercentage
                        + request.MostRecentPaidBonusAmount * request.CustomLTDInsurableIncomeBonusPercentage
                        + request.MostRecentPaidCommissionAmount * request.CustomLTDInsurableIncomeCommissionPercentage
                        + request.OtherIncomeAmount * request.CustomLTDInsurableIncomeOtherIncomePercentage;
            }
            else if (request.ClassCalculationRequest.CustomIDIInsurableBaseSalaryPercentage.HasValue
                || request.ClassCalculationRequest.CustomIDIInsurableBonusPercentage.HasValue
                || request.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage.HasValue
                || request.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage.HasValue
                || request.ClassCalculationRequest.CustomIDIInsurableOtherIncomePercentage.HasValue)

            {
                decimal? customizeBaseSalary = request.ClassCalculationRequest.CustomIDIInsurableBaseSalaryPercentage > 0.0m ? new IDIBaseSalaryCalculator().Calculate(request) : 0.0m;
                decimal? customizeBonus = request.ClassCalculationRequest.CustomIDIInsurableBonusPercentage > 0.0m ? new IDIBonusIncomeCalculator().Calculate(request) : 0.0m;
                decimal? customizeCommission = request.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage > 0.0m ? new IDICommissionsIncomeCalculator().Calculate(request) : 0.0m;
                decimal? customizeK1 = request.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage > 0.0m ? new IDIK1IncomeCalculator().Calculate(request) : 0.0m;
                decimal? customizeOtherIncome = request.ClassCalculationRequest.CustomIDIInsurableOtherIncomePercentage > 0.0m ? new IDIOtherIncomeCalculator().Calculate(request) : 0.0m;
                result = customizeBaseSalary + customizeBonus + customizeCommission + customizeK1 + customizeOtherIncome;
            }
            else if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.BonusOnlyPlan)
            {
                switch (request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly)
                {
                    case CoveredEarningsBonusOnlyTypeEnum.Bonus:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount);
                        break;
                    case CoveredEarningsBonusOnlyTypeEnum.Commissions:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                        break;
                    case CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                        break;
                    case CoveredEarningsBonusOnlyTypeEnum.K_1Earnings:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount);
                        break;
                    case CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount)
                                + request.OtherIncomeAmount * 0.75m;
                        break;
                }
            }
            else
            {
                switch (request.ClassCalculationRequest.PDRClassCoveredEarnings)
                {
                    case CoveredEarningsTypeEnum.BaseSalaryOnly:
                        result = request.MostRecentSalaryAmount;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                        result = request.MostRecentSalaryAmount
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount);
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                        result = request.MostRecentSalaryAmount
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Commission:
                        result = request.MostRecentSalaryAmount
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                        break;
                    case CoveredEarningsTypeEnum.W_2Income:
                        result = request.MostRecentW2IncomeAmount;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount);
                        break;
                    case CoveredEarningsTypeEnum.TotalCompensation:
                        result = request.MostRecentSalaryAmount
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount)
                                + request.OtherIncomeAmount * 0.75m;
                        break;
                    default:
                        result = request.OtherIncomeAmount;
                        break;
                }
            }
            return result != null ? result.Value.Roundoff(2) : result;
        }
    }
}
