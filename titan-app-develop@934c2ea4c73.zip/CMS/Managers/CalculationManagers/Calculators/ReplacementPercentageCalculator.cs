﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Interfaces.Managers.PreQuoteCalculationManagers;
using Common.Utilities;


namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class ReplacementPercentageCalculator
    {
        public decimal? Calculate(PreQuoteCalculationRequest request)
        {
            decimal? result = 0.0m;
            if (request == null)
            {
                return 0.0m;
            }
            request.LTDCalculatedAmount = request.LTDCalculatedAmount.HasValue ? request.LTDCalculatedAmount : 0.0m;
            request.OtherExistingIDICoverageTotalAmount = request.OtherExistingIDICoverageTotalAmount.HasValue ? request.OtherExistingIDICoverageTotalAmount : 0.0m;
            request.GuardianExistingIDICoverageAmount = request.GuardianExistingIDICoverageAmount.HasValue ? request.GuardianExistingIDICoverageAmount : 0.0m;
            request.IDIInsurableIncomeAmount = request.IDIInsurableIncomeAmount.HasValue ? request.IDIInsurableIncomeAmount : 0.0m;
            if (request.IDIInsurableIncomeAmount.Value == 0.0m)
            {
                return 0.0m;
            }
            
            result = (((request.LTDCalculatedAmount.Value + request.OtherExistingIDICoverageTotalAmount + request.GuardianExistingIDICoverageAmount) / (request.IDIInsurableIncomeAmount / 12))).Value.Roundoff(2);

            return result;
        }
    }
}
