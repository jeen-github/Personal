﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Guardian.Core.Entities.Product.Enums;
using Common.Utilities;
using CMS.Model.Enums;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class EligibleCATAmountCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {

            decimal? result = null;

            if (request == null)
            {
                return 0.0m;
            }

            request.GSICalculatedAmountResponse = request.GSICalculatedAmountResponse.HasValue ? request.GSICalculatedAmountResponse : 0.0m;
            //if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan && request.ClassCalculationRequest.IsVoluntaryBuyUpPlan)
            if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan)
            {
                request.IDIInsurableIncomeAmount = request.VGSIBuyUpIDIInsurableIncomeAmount;
            }
            request.IDIInsurableIncomeAmount = request.IDIInsurableIncomeAmount.HasValue ? request.IDIInsurableIncomeAmount : 0.0m;
            request.TotalGLTDPlusIDIAmount = request.TotalGLTDPlusIDIAmount.HasValue ? request.TotalGLTDPlusIDIAmount : 0.0m;
            request.ClassCalculationRequest.CATAmount = request.ClassCalculationRequest.CATAmount.HasValue ? request.ClassCalculationRequest.CATAmount : 0.0m;

            if (request.ClassCalculationRequest.ContractState == StateTypeEnum.CA || request.ClassCalculationRequest.ContractState == StateTypeEnum.TX)
            {
                result = 0.0m;
            }
            //else if (request.ClassCalculationRequest.ContractState == StateTypeEnum.NJ)
            //{
            //    result = (request.GSICalculatedAmountResponse.Value.GetMinVal(request.ClassCalculationRequest.CATAmount.Value, ((request.IDIInsurableIncomeAmount.Value / 12) * 0.4m), ((request.IDIInsurableIncomeAmount.Value / 12) - request.TotalGLTDPlusIDIAmount.Value))).Value.Roundoff(2);
            //}
            else
            {
                result = (((request.IDIInsurableIncomeAmount.Value / 12) * 0.4m).GetMinVal(((request.IDIInsurableIncomeAmount.Value / 12) - request.TotalGLTDPlusIDIAmount.Value), request.ClassCalculationRequest.CATAmount.Value)).Value.Roundoff(2);
            }
            result = result < 0 ? 0.0m : result;
            return result;
        }
    }
}
