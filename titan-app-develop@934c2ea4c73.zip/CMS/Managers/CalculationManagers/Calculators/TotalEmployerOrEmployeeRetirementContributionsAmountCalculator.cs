﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class TotalEmployerOrEmployeeRetirementContributionsAmountCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {

            if (request == null)
            {
                return 0.0m;
            }
            if (request.ClassCalculationRequest.PlanDesignType == null)
            {
                return 0.0m;
            }

            request.MostRecentSalaryAmount = request.MostRecentSalaryAmount.HasValue ? request.MostRecentSalaryAmount : 0.0m;
            request.MostRecentPaidBonusAmount = request.MostRecentPaidBonusAmount.HasValue ? request.MostRecentPaidBonusAmount : 0.0m;
            request.PriorPaidBonusAmount = request.PriorPaidBonusAmount.HasValue ? request.PriorPaidBonusAmount : 0.0m;
            request.MostRecentPaidCommissionAmount = request.MostRecentPaidCommissionAmount.HasValue ? request.MostRecentPaidCommissionAmount : 0.0m;
            request.PriorPaidCommissionAmount = request.PriorPaidCommissionAmount.HasValue ? request.PriorPaidCommissionAmount : 0.0m;
            request.MostRecentPaidK1IncomeAmount = request.MostRecentPaidK1IncomeAmount.HasValue ? request.MostRecentPaidK1IncomeAmount : 0.0m;
            request.PriorPaidK1IncomeAmount = request.PriorPaidK1IncomeAmount.HasValue ? request.PriorPaidK1IncomeAmount : 0.0m;
            request.OtherIncomeAmount = request.OtherIncomeAmount.HasValue ? request.OtherIncomeAmount : 0.0m;
            request.MostRecentW2IncomeAmount = request.MostRecentW2IncomeAmount.HasValue ? request.MostRecentW2IncomeAmount : 0.0m;

            decimal ? idiInsurableIncomeAmount = null;
            decimal? result = null;

            if (request.ClassCalculationRequest.RetirementContributionsType != null)
            {
                switch (request.ClassCalculationRequest.RetirementContributionsType)
                {
                    case RetirementContributionsTypeEnum.ActualContributiononCensus:
                        result = request.TotalEmployerOrEmployeeRetirementContributionAmount;
                        break;
                    case RetirementContributionsTypeEnum.FlatContribution:
                        result = request.ClassCalculationRequest.AnnualContribution;
                        break;
                    case RetirementContributionsTypeEnum.PercentofCoveredEarnings:
                        if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                        {
                            idiInsurableIncomeAmount = request.IDIInsurableIncomeAmount.Value;
                        }
                        else
                        {
                            switch (request.ClassCalculationRequest.RPPRiderCoveredEarnings)
                            {
                                case CoveredEarningsTypeEnum.BaseSalaryOnly:
                                    idiInsurableIncomeAmount = request.MostRecentSalaryAmount;
                                    break;
                                case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                                    idiInsurableIncomeAmount = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount;
                                    break;
                                case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                                    idiInsurableIncomeAmount = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount + request.MostRecentPaidCommissionAmount;
                                    break;
                                case CoveredEarningsTypeEnum.BaseSalary_Commission:
                                    idiInsurableIncomeAmount = request.MostRecentSalaryAmount + request.MostRecentPaidCommissionAmount;
                                    break;
                                case CoveredEarningsTypeEnum.K_1Earnings:
                                    idiInsurableIncomeAmount = request.MostRecentPaidK1IncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.TotalCompensation:
                                    idiInsurableIncomeAmount = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount + request.MostRecentPaidCommissionAmount + request.MostRecentW2IncomeAmount + request.MostRecentPaidK1IncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.Other:
                                    idiInsurableIncomeAmount = request.OtherIncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.W_2Income:
                                    idiInsurableIncomeAmount = request.MostRecentW2IncomeAmount != null ? request.MostRecentW2IncomeAmount : 0.0m;
                                    break;
                                case CoveredEarningsTypeEnum.IDIInsurableIncome:
                                    if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan)
                                    {
                                        idiInsurableIncomeAmount = request.LTDInsurableIncomeAmount.Value;
                                    }
                                    else
                                    {
                                        idiInsurableIncomeAmount = request.IDIInsurableIncomeAmount.Value;
                                    }
                                    break;
                            }
                        }

                        result = ((request.ClassCalculationRequest.RequestedPercentage.Value / 100) * idiInsurableIncomeAmount.Value).Roundoff(2);

                        break;
                }
            }
            else
            {
                return 0.0m;
            }

            return result;
        }
    }
}
