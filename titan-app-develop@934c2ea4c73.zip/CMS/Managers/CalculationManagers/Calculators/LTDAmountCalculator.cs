﻿using System;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Logger.Static;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class LTDAmountCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;
            if (request == null)
            {
                return 0.0m;
            }

            request.ClassCalculationRequest.GroupLTDCapAmount = request.ClassCalculationRequest.GroupLTDCapAmount.HasValue ? request.ClassCalculationRequest.GroupLTDCapAmount : 0.0m;
            request.ClassCalculationRequest.GroupLTDReplacementPercentage = request.ClassCalculationRequest.GroupLTDReplacementPercentage.HasValue ? request.ClassCalculationRequest.GroupLTDReplacementPercentage : 0.0m;
            request.LTDInsurableIncomeAmount = request.LTDInsurableIncomeAmount.HasValue ? request.LTDInsurableIncomeAmount : 0.0m;

            decimal? groupLTDCalc = ((request.LTDInsurableIncomeAmount.Value / 12) * (request.ClassCalculationRequest.GroupLTDReplacementPercentage.Value / 100)).Roundoff(2);
            if (!groupLTDCalc.HasValue)
            {
                groupLTDCalc = 0.0m;
            }

            int res = request.ClassCalculationRequest.GroupLTDCapAmount.Value.CompareTo(groupLTDCalc);
            if (res < 0)
            {
                result = request.ClassCalculationRequest.GroupLTDCapAmount;
            }
            else
            {
                result = groupLTDCalc;
            }

            return result;
        }
    }
}
