﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IDIBonusIncomeCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {

            decimal? result = 0.0m;

            if (request == null)
            {
                return result;
            }

            if (request.ClassCalculationRequest.PlanDesignType == null)
            {
                return 0.0m;
            }
            if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan && request.ClassCalculationRequest.RetirementContributionsType != RetirementContributionsTypeEnum.PercentofCoveredEarnings)
            {
                return 0.0m;
            }

            request.PriorPaidBonusAmount = request.PriorPaidBonusAmount.HasValue ? request.PriorPaidBonusAmount : 0.0m;
            request.MostRecentPaidBonusAmount = request.MostRecentPaidBonusAmount.HasValue ? request.MostRecentPaidBonusAmount : 0.0m;
            request.AdditionalPriorPaidBonusAmount = request.AdditionalPriorPaidBonusAmount.HasValue ? request.AdditionalPriorPaidBonusAmount : 0.0m;

            if (request.ClassCalculationRequest.PlanDesignType != PlanDesignTypeEnum.BonusOnlyPlan)
            {
                if (request.ClassCalculationRequest.CustomIDIInsurableBonusPercentage.HasValue)
                {
                    result = CustomIDIBonusCalculation(request, result);
                }
                else if (request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.BaseSalary_Bonus || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.W_2Income || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.TotalCompensation)
                {
                    result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount);
                }
            }
            else
            {
                if (request.ClassCalculationRequest.CustomIDIInsurableBonusPercentage.HasValue)
                {
                    result = CustomIDIBonusCalculation(request, result);
                }
                else if (request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly == CoveredEarningsBonusOnlyTypeEnum.Bonus 
                    || request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly == CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission 
                    || request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly == CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus)
                {
                    result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount);
                }
            }

            return result;
        }

        private decimal? CustomIDIBonusCalculation(BenefitAmountsCalculationRequest request, decimal? result)
        {
            switch (request.ClassCalculationRequest.CustomIDIInsurableBonusNoOfYear.ToString())
            {
                case "1":
                    result = (request.MostRecentPaidBonusAmount * request.ClassCalculationRequest.CustomIDIInsurableBonusPercentage);
                    break;
                case "2":
                    result = (((request.MostRecentPaidBonusAmount + request.PriorPaidBonusAmount) / request.ClassCalculationRequest.CustomIDIInsurableBonusNoOfYear) * request.ClassCalculationRequest.CustomIDIInsurableBonusPercentage);
                    break;
                case "3":
                    result = (((request.MostRecentPaidBonusAmount + request.PriorPaidBonusAmount + request.AdditionalPriorPaidBonusAmount) / request.ClassCalculationRequest.CustomIDIInsurableBonusNoOfYear) * request.ClassCalculationRequest.CustomIDIInsurableBonusPercentage);
                    break;
            }

            return result;
        }

    }
}
