﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using System.Linq;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class EEPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator
    {
        public decimal? AMBCalculate(AMBBenefitAmountCalculationRequest request)
        {
            decimal? eEPaidRPPGSIBasePlusAMBInForceAnnualAmount = 0.0m;

            if (request == null)
            {
                return 0.0m;
            }

            if (request.PremiumPayerType != null)
            {
                if (request.PremiumPayerType == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                {
                    var costSharePolicyInfo = request.PolicyDetails.Where(c => c.CaseNumber == request.CaseNumber
                            && c.CLOASPolicyStatus == "Inforce").ToList();

                    if (costSharePolicyInfo.Any())
                    {
                        if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PercentofPremium)
                        {
                            eEPaidRPPGSIBasePlusAMBInForceAnnualAmount = costSharePolicyInfo.Sum(c => c.AnnualizedPremium) * request.EmployeePaidPremium;
                        }
                        else if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PremiumAmount)
                        {
                            eEPaidRPPGSIBasePlusAMBInForceAnnualAmount = costSharePolicyInfo.Sum(c => c.AnnualizedPremium) - (request.EmployerPaysUpto * 12);
                        }
                    }
                }
            }

            if (eEPaidRPPGSIBasePlusAMBInForceAnnualAmount.HasValue)
            {
                eEPaidRPPGSIBasePlusAMBInForceAnnualAmount = eEPaidRPPGSIBasePlusAMBInForceAnnualAmount < 0 ? 0.0m : eEPaidRPPGSIBasePlusAMBInForceAnnualAmount.Value.Roundoff(2);
            }

            return eEPaidRPPGSIBasePlusAMBInForceAnnualAmount;
        }
    }
}
