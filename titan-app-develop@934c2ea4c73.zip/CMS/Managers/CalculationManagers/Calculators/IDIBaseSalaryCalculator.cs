﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Logger.Static;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IDIBaseSalaryCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            if (request == null)
            {
                return result;
            }

            request.MostRecentSalaryAmount = request.MostRecentSalaryAmount.HasValue ? request.MostRecentSalaryAmount : 0.0m;
            if (request.ClassCalculationRequest.PlanDesignType != PlanDesignTypeEnum.BonusOnlyPlan)
            {
                if(request.ClassCalculationRequest.CustomIDIInsurableBaseSalaryPercentage.HasValue)
                {
                    result = request.MostRecentSalaryAmount.Value * request.ClassCalculationRequest.CustomIDIInsurableBaseSalaryPercentage;
                }
                else if (request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.BaseSalaryOnly || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.BaseSalary_Bonus || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.W_2Income || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.TotalCompensation || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.BaseSalary_Commission)
                {
                    result = request.MostRecentSalaryAmount.Value;
                }
            }
            return result;
        }
    }
}
