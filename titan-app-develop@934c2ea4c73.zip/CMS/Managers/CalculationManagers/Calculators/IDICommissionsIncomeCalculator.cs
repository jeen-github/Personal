﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IDICommissionsIncomeCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            if (request == null)
            {
                return result;
            }

            if (request.ClassCalculationRequest.PlanDesignType == null)
            {
                return 0.0m;
            }
            if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan && request.ClassCalculationRequest.RetirementContributionsType != RetirementContributionsTypeEnum.PercentofCoveredEarnings)
            {
                return 0.0m;
            }

            request.PriorPaidCommissionAmount = request.PriorPaidCommissionAmount.HasValue ? request.PriorPaidCommissionAmount : 0.0m;
            request.MostRecentPaidCommissionAmount = request.MostRecentPaidCommissionAmount.HasValue ? request.MostRecentPaidCommissionAmount : 0.0m;
            request.AdditionalPriorPaidCommissionAmount = request.AdditionalPriorPaidCommissionAmount.HasValue ? request.AdditionalPriorPaidCommissionAmount : 0.0m;

            if (request.ClassCalculationRequest.PlanDesignType != PlanDesignTypeEnum.BonusOnlyPlan)
            {
                if (request.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage.HasValue)
                {
                    result = CustomIDICommisionCalculation(request, result);
                }
                else if (request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.BaseSalary_Commission || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.W_2Income || request.ClassCalculationRequest.PDRClassCoveredEarnings == CoveredEarningsTypeEnum.TotalCompensation)
                {
                    result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                }
            }
            else
            {
                if (request.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage.HasValue)
                {
                    result = CustomIDICommisionCalculation(request, result);
                }
                else if (request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly == CoveredEarningsBonusOnlyTypeEnum.Commissions 
                    || request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly == CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission
                    || request.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly == CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus)
                {
                    result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                }
            }

            return result;
        }


        private decimal? CustomIDICommisionCalculation(BenefitAmountsCalculationRequest request, decimal? result)
        {
            switch (request.ClassCalculationRequest.CustomIDIInsurableCommissionsNoOfYear.ToString())
            {
                case "1":
                    result = (request.MostRecentPaidCommissionAmount * request.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage);
                    break;
                case "2":
                    result = (((request.MostRecentPaidCommissionAmount + request.PriorPaidCommissionAmount) / request.ClassCalculationRequest.CustomIDIInsurableCommissionsNoOfYear) * request.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage);
                    break;
                case "3":
                    result = (((request.MostRecentPaidCommissionAmount + request.PriorPaidCommissionAmount + request.AdditionalPriorPaidCommissionAmount) / request.ClassCalculationRequest.CustomIDIInsurableCommissionsNoOfYear) * request.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage);
                    break;
            }

            return result;
        }
    }
}
