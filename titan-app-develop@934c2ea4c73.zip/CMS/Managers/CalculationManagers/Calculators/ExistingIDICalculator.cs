﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Logger.Static;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class ExistingIDICalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            if (request == null)
            {
                return 0.0m;
            }
            request.GuardianExistingIDICoverageAmount = request.GuardianExistingIDICoverageAmount.HasValue ? request.GuardianExistingIDICoverageAmount : 0.0m;
            request.OtherExistingIDICoverageAmount = request.OtherExistingIDICoverageAmount.HasValue ? request.OtherExistingIDICoverageAmount : 0.0m;
            request.FullyUnderWrittenIDIAmount = request.FullyUnderWrittenIDIAmount.HasValue ? request.FullyUnderWrittenIDIAmount : 0.0m;

            result = request.GuardianExistingIDICoverageAmount + request.OtherExistingIDICoverageAmount - request.FullyUnderWrittenIDIAmount;//(Removing the FUW amount here since it is already present in the Guardianexisting amount)

            return result;
        }
    }
}
