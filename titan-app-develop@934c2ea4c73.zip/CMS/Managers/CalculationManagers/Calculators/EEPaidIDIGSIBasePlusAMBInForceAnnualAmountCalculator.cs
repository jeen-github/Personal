﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using System.Linq;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class EEPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator
    {
        public decimal? AMBCalculate(AMBBenefitAmountCalculationRequest request)
        {
            decimal? eEPaidIDIGSIBasePlusAMBInForceAnnualAmount = 0.0m;

            if (request == null)
            {
                return 0.0m;
            }

            if (request.PremiumPayerType != null)
            {
                if (request.PremiumPayerType == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                {
                    var costSharePolicyInfo = request.PolicyDetails.Where(c => c.CaseNumber == request.CaseNumber
                            && c.CLOASPolicyStatus == "Inforce").ToList();

                    if (costSharePolicyInfo.Any())
                    {
                        if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PercentofPremium)
                        {
                            eEPaidIDIGSIBasePlusAMBInForceAnnualAmount = costSharePolicyInfo.Sum(c => c.AnnualizedPremium) * request.EmployeePaidPremium;
                        }
                        else if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PremiumAmount)
                        {
                            eEPaidIDIGSIBasePlusAMBInForceAnnualAmount = costSharePolicyInfo.Sum(c => c.AnnualizedPremium) - (request.EmployerPaysUpto * 12);
                        }
                    }
                }
                else
                {
                    var employerPaidPolicyInfo = request.PolicyDetails.Where(c => c.CaseNumber == request.CaseNumber
                    && c.CLOASPolicyStatus == "Inforce"
                    && c.PremiumPayer == PremiumPayerTypeEnum.Employee.GetDescription()).ToList();

                    if (employerPaidPolicyInfo.Any())
                    {
                        eEPaidIDIGSIBasePlusAMBInForceAnnualAmount = employerPaidPolicyInfo.Sum(c => c.AnnualizedPremium);
                    }
                }
            }

            if (eEPaidIDIGSIBasePlusAMBInForceAnnualAmount.HasValue)
            {
                eEPaidIDIGSIBasePlusAMBInForceAnnualAmount = eEPaidIDIGSIBasePlusAMBInForceAnnualAmount < 0 ? 0.0m : eEPaidIDIGSIBasePlusAMBInForceAnnualAmount.Value.Roundoff(2);
            }

            return eEPaidIDIGSIBasePlusAMBInForceAnnualAmount;
        }
    }
}
