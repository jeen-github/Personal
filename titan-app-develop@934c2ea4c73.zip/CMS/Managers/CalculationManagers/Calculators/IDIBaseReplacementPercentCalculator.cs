﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Logger.Static;
using Common.Utilities;
using CMS.Model.Enums;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IDIBaseReplacementPercentCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;

            //if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan && request.ClassCalculationRequest.IsVoluntaryBuyUpPlan)
            if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan )
            {
                request.IDIInsurableIncomeAmount = request.VGSIBuyUpIDIInsurableIncomeAmount;
            }

            if (request == null || !request.IDIInsurableIncomeAmount.HasValue || request.IDIInsurableIncomeAmount.Value == 0.0m)
            {
                return null;
            }
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;
            request.GSICalculatedAmountResponse = request.GSICalculatedAmountResponse.HasValue ? request.GSICalculatedAmountResponse : 0.0m;
            request.VGSIBuyUpBenefitAmount = request.VGSIBuyUpBenefitAmount.HasValue ? request.VGSIBuyUpBenefitAmount : 0.0m;
            request.BaseAMBCalculatedAmountResponse = request.BaseAMBCalculatedAmountResponse.HasValue ? request.BaseAMBCalculatedAmountResponse : 0.0m;
            request.VGSIAMBCalculatedAmountResponse = request.VGSIAMBCalculatedAmountResponse.HasValue ? request.VGSIAMBCalculatedAmountResponse : 0.0m;

            result = (((request.ExistingIDIAmount.Value + request.GSICalculatedAmountResponse.Value + request.VGSIBuyUpBenefitAmount.Value
                + request.BaseAMBCalculatedAmountResponse.Value + request.VGSIAMBCalculatedAmountResponse.Value) * 12) / request.IDIInsurableIncomeAmount.Value).Roundoff(4);

            return result;
        }
    }
}
