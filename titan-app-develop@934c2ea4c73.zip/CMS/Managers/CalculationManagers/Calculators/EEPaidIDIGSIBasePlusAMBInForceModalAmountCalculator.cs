﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using System.Linq;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class EEPaidIDIGSIBasePlusAMBInForceModalAmountCalculator
    {
        public decimal? AMBCalculate(AMBBenefitAmountCalculationRequest request)
        {
            decimal? eEPaidIDIGSIBasePlusAMBInForceModalAmount = 0.0m;

            if (request == null)
            {
                return 0.0m;
            }

            if (request.PremiumPayerType != null)
            {
                if (request.PremiumPayerType == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                {
                    var costSharePolicyInfo = request.PolicyDetails.Where(c => c.CaseNumber == request.CaseNumber
                                                && c.CLOASPolicyStatus == "Inforce").ToList();

                    var modalPremiums = costSharePolicyInfo.Sum(c => c.ModalPremium);
                    modalPremiums = modalPremiums != null ? modalPremiums : 0;

                    if (costSharePolicyInfo.Any())
                    {
                        if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PercentofPremium)
                        {
                            eEPaidIDIGSIBasePlusAMBInForceModalAmount = modalPremiums * request.EmployeePaidPremium;
                        }
                        else if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PremiumAmount)
                        {
                            var policy = costSharePolicyInfo.FirstOrDefault();
                            if (policy != null && policy.BillingMode != null)
                            {
                                switch (policy.BillingMode)
                                {
                                    case "Monthly":
                                        eEPaidIDIGSIBasePlusAMBInForceModalAmount = modalPremiums - request.EmployerPaysUpto;
                                        break;
                                    case "Quarterly":
                                        eEPaidIDIGSIBasePlusAMBInForceModalAmount = modalPremiums - (request.EmployerPaysUpto * 3);
                                        break;
                                    case "Semi Annual":
                                    case "Half Yearly":
                                        eEPaidIDIGSIBasePlusAMBInForceModalAmount = modalPremiums - (request.EmployerPaysUpto * 6);
                                        break;
                                    case "Annual":
                                    case "Yearly":
                                        eEPaidIDIGSIBasePlusAMBInForceModalAmount = modalPremiums - (request.EmployerPaysUpto * 12);
                                        break;
                                }

                            }
                        }
                    }
                }
                else
                {
                    var employerPaidPolicyInfo = request.PolicyDetails.Where(c => c.CaseNumber == request.CaseNumber
                        && c.CLOASPolicyStatus == "Inforce"
                        && c.PremiumPayer == PremiumPayerTypeEnum.Employee.GetDescription()).ToList();

                    if (employerPaidPolicyInfo.Any())
                    {
                        eEPaidIDIGSIBasePlusAMBInForceModalAmount = employerPaidPolicyInfo.Sum(c => c.ModalPremium);
                    }
                }
            }

            if (eEPaidIDIGSIBasePlusAMBInForceModalAmount.HasValue)
            {
                eEPaidIDIGSIBasePlusAMBInForceModalAmount = eEPaidIDIGSIBasePlusAMBInForceModalAmount < 0 ? 0.0m : eEPaidIDIGSIBasePlusAMBInForceModalAmount.Value.Roundoff(2);
            }
            return eEPaidIDIGSIBasePlusAMBInForceModalAmount;
        }
    }
}
