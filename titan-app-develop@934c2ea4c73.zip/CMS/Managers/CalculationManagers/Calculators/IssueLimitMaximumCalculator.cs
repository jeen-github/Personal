﻿using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using System.Collections.Generic;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IssueLimitMaximumCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;
            List<int> sicCode = new List<int>() { 8000, 8011, 8050, 8051, 8060, 8062, 8071, 8082, 8090, 8093 };
            if (request == null)
            {
                return 0.0m;
            }

            request.ClassCalculationRequest.CompanySICCode = request.ClassCalculationRequest.CompanySICCode.HasValue ? request.ClassCalculationRequest.CompanySICCode : 0;
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;
            
            if (request.ClassCalculationRequest.EligibilityConfigIssueLimitMaximum.HasValue && request.ClassCalculationRequest.ContractState != StateTypeEnum.CA)
            {
                result = request.ClassCalculationRequest.EligibilityConfigIssueLimitMaximum;
            }
            else if (request.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum.HasValue && request.ClassCalculationRequest.ContractState == StateTypeEnum.CA)
            {
                result = request.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum;
            }
            else
            {
                if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.SupplementalPlan || request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.BonusOnlyPlan)
                {
                    if (request.ClassCalculationRequest.ContractState == StateTypeEnum.CA)
                    {
                        result = request.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum;
                    }
                    else if (sicCode.Contains(request.ClassCalculationRequest.CompanySICCode.Value))
                    {
                        result = 17000.00m;
                    }
                    else
                    {
                        result = request.ClassCalculationRequest.EligibilityConfigIssueLimitMaximum;
                    }
                }
                else if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneIDIPlan)
                {
                    result = 16000.00m;
                }
                else
                {
                    if (request.ClassCalculationRequest.ContractState == StateTypeEnum.CA)
                    {
                        result = request.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum;
                    }
                    else if (request.ClassCalculationRequest.CompanySICCode >= 8000 && request.ClassCalculationRequest.CompanySICCode <= 8099)
                    {
                        result = 17000.00m;
                    }
                    else
                    {
                        result = request.ClassCalculationRequest.EligibilityConfigIssueLimitMaximum;
                    }
                }
            }
            result = result - request.ExistingIDIAmount;
            if( result < 0)
            {
                result = 0.0m;
            }
            return result;
        }
    }
}
