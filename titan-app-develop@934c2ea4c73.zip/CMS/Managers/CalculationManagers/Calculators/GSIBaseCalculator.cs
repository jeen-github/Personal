﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class GSIBaseCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            decimal? newGSIWithAmbAmount = 0.0m;
            decimal? newEligibleGSIWithAmbAmount = 0.0m;
            decimal? eligibleCoverageAmount = 0.0m;
            decimal? ambCalculatedtedAmount = 0.0m;

            if (request == null)
            {
                return 0.0m;
            }

            request.ClassCalculationRequest.PrimaryGSIAmount = request.ClassCalculationRequest.PrimaryGSIAmount.HasValue ? request.ClassCalculationRequest.PrimaryGSIAmount : 0.0m;
            request.GSIIDIBaseAMBAmount = request.GSIIDIBaseAMBAmount.HasValue ? request.GSIIDIBaseAMBAmount : 0.0m;
            request.FullyUnderWrittenIDIAmount = request.FullyUnderWrittenIDIAmount.HasValue ? request.FullyUnderWrittenIDIAmount : 0.0m;
            request.CoveragePossibleBeforeIandPMaximumAmount = request.CoveragePossibleBeforeIandPMaximumAmount.HasValue ? request.CoveragePossibleBeforeIandPMaximumAmount : 0.0m;
            request.ParticipationLimitMaximumAmount = request.ParticipationLimitMaximumAmount.HasValue ? request.ParticipationLimitMaximumAmount : 0.0m;
            request.IssueLimitMaximumAmount = request.IssueLimitMaximumAmount.HasValue ? request.IssueLimitMaximumAmount : 0.0m;
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;
            request.LTDCalculatedAmount = request.LTDCalculatedAmount.HasValue ? request.LTDCalculatedAmount : 0.0m;
            request.ClassCalculationRequest.MaximumReplacementRatio = request.ClassCalculationRequest.MaximumReplacementRatio.HasValue ? request.ClassCalculationRequest.MaximumReplacementRatio : 0.0m;
            request.IDIInsurableIncomeAmount = request.IDIInsurableIncomeAmount.HasValue ? request.IDIInsurableIncomeAmount : 0.0m;
            request.ManualBenefitAmount = request.ManualBenefitAmount.HasValue ? request.ManualBenefitAmount : 0.0m;
            request.ClassCalculationRequest.BasePlanGSIPercentage = request.ClassCalculationRequest.BasePlanGSIPercentage.HasValue ? request.ClassCalculationRequest.BasePlanGSIPercentage : 1.0m;
            request.ManualBenefitAMBIncreaseAmount = (request.ManualBenefitAMBIncreaseAmount.HasValue && request.ManualBenefitAMBIncreaseAmount > 0) ? request.ManualBenefitAMBIncreaseAmount : 0.0m;
            if (request.FullyUnderWrittenIDIAmount > 0)
            {
                eligibleCoverageAmount = ((request.IDIInsurableIncomeAmount * (request.ClassCalculationRequest.MaximumReplacementRatio / 100)) / 12).Value.Roundoff(2) 
                                        - request.LTDCalculatedAmount - request.FullyUnderWrittenIDIAmount;
                newGSIWithAmbAmount = (eligibleCoverageAmount.Value.GetMinVal(request.ClassCalculationRequest.PrimaryGSIAmount.Value)) - request.GSIIDIBaseAMBAmount;
            }
            else
            {
                newGSIWithAmbAmount = request.GSIIDIBaseAMBAmount != null ? request.ClassCalculationRequest.ApprovedTotalGSIAmount - request.GSIIDIBaseAMBAmount : request.ClassCalculationRequest.ApprovedTotalGSIAmount;
            }


            if (request.IsAMBIncreasePolicy)
            {
                ambCalculatedtedAmount = ((request.IDIInsurableIncomeAmount * (request.ClassCalculationRequest.MaximumReplacementRatio / 100))/12).Value.Roundoff(2)
                                           - request.LTDCalculatedAmount - request.ExistingIDIAmount;

                newEligibleGSIWithAmbAmount = (ambCalculatedtedAmount).Value.GetMinVal(request.ClassCalculationRequest.PrimaryGSIAmount.Value - (request.BaseGSIMaxAmount.HasValue ? request.BaseGSIMaxAmount.Value : 0));


            }

            if (request.ManualBenefitAmount > 0)
            {
                result = request.ManualBenefitAmount * request.ClassCalculationRequest.BasePlanGSIPercentage;
            }
            else if(request.ManualBenefitAMBIncreaseAmount > 0)
            {
                result = request.ManualBenefitAMBIncreaseAmount * request.ClassCalculationRequest.BasePlanGSIPercentage;
            }
            else
            {
                switch (request.ClassCalculationRequest.PlanDesignType)
                {
                    case PlanDesignTypeEnum.SupplementalPlan:
                        result = request.CoveragePossibleBeforeIandPMaximumAmount.Value.GetMinVal(request.IssueLimitMaximumAmount.Value, request.ParticipationLimitMaximumAmount, request.ClassCalculationRequest.PrimaryGSIAmount);
                        if (result > 0)
                        {
                            if (request.IsAMBIncreasePolicy)
                            {
                                result = result.Value.GetMinVal((decimal)newGSIWithAmbAmount, newEligibleGSIWithAmbAmount);
                            }
                            else
                            { result = result.Value.GetMinVal((decimal)newGSIWithAmbAmount); }
                        }
                        break;
                    case PlanDesignTypeEnum.StandAloneIDIPlan:
                        result = request.CoveragePossibleBeforeIandPMaximumAmount.Value.GetMinVal(request.IssueLimitMaximumAmount.Value, request.ClassCalculationRequest.PrimaryGSIAmount);
                        if (result > 0)
                        {
                            if (request.IsAMBIncreasePolicy)
                            {
                                result = result.Value.GetMinVal((decimal)newGSIWithAmbAmount, newEligibleGSIWithAmbAmount);
                            }
                            else
                            { result = result.Value.GetMinVal((decimal)newGSIWithAmbAmount); }
                        }
                        break;
                    case PlanDesignTypeEnum.BonusOnlyPlan:
                        result = request.CoveragePossibleBeforeIandPMaximumAmount.Value.GetMinVal(request.IssueLimitMaximumAmount.Value, request.ParticipationLimitMaximumAmount, request.ClassCalculationRequest.PrimaryGSIAmount);
                        if (result > 0)
                        {
                            if (request.IsAMBIncreasePolicy)
                            {
                                result = result.Value.GetMinVal((decimal)newGSIWithAmbAmount, newEligibleGSIWithAmbAmount);
                            }
                            else
                            { result = result.Value.GetMinVal((decimal)newGSIWithAmbAmount); }
                        }
                        break;
                    case PlanDesignTypeEnum.FlatBenefitPlan:
                        decimal flatBenefitAmount = 0m;
                        if (request.ClassCalculationRequest.FlatRateOther != null)
                        {
                            flatBenefitAmount = (decimal)request.ClassCalculationRequest.FlatRateOther;
                        }
                        else
                        {
                            flatBenefitAmount = (decimal)request.ClassCalculationRequest.FlatRateTypeId;
                        }
                        if (request.ClassCalculationRequest.ContractState == StateTypeEnum.CA)
                        {
                            request.IssueLimitMaximumAmount = request.CAIssueLimitMaximumAmount;
                            request.ParticipationLimitMaximumAmount = request.CAParticipationLimitMaximumAmount;

                        }
                        else if (request.ClassCalculationRequest.CompanySICCode >= 8000 && request.ClassCalculationRequest.CompanySICCode <= 8099)
                        {
                            request.IssueLimitMaximumAmount = 17000m;
                            request.ParticipationLimitMaximumAmount = 35000m;
                        }
                        else
                        {
                            request.IssueLimitMaximumAmount = request.IssueLimitMaximumAmount;
                            request.ParticipationLimitMaximumAmount = request.ParticipationLimitMaximumAmount;
                        }
                        request.IssueLimitMaximumAmount = request.IssueLimitMaximumAmount - request.ExistingIDIAmount;
                        request.ParticipationLimitMaximumAmount = request.ParticipationLimitMaximumAmount - request.LTDCalculatedAmount - request.ExistingIDIAmount;
                        result = flatBenefitAmount.GetMinVal(request.IssueLimitMaximumAmount.Value, request.ParticipationLimitMaximumAmount);
                        break;
                    default:
                        result = request.ClassCalculationRequest.PrimaryGSIAmount.Value;
                        break;
                }
                if (result != null)
                {
                    result = result * request.ClassCalculationRequest.BasePlanGSIPercentage;
                }
                result = result < 0 ? 0.0m : result.Value.NearestRoundoff(10);
                
                if (request.ClassCalculationRequest.MinimumBenefitAmount.HasValue && request.ClassCalculationRequest.MinimumBenefitAmount > 0.0m)
                {
                    if (result < request.ClassCalculationRequest.MinimumBenefitAmount)
                    {
                        result = 0.0m;
                    }
                }
            }
            return result;

        }
    }
}
