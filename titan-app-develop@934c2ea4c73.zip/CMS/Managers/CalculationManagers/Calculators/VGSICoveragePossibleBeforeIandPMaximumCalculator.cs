﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class VGSICoveragePossibleBeforeIandPMaximumCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            if (request == null)
            {
                return result;
            }
            request.ClassCalculationRequest.VGSIMaximumReplacementRatio = request.ClassCalculationRequest.VGSIMaximumReplacementRatio.HasValue ? request.ClassCalculationRequest.VGSIMaximumReplacementRatio : 0.0m;
            request.VGSIBuyUpIDIInsurableIncomeAmount = request.VGSIBuyUpIDIInsurableIncomeAmount.HasValue ? request.VGSIBuyUpIDIInsurableIncomeAmount : 0.0m;
            request.LTDCalculatedAmount = request.LTDCalculatedAmount.HasValue ? request.LTDCalculatedAmount : 0.0m;
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;
            request.GSICalculatedAmountResponse = request.GSICalculatedAmountResponse.HasValue ? request.GSICalculatedAmountResponse : 0.0m;

            result = ((((request.ClassCalculationRequest.VGSIMaximumReplacementRatio.Value / 100) * request.VGSIBuyUpIDIInsurableIncomeAmount.Value) / 12) - request.LTDCalculatedAmount.Value - request.ExistingIDIAmount.Value - request.GSICalculatedAmountResponse.Value).Roundoff(2);

            return result;
        }
    }
}
