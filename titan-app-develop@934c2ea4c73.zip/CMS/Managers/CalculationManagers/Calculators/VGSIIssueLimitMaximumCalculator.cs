﻿using Guardian.Core.Entities.Product.Enums;
using System.Collections.Generic;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class VGSIIssueLimitMaximumCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;
            List<int> sicCode = new List<int>() { 8000, 8011, 8050, 8051, 8060, 8062, 8071, 8082, 8090, 8093 };
            if (request == null)
            {
                return 0.0m;
            }

            request.ClassCalculationRequest.CompanySICCode = request.ClassCalculationRequest.CompanySICCode.HasValue ? request.ClassCalculationRequest.CompanySICCode : 0;
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;
            request.GSICalculatedAmountResponse = request.GSICalculatedAmountResponse.HasValue ? request.GSICalculatedAmountResponse : 0.0m;
            if (request.ClassCalculationRequest.EligibilityConfigIssueLimitMaximum.HasValue && request.ClassCalculationRequest.ContractState != StateTypeEnum.CA)
            {
                result = request.ClassCalculationRequest.EligibilityConfigIssueLimitMaximum;
            }
            else if (request.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum.HasValue && request.ClassCalculationRequest.ContractState == StateTypeEnum.CA)
            {
                result = request.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum;
            }
            else
            {
                if (request.ClassCalculationRequest.ContractState == StateTypeEnum.CA)
                {
                    result = request.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum;
                }
                else if (sicCode.Contains(request.ClassCalculationRequest.CompanySICCode.Value))
                {
                    result = 17000.00m;
                }
                else
                {
                    result = 20000.00m;
                }
            }

            result = result - request.GSICalculatedAmountResponse - request.ExistingIDIAmount;
            return result;
        }
    }
}
