﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IssueAgeCalculator
    {
        public int? Calculate(BenefitAmountsCalculationRequest request)
        {
            int? result = null;

            if (request == null)
            {
                return result;
            }

            if(request.ParticipantDateOfBirth == null || request.ClassCalculationRequest.IllustrationEffectiveDate == null)
            {
                return result;
            }
            result = request.ParticipantDateOfBirth.GetAge(request.ClassCalculationRequest.IllustrationEffectiveDate);
            return result;
        }
    }
}
