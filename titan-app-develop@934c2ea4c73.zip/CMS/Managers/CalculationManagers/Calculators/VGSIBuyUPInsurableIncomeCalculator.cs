﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class VGSIBuyUPInsurableIncomeCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            if (request == null)
            {
                return 0.0m;
            }
            if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == null)
            {
                return 0.0m;
            }
            decimal? result = null;
            request.MostRecentSalaryAmount = request.MostRecentSalaryAmount.HasValue ? request.MostRecentSalaryAmount : 0.0m;
            request.MostRecentPaidBonusAmount = request.MostRecentPaidBonusAmount.HasValue ? request.MostRecentPaidBonusAmount : 0.0m;
            request.PriorPaidBonusAmount = request.PriorPaidBonusAmount.HasValue ? request.PriorPaidBonusAmount : 0.0m;
            request.MostRecentPaidCommissionAmount = request.MostRecentPaidCommissionAmount.HasValue ? request.MostRecentPaidCommissionAmount : 0.0m;
            request.PriorPaidCommissionAmount = request.PriorPaidCommissionAmount.HasValue ? request.PriorPaidCommissionAmount : 0.0m;
            request.MostRecentPaidK1IncomeAmount = request.MostRecentPaidK1IncomeAmount.HasValue ? request.MostRecentPaidK1IncomeAmount : 0.0m;
            request.PriorPaidK1IncomeAmount = request.PriorPaidK1IncomeAmount.HasValue ? request.PriorPaidK1IncomeAmount : 0.0m;
            request.OtherIncomeAmount = request.OtherIncomeAmount.HasValue ? request.OtherIncomeAmount : 0.0m;
            request.MostRecentW2IncomeAmount = request.MostRecentW2IncomeAmount.HasValue ? request.MostRecentW2IncomeAmount : 0.0m;

            if (request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBaseSalaryPercentage.HasValue
                || request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusPercentage.HasValue
                || request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionPercentage.HasValue
                || request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsPercentage.HasValue
                || request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeOtherIncomePercentage.HasValue)

            {
                result = VGSIBuyUPInsurableIncomeClassLevelBaseSalaryCalculate(request) + VGSIBuyUPInsurableIncomeClassLevelBonusCalculate(request)
                        + VGSIBuyUPInsurableIncomeClassLevelCommisionCalculate(request) + VGSIBuyUPInsurableIncomeClassLevelK1EarningsCalculate(request)
                        + VGSIBuyUPInsurableIncomeClassLevelOtherIncomeCalculate(request);
            }
            else if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.BonusOnlyPlan)
            {
                switch (request.ClassCalculationRequest.VGSIBuyUpCoveredEarningsBonusOnly)
                {
                    case CoveredEarningsBonusOnlyTypeEnum.Bonus:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount);
                        break;
                    case CoveredEarningsBonusOnlyTypeEnum.Commissions:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                        break;
                    case CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                        break;
                    case CoveredEarningsBonusOnlyTypeEnum.K_1Earnings:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount);
                        break;
                    case CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount)
                                + request.OtherIncomeAmount * 0.75m;
                        break;
                }
            }
            else
            {
                switch (request.ClassCalculationRequest.VGSIBuyUpCoveredEarnings)
                {
                    case CoveredEarningsTypeEnum.BaseSalaryOnly:
                        result = request.MostRecentSalaryAmount;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                        result = request.MostRecentSalaryAmount
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount);
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                        result = request.MostRecentSalaryAmount
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Commission:
                        result = request.MostRecentSalaryAmount
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount);
                        break;
                    case CoveredEarningsTypeEnum.W_2Income:
                        result = request.MostRecentW2IncomeAmount;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings:
                        result = AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount);
                        break;
                    case CoveredEarningsTypeEnum.TotalCompensation:
                        result = request.MostRecentSalaryAmount
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidBonusAmount, request.PriorPaidBonusAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidCommissionAmount, request.PriorPaidCommissionAmount)
                                + AdjustCurrentAmount.GetAdjustedAmount(request.MostRecentPaidK1IncomeAmount, request.PriorPaidK1IncomeAmount)
                                + request.OtherIncomeAmount * 0.75m;
                        break;
                }
            }
            return result != null ? result.Value.Roundoff(2) : result;
        }

        private decimal? VGSIBuyUPInsurableIncomeClassLevelBaseSalaryCalculate(BenefitAmountsCalculationRequest request)
        {
            request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBaseSalaryPercentage = request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBaseSalaryPercentage.HasValue ? request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBaseSalaryPercentage : 0.0m;
            return request.MostRecentSalaryAmount * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBaseSalaryPercentage;
        }

        private decimal? VGSIBuyUPInsurableIncomeClassLevelBonusCalculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            switch (request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusNoOfYear.ToString())
            {
                case "1":
                    result = (request.MostRecentPaidBonusAmount * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusPercentage);
                    break;
                case "2":
                    result = (((request.MostRecentPaidBonusAmount + request.PriorPaidBonusAmount) / request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusNoOfYear) * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusPercentage);
                    break;
                case "3":
                    result = (((request.MostRecentPaidBonusAmount + request.PriorPaidBonusAmount + request.AdditionalPriorPaidBonusAmount) / request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusNoOfYear) * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusPercentage);
                    break;
            }

            return result;
        }

        private decimal? VGSIBuyUPInsurableIncomeClassLevelCommisionCalculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            switch (request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionsNoOfYear.ToString())
            {
                case "1":
                    result = (request.MostRecentPaidCommissionAmount * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionPercentage);
                    break;
                case "2":
                    result = (((request.MostRecentPaidCommissionAmount + request.PriorPaidCommissionAmount) / request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionsNoOfYear) * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionPercentage);
                    break;
                case "3":
                    result = (((request.MostRecentPaidCommissionAmount + request.PriorPaidCommissionAmount + request.AdditionalPriorPaidCommissionAmount) / request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionsNoOfYear) * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionPercentage);
                    break;
            }

            return result;
        }

        private decimal? VGSIBuyUPInsurableIncomeClassLevelK1EarningsCalculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            switch (request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsNoOfYear.ToString())
            {
                case "1":
                    result = (request.MostRecentPaidK1IncomeAmount * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsPercentage);
                    break;
                case "2":
                    result = (((request.MostRecentPaidK1IncomeAmount + request.PriorPaidK1IncomeAmount) / request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsNoOfYear) * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsPercentage);
                    break;
                case "3":
                    result = (((request.MostRecentPaidK1IncomeAmount + request.PriorPaidK1IncomeAmount + request.AdditionalPriorPaidK1IncomeAmount) / request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsNoOfYear) * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsPercentage);
                    break;
            }

            return result;
        }

        private decimal? VGSIBuyUPInsurableIncomeClassLevelOtherIncomeCalculate(BenefitAmountsCalculationRequest request)
        {
            request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeOtherIncomePercentage = request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeOtherIncomePercentage.HasValue ? request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeOtherIncomePercentage : 0.0m;
            return request.OtherIncomeAmount * request.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeOtherIncomePercentage;
        }
    }
}
