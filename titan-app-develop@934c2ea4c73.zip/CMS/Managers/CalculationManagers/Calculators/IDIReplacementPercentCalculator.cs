﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class IDIReplacementPercentCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;

            //if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan && request.ClassCalculationRequest.IsVoluntaryBuyUpPlan)
            if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan )
            {
                request.IDIInsurableIncomeAmount = request.VGSIBuyUpIDIInsurableIncomeAmount;
            }

            if (request == null || request.ClassCalculationRequest.PlanDesignType == null || (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan || request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan) || !request.IDIInsurableIncomeAmount.HasValue || request.IDIInsurableIncomeAmount.Value == 0.0m)
            {
                return null;
            }
            request.GLTDBenefitCalculatedAmount = request.GLTDBenefitCalculatedAmount.HasValue ? request.GLTDBenefitCalculatedAmount : 0.0m;
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;
            
            result = (((request.GLTDBenefitCalculatedAmount.Value + request.ExistingIDIAmount.Value) * 12) / request.IDIInsurableIncomeAmount.Value).Roundoff(4);

            return result;
        }
    }
}
