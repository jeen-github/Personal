﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;
using Logger.Static;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class CoveragePossibleBeforeIandPMaximumCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;
            if (request == null)
            {
                return 0.0m;
            }
            request.ClassCalculationRequest.MaximumReplacementRatio = request.ClassCalculationRequest.MaximumReplacementRatio.HasValue ? request.ClassCalculationRequest.MaximumReplacementRatio : 0.0m;
            request.IDIInsurableIncomeAmount = request.IDIInsurableIncomeAmount.HasValue ? request.IDIInsurableIncomeAmount : 0.0m;
            request.LTDCalculatedAmount = request.LTDCalculatedAmount.HasValue ? request.LTDCalculatedAmount : 0.0m;
            request.ExistingIDIAmount = request.ExistingIDIAmount.HasValue ? request.ExistingIDIAmount : 0.0m;

            if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneIDIPlan || request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.BonusOnlyPlan)
            {
                result = ((((request.ClassCalculationRequest.MaximumReplacementRatio.Value / 100) * request.IDIInsurableIncomeAmount.Value) / 12) - request.ExistingIDIAmount.Value).Roundoff(2);
            }
            else
            {
                result = ((((request.ClassCalculationRequest.MaximumReplacementRatio.Value / 100) * request.IDIInsurableIncomeAmount.Value) / 12) - request.LTDCalculatedAmount.Value - request.ExistingIDIAmount.Value).Roundoff(2);
            }

            return result;
        }
    }
}
