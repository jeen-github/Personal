﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using System.Linq;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class ERPaidRPPGSIBasePlusAMBInForceAnnualAmountCalculator
    {
        public decimal? AMBCalculate(AMBBenefitAmountCalculationRequest request)
        {
            decimal? eRPaidRPPGSIBasePlusAMBInForceAnnualAmount = 0.0m;

            if (request == null)
            {
                return 0.0m;
            }

            if (request.PremiumPayerType != null)
            {
                if (request.PremiumPayerType == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                {
                    var costSharePolicyInfo = request.PolicyDetails.Where(c => c.CaseNumber == request.CaseNumber
                            && c.CLOASPolicyStatus == "Inforce").ToList();

                    if (costSharePolicyInfo.Any())
                    {
                        var annualPremiums = costSharePolicyInfo.Sum(c => c.AnnualizedPremium);
                        annualPremiums = annualPremiums != null ? annualPremiums : 0;

                        if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PercentofPremium)
                        {
                            eRPaidRPPGSIBasePlusAMBInForceAnnualAmount = annualPremiums * request.EmployerPaidPremium;
                        }
                        else if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PremiumAmount)
                        {
                            eRPaidRPPGSIBasePlusAMBInForceAnnualAmount = ((request.EmployerPaysUpto * 12)).Value.GetMinVal(annualPremiums.Value);
                        }
                    }
                }
            }

            if (eRPaidRPPGSIBasePlusAMBInForceAnnualAmount.HasValue)
            {
                eRPaidRPPGSIBasePlusAMBInForceAnnualAmount = eRPaidRPPGSIBasePlusAMBInForceAnnualAmount < 0 ? 0.0m : eRPaidRPPGSIBasePlusAMBInForceAnnualAmount.Value.Roundoff(2);
            }

            return eRPaidRPPGSIBasePlusAMBInForceAnnualAmount;
        }
    }
}
