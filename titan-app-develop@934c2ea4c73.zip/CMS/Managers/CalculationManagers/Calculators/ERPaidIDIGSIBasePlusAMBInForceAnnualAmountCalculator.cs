﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using System.Linq;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class ERPaidIDIGSIBasePlusAMBInForceAnnualAmountCalculator
    {
        public decimal? AMBCalculate(AMBBenefitAmountCalculationRequest request)
        {
            decimal? eRPaidIDIGSIBasePlusAMBInForceAnnualAmount = 0.0m;

            if (request == null)
            {
                return 0.0m;
            }

            if (request.PremiumPayerType != null)
            {
                if (request.PremiumPayerType == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                {
                    var costSharePolicyInfo = request.PolicyDetails.Where(c => c.CaseNumber == request.CaseNumber
                            && c.CLOASPolicyStatus == "Inforce").ToList();

                    if (costSharePolicyInfo.Any())
                    {
                        var annualPremiums = costSharePolicyInfo.Sum(c => c.AnnualizedPremium);
                        annualPremiums = annualPremiums != null ? annualPremiums : 0;

                        if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PercentofPremium)
                        {
                            eRPaidIDIGSIBasePlusAMBInForceAnnualAmount = annualPremiums * request.EmployerPaidPremium;
                        }
                        else if (request.CostShareTypeOfShare == TypeOfShareTypeEnum.PremiumAmount)
                        {
                            eRPaidIDIGSIBasePlusAMBInForceAnnualAmount = ((request.EmployerPaysUpto * 12)).Value.GetMinVal(annualPremiums.Value);
                        }
                    }
                }
                else
                {
                    var employerPaidPolicyInfo = request.PolicyDetails.Where(c => c.CaseNumber == request.CaseNumber
                           && c.CLOASPolicyStatus == "Inforce"
                           && c.PremiumPayer == PremiumPayerTypeEnum.Employer.GetDescription()).ToList();

                    if (employerPaidPolicyInfo.Any())
                    {
                        eRPaidIDIGSIBasePlusAMBInForceAnnualAmount = employerPaidPolicyInfo.Sum(c => c.AnnualizedPremium);
                    }
                }
            }

            if (eRPaidIDIGSIBasePlusAMBInForceAnnualAmount.HasValue)
            {
                eRPaidIDIGSIBasePlusAMBInForceAnnualAmount = eRPaidIDIGSIBasePlusAMBInForceAnnualAmount < 0 ? 0.0m : eRPaidIDIGSIBasePlusAMBInForceAnnualAmount.Value.Roundoff(2);
            }

            return eRPaidIDIGSIBasePlusAMBInForceAnnualAmount;
        }
    }
}
