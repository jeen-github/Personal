﻿using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Model.Enums;
using Common.Utilities;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class GLTDReplacementPercentageCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = 0.0m;

            //if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan && request.ClassCalculationRequest.IsVoluntaryBuyUpPlan)
            if (request.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan )
            {
                request.IDIInsurableIncomeAmount = request.VGSIBuyUpIDIInsurableIncomeAmount;
            }

            if (request == null || !request.IDIInsurableIncomeAmount.HasValue || request.IDIInsurableIncomeAmount.Value == 0.0m || !request.LTDCalculatedAmount.HasValue)
            {
                return null;
            }

            result = ((request.LTDCalculatedAmount.Value * 12) / request.IDIInsurableIncomeAmount.Value).Roundoff(4);
            return result;
        }
    }
}
