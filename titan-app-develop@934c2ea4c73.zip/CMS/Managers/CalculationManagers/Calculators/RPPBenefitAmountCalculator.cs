﻿using System;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using Logger.Static;
using Common.Utilities;
using CMS.Model.Enums;

namespace CMS.Managers.PreQuoteCalculationManagers.Calculators
{
    public class RPPBenefitAmountCalculator
    {
        public decimal? Calculate(BenefitAmountsCalculationRequest request)
        {
            decimal? result = null;
            decimal indemnityAmount = 0.0m;

            if (request == null)
            {
                return 0.0m;
            }
            request.ClassCalculationRequest.RPPBenefitAmount = request.ClassCalculationRequest.RPPBenefitAmount.HasValue ? request.ClassCalculationRequest.RPPBenefitAmount : 0.0m;
            if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                if (request.ClassCalculationRequest.RPPBenefitAmount == 0.0m)
                {
                    request.ClassCalculationRequest.RPPBenefitAmount = request.ClassCalculationRequest.PrimaryGSIAmount;
                }
            }
            request.ClassCalculationRequest.RetirementContributionAmount = request.ClassCalculationRequest.RetirementContributionAmount.HasValue ? request.ClassCalculationRequest.RetirementContributionAmount : 0.0m;
            request.ClassCalculationRequest.RPPMaximumIndemnityAmount = request.ClassCalculationRequest.RPPMaximumIndemnityAmount.HasValue ? request.ClassCalculationRequest.RPPMaximumIndemnityAmount : 0;
            request.ClassCalculationRequest.RPPMaximumIndemnityAmountUnderAge49 = request.ClassCalculationRequest.RPPMaximumIndemnityAmountUnderAge49.HasValue ? request.ClassCalculationRequest.RPPMaximumIndemnityAmountUnderAge49 : 0;
            request.TotalEmployerOrEmployeeRetirementContributionAmount = request.TotalEmployerOrEmployeeRetirementContributionAmount.HasValue ? request.TotalEmployerOrEmployeeRetirementContributionAmount : 0.0m;
            request.IDIInsurableIncomeAmount = request.IDIInsurableIncomeAmount.HasValue ? request.IDIInsurableIncomeAmount : 0.0m;
            request.MostRecentSalaryAmount = request.MostRecentSalaryAmount.HasValue ? request.MostRecentSalaryAmount : 0.0m;
            request.MostRecentPaidBonusAmount = request.MostRecentPaidBonusAmount.HasValue ? request.MostRecentPaidBonusAmount : 0.0m;
            request.MostRecentPaidCommissionAmount = request.MostRecentPaidCommissionAmount.HasValue ? request.MostRecentPaidCommissionAmount : 0.0m;
            request.MostRecentW2IncomeAmount = request.MostRecentW2IncomeAmount.HasValue ? request.MostRecentW2IncomeAmount : 0.0m;
            request.MostRecentPaidK1IncomeAmount = request.MostRecentPaidK1IncomeAmount.HasValue ? request.MostRecentPaidK1IncomeAmount : 0.0m;
            request.OtherIncomeAmount = request.OtherIncomeAmount.HasValue ? request.OtherIncomeAmount : 0.0m;
            request.ClassCalculationRequest.RequestedPercentage = request.ClassCalculationRequest.RequestedPercentage.HasValue ? request.ClassCalculationRequest.RequestedPercentage : 0.0m;
            request.GSIRPPBaseAMBAmount = request.GSIRPPBaseAMBAmount ?? 0.0m;
            request.FullyUnderWrittenRPPAmount = request.FullyUnderWrittenRPPAmount ?? 0.0m;
           
            indemnityAmount = request.Age > 49 ? Convert.ToDecimal(request.ClassCalculationRequest.RPPMaximumIndemnityAmount) : Convert.ToDecimal(request.ClassCalculationRequest.RPPMaximumIndemnityAmountUnderAge49);
            request.TotalEmployerOrEmployeeRetirementContributionsCalculatedAmount = request.TotalEmployerOrEmployeeRetirementContributionsCalculatedAmount ?? 0.0m;
            request.ManualRPPAmount = request.ManualRPPAmount.HasValue ? request.ManualRPPAmount : 0.0m;
            request.ManualRPPAMBIncreaseAmount = (request.ManualRPPAMBIncreaseAmount.HasValue && request.ManualRPPAMBIncreaseAmount > 0) ? request.ManualRPPAMBIncreaseAmount : 0.0m;
            if (request.ManualRPPAmount > 0)
            {
                result = request.ManualRPPAmount * request.ClassCalculationRequest.BasePlanGSIPercentage;
            }
            else if (request.ManualRPPAMBIncreaseAmount > 0)
            {
                result = request.ManualRPPAMBIncreaseAmount * request.ClassCalculationRequest.BasePlanGSIPercentage;
            }
            else
            {

                switch (request.ClassCalculationRequest.RetirementContributionsType)
                {
                    case RetirementContributionsTypeEnum.FlatContribution:
                        //result = (request.ClassCalculationRequest.RPPBenefitAmount).Value.GetMinVal(indemnityAmount, (request.ClassCalculationRequest.RetirementContributionAmount / 12).Value.Roundoff(2));
                        result = (request.ClassCalculationRequest.RPPBenefitAmount).Value.GetMinVal(indemnityAmount, (request.TotalEmployerOrEmployeeRetirementContributionsCalculatedAmount / 12).Value.Roundoff(2));
                        break;
                    case RetirementContributionsTypeEnum.ActualContributiononCensus:
                        //result = (request.ClassCalculationRequest.RPPBenefitAmount).Value.GetMinVal(indemnityAmount, (request.TotalEmployerOrEmployeeRetirementContributionAmount / 12).Value.Roundoff(2));
                        result = (request.ClassCalculationRequest.RPPBenefitAmount).Value.GetMinVal(indemnityAmount, (request.TotalEmployerOrEmployeeRetirementContributionsCalculatedAmount / 12).Value.Roundoff(2));
                        break;
                    case RetirementContributionsTypeEnum.PercentofCoveredEarnings:
                        if (request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                        {
                            switch (request.ClassCalculationRequest.PDRClassCoveredEarnings)
                            {
                                case CoveredEarningsTypeEnum.BaseSalaryOnly:
                                    result = request.MostRecentSalaryAmount;
                                    break;
                                case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                                    result = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount;
                                    break;
                                case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                                    result = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount + request.MostRecentPaidCommissionAmount;
                                    break;
                                case CoveredEarningsTypeEnum.BaseSalary_Commission:
                                    result = request.MostRecentSalaryAmount + request.MostRecentPaidCommissionAmount;
                                    break;
                                case CoveredEarningsTypeEnum.K_1Earnings:
                                    result = request.MostRecentPaidK1IncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.TotalCompensation:
                                    result = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount + request.MostRecentPaidCommissionAmount + request.MostRecentW2IncomeAmount + request.MostRecentPaidK1IncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.Other:
                                    result = request.OtherIncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.W_2Income:
                                    result = request.MostRecentW2IncomeAmount;
                                    break;
                            }
                        }
                        else
                        {
                            switch (request.ClassCalculationRequest.RPPRiderCoveredEarnings)
                            {
                                case CoveredEarningsTypeEnum.BaseSalaryOnly:
                                    result = request.MostRecentSalaryAmount;
                                    break;
                                case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                                    result = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount;
                                    break;
                                case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                                    result = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount + request.MostRecentPaidCommissionAmount;
                                    break;
                                case CoveredEarningsTypeEnum.BaseSalary_Commission:
                                    result = request.MostRecentSalaryAmount + request.MostRecentPaidCommissionAmount;
                                    break;
                                case CoveredEarningsTypeEnum.K_1Earnings:
                                    result = request.MostRecentPaidK1IncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.TotalCompensation:
                                    result = request.MostRecentSalaryAmount + request.MostRecentPaidBonusAmount + request.MostRecentPaidCommissionAmount + request.MostRecentW2IncomeAmount + request.MostRecentPaidK1IncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.Other:
                                    result = request.OtherIncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.W_2Income:
                                    result = request.MostRecentW2IncomeAmount;
                                    break;
                                case CoveredEarningsTypeEnum.IDIInsurableIncome:
                                    result = request.IDIInsurableIncomeAmount;
                                    break;
                            }
                        }
                        result = (result * (request.ClassCalculationRequest.RequestedPercentage / 100)) / 12;
                        if (result != null)
                        {
                            result = indemnityAmount.GetMinVal(result.Value, request.ClassCalculationRequest.RPPBenefitAmount, (request.TotalEmployerOrEmployeeRetirementContributionsCalculatedAmount / 12).Value.Roundoff(2));
                        }
                        break;
                }
                result = result - (request.GSIRPPBaseAMBAmount + request.FullyUnderWrittenRPPAmount);
                if (result.HasValue)
                {
                    result = result < 0 ? 0.0m : result.Value.NearestRoundoff(10);
                }
            }
            return result;
        }
    }
}
