﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Managers.PreQuoteCalculationManagers.Calculators;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Guardian.Core.Entities.Product.Enums.EnumExtensions;

namespace CMS.Managers.BenefitAmountsCalculationManagers
{
    public class BenefitAmountsCalculationManager : IBenefitAmountsCalculationManager
    {
        private readonly IDIInsurableIncomeCalculator _idiInsurableIncomeCalculator;
        private readonly LTDInsurableIncomeCalculator _ltdInsurableIncomeCalculator;
        private readonly VGSIBuyUPInsurableIncomeCalculator _vgsiBuyUPInsurableIncomeCalculator;
        private readonly LTDAmountCalculator _ltdAmountCalculator;
        private readonly IDIReplacementPercentCalculator _idiReplacementPercentCalculator;
        private readonly OtherExistingIDICoverageTotalAmountCalculator _otherExistingIDICoverageTotalAmountCalculator;
        private readonly GuardianExistingIDICoverageTotalAmountCalculator _guardianExistingIDICoverageTotalAmountCalculator;
        private readonly TotalEmployerOrEmployeeRetirementContributionsAmountCalculator _totalEmployerOrEmployeeRetirementContributionsAmountCalculator;
        private readonly VoluntaryGSIBuyUpAmountCalculator _volunataryGSIBuyUpAmountCalculator;
        private readonly IDIBaseSalaryCalculator _iDIBaseSalaryCalculator;
        private readonly IDICommissionsIncomeCalculator _iDICommissionsIncomeCalculator;
        private readonly IDIBonusIncomeCalculator _iDIBonusIncomeCalculator;
        private readonly IDIK1IncomeCalculator _iDIK1IncomeCalculator;
        private readonly IDIOtherIncomeCalculator _iDIOtherIncomeCalculator;
        private readonly ExistingIDICalculator _existingIDICalculator;
        private readonly IDIBaseReplacementPercentCalculator _iDIBaseReplacementPercentCalculator;
        private readonly GSIBaseCalculator _gSIBaseCalculator;
        private readonly GLTDReplacementPercentageCalculator _gLTDReplacementPercentageCalculator;
        private readonly TotalGLTDPlusIDICalculator _totalGLTDCalculator;
        private readonly TotalGLTDPlusIDIPercentCalculator _totalGLTDPercentCalculator;
        private readonly CATAmountCalculator _cATAmountCalculator;
        private readonly RPPBenefitAmountCalculator _rPPBenefitAmountCalculator;
        private readonly ContractStateCalculator _contractStateCalculator;
        private readonly CoveragePossibleBeforeIandPMaximumCalculator _coveragePossibleBeforeIandPMaximumCalculator;
        private readonly VGSICoveragePossibleBeforeIandPMaximumCalculator _vgsiCoveragePossibleBeforeIandPMaximumCalculator;
        private readonly VGSIIssueLimitMaximumCalculator _vgsiIssueLimitMaximumCalculator;
        private readonly VGSIParticipationLimitMaximumCalculator _vgsiparticipationLimitMaximumCalculator;
        private readonly VGSIBuyUpBenefitCalculator _vgsiBuyUpBenefitCalculator;
        private readonly ParticipationLimitMaximumCalculator _participationLimitMaximumCalculator;
        private readonly IssueLimitMaximumCalculator _issueLimitMaximumCalculator;
        private readonly EligibleCATAmountCalculator _eligibleCATAmountCalculator;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;
        private readonly IssueAgeCalculator _issueAgeCalculator;
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        // Temp caches to help reduce database calls for large cases
        private readonly Dictionary<int, BenefitAmountsCalculationRequest> _pdrClassBenefitAmountsCalculationRequestDictionary;
        private readonly ConcurrentDictionary<int, DateTime?> _pdrClassIllustrationEffectiveDateDictionary;

        public BenefitAmountsCalculationManager(IEligibilityConfigurationManager eligibilityConfigurationManager, IUnitOfWorkFactory unitOfWorkFactory)
        {
            _idiInsurableIncomeCalculator = new IDIInsurableIncomeCalculator();
            _ltdInsurableIncomeCalculator = new LTDInsurableIncomeCalculator();
            _vgsiBuyUPInsurableIncomeCalculator = new VGSIBuyUPInsurableIncomeCalculator();
            _ltdAmountCalculator = new LTDAmountCalculator();
            _idiReplacementPercentCalculator = new IDIReplacementPercentCalculator();
            _otherExistingIDICoverageTotalAmountCalculator = new OtherExistingIDICoverageTotalAmountCalculator();
            _guardianExistingIDICoverageTotalAmountCalculator = new GuardianExistingIDICoverageTotalAmountCalculator();
            _totalEmployerOrEmployeeRetirementContributionsAmountCalculator = new TotalEmployerOrEmployeeRetirementContributionsAmountCalculator();
            _volunataryGSIBuyUpAmountCalculator = new VoluntaryGSIBuyUpAmountCalculator();
            _iDIBaseSalaryCalculator = new IDIBaseSalaryCalculator();
            _iDICommissionsIncomeCalculator = new IDICommissionsIncomeCalculator();
            _iDIBonusIncomeCalculator = new IDIBonusIncomeCalculator();
            _iDIK1IncomeCalculator = new IDIK1IncomeCalculator();
            _iDIOtherIncomeCalculator = new IDIOtherIncomeCalculator();
            _existingIDICalculator = new ExistingIDICalculator();
            _iDIBaseReplacementPercentCalculator = new IDIBaseReplacementPercentCalculator();
            _gSIBaseCalculator = new GSIBaseCalculator();
            _gLTDReplacementPercentageCalculator = new GLTDReplacementPercentageCalculator();
            _totalGLTDCalculator = new TotalGLTDPlusIDICalculator();
            _totalGLTDPercentCalculator = new TotalGLTDPlusIDIPercentCalculator();
            _cATAmountCalculator = new CATAmountCalculator();
            _rPPBenefitAmountCalculator = new RPPBenefitAmountCalculator();
            _contractStateCalculator = new ContractStateCalculator();
            _coveragePossibleBeforeIandPMaximumCalculator = new CoveragePossibleBeforeIandPMaximumCalculator();
            _vgsiCoveragePossibleBeforeIandPMaximumCalculator = new VGSICoveragePossibleBeforeIandPMaximumCalculator();
            _vgsiIssueLimitMaximumCalculator = new VGSIIssueLimitMaximumCalculator();
            _vgsiparticipationLimitMaximumCalculator = new VGSIParticipationLimitMaximumCalculator();
            _vgsiBuyUpBenefitCalculator = new VGSIBuyUpBenefitCalculator();
            _participationLimitMaximumCalculator = new ParticipationLimitMaximumCalculator();
            _issueLimitMaximumCalculator = new IssueLimitMaximumCalculator();
            _eligibleCATAmountCalculator = new EligibleCATAmountCalculator();
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
            _issueAgeCalculator = new IssueAgeCalculator();
            _unitOfWorkFactory = unitOfWorkFactory;

            _pdrClassBenefitAmountsCalculationRequestDictionary = new Dictionary<int, BenefitAmountsCalculationRequest>();
            _pdrClassIllustrationEffectiveDateDictionary = new ConcurrentDictionary<int, DateTime?>();
        }

        public BenefitAmountsCalculationResponse CalculateInsurableIncomes(BenefitAmountsCalculationRequest request)
        {
            var response = new BenefitAmountsCalculationResponse();

            response.IDIInsurableIncomeAmount = _idiInsurableIncomeCalculator.Calculate(request);
            response.LTDInsurableIncomeAmount = _ltdInsurableIncomeCalculator.Calculate(request);
            response.VGSIBuyUpIDIInsurableIncomeAmount = _vgsiBuyUPInsurableIncomeCalculator.Calculate(request);
            response.IssueAge = _issueAgeCalculator.Calculate(request);

            request.LTDInsurableIncomeAmount = response.LTDInsurableIncomeAmount;
            response.LTDCalculatedAmount = _ltdAmountCalculator.Calculate(request);

            request.LTDCalculatedAmount = response.LTDCalculatedAmount;
            request.IDIInsurableIncomeAmount = response.IDIInsurableIncomeAmount;

            response.OtherExistingIDICoverageTotalAmount = _otherExistingIDICoverageTotalAmountCalculator.Calculate(request);
            response.GuardianExistingIDICoverageTotalAmount = _guardianExistingIDICoverageTotalAmountCalculator.Calculate(request);
            response.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount = _totalEmployerOrEmployeeRetirementContributionsAmountCalculator.Calculate(request);

            request.OtherExistingIDICoverageTotalAmount = response.OtherExistingIDICoverageTotalAmount;
            request.GuardianExistingIDICoverageAmount = response.GuardianExistingIDICoverageTotalAmount;

            return response;
        }

        public BenefitAmountsCalculationResponse CalculateBenefitAmounts(BenefitAmountsCalculationRequest request, BenefitAmountsCalculationResponse response = null)
        {
            if (response == null) response = new BenefitAmountsCalculationResponse();

            response.IDIBaseSalaryCalculatedAmount = _iDIBaseSalaryCalculator.Calculate(request);
            response.IDIBonusIncomeCalculatedAmount = _iDIBonusIncomeCalculator.Calculate(request);
            response.IDICommissionsIncomeCalculatedAmount = _iDICommissionsIncomeCalculator.Calculate(request);
            response.IDIK1IncomeCalculatedAmount = _iDIK1IncomeCalculator.Calculate(request);
            response.IDIOtherIncomeCalculatedAmount = _iDIOtherIncomeCalculator.Calculate(request);

            response.GLTDBenefitCalculatedAmount = request.LTDCalculatedAmount;
            response.ExistingIDICalculatedAmount = _existingIDICalculator.Calculate(request);
            request.ExistingIDIAmount = response.ExistingIDICalculatedAmount;

            response.ContractState = _contractStateCalculator.Calculate(request);
            request.ClassCalculationRequest.ContractState = response.ContractState;

            response.CoveragePossibleBeforeIandPMaximumAmount = _coveragePossibleBeforeIandPMaximumCalculator.Calculate(request);
            request.CoveragePossibleBeforeIandPMaximumAmount = response.CoveragePossibleBeforeIandPMaximumAmount;

            response.ParticipationLimitMaximumAmount = _participationLimitMaximumCalculator.Calculate(request);
            request.ParticipationLimitMaximumAmount = response.ParticipationLimitMaximumAmount;
            request.CAParticipationLimitMaximumAmount = response.ParticipationLimitMaximumAmount;

            response.IssueLimitMaximumAmount = _issueLimitMaximumCalculator.Calculate(request);
            request.IssueLimitMaximumAmount = response.IssueLimitMaximumAmount;
            request.CAIssueLimitMaximumAmount = response.IssueLimitMaximumAmount;

            response.GSIBaseCalculatedAmount = _gSIBaseCalculator.Calculate(request);
            request.GSICalculatedAmountResponse = response.GSIBaseCalculatedAmount;

            request.GLTDBenefitCalculatedAmount = response.GLTDBenefitCalculatedAmount;

            if (request.IDIInsurableIncomeAmount > 0)
            {
                //response.GLTDReplacementCalculatedPercentage = _gLTDReplacementPercentageCalculator.Calculate(request);
                //response.IDIBaseReplacementCalculatedPercentage = _iDIBaseReplacementPercentCalculator.Calculate(request);
                response.IDIReplacementPercent = _idiReplacementPercentCalculator.Calculate(request);
                request.IDIReplacementPercent = response.IDIReplacementPercent;
            }

            response.VoluntaryGSIBuyUpAmount = _volunataryGSIBuyUpAmountCalculator.Calculate(request);

            response.VGSICoveragePossibleBeforeIandPMaximumAmount = request.ClassCalculationRequest.IsVGSIBuyUp ? _vgsiCoveragePossibleBeforeIandPMaximumCalculator.Calculate(request) : 0.0m;
            request.VGSICoveragePossibleBeforeIandPMaximumAmount = response.VGSICoveragePossibleBeforeIandPMaximumAmount;

            response.VGSIIssueLimitMaximumAmount = request.ClassCalculationRequest.IsVGSIBuyUp ? _vgsiIssueLimitMaximumCalculator.Calculate(request) : 0.0m;
            request.VGSIIssueLimitMaximumAmount = response.VGSIIssueLimitMaximumAmount;

            response.VGSIParticipationLimitMaximumAmount = request.ClassCalculationRequest.IsVGSIBuyUp ? _vgsiparticipationLimitMaximumCalculator.Calculate(request) : 0.0m;
            request.VGSIParticipationLimitMaximumAmount = response.VGSIParticipationLimitMaximumAmount;

            response.VGSIBuyUpBenefitAmount = request.ClassCalculationRequest.IsVGSIBuyUp ? _vgsiBuyUpBenefitCalculator.Calculate(request) : 0.0m;

            response.TotalVGSIBenefit = 0.0m;
            response.VGSIAMBCalculatedAmount = 0.0m;
            if (request.IsAMBIncreasePolicy) 
            {
                response.BaseAMBCalculatedAmount = response.GSIBaseCalculatedAmount;
                request.BaseAMBCalculatedAmountResponse = response.GSIBaseCalculatedAmount;
                response.GSIBaseCalculatedAmount = 0.0m;
                request.GSICalculatedAmountResponse = response.GSIBaseCalculatedAmount;

                response.GSIPlusAMBTotalBaseBenefitAmount = (request.GSIBasePlusInforceAMB != null ? request.GSIBasePlusInforceAMB : 0) + (response.BaseAMBCalculatedAmount != null ? response.BaseAMBCalculatedAmount : 0);

                response.TotalVGSIBenefit += response.GSIPlusAMBTotalBaseBenefitAmount;
            }
            if (request.IsBuyUpAMBIncreaseIndicator)
            {
                response.VGSIAMBCalculatedAmount = response.VGSIBuyUpBenefitAmount;
                request.VGSIAMBCalculatedAmountResponse = response.VGSIBuyUpBenefitAmount;
                response.VGSIBuyUpBenefitAmount = 0.0m;
                request.VGSIBuyUpBenefitAmount = response.VGSIBuyUpBenefitAmount;

                response.GSIPlusAMBTotalVGSIBuyUpBenefitAmount = (request.VGSIBuyUpPlusInforceAMB != null ? request.VGSIBuyUpPlusInforceAMB : 0) + (response.VGSIAMBCalculatedAmount != null ? response.VGSIAMBCalculatedAmount : 0);

                response.TotalVGSIBenefit += response.GSIPlusAMBTotalVGSIBuyUpBenefitAmount;
            }
            request.VGSIBuyUpBenefitAmount = response.VGSIBuyUpBenefitAmount;

            if (request.IDIInsurableIncomeAmount > 0)
            {
                response.GLTDReplacementCalculatedPercentage = _gLTDReplacementPercentageCalculator.Calculate(request);
                response.IDIBaseReplacementCalculatedPercentage = _iDIBaseReplacementPercentCalculator.Calculate(request);
            }

            response.TotalGLTDPlusIDICalculatedAmount = _totalGLTDCalculator.Calculate(request);
            request.TotalGLTDPlusIDIAmount = response.TotalGLTDPlusIDICalculatedAmount;

            if (request.IDIInsurableIncomeAmount > 0)
            {
                response.TotalGLTDPlusIDICalculatedPercentage = _totalGLTDPercentCalculator.Calculate(request);
            }

            response.CATCalculatedAmount = _cATAmountCalculator.Calculate(request);
            request.TotalEmployerOrEmployeeRetirementContributionsCalculatedAmount = response.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount;
            response.RPPBenefitCalculatedAmount = _rPPBenefitAmountCalculator.Calculate(request);
            request.RPPBenefitCalculatedAmountResponse = response.RPPBenefitCalculatedAmount;

            if (request.IsAMBIncreasePolicy && request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                response.RPPAMBCalculatedAmount = response.RPPBenefitCalculatedAmount;
                response.RPPBenefitCalculatedAmount = 0.0m;

                response.RPPPlusAMBTotalBaseBenefitAmount = (request.GSIBasePlusInforceAMBRpp != null ? request.GSIBasePlusInforceAMBRpp : 0) + (response.RPPAMBCalculatedAmount != null ? response.RPPAMBCalculatedAmount : 0);
            }
            
            response.EligibleCATCalculatedAmount = request.ClassCalculationRequest.PlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan ? _eligibleCATAmountCalculator.Calculate(request) : 0.0m;

            return response;
        }

        public void Calculate(BenefitAmountsCalculationRequest request, Participant participant)
        {
            var calcResponse = Calculate(request);
            CopyCalculationResponseToParticipantEntity(calcResponse, participant);
        }

        public BenefitAmountsCalculationResponse Calculate(BenefitAmountsCalculationRequest request)
        {
            var calcResponse = CalculateInsurableIncomes(request);
            request.Age = calcResponse.IssueAge;
            request.VGSIBuyUpIDIInsurableIncomeAmount = calcResponse.VGSIBuyUpIDIInsurableIncomeAmount;
            request.LTDCalculatedAmount = calcResponse.LTDCalculatedAmount;
            request.GuardianExistingIDICoverageAmount = calcResponse.GuardianExistingIDICoverageTotalAmount;
            request.OtherExistingIDICoverageAmount = calcResponse.OtherExistingIDICoverageTotalAmount;
            request.IDIInsurableIncomeAmount = request.ClassCalculationRequest.PlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan ? calcResponse.LTDInsurableIncomeAmount : calcResponse.IDIInsurableIncomeAmount;
            calcResponse = CalculateBenefitAmounts(request, calcResponse);

            return calcResponse;
        }

        private static void CopyCalculationResponseToParticipantEntity(BenefitAmountsCalculationResponse calcResponse, Participant participant)
        {
            participant.LTDInsurableIncomeCalculatedAmount = calcResponse.LTDInsurableIncomeAmount;
            participant.IDIInsurableIncomeCalculatedAmount = calcResponse.IDIInsurableIncomeAmount;
            participant.LTDCalculatedAmount = calcResponse.LTDCalculatedAmount;
            participant.VGSIBuyUpIDIInsurableIncomeCalculatedAmount = calcResponse.VGSIBuyUpIDIInsurableIncomeAmount;

            participant.OtherExistingIDICoverageTotalCalculatedAmount = calcResponse.OtherExistingIDICoverageTotalAmount;
            participant.GuardianExistingIDICoverageTotalCalculatedAmount = calcResponse.GuardianExistingIDICoverageTotalAmount;
            participant.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount = calcResponse.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount;
            participant.VoluntaryGSIBuyUpCalculatedAmount = calcResponse.VoluntaryGSIBuyUpAmount;

            participant.IssueAge = calcResponse.IssueAge;

            participant.EligibleCATCalculatedAmount = calcResponse.EligibleCATCalculatedAmount;
            participant.IDIBaseSalaryCalculatedAmount = calcResponse.IDIBaseSalaryCalculatedAmount;
            participant.IDIBonusIncomeCalculatedAmount = calcResponse.IDIBonusIncomeCalculatedAmount;
            participant.IDICommissionsIncomeCalculatedAmount = calcResponse.IDICommissionsIncomeCalculatedAmount;
            participant.IDIK1IncomeCalculatedAmount = calcResponse.IDIK1IncomeCalculatedAmount;
            participant.IDIOtherIncomeCalculatedAmount = calcResponse.IDIOtherIncomeCalculatedAmount;
            participant.GLTDBenefitCalculatedAmount = calcResponse.GLTDBenefitCalculatedAmount;
            participant.GLTDReplacementCalculatedPercentage = calcResponse.GLTDReplacementCalculatedPercentage;
            participant.ExistingIDICalculatedAmount = calcResponse.ExistingIDICalculatedAmount;
            participant.GSIBaseCalculatedAmount = calcResponse.GSIBaseCalculatedAmount;
            participant.IDIBaseReplacementCalculatedPercentage = calcResponse.IDIBaseReplacementCalculatedPercentage;
            participant.IDIReplacementCalculatedPercent = calcResponse.IDIReplacementPercent;
            participant.TotalGLTDPlusIDICalculatedAmount = calcResponse.TotalGLTDPlusIDICalculatedAmount;
            participant.TotalGLTDPlusIDICalculatedPercentage = calcResponse.TotalGLTDPlusIDICalculatedPercentage;
            participant.CATCalculatedAmount = calcResponse.CATCalculatedAmount;
            participant.RPPBenefitCalculatedAmount = calcResponse.RPPBenefitCalculatedAmount;
            participant.CoveragePossibleBeforeIandPMaximums = calcResponse.CoveragePossibleBeforeIandPMaximumAmount;
            participant.ParticipationLimitMaximum = calcResponse.ParticipationLimitMaximumAmount;
            participant.IssueLimitMaximum = calcResponse.IssueLimitMaximumAmount;
            participant.VGSIBuyUpCoveragePossibleBeforeIandPMaximums = calcResponse.VGSICoveragePossibleBeforeIandPMaximumAmount;
            participant.VGSIParticipationLimitMaximum = calcResponse.VGSIParticipationLimitMaximumAmount;
            participant.VGSIBuyUpBenefit = calcResponse.VGSIBuyUpBenefitAmount;
            participant.BaseAMBCalculatedAmount = calcResponse.BaseAMBCalculatedAmount;
            participant.VGSIBuyUpAMBCalculatedAmount = calcResponse.VGSIAMBCalculatedAmount;
            participant.RPPAMBCalculatedAmount = calcResponse.RPPAMBCalculatedAmount;
            participant.GSIPlusAMBTotalBaseBenefitAmount = calcResponse.GSIPlusAMBTotalBaseBenefitAmount;
            participant.GSIPlusAMBTotalVGSIBuyUpBenefitAmount = calcResponse.GSIPlusAMBTotalVGSIBuyUpBenefitAmount;
            participant.RPPPlusAMBTotalBaseBenefitAmount = calcResponse.RPPPlusAMBTotalBaseBenefitAmount;
            participant.TotalVGSIBenefit = calcResponse.TotalVGSIBenefit;
            if (calcResponse.ContractState.HasValue)
            {
                participant.ContractState = calcResponse.ContractState;
                participant.ContractStateDescription = calcResponse.ContractState.GetCode();
            }
            else
            {
                participant.ContractState = null;
                participant.ContractStateDescription = null;
            }
            
        }


        public BenefitAmountsCalculationRequest CreateIllustrationCalculationRequest(IllustrationCensusParticipantDto censusParticipant, BenefitAmountsCalculationRequest preQuoteCalculationRequest)
        {
            preQuoteCalculationRequest.Age = censusParticipant.IssueAge;
            preQuoteCalculationRequest.MostRecentW2IncomeAmount = censusParticipant.MostRecentW2IncomeAmount;
            preQuoteCalculationRequest.HomeState = censusParticipant.HomeState;
            preQuoteCalculationRequest.MostRecentSalaryAmount = censusParticipant.MostRecentSalaryAmount;
            preQuoteCalculationRequest.MostRecentPaidBonusAmount = censusParticipant.MostRecentPaidBonusAmount;
            preQuoteCalculationRequest.PriorPaidBonusAmount = censusParticipant.PriorPaidBonusAmount;
            preQuoteCalculationRequest.MostRecentPaidCommissionAmount = censusParticipant.MostRecentPaidCommissionAmount;
            preQuoteCalculationRequest.PriorPaidCommissionAmount = censusParticipant.PriorPaidCommissionAmount;
            preQuoteCalculationRequest.MostRecentPaidK1IncomeAmount = censusParticipant.MostRecentPaidK1IncomeAmount;
            preQuoteCalculationRequest.PriorPaidK1IncomeAmount = censusParticipant.PriorPaidK1IncomeAmount;
            preQuoteCalculationRequest.OtherIncomeAmount = censusParticipant.OtherIncomeAmount;
            //preQuoteCalculationRequest.IDIInsurableIncomeAmount = censusParticipant.IDIInsurableIncomeCalculatedAmount;
            preQuoteCalculationRequest.TotalEmployerOrEmployeeRetirementContributionAmount = censusParticipant.TotalEmployerOrEmployeeRetirementContributionsAmount;

            List<IDIReplacementPercentRequest> idiReplacementRequests = new List<IDIReplacementPercentRequest>();
            idiReplacementRequests.Add(AssignReplacementPercentRequest(censusParticipant.IDIBenefitAmount1, censusParticipant.IDIToBeReplaced1, censusParticipant.IDICarrier1, censusParticipant.IDIReplacementAmount1, censusParticipant.IDIToBeIgnore1));
            idiReplacementRequests.Add(AssignReplacementPercentRequest(censusParticipant.IDIBenefitAmount2, censusParticipant.IDIToBeReplaced2, censusParticipant.IDICarrier2, censusParticipant.IDIReplacementAmount2, censusParticipant.IDIToBeIgnore2));
            idiReplacementRequests.Add(AssignReplacementPercentRequest(censusParticipant.IDIBenefitAmount3, censusParticipant.IDIToBeReplaced3, censusParticipant.IDICarrier3, censusParticipant.IDIReplacementAmount3, censusParticipant.IDIToBeIgnore3));
            idiReplacementRequests.Add(AssignReplacementPercentRequest(censusParticipant.IDIBenefitAmount4, censusParticipant.IDIToBeReplaced4, censusParticipant.IDICarrier4, censusParticipant.IDIReplacementAmount4, censusParticipant.IDIToBeIgnore4));
            preQuoteCalculationRequest.IDIReplacementPercentRequests = idiReplacementRequests;

            //preQuoteCalculationRequest.LTDCalculatedAmount = censusParticipant.LTDCalculatedAmount;
            //preQuoteCalculationRequest.GuardianExistingIDICoverageAmount = censusParticipant.GuardianExistingIDICoverageTotalCalculatedAmount;
            //preQuoteCalculationRequest.OtherExistingIDICoverageAmount = censusParticipant.OtherExistingIDICoverageTotalCalculatedAmount;
            //preQuoteCalculationRequest.IDIInsurableIncomeAmount = censusParticipant.IDIInsurableIncomeCalculatedAmount;

            return preQuoteCalculationRequest;
        }

        public BenefitAmountsCalculationRequest CreateCalculationRequestForPDRClass(PlanDesignRequestClass planDesignRequestClass, EligibilityConfigurationDto eligibilityConfigurationClassDto = null)
        {
            var preQuoteCalculationRequest = new BenefitAmountsCalculationRequest();

            if (eligibilityConfigurationClassDto == null)
            {
                eligibilityConfigurationClassDto = new EligibilityConfigurationDto { PlanDesignRequestClassId = planDesignRequestClass.Id };
                eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
            }

            preQuoteCalculationRequest.ClassCalculationRequest.PlanDesignType = planDesignRequestClass.ApprovedPlanDesignType;
            if (planDesignRequestClass.ApprovedPlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.PDRClassCoveredEarnings = planDesignRequestClass.PlanDesignRequestClassLTDCoverage.Select(i => i.GroupLTDCoveredEarningsType).FirstOrDefault();
            }
            else
            {
                preQuoteCalculationRequest.ClassCalculationRequest.PDRClassCoveredEarnings = planDesignRequestClass.ApprovedCoveredEarningsType;
            }
            preQuoteCalculationRequest.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly = planDesignRequestClass.ApprovedCoveredEarningsBonusOnlyType;
            preQuoteCalculationRequest.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType = planDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType;
            preQuoteCalculationRequest.ClassCalculationRequest.RPPMaximumIndemnityAmount = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmount;
            preQuoteCalculationRequest.ClassCalculationRequest.RPPMaximumIndemnityAmountUnderAge49 = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmountUnderAge49;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigIssueLimitMaximum = eligibilityConfigurationClassDto.IssueLimitMaximum;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigParticipationLimit = eligibilityConfigurationClassDto.ParticipationLimit;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum = eligibilityConfigurationClassDto.CAIssueLimitMaximum;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigCAParticipationLimit = eligibilityConfigurationClassDto.CAParticipationLimit;

            if (planDesignRequestClass.ApprovedFlatRateType != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.FlatRateTypeId = planDesignRequestClass.ApprovedFlatRateType.Id;
                preQuoteCalculationRequest.ClassCalculationRequest.FlatRateOther = planDesignRequestClass.ApprovedFlatRate_Other;
            }

            preQuoteCalculationRequest.ClassCalculationRequest.RPPRiderCoveredEarnings = planDesignRequestClass.ApprovedRppRiderCoveredEarningsType != null ? planDesignRequestClass.ApprovedRppRiderCoveredEarningsType : null;

            if (planDesignRequestClass.PlanDesignRequestClassLTDCoverage != null)
            {
                var ltdCoverageInfo = planDesignRequestClass.PlanDesignRequestClassLTDCoverage.FirstOrDefault();
                if (ltdCoverageInfo != null)
                {
                    preQuoteCalculationRequest.ClassCalculationRequest.GroupLTDCapAmount = ltdCoverageInfo.GroupLTDCapAmount;
                    preQuoteCalculationRequest.ClassCalculationRequest.GroupLTDReplacementPercentage = ltdCoverageInfo.GroupLTDReplacementPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.GroupLTDCoveredEarnings = ltdCoverageInfo.GroupLTDCoveredEarningsType;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage = ltdCoverageInfo.BaseSalaryPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassBonusPercentage = ltdCoverageInfo.BonusPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassBonusNoOfYear = ltdCoverageInfo.BonusNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassCommissionPercentage = ltdCoverageInfo.CommissionPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassCommissionsNoOfYear = ltdCoverageInfo.CommissionNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsPercentage = ltdCoverageInfo.K1EarningsPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsNoOfYear = ltdCoverageInfo.K1EarningsNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage = ltdCoverageInfo.OtherIncomePercentage;
                }
            }

            preQuoteCalculationRequest.ClassCalculationRequest.VGSIBuyUpCoveredEarnings = planDesignRequestClass.ApprovedGSIBuyUpCoveredEarningsType;
            preQuoteCalculationRequest.ClassCalculationRequest.VGSIBuyUpCoveredEarningsBonusOnly = planDesignRequestClass.ApprovedGSIBuyUpCoveredEarningsBonusOnlyType;
            preQuoteCalculationRequest.ClassCalculationRequest.VGSIMaximumReplacementRatio = planDesignRequestClass.ApprovedGSIBuyUpReplacementPercentage;

            preQuoteCalculationRequest.ClassCalculationRequest.IDIPercentage = planDesignRequestClass.ApprovedIDIPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.LTDPercentage = planDesignRequestClass.ApprovedLTDPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.IDICoversFirst = planDesignRequestClass.ApprovedIDICovers1st;
            preQuoteCalculationRequest.ClassCalculationRequest.LTDCoversNext = planDesignRequestClass.ApprovedLTDCoversNext;
            preQuoteCalculationRequest.ClassCalculationRequest.MaximumReplacementRatio = planDesignRequestClass.ApprovedMaximumReplacementRatio;
            preQuoteCalculationRequest.ClassCalculationRequest.AnnualContribution = planDesignRequestClass.ApprovedAnnualContributions;
            preQuoteCalculationRequest.ClassCalculationRequest.RetirementContributionsType = planDesignRequestClass.ApprovedRetirementContributionsType;
            preQuoteCalculationRequest.ClassCalculationRequest.RequestedPercentage = planDesignRequestClass.ApprovedCoveredEarningsPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.RetirementContributionAmount = planDesignRequestClass.ApprovedAnnualContributions;

            var riders = planDesignRequestClass.PlanDesignRequestClassRiders.Where(c => c.IsGSIPlanIndicator == false);

            var CATBenifitPDRClassRider = riders.FirstOrDefault(p => (p.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider || p.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider));
            if (CATBenifitPDRClassRider != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.CATAmount = CATBenifitPDRClassRider.ApprovedAmount;
            }

            var RPPBenifitPDRClassRider = riders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
            if (RPPBenifitPDRClassRider != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.RPPBenefitAmount = RPPBenifitPDRClassRider.ApprovedAmount;
            }

            var primarPlanProduct = planDesignRequestClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == false);

            if (primarPlanProduct != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.PrimaryGSIAmount = primarPlanProduct.GSIAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.ApprovedTotalGSIAmount = primarPlanProduct.GSIAmount;
            }

            if (planDesignRequestClass.PlanDesignRequest.Case.CaseUnderwritingRequests.Any())
            {
                var caseUnderwritingRequest = planDesignRequestClass.PlanDesignRequest.Case.CaseUnderwritingRequests.First();
                preQuoteCalculationRequest.ClassCalculationRequest.SitusType = caseUnderwritingRequest.SitusType;
                preQuoteCalculationRequest.ClassCalculationRequest.CorporateSitusState = caseUnderwritingRequest.StateType;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState1Type = caseUnderwritingRequest.SitusMultiState1Type;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState2Type = caseUnderwritingRequest.SitusMultiState2Type;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState3Type = caseUnderwritingRequest.SitusMultiState3Type;
            }

            if (!string.IsNullOrEmpty(planDesignRequestClass.PlanDesignRequest.Case.CompanyRevisionSicCode))
            {
                int value = 0;
                int.TryParse(planDesignRequestClass.PlanDesignRequest.Case.CompanyRevisionSicCode.Substring(0, 4), out value);
                preQuoteCalculationRequest.ClassCalculationRequest.CompanySICCode = value;
            }

            var customizeIDIInsurableIncome = planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault(c => c.IsGSIPlanIndicator == false);
            GetCustomizedIDIInsurableIncome(preQuoteCalculationRequest, customizeIDIInsurableIncome);

            var customizeVGSIBuyUpIDIInsurableIncome = planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault(c => c.IsGSIPlanIndicator == true);
            GetCustomizedIDIInsurableIncome(preQuoteCalculationRequest, customizeVGSIBuyUpIDIInsurableIncome, true);

            preQuoteCalculationRequest.ClassCalculationRequest.IllustrationEffectiveDate = GetIllustrationEffectiveDate(planDesignRequestClass);
            return preQuoteCalculationRequest;
        }

        public BenefitAmountsCalculationRequest CreateCalculationRequestForParticipant(Participant participant, EligibilityConfigurationDto eligibilityConfigurationClassDto = null)
        {
            var preQuoteCalculationRequest = new BenefitAmountsCalculationRequest();

            if (eligibilityConfigurationClassDto == null)
            {
                eligibilityConfigurationClassDto = new EligibilityConfigurationDto { PlanDesignRequestClassId = participant.PlanDesignRequestClass.Id };
                eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
            }

            preQuoteCalculationRequest.ClassCalculationRequest.RPPMaximumIndemnityAmount = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmount;
            preQuoteCalculationRequest.ClassCalculationRequest.RPPMaximumIndemnityAmountUnderAge49 = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmountUnderAge49;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigIssueLimitMaximum = eligibilityConfigurationClassDto.IssueLimitMaximum;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigParticipationLimit = eligibilityConfigurationClassDto.ParticipationLimit;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum = eligibilityConfigurationClassDto.CAIssueLimitMaximum;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigCAParticipationLimit = eligibilityConfigurationClassDto.CAParticipationLimit;

            if (participant.MostRecentYearPaidW2Income.HasValue)
            {
                preQuoteCalculationRequest.MostRecentW2IncomeAmount = participant.MostRecentYearPaidW2Income;
            }

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(p => p.PlanDesignRequestClass.Id == participant.PlanDesignRequestClass.Id && p.IsActive);

                if (pdrSoldClass != null)
                {
                    BuildPreQuoteCalculationRequestForSoldClass(pdrSoldClass, preQuoteCalculationRequest);
                }
                else
                {
                    BuildPreQuoteCalculationRequestForPDRClass(participant.PlanDesignRequestClass, preQuoteCalculationRequest);
                }

                BuildPreQuoteCalculationRequestForParticipantInformation(participant, preQuoteCalculationRequest);
            }

            // CHANGE HERE
            //using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            //{
            //    if (!_pdrClassBenefitAmountsCalculationRequestDictionary.ContainsKey(participant.PlanDesignRequestClass.Id))
            //    {
            //        var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(p => p.PlanDesignRequestClass.Id == participant.PlanDesignRequestClass.Id && p.IsActive);
            //        if (pdrSoldClass != null)
            //        {
            //            BuildPreQuoteCalculationRequestForSoldClass(pdrSoldClass, preQuoteCalculationRequest, eligibilityConfigurationClassDto);
            //        }
            //        else
            //        {
            //            BuildPreQuoteCalculationRequestForPDRClass(participant.PlanDesignRequestClass, preQuoteCalculationRequest);
            //        }
            //        _pdrClassBenefitAmountsCalculationRequestDictionary.Add(participant.PlanDesignRequestClass.Id, preQuoteCalculationRequest);
            //    }
            //    else
            //    {
            //        preQuoteCalculationRequest = _pdrClassBenefitAmountsCalculationRequestDictionary[participant.PlanDesignRequestClass.Id];
            //    }
            //    BuildPreQuoteCalculationRequestForParticipantInformation(participant, preQuoteCalculationRequest);
            //}

            return preQuoteCalculationRequest;
        }

        private void BuildPreQuoteCalculationRequestForPDRClass(PlanDesignRequestClass participantPDRClass, BenefitAmountsCalculationRequest preQuoteCalculationRequest)
        {
            var primarPlanProduct = participantPDRClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == false);
            var vgsiBuyUpPlanProduct = participantPDRClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == true);
            if (primarPlanProduct != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.PrimaryGSIAmount = primarPlanProduct.GSIAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.ApprovedTotalGSIAmount = primarPlanProduct.GSIAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.IsVGSIBuyUp = false;
            }
            if (vgsiBuyUpPlanProduct != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.TotalMaxGSIAmount = vgsiBuyUpPlanProduct.TotalMaxGSIAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.ApprovedTotalGSIAmount = vgsiBuyUpPlanProduct.TotalMaxGSIAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.VoluntaryGSIAmount = vgsiBuyUpPlanProduct.GSIAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.IsVGSIBuyUp = true;
            }

            preQuoteCalculationRequest.ClassCalculationRequest.MaximumReplacementRatio = participantPDRClass.ApprovedMaximumReplacementRatio ?? participantPDRClass.RequestedMaximumReplacementRatio;

            preQuoteCalculationRequest.ClassCalculationRequest.PlanDesignType = participantPDRClass.ApprovedPlanDesignType ?? participantPDRClass.RequestedPlanDesignType;

            if (participantPDRClass.ApprovedPlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.PDRClassCoveredEarnings = participantPDRClass.PlanDesignRequestClassLTDCoverage.Select(i => i.GroupLTDCoveredEarningsType).FirstOrDefault();
            }
            else
            {
                preQuoteCalculationRequest.ClassCalculationRequest.PDRClassCoveredEarnings = participantPDRClass.ApprovedCoveredEarningsType ?? participantPDRClass.RequestedCoveredEarningsType;
            }

            preQuoteCalculationRequest.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly = participantPDRClass.ApprovedCoveredEarningsBonusOnlyType ?? participantPDRClass.RequestedCoveredEarningsBonusOnlyType;
            preQuoteCalculationRequest.ClassCalculationRequest.VGSIBuyUpCoveredEarnings = participantPDRClass.ApprovedGSIBuyUpCoveredEarningsType ?? participantPDRClass.RequestedGSIBuyUpCoveredEarningsType;
            preQuoteCalculationRequest.ClassCalculationRequest.VGSIBuyUpCoveredEarningsBonusOnly = participantPDRClass.ApprovedGSIBuyUpCoveredEarningsBonusOnlyType ?? participantPDRClass.RequestedGSIBuyUpCoveredEarningsBonusOnlyType;
            preQuoteCalculationRequest.ClassCalculationRequest.VGSIMaximumReplacementRatio = participantPDRClass.ApprovedGSIBuyUpReplacementPercentage ?? participantPDRClass.RequestedGSIBuyUpReplacementPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.RetirementContributionsType = participantPDRClass.ApprovedRetirementContributionsType ?? participantPDRClass.RequestedRetirementContributionsType;
            preQuoteCalculationRequest.ClassCalculationRequest.RetirementContributionAmount = participantPDRClass.ApprovedAnnualContributions ?? participantPDRClass.RequestedAnnualContributions;
            preQuoteCalculationRequest.ClassCalculationRequest.RequestedPercentage = participantPDRClass.ApprovedCoveredEarningsPercentage ?? participantPDRClass.RequestedCoveredEarningsPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.RPPRiderCoveredEarnings = participantPDRClass.ApprovedRppRiderCoveredEarningsType ?? participantPDRClass.RequestedRppRiderCoveredEarningsType;

            if (!string.IsNullOrEmpty(participantPDRClass.PlanDesignRequest.Case.CompanyRevisionSicCode))
            {
                int value = 0;
                int.TryParse(participantPDRClass.PlanDesignRequest.Case.CompanyRevisionSicCode.Substring(0, 4), out value);
                preQuoteCalculationRequest.ClassCalculationRequest.CompanySICCode = value;
            }

            if (participantPDRClass.IsApprovedVoluntaryGSIBuyUpPlan != null)
            {
                if (Convert.ToBoolean(participantPDRClass.IsApprovedVoluntaryGSIBuyUpPlan))
                {
                    preQuoteCalculationRequest.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType = participantPDRClass.ApprovedVoluntaryGSIBuyUpPlanDesignType;
                }
            }
            else
            {
                if (participantPDRClass.IsRequestedVoluntaryGSIBuyUpPlan != null)
                {
                    if (Convert.ToBoolean(participantPDRClass.IsRequestedVoluntaryGSIBuyUpPlan))
                    {
                        preQuoteCalculationRequest.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType = participantPDRClass.RequestedVoluntaryGSIBuyUpPlanDesignType;
                    }
                }
            }
            if (participantPDRClass.ApprovedFlatRateType != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.FlatRateTypeId = participantPDRClass.ApprovedFlatRateType.Id;
                preQuoteCalculationRequest.ClassCalculationRequest.FlatRateOther = participantPDRClass.ApprovedFlatRate_Other;
            }
            else
            {
                if (participantPDRClass.RequestedFlatRateType != null)
                {
                    preQuoteCalculationRequest.ClassCalculationRequest.FlatRateTypeId = participantPDRClass.RequestedFlatRateType.Id;
                    preQuoteCalculationRequest.ClassCalculationRequest.FlatRateOther = participantPDRClass.RequestedFlatRate_Other;
                }
            }

            if (participantPDRClass.PlanDesignRequestClassLTDCoverage != null)
            {
                var ltdCoverageInfo = participantPDRClass.PlanDesignRequestClassLTDCoverage.FirstOrDefault();
                if (ltdCoverageInfo != null)
                {
                    preQuoteCalculationRequest.ClassCalculationRequest.GroupLTDCoveredEarnings = ltdCoverageInfo.GroupLTDCoveredEarningsType;
                    preQuoteCalculationRequest.ClassCalculationRequest.GroupLTDCapAmount = ltdCoverageInfo.GroupLTDCapAmount;
                    preQuoteCalculationRequest.ClassCalculationRequest.GroupLTDReplacementPercentage = ltdCoverageInfo.GroupLTDReplacementPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage = ltdCoverageInfo.BaseSalaryPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassBonusPercentage = ltdCoverageInfo.BonusPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassBonusNoOfYear = ltdCoverageInfo.BonusNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassCommissionPercentage = ltdCoverageInfo.CommissionPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassCommissionsNoOfYear = ltdCoverageInfo.CommissionNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsPercentage = ltdCoverageInfo.K1EarningsPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsNoOfYear = ltdCoverageInfo.K1EarningsNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage = ltdCoverageInfo.OtherIncomePercentage;
                }
            }

            preQuoteCalculationRequest.ClassCalculationRequest.IDIPercentage = participantPDRClass.ApprovedIDIPercentage ?? participantPDRClass.RequestedIDIPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.LTDPercentage = participantPDRClass.ApprovedLTDPercentage ?? participantPDRClass.RequestedLTDPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.IDICoversFirst = participantPDRClass.ApprovedIDICovers1st ?? participantPDRClass.RequestedIDICovers1st;
            preQuoteCalculationRequest.ClassCalculationRequest.LTDCoversNext = participantPDRClass.ApprovedLTDCoversNext ?? participantPDRClass.RequestedLTDCoversNext;
            preQuoteCalculationRequest.ClassCalculationRequest.AnnualContribution = participantPDRClass.ApprovedAnnualContributions ?? participantPDRClass.RequestedAnnualContributions;
            //TO determine the Approved CAT amount for primary plan appoval
            var riders = participantPDRClass.PlanDesignRequestClassRiders.Where(c => c.IsGSIPlanIndicator == false);
            var RPPBenifitPDRClassRider = riders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
            if (RPPBenifitPDRClassRider != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.RPPBenefitAmount = RPPBenifitPDRClassRider.ApprovedAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.PrimaryPlanRPPRider = RPPBenifitPDRClassRider.BenefitType;
            }
            var voluntaryPlanRiders = participantPDRClass.PlanDesignRequestClassRiders.Where(c => c.IsGSIPlanIndicator == true);
            if (voluntaryPlanRiders != null)
            {
                var rppRider = voluntaryPlanRiders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
                if (rppRider != null)
                {
                    preQuoteCalculationRequest.ClassCalculationRequest.VoluntaryPlanRPPRider = rppRider.BenefitType;
                }
            }
            var planDesignRequestClassRiderCAT = riders.FirstOrDefault(p => (p.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider || p.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider));
            preQuoteCalculationRequest.ClassCalculationRequest.CATAmount = planDesignRequestClassRiderCAT != null ? planDesignRequestClassRiderCAT.ApprovedAmount : 0.0m;

            var customizeIDIInsurableIncome = participantPDRClass.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault(c => c.IsGSIPlanIndicator == false);
            GetCustomizedIDIInsurableIncome(preQuoteCalculationRequest, customizeIDIInsurableIncome, false);

            var customizeVGSIBuyUpIDIInsurableIncome = participantPDRClass.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault(c => c.IsGSIPlanIndicator == true);
            GetCustomizedIDIInsurableIncome(preQuoteCalculationRequest, customizeVGSIBuyUpIDIInsurableIncome, true);

            if (participantPDRClass.PlanDesignRequest.Case.CaseUnderwritingRequests.Any())
            {
                var caseUnderwritingRequest = participantPDRClass.PlanDesignRequest.Case.CaseUnderwritingRequests.First();
                preQuoteCalculationRequest.ClassCalculationRequest.SitusType = caseUnderwritingRequest.SitusType;
                preQuoteCalculationRequest.ClassCalculationRequest.CorporateSitusState = caseUnderwritingRequest.StateType;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState1Type = caseUnderwritingRequest.SitusMultiState1Type;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState2Type = caseUnderwritingRequest.SitusMultiState2Type;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState3Type = caseUnderwritingRequest.SitusMultiState3Type;
            }

            preQuoteCalculationRequest.ClassCalculationRequest.IllustrationEffectiveDate = GetIllustrationEffectiveDate(participantPDRClass);
        }

        public void BuildPreQuoteCalculationRequestForSoldClass(PDRSoldClass pdrSoldClass, BenefitAmountsCalculationRequest preQuoteCalculationRequest, EligibilityConfigurationDto eligibilityConfigurationClassDto = null)
        {
            //if (eligibilityConfigurationClassDto == null)
            //{
                eligibilityConfigurationClassDto = new EligibilityConfigurationDto { PlanDesignRequestClassId = pdrSoldClass.PlanDesignRequestClass.Id };
                eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
            //}

            preQuoteCalculationRequest.ClassCalculationRequest.RPPMaximumIndemnityAmount = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmount;
            preQuoteCalculationRequest.ClassCalculationRequest.RPPMaximumIndemnityAmountUnderAge49 = eligibilityConfigurationClassDto.RPPMaximumIndemnityAmountUnderAge49;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigIssueLimitMaximum = eligibilityConfigurationClassDto.IssueLimitMaximum;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigParticipationLimit = eligibilityConfigurationClassDto.ParticipationLimit;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigCAIssueLimitMaximum = eligibilityConfigurationClassDto.CAIssueLimitMaximum;
            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigCAParticipationLimit = eligibilityConfigurationClassDto.CAParticipationLimit;

            preQuoteCalculationRequest.ClassCalculationRequest.EligibilityConfigurationDto = eligibilityConfigurationClassDto;

            var pdrSoldClassPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
            var pdrSoldClassVoluntaryPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

            preQuoteCalculationRequest.ClassCalculationRequest.PrimaryGSIAmount = pdrSoldClassPlan.GSIAmount;
            preQuoteCalculationRequest.ClassCalculationRequest.ApprovedTotalGSIAmount = pdrSoldClassPlan.GSIAmount;
            preQuoteCalculationRequest.ClassCalculationRequest.MaximumReplacementRatio = pdrSoldClassPlan.MaximumReplacementRatio;

            var pdrSoldClassPlanRidersCAT = pdrSoldClassPlan.PDRSoldClassPlanRiders.FirstOrDefault(p => (p.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider || p.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider));
            preQuoteCalculationRequest.ClassCalculationRequest.CATAmount = pdrSoldClassPlanRidersCAT != null ? pdrSoldClassPlanRidersCAT.ApprovedAmount : 0.0m;
            preQuoteCalculationRequest.ClassCalculationRequest.RPPRiderCoveredEarnings = pdrSoldClassPlan.RppRiderCoveredEarningsType;
            preQuoteCalculationRequest.ClassCalculationRequest.RetirementContributionsType = pdrSoldClassPlan.RetirementContributionsType;

            if (pdrSoldClassPlan.PlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.PDRClassCoveredEarnings = pdrSoldClassPlan.PDRSoldClass.PDRSoldClassLTDCoverage.Select(i => i.GroupLTDCoveredEarningsType).FirstOrDefault();
            }
            else
            {
                preQuoteCalculationRequest.ClassCalculationRequest.PDRClassCoveredEarnings = pdrSoldClassPlan.CoveredEarningsType;
            }
            preQuoteCalculationRequest.ClassCalculationRequest.PDRClassCoveredEarningsBonusOnly = pdrSoldClassPlan.CoveredEarningsBonusOnlyType;
            preQuoteCalculationRequest.ClassCalculationRequest.RetirementContributionAmount = pdrSoldClassPlan.AnnualContributions;
            preQuoteCalculationRequest.ClassCalculationRequest.RequestedPercentage = pdrSoldClassPlan.CoveredEarningsPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.PlanDesignType = pdrSoldClassPlan.PlanDesignType;
            preQuoteCalculationRequest.ClassCalculationRequest.IsVGSIBuyUp = false;

            if (!string.IsNullOrEmpty(pdrSoldClass.PlanDesignRequest.Case.CompanyRevisionSicCode))
            {
                int value = 0;
                int.TryParse(pdrSoldClassPlan.PDRSoldClass.PlanDesignRequest.Case.CompanyRevisionSicCode.Substring(0, 4), out value);
                preQuoteCalculationRequest.ClassCalculationRequest.CompanySICCode = value;
            }

            if (pdrSoldClassPlan.FlatRateType != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.FlatRateTypeId = pdrSoldClassPlan.FlatRateType.Id;
            }
            preQuoteCalculationRequest.ClassCalculationRequest.FlatRateOther = pdrSoldClassPlan.FlatRate_Other;

            if (pdrSoldClass.PDRSoldClassLTDCoverage != null)
            {
                var ltdCoverageInfo = pdrSoldClass.PDRSoldClassLTDCoverage.FirstOrDefault();
                if (ltdCoverageInfo != null)
                {
                    preQuoteCalculationRequest.ClassCalculationRequest.GroupLTDCapAmount = ltdCoverageInfo.GroupLTDCapAmount;
                    preQuoteCalculationRequest.ClassCalculationRequest.GroupLTDReplacementPercentage = ltdCoverageInfo.GroupLTDReplacementPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.GroupLTDCoveredEarnings = ltdCoverageInfo.GroupLTDCoveredEarningsType;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassBaseSalaryPercentage = ltdCoverageInfo.BaseSalaryPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassBonusPercentage = ltdCoverageInfo.BonusPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassBonusNoOfYear = ltdCoverageInfo.BonusNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassCommissionPercentage = ltdCoverageInfo.CommissionPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassCommissionsNoOfYear = ltdCoverageInfo.CommissionNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsPercentage = ltdCoverageInfo.K1EarningsPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassK1EarningsNoOfYear = ltdCoverageInfo.K1EarningsNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomLTDInsurableClassOtherIncomePercentage = ltdCoverageInfo.OtherIncomePercentage;
                }

            }

            preQuoteCalculationRequest.ClassCalculationRequest.IDIPercentage = pdrSoldClassPlan.IDIPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.LTDPercentage = pdrSoldClassPlan.LTDPercentage;
            preQuoteCalculationRequest.ClassCalculationRequest.IDICoversFirst = pdrSoldClassPlan.IDICovers1st;
            preQuoteCalculationRequest.ClassCalculationRequest.LTDCoversNext = pdrSoldClassPlan.LTDCoversNext;

            preQuoteCalculationRequest.ClassCalculationRequest.AnnualContribution = pdrSoldClassPlan.AnnualContributions;

            //TO determine the Approved CAT amount for primary plan appoval
            var riders = pdrSoldClassPlan.PDRSoldClassPlanRiders.Where(c => c.PDRSoldClassPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
            var RPPBenifitPDRClassRider = riders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
            if (RPPBenifitPDRClassRider != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.RPPBenefitAmount = RPPBenifitPDRClassRider.ApprovedAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.PrimaryPlanRPPRider = RPPBenifitPDRClassRider.BenefitType;
            }
            if (pdrSoldClassVoluntaryPlan != null)
            {
                var voluntaryPlanRiders = pdrSoldClassVoluntaryPlan.PDRSoldClassPlanRiders.Where(c => c.PDRSoldClassPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                if (voluntaryPlanRiders != null)
                {
                    var rppRider = voluntaryPlanRiders.FirstOrDefault(c => c.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
                    if (rppRider != null)
                    {
                        preQuoteCalculationRequest.ClassCalculationRequest.VoluntaryPlanRPPRider = rppRider.BenefitType;
                    }
                }
            }
            //Customize
            var customizeIDIInsurableIncome = pdrSoldClassPlan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.FirstOrDefault();
            if (customizeIDIInsurableIncome != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableBaseSalaryPercentage = customizeIDIInsurableIncome.BaseSalaryPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableBonusPercentage = customizeIDIInsurableIncome.BonusPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableBonusNoOfYear = customizeIDIInsurableIncome.BonusNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage = customizeIDIInsurableIncome.CommissionPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableCommissionsNoOfYear = customizeIDIInsurableIncome.CommissionNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage = customizeIDIInsurableIncome.K1EarningsPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableK1EarningsNoOfYear = customizeIDIInsurableIncome.K1EarningsNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableOtherIncomePercentage = customizeIDIInsurableIncome.OtherIncomePercentage;
            }
            var pdrSoldClassVGSIBuyUpPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
            if (pdrSoldClassVGSIBuyUpPlan != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.VoluntaryGSIBuyUpPlanDesignType = (PlanDesignGSITypeEnum?)pdrSoldClassVGSIBuyUpPlan.PlanDesignType;
                preQuoteCalculationRequest.ClassCalculationRequest.VGSIBuyUpCoveredEarnings = pdrSoldClassVGSIBuyUpPlan.CoveredEarningsType;
                preQuoteCalculationRequest.ClassCalculationRequest.VGSIBuyUpCoveredEarningsBonusOnly = pdrSoldClassVGSIBuyUpPlan.CoveredEarningsBonusOnlyType;
                preQuoteCalculationRequest.ClassCalculationRequest.TotalMaxGSIAmount = pdrSoldClassVGSIBuyUpPlan.TotalMaxGSIAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.ApprovedTotalGSIAmount = pdrSoldClassVGSIBuyUpPlan.TotalMaxGSIAmount;
                preQuoteCalculationRequest.ClassCalculationRequest.VoluntaryGSIAmount = pdrSoldClassVGSIBuyUpPlan.GSIAmount;

                preQuoteCalculationRequest.ClassCalculationRequest.VGSIMaximumReplacementRatio = pdrSoldClassVGSIBuyUpPlan.ReplacementPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.IsVGSIBuyUp = true;
                var customizeVGSIBuyUpIDIInsurableIncome = pdrSoldClassVGSIBuyUpPlan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.FirstOrDefault();
                if (customizeVGSIBuyUpIDIInsurableIncome != null)
                {
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBaseSalaryPercentage = customizeVGSIBuyUpIDIInsurableIncome.BaseSalaryPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusPercentage = customizeVGSIBuyUpIDIInsurableIncome.BonusPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusNoOfYear = customizeVGSIBuyUpIDIInsurableIncome.BonusNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionPercentage = customizeVGSIBuyUpIDIInsurableIncome.CommissionPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionsNoOfYear = customizeVGSIBuyUpIDIInsurableIncome.CommissionNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsPercentage = customizeVGSIBuyUpIDIInsurableIncome.K1EarningsPercentage;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsNoOfYear = customizeVGSIBuyUpIDIInsurableIncome.K1EarningsNumberofYears;
                    preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeOtherIncomePercentage = customizeVGSIBuyUpIDIInsurableIncome.OtherIncomePercentage;
                }
            }

            if (pdrSoldClass.PlanDesignRequestClass.PlanDesignRequest.Case.CaseUnderwritingRequests.Any())
            {
                var caseUnderwritingRequest = pdrSoldClass.PlanDesignRequestClass.PlanDesignRequest.Case.CaseUnderwritingRequests.First();
                preQuoteCalculationRequest.ClassCalculationRequest.SitusType = caseUnderwritingRequest.SitusType;
                preQuoteCalculationRequest.ClassCalculationRequest.CorporateSitusState = caseUnderwritingRequest.StateType;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState1Type = caseUnderwritingRequest.SitusMultiState1Type;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState2Type = caseUnderwritingRequest.SitusMultiState2Type;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState3Type = caseUnderwritingRequest.SitusMultiState3Type;
            }

            preQuoteCalculationRequest.ClassCalculationRequest.IllustrationEffectiveDate = GetIllustrationEffectiveDate(pdrSoldClass.PlanDesignRequestClass);
        }

        private void BuildPreQuoteCalculationRequestForParticipantInformation(Participant participant, BenefitAmountsCalculationRequest preQuoteCalculationRequest)
        {
            preQuoteCalculationRequest.MostRecentSalaryAmount = participant.MostRecentSalaryAmount;
            preQuoteCalculationRequest.MostRecentPaidBonusAmount = participant.MostRecentPaidBonusAmount;
            preQuoteCalculationRequest.PriorPaidBonusAmount = participant.PriorPaidBonusAmount;
            preQuoteCalculationRequest.AdditionalPriorPaidBonusAmount = participant.AdditionalPriorPaidBonusAmount;
            preQuoteCalculationRequest.MostRecentPaidCommissionAmount = participant.MostRecentPaidCommissionAmount;
            preQuoteCalculationRequest.PriorPaidCommissionAmount = participant.PriorPaidCommissionAmount;
            preQuoteCalculationRequest.AdditionalPriorPaidCommissionAmount = participant.AdditionalPriorPaidCommissionAmount;
            preQuoteCalculationRequest.MostRecentPaidK1IncomeAmount = participant.MostRecentPaidK1IncomeAmount;
            preQuoteCalculationRequest.PriorPaidK1IncomeAmount = participant.PriorPaidK1IncomeAmount;
            preQuoteCalculationRequest.AdditionalPriorPaidK1IncomeAmount = participant.AdditionalPriorPaidK1IncomeAmount;
            preQuoteCalculationRequest.OtherIncomeAmount = participant.OtherIncomeAmount;
            preQuoteCalculationRequest.IDIInsurableIncomeAmount = participant.IDIInsurableIncomeCalculatedAmount;
            preQuoteCalculationRequest.TotalEmployerOrEmployeeRetirementContributionAmount = participant.TotalEmployerOrEmployeeRetirementContributionAmount;

            preQuoteCalculationRequest.IDIReplacementPercentRequests = new List<IDIReplacementPercentRequest>
            {
                AssignReplacementPercentRequest(participant.IDIBenefitAmount1, participant.IDIToBeReplaced1, participant.IDICarrier1, participant.IDIToBeReplacedAmount1,participant.IDIToBeIgnore1),
                AssignReplacementPercentRequest(participant.IDIBenefitAmount2, participant.IDIToBeReplaced2, participant.IDICarrier2, participant.IDIToBeReplacedAmount2,participant.IDIToBeIgnore2),
                AssignReplacementPercentRequest(participant.IDIBenefitAmount3, participant.IDIToBeReplaced3, participant.IDICarrier3, participant.IDIToBeReplacedAmount3,participant.IDIToBeIgnore3),
                AssignReplacementPercentRequest(participant.IDIBenefitAmount4, participant.IDIToBeReplaced4, participant.IDICarrier4, participant.IDIToBeReplacedAmount4,participant.IDIToBeIgnore4)
            };

            if (participant.Census.PlanDesignRequest.Case.CaseUnderwritingRequests.Any())
            {
                var caseUnderwritingRequest = participant.Census.PlanDesignRequest.Case.CaseUnderwritingRequests.First();
                preQuoteCalculationRequest.ClassCalculationRequest.SitusType = caseUnderwritingRequest.SitusType;
                preQuoteCalculationRequest.ClassCalculationRequest.CorporateSitusState = caseUnderwritingRequest.StateType;
                preQuoteCalculationRequest.HomeState = participant.HomeState;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState1Type = caseUnderwritingRequest.SitusMultiState1Type;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState2Type = caseUnderwritingRequest.SitusMultiState2Type;
                preQuoteCalculationRequest.ClassCalculationRequest.SitusMultiState3Type = caseUnderwritingRequest.SitusMultiState3Type;
            }

            preQuoteCalculationRequest.LTDCalculatedAmount = participant.LTDCalculatedAmount;
            preQuoteCalculationRequest.GuardianExistingIDICoverageAmount = participant.GuardianExistingIDICoverageTotalCalculatedAmount;
            preQuoteCalculationRequest.OtherExistingIDICoverageAmount = participant.OtherExistingIDICoverageTotalCalculatedAmount;
            preQuoteCalculationRequest.IDIInsurableIncomeAmount = participant.IDIInsurableIncomeCalculatedAmount;

            preQuoteCalculationRequest.CustomLTDInsurableIncomeBaseSalaryPercentage = participant.CustomLTDInsurableIncomeBaseSalaryPercentage;
            preQuoteCalculationRequest.CustomLTDInsurableIncomeBonusPercentage = participant.CustomLTDInsurableIncomeBonusPercentage;
            preQuoteCalculationRequest.CustomLTDInsurableIncomeCommissionPercentage = participant.CustomLTDInsurableIncomeCommissionPercentage;
            preQuoteCalculationRequest.CustomLTDInsurableIncomeOtherIncomePercentage = participant.CustomLTDInsurableIncomeOtherIncomePercentage;

            //preQuoteCalculationRequest.Age = GetIssueAge(participant.DateOfBirth, participant.PlanDesignRequestClass.PlanDesignRequest.IllustrationEffectiveDate, participant.PlanDesignRequestClass.Id);
            preQuoteCalculationRequest.ParticipantDateOfBirth = participant.DateOfBirth;
            preQuoteCalculationRequest.ManualBenefitAmount = participant.ManualBenefitAmount;
            preQuoteCalculationRequest.ManualBenefitAMBIncreaseAmount = participant.ManualBenefitAMBIncreaseAmount;
            preQuoteCalculationRequest.ManualRPPAmount = participant.ManualRPPAmount;
            preQuoteCalculationRequest.ManualRPPAMBIncreaseAmount = participant.ManualRPPAMBIncreaseAmount;
            preQuoteCalculationRequest.ManualVGSIBuyUpAMBIncreaseAmount = participant.ManualVGSIBuyUpAMBIncreaseAmount;
            preQuoteCalculationRequest.ClassCalculationRequest.IllustrationEffectiveDate = GetIllustrationEffectiveDate(participant.PlanDesignRequestClass);

            if (participant.ParticipantExistingPolicies.Any())
            {
                var cmsCase = participant.PlanDesignRequestClass.PlanDesignRequest.Case;
                var participantExistingPolicy = participant.ParticipantExistingPolicies.FirstOrDefault();                
                if (preQuoteCalculationRequest.IDIReplacementPercentRequests.Any())
                {   
                    decimal? idiGuardianBenefitAmount = preQuoteCalculationRequest.IDIReplacementPercentRequests.Where(i => i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Berkshire || i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Guardian)
                                                                                     .Sum(j => j.IDIBenefitAmount);
                    decimal? idiGuardianReplacementAmount = preQuoteCalculationRequest.IDIReplacementPercentRequests.Where(i => i.IsReplaceCoverage == true && (i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Berkshire || i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Guardian))
                                                                                        .Sum(j => j.IDIReplacementAmount);

                    decimal? idiOtherBenefitAmount = preQuoteCalculationRequest.IDIReplacementPercentRequests.Where(i => i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Berkshire && i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Guardian)
                                                                                     .Sum(j => j.IDIBenefitAmount);
                    decimal? idiOtherReplacementAmount = preQuoteCalculationRequest.IDIReplacementPercentRequests.Where(i => i.IsReplaceCoverage == true && (i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Berkshire && i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Guardian))
                                                                                        .Sum(j => j.IDIReplacementAmount);

                    preQuoteCalculationRequest.GSIIDIBaseAMBAmount = (idiGuardianBenefitAmount.HasValue ? idiGuardianBenefitAmount : 0.0m) - (idiGuardianReplacementAmount.HasValue ? idiGuardianReplacementAmount : 0.0m);
                    //Below line is not required as per NBTC-3088
                    //preQuoteCalculationRequest.FullyUnderWrittenIDIAmount = (idiOtherBenefitAmount.HasValue ? idiOtherBenefitAmount : 0.0m) - (idiOtherReplacementAmount.HasValue ? idiOtherReplacementAmount : 0.0m);


                }

                if (participantExistingPolicy.ParticipantExistingPolicyDetails.Any())
                {
                    var policyDetails = participantExistingPolicy.ParticipantExistingPolicyDetails;
                    preQuoteCalculationRequest.BaseGSIMaxAmount = policyDetails.Where(i => i.PremiumPayer != null && i.PremiumPayer.ToUpper() == "EMPLOYER" && i.IsTerminateAndReplace == false).Sum(j => j.MonthlyIndemnity);
                    preQuoteCalculationRequest.VGSIBuyUpMaxAmount = policyDetails.Where(i => i.PremiumPayer != null && i.PremiumPayer.ToUpper() == "EMPLOYEE" && i.IsTerminateAndReplace == false).Sum(j => j.MonthlyIndemnity);
                }

                if (participantExistingPolicy.FullyUnderwrittenIDI != null && participantExistingPolicy.FullyUnderwrittenIDI > 0)
                {
                    preQuoteCalculationRequest.FullyUnderWrittenIDIAmount = participantExistingPolicy.FullyUnderwrittenIDI;
                }

                if (participantExistingPolicy.GSIIDIBaseAMB != null && participantExistingPolicy.GSIIDIBaseAMB > 0)
                {
                    preQuoteCalculationRequest.GSIIDIBaseAMBAmount = participantExistingPolicy.GSIIDIBaseAMB;
                }

                //Fixing INC2412851 - Fully Underwriten coverage  FUW not calculating correctly in Production - DFCT0051077
                if (participantExistingPolicy.GSIIDIBaseAMB == null && (participantExistingPolicy.FullyUnderwrittenIDI != null && participantExistingPolicy.FullyUnderwrittenIDI > 0))
                {
                    preQuoteCalculationRequest.GSIIDIBaseAMBAmount = 0;
                }

                preQuoteCalculationRequest.GSIRPPBaseAMBAmount = participantExistingPolicy.GSIRPPBaseAMB;
                preQuoteCalculationRequest.FullyUnderWrittenRPPAmount = participantExistingPolicy.FullyUnderwrittenRPP;

                GetParticipantExistingPolicyRequest(participantExistingPolicy.ParticipantExistingPolicyDetails, cmsCase, participantExistingPolicy, preQuoteCalculationRequest);
            }

            preQuoteCalculationRequest.ManualVGSIBuyUpBenefitAmount = participant.ManualVGSIBuyUpBenefitAmount;
            preQuoteCalculationRequest.IsAMBIncreasePolicy = participant.IsAMBIncreaseIndicator ?? false;
            preQuoteCalculationRequest.IsAMBPolicy = participant.IsPushtoNewProviderChoicePolicyIndicator;
            preQuoteCalculationRequest.IsBuyUpAMBIncreaseIndicator = participant.IsBuyUpAMBIncreaseIndicator ?? false;
        }

        public void GetParticipantExistingPolicyRequest(IList<ParticipantExistingPolicyDetail> participantExistingPolicyDetail, Case cmsCase, ParticipantExistingPolicy participantExistingPolicy, BenefitAmountsCalculationRequest preQuoteCalculationRequest)
        {
            if (participantExistingPolicy != null && participantExistingPolicyDetail.Any())
            {
                var gsiBasePlusInforceAMB = participantExistingPolicyDetail.Where(c => c.CaseNumber != null && c.CaseNumber.Trim() == cmsCase.CaseNumber
                && c.PremiumPayer == "Employer"
                && c.CLOASPolicyStatus == "Inforce").ToList();
                if (gsiBasePlusInforceAMB != null && gsiBasePlusInforceAMB.Any())
                {
                    preQuoteCalculationRequest.GSIBasePlusInforceAMB = gsiBasePlusInforceAMB.Sum(c => c.MonthlyIndemnity);
                }

                var vgsiBuyUpPlusInforceAMB = participantExistingPolicyDetail.Where(c => c.CaseNumber != null && c.CaseNumber.Trim() == cmsCase.CaseNumber
                && c.PremiumPayer == "Employee"
                && c.CLOASPolicyStatus == "Inforce").ToList();
                if (vgsiBuyUpPlusInforceAMB != null && vgsiBuyUpPlusInforceAMB.Any())
                {
                    preQuoteCalculationRequest.VGSIBuyUpPlusInforceAMB = vgsiBuyUpPlusInforceAMB.Sum(c => c.MonthlyIndemnity);
                }

                if ((participantExistingPolicy.FullyUnderwrittenRPP != null && participantExistingPolicy.FullyUnderwrittenRPP > 0)
                    || (participantExistingPolicy.GSIRPPBaseAMB != null && participantExistingPolicy.GSIRPPBaseAMB > 0))
                {
                    var gsiBasePlusInforceAMBRpp = participantExistingPolicyDetail.Where(c => c.CaseNumber != null && c.CaseNumber.Trim() == cmsCase.CaseNumber
                    && c.CLOASPolicyStatus == "Inforce").ToList();
                    if (gsiBasePlusInforceAMBRpp != null && gsiBasePlusInforceAMBRpp.Any())
                    {
                        preQuoteCalculationRequest.GSIBasePlusInforceAMBRpp = gsiBasePlusInforceAMBRpp.Sum(c => c.MonthlyIndemnity);
                    }
                }
            }
        }

        private void GetCustomizedIDIInsurableIncome(BenefitAmountsCalculationRequest preQuoteCalculationRequest, PDRClassCustomizedIDIInsurableIncome customizeIDIInsurableIncome, bool isVGSIBuyUp)
        {
            if (isVGSIBuyUp && customizeIDIInsurableIncome != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBaseSalaryPercentage = customizeIDIInsurableIncome.BaseSalaryPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusPercentage = customizeIDIInsurableIncome.BonusPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeBonusNoOfYear = customizeIDIInsurableIncome.BonusNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionPercentage = customizeIDIInsurableIncome.CommissionPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeCommissionsNoOfYear = customizeIDIInsurableIncome.CommissionNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsPercentage = customizeIDIInsurableIncome.K1EarningsPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeK1EarningsNoOfYear = customizeIDIInsurableIncome.K1EarningsNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomVGSIBuyUPInsurableIncomeOtherIncomePercentage = customizeIDIInsurableIncome.OtherIncomePercentage;
            }
            else if (customizeIDIInsurableIncome != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableBaseSalaryPercentage = customizeIDIInsurableIncome.BaseSalaryPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableBonusPercentage = customizeIDIInsurableIncome.BonusPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableBonusNoOfYear = customizeIDIInsurableIncome.BonusNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage = customizeIDIInsurableIncome.CommissionPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableCommissionsNoOfYear = customizeIDIInsurableIncome.CommissionNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage = customizeIDIInsurableIncome.K1EarningsPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableK1EarningsNoOfYear = customizeIDIInsurableIncome.K1EarningsNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableOtherIncomePercentage = customizeIDIInsurableIncome.OtherIncomePercentage;
            }
        }

        private IDIReplacementPercentRequest AssignReplacementPercentRequest(decimal? idiBenefitAmount, bool? isReplaceCoverage, IDICoverageCarrierTypeEnum? idiCoverageCarrier_Id, decimal? idiReplacementAmount, bool? isIgnoreCoverage)
        {
            IDIReplacementPercentRequest idiReplacementPercentRequest = new IDIReplacementPercentRequest();
            idiReplacementPercentRequest.IDIBenefitAmount = idiBenefitAmount.HasValue ? idiBenefitAmount : 0.0m;
            idiReplacementPercentRequest.IsReplaceCoverage = isReplaceCoverage ?? null;
            idiReplacementPercentRequest.IDICarrier_Id = idiCoverageCarrier_Id ?? null;
            idiReplacementPercentRequest.IDIReplacementAmount = idiReplacementAmount.HasValue ? idiReplacementAmount : 0.0m;
            idiReplacementPercentRequest.IsIgnoreCoverage = isIgnoreCoverage ?? null;
            return idiReplacementPercentRequest;
        }

        private void GetCustomizedIDIInsurableIncome(BenefitAmountsCalculationRequest preQuoteCalculationRequest, PDRClassCustomizedIDIInsurableIncome customizeIDIInsurableIncome)
        {
            if (customizeIDIInsurableIncome != null)
            {
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableBaseSalaryPercentage = customizeIDIInsurableIncome.BaseSalaryPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableBonusPercentage = customizeIDIInsurableIncome.BonusPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableBonusNoOfYear = customizeIDIInsurableIncome.BonusNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableCommissionPercentage = customizeIDIInsurableIncome.CommissionPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableCommissionsNoOfYear = customizeIDIInsurableIncome.CommissionNumberofYears;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableK1EarningsPercentage = customizeIDIInsurableIncome.K1EarningsPercentage;
                preQuoteCalculationRequest.ClassCalculationRequest.CustomIDIInsurableK1EarningsNoOfYear = customizeIDIInsurableIncome.K1EarningsNumberofYears;
            }
        }

        public DateTime? GetIllustrationEffectiveDate(PlanDesignRequestClass planDesignRequestClass)
        {
            if (_pdrClassIllustrationEffectiveDateDictionary.ContainsKey(planDesignRequestClass.Id)) return _pdrClassIllustrationEffectiveDateDictionary[planDesignRequestClass.Id];

            DateTime? illustrationEffectiveDate = planDesignRequestClass.PlanDesignRequest.IllustrationEffectiveDate;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentPDRClass = unitOfWork.Repository<EnrollmentPDRClass>().Linq()
                    .Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClass.Id);

                if (enrollmentPDRClass.Any())
                {
                    var enrollments = enrollmentPDRClass.OrderByDescending(x => x.Enrollment).First();
                    if (enrollments != null)
                    {
                        illustrationEffectiveDate = enrollments.Enrollment.EffectiveDate;
                    }
                }
            }

            _pdrClassIllustrationEffectiveDateDictionary.TryAdd(planDesignRequestClass.Id, illustrationEffectiveDate);

            return illustrationEffectiveDate;
        }
    }
}