﻿using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.CensusManagers;
using Common.Exceptions;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Model.Enums;
using System.Text.RegularExpressions;

namespace CMS.Managers.CaseManagers
{
    public class CensusManagerValidator
    {
        public void ValidateEligibilityData(CensusParticipantDto participantsInfoDto)
        {
            Log.TraceFormat("+ValidateEligibilityData");

            var errorMessages = new List<string>();

            if (participantsInfoDto.IsEligible == false && (participantsInfoDto.InEligibleReason_Id == 0 || participantsInfoDto.InEligibleReason_Id == null))
            {
                errorMessages.Add("Please select ineligible reason.");
            }
            else if (participantsInfoDto.InEligibleReason_Id == 99 && String.IsNullOrEmpty(participantsInfoDto.OtherReason))
            {
                errorMessages.Add("Please enter other ineligible reason.");
            }

            if (participantsInfoDto.CustomLTDInsurableIncomeBaseSalaryPercentage.HasValue)
            {
                if (participantsInfoDto.CustomLTDInsurableIncomeBaseSalaryPercentage <= 0 || participantsInfoDto.CustomLTDInsurableIncomeBaseSalaryPercentage > 100)
                {
                    errorMessages.Add("Please enter a valid Base Salary Percentage.");
                }
            }

            if (participantsInfoDto.CustomLTDInsurableIncomeBonusPercentage.HasValue)
            {
                if (participantsInfoDto.CustomLTDInsurableIncomeBonusPercentage <= 0 || participantsInfoDto.CustomLTDInsurableIncomeBonusPercentage > 100)
                {
                    errorMessages.Add("Please enter a valid Bonus Percentage.");
                }
            }

            if (participantsInfoDto.CustomLTDInsurableIncomeCommissionPercentage.HasValue)
            {
                if (participantsInfoDto.CustomLTDInsurableIncomeCommissionPercentage <= 0 || participantsInfoDto.CustomLTDInsurableIncomeCommissionPercentage > 100)
                {
                    errorMessages.Add("Please enter a valid Commission Percentage.");
                }
            }

            if (participantsInfoDto.CustomLTDInsurableIncomeOtherIncomePercentage.HasValue)
            {
                if (participantsInfoDto.CustomLTDInsurableIncomeOtherIncomePercentage <= 0 || participantsInfoDto.CustomLTDInsurableIncomeOtherIncomePercentage > 100)
                {
                    errorMessages.Add("Please enter a valid Other Income Percentage.");
                }
            }

            if (participantsInfoDto.ReplacementPercent1.HasValue)
            {
                if (participantsInfoDto.ReplacementPercent1 <= 0 || participantsInfoDto.ReplacementPercent1 > 100)
                {
                    errorMessages.Add("Please enter a valid Replacement Percentage.");
                }
            }

            //if (participantsInfoDto.IDICarrierID1 != null || participantsInfoDto.PremiumPayerId1 != null || participantsInfoDto.ReplacementPercent1 != null || participantsInfoDto.IDIBenefitAmount1 != null)
            //{
            //    bool errorInc = false;
            //    if (participantsInfoDto.IDICarrierID1 != null)
            //    {
            //        if (participantsInfoDto.PremiumPayerId1 == null || participantsInfoDto.ReplacementPercent1 == null || participantsInfoDto.IDIBenefitAmount1 == null)
            //        {
            //            errorInc = true;
            //        }
            //    }
            //    if (participantsInfoDto.PremiumPayerId1 != null)
            //    {
            //        if (participantsInfoDto.IDICarrierID1 == null || participantsInfoDto.ReplacementPercent1 == null || participantsInfoDto.IDIBenefitAmount1 == null)
            //        {
            //            errorInc = true;
            //        }
            //    }
            //    if (participantsInfoDto.ReplacementPercent1 != null)
            //    {
            //        if (participantsInfoDto.IDICarrierID1 == null || participantsInfoDto.PremiumPayerId1 == null || participantsInfoDto.IDIBenefitAmount1 == null)
            //        {
            //            errorInc = true;
            //        }
            //    }
            //    if (participantsInfoDto.IDIBenefitAmount1 != null)
            //    {
            //        if (participantsInfoDto.IDICarrierID1 == null || participantsInfoDto.PremiumPayerId1 == null || participantsInfoDto.ReplacementPercent1 == null)
            //        {
            //            errorInc = true;
            //        }
            //    }

            //    if (errorInc == true)
            //    {
            //        errorMessages.Add("Please enter value for all the coverage detail fields.");
            //    }
            //}


        Log.TraceFormat("-ValidateEligibilityData");

            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }

        public void ValidateEditCensusInformation(CensusParticipantDto participantsInfoDto)
        {
            Log.TraceFormat("+ValidateEditCensusInformation");

            var errorMessages = new List<string>();

            ValidateOtherReason(participantsInfoDto, errorMessages);

            ValidateIneligibleReason(participantsInfoDto, errorMessages);

            ValidateZipCode(participantsInfoDto, errorMessages);

            ValidateAddressLength(participantsInfoDto, errorMessages);

            Log.TraceFormat("-ValidateEditCensusInformation");
            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }
        public void ValidateOtherReason(CensusParticipantDto participantsInfoDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateOtherReason");

            if (participantsInfoDto.InEligibleReason_Id == (int)InEligibleReasonTypeEnum.Other && string.IsNullOrEmpty(participantsInfoDto.OtherReason))
            {
                errorMessages.Add("Please enter Other reason.");
            }
            Log.TraceFormat("-ValidateOtherReason");
        }

        public void ValidateIneligibleReason(CensusParticipantDto participantsInfoDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateIneligibleReason");

            if (participantsInfoDto.InEligibleReason_Id == null && participantsInfoDto.IsEligible == false)
            {
                errorMessages.Add("Please set reason for ineligibility.");
            }

            Log.TraceFormat("-ValidateIneligibleReason");
        }
        public void ValidateZipCode(CensusParticipantDto participantsInfoDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateZipCode");

            if (!string.IsNullOrEmpty(participantsInfoDto.HomeZipCode))
            {
                bool isUsZipCode = IsUsZipCode(participantsInfoDto.HomeZipCode);
                Log.DebugFormat("IsUsZipCode={0}", isUsZipCode);
                if (!isUsZipCode) errorMessages.Add("Home Zip Code is invalid");
            }
            if (!string.IsNullOrEmpty(participantsInfoDto.WorkZipCode))
            {
                bool isUsZipCode = IsUsZipCode(participantsInfoDto.WorkZipCode);
                Log.DebugFormat("IsUsZipCode={0}", isUsZipCode);
                if (!isUsZipCode) errorMessages.Add("Work Zip Code is invalid");
            }

            Log.TraceFormat("-ValidateZipCode");
        }
        private bool IsUsZipCode(string zipCode)
        {
            Log.TraceFormat("+IsUsZipCode");

            bool validZipCode = false;
            string _usZipRegEx = @"^\d{5}(?:[-\s]\d{4})?$";
            if (Regex.Match(zipCode, _usZipRegEx).Success)
            {
                validZipCode = true;
            }

            Log.TraceFormat("-IsUsZipCode");

            return validZipCode;
        }

        public void ValidateAddressLength(CensusParticipantDto participantsInfoDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateAddressLength");
            if (participantsInfoDto.HomeStreet1 != null)
            {
                if (participantsInfoDto.HomeStreet1.Length >= 23)
                {
                    errorMessages.Add("Please enter HomeAddress1 length less than 23.");
                }
            }
            if(participantsInfoDto.HomeStreet2 != null)
            {
                if (participantsInfoDto.HomeStreet2.Length >= 23)
                {
                    errorMessages.Add("Please enter HomeAddress2 length less than 23.");
                }
            }
            if (participantsInfoDto.HomeCity != null)
            {
                if (participantsInfoDto.HomeCity.Length >= 23)
                {
                    errorMessages.Add("Please enter HomeCity length less than 23.");
                }
            }
            if (participantsInfoDto.WorkStreet1 != null)
            {
                if (participantsInfoDto.WorkStreet1.Length >= 23)
                {
                    errorMessages.Add("Please enter WorkAddress1 length less than 23.");
                }
            }
            if (participantsInfoDto.WorkStreet2 != null)
            {
                if (participantsInfoDto.WorkStreet2.Length >= 23)
                {
                    errorMessages.Add("Please enter WorkAddress2 length less than 23.");
                }
            }
            if (participantsInfoDto.WorkCity != null)
            {
                if (participantsInfoDto.WorkCity.Length >= 23)
                {
                    errorMessages.Add("Please enter WorkCity length less than 23.");
                }
            }

            Log.TraceFormat("-ValidateAddressLength");
        }
    }
}
