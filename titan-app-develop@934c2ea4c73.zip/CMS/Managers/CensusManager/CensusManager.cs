﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.BrokerDataServices;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.CensusManagers;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Interfaces.Managers.LookupManagers;
using CMS.Interfaces.Managers.OccupationClassAssignmentManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.SecurityManagers;
using CMS.Interfaces.Managers.TaskManagers;
using CMS.Managers.CaseManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Exceptions;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;
using Guardian.Core.Entities.Product.Enums.EnumExtensions;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace CMS.Managers.CensusManagers
{
    public class CensusManager : ICensusManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IBenefitAmountsCalculationManager _preQuoteCalculationManager;
        private readonly IEligibilityDeterminationManager _eligibilityDeterminationManager;
        private readonly IOccupationClassAssignmentManager _occupationClassAssignmentManager;
        private readonly ILookupManager _lookupManager;
        private readonly CensusManagerValidator _censusManagerValidator;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;
        private readonly IPlanDesignRequestSoldManager _planDesignRequestSoldManager;
        private readonly ITaskManager _taskManager;
        private readonly ICaseManager _caseManager;
        private readonly Dictionary<int, EligibilityConfigurationDto> _classEligibilityConfigurationDictionary;
        private readonly string AddressLengthErrorReason = "Review Address";
        private readonly int ThreadSleep15Secs = 15000;
        private readonly string[] PriorReasons = { "prior coverage - policy status", "more than 3 in force policies", "Confirm in force Guardian Coverage" };
        private readonly string[] TitanPriorCoverageSearchGroupings = { "Fully Underwritten IDI RPP", "Fully Underwritten IDI", "MultiLife GSI RPP", "MultiLife GSI" };
        private readonly IBrokerDataClient _brokerService;
        private bool IsOneStepEnrollmentIndicator = false;
        private static List<OccupationCode> occupationCodes;
        private readonly ISecurityManager _securityManager;

        public CensusManager(IUnitOfWorkFactory unitOfWorkFactory, IBenefitAmountsCalculationManager preQuoteCalculationManager, IEligibilityDeterminationManager eligibilityDeterminationManager,
            IOccupationClassAssignmentManager occupationClassAssignmentManager, ILookupManager lookupManager, CensusManagerValidator censusManagerValidator, IEligibilityConfigurationManager eligibilityConfigurationManager,
             IPlanDesignRequestSoldManager planDesignRequestSoldManager, ITaskManager taskManager, ICaseManager caseManager, IBrokerDataClient brokerService, ISecurityManager securityManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _preQuoteCalculationManager = preQuoteCalculationManager;
            _eligibilityDeterminationManager = eligibilityDeterminationManager;
            _occupationClassAssignmentManager = occupationClassAssignmentManager;
            _lookupManager = lookupManager;
            _censusManagerValidator = censusManagerValidator;
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
            _planDesignRequestSoldManager = planDesignRequestSoldManager;
            _taskManager = taskManager;
            _caseManager = caseManager;
            _classEligibilityConfigurationDictionary = new Dictionary<int, EligibilityConfigurationDto>();
            _brokerService = brokerService;
            _securityManager = securityManager;
        }

        public List<CensusPlanDesignRequestClassDto> GetCensusPlanDesignRequestClassList(int censusPlanDesignRequestId)
        {
            Log.TraceFormat("+GetCensusPlanDesignRequestClassList");
            List<CensusPlanDesignRequestClassDto> censusPDRClassDtos;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                censusPDRClassDtos = unitOfWork.Repository<PlanDesignRequestClass>().Linq()
                    .Where(c => c.PlanDesignRequest.Id == censusPlanDesignRequestId && c.IsActive)
                    .Select(c =>
                        new CensusPlanDesignRequestClassDto
                        {
                            CensusPlanDesignRequestId = c.PlanDesignRequest.Id,
                            CensusPlanDesignRequestClassId = c.Id,
                            CensusPlanDesignRequestClass = c.PlanDesignRequestClassName,
                            CensusApprovedEligiblePopulationText = GetApprovedEligibleText(c.PlanDesignRequest.Id, c.Id, c.ApprovedEligiblePopulationText),
                            CensusRequestedEligiblePopulationText = c.RequestedEligiblePopulationText
                        })
                    .ToList();


            }
            var firstThreeFixedRows = GetFixedClassData(censusPlanDesignRequestId).Where(i => i.CensusPlanDesignRequestClassId < 0).ToList();
            var lastFixedRow = GetFixedClassData(censusPlanDesignRequestId).Where(i => i.CensusPlanDesignRequestClassId == 0).ToList();
            var mergedCensusPDRClassDtos = firstThreeFixedRows.Concat(censusPDRClassDtos).Concat(lastFixedRow).ToList();


            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var census = unitOfWork.Repository<Census>().LinqWithTimeOut().FirstOrDefault(i => i.PlanDesignRequest.Id == censusPlanDesignRequestId && i.IsActiveIndicator);

                //var participant = unitOfWork.Repository<Participant>().LinqWithTimeOut().Where(i => i.PlanDesignRequestClass.PlanDesignRequest.Id == censusPlanDesignRequestId);


                var participant = unitOfWork.Repository<Participant>().LinqWithTimeOut()
                                       .Where(i => i.Census.Id == census.Id);

                foreach (var classDto in mergedCensusPDRClassDtos)
                {
                    try
                    {
                        switch (classDto.CensusPlanDesignRequestClassId)
                        {
                            case (int)CensusClassTypeEnum.Error:
                                classDto.CensusPlanDesignRequestParticipants = participant.Count(p => (p.IsError != null && p.IsError == true && p.IsActive == true));
                                break;
                            case (int)CensusClassTypeEnum.Ineligible:
                                classDto.CensusPlanDesignRequestParticipants = participant.Count(p => (p.IsError == null || p.IsError == false) && (p.IsEligible == false && p.IsEligible != null) && p.IsActive == true);
                                break;
                            case (int)CensusClassTypeEnum.Unassigned:

                                classDto.CensusPlanDesignRequestParticipants = participant.Count(p => p.PlanDesignRequestClass == null
                                && (p.IsError == null || p.IsError == false) && (p.IsEligible == true || p.IsEligible == null) && p.IsActive == true);
                                break;
                            case (int)CensusClassTypeEnum.All:
                                classDto.CensusPlanDesignRequestParticipants = participant.Count(p => p.IsActive == true);
                                break;
                            default:
                                classDto.CensusPlanDesignRequestParticipants = participant.Count(p => p.PlanDesignRequestClass != null
                                                                               && p.PlanDesignRequestClass.Id == classDto.CensusPlanDesignRequestClassId
                                                                               && (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null) && p.IsActive == true);
                                break;
                        }

                    }
                    catch (Exception ex)
                    {
                        Log.ErrorFormat("ERROR in calculating participant count", ex);
                    }
                }
            }

            Log.TraceFormat("-GetCensusPlanDesignRequestClassList");
            return mergedCensusPDRClassDtos;
        }
        private string GetApprovedEligibleText(int planDesignRquestId, int planDesignRequestclassId, string approvedEligiblePopulationText)
        {
            Log.TraceFormat("+GetApprovedEligibleText");
            string approvedText = string.Empty;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                approvedText = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Id == planDesignRquestId && c.PlanDesignRequestClass.Id == planDesignRequestclassId).Select(i => i.EligiblePopulationText).FirstOrDefault();
                if (string.IsNullOrEmpty(approvedText))
                {
                    approvedText = approvedEligiblePopulationText != null ? approvedEligiblePopulationText : "";
                }
            }
            Log.TraceFormat("-GetApprovedEligibleText");
            return approvedText;
        }

        public List<IllustrationCensusParticipantDto> GetParticipants(int planDesignRequestClassId)
        {
            Log.TraceFormat("+GetParticipants");
            List<IllustrationCensusParticipantDto> participants;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                participants = unitOfWork.Repository<Participant>().Linq()
                    .Where(c => c.PlanDesignRequestClass.Id == planDesignRequestClassId && c.Census.IsActiveIndicator && c.IsActive == true)
                    .Select(c => new IllustrationCensusParticipantDto
                    {
                        CensusParticipantId = c.Id,
                        HomeState = c.HomeState ?? null,
                        WorkState = c.WorkState ?? null,
                        ContractState = c.ContractState ?? null,
                        Age = c.Age,
                        IssueAge = c.IssueAge,
                        DateOfBirth = c.DateOfBirth,
                        OccupationClass_Id = c.OccupationClass_Id,
                        MostRecentSalaryAmount = c.MostRecentSalaryAmount,
                        MostRecentPaidBonusAmount = c.MostRecentPaidBonusAmount,
                        PriorPaidBonusAmount = c.PriorPaidBonusAmount,
                        MostRecentPaidCommissionAmount = c.MostRecentPaidCommissionAmount,
                        PriorPaidCommissionAmount = c.PriorPaidCommissionAmount,
                        MostRecentPaidK1IncomeAmount = c.MostRecentPaidK1IncomeAmount,
                        PriorPaidK1IncomeAmount = c.PriorPaidK1IncomeAmount,
                        OtherIncomeAmount = c.OtherIncomeAmount,
                        IDIInsurableIncomeCalculatedAmount = c.IDIInsurableIncomeCalculatedAmount,
                        TotalEmployerOrEmployeeRetirementContributionsAmount = c.TotalEmployerOrEmployeeRetirementContributionAmount,
                        LTDCalculatedAmount = c.LTDCalculatedAmount,
                        GuardianExistingIDICoverageTotalCalculatedAmount = c.GuardianExistingIDICoverageTotalCalculatedAmount,
                        OtherExistingIDICoverageTotalCalculatedAmount = c.OtherExistingIDICoverageTotalCalculatedAmount,
                        IDICarrier1 = c.IDICarrier1,
                        IDIBenefitAmount1 = c.IDIBenefitAmount1,
                        IDIToBeReplaced1 = c.IDIToBeReplaced1,
                        IDICarrier2 = c.IDICarrier2,
                        IDIBenefitAmount2 = c.IDIBenefitAmount2,
                        IDIToBeReplaced2 = c.IDIToBeReplaced2,
                        IDICarrier3 = c.IDICarrier3,
                        IDIBenefitAmount3 = c.IDIBenefitAmount3,
                        IDIToBeReplaced3 = c.IDIToBeReplaced3,
                        MostRecentW2IncomeAmount = c.MostRecentYearPaidW2Income
                    }).ToList();
            }

            Log.TraceFormat("-GetParticipants");
            return participants;
        }

        public void CalculatePreQuoteAmounts(List<int> censusParticipantIds, CensusManagerOperation operationID)
        {
            Log.TraceFormat("+CalculatePreQuoteAmounts");

            var splittedParticipantsIds = censusParticipantIds.ChunkBy(1500);
            List<PlanDesignRequestClass> pdrClasslist = new List<PlanDesignRequestClass>();

            foreach (var chunkIds in splittedParticipantsIds)
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var censusParticipants = unitOfWork.Repository<Participant>().Linq().Where(c => chunkIds.Contains(c.Id)).ToList();
                    var distinctClasses = censusParticipants.GroupBy(c => c.PlanDesignRequestClass).Where(gr => gr.Key != null).Select(gr => gr.Key);

                    foreach (var obj in distinctClasses)
                    {
                        if (pdrClasslist.Where(i => i.Id == obj.Id).Count() == 0)
                        {
                            pdrClasslist.Add(obj);
                        }
                    }
                }
            }


            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                if (pdrClasslist != null)
                {
                    foreach (var pdrC in pdrClasslist)
                    {
                        foreach (var chunkIds in splittedParticipantsIds)
                        {
                            var censusParticipants = unitOfWork.Repository<Participant>().Linq().Where(c => chunkIds.Contains(c.Id)).ToList();
                            var participantsByClass = censusParticipants.Where(c => c.PlanDesignRequestClass.Id == pdrC.Id).ToList();
                            if (participantsByClass.Any())
                            {
                                var participantIds = participantsByClass.Select(c => c.Id).ToList();
                                PerformOperation(participantIds, operationID);
                            }
                        }
                    }
                }
            }

            Log.TraceFormat("-CalculatePreQuoteAmounts");
        }

        public void PerformOperation(List<int> censusParticipantIds, CensusManagerOperation operationID)
        {
            Log.TraceFormat("+PerformOperation");

            int? companySicMajorGroupTypeId = null;
            int? companySicSubGroupTypeId = null;
            int classParticipantCount = 0;
            bool? IsGSIPlanIndicator = false;
            ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum? premiumPayerandTaxability = null;
            PDRSoldClass pdrSoldClass = new PDRSoldClass();
            PDRSoldClassPlan pdrSoldClassPlan = new PDRSoldClassPlan();
            PlanDesignRequestClass planDesignRequestClass = new PlanDesignRequestClass();

            var splittedParticipantsIds = censusParticipantIds.ChunkBy(1000);
            var startTime = DateTime.Now;
            //Parallel.ForEach(splittedParticipantsIds, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, obj =>
            foreach (var obj in splittedParticipantsIds)
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var censusParticipants = unitOfWork.Repository<Participant>().Linq().Where(c => c.IsEligible == true || c.IsEligible == null);
                    var selectedParticipants = censusParticipants.Where(c => obj.Contains(c.Id) && c.PlanDesignRequestClass != null).ToList();
                    var pdrSoldClassList = unitOfWork.Repository<PDRSoldClass>().Linq();
                    var planDesignRequestClassList = unitOfWork.Repository<PlanDesignRequestClass>().Linq();

                    if (selectedParticipants != null && selectedParticipants.Count() > 0)
                    {
                        var singleParticipant = selectedParticipants.FirstOrDefault();
                        if (singleParticipant != null)
                        {
                            companySicMajorGroupTypeId = singleParticipant.Census.PlanDesignRequest.Case.CompanySicMajorGroupType != null ? (int?)singleParticipant.Census.PlanDesignRequest.Case.CompanySicMajorGroupType.Id : null;
                            companySicSubGroupTypeId = singleParticipant.Census.PlanDesignRequest.Case.CompanySicSubGroupType != null ? (int?)singleParticipant.Census.PlanDesignRequest.Case.CompanySicSubGroupType.Id : null;
                            classParticipantCount = censusParticipants.Count(p => p.Census.PlanDesignRequest.Id == singleParticipant.Census.PlanDesignRequest.Id && p.PlanDesignRequestClass.Id == singleParticipant.PlanDesignRequestClass.Id && p.IsError == false && p.IsEligible == true);

                            if (singleParticipant.PlanDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType != null)
                            {
                                premiumPayerandTaxability = (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum)singleParticipant.PlanDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Id;
                            }
                            else
                            {
                                if (singleParticipant.PlanDesignRequestClass.RequestedPremiumPayerAndTaxabilityType != null)
                                {
                                    premiumPayerandTaxability = (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum)singleParticipant.PlanDesignRequestClass.RequestedPremiumPayerAndTaxabilityType.Id;
                                }
                            }

                            planDesignRequestClass = planDesignRequestClassList.FirstOrDefault(c => c.Id == singleParticipant.PlanDesignRequestClass.Id && c.IsActive == true);
                            pdrSoldClass = pdrSoldClassList.FirstOrDefault(c => c.PlanDesignRequestClass.Id == singleParticipant.PlanDesignRequestClass.Id && c.IsActive == true);
                            if (pdrSoldClass != null)
                            {
                                pdrSoldClassPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                                IsGSIPlanIndicator = pdrSoldClass.PDRSoldClassPlan.Any(x => x.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                            }
                            else
                            {
                                IsGSIPlanIndicator = planDesignRequestClass?.PlanDesignRequestClassProducts.Any(x => x.IsGSIPlanIndicator == true);
                            }

                        }
                    }

                    Parallel.ForEach(selectedParticipants, participant =>
                    {
                        switch (operationID)
                        {
                            case CensusManagerOperation.CLOASOccupationCodeAssignment:
                                var occupationClassAssignmentRequest = CreateOccupationClassAssignmentRequest(participant, null, participant.PlanDesignRequestClass, companySicMajorGroupTypeId, companySicSubGroupTypeId, classParticipantCount, premiumPayerandTaxability);
                                var occupationClassAssignmentResponse = _occupationClassAssignmentManager.GetCLOASOccupationCode(occupationClassAssignmentRequest);
                                participant.IsError = occupationClassAssignmentResponse.IsError;
                                participant.ErrorReason = occupationClassAssignmentResponse.ErrorReason;
                                participant.CLOASOccupationCode = occupationClassAssignmentResponse.OccCode;
                                if (occupationClassAssignmentResponse.Occupation != null)
                                {
                                    participant.Occupation = occupationClassAssignmentResponse.Occupation;
                                }
                                Log.Trace(string.Format("Participant Id:{0} Participant Cloas Occupation code:{1}", participant.Id, participant.CLOASOccupationCode));
                                break;
                            case CensusManagerOperation.OccupationClassAssignment:
                                if (participant.IsAMBIncreaseIndicator != true && participant.IsBuyUpAMBIncreaseIndicator != true)
                                {
                                    var occupationClassAssignmentRequest1 = CreateOccupationClassAssignmentRequest(participant, censusParticipants, participant.PlanDesignRequestClass, companySicMajorGroupTypeId, companySicSubGroupTypeId, classParticipantCount, premiumPayerandTaxability);

                                    var occupationClassAssignmentResponse1 = _occupationClassAssignmentManager.GetOccupationClass(occupationClassAssignmentRequest1);
                                    participant.IsError = occupationClassAssignmentResponse1.IsError;
                                    participant.ErrorReason = occupationClassAssignmentResponse1.ErrorReason;
                                    participant.OccupationClass_Id = (int?)occupationClassAssignmentResponse1.OccupationClass;
                                    participant.OccupationClassDescription = occupationClassAssignmentResponse1.OccupationClass == null ? null : occupationClassAssignmentResponse1.OccupationClass.GetDescription();
                                    if (!occupationClassAssignmentResponse1.IsEligible)
                                    {
                                        participant.IsEligible = occupationClassAssignmentResponse1.IsEligible;
                                        participant.IneligibleReason = occupationClassAssignmentResponse1.InEligibleReason;
                                    }
                                }
                                break;
                        }

                        unitOfWork.Repository<Participant>().Save(participant);
                    });


                    foreach (var participant in selectedParticipants)
                    {
                        switch (operationID)
                        {
                            case CensusManagerOperation.BenefitAmountCalculations:
                                if (participant.PlanDesignRequestClass != null)
                                {
                                    CalculateAmountsForParticipant(participant, null);
                                    participant.PlanDesignRequestClassEligiblePopulationText = GetApprovedEligibleText(participant.PlanDesignRequestClass.PlanDesignRequest.Id, participant.PlanDesignRequestClass.Id, participant.PlanDesignRequestClassEligiblePopulationText);
                                }
                                break;
                            case CensusManagerOperation.EligibilityDetermination:
                                EligibilityDeterminationRequest eligibilityDeterminationRequest;
                                eligibilityDeterminationRequest = pdrSoldClass != null ?
                                        _eligibilityDeterminationManager.CreateEligibilityDeterminationRequest(participant, pdrSoldClass) :
                                        _eligibilityDeterminationManager.CreateEligibilityDeterminationRequest(participant, planDesignRequestClass);

                                var determinationResponse = _eligibilityDeterminationManager.Determine(eligibilityDeterminationRequest);
                                participant.IsEligible = determinationResponse.isEligible;
                                participant.IneligibleReason = determinationResponse.InEligibleReason;
                                participant.AAW = eligibilityDeterminationRequest.AAW;
                                participant.PlanDesignRequestClassEligiblePopulationText = GetApprovedEligibleText(participant.PlanDesignRequestClass.PlanDesignRequest.Id, participant.PlanDesignRequestClass.Id, participant.PlanDesignRequestClassEligiblePopulationText);

                                if (eligibilityDeterminationRequest.IsOneStepEnrollmentIndicator)
                                {
                                    var onestepdeterminationResponse = _eligibilityDeterminationManager.DetermineOneStepEligibility(eligibilityDeterminationRequest);
                                    participant.IsError = onestepdeterminationResponse.IsError;
                                    participant.ErrorReason = onestepdeterminationResponse.ErrorReason;
                                }

                                if (participant.IsEligible == true)
                                {
                                    participant.InEligibleReason_Id = null;
                                    if (participant.IsAMBIncreaseIndicator == true)
                                    {
                                        participant.ParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.AMB;
                                        participant.ParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.AMB.GetCode();
                                    }

                                    else if (participant.BasePlanPreviousSolicitations == 0 || participant.BasePlanPreviousSolicitations == null)
                                    {
                                        participant.ParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.NE;
                                        participant.ParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.NE.GetCode();
                                    }
                                    else if (participant.BasePlanPreviousSolicitations == 1)
                                    {
                                        participant.ParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.PS;
                                        participant.ParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.PS.GetCode();
                                    }
                                    else if (participant.BasePlanPreviousSolicitations >= 2)
                                    {
                                        participant.ParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.FO;
                                        participant.ParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.FO.GetCode();
                                    }
                                    if (IsGSIPlanIndicator == true)
                                    {
                                        if (participant.IsBuyUpAMBIncreaseIndicator == true)
                                        {
                                            participant.BuyUpParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.AMB;
                                            participant.BuyUpParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.AMB.GetCode();
                                        }
                                        else if (participant.VGSIPlanPreviousSolicitations == 0 || participant.VGSIPlanPreviousSolicitations == null)
                                        {
                                            participant.BuyUpParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.NE;
                                            participant.BuyUpParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.NE.GetCode();
                                        }
                                        else if (participant.VGSIPlanPreviousSolicitations == 1)
                                        {
                                            participant.BuyUpParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.PS;
                                            participant.BuyUpParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.PS.GetCode();
                                        }
                                        else if (participant.VGSIPlanPreviousSolicitations >= 2)
                                        {
                                            participant.BuyUpParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.FO;
                                            participant.BuyUpParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.FO.GetCode();
                                        }
                                    }
                                }
                                break;
                        }
                        unitOfWork.Repository<Participant>().Save(participant);
                    }
                    unitOfWork.Commit();
                }
            }//);

            var endtime = DateTime.Now;
            var elapsedTime = endtime - startTime;
            Log.TraceFormat("-PerformOperation");
        }

        public void SaveCensusInfo(CensusDto request, bool isReenrollment)
        {
            Log.TraceFormat("+SaveCensusInfo");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var planDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == request.PlanDesignRequestId);
                var planDesignRequestClasses = unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.PlanDesignRequest.Id == request.PlanDesignRequestId).ToList();

                bool isAnnualReviewExists = unitOfWork.Repository<AnnualReview>().Linq().Any(c => c.Case.Id == request.CaseId); // For checking re-enrollment census - B-08048

                Log.TraceFormat("+SaveCensusInfo: CaseId:{0} PdrId:{1} GaPdrId:{2} IsActive:{3}", request.CaseId, request.PlanDesignRequestId, request.GAPlanDesignRequestId, request.IsActiveIndicator);

                var census = new Census
                {
                    Case = cmsCase,
                    GACensusId = request.GACensusId,
                    PlanDesignRequest = planDesignRequest,
                    IsActiveIndicator = request.IsActiveIndicator,
                    ReceivedDateTime = request.ReceivedDateTime,
                    GAPlanDesignRequestId = request.GAPlanDesignRequestId
                };

                if (request.CensusParticipants != null)
                {
                    BuildCensusParticipant(request, census, planDesignRequestClasses, isReenrollment);
                }

                if (isAnnualReviewExists)
                {
                    if (cmsCase.CaseStatusType != CaseStatusTypeEnum.Withdrawn)
                    {
                        var caseStatusRequest = new CaseStatusDto
                        {
                            CaseId = request.CaseId,
                            CaseStatusType = CaseStatusTypeEnum.ReEnrollmentReview,
                            PlanDesignRequestStatusType = null,
                        };

                        _caseManager.SaveCaseStatusAndPDRStatus(caseStatusRequest);
                    }
                    CreateTasksForReEnrollmentCensus(request.CaseId, unitOfWork);
                }
                else
                {
                    if (isReenrollment)
                    {
                        var caseStatusRequest = new CaseStatusDto
                        {
                            CaseId = request.CaseId,
                            CaseStatusType = CaseStatusTypeEnum.EnrollmentReview,
                            PlanDesignRequestStatusType = null,
                        };
                        _caseManager.SaveCaseStatusAndPDRStatus(caseStatusRequest);
                    }
                    else
                    {
                        UpdatePDRStatusToCensusApproved(request);
                    }
                }

                unitOfWork.Repository<Census>().Save(census);
                unitOfWork.Commit();


                if (!isReenrollment && request.PlanDesignRequestId == -1)
                {
                    RecoverFailedCensusLink(request);
                }
            }

            Log.TraceFormat("-SaveCensusInfo");
        }

        private void UpdatePDRStatusToCensusApproved(CensusDto request)
        {
            Log.TraceFormat("+UpdatePDRStatusToCensusApproved caseId{0} Plan Design Request Id {1}", request.CaseId, request.PlanDesignRequestId);

            var caseStatusRequest = new CaseStatusDto
            {
                CaseId = request.CaseId,
                TaskName = CmsTask.TaskRevisedCaseReceived,
                IsClaimingOfRevisedCase = false,
                PlanDesignRequestStatusType = PlanDesignRequestStatusTypeEnum.CensusApproved,
                CaseStatusType = CaseStatusTypeEnum.PDRSubmitted,
                PlanDesignRequestId = request.PlanDesignRequestId
            };
            _caseManager.SaveCaseStatusAndPDRStatus(caseStatusRequest);

            Log.TraceFormat("-UpdatePDRStatusToCensusApproved");

        }

        public void RecoverFailedCensusLink(CensusDto request)
        {
            Log.TraceFormat("+RecoverFailedCensusLink");

            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    Log.TraceFormat("+RecoverFailedCensusLink: CaseId:{0} PdrId:{1}", request.CaseId, request.PlanDesignRequestId);

                    var census = unitOfWork.Repository<Census>().Linq()
                                .Where(c => c.Case.Id == request.CaseId && c.PlanDesignRequest.Id == request.PlanDesignRequestId
                                 && c.GACensusId == request.GACensusId && c.IsActiveIndicator);

                    if (!census.Any())
                    {
                        Log.TraceFormat("+RecoverFailedCensusLink: PdrId is -1 for CaseId: {0}", request.CaseId);

                        for (int i = 1; i < 4; i++) // 3 retry max
                        {
                            Log.TraceFormat("+RecoverFailedCensusLink: Retry count : {0}", i);

                            var planDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId && c.GAPlanDesignRequestId == request.GAPlanDesignRequestId);

                            if (planDesignRequest != null)
                            {
                                if (RetryCensusLinkUpdate(request, planDesignRequest, unitOfWork))
                                {
                                    Log.TraceFormat("+RecoverFailedCensusLink: Census PdrId link restored, Retry:{0} CaseId:{1} PdrId:{2}", i, request.CaseId, planDesignRequest.Id);
                                    break;
                                }
                                else
                                {
                                    Thread.Sleep(ThreadSleep15Secs);
                                    Log.TraceFormat("+RecoverFailedCensusLink: Wait added for 15 seconds.");
                                }
                            }
                            else
                            {
                                Log.TraceFormat("+RecoverFailedCensusLink: Pdr request not exist for CaseId:{0} Retry:{1}", request.CaseId, i);
                                Thread.Sleep(ThreadSleep15Secs);
                                Log.TraceFormat("+RecoverFailedCensusLink: Wait added for 15 seconds.");
                            }
                            //Log.TraceFormat("+RecoverFailedCensusLink: Census PdrId link not restored Retry:{0} CaseId:{1} GaPdrId:{2}", i, request.CaseId, request.GAPlanDesignRequestId);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error Recovering Failed Census Link.", ex);
                Log.TraceFormat("-RecoverFailedCensusLink");
            }

            Log.TraceFormat("-RecoverFailedCensusLink");
        }

        public bool RetryCensusLinkUpdate(CensusDto request, PlanDesignRequest planDesignRequest, IUnitOfWork unitOfWork)
        {
            Log.TraceFormat("+RetryCensusLinkUpdate");
            string censusIds = string.Empty;

            bool isSuccess = true;
            for (int noofRetries = 0; noofRetries < 3; noofRetries++)
            {
                Log.TraceFormat("+RetryCensusLinkUpdate: Retry count : {0} Case Id : {1} Census Id : {2} GACensus Id : {3} GAPlanDesignRequest Id : {4} PlanDesignRequest Id : {5}"
                    , noofRetries, request.CaseId, request.CensusId, request.GACensusId, request.GAPlanDesignRequestId, request.PlanDesignRequestId);

                var updateFailedCensusList = unitOfWork.Repository<Census>().Linq()
                             .Where(c => c.Case.Id == request.CaseId && c.GACensusId == request.GACensusId && c.IsActiveIndicator && c.PlanDesignRequest == null);

                if (updateFailedCensusList.Any())
                {
                    try
                    {
                        var updatedPdrCensusList = new List<int>();
                        foreach (var updateFailedCensus in updateFailedCensusList)
                        {
                            Log.TraceFormat("+RetryCensusLinkUpdate: Trying PdrId:{0} linking for CensusId:{1}", planDesignRequest.Id, updateFailedCensus.Id);
                            updatedPdrCensusList.Add(updateFailedCensus.Id);
                            censusIds = censusIds + updateFailedCensus.Id + ", ";
                            updateFailedCensus.PlanDesignRequest = planDesignRequest;
                            unitOfWork.Repository<Census>().Save(updateFailedCensus);
                        }
                        unitOfWork.Commit();
                        Log.TraceFormat("+RetryCensusLinkUpdate: PdrId:{0} linking Successful for CensusIds:{1}", planDesignRequest.Id, censusIds);

                        if (updatedPdrCensusList != null && updatedPdrCensusList.Count > 0)
                        {
                            RecoverParticipantPDRClass(updatedPdrCensusList);
                        }

                        if (planDesignRequest != null)
                        {
                            request.PlanDesignRequestId = planDesignRequest.Id;
                            UpdatePDRStatusToCensusApproved(request);
                        }

                        isSuccess = true;
                        break;
                    }
                    catch (Exception ex)
                    {
                        Log.ErrorFormat("Error updating Census", ex);
                        Log.TraceFormat("+RetryCensusLinkUpdate: PdrId:{0} linking failed for CensusIds:{1}", planDesignRequest.Id, censusIds);
                        isSuccess = false;
                    }
                }
                else
                {
                    isSuccess = false;
                    Log.TraceFormat("+RetryCensusLinkUpdate: Census id's not availble for linking the PdrId:{0}", planDesignRequest.Id);
                    Thread.Sleep(ThreadSleep15Secs);
                    Log.TraceFormat("+RetryCensusLinkUpdate: Wait added for 15 seconds.");
                }

            }

            Log.TraceFormat("-RetryCensusLinkUpdate");

            return isSuccess;
        }

        private void RecoverParticipantPDRClass(List<int> updatedPdrCensusList)
        {
            Log.TraceFormat("+RecoverParticipantPDRClass");
            string ParticipantId = string.Empty;
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    foreach (var censusId in updatedPdrCensusList)
                    {
                        var census = unitOfWork.Repository<Census>().Linq().FirstOrDefault(c => c.Id == censusId);
                        var plandesignRequest = census.PlanDesignRequest;
                        if (plandesignRequest != null)
                        {
                            var pdrClassess = unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.PlanDesignRequest.Id == plandesignRequest.Id);
                            var participants = unitOfWork.Repository<Participant>().Linq().Where(c => c.Census.Id == censusId);
                            foreach (var p in participants)
                            {
                                ParticipantId = p.Id.ToString(); //Logging purpose
                                Log.TraceFormat("+RecoverParticipantPDRClass : Participant Eligible class:{0} - CensusIds:{1} - PDR ID : {2}", p.EligibleClass, censusId, plandesignRequest.Id);

                                var pdrClass = pdrClassess.FirstOrDefault(c => c.GAPlanDesignRequestClassId == p.EligibleClass);
                                if (pdrClass != null)
                                {
                                    p.PlanDesignRequestClass = pdrClass;
                                    p.PlanDesignRequestClassEligiblePopulationText = pdrClass.ApprovedEligiblePopulationText ??
                                                                                                     pdrClass.RequestedEligiblePopulationText;
                                    Log.TraceFormat("+RecoverParticipantPDRClass : Participant PDR Class Id: {0} - CensusIds:{1}", pdrClass.Id, censusId);
                                }
                                unitOfWork.Repository<Participant>().Save(p);
                            }
                        }
                    }
                    unitOfWork.Commit();
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error updating RecoverParticipantPDRClass", ex);
                Log.TraceFormat("+RecoverParticipantPDRClass: Failed Participant Id {0}", ParticipantId);
            }

            Log.TraceFormat("-RecoverParticipantPDRClass");
        }

        public void ChangeSelectedClassForCensusParticipants(List<int> selectedParticipantIds, int selectedClassId, bool isSold)
        {
            Log.TraceFormat("+ChangeSelectedClassForCensusParticipants");

            List<List<int>> splittedParticipants = selectedParticipantIds.ChunkBy(2000);

            Parallel.ForEach(splittedParticipants, obj =>
            {
                try
                {
                    using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                    {
                        string eligibleText = string.Empty;
                        var selectedParticipants = unitOfWork.Repository<Participant>().Linq().Where(c => obj.Contains(c.Id)).ToList();
                        if (isSold)
                        {
                            var sold = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.Id == selectedClassId).FirstOrDefault();
                            if (sold != null)
                            {
                                eligibleText = sold.EligiblePopulationText;
                                selectedClassId = sold.PlanDesignRequestClass.Id;
                            }
                        }

                        var planDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == selectedClassId);

                        foreach (Participant censusParticipant in selectedParticipants)
                        {
                            if (planDesignRequestClass != null)
                            {
                                censusParticipant.PlanDesignRequestClassEligiblePopulationText = isSold ? eligibleText : planDesignRequestClass.ApprovedEligiblePopulationText;
                                censusParticipant.PlanDesignRequestClass = planDesignRequestClass;
                            }

                            unitOfWork.Repository<Participant>().Save(censusParticipant);
                        }
                        unitOfWork.Commit();
                    }
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat("Error in changing the participants class", ex);
                }
            });

            Log.TraceFormat("-ChangeSelectedClassForCensusParticipants");
        }
        public void UpdateCensusParticipants(List<int> selectedParticipantIds,string status)
        {
            Log.TraceFormat("+UpdateCensusParticipants");

            List<List<int>> segmentedParticipants = selectedParticipantIds.ChunkBy(2000);

            Parallel.ForEach(segmentedParticipants, segmentedParticipant =>
            {
                try
                {
                    using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                    {
                        var selectedParticipants = unitOfWork.Repository<Participant>().Linq().Where(participant => segmentedParticipant.Contains(participant.Id)).ToList();

                        foreach (Participant censusParticipant in selectedParticipants)
                        {
                            if (status == "deactivate")
                            {
                                censusParticipant.IsActive = false;
                                
                            }
                            else if(status== "activate")
                            {
                                censusParticipant.IsActive = true;
                            }
                            unitOfWork.Repository<Participant>().Save(censusParticipant);
                        }
                        unitOfWork.Commit();
                    }
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat("Error in "+ status +" the participants", ex);
                }
            });

            Log.TraceFormat("-UpdateCensusParticipants");
        }
 
        public void SaveEditMultipleParticipantsInfo(CensusParticipantDto participantsInfoDto, List<int> selectedCensusParticipantsIds)
        {
            Log.TraceFormat("+SaveEditMultipleParticipantsInfo");
            try
            {
                _censusManagerValidator.ValidateEligibilityData(participantsInfoDto);

                var censusList = new List<Participant>();
                var finalCensusParticipantList = new List<Participant>();
                var enrollmentParticipantsDto = new List<EditEnrollmentParticipantDto>();
                var partialPolicyMatchParicipantIds = new List<int>();
                var inForceCoveragePolicyMatchParicipantIds = new List<int>();
                var oseIndicatorList = new List<OSEIndicator>();

                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var participant = unitOfWork.Repository<Participant>().LinqWithTimeOut();                    

                    // NEW
                    int[] pdrClassIds = unitOfWork.Repository<PlanDesignRequestClass>().LinqWithTimeOut()
                        .Where(x => participantsInfoDto.SelectedPdrIdList.Contains(x.PlanDesignRequest.Id) && x.IsActive)
                        .Select(x => x.Id)
                        .ToArray();
                    censusList = participant.Where(x =>
                            participantsInfoDto.SelectedPdrIdList.Contains(x.Census.PlanDesignRequest.Id) &&
                            x.Census.PlanDesignRequest.IsActive &&
                            x.Census.IsActiveIndicator &&
                            pdrClassIds.Contains(x.PlanDesignRequestClass.Id))
                        .ToList();


                    if (participantsInfoDto.IDICarrierID1 != null && participantsInfoDto.PremiumPayerId1 != null && participantsInfoDto.ReplacementPercent1 != null && participantsInfoDto.IDIBenefitAmount1 != null)
                    {
                        var censusMaxIDICarrierList = censusList.Where(c => selectedCensusParticipantsIds.Contains(c.Id)
                                                                            && (c.IDICarrier1 != null || c.PremiumPayerId1 != null || c.ReplacementPercent1 != null || c.IDIBenefitAmount1 != null)
                                                                            && (c.IDICarrier2 != null || c.PremiumPayerId2 != null || c.ReplacementPercent2 != null || c.IDIBenefitAmount2 != null)
                                                                            && (c.IDICarrier3 != null || c.PremiumPayerId3 != null || c.ReplacementPercent3 != null || c.IDIBenefitAmount3 != null)
                                                                            && (c.IDICarrier4 != null || c.PremiumPayerId4 != null || c.ReplacementPercent4 != null || c.IDIBenefitAmount4 != null)
                        ).ToList();
                        if (censusMaxIDICarrierList.Any())
                        {
                            var participantIDs = censusMaxIDICarrierList.Select(c => c.EmployeeId);
                            throw new ValidationException("Number of IDI Coverage Records for Participant exceeds maximum for selected participants: " + string.Join(",", participantIDs));
                        }
                    }

                    var selectedParticipantsEmployeeIds = participant
                        .Where(x => selectedCensusParticipantsIds.Contains(x.Id))
                        .Select(x => x.EmployeeId)
                        .ToList();
                    var finalListChunk = censusList
                        .Where(x => selectedParticipantsEmployeeIds.Contains(x.EmployeeId))
                        .ToList();
                    finalCensusParticipantList.AddRange(finalListChunk);

                    if (participantsInfoDto.IsRemoveAllOutsideCoverage == true)
                    {
                        RemoveAllOutsideCoverage(finalCensusParticipantList);
                    }

                    if ((participantsInfoDto.IsEligible == null || participantsInfoDto.IsEligible == false) && participantsInfoDto.IsIncludePartialMatchPriorCoverage == null)
                    {
                        var partialPolicyMatchParicipantEmployeeIds = finalCensusParticipantList.Where(p => p.IsError == true && p.ParticipantExistingPolicies.Any(pep => pep.ParticipantExistingPolicyDetails.Any(pepd => pepd.IsPolicyMatch == false))).Select(p => p.EmployeeId).ToList();
                        if (partialPolicyMatchParicipantEmployeeIds.Any())
                        {
                            throw new ValidationException("There are participants in the error class with the \"Potential Prior Coverage Match\" error. It is require one of the radio button options of \"Include\" or \"Remove\" be selected to complete the Edit Multiple Participant.\n Participant Employeed Id : " + string.Join(", ", partialPolicyMatchParicipantEmployeeIds));
                        }
                    }


                    // NEW CODE - get OSE indicators
                    Dictionary<int, bool> pdrClassOseDictionary = new Dictionary<int, bool>();
                    int[] finalPdrClassIds = finalCensusParticipantList
                        .Select(x => x.PlanDesignRequestClass.Id)
                        .Distinct()
                        .ToArray();
                    foreach (var pdrClassId in finalPdrClassIds)
                    {
                        if (!pdrClassOseDictionary.ContainsKey(pdrClassId))
                        {
                            int pdrSoldClassId = unitOfWork.Repository<PDRSoldClass>().Linq()
                                .Where(x => x.PlanDesignRequestClass.Id == pdrClassId)
                                .Select(x => x.Id)
                                .FirstOrDefault();
                            if (pdrSoldClassId > 0)
                            {
                                // Then this is having sold class
                                bool oneStepEnrollmentIndicator = unitOfWork.Repository<PDRSoldClassPlan>().Linq()
                                    .Where(x => x.PDRSoldClass.Id == pdrSoldClassId)
                                    .Select(x => x.IsOneStepEnrollmentIndicator)
                                    .FirstOrDefault();
                                pdrClassOseDictionary.Add(pdrClassId, oneStepEnrollmentIndicator);
                            }
                            else
                            {
                                // Not having sold class
                                bool oneStepEnrollmentIndicator = unitOfWork.Repository<PlanDesignRequestClassProduct>().Linq()
                                    .Where(x => x.PlanDesignRequestClass.Id == pdrClassId)
                                    .Select(x => x.IsOneStepEnrollmentIndicator)
                                    .FirstOrDefault();
                                pdrClassOseDictionary.Add(pdrClassId, oneStepEnrollmentIndicator);
                            }
                        }
                    }

                    foreach (var censusParticipant in finalCensusParticipantList)
                    {
                        int? pdrClassId = censusParticipant.PlanDesignRequestClass?.Id;
                        
                        // NEW CODE - set OSE indicator from new code above
                        IsOneStepEnrollmentIndicator = pdrClassId.HasValue && pdrClassOseDictionary.ContainsKey(pdrClassId.Value) && pdrClassOseDictionary[pdrClassId.Value];

                        SaveBasePlanAndVGSIBuyUpSolicitation(participantsInfoDto, censusParticipant);
                        censusParticipant.OccupationClass_Id = (participantsInfoDto.OccupationClass_Id != null && participantsInfoDto.OccupationClass_Id != 0) ? participantsInfoDto.OccupationClass_Id : censusParticipant.OccupationClass_Id;
                        censusParticipant.OccupationClassDescription = !string.IsNullOrEmpty(participantsInfoDto.OccupationClassDescription) ? participantsInfoDto.OccupationClassDescription : censusParticipant.OccupationClassDescription;
                        censusParticipant.CLOASOccupationCode = !string.IsNullOrEmpty(participantsInfoDto.CLOASOccupationCode) ? participantsInfoDto.CLOASOccupationCode : censusParticipant.CLOASOccupationCode;
                        censusParticipant.Occupation = !string.IsNullOrEmpty(participantsInfoDto.Occupation) ? participantsInfoDto.Occupation : censusParticipant.Occupation;
                        censusParticipant.GroupLTDClass = (participantsInfoDto.GroupLTDClass != null && participantsInfoDto.GroupLTDClass != 0) ? participantsInfoDto.GroupLTDClass : censusParticipant.GroupLTDClass;
                        censusParticipant.CaseCompanyLocationName = participantsInfoDto.CaseCompanyLocationName ?? censusParticipant.CaseCompanyLocationName;
                        censusParticipant.BenefitDeductionFrequency = participantsInfoDto.BenefitDeductionFrequency_Id != null ? (BenefitDeductionFrequencyTypeEnum?)participantsInfoDto.BenefitDeductionFrequency_Id : censusParticipant.BenefitDeductionFrequency;
                        censusParticipant.BenefitDeductionFrequencyDescription = participantsInfoDto.BenefitDeductionFrequency_Id != null ? ((BenefitDeductionFrequencyTypeEnum?)participantsInfoDto.BenefitDeductionFrequency_Id).GetDescription() : censusParticipant.BenefitDeductionFrequencyDescription;
                        censusParticipant.CustomLTDInsurableIncomeBaseSalaryPercentage = participantsInfoDto.CustomLTDInsurableIncomeBaseSalaryPercentage != null ? participantsInfoDto.CustomLTDInsurableIncomeBaseSalaryPercentage : censusParticipant.CustomLTDInsurableIncomeBaseSalaryPercentage;
                        censusParticipant.CustomLTDInsurableIncomeBonusPercentage = participantsInfoDto.CustomLTDInsurableIncomeBonusPercentage != null ? participantsInfoDto.CustomLTDInsurableIncomeBonusPercentage : censusParticipant.CustomLTDInsurableIncomeBonusPercentage;
                        censusParticipant.CustomLTDInsurableIncomeCommissionPercentage = participantsInfoDto.CustomLTDInsurableIncomeCommissionPercentage != null ? participantsInfoDto.CustomLTDInsurableIncomeCommissionPercentage : censusParticipant.CustomLTDInsurableIncomeCommissionPercentage;
                        censusParticipant.CustomLTDInsurableIncomeOtherIncomePercentage = participantsInfoDto.CustomLTDInsurableIncomeOtherIncomePercentage != null ? participantsInfoDto.CustomLTDInsurableIncomeOtherIncomePercentage : censusParticipant.CustomLTDInsurableIncomeOtherIncomePercentage;
                        censusParticipant.IsSpecialHandlingRequired = participantsInfoDto.IsSpecialHandlingRequired != null ? participantsInfoDto.IsSpecialHandlingRequired : censusParticipant.IsSpecialHandlingRequired;
                        censusParticipant.SpecialHandlingComments = participantsInfoDto.SpecialHandlingComments;
                        censusParticipant.ParticipantCategoryCodeType = participantsInfoDto.ParticipantCategoryCodeTypeId != null ? (ParticipantCategoryCodeTypeEnum?)participantsInfoDto.ParticipantCategoryCodeTypeId : censusParticipant.ParticipantCategoryCodeType;
                        censusParticipant.ParticipantCategoryCodeDescription = participantsInfoDto.ParticipantCategoryCodeTypeId != null ? participantsInfoDto.ParticipantCategoryCodeTypeDescription : censusParticipant.ParticipantCategoryCodeDescription;
                        censusParticipant.BuyUpParticipantCategoryCodeType = participantsInfoDto.BuyUpParticipantCategoryCodeTypeId != null ? (ParticipantCategoryCodeTypeEnum?)participantsInfoDto.BuyUpParticipantCategoryCodeTypeId : censusParticipant.BuyUpParticipantCategoryCodeType;
                        censusParticipant.BuyUpParticipantCategoryCodeDescription = participantsInfoDto.BuyUpParticipantCategoryCodeTypeId != null ? participantsInfoDto.BuyUpParticipantCategoryCodeTypeDescription : censusParticipant.BuyUpParticipantCategoryCodeDescription;
                        censusParticipant.IsPushtoNewProviderChoicePolicyIndicator = participantsInfoDto.IsPushtoNewProviderChoicePolicyIndicator != null ? participantsInfoDto.IsPushtoNewProviderChoicePolicyIndicator : censusParticipant.IsPushtoNewProviderChoicePolicyIndicator;
                        censusParticipant.IsAMBIncreaseIndicator = participantsInfoDto.IsAMBIncreaseIndicator != null ? participantsInfoDto.IsAMBIncreaseIndicator : censusParticipant.IsAMBIncreaseIndicator;
                        censusParticipant.IsBuyUpPushtoNewProviderChoicePolicyIndicator = participantsInfoDto.IsBuyUpPushtoNewProviderChoicePolicyIndicator != null ? participantsInfoDto.IsBuyUpPushtoNewProviderChoicePolicyIndicator : censusParticipant.IsBuyUpPushtoNewProviderChoicePolicyIndicator;
                        censusParticipant.IsBuyUpAMBIncreaseIndicator = participantsInfoDto.IsBuyUpAMBIncreaseIndicator != null ? participantsInfoDto.IsBuyUpAMBIncreaseIndicator : censusParticipant.IsBuyUpAMBIncreaseIndicator;
                        censusParticipant.FrequencyClass = participantsInfoDto.FrequencyClass != null ? participantsInfoDto.FrequencyClass : censusParticipant.FrequencyClass;
                        censusParticipant.Citizenship = participantsInfoDto.Citizenship != null ? participantsInfoDto.Citizenship : censusParticipant.Citizenship;
                        censusParticipant.WeeklyHoursWorked = participantsInfoDto.WeeklyHoursWorked != null ? participantsInfoDto.WeeklyHoursWorked : censusParticipant.WeeklyHoursWorked;
                        censusParticipant.IsMicrositeAccess = participantsInfoDto.IsMicrositeAccess != null ? (bool)participantsInfoDto.IsMicrositeAccess : censusParticipant.IsMicrositeAccess;
                        censusParticipant.Gender = participantsInfoDto.Gender != null ? participantsInfoDto.Gender : censusParticipant.Gender;                        
                        if ((participantsInfoDto.ManualBenefitAmount == null || participantsInfoDto.ManualBenefitAmount.Value == 0) && (participantsInfoDto.ManualBenefitAMBIncreaseAmount == null || participantsInfoDto.ManualBenefitAMBIncreaseAmount.Value == 0))
                        {
                            censusParticipant.ManualBenefitAmount = censusParticipant.ManualBenefitAmount;
                            censusParticipant.ManualBenefitAMBIncreaseAmount = censusParticipant.ManualBenefitAMBIncreaseAmount;
                        }
                        else if (participantsInfoDto.ManualBenefitAmount != null && participantsInfoDto.ManualBenefitAmount.Value != 0)
                        {
                            censusParticipant.ManualBenefitAmount = participantsInfoDto.ManualBenefitAmount;
                            censusParticipant.ManualBenefitAMBIncreaseAmount = 0;
                        }
                        else
                        {
                            censusParticipant.ManualBenefitAmount = 0;
                        }
                        if ((participantsInfoDto.ManualBenefitAmount == null || participantsInfoDto.ManualBenefitAmount.Value == 0) && (participantsInfoDto.ManualBenefitAMBIncreaseAmount == null || participantsInfoDto.ManualBenefitAMBIncreaseAmount.Value == 0))
                        {
                            censusParticipant.ManualBenefitAmount = censusParticipant.ManualBenefitAmount;
                            censusParticipant.ManualBenefitAMBIncreaseAmount = censusParticipant.ManualBenefitAMBIncreaseAmount;
                        }
                        else if (participantsInfoDto.ManualBenefitAMBIncreaseAmount != null && participantsInfoDto.ManualBenefitAMBIncreaseAmount.Value != 0)
                        {
                            censusParticipant.ManualBenefitAMBIncreaseAmount = participantsInfoDto.ManualBenefitAMBIncreaseAmount;
                            censusParticipant.ManualBenefitAmount = 0;

                        }
                        else
                        {
                            censusParticipant.ManualBenefitAMBIncreaseAmount = 0;
                        }
                        if ((participantsInfoDto.ManualRPPAmount == null || participantsInfoDto.ManualRPPAmount.Value == 0) && (participantsInfoDto.ManualRPPAMBIncreaseAmount == null || participantsInfoDto.ManualRPPAMBIncreaseAmount.Value == 0))
                        {
                            censusParticipant.ManualRPPAmount = censusParticipant.ManualRPPAmount;
                            censusParticipant.ManualRPPAMBIncreaseAmount = censusParticipant.ManualRPPAMBIncreaseAmount;
                        }
                        else if (participantsInfoDto.ManualRPPAmount != null && participantsInfoDto.ManualRPPAmount.Value != 0)
                        {
                            censusParticipant.ManualRPPAmount = participantsInfoDto.ManualRPPAmount;
                            censusParticipant.ManualRPPAMBIncreaseAmount = 0;
                        }
                        else
                        {
                            censusParticipant.ManualRPPAmount = 0;
                        }
                        if ((participantsInfoDto.ManualRPPAmount == null || participantsInfoDto.ManualRPPAmount.Value == 0) && (participantsInfoDto.ManualRPPAMBIncreaseAmount == null || participantsInfoDto.ManualRPPAMBIncreaseAmount.Value == 0))
                        {
                            censusParticipant.ManualRPPAmount = censusParticipant.ManualRPPAmount;
                            censusParticipant.ManualRPPAMBIncreaseAmount = censusParticipant.ManualRPPAMBIncreaseAmount;
                        }
                        else if (participantsInfoDto.ManualRPPAMBIncreaseAmount != null && participantsInfoDto.ManualRPPAMBIncreaseAmount.Value != 0)
                        {
                            censusParticipant.ManualRPPAMBIncreaseAmount = participantsInfoDto.ManualRPPAMBIncreaseAmount;
                            censusParticipant.ManualRPPAmount = 0;

                        }
                        else
                        {
                            censusParticipant.ManualRPPAMBIncreaseAmount = 0;
                        }
                        if ((participantsInfoDto.ManualVGSIBuyUpBenefitAmount == null || participantsInfoDto.ManualVGSIBuyUpBenefitAmount.Value == 0) && (participantsInfoDto.ManualVGSIBuyUpAMBIncreaseAmount == null || participantsInfoDto.ManualVGSIBuyUpAMBIncreaseAmount.Value == 0))
                        {
                            censusParticipant.ManualVGSIBuyUpBenefitAmount = censusParticipant.ManualVGSIBuyUpBenefitAmount;
                            censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount = censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount;
                        }
                        else if (participantsInfoDto.ManualVGSIBuyUpBenefitAmount != null && participantsInfoDto.ManualVGSIBuyUpBenefitAmount.Value != 0)
                        {
                            censusParticipant.ManualVGSIBuyUpBenefitAmount = participantsInfoDto.ManualVGSIBuyUpBenefitAmount;
                            censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount = 0;
                        }
                        else
                        {
                            censusParticipant.ManualVGSIBuyUpBenefitAmount = 0;
                        }
                        if ((participantsInfoDto.ManualVGSIBuyUpBenefitAmount == null || participantsInfoDto.ManualVGSIBuyUpBenefitAmount.Value == 0) && (participantsInfoDto.ManualVGSIBuyUpAMBIncreaseAmount == null || participantsInfoDto.ManualVGSIBuyUpAMBIncreaseAmount.Value == 0))
                        {
                            censusParticipant.ManualVGSIBuyUpBenefitAmount = censusParticipant.ManualVGSIBuyUpBenefitAmount;
                            censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount = censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount;
                        }
                        else if (participantsInfoDto.ManualVGSIBuyUpAMBIncreaseAmount != null && participantsInfoDto.ManualVGSIBuyUpAMBIncreaseAmount.Value != 0)
                        {
                            censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount = participantsInfoDto.ManualVGSIBuyUpAMBIncreaseAmount;
                            censusParticipant.ManualVGSIBuyUpBenefitAmount = 0;

                        }
                        else
                        {
                            censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount = 0;
                        }

                        if (IsOneStepEnrollmentIndicator)
                        {
                            if (censusParticipant.WeeklyHoursWorked > 0 && censusParticipant.WeeklyHoursWorked < 30)
                            {
                                censusParticipant.AAW = false;
                            }
                            else if (censusParticipant.WeeklyHoursWorked >= 30)
                            {
                                censusParticipant.AAW = true;
                            }
                            else
                            {
                                censusParticipant.AAW = participantsInfoDto.AAW != null ? participantsInfoDto.AAW : censusParticipant.AAW;
                                censusParticipant.WeeklyHoursWorked = null;
                            }
                        }
                        else
                        {
                            censusParticipant.AAW = participantsInfoDto.AAW != null ? participantsInfoDto.AAW : censusParticipant.AAW;
                        }

                        if (participantsInfoDto.RemoveManualBenefitAmount == true)
                        {
                            censusParticipant.ManualBenefitAmount = null;
                        }

                        if (participantsInfoDto.RemoveManualVGSIBenefitAmount == true)
                        {
                            censusParticipant.ManualVGSIBuyUpBenefitAmount = null;
                        }
                        if (participantsInfoDto.RemoveManualBenefitAMBIncreaseAmount == true)
                        {
                            censusParticipant.ManualBenefitAMBIncreaseAmount = null;
                        }
                        if (participantsInfoDto.RemoveManualVGSIBuyUpAMBIncreaseAmount == true)
                        {
                            censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount = null;
                        }
                        if (participantsInfoDto.RemoveManualRPPAmount == true)
                        {
                            censusParticipant.ManualRPPAmount = null;
                        }
                        if (participantsInfoDto.RemoveManualRPPAMBIncreaseAmount == true)
                        {
                            censusParticipant.ManualRPPAMBIncreaseAmount = null;
                        }


                        if (participantsInfoDto.RemoveCustomLTDBaseSalaryPercentage == true)
                        {
                            censusParticipant.CustomLTDInsurableIncomeBaseSalaryPercentage = null;
                        }

                        if (participantsInfoDto.RemoveCustomLTDBonusPercentage == true)
                        {
                            censusParticipant.CustomLTDInsurableIncomeBonusPercentage = null;
                        }

                        if (participantsInfoDto.RemoveCustomLTDCommissionPercentage == true)
                        {
                            censusParticipant.CustomLTDInsurableIncomeCommissionPercentage = null;
                        }

                        if (participantsInfoDto.RemoveCustomLTDOtherIncomePercentage == true)
                        {
                            censusParticipant.CustomLTDInsurableIncomeOtherIncomePercentage = null;
                        }

                        if (participantsInfoDto.RemoveManualBenefitAmount == true && participantsInfoDto.RemoveManualVGSIBenefitAmount == true
                            && participantsInfoDto.RemoveManualBenefitAMBIncreaseAmount == true && participantsInfoDto.RemoveManualVGSIBuyUpAMBIncreaseAmount == true
                            && participantsInfoDto.RemoveManualRPPAmount == true && participantsInfoDto.RemoveManualRPPAMBIncreaseAmount == true
                           && participantsInfoDto.RemoveCustomLTDBaseSalaryPercentage == true && participantsInfoDto.RemoveCustomLTDBonusPercentage == true
                           && participantsInfoDto.RemoveCustomLTDCommissionPercentage == true && participantsInfoDto.RemoveCustomLTDOtherIncomePercentage == true)
                        {
                            censusParticipant.ManualOverride = false;
                        }
                        if (censusParticipant.ManualBenefitAmount > 0 || censusParticipant.ManualVGSIBuyUpBenefitAmount > 0
                            || censusParticipant.ManualBenefitAMBIncreaseAmount > 0 || censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount > 0
                            || censusParticipant.ManualRPPAmount > 0 || censusParticipant.ManualRPPAMBIncreaseAmount > 0
                            || censusParticipant.CustomLTDInsurableIncomeBaseSalaryPercentage > 0 || censusParticipant.CustomLTDInsurableIncomeBonusPercentage > 0
                            || censusParticipant.CustomLTDInsurableIncomeCommissionPercentage > 0 || censusParticipant.CustomLTDInsurableIncomeOtherIncomePercentage > 0)
                        {
                            censusParticipant.ManualOverride = true;
                        }
                        else { censusParticipant.ManualOverride = false; }

                        if (participantsInfoDto.IDICarrierID1 != null)
                        {
                            censusParticipant.IDICarrier1 = (IDICoverageCarrierTypeEnum?)participantsInfoDto.IDICarrierID1;
                            censusParticipant.IDICarrier1Description = participantsInfoDto.IDICarrierID1 != null ? ((IDICoverageCarrierTypeEnum?)participantsInfoDto.IDICarrierID1).GetDescription() : string.Empty;
                        }
                        if (participantsInfoDto.PremiumPayerId1 != null)
                        {
                            censusParticipant.PremiumPayerId1 = participantsInfoDto.PremiumPayerId1;
                        }
                        if (participantsInfoDto.ReplacementPercent1 != null)
                        {
                            censusParticipant.ReplacementPercent1 = participantsInfoDto.ReplacementPercent1;
                        }
                        if (participantsInfoDto.IDIBenefitAmount1 != null)
                        {
                            censusParticipant.IDIBenefitAmount1 = participantsInfoDto.IDIBenefitAmount1;
                        }
                        if (participantsInfoDto.IDIToBeReplaced1 != null && participantsInfoDto.IDIToBeReplaced1 == true)
                        {
                            censusParticipant.IDIToBeReplaced1 = participantsInfoDto.IDIToBeReplaced1;
                        }

                        if (censusParticipant.ReplacementPercent1 != null)
                        {
                            censusParticipant.IDIToBeReplacedAmount1 = ((censusParticipant.ReplacementPercent1 ?? 0) * (censusParticipant.IDIBenefitAmount1 ?? 0)) / 100;
                        }


                        var enrollmentParticipantList = censusParticipant.EnrollmentCensusParticipants.ToList();
                        if (enrollmentParticipantList != null && enrollmentParticipantList.Any())
                        {
                            var enrollmentParticipant = enrollmentParticipantList.OrderByDescending(x => x.Enrollment.Id).First();

                            var enrollmentParticipantDto = new EditEnrollmentParticipantDto();
                            enrollmentParticipantDto.EnrollmentParticipant_Id = enrollmentParticipant.Id;
                            if (participantsInfoDto.BasePlanDeclinedCoverage == true)
                            {
                                enrollmentParticipant.BasePlanEnrollmentParticipantStatusType = EnrollmentParticipantStatusTypeEnum.Declined;
                                enrollmentParticipantDto.BasePlanEnrollmentParticipantStatusType_Id = (int)EnrollmentParticipantStatusTypeEnum.Declined;
                            }
                            else
                            {
                                enrollmentParticipant.BasePlanEnrollmentParticipantStatusType = null;
                            }
                            if (participantsInfoDto.VGSIBuyUpPlanDeclinedCoverage == true)
                            {
                                enrollmentParticipant.VGSIPlanEnrollmentParticipantStatusType = EnrollmentParticipantStatusTypeEnum.Declined;
                                enrollmentParticipantDto.VGSIPlanEnrollmentParticipantStatusType_Id = (int)EnrollmentParticipantStatusTypeEnum.Declined;
                            }
                            else
                            {
                                enrollmentParticipant.VGSIPlanEnrollmentParticipantStatusType = null;
                            }
                            enrollmentParticipantsDto.Add(enrollmentParticipantDto);
                        }

                        if (censusParticipant.PlanDesignRequestClass != null)
                        {
                            CalculateAmountsForParticipant(censusParticipant, null);
                        }

                        if (participantsInfoDto.IsEligible != null && participantsInfoDto.IsEligible == true)
                        {
                            censusParticipant.IsError = false;
                            censusParticipant.ErrorReason = null;
                        }
                        else if (participantsInfoDto.IsIncludePartialMatchPriorCoverage != null)
                        {
                            censusParticipant.IsError = false;
                            censusParticipant.ErrorReason = null;
                            censusParticipant.IsPushtoNewProviderChoicePolicyIndicator = participantsInfoDto.IsIncludePartialMatchPriorCoverage == true ? true : false;
                        }
                    }

                    var participantsDto = finalCensusParticipantList.Select(p => new EditParticipantDto
                    {
                        Participant_Id = p.Id,
                        OccupationClass_Id = p.OccupationClass_Id,
                        OccupationClassDescription = p.OccupationClassDescription,
                        CLOASOccupationCode = p.CLOASOccupationCode,
                        Occupation = p.Occupation,
                        GroupLTDClass = p.GroupLTDClass,
                        CaseCompanyLocationName = p.CaseCompanyLocationName,
                        ManualBenefitAmount = p.ManualBenefitAmount,
                        IsEligible = p.IsEligible,
                        InEligibleReason_Id = p.InEligibleReason_Id,
                        IneligibleReason = p.IneligibleReason,
                        OtherReason = p.OtherReason,
                        IsError = p.IsError,
                        ErrorReason = p.ErrorReason,
                        CustomLTDInsurableIncomeBaseSalaryPercentage = p.CustomLTDInsurableIncomeBaseSalaryPercentage,
                        CustomLTDInsurableIncomeBonusPercentage = p.CustomLTDInsurableIncomeBonusPercentage,
                        CustomLTDInsurableIncomeCommissionPercentage = p.CustomLTDInsurableIncomeCommissionPercentage,
                        CustomLTDInsurableIncomeOtherIncomePercentage = p.CustomLTDInsurableIncomeOtherIncomePercentage,
                        IDIToBeReplaced1 = p.IDIToBeReplaced1,
                        IDICarrier1_Id = (int?)p.IDICarrier1,
                        IDIPolicyNumber1 = p.IDIPolicyNumber1,
                        IDICarrier1Description = p.IDICarrier1Description,
                        PremiumPayerId1 = p.PremiumPayerId1,
                        ReplacementPercent1 = p.ReplacementPercent1,
                        IDIBenefitAmount1 = p.IDIBenefitAmount1,
                        IDIToBeReplacedAmount1 = p.IDIToBeReplacedAmount1,
                        IDIToBeReplaced2 = p.IDIToBeReplaced2,
                        IDICarrier2_Id = (int?)p.IDICarrier2,
                        IDIPolicyNumber2 = p.IDIPolicyNumber2,
                        IDICarrier2Description = p.IDICarrier2Description,
                        PremiumPayerId2 = p.PremiumPayerId2,
                        ReplacementPercent2 = p.ReplacementPercent2,
                        IDIBenefitAmount2 = p.IDIBenefitAmount2,
                        IDIToBeReplacedAmount2 = p.IDIToBeReplacedAmount2,
                        IDIToBeReplaced3 = p.IDIToBeReplaced3,
                        IDICarrier3_Id = (int?)p.IDICarrier3,
                        IDIPolicyNumber3 = p.IDIPolicyNumber3,
                        IDICarrier3Description = p.IDICarrier3Description,
                        PremiumPayerId3 = p.PremiumPayerId3,
                        ReplacementPercent3 = p.ReplacementPercent3,
                        IDIBenefitAmount3 = p.IDIBenefitAmount3,
                        IDIToBeReplacedAmount3 = p.IDIToBeReplacedAmount3,
                        IDIToBeReplaced4 = p.IDIToBeReplaced4,
                        IDICarrier4_Id = (int?)p.IDICarrier4,
                        IDIPolicyNumber4 = p.IDIPolicyNumber4,
                        IDICarrier4Description = p.IDICarrier4Description,
                        PremiumPayerId4 = p.PremiumPayerId4,
                        ReplacementPercent4 = p.ReplacementPercent4,
                        IDIBenefitAmount4 = p.IDIBenefitAmount4,
                        IDIToBeReplacedAmount4 = p.IDIToBeReplacedAmount4,
                        BasePlanPreviousSolicitations = p.BasePlanPreviousSolicitations,
                        VGSIPlanPreviousSolicitations = p.VGSIPlanPreviousSolicitations,
                        LTDInsurableIncomeCalculatedAmount = p.LTDInsurableIncomeCalculatedAmount,
                        IDIInsurableIncomeCalculatedAmount = p.IDIInsurableIncomeCalculatedAmount,
                        LTDCalculatedAmount = p.LTDCalculatedAmount,
                        VGSIBuyUpIDIInsurableIncomeCalculatedAmount = p.VGSIBuyUpIDIInsurableIncomeCalculatedAmount,
                        OtherExistingIDICoverageTotalCalculatedAmount = p.OtherExistingIDICoverageTotalCalculatedAmount,
                        GuardianExistingIDICoverageTotalCalculatedAmount = p.GuardianExistingIDICoverageTotalCalculatedAmount,
                        TotalEmployerOrEmployeeRetirementContributionCalculatedAmount = p.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount,
                        VoluntaryGSIBuyUpCalculatedAmount = p.VoluntaryGSIBuyUpCalculatedAmount,
                        IssueAge = p.IssueAge,
                        EligibleCATCalculatedAmount = p.EligibleCATCalculatedAmount,
                        IDIBaseSalaryCalculatedAmount = p.IDIBaseSalaryCalculatedAmount,
                        IDIBonusIncomeCalculatedAmount = p.IDIBonusIncomeCalculatedAmount,
                        IDICommissionsIncomeCalculatedAmount = p.IDICommissionsIncomeCalculatedAmount,
                        IDIK1IncomeCalculatedAmount = p.IDIK1IncomeCalculatedAmount,
                        IDIOtherIncomeCalculatedAmount = p.IDIOtherIncomeCalculatedAmount,
                        GLTDBenefitCalculatedAmount = p.GLTDBenefitCalculatedAmount,
                        GLTDReplacementCalculatedPercentage = p.GLTDReplacementCalculatedPercentage,
                        ExistingIDICalculatedAmount = p.ExistingIDICalculatedAmount,
                        GSIBaseCalculatedAmount = p.GSIBaseCalculatedAmount,
                        IDIBaseReplacementCalculatedPercentage = p.IDIBaseReplacementCalculatedPercentage,
                        IDIReplacementCalculatedPercent = p.IDIReplacementCalculatedPercent,
                        TotalGLTDPlusIDICalculatedAmount = p.TotalGLTDPlusIDICalculatedAmount,
                        TotalGLTDPlusIDICalculatedPercentage = p.TotalGLTDPlusIDICalculatedPercentage,
                        CATCalculatedAmount = p.CATCalculatedAmount,
                        RPPBenefitCalculatedAmount = p.RPPBenefitCalculatedAmount,
                        CoveragePossibleBeforeIandPMaximums = p.CoveragePossibleBeforeIandPMaximums,
                        ParticipationLimitMaximum = p.ParticipationLimitMaximum,
                        IssueLimitMaximum = p.IssueLimitMaximum,
                        VGSIBuyUpCoveragePossibleBeforeIandPMaximums = p.VGSIBuyUpCoveragePossibleBeforeIandPMaximums,
                        VGSIParticipationLimitMaximum = p.VGSIParticipationLimitMaximum,
                        VGSIBuyUpBenefit = p.VGSIBuyUpBenefit,
                        ContractState_Id = (int?)p.ContractState,
                        ContractStateDescription = p.ContractStateDescription,
                        BenefitDeductionFrequency_Id = p.BenefitDeductionFrequency != null ? (int?)p.BenefitDeductionFrequency : null,
                        BenefitDeductionFrequencyDescription = p.BenefitDeductionFrequencyDescription,
                        ManualVGSIBuyUpBenefitAmount = p.ManualVGSIBuyUpBenefitAmount,
                        IsSpecialHandlingRequired = p.IsSpecialHandlingRequired,
                        SpecialHandlingComments = p.SpecialHandlingComments,
                        BaseAMBCalculatedAmount = p.BaseAMBCalculatedAmount,
                        VGSIBuyUpAMBCalculatedAmount = p.VGSIBuyUpAMBCalculatedAmount,
                        RPPAMBCalculatedAmount = p.RPPAMBCalculatedAmount,
                        ParticipantCategoryCodeTypeId = p.ParticipantCategoryCodeType != null ? (int?)p.ParticipantCategoryCodeType : null,
                        ParticipantCategoryCodeTypeDescription = p.ParticipantCategoryCodeDescription,
                        BuyUpParticipantCategoryCodeTypeId = p.BuyUpParticipantCategoryCodeType != null ? (int?)p.BuyUpParticipantCategoryCodeType : null,
                        BuyUpParticipantCategoryCodeTypeDescription = p.BuyUpParticipantCategoryCodeDescription,
                        IsPushtoNewProviderChoicePolicyIndicator = p.IsPushtoNewProviderChoicePolicyIndicator,
                        IsAMBIncreaseIndicator = p.IsAMBIncreaseIndicator,
                        IsBuyUpPushtoNewProviderChoicePolicyIndicator = p.IsBuyUpPushtoNewProviderChoicePolicyIndicator,
                        IsBuyUpAMBIncreaseIndicator = p.IsBuyUpAMBIncreaseIndicator,
                        FrequencyClass = p.FrequencyClass,
                        ManualOverride = p.ManualOverride,
                        AAW = p.AAW,
                        Citizenship = p.Citizenship,
                        HoursWorked = p.WeeklyHoursWorked,
                        IsMicrositeAccess = p.IsMicrositeAccess,
                        Gender = p.Gender,
                        ManualRPPAmount = p.ManualRPPAmount,
                        ManualBenefitAMBIncreaseAmount = p.ManualBenefitAMBIncreaseAmount,
                        ManualRPPAMBIncreaseAmount = p.ManualRPPAMBIncreaseAmount,
                        ManualVGSIBuyUpAMBIncreaseAmount = p.ManualVGSIBuyUpAMBIncreaseAmount,

                    }).ToList();

                    SaveEditedParticipantsToDatabase(participantsDto, enrollmentParticipantsDto);

                    partialPolicyMatchParicipantIds = finalCensusParticipantList.Where(p => p.ParticipantExistingPolicies.Any(pep => pep.ParticipantExistingPolicyDetails.Any(pepd => pepd.IsPolicyMatch == false))).Select(p => p.Id).ToList();

                    inForceCoveragePolicyMatchParicipantIds = finalCensusParticipantList.Where(p => p.ParticipantExistingPolicies.Any(pep => pep.ParticipantExistingPolicyDetails.Any(pepd => pepd.IsPolicyMatch == true))).Select(p => p.Id).ToList();

                }

                if (partialPolicyMatchParicipantIds.Any())
                {
                    if (participantsInfoDto.IsIncludePartialMatchPriorCoverage == false)
                    {
                        RemovePartialMatchPriorCoverages(partialPolicyMatchParicipantIds);
                    }
                }

                if (inForceCoveragePolicyMatchParicipantIds.Any())
                {
                    if (participantsInfoDto.IsRemoveAllInforcePolicy == true)
                    {
                        RemovePartialMatchPriorCoverages(inForceCoveragePolicyMatchParicipantIds, true);
                    }
                }
                if (participantsInfoDto.IsTerminateAndReplace && !inForceCoveragePolicyMatchParicipantIds.Any())
                {
                    BulkEditTerminateAndReplace(selectedCensusParticipantsIds);
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error in saving the edit multiple participants", ex);
            }
            Log.TraceFormat("-SaveEditMultipleParticipantsInfo");
        }

        private void BulkEditTerminateAndReplace(List<int> selectedCensusParticipantsIds)
        {
            Log.TraceFormat("+BulkEditTerminateAndReplace");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var participants = unitOfWork.Repository<Participant>().Linq().Where(p => selectedCensusParticipantsIds.Contains(p.Id)).ToList();
                foreach (var participant in participants)
                {
                    var participantExistingPolicy = participant.ParticipantExistingPolicies.FirstOrDefault();
                    if (participantExistingPolicy != null)
                    {
                        var policyDetails = participantExistingPolicy.ParticipantExistingPolicyDetails.ToList();
                        if (policyDetails.Any())
                        {
                            policyDetails.Select(p => { p.IsTerminateAndReplace = true; return p; }).ToList();

                            if (participant.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
                            {
                                participant.IDIToBeReplacedAmount1 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                            }
                            else if (participant.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
                            {
                                participant.IDIToBeReplacedAmount2 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                            }
                            else if (participant.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
                            {
                                participant.IDIToBeReplacedAmount3 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                            }
                            else if (participant.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
                            {
                                participant.IDIToBeReplacedAmount4 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                            }

                            participantExistingPolicy.GSIIDIBaseAMB = 0;
                            participantExistingPolicy.GSIRPPBaseAMB = 0;
                            participantExistingPolicy.FullyUnderwrittenIDI = 0;
                            participantExistingPolicy.FullyUnderwrittenRPP = 0;

                            participant.IsPushtoNewProviderChoicePolicyIndicator = false;
                            participant.IsAMBIncreaseIndicator = false;
                        }
                        unitOfWork.Repository<Participant>().Save(participant);
                    }
                }
                unitOfWork.Commit();
            }
            Log.TraceFormat("-BulkEditTerminateAndReplace");
        }



        private void SaveBasePlanAndVGSIBuyUpSolicitation(CensusParticipantDto participantsInfoDto, Participant censusParticipant)
        {
            if (participantsInfoDto.IsEligible != null && participantsInfoDto.IsEligible == false)
            {               
                if (participantsInfoDto.InEligibleReason_Id == (int?)InEligibleReasonTypeEnum.NoLongerInGroup)
                {
                    censusParticipant.BasePlanPreviousSolicitations = 0;
                    censusParticipant.VGSIPlanPreviousSolicitations = 0;
                }
                else
                {
                    censusParticipant.BasePlanPreviousSolicitations = (participantsInfoDto.BasePlanPreviousSolicitations == 0 || participantsInfoDto.BasePlanPreviousSolicitations == null) ? censusParticipant.BasePlanPreviousSolicitations : participantsInfoDto.BasePlanPreviousSolicitations;
                    censusParticipant.VGSIPlanPreviousSolicitations = (participantsInfoDto.VGSIPlanPreviousSolicitations == 0 || participantsInfoDto.VGSIPlanPreviousSolicitations == null) ? censusParticipant.VGSIPlanPreviousSolicitations : participantsInfoDto.VGSIPlanPreviousSolicitations;
                }
            }
            else
            {
                if (censusParticipant.InEligibleReason_Id == (int?)InEligibleReasonTypeEnum.NoLongerInGroup)
                {
                    censusParticipant.BasePlanPreviousSolicitations = 0;
                    censusParticipant.VGSIPlanPreviousSolicitations = 0;
                }
                else
                {
                    censusParticipant.BasePlanPreviousSolicitations = (participantsInfoDto.BasePlanPreviousSolicitations == null) ? censusParticipant.BasePlanPreviousSolicitations : participantsInfoDto.BasePlanPreviousSolicitations;
                    censusParticipant.VGSIPlanPreviousSolicitations = (participantsInfoDto.VGSIPlanPreviousSolicitations == null) ? censusParticipant.VGSIPlanPreviousSolicitations : participantsInfoDto.VGSIPlanPreviousSolicitations;
                } 
            }

            censusParticipant.IsError = false;
            censusParticipant.ErrorReason = null;
            censusParticipant.IsEligible = participantsInfoDto.IsEligible != null ? participantsInfoDto.IsEligible : censusParticipant.IsEligible;

            if (censusParticipant.IsEligible.HasValue && censusParticipant.IsEligible == false)
            {
                censusParticipant.InEligibleReason_Id = participantsInfoDto.InEligibleReason_Id != null ? participantsInfoDto.InEligibleReason_Id : censusParticipant.InEligibleReason_Id;
                censusParticipant.IneligibleReason = participantsInfoDto.IneligibleReason != null ? participantsInfoDto.IneligibleReason : censusParticipant.IneligibleReason;
                censusParticipant.OtherReason = participantsInfoDto.OtherReason != null ? participantsInfoDto.OtherReason : censusParticipant.OtherReason;
            }
            else
            {
                censusParticipant.InEligibleReason_Id = -1;
                censusParticipant.IneligibleReason = null;
                censusParticipant.OtherReason = null;
            }
        }

        public void SaveParticipantInformation(CensusParticipantDto participantInformationDto)
        {
            Log.TraceFormat("+SaveParticipantInformation");

            _censusManagerValidator.ValidateEditCensusInformation(participantInformationDto);

            var censusParticipantId = new List<int> { participantInformationDto.CensusParticipantId };

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                try
                {
                    var participant = unitOfWork.Repository<Participant>().Linq().FirstOrDefault(c => c.Id == participantInformationDto.CensusParticipantId);
                    if (participant != null)
                    {
                        var planDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == participantInformationDto.PlanDesignRequestClassId);
                        if (planDesignRequestClass != null)
                        {
                            participant.PlanDesignRequestClass = planDesignRequestClass;
                            participant.PlanDesignRequestClassEligiblePopulationText = participantInformationDto.PlanDesignRequestClassEligiblePopulationText;
                            var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequestClass.Id == participantInformationDto.PlanDesignRequestClassId).FirstOrDefault();
                            if (pdrSoldClass != null)
                            {
                                var pdrSoldClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(c => c.PDRSoldClass.Id == pdrSoldClass.Id).FirstOrDefault();
                                IsOneStepEnrollmentIndicator = pdrSoldClassPlan.IsOneStepEnrollmentIndicator;
                            }
                            else
                            {
                                IsOneStepEnrollmentIndicator = unitOfWork.Repository<PlanDesignRequestClassProduct>().Linq().Where(c => c.PlanDesignRequestClass.Id == participantInformationDto.PlanDesignRequestClassId).Select(c => c.IsOneStepEnrollmentIndicator).FirstOrDefault();
                            }
                        }

                        // NBTAB-3990: make sure if participant data is change after an MLDE offer is sent, then mark the participant as 'dirty' to display warning in Enrollment Participant table on Implementation tab
                        if (participant.FirstName != participantInformationDto.FirstName ||
                            participant.LastName != participantInformationDto.LastName ||
                            participant.DateOfBirth != participantInformationDto.DateOfBirth ||
                            participant.WorkEmail != participantInformationDto.WorkEmail)
                        {
                            // Data has changed, check the database for an MLDE enrollment and grab most recent one
                            var mldeEnrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                .Where(x =>
                                    x.Participant != null &&
                                    x.Participant.Id == participant.Id &&
                                    x.MldeUploadStatusType != null &&
                                    x.MldeStatusType != null && (x.Enrollment.IsActive == null || x.Enrollment.IsActive == true)
                                    )
                                .OrderByDescending(x => x.Enrollment.Id)
                                .FirstOrDefault();
                            if (mldeEnrollmentParticipant != null)
                            {
                                // Flag enrollment participant as dirty
                                mldeEnrollmentParticipant.MLDEParticipantDirtyDataIndicator = true;
                                unitOfWork.Repository<EnrollmentParticipant>().Save(mldeEnrollmentParticipant);
                            }
                        }

                        participant.EmployeeId = participantInformationDto.EmployeeId;
                        participant.ClientReferenceNumber = participantInformationDto.ClientReferenceNumber;
                        participant.FirstName = participantInformationDto.FirstName;
                        participant.LastName = participantInformationDto.LastName;
                        participant.MiddleInitial = participantInformationDto.MiddleInitial;
                        participant.Suffix = participantInformationDto.Suffix;
                        participant.Age = participantInformationDto.Age;
                        participant.DateOfHire = participantInformationDto.DateOfHire;
                        participant.DateOfBirth = participantInformationDto.DateOfBirth;
                        participant.Gender = participantInformationDto.Gender != null ? participantInformationDto.Gender.ToUpper() : "";
                        participant.JobTitle = participantInformationDto.JobTitle;
                        participant.BoardCertification = participantInformationDto.BoardCertification;
                        participant.OccupationClass_Id = participantInformationDto.OccupationClass_Id;
                        participant.OccupationClassDescription = participantInformationDto.OccupationClassDescription;
                        participant.Occupation = participantInformationDto.Occupation;
                        participant.CLOASOccupationCode = participantInformationDto.CLOASOccupationCode;
                        participant.EmploymentStatus = participantInformationDto.EmploymentStatus;
                        participant.EmploymentStatusType = (EmploymentStatusTypeEnum?)participantInformationDto.EmploymentStatusId;
                        participant.TerminationDate = (EmploymentStatusTypeEnum?)participantInformationDto.EmploymentStatusId == EmploymentStatusTypeEnum.Terminated ? participantInformationDto.TerminationDate : null;
                        //participant.WeeklyHoursWorked = participantInformationDto.WeeklyHoursWorked;
                        participant.PersonalEmail = participantInformationDto.PersonalEmail;
                        participant.CellPhone = participantInformationDto.CellPhone;
                        participant.HomePhone = participantInformationDto.HomePhone;
                        participant.HomeStreet1 = participantInformationDto.HomeStreet1;
                        participant.HomeStreet2 = participantInformationDto.HomeStreet2;
                        participant.HomeCity = participantInformationDto.HomeCity;
                        participant.HomeState = (StateTypeEnum?)participantInformationDto.HomeStateId;
                        participant.HomeStateDescription = ((StateTypeEnum?)participantInformationDto.HomeStateId) != null ? ((StateTypeEnum?)participantInformationDto.HomeStateId).GetCode() : string.Empty;
                        participant.HomeZipCode = participantInformationDto.HomeZipCode;

                        participant.WorkStreet1 = participantInformationDto.WorkStreet1;
                        participant.WorkStreet2 = participantInformationDto.WorkStreet2;
                        participant.WorkCity = participantInformationDto.WorkCity;
                        participant.WorkState = (StateTypeEnum?)participantInformationDto.WorkStateId;
                        participant.WorkStateDescription = ((StateTypeEnum?)participantInformationDto.WorkStateId) != null ? ((StateTypeEnum?)participantInformationDto.WorkStateId).GetCode() : string.Empty;
                        participant.WorkZipCode = participantInformationDto.WorkZipCode;
                        participant.WorkStopCode = participantInformationDto.WorkStopCode;
                        participant.WorkLocationExtension = participantInformationDto.WorkLocationExtension;
                        participant.WorkLocationPhone = participantInformationDto.WorkLocationPhone;
                        participant.WorkEmail = participantInformationDto.WorkEmail;

                        participant.BenefitDeductionFrequency = participantInformationDto.BenefitDeductionFrequency_Id != null ? (BenefitDeductionFrequencyTypeEnum?)participantInformationDto.BenefitDeductionFrequency_Id : null;
                        participant.BenefitDeductionFrequencyDescription = participantInformationDto.BenefitDeductionFrequencyDescription;
                        participant.FrequencyClass = participantInformationDto.FrequencyClass;
                        participant.GroupLTDClass = participantInformationDto.GroupLTDClass;
                        participant.MostRecentSalaryAmount = participantInformationDto.MostRecentSalaryAmount;
                        participant.IDICarrier1 = (IDICoverageCarrierTypeEnum?)participantInformationDto.IDICarrierID1;
                        participant.IDICarrier2 = (IDICoverageCarrierTypeEnum?)participantInformationDto.IDICarrierID2;
                        participant.IDICarrier3 = (IDICoverageCarrierTypeEnum?)participantInformationDto.IDICarrierID3;
                        participant.IDICarrier4 = (IDICoverageCarrierTypeEnum?)participantInformationDto.IDICarrierID4;
                        participant.IDICarrier1Description = participantInformationDto.IDICarrier1Description;
                        participant.IDICarrier2Description = participantInformationDto.IDICarrier2Description;
                        participant.IDICarrier3Description = participantInformationDto.IDICarrier3Description;
                        participant.IDICarrier4Description = participantInformationDto.IDICarrier4Description;
                        participant.IDIBenefitAmount1 = participantInformationDto.IDIBenefitAmount1;
                        participant.IDIBenefitAmount2 = participantInformationDto.IDIBenefitAmount2;
                        participant.IDIBenefitAmount3 = participantInformationDto.IDIBenefitAmount3;
                        participant.IDIBenefitAmount4 = participantInformationDto.IDIBenefitAmount4;
                        participant.IDIToBeReplaced1 = participantInformationDto.IDIToBeReplaced1;
                        participant.IDIToBeReplaced2 = participantInformationDto.IDIToBeReplaced2;
                        participant.IDIToBeReplaced3 = participantInformationDto.IDIToBeReplaced3;
                        participant.IDIToBeReplaced4 = participantInformationDto.IDIToBeReplaced4;
                        participant.IDIToBeReplacedAmount1 = participantInformationDto.IDIToBeReplacedAmount1;
                        participant.IDIToBeReplacedAmount2 = participantInformationDto.IDIToBeReplacedAmount2;
                        participant.IDIToBeReplacedAmount3 = participantInformationDto.IDIToBeReplacedAmount3;
                        participant.IDIToBeReplacedAmount4 = participantInformationDto.IDIToBeReplacedAmount4;
                        participant.PremiumPayerId1 = participantInformationDto.PremiumPayerId1;
                        participant.PremiumPayerId2 = participantInformationDto.PremiumPayerId2;
                        participant.PremiumPayerId3 = participantInformationDto.PremiumPayerId3;
                        participant.PremiumPayerId4 = participantInformationDto.PremiumPayerId4;
                        participant.IDIPolicyNumber1 = participantInformationDto.IDIPolicyNumber1;
                        participant.IDIPolicyNumber2 = participantInformationDto.IDIPolicyNumber2;
                        participant.IDIPolicyNumber3 = participantInformationDto.IDIPolicyNumber3;
                        participant.IDIPolicyNumber4 = participantInformationDto.IDIPolicyNumber4;

                        participant.MostRecentPaidBonusAmount = participantInformationDto.MostRecentPaidBonusAmount;
                        participant.PriorPaidBonusAmount = participantInformationDto.PriorPaidBonusAmount;
                        participant.AdditionalPriorPaidBonusAmount = participantInformationDto.AdditionalPriorPaidBonusAmount;
                        participant.MostRecentPaidCommissionAmount = participantInformationDto.MostRecentPaidCommissionAmount;
                        participant.PriorPaidCommissionAmount = participantInformationDto.PriorPaidCommissionAmount;
                        participant.AdditionalPriorPaidCommissionAmount = participantInformationDto.AdditionalPriorPaidCommissionAmount;
                        participant.MostRecentPaidK1IncomeAmount = participantInformationDto.MostRecentPaidK1IncomeAmount;
                        participant.PriorPaidK1IncomeAmount = participantInformationDto.PriorPaidK1IncomeAmount;
                        participant.AdditionalPriorPaidK1IncomeAmount = participantInformationDto.AdditionalPriorPaidK1IncomeAmount;
                        participant.OtherIncomeAmount = participantInformationDto.OtherIncomeAmount;
                        participant.TypeOfIncome = participantInformationDto.TypeOfIncome;
                        participant.ManualBenefitAmount = participantInformationDto.ManualBenefitAmount;
                        participant.TotalEmployerOrEmployeeRetirementContributionAmount = participantInformationDto.TotalEmployerOrEmployeeRetirementContributionAmount;

                        participant.MostRecentPaidBonusYear = participantInformationDto.MostRecentPaidBonusYear;
                        participant.PriorPaidBonusYear = participantInformationDto.PriorPaidBonusYear;
                        participant.AdditionalPriorPaidBonusYear = participantInformationDto.AdditionalPriorPaidBonusYear;

                        participant.MostRecentPaidCommissionYear = participantInformationDto.MostRecentPaidCommissionYear;
                        participant.PriorPaidCommissionYear = participantInformationDto.PriorPaidCommissionYear;
                        participant.AdditionalPriorPaidCommissionYear = participantInformationDto.AdditionalPriorPaidCommissionYear;

                        participant.MostRecentPaidK1IncomeYear = participantInformationDto.MostRecentPaidK1IncomeYear;
                        participant.PriorPaidK1IncomeYear = participantInformationDto.PriorPaidK1IncomeYear;
                        participant.AdditionalPriorPaidK1IncomeYear = participantInformationDto.AdditionalPriorPaidK1IncomeYear;

                        participant.ReplacementPercent1 = participantInformationDto.ReplacementPercent1;
                        participant.ReplacementPercent2 = participantInformationDto.ReplacementPercent2;
                        participant.ReplacementPercent3 = participantInformationDto.ReplacementPercent3;
                        participant.ReplacementPercent4 = participantInformationDto.ReplacementPercent4;

                        participant.BasePlanPreviousSolicitations = participantInformationDto.BasePlanPreviousSolicitations;
                        participant.VGSIPlanPreviousSolicitations = participantInformationDto.VGSIPlanPreviousSolicitations;

                        participant.OtherDisabilityInformation = participantInformationDto.OtherDisabilityInformation;
                        participant.MostRecentYearPaidW2Income = participantInformationDto.MostRecentYearPaidW2Income;
                        participant.AdditionalInfo1 = participantInformationDto.AdditionalInfo1;
                        participant.AdditionalInfo2 = participantInformationDto.AdditionalInfo2;
                        participant.IsSpecialHandlingRequired = participantInformationDto.IsSpecialHandlingRequired;
                        participant.SpecialHandlingComments = participantInformationDto.SpecialHandlingComments;
                        participant.ManualVGSIBuyUpBenefitAmount = participantInformationDto.ManualVGSIBuyUpBenefitAmount;
                        participant.IsOwnerIndicator = participantInformationDto.IsOwnerIndicator;
                        participant.CaseCompanyLocationName = participantInformationDto.CaseCompanyLocationName;
                        participant.ParticipantCategoryCodeType = participantInformationDto.ParticipantCategoryCodeTypeId != null ? (ParticipantCategoryCodeTypeEnum?)participantInformationDto.ParticipantCategoryCodeTypeId : null;
                        participant.ParticipantCategoryCodeDescription = participantInformationDto.ParticipantCategoryCodeTypeDescription;
                        participant.BuyUpParticipantCategoryCodeType = participantInformationDto.BuyUpParticipantCategoryCodeTypeId != null ? (ParticipantCategoryCodeTypeEnum?)participantInformationDto.BuyUpParticipantCategoryCodeTypeId : null;
                        participant.BuyUpParticipantCategoryCodeDescription = participantInformationDto.BuyUpParticipantCategoryCodeTypeDescription;
                        participant.IsPushtoNewProviderChoicePolicyIndicator = participantInformationDto.IsPushtoNewProviderChoicePolicyIndicator != null ? participantInformationDto.IsPushtoNewProviderChoicePolicyIndicator : participant.IsPushtoNewProviderChoicePolicyIndicator;
                        participant.IsAMBIncreaseIndicator = participantInformationDto.IsAMBIncreaseIndicator != null ? participantInformationDto.IsAMBIncreaseIndicator : participant.IsAMBIncreaseIndicator;
                        participant.IsBuyUpPushtoNewProviderChoicePolicyIndicator = participantInformationDto.IsBuyUpPushtoNewProviderChoicePolicyIndicator != null ? participantInformationDto.IsBuyUpPushtoNewProviderChoicePolicyIndicator : participant.IsBuyUpPushtoNewProviderChoicePolicyIndicator;
                        participant.IsBuyUpAMBIncreaseIndicator = participantInformationDto.IsBuyUpAMBIncreaseIndicator != null ? participantInformationDto.IsBuyUpAMBIncreaseIndicator : participant.IsBuyUpAMBIncreaseIndicator;

                        participant.BaseAMBCalculatedAmount = participantInformationDto.BaseAMBCalculatedAmount;
                        participant.VGSIBuyUpAMBCalculatedAmount = participantInformationDto.VGSIBuyUpAMBCalculatedAmount;
                        participant.RPPAMBCalculatedAmount = participantInformationDto.RPPAMBCalculatedAmount;

                        participant.SocialSecurityNumber = participantInformationDto.SocialSecurityNumber != null ? participantInformationDto.SocialSecurityNumber : participant.SocialSecurityNumber;
                        participant.Citizenship = participantInformationDto.Citizenship != null ? participantInformationDto.Citizenship : participant.Citizenship;
                        participant.WeeklyHoursWorked = participantInformationDto.WeeklyHoursWorked != null ? participantInformationDto.WeeklyHoursWorked : participant.WeeklyHoursWorked;
                        participant.IsMicrositeAccess = participantInformationDto.IsMicrositeAccess != null ? (bool)participantInformationDto.IsMicrositeAccess : participant.IsMicrositeAccess;

                        //participant.IDIToBeIgnore1 = participantInformationDto.IDIToBeIgnore1;
                        //participant.IDIToBeIgnore2 = participantInformationDto.IDIToBeIgnore2;
                        //participant.IDIToBeIgnore3 = participantInformationDto.IDIToBeIgnore3;
                        //participant.IDIToBeIgnore4 = participantInformationDto.IDIToBeIgnore4;
                        participant.IDIToBeIgnore1 = false;
                        participant.IDIToBeIgnore2 = false;
                        participant.IDIToBeIgnore3 = false;
                        participant.IDIToBeIgnore4 = false;
                        participant.ManualRPPAmount = participantInformationDto.ManualRPPAmount;
                        participant.ManualBenefitAMBIncreaseAmount = participantInformationDto.ManualBenefitAMBIncreaseAmount;
                        participant.ManualRPPAMBIncreaseAmount = participantInformationDto.ManualRPPAMBIncreaseAmount;
                        participant.ManualVGSIBuyUpAMBIncreaseAmount = participantInformationDto.ManualVGSIBuyUpAMBIncreaseAmount;


                        if (IsOneStepEnrollmentIndicator)
                        {
                            if (participant.WeeklyHoursWorked > 0 && participant.WeeklyHoursWorked < 30)
                            {
                                participant.AAW = false;
                            }
                            else if (participant.WeeklyHoursWorked >= 30)
                            {
                                participant.AAW = true;
                            }
                            else
                            {
                                participant.AAW = participantInformationDto.AAW != null ? participantInformationDto.AAW : participant.AAW;
                                participant.WeeklyHoursWorked = null;
                            }
                        }
                        else
                        {
                            participant.AAW = participantInformationDto.AAW != null ? participantInformationDto.AAW : participant.AAW;
                            //participant.WeeklyHoursWorked = null;
                        }



                        if (participantInformationDto.ManualBenefitAmount > 0 || participantInformationDto.ManualVGSIBuyUpBenefitAmount > 0
                            || participantInformationDto.ManualBenefitAMBIncreaseAmount > 0 || participantInformationDto.ManualVGSIBuyUpAMBIncreaseAmount > 0
                            || participantInformationDto.ManualRPPAmount > 0 || participantInformationDto.ManualRPPAMBIncreaseAmount > 0
                            || participant.CustomLTDInsurableIncomeBaseSalaryPercentage > 0 || participant.CustomLTDInsurableIncomeBonusPercentage > 0
                            || participant.CustomLTDInsurableIncomeCommissionPercentage > 0 || participant.CustomLTDInsurableIncomeOtherIncomePercentage > 0)
                        {
                            participant.ManualOverride = true;
                        }
                        else
                        {
                            participant.ManualOverride = false;
                        }


                        foreach (var enrollemntStaus in participantInformationDto.EnrollmentStatusDto)
                        {
                            //var enrollmentParticipant = participant.EnrollmentCensusParticipants.FirstOrDefault(x => x.Participant.Id == participant.Id && x.Enrollment.Id == enrollemntStaus.EnrollmentId);
                            var enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq().FirstOrDefault(i => i.Id == enrollemntStaus.EnrollmentParticipantId);
                            var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(x => x.Id == enrollemntStaus.EnrollmentId);
                            if (enrollmentParticipant == null)
                            {
                                enrollmentParticipant = new EnrollmentParticipant
                                {
                                    Participant = participant,
                                    Enrollment = enrollment
                                };
                            }
                            enrollmentParticipant.BasePlanEnrollmentParticipantStatusType = (EnrollmentParticipantStatusTypeEnum?)enrollemntStaus.BasePlanEnrollementStatusTypeId;
                            enrollmentParticipant.VGSIPlanEnrollmentParticipantStatusType = (EnrollmentParticipantStatusTypeEnum?)enrollemntStaus.VGSIEnrollementStatusTypeId;
                            unitOfWork.Repository<EnrollmentParticipant>().Save(enrollmentParticipant);
                        }



                        //Added for NBTC-2479 story
                        foreach (var enrollmentParticipantPolicydata in participantInformationDto.EnrollmentParticipantPolicyDto)
                        {

                            // Insert the new policydata with the help of an existing policy data for an enrollment.                    
                            var enrollementParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                                        .Where(i => i.Id == enrollmentParticipantPolicydata.EnrollmentParticipantId).FirstOrDefault();

                            if (enrollementParticipant != null)
                            {
                                int? participantId = enrollementParticipant.Participant?.Id;
                                var caseId = enrollementParticipant.Enrollment?.Case?.Id;

                                if (participantId != null && caseId != null)
                                {
                                    var recentEnrollment = unitOfWork.Repository<Enrollment>().Linq().OrderByDescending(i => i.Id).Where(j => j.Case.Id == caseId).FirstOrDefault();
                                    if (!String.IsNullOrEmpty(enrollmentParticipantPolicydata.PrimaryPolicyNumber))
                                    {
                                        var availblePrimaryPolicyData = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().Where(i => i.PolicyNumber == enrollmentParticipantPolicydata.PrimaryPolicyNumber).FirstOrDefault();
                                        UpdateorInsertPolicyDetails(unitOfWork, enrollmentParticipantPolicydata, participantId, recentEnrollment, availblePrimaryPolicyData, false);
                                    }
                                    if (!String.IsNullOrEmpty(enrollmentParticipantPolicydata.VGSIPolicyNumber))
                                    {
                                        var availbleVGSIPolicyData = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().Where(i => i.PolicyNumber == enrollmentParticipantPolicydata.VGSIPolicyNumber).FirstOrDefault();
                                        UpdateorInsertPolicyDetails(unitOfWork, enrollmentParticipantPolicydata, participantId, recentEnrollment, availbleVGSIPolicyData, true);
                                    }
                                }
                            }
                        }

                        //Save the modified selected option against the latest enrollment                       
                        foreach (var participantSelectedOptionData in participantInformationDto.ParticipantSelectedOptionDto)
                        {

                            if (participantSelectedOptionData.EnrollmentParticipantId != 0)
                            {
                                var updateEnrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                                            .Where(i => i.Id == participantSelectedOptionData.EnrollmentParticipantId
                                                                 && i.Enrollment.Id == participantSelectedOptionData.EnrollmentId).FirstOrDefault();

                                var primaryPolicy = participantInformationDto.EnrollmentParticipantPolicyDto.Where(i => i.EnrollmentParticipantId == participantSelectedOptionData.EnrollmentParticipantId).FirstOrDefault().PrimaryPolicyNumber;
                                var vgsiPolicy = participantInformationDto.EnrollmentParticipantPolicyDto.Where(i => i.EnrollmentParticipantId == participantSelectedOptionData.EnrollmentParticipantId).FirstOrDefault().VGSIPolicyNumber;

                                if (updateEnrollmentParticipant != null)
                                {
                                    if (!String.IsNullOrEmpty(primaryPolicy))
                                    {
                                        if (participantSelectedOptionData.SelectedOptionCodeForBasePlan == 1 || participantSelectedOptionData.SelectedOptionCodeForBasePlan == 2 || participantSelectedOptionData.SelectedOptionCodeForBasePlan == 3)
                                        {
                                            UpdateSelectedOptions(unitOfWork, participantSelectedOptionData, updateEnrollmentParticipant, primaryPolicy, false);
                                        }
                                    }
                                    if (!String.IsNullOrEmpty(vgsiPolicy))
                                    {
                                        if (participantSelectedOptionData.SelectedOptionCodeForVoluntaryPlan == 2 || participantSelectedOptionData.SelectedOptionCodeForVoluntaryPlan == 3)
                                        {
                                            UpdateSelectedOptions(unitOfWork, participantSelectedOptionData, updateEnrollmentParticipant, vgsiPolicy, true);
                                        }
                                    }
                                }
                            }
                        }



                        SaveParticipantExistingPolicies(participant, participantInformationDto);
                        TerminateAndReplaceExistingPolicies(participant, participantInformationDto);

                        if (participant.PlanDesignRequestClass != null)
                        {
                            CalculateAmountsForParticipant(participant, null);
                        }

                        if (participantInformationDto.IsEligible != null)
                        {
                            participant.IsEligible = participantInformationDto.IsEligible;
                            participant.InEligibleReason_Id = participantInformationDto.InEligibleReason_Id;
                            participant.IneligibleReason = participantInformationDto.IneligibleReason;
                            participant.OtherReason = participantInformationDto.OtherReason;
                            if (participantInformationDto.IsEligible == true)
                            {
                                participant.IsError = false;
                                participant.ErrorReason = null;
                            }
                        }

                        participant.IsMicrositeAccess = (bool)participantInformationDto.IsMicrositeAccess;

                        if (participant.ErrorReason == AddressLengthErrorReason)
                        {
                            participant.IsError = false;
                            participant.ErrorReason = null;
                        }

                        unitOfWork.Repository<Participant>().Save(participant);
                        unitOfWork.Commit();
                    }
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat("Error Saving Participant Information.", ex);
                }
            }

            //PerformOperation(censusParticipantId, CensusManagerOperation.CLOASOccupationClassAssignment);

            Log.TraceFormat("-SaveParticipantInformation");
        }

        private void UpdateSelectedOptions(IUnitOfWork unitOfWork, ParticipantSelectedOptionDto participantSelectedOptionData, EnrollmentParticipant updateEnrollmentParticipant, string policyNumber, bool hasBuyUp)
        {

            var updateEnrollmentParticipantPolicy = new EnrollmentParticipantPolicy();

            if (hasBuyUp)
            {
                updateEnrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                                                        .Where(i => i.EnrollmentParticipant.Id == participantSelectedOptionData.EnrollmentParticipantId
                                                                 && i.PolicyNumber == policyNumber
                                                                 && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp).FirstOrDefault();

                if (updateEnrollmentParticipantPolicy == null)
                {
                    updateEnrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                                                            .Where(i => i.EnrollmentParticipant.Id == participantSelectedOptionData.EnrollmentParticipantId
                                                                     && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp).FirstOrDefault();
                }
            }
            else
            {
                updateEnrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                                                       .Where(i => i.EnrollmentParticipant.Id == participantSelectedOptionData.EnrollmentParticipantId
                                                                && i.PolicyNumber == policyNumber
                                                                && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).FirstOrDefault();

                if (updateEnrollmentParticipantPolicy == null)
                {
                    updateEnrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                                                            .Where(i => i.EnrollmentParticipant.Id == participantSelectedOptionData.EnrollmentParticipantId
                                                                     && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).FirstOrDefault();
                }
            }

            if (updateEnrollmentParticipantPolicy != null)
            {
                var existingOptionPlanId = updateEnrollmentParticipantPolicy.EnrollmentPDRClassOptionPlan.Id;

                var enrollmentPDRClassId = unitOfWork.Repository<EnrollmentPDRClassOption>().Linq()
                                            .Where(i => i.Id == existingOptionPlanId).FirstOrDefault()?.EnrollmentPDRClass.Id;

                var optionCode = GetSelectedOptionCodeForPlans(participantSelectedOptionData.SelectedOptionCodeForBasePlan);
                if (hasBuyUp)
                {
                    optionCode = GetSelectedOptionCodeForPlans(participantSelectedOptionData.SelectedOptionCodeForVoluntaryPlan);
                }

                if (enrollmentPDRClassId != null && !String.IsNullOrEmpty(optionCode))
                {
                    var newEnrollmentPDRClass = unitOfWork.Repository<EnrollmentPDRClassOption>().Linq()
                                                .Where(i => i.EnrollmentPDRClass.Id == enrollmentPDRClassId && i.OptionCode == optionCode).FirstOrDefault();

                    if (newEnrollmentPDRClass != null)
                    {
                        var enrollmentPDRClassOptionPlan = unitOfWork.Repository<EnrollmentPDRClassOptionPlan>().Linq()
                                               .Where(i => i.Id == newEnrollmentPDRClass.Id).FirstOrDefault();

                        updateEnrollmentParticipant.SelectedEnrollmentPDRClassOption = newEnrollmentPDRClass;

                        updateEnrollmentParticipantPolicy.EnrollmentPDRClassOptionPlan = enrollmentPDRClassOptionPlan;
                    }
                }

                unitOfWork.Repository<EnrollmentParticipant>().Save(updateEnrollmentParticipant);
                unitOfWork.Repository<EnrollmentParticipantPolicy>().Save(updateEnrollmentParticipantPolicy);
            }

        }

        private static void UpdateorInsertPolicyDetails(IUnitOfWork unitOfWork, EnrollmentParticipantPolicyDto enrollmentParticipantPolicydata, int? participantId, Enrollment recentEnrollment, EnrollmentParticipantPolicy availblePolicyData, bool hasBuyUp)
        {
            Log.TraceFormat("+UpdateorInsertPolicyDetails");

            var oldEnrollmentParticipant = new EnrollmentParticipant();
            var newEnrollmentParticipantToUpdate = new EnrollmentParticipant();
            var oldEnrollmentPolicy = new EnrollmentParticipantPolicy();
            var newEnrollmentParticipantPolicy = new EnrollmentParticipantPolicy();

            if (availblePolicyData != null && !String.IsNullOrEmpty(availblePolicyData.PolicyNumber))
            {
                oldEnrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                   .FirstOrDefault(i => i.Id == availblePolicyData.EnrollmentParticipant.Id);

                newEnrollmentParticipantToUpdate = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                   .FirstOrDefault(i => i.Participant.Id == participantId && i.Enrollment.Id == recentEnrollment.Id);
            }
            else
            {
                oldEnrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                   .FirstOrDefault(i => i.Id == enrollmentParticipantPolicydata.EnrollmentParticipantId);

                newEnrollmentParticipantToUpdate = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                   .FirstOrDefault(i => i.Participant.Id == participantId && i.Enrollment.Id == recentEnrollment.Id);
            }

            if (newEnrollmentParticipantToUpdate == null)
            {
                newEnrollmentParticipantToUpdate = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                .OrderByDescending(i => i.Id).FirstOrDefault(i => i.Participant.Id == participantId && i.Enrollment.Case.Id == recentEnrollment.Case.Id);
            }

            if (newEnrollmentParticipantToUpdate != null && oldEnrollmentParticipant != null)
            {
                newEnrollmentParticipantToUpdate.SelectedEnrollmentPDRClassOption = oldEnrollmentParticipant.SelectedEnrollmentPDRClassOption; // Important update to show the selected option in Titan UI
                //newEnrollmentParticipantToUpdate.BasePlanEnrollmentParticipantStatusType = oldEnrollmentParticipant.BasePlanEnrollmentParticipantStatusType; //Important update to show the selected option in Titan UI

                newEnrollmentParticipantToUpdate.Announcement = oldEnrollmentParticipant.Announcement;
                newEnrollmentParticipantToUpdate.AnnouncementApproved = oldEnrollmentParticipant.AnnouncementApproved;
                newEnrollmentParticipantToUpdate.AnnouncementStatus = oldEnrollmentParticipant.AnnouncementStatus;
                newEnrollmentParticipantToUpdate.Kit = oldEnrollmentParticipant.Kit;
                newEnrollmentParticipantToUpdate.KitApproved = oldEnrollmentParticipant.KitApproved;
                newEnrollmentParticipantToUpdate.KitStatus = oldEnrollmentParticipant.KitStatus;
                newEnrollmentParticipantToUpdate.Sweep = oldEnrollmentParticipant.Sweep;
                newEnrollmentParticipantToUpdate.SweepApproved = oldEnrollmentParticipant.SweepApproved;
                newEnrollmentParticipantToUpdate.SweepStatus = oldEnrollmentParticipant.SweepStatus;
                newEnrollmentParticipantToUpdate.Other = oldEnrollmentParticipant.Other;
                //newEnrollmentParticipantToUpdate.VGSIPlanEnrollmentParticipantStatusType = oldEnrollmentParticipant.VGSIPlanEnrollmentParticipantStatusType;
                newEnrollmentParticipantToUpdate.OnlineEnrollmentPassword = oldEnrollmentParticipant.OnlineEnrollmentPassword;
                newEnrollmentParticipantToUpdate.IsSmoker = oldEnrollmentParticipant.IsSmoker;
                newEnrollmentParticipantToUpdate.SocialSecurityNumber = oldEnrollmentParticipant.SocialSecurityNumber;
                newEnrollmentParticipantToUpdate.ApplicationSignedDate = oldEnrollmentParticipant.ApplicationSignedDate;
                newEnrollmentParticipantToUpdate.BillingCycle = oldEnrollmentParticipant.BillingCycle;
                newEnrollmentParticipantToUpdate.IsHEXCLCreatedOnline = oldEnrollmentParticipant.IsHEXCLCreatedOnline;
                newEnrollmentParticipantToUpdate.IsActivelyWorking = oldEnrollmentParticipant.IsActivelyWorking;
                newEnrollmentParticipantToUpdate.IsCurrentlyDisabled = oldEnrollmentParticipant.IsCurrentlyDisabled;
                newEnrollmentParticipantToUpdate.IsUsCitizen = oldEnrollmentParticipant.IsUsCitizen;
                newEnrollmentParticipantToUpdate.VisaType = oldEnrollmentParticipant.VisaType;
                newEnrollmentParticipantToUpdate.VisaDuration = oldEnrollmentParticipant.VisaDuration;
                newEnrollmentParticipantToUpdate.CATa = oldEnrollmentParticipant.CATa;
                newEnrollmentParticipantToUpdate.CATb = oldEnrollmentParticipant.CATb;
                newEnrollmentParticipantToUpdate.CATc = oldEnrollmentParticipant.CATc;
                newEnrollmentParticipantToUpdate.CATd = oldEnrollmentParticipant.CATd;
                newEnrollmentParticipantToUpdate.CATe = oldEnrollmentParticipant.CATe;
                newEnrollmentParticipantToUpdate.SLPQuestion = oldEnrollmentParticipant.SLPQuestion;
                newEnrollmentParticipantToUpdate.SISQuestion = oldEnrollmentParticipant.SISQuestion;

                unitOfWork.Repository<EnrollmentParticipant>().Save(newEnrollmentParticipantToUpdate);
            }

            if (hasBuyUp)
            {
                oldEnrollmentPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                .FirstOrDefault(i => i.PolicyNumber == enrollmentParticipantPolicydata.VGSIPolicyNumber
                                    && i.EnrollmentParticipant.Id == oldEnrollmentParticipant.Id
                                    && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                if (oldEnrollmentPolicy == null)
                {
                    oldEnrollmentPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                        .FirstOrDefault(i => i.EnrollmentParticipant.Id == oldEnrollmentParticipant.Id
                                          && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                }

                newEnrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                .FirstOrDefault(i => i.PolicyNumber == enrollmentParticipantPolicydata.VGSIPolicyNumber
                                    && i.EnrollmentParticipant.Id == enrollmentParticipantPolicydata.EnrollmentParticipantId
                                    && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                if (newEnrollmentParticipantPolicy == null)
                {
                    newEnrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                   .FirstOrDefault(i => i.EnrollmentParticipant.Id == enrollmentParticipantPolicydata.EnrollmentParticipantId
                                       && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                }
            }
            else
            {
                oldEnrollmentPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                .FirstOrDefault(i => i.PolicyNumber == enrollmentParticipantPolicydata.PrimaryPolicyNumber
                                    && i.EnrollmentParticipant.Id == oldEnrollmentParticipant.Id
                                    && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);

                if (oldEnrollmentPolicy == null)
                {
                    oldEnrollmentPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                    .FirstOrDefault(i => i.EnrollmentParticipant.Id == oldEnrollmentParticipant.Id
                                        && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);

                }

                newEnrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                            .FirstOrDefault(i => i.PolicyNumber == enrollmentParticipantPolicydata.PrimaryPolicyNumber
                                              && i.EnrollmentParticipant.Id == enrollmentParticipantPolicydata.EnrollmentParticipantId
                                              && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);

                if (newEnrollmentParticipantPolicy == null)
                {

                    newEnrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().OrderByDescending(i => i.Id)
                                .FirstOrDefault(i => i.EnrollmentParticipant.Id == enrollmentParticipantPolicydata.EnrollmentParticipantId
                                                  && i.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                }
            }


            if ((oldEnrollmentPolicy != null && newEnrollmentParticipantPolicy == null) || (oldEnrollmentPolicy == null && newEnrollmentParticipantPolicy == null))
            {
                newEnrollmentParticipantPolicy = new EnrollmentParticipantPolicy();
            }

            newEnrollmentParticipantPolicy.EnrollmentParticipant = newEnrollmentParticipantToUpdate;
            newEnrollmentParticipantPolicy.EnrollmentParticipantOptionPlan = oldEnrollmentPolicy?.EnrollmentParticipantOptionPlan;
            newEnrollmentParticipantPolicy.EnrollmentPDRClassOptionPlan = oldEnrollmentPolicy?.EnrollmentPDRClassOptionPlan;

            if (oldEnrollmentPolicy?.EnrollmentPDRClassOptionPlan == null || oldEnrollmentPolicy?.EnrollmentParticipantOptionPlan == null)
            {
                var enrollmentPDRClass = unitOfWork.Repository<EnrollmentPDRClass>().Linq()
                    .FirstOrDefault(i => i.Enrollment.Id == newEnrollmentParticipantToUpdate.Enrollment.Id
                    && i.PlanDesignRequestClass.Id == newEnrollmentParticipantToUpdate.Participant.PlanDesignRequestClass.Id);

                var enrollmentPDRClassOptions = unitOfWork.Repository<EnrollmentPDRClassOption>().Linq()
                    .Where(i => i.EnrollmentPDRClass.Id == enrollmentPDRClass.Id);

                var enrollmentPDRClassOption = enrollmentPDRClassOptions.FirstOrDefault(i => i.EnrollmentPDRClassOptionPlans.Any(j => j.PDRClassPlanType == PDRClassPlanTypeEnum.Primary));

                if (hasBuyUp)
                {
                    enrollmentPDRClassOption = enrollmentPDRClassOptions.FirstOrDefault(i => i.EnrollmentPDRClassOptionPlans.Any(j => j.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp));
                }

                var enrollmentPDRClassOptionPlan = unitOfWork.Repository<EnrollmentPDRClassOptionPlan>().Linq().FirstOrDefault(i => i.Id == enrollmentPDRClassOption.Id);
                newEnrollmentParticipantPolicy.EnrollmentPDRClassOptionPlan = enrollmentPDRClassOptionPlan; //important update for newly inserted policy

                var enrollmentParticipantOptionPlan = unitOfWork.Repository<EnrollmentParticipantOptionPlan>().Linq().FirstOrDefault(i => i.EnrollmentPDRClassOptionPlan.Id == enrollmentPDRClassOption.Id);
                newEnrollmentParticipantPolicy.EnrollmentParticipantOptionPlan = enrollmentParticipantOptionPlan; //important update for newly inserted policy
            }


            newEnrollmentParticipantPolicy.ReviewReason = oldEnrollmentPolicy?.ReviewReason;

            if (!hasBuyUp)
            {
                newEnrollmentParticipantPolicy.PolicyNumber = enrollmentParticipantPolicydata.PrimaryPolicyNumber;

                if (enrollmentParticipantPolicydata.PrimaryPolicyStatus == "Coded")
                {
                    newEnrollmentParticipantPolicy.PolicyStatusType = PolicyStatusTypeEnum.Coded;
                }
                else if (enrollmentParticipantPolicydata.PrimaryPolicyStatus == "Issued")
                {
                    newEnrollmentParticipantPolicy.PolicyStatusType = PolicyStatusTypeEnum.Issued;
                }
                else if (enrollmentParticipantPolicydata.PrimaryPolicyStatus == "FailedToCode")
                {
                    newEnrollmentParticipantPolicy.PolicyStatusType = PolicyStatusTypeEnum.FailedToCode;
                }
                else if (enrollmentParticipantPolicydata.PrimaryPolicyStatus == "FailedToIssue")
                {
                    newEnrollmentParticipantPolicy.PolicyStatusType = PolicyStatusTypeEnum.FailedToIssue;
                }
            }
            else
            {
                newEnrollmentParticipantPolicy.PolicyNumber = enrollmentParticipantPolicydata.VGSIPolicyNumber;

                if (enrollmentParticipantPolicydata.VGSIPolicyStatus == "Coded")
                {
                    newEnrollmentParticipantPolicy.PolicyStatusType = PolicyStatusTypeEnum.Coded;
                }
                else if (enrollmentParticipantPolicydata.VGSIPolicyStatus == "Issued")
                {
                    newEnrollmentParticipantPolicy.PolicyStatusType = PolicyStatusTypeEnum.Issued;
                }
                else if (enrollmentParticipantPolicydata.VGSIPolicyStatus == "FailedToCode")
                {
                    newEnrollmentParticipantPolicy.PolicyStatusType = PolicyStatusTypeEnum.FailedToCode;
                }
                else if (enrollmentParticipantPolicydata.VGSIPolicyStatus == "FailedToIssue")
                {
                    newEnrollmentParticipantPolicy.PolicyStatusType = PolicyStatusTypeEnum.FailedToIssue;
                }
            }
            unitOfWork.Repository<EnrollmentParticipantPolicy>().Save(newEnrollmentParticipantPolicy);


            Log.TraceFormat("-UpdateorInsertPolicyDetails");
        }

        private string GetSelectedOptionCodeForPlans(int? selectedOptionId)
        {
            string selectedOptionCode = string.Empty;
            if (selectedOptionId == 1)
            {
                selectedOptionCode = "Option 1";
            }
            else if (selectedOptionId == 2)
            {
                selectedOptionCode = "Option 2";
            }
            else if (selectedOptionId == 3)
            {
                selectedOptionCode = "Option 3";
            }
            return selectedOptionCode;
        }
        private void TerminateAndReplaceExistingPolicies(Participant participant, CensusParticipantDto participantDto)
        {
            Log.TraceFormat("+TerminateAndReplaceExistingPolicies - Participant Id:" + participant.Id);

            var removedAllInforcePolicyIds = participantDto.ParticipantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => p.IsRemoveAllInforcePolicy == true).Select(p => p.ParticipantExistingPolicyDetailId).ToList();
            if (!removedAllInforcePolicyIds.Any())
            {
                if (participant.IsEligible == true || participant.IsEligible == null)
                {
                    if (participantDto.ParticipantExistingPolicy != null)
                    {
                        string caseNumber = participant.Census.Case.CaseNumber;
                        var inForcePolicies = participantDto.ParticipantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => (p.CLOASPolicyStatus == "Inforce" || p.CLOASPolicyStatus == "Inforce-Claim" || p.CLOASPolicyStatus == "Pending")).ToList();
                        if (inForcePolicies.Any())
                        {
                            bool incomeProviderPolicy = true;
                            bool providerChoicePolicy = true;

                            foreach (var inForcePolicy in inForcePolicies)
                            {
                                if (inForcePolicy.IsTerminateAndReplace == false && inForcePolicy.Product == "Income Provider" && inForcePolicy.CaseNumber == caseNumber)
                                {
                                    incomeProviderPolicy = false;
                                    continue;
                                }
                                if (inForcePolicy.IsTerminateAndReplace == true && (inForcePolicy.Product == "Provider Choice" || inForcePolicy.Product == "Provider Choice RPP") && inForcePolicy.CaseNumber == caseNumber)
                                {
                                    providerChoicePolicy = true;
                                    continue;
                                }
                                if (inForcePolicy.IsTerminateAndReplace == true && inForcePolicy.Product == "Income Provider" && inForcePolicy.CaseNumber == caseNumber)
                                {
                                    incomeProviderPolicy = true;
                                    continue;
                                }
                                if (inForcePolicy.IsTerminateAndReplace == false && (inForcePolicy.Product == "Provider Choice" || inForcePolicy.Product == "Provider Choice RPP") && inForcePolicy.CaseNumber == caseNumber)
                                {
                                    providerChoicePolicy = false;
                                    continue;
                                }
                            }

                            if (!incomeProviderPolicy && providerChoicePolicy)
                            {
                                participant.IsPushtoNewProviderChoicePolicyIndicator = true;
                                participant.IsAMBIncreaseIndicator = false;
                            }
                            else if (incomeProviderPolicy && !providerChoicePolicy)
                            {
                                participant.IsPushtoNewProviderChoicePolicyIndicator = false;
                                participant.IsAMBIncreaseIndicator = true;
                            }
                            else
                            {
                                participant.IsPushtoNewProviderChoicePolicyIndicator = false;
                                participant.IsAMBIncreaseIndicator = false;
                            }
                        }

                        var policyDetails = participantDto.ParticipantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => p.IsTerminateAndReplace == true).ToList();
                        if (policyDetails.Any())
                        {
                            var participantExistingPolicy = participant.ParticipantExistingPolicies.FirstOrDefault();

                            foreach (var policyDetail in policyDetails)
                            {
                                if (participantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => p.Id == policyDetail.ParticipantExistingPolicyDetailId).FirstOrDefault().IsTerminateAndReplace != true)
                                {
                                    if (policyDetail.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[3])
                                    {
                                        participantExistingPolicy.GSIIDIBaseAMB -= policyDetail.MonthlyIndemnity + policyDetail.AMBAmount;
                                    }
                                    if (policyDetail.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[2])
                                    {
                                        participantExistingPolicy.GSIRPPBaseAMB -= policyDetail.MonthlyIndemnity + policyDetail.AMBAmount;
                                    }
                                    if (policyDetail.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[1])
                                    {
                                        participantExistingPolicy.FullyUnderwrittenIDI -= policyDetail.MonthlyIndemnity + policyDetail.AMBAmount;//Verify with business
                                    }
                                    if (policyDetail.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[0])
                                    {
                                        participantExistingPolicy.FullyUnderwrittenRPP -= policyDetail.MonthlyIndemnity + policyDetail.AMBAmount;
                                    }
                                    participantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => p.Id == policyDetail.ParticipantExistingPolicyDetailId).FirstOrDefault().IsTerminateAndReplace = true;
                                }
                            }

                            if (participant.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
                            {
                                participant.IDIToBeReplacedAmount1 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                            }
                            else if (participant.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
                            {
                                participant.IDIToBeReplacedAmount2 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                            }
                            else if (participant.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
                            {
                                participant.IDIToBeReplacedAmount3 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                            }
                            else if (participant.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
                            {
                                participant.IDIToBeReplacedAmount4 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                            }
                        }
                    }
                }
            }
            Log.TraceFormat("-TerminateAndReplaceExistingPolicies - Participant Id:" + participant.Id);
        }

        private void SaveParticipantExistingPolicies(Participant participant, CensusParticipantDto participantDto)
        {
            Log.TraceFormat("+SaveParticipantExistingPolicies - Participant Id:" + participant.Id);
            if (participantDto.ParticipantExistingPolicy != null)
            {
                var removedPolicyDetailIds = participantDto.ParticipantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => p.IsRemovePolicy == true).Select(p => p.ParticipantExistingPolicyDetailId).ToList();
                if (removedPolicyDetailIds.Any())
                {
                    var participantExistingPolicy = participant.ParticipantExistingPolicies.FirstOrDefault();

                    var removedPolicies = participantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => removedPolicyDetailIds.Contains(p.Id)).ToList();

                    RemovePartialMatchPolicies(participant, participantExistingPolicy, removedPolicies);
                }

                var removedAllInforcePolicyIds = participantDto.ParticipantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => p.IsRemoveAllInforcePolicy == true).Select(p => p.ParticipantExistingPolicyDetailId).ToList();
                if (removedAllInforcePolicyIds.Any())
                {
                    var participantExistingPolicy = participant.ParticipantExistingPolicies.FirstOrDefault();

                    var removedPolicies = participantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => removedAllInforcePolicyIds.Contains(p.Id)).ToList();

                    RemoveAllInforcePolicy(participant, participantExistingPolicy, removedPolicies);
                }
            }
            Log.TraceFormat("-SaveParticipantExistingPolicies");
        }

        private void RemoveAllInforcePolicy(Participant participant, ParticipantExistingPolicy participantExistingPolicy, List<ParticipantExistingPolicyDetail> removedPolicies)
        {
            Log.TraceFormat("+RemoveAllInforcePolicy - Participant Id:" + participant.Id);

            bool isGuardianExistingPolicyRemoved = false;

            foreach (var removedPolicy in removedPolicies)
            {
                participantExistingPolicy.ParticipantExistingPolicyDetails.Remove(removedPolicy);
                participant.ParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.NE;
                participant.ParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.NE.ToString();
                participant.IsAMBIncreaseIndicator = false;
                if (participant.BuyUpParticipantCategoryCodeType != null)
                {
                    participant.BuyUpParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.NE;
                    participant.BuyUpParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.NE.ToString();
                    participant.IsBuyUpAMBIncreaseIndicator = false;
                }

                isGuardianExistingPolicyRemoved = true;
            }

            var policyDetails = participantExistingPolicy.ParticipantExistingPolicyDetails.ToList();
            if (policyDetails.Any())
            {
                participantExistingPolicy.GSIIDIBaseAMB = 0;
                participantExistingPolicy.GSIRPPBaseAMB = 0;
                participantExistingPolicy.FullyUnderwrittenIDI = 0;
                participantExistingPolicy.FullyUnderwrittenRPP = 0;


                foreach (var policyDetail in policyDetails)
                {
                    if (policyDetail.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[3])
                    {
                        participantExistingPolicy.GSIIDIBaseAMB += policyDetail.MonthlyIndemnity + policyDetail.AMBAmount;
                    }
                    if (policyDetail.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[2])
                    {
                        participantExistingPolicy.GSIRPPBaseAMB += policyDetail.MonthlyIndemnity + policyDetail.AMBAmount;
                    }
                    if (policyDetail.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[1])
                    {
                        participantExistingPolicy.FullyUnderwrittenIDI += policyDetail.MonthlyIndemnity + policyDetail.AMBAmount;//Verify with business
                    }
                    if (policyDetail.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[0])
                    {
                        participantExistingPolicy.FullyUnderwrittenRPP += policyDetail.MonthlyIndemnity + policyDetail.AMBAmount;
                    }
                }

                if (participant.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
                {
                    participant.IDIBenefitAmount1 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                }
                else if (participant.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
                {
                    participant.IDIBenefitAmount2 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                }
                else if (participant.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
                {
                    participant.IDIBenefitAmount3 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                }
                else if (participant.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
                {
                    participant.IDIBenefitAmount4 = policyDetails.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                }
            }
            else
            {
                if (isGuardianExistingPolicyRemoved)
                {
                    participantExistingPolicy.GSIIDIBaseAMB = 0;
                    participantExistingPolicy.GSIRPPBaseAMB = 0;
                    participantExistingPolicy.FullyUnderwrittenIDI = 0;
                    participantExistingPolicy.FullyUnderwrittenRPP = 0;

                    if (participant.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
                    {
                        participant.IDIBenefitAmount1 = null;
                        participant.IDICarrier1 = null;
                        participant.IDICarrier1Description = string.Empty;
                    }
                    else if (participant.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
                    {
                        participant.IDIBenefitAmount2 = null;
                        participant.IDICarrier2 = null;
                        participant.IDICarrier2Description = string.Empty;
                    }
                    else if (participant.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
                    {
                        participant.IDIBenefitAmount3 = null;
                        participant.IDICarrier3 = null;
                        participant.IDICarrier3Description = string.Empty;
                    }
                    else if (participant.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
                    {
                        participant.IDIBenefitAmount4 = null;
                        participant.IDICarrier4 = null;
                        participant.IDICarrier4Description = string.Empty;
                    }

                }
            }

            Log.TraceFormat("-RemoveAllInforcePolicy");
        }
        private void RemovePartialMatchPriorCoverages(List<int> partialPolicyMatchParicipantIds, bool isPolicyMatch = false)
        {
            Log.TraceFormat("+RemovePartialMatchPriorCoverages");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var participants = unitOfWork.Repository<Participant>().Linq().Where(p => partialPolicyMatchParicipantIds.Contains(p.Id)).ToList();
                foreach (var participant in participants)
                {
                    var participantExistingPolicy = participant.ParticipantExistingPolicies.FirstOrDefault();
                    var removedPolicies = participantExistingPolicy.ParticipantExistingPolicyDetails.Where(p => p.IsPolicyMatch == isPolicyMatch).ToList();
                    RemovePartialMatchPolicies(participant, participantExistingPolicy, removedPolicies);

                    if (isPolicyMatch == true)
                    {
                        participant.ParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.NE;
                        participant.ParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.NE.ToString();
                        participant.IsAMBIncreaseIndicator = false;
                        if (participant.BuyUpParticipantCategoryCodeType != null)
                        {
                            participant.BuyUpParticipantCategoryCodeType = ParticipantCategoryCodeTypeEnum.NE;
                            participant.BuyUpParticipantCategoryCodeDescription = ParticipantCategoryCodeTypeEnum.NE.ToString();
                            participant.IsBuyUpAMBIncreaseIndicator = false;
                        }

                        if (participant.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
                        {
                            participant.IDIBenefitAmount1 = null;
                            participant.IDICarrier1 = null;
                            participant.IDICarrier1Description = string.Empty;
                        }
                        else if (participant.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
                        {
                            participant.IDIBenefitAmount2 = null;
                            participant.IDICarrier2 = null;
                            participant.IDICarrier2Description = string.Empty;
                        }
                        else if (participant.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
                        {
                            participant.IDIBenefitAmount3 = null;
                            participant.IDICarrier3 = null;
                            participant.IDICarrier3Description = string.Empty;
                        }
                        else if (participant.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
                        {
                            participant.IDIBenefitAmount4 = null;
                            participant.IDICarrier4 = null;
                            participant.IDICarrier4Description = string.Empty;
                        }
                    }
                    unitOfWork.Repository<Participant>().Save(participant);
                }
                unitOfWork.Commit();
            }
            Log.TraceFormat("-RemovePartialMatchPriorCoverages");
        }

        private void RemovePartialMatchPolicies(Participant participant, ParticipantExistingPolicy participantExistingPolicy, List<ParticipantExistingPolicyDetail> removedPolicies)
        {
            Log.TraceFormat("+RemovePartialMatchPolicies - Participant Id:" + participant.Id);

            foreach (var removedPolicy in removedPolicies)
            {
                participantExistingPolicy.ParticipantExistingPolicyDetails.Remove(removedPolicy);
            }
            if (participantExistingPolicy.ParticipantExistingPolicyDetails.Count(c => c.IsPolicyMatch == false) == 0)
            {
                participant.IsError = false;
                participant.ErrorReason = null;
            }
            if (participantExistingPolicy.ParticipantExistingPolicyDetails.Any())
            {
                participantExistingPolicy.GSIIDIBaseAMB = CalculateGSIIDIBaseAMB(participantExistingPolicy.ParticipantExistingPolicyDetails);
                participantExistingPolicy.GSIRPPBaseAMB = CalculateGSIRPPBaseAMB(participantExistingPolicy.ParticipantExistingPolicyDetails);
                participantExistingPolicy.FullyUnderwrittenIDI = CalculateFullyUnderwrittenIDI(participantExistingPolicy.ParticipantExistingPolicyDetails);
                participantExistingPolicy.FullyUnderwrittenRPP = CalculateFullyUnderwrittenRPP(participantExistingPolicy.ParticipantExistingPolicyDetails);
            }
            else
            {
                participantExistingPolicy.GSIIDIBaseAMB = null;
                participantExistingPolicy.GSIRPPBaseAMB = null;
                participantExistingPolicy.FullyUnderwrittenIDI = null;
                participantExistingPolicy.FullyUnderwrittenRPP = null;
            }

            if (participant.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
            {
                participant.IDIBenefitAmount1 = participantExistingPolicy.GSIIDIBaseAMB ?? 0.0m + participantExistingPolicy.FullyUnderwrittenIDI ?? 0.0m;
            }
            else if (participant.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
            {
                participant.IDIBenefitAmount2 = participantExistingPolicy.GSIIDIBaseAMB ?? 0.0m + participantExistingPolicy.FullyUnderwrittenIDI ?? 0.0m;
            }
            else if (participant.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
            {
                participant.IDIBenefitAmount3 = participantExistingPolicy.GSIIDIBaseAMB ?? 0.0m + participantExistingPolicy.FullyUnderwrittenIDI ?? 0.0m;
            }
            else if (participant.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
            {
                participant.IDIBenefitAmount4 = participantExistingPolicy.GSIIDIBaseAMB ?? 0.0m + participantExistingPolicy.FullyUnderwrittenIDI ?? 0.0m;
            }
            Log.TraceFormat("-RemovePartialMatchPolicies");
        }

        private decimal? CalculateFullyUnderwrittenRPP(IList<ParticipantExistingPolicyDetail> participantExistingPolicyDetails)
        {
            if (participantExistingPolicyDetails.Any(pd => pd.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[0]))
            {
                var result = participantExistingPolicyDetails.Where(pd => pd.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[0]).Sum(pd => pd.MonthlyIndemnity);
                return result;
            }
            return null;
        }

        private decimal? CalculateFullyUnderwrittenIDI(IList<ParticipantExistingPolicyDetail> participantExistingPolicyDetails)
        {
            if (participantExistingPolicyDetails.Any(pd => pd.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[1]))
            {
                var result = participantExistingPolicyDetails.Where(pd => pd.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[1]).Sum(pd => pd.MonthlyIndemnity);
                return result;
            }
            return null;
        }

        private decimal? CalculateGSIRPPBaseAMB(IList<ParticipantExistingPolicyDetail> participantExistingPolicyDetails)
        {
            if (participantExistingPolicyDetails.Any(pd => pd.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[2]))
            {
                var result = participantExistingPolicyDetails.Where(pd => pd.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[2]).Sum(pd => pd.MonthlyIndemnity);
                return result;
            }
            return null;
        }

        private decimal? CalculateGSIIDIBaseAMB(IList<ParticipantExistingPolicyDetail> participantExistingPolicyDetails)
        {
            if (participantExistingPolicyDetails.Any(pd => pd.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[3]))
            {
                var result = participantExistingPolicyDetails.Where(pd => pd.TitanPriorCoverageSearchGrouping == TitanPriorCoverageSearchGroupings[3]).Sum(pd => pd.MonthlyIndemnity);
                return result;
            }
            return null;
        }

        public void ValidateParicipantAddressLength(List<int> participantIds)
        {
            Log.TraceFormat("+ValidateParicipantAddressLength");
            var finalParticipants = new List<Participant>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var participants = unitOfWork.Repository<Participant>().Linq();

                List<List<int>> splittedParticipants = participantIds.ChunkBy(1500);

                foreach (var splittedparticipantIds in splittedParticipants)
                {
                    var selectedParticipants = participants.Where(c => splittedparticipantIds.Contains(c.Id) &&
                                                                    ((c.HomeStreet1 != null && c.HomeStreet1.Length >= 23)
                                                                    || (c.HomeStreet2 != null && c.HomeStreet2.Length >= 23)
                                                                    || (c.HomeCity != null && c.HomeCity.Length >= 23))).ToList();
                    finalParticipants.AddRange(selectedParticipants);
                }

            }
            if (finalParticipants.Count > 0)
            {
                SaveValidateParicipantAddressLengthToDatabase(finalParticipants);
            }
            Log.TraceFormat("-ValidateParicipantAddressLength");
        }

        public void GiftPolicyToMultipleParticipants(List<int> selectedCensusParticipantsIds)
        {
            Log.TraceFormat("+GiftPolicyToMultipleParticipants");

            var splittedParticipantsIds = selectedCensusParticipantsIds.ChunkBy(2000);
            Parallel.ForEach(splittedParticipantsIds, currentChunk =>
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var participants = unitOfWork.Repository<Participant>().Linq()
                                            .Where(participant => currentChunk.Contains(participant.Id))
                                            .ToList();
                    foreach (var participant in participants)
                    {
                        participant.ManualBenefitAmount = GetManualBenefitAmount(participant.PlanDesignRequestClass.Id);
                        participant.ManualOverride = true;
                        CalculateAmountsForParticipant(participant, null);

                        unitOfWork.Repository<Participant>().Save(participant);
                    }
                    unitOfWork.Commit();
                }
            });

            Log.TraceFormat("-GiftPolicyToMultipleParticipants");
        }

        public void SaveValidateParicipantAddressLengthToDatabase(List<Participant> participants)
        {
            Log.TraceFormat("+SaveValidateParicipantAddressLengthToDatabase");
            string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");
            IList<ValidateAddressLengthParticipantDto> participantDtos = participants
                                .Select(p => new ValidateAddressLengthParticipantDto
                                {
                                    Participant_Id = p.Id,
                                    IsError = true,
                                    ErrorReason = AddressLengthErrorReason
                                }
                               ).ToList();

            DataTable participantTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(participantDtos));

            using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
            {
                SqlCommand command = sqlConnection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "[cms].[USP_UpdateParticipantAddressLengthValidation]";

                SqlParameter parameter1 = new SqlParameter();
                parameter1.ParameterName = "@ParticipantTableVariable";
                parameter1.SqlDbType = SqlDbType.Structured;
                parameter1.Value = participantTable;
                command.Parameters.Add(parameter1);

                sqlConnection.Open();
                int numberOfRowsUpdated = command.ExecuteNonQuery();
            }

            Log.TraceFormat("-SaveValidateParicipantAddressLengthToDatabase");
        }

        private void CreateTasksForReEnrollmentCensus(int caseId, IUnitOfWork unitOfWork)
        {
            var isVoluntary = _planDesignRequestSoldManager.IsVoluntaryPremiumPayerClass(caseId);

            //const string enrollmentCensusReceivedTaskName = "A re-enrollment census received";
            var dueTimeSpan = TimeSpan.FromDays(10);

            var taskSLA = unitOfWork.Repository<TaskSLAType>().Linq();
            var taskSlaForImpAnalyst = taskSLA.Where(i => i.ShortDescription == "ReEnrollmentReceivedImpAnalyst").FirstOrDefault();

            if (taskSlaForImpAnalyst != null)
            {
                var assignedUserId = _taskManager.GetAssignedUserId(caseId);
                _taskManager.CreateTask(caseId, taskSlaForImpAnalyst.TaskName, UserGroup.Group_Implementation_Analyst, null, taskSlaForImpAnalyst.SLAInHours, taskSlaForImpAnalyst.isSameDayResponseRequired);
            }
        }

        private EligibilityConfigurationDto GetClassEligibilityConfiguration(int pdrClassId)
        {
            if (_classEligibilityConfigurationDictionary.ContainsKey(pdrClassId)) return _classEligibilityConfigurationDictionary[pdrClassId];

            var eligibilityConfigurationClassDto = new EligibilityConfigurationDto { PlanDesignRequestClassId = pdrClassId };
            eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
            _classEligibilityConfigurationDictionary[pdrClassId] = eligibilityConfigurationClassDto;

            return eligibilityConfigurationClassDto;
        }

        private void BuildCensusParticipant(CensusDto request, Census census, List<PlanDesignRequestClass> planDesignRequestClasses, bool isEnrollmentCensus)
        {
            Log.TraceFormat("+BuildCensusParticipant");

            var classEligibilityConfiguration = new Dictionary<int, EligibilityConfigurationDto>();
            foreach (var planDesignRequestClass in planDesignRequestClasses)
            {
                var eligibilityConfigurationClassDto = new EligibilityConfigurationDto { PlanDesignRequestClassId = planDesignRequestClass.Id };
                eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);

                if (!classEligibilityConfiguration.ContainsKey(planDesignRequestClass.Id))
                    classEligibilityConfiguration.Add(planDesignRequestClass.Id, eligibilityConfigurationClassDto);
            }

            Log.TraceFormat("+BuildCensusParticipant CaseID:{0} PdrId:{1}", request.CaseId, request.PlanDesignRequestId);

            foreach (var participant in request.CensusParticipants)
            {
                var censusParticipant = new Participant(false) { Census = census };

                if (!isEnrollmentCensus)
                {
                    var pdrClass = planDesignRequestClasses.FirstOrDefault(c => c.GAPlanDesignRequestClassId == participant.EligibleClass);
                    if (pdrClass != null)
                    {
                        censusParticipant.PlanDesignRequestClass = pdrClass;
                        censusParticipant.PlanDesignRequestClassEligiblePopulationText = pdrClass.ApprovedEligiblePopulationText ??
                                                                                         pdrClass.RequestedEligiblePopulationText;
                    }
                }

                censusParticipant.EligibleClass = participant.EligibleClass;
                censusParticipant.EmployeeId = participant.EmployeeId;
                censusParticipant.ClientReferenceNumber = participant.ClientReferenceNumber;
                censusParticipant.FirstName = participant.FirstName;
                censusParticipant.LastName = participant.LastName;
                censusParticipant.MiddleInitial = participant.MiddleInitial;
                censusParticipant.Suffix = participant.Suffix;
                censusParticipant.HomeStreet1 = participant.HomeStreet1;
                censusParticipant.HomeStreet2 = participant.HomeStreet2;
                censusParticipant.HomeCity = participant.HomeCity;
                censusParticipant.HomeStateDescription = participant.HomeStateDescription;
                censusParticipant.HomeState = (StateTypeEnum?)GetStateId(participant.HomeStateDescription);
                censusParticipant.HomeZipCode = participant.HomeZipCode;
                censusParticipant.WorkStreet1 = participant.WorkStreet1;
                censusParticipant.WorkStreet2 = participant.WorkStreet2;
                censusParticipant.WorkCity = participant.WorkCity;
                censusParticipant.WorkStateDescription = !string.IsNullOrEmpty(participant.WorkStateDescription) ? participant.WorkStateDescription.Trim().ToUpper() : null;
                censusParticipant.WorkState = (StateTypeEnum?)GetStateId(participant.WorkStateDescription);
                censusParticipant.WorkStreet1 = participant.WorkStreet1;
                censusParticipant.WorkZipCode = participant.WorkZipCode;
                censusParticipant.WorkLocationPhone = participant.WorkLocationPhone;
                censusParticipant.WorkLocationExtension = participant.WorkLocationExtension;
                censusParticipant.WorkStopCode = participant.WorkStopCode;
                censusParticipant.WorkEmail = participant.WorkEmail;
                censusParticipant.DateOfBirth = participant.DateOfBirth;
                censusParticipant.DateOfHire = participant.DateOfHire;
                censusParticipant.Age = participant.Age;
                censusParticipant.Gender = participant.Gender != null ? participant.Gender.ToUpper() : "";
                censusParticipant.JobTitle = participant.JobTitle;
                censusParticipant.BoardCertification = participant.BoardCertification;
                censusParticipant.MostRecentSalaryAmount = participant.MostRecentSalaryAmount;
                censusParticipant.MostRecentPaidBonusAmount = participant.MostRecentPaidBonusAmount;
                censusParticipant.PriorPaidBonusAmount = participant.PriorPaidBonusAmount;
                censusParticipant.AdditionalPriorPaidBonusAmount = participant.AdditionalPriorPaidBonusAmount;
                censusParticipant.MostRecentPaidCommissionAmount = participant.MostRecentPaidCommissionAmount;
                censusParticipant.PriorPaidCommissionAmount = participant.PriorPaidCommissionAmount;
                censusParticipant.AdditionalPriorPaidCommissionAmount = participant.AdditionalPriorPaidCommissionAmount;
                censusParticipant.MostRecentPaidK1IncomeAmount = participant.MostRecentPaidK1IncomeAmount;
                censusParticipant.PriorPaidK1IncomeAmount = participant.PriorPaidK1IncomeAmount;
                censusParticipant.AdditionalPriorPaidK1IncomeAmount = participant.AdditionalPriorPaidK1IncomeAmount;
                censusParticipant.OtherIncomeAmount = participant.OtherIncomeAmount;
                censusParticipant.TotalEmployerOrEmployeeRetirementContributionAmount = participant.TotalEmployerOrEmployeeRetirementContributionAmount;
                censusParticipant.GroupLTDClass = participant.GroupLTDClass;
                censusParticipant.IDICarrier1Description = participant.IDICarrier1Description;
                censusParticipant.IDICarrier1 = (IDICoverageCarrierTypeEnum?)GetCarrierId(participant.IDICarrier1Description);
                censusParticipant.IDIBenefitAmount1 = participant.IDIBenefitAmount1;
                censusParticipant.IDIToBeReplaced1 = participant.IDIToBeReplaced1;
                censusParticipant.IDIToBeReplacedAmount1 = participant.IDIToBeReplacedAmount1;
                censusParticipant.IDIPolicyNumber1 = participant.IDIPolicyNumber1;
                censusParticipant.IDICarrier2Description = participant.IDICarrier2Description;
                censusParticipant.IDICarrier2 = (IDICoverageCarrierTypeEnum?)GetCarrierId(participant.IDICarrier2Description);
                censusParticipant.IDIBenefitAmount2 = participant.IDIBenefitAmount2;
                censusParticipant.IDIToBeReplaced2 = participant.IDIToBeReplaced2;
                censusParticipant.IDIToBeReplacedAmount2 = participant.IDIToBeReplacedAmount2;
                censusParticipant.IDIPolicyNumber2 = participant.IDIPolicyNumber2;
                censusParticipant.IDICarrier3Description = participant.IDICarrier3Description;
                censusParticipant.IDICarrier3 = (IDICoverageCarrierTypeEnum?)GetCarrierId(participant.IDICarrier3Description);
                censusParticipant.IDIBenefitAmount3 = participant.IDIBenefitAmount3;
                censusParticipant.IDIToBeReplaced3 = participant.IDIToBeReplaced3;
                censusParticipant.IDIToBeReplacedAmount3 = participant.IDIToBeReplacedAmount3;
                censusParticipant.IDIPolicyNumber3 = participant.IDIPolicyNumber3;

                censusParticipant.BenefitDeductionFrequencyDescription = string.IsNullOrEmpty(participant.BenefitDeductionFrequencyDescription) ? string.Empty : GetBenefitDeductionFrequencyDescription(participant.BenefitDeductionFrequencyDescription);

                censusParticipant.BenefitDeductionFrequency = (BenefitDeductionFrequencyTypeEnum?)GetBenefitDeductionFrequencyId(censusParticipant.BenefitDeductionFrequencyDescription);
                censusParticipant.Occupation = participant.Occupation;
                censusParticipant.EmploymentStatus = string.IsNullOrEmpty(participant.EmploymentStatus) ? string.Empty : GetEmploymentStatusDescription(participant.EmploymentStatus);
                censusParticipant.EmploymentStatusType = (EmploymentStatusTypeEnum?)GetEmploymentStatusId(participant?.EmploymentStatus?.Trim());
                censusParticipant.OtherDisabilityInformation = participant.OtherDisabilityInformation;
                censusParticipant.IsOwnerIndicator = participant.IsOwnerIndicator;
                censusParticipant.MostRecentPaidBonusYear = participant.MostRecentPaidBonusYear;
                censusParticipant.PriorPaidBonusYear = participant.PriorPaidBonusYear;
                censusParticipant.AdditionalPriorPaidBonusYear = participant.AdditionalPriorPaidBonusYear;
                censusParticipant.MostRecentPaidCommissionYear = participant.MostRecentPaidCommissionYear;
                censusParticipant.PriorPaidCommissionYear = participant.PriorPaidCommissionYear;
                censusParticipant.AdditionalPriorPaidCommissionYear = participant.AdditionalPriorPaidCommissionYear;
                censusParticipant.MostRecentPaidK1IncomeYear = participant.MostRecentPaidK1IncomeYear;
                censusParticipant.PriorPaidK1IncomeYear = participant.PriorPaidK1IncomeYear;
                censusParticipant.AdditionalPriorPaidK1IncomeYear = participant.AdditionalPriorPaidK1IncomeYear;
                censusParticipant.MostRecentYearPaidW2Income = participant.MostRecentYearPaidW2Income;
                censusParticipant.AdditionalInfo1 = participant.AdditionalInfo1;
                censusParticipant.AdditionalInfo2 = participant.AdditionalInfo2;
                censusParticipant.BaseAMBCalculatedAmount = participant.BaseAMBCalculatedAmount;
                censusParticipant.VGSIBuyUpAMBCalculatedAmount = participant.VGSIBuyUpAMBCalculatedAmount;
                censusParticipant.RPPAMBCalculatedAmount = participant.RPPAMBCalculatedAmount;
                censusParticipant.SocialSecurityNumber = participant.SocialSecurityNumber;
                censusParticipant.Citizenship = participant.Citizenship;
                censusParticipant.AAW = participant.AAW;
                censusParticipant.WeeklyHoursWorked = participant.WeeklyHoursWorked;
                //Changes to be for NBTDI-70
                censusParticipant.IsMicrositeAccess = participant.IsMicrositeAccess.Value;

                //Changes to be for NBTAB-5111
                censusParticipant.ManualBenefitAmount = participant.ManualBenefitAmount;
                censusParticipant.ManualBenefitAMBIncreaseAmount = participant.ManualAMBAmount;
                censusParticipant.ManualVGSIBuyUpBenefitAmount = participant.ManualBuyUpBenefitAmount;
                censusParticipant.ManualRPPAmount = participant.ManualRPPAmount;
                censusParticipant.ManualRPPAMBIncreaseAmount = participant.ManualRPPAMBAmount;
                censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount = participant.ManualBuyUpAMBAmount;
                if (censusParticipant.ManualBenefitAmount > 0 || censusParticipant.ManualBenefitAMBIncreaseAmount > 0
                           || censusParticipant.ManualRPPAmount > 0 || censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount > 0
                           || censusParticipant.ManualRPPAMBIncreaseAmount > 0 || censusParticipant.ManualVGSIBuyUpAMBIncreaseAmount > 0)
                {
                    censusParticipant.ManualOverride = true;
                }
                else { censusParticipant.ManualOverride = false; }
                censusParticipant.CLOASOccupationCode = participant.CLOASOccupationCode;
                if (participant?.OccClass != null && !String.IsNullOrEmpty(participant?.OccClass))
                {
                    OccupationClassTypeEnum occupationClassTypeEnum;
                    occupationClassTypeEnum = (OccupationClassTypeEnum)Enum.Parse(typeof(OccupationClassTypeEnum), "_" + participant.OccClass.Trim().ToUpper(), true);
                    censusParticipant.OccupationClass_Id = (int)occupationClassTypeEnum;
                    censusParticipant.OccupationClassDescription = occupationClassTypeEnum.GetDescription();
                }
                census.CensusParticipants.Add(censusParticipant);
            }

            Log.TraceFormat("-BuildCensusParticipant");
        }


        private string GetBenefitDeductionFrequencyDescription(string benefitDeductionFrequencyDescription)
        {
            if (benefitDeductionFrequencyDescription == "Bi-Weekly" || benefitDeductionFrequencyDescription == "Bi Weekly")
            {
                benefitDeductionFrequencyDescription = BenefitDeductionFrequencyTypeEnum.BiWeekly26Paychecks.GetDescription();
            }
            else if (benefitDeductionFrequencyDescription == "Bi-Monthly" || benefitDeductionFrequencyDescription == "Bi Monthly")
            {
                benefitDeductionFrequencyDescription = BenefitDeductionFrequencyTypeEnum.BiMonthly24weeks.GetDescription();
            }
            else if (benefitDeductionFrequencyDescription == "Semi Monthly")
            {
                benefitDeductionFrequencyDescription = BenefitDeductionFrequencyTypeEnum.SemiMonthly24Paychecks.GetDescription();
            }

            return benefitDeductionFrequencyDescription;
        }
        private string GetEmploymentStatusDescription(string employmentStatusDescription)
        {
            if (employmentStatusDescription == "Full-time" || employmentStatusDescription == "Full Time" || employmentStatusDescription == "F/T")
            {
                employmentStatusDescription = EmploymentStatusTypeEnum.FullTime.GetDescription();
            }
            else if (employmentStatusDescription == "Part-time" || employmentStatusDescription == "Part Time" || employmentStatusDescription == "P/T")
            {
                employmentStatusDescription = EmploymentStatusTypeEnum.PartTime.GetDescription();
            }

            return employmentStatusDescription;
        }
        private OccupationClassAssignmentRequest CreateOccupationClassAssignmentRequest(Participant participant, IQueryable<Participant> censusParticipants,
            PlanDesignRequestClass participantPDRClass, int? companySicMajorGroupTypeId, int? companySicSubGroupTypeId, int classParticipantCount, ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum? premiumPayerandTaxability)
        {
            //Log.TraceFormat("+CreateOccupationClassAssignmentRequest");
            var occupationClassAssignmentRequest = new OccupationClassAssignmentRequest();

            occupationClassAssignmentRequest.ParticipantId = participant.Id;
            occupationClassAssignmentRequest.ParticipantJobTitle = participant.JobTitle;
            occupationClassAssignmentRequest.Occupation = participant.Occupation;
            occupationClassAssignmentRequest.CLOASOccupationCode = participant.CLOASOccupationCode;
            occupationClassAssignmentRequest.CompanySicMajorGroupId = companySicMajorGroupTypeId;
            occupationClassAssignmentRequest.CompanySicSubGroupId = companySicSubGroupTypeId;
            occupationClassAssignmentRequest.ClassParticipantCount = classParticipantCount;
            occupationClassAssignmentRequest.PremiumPayerandTaxability = premiumPayerandTaxability;
            occupationClassAssignmentRequest.MostRecentPaidCommissionAmount = participant.MostRecentPaidCommissionAmount;
            occupationClassAssignmentRequest.PriorPaidCommissionAmount = participant.PriorPaidCommissionAmount;
            occupationClassAssignmentRequest.IDIInsurableIncomeAmount = participant.IDIInsurableIncomeCalculatedAmount;
            occupationClassAssignmentRequest.IsAMBIncreaseIndicator = participant.IsAMBIncreaseIndicator;

            //Log.TraceFormat("-CreateOccupationClassAssignmentRequest");
            return occupationClassAssignmentRequest;
        }

        private void CalculateAmountsForParticipant(Participant participant, BenefitAmountsCalculationRequest preQuoteCalculationRequest)
        {
            //Log.Trace("+CalculateAmountsForParticipant");

            //var stopwatch = new Stopwatch();
            //stopwatch.Start();

            if (preQuoteCalculationRequest == null)
            {

                var classEligibilityConfigurationDto = GetClassEligibilityConfiguration(participant.PlanDesignRequestClass.Id);
                preQuoteCalculationRequest = _preQuoteCalculationManager.CreateCalculationRequestForParticipant(participant, classEligibilityConfigurationDto);

                if (preQuoteCalculationRequest.IsAMBIncreasePolicy || preQuoteCalculationRequest.IsBuyUpAMBIncreaseIndicator)
                {
                    GetGSIPercentageFromPreviousYearPlan(participant, preQuoteCalculationRequest);
                }

            }

            _preQuoteCalculationManager.Calculate(preQuoteCalculationRequest, participant);

            //stopwatch.Stop();
            //Log.Debug($"_preQuoteCalculationManager.CalculateAmountsForParticipant ran'{stopwatch.Elapsed.TotalSeconds}' seconds ('{stopwatch.Elapsed.TotalMilliseconds}' milliseconds)");

            //Log.Trace("-CalculateAmountsForParticipant");
        }

        private void GetGSIPercentageFromPreviousYearPlan(Participant participant, BenefitAmountsCalculationRequest preQuoteCalculationRequest)
        {
            var enrollmentParticipant = participant.EnrollmentCensusParticipants.OrderByDescending(c => c.Id).FirstOrDefault(c => c.Participant.Id == participant.Id);

            if (enrollmentParticipant != null)
            {
                if (enrollmentParticipant.Policies != null)
                {
                    var distinctPolicies = GetDistinctPolicies(enrollmentParticipant.Policies);

                    foreach (var policy in distinctPolicies)
                    {
                        var SelectedPlan = policy.EnrollmentPDRClassOptionPlan;
                        if (SelectedPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary)
                        {
                            preQuoteCalculationRequest.ClassCalculationRequest.BasePlanGSIPercentage = (SelectedPlan.GSIPercentage / 100);
                        }
                        else
                        {
                            preQuoteCalculationRequest.ClassCalculationRequest.BasePlanGSIPercentage = 1.0m;
                            preQuoteCalculationRequest.ClassCalculationRequest.BuyUpPlanGSIPercentage = (SelectedPlan.GSIPercentage / 100);
                        }
                    }
                }
            }
        }

        private IList<EnrollmentParticipantPolicy> GetDistinctPolicies(IList<EnrollmentParticipantPolicy> enrollmentParticipantPolicies)
        {
            var distinctPolicies = new List<EnrollmentParticipantPolicy>();

            var ordredEnrollmentPolicies = enrollmentParticipantPolicies.OrderByDescending(ep => ep.Id);

            var policyNumbers = enrollmentParticipantPolicies.Select(ep => ep.PolicyNumber).Distinct();

            foreach (var policyNumber in policyNumbers)
            {
                var policy = ordredEnrollmentPolicies.FirstOrDefault(oep => oep.PolicyNumber == policyNumber);
                distinctPolicies.Add(policy);
            }

            return distinctPolicies;
        }

        public CensusParticipantDto GetCensusParticipantInformation(int censusParticipantId)
        {
            Log.TraceFormat("+GetCensusParticipantInformation ParticipantId : " + censusParticipantId);
            var censusParticipantDto = new CensusParticipantDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmscensusParticipant = unitOfWork.Repository<Participant>().Linq().FirstOrDefault(c => c.Id == censusParticipantId);

                if (cmscensusParticipant != null)
                {
                    censusParticipantDto.CensusParticipantId = censusParticipantId;
                    censusParticipantDto.EmployeeId = cmscensusParticipant.EmployeeId;
                    censusParticipantDto.ClientReferenceNumber = cmscensusParticipant.ClientReferenceNumber != null ? cmscensusParticipant.ClientReferenceNumber : null;
                    censusParticipantDto.FirstName = cmscensusParticipant.FirstName;
                    censusParticipantDto.MiddleInitial = cmscensusParticipant.MiddleInitial;
                    censusParticipantDto.LastName = cmscensusParticipant.LastName;
                    censusParticipantDto.Suffix = cmscensusParticipant.Suffix;
                    censusParticipantDto.DateOfBirth = cmscensusParticipant.DateOfBirth;
                    censusParticipantDto.DateOfHire = cmscensusParticipant.DateOfHire;
                    censusParticipantDto.Age = cmscensusParticipant.Age;
                    censusParticipantDto.Gender = cmscensusParticipant.Gender != null ? cmscensusParticipant.Gender.ToUpper() : "";
                    censusParticipantDto.PersonalEmail = cmscensusParticipant.PersonalEmail;
                    censusParticipantDto.CellPhone = cmscensusParticipant.CellPhone;
                    censusParticipantDto.HomePhone = cmscensusParticipant.HomePhone;
                    censusParticipantDto.HomeStreet1 = cmscensusParticipant.HomeStreet1;
                    censusParticipantDto.HomeStreet2 = cmscensusParticipant.HomeStreet2;
                    censusParticipantDto.HomeCity = cmscensusParticipant.HomeCity;
                    censusParticipantDto.HomeStateId = (int?)cmscensusParticipant.HomeState;
                    censusParticipantDto.HomeStateDescription = cmscensusParticipant.HomeStateDescription;
                    censusParticipantDto.HomeZipCode = cmscensusParticipant.HomeZipCode;

                    censusParticipantDto.WorkStreet1 = cmscensusParticipant.WorkStreet1;
                    censusParticipantDto.WorkStreet2 = cmscensusParticipant.WorkStreet2;
                    censusParticipantDto.WorkCity = cmscensusParticipant.WorkCity;
                    censusParticipantDto.WorkStateId = (int?)cmscensusParticipant.WorkState;
                    censusParticipantDto.WorkStateDescription = cmscensusParticipant.WorkStateDescription;
                    censusParticipantDto.WorkZipCode = cmscensusParticipant.WorkZipCode;
                    censusParticipantDto.WorkStopCode = cmscensusParticipant.WorkStopCode;
                    censusParticipantDto.WorkLocationPhone = cmscensusParticipant.WorkLocationPhone;
                    censusParticipantDto.WorkLocationExtension = cmscensusParticipant.WorkLocationExtension;
                    censusParticipantDto.WorkEmail = cmscensusParticipant.WorkEmail;

                    censusParticipantDto.OccupationClass_Id = cmscensusParticipant.OccupationClass_Id;
                    censusParticipantDto.OccupationClassDescription = cmscensusParticipant.OccupationClassDescription;
                    censusParticipantDto.JobTitle = cmscensusParticipant.JobTitle;
                    censusParticipantDto.BoardCertification = cmscensusParticipant.BoardCertification;
                    censusParticipantDto.Occupation = cmscensusParticipant.Occupation;
                    censusParticipantDto.EmploymentStatusId = cmscensusParticipant.EmploymentStatusType != null ? (int)cmscensusParticipant.EmploymentStatusType : 0;
                    censusParticipantDto.EmploymentStatus = cmscensusParticipant.EmploymentStatus;
                    censusParticipantDto.TerminationDate = cmscensusParticipant.TerminationDate;
                    censusParticipantDto.WeeklyHoursWorked = cmscensusParticipant.WeeklyHoursWorked;
                    censusParticipantDto.BenefitDeductionFrequency_Id = cmscensusParticipant.BenefitDeductionFrequency != null ? (int?)cmscensusParticipant.BenefitDeductionFrequency : null;
                    censusParticipantDto.BenefitDeductionFrequencyDescription = cmscensusParticipant.BenefitDeductionFrequencyDescription;
                    censusParticipantDto.FrequencyClass = cmscensusParticipant.FrequencyClass;
                    censusParticipantDto.PlanDesignRequestClassId = (cmscensusParticipant.PlanDesignRequestClass != null) ? cmscensusParticipant.PlanDesignRequestClass.Id : 0;
                    censusParticipantDto.IDIInsurableIncomeDefinition = (cmscensusParticipant.PlanDesignRequestClass != null) ? GetInsurableIncomeDefinition(cmscensusParticipant.PlanDesignRequestClass, unitOfWork) : string.Empty;
                    censusParticipantDto.PlanDesignRequestClassEligiblePopulationText = cmscensusParticipant.PlanDesignRequestClassEligiblePopulationText;
                    censusParticipantDto.IsEligible = cmscensusParticipant.IsEligible;
                    censusParticipantDto.IsMicrositeAccess = cmscensusParticipant.IsMicrositeAccess;
                    censusParticipantDto.InEligibleReason_Id = cmscensusParticipant.InEligibleReason_Id;
                    censusParticipantDto.IneligibleReason = cmscensusParticipant?.IneligibleReason?.Split(',')[0]?.Trim();
                    censusParticipantDto.OtherReason = cmscensusParticipant.OtherReason;
                    censusParticipantDto.IDIReplacementCalculatedPercent = cmscensusParticipant.IDIReplacementCalculatedPercent;
                    censusParticipantDto.GroupLTDClass = cmscensusParticipant.GroupLTDClass;
                    censusParticipantDto.LTDCalculatedAmount = cmscensusParticipant.LTDCalculatedAmount;
                    censusParticipantDto.OtherExistingIDICoverageTotalCalculatedAmount = cmscensusParticipant.OtherExistingIDICoverageTotalCalculatedAmount;
                    censusParticipantDto.GuardianExistingIDICoverageTotalCalculatedAmount = cmscensusParticipant.GuardianExistingIDICoverageTotalCalculatedAmount;
                    censusParticipantDto.MostRecentSalaryAmount = cmscensusParticipant.MostRecentSalaryAmount;

                    censusParticipantDto.MostRecentPaidBonusAmount = cmscensusParticipant.MostRecentPaidBonusAmount;
                    censusParticipantDto.PriorPaidBonusAmount = cmscensusParticipant.PriorPaidBonusAmount;
                    censusParticipantDto.AdditionalPriorPaidBonusAmount = cmscensusParticipant.AdditionalPriorPaidBonusAmount;
                    censusParticipantDto.MostRecentPaidCommissionAmount = cmscensusParticipant.MostRecentPaidCommissionAmount;
                    censusParticipantDto.PriorPaidCommissionAmount = cmscensusParticipant.PriorPaidCommissionAmount;
                    censusParticipantDto.AdditionalPriorPaidCommissionAmount = cmscensusParticipant.AdditionalPriorPaidCommissionAmount;
                    censusParticipantDto.MostRecentPaidK1IncomeAmount = cmscensusParticipant.MostRecentPaidK1IncomeAmount;
                    censusParticipantDto.PriorPaidK1IncomeAmount = cmscensusParticipant.PriorPaidK1IncomeAmount;
                    censusParticipantDto.AdditionalPriorPaidK1IncomeAmount = cmscensusParticipant.AdditionalPriorPaidK1IncomeAmount;
                    censusParticipantDto.OtherIncomeAmount = cmscensusParticipant.OtherIncomeAmount;
                    censusParticipantDto.TypeOfIncome = cmscensusParticipant.TypeOfIncome;
                    censusParticipantDto.TotalEmployerOrEmployeeRetirementContributionAmount = cmscensusParticipant.TotalEmployerOrEmployeeRetirementContributionAmount;
                    censusParticipantDto.LTDInsurableIncomeCalculatedAmount = cmscensusParticipant.LTDInsurableIncomeCalculatedAmount;
                    censusParticipantDto.IDIInsurableIncomeCalculatedAmount = cmscensusParticipant.IDIInsurableIncomeCalculatedAmount;
                    censusParticipantDto.MostRecentPaidBonusYear = cmscensusParticipant.MostRecentPaidBonusYear;
                    censusParticipantDto.PriorPaidBonusYear = cmscensusParticipant.PriorPaidBonusYear;
                    censusParticipantDto.AdditionalPriorPaidBonusYear = cmscensusParticipant.AdditionalPriorPaidBonusYear;

                    censusParticipantDto.MostRecentPaidCommissionYear = cmscensusParticipant.MostRecentPaidCommissionYear;
                    censusParticipantDto.PriorPaidCommissionYear = cmscensusParticipant.PriorPaidCommissionYear;
                    censusParticipantDto.AdditionalPriorPaidCommissionYear = cmscensusParticipant.AdditionalPriorPaidCommissionYear;

                    censusParticipantDto.MostRecentPaidK1IncomeYear = cmscensusParticipant.MostRecentPaidK1IncomeYear;
                    censusParticipantDto.PriorPaidK1IncomeYear = cmscensusParticipant.PriorPaidK1IncomeYear;
                    censusParticipantDto.AdditionalPriorPaidK1IncomeYear = cmscensusParticipant.AdditionalPriorPaidK1IncomeYear;

                    censusParticipantDto.CustomLTDInsurableIncomeBaseSalaryPercentage = cmscensusParticipant.CustomLTDInsurableIncomeBaseSalaryPercentage;
                    censusParticipantDto.CustomLTDInsurableIncomeBonusPercentage = cmscensusParticipant.CustomLTDInsurableIncomeBonusPercentage;
                    censusParticipantDto.CustomLTDInsurableIncomeCommissionPercentage = cmscensusParticipant.CustomLTDInsurableIncomeCommissionPercentage;
                    censusParticipantDto.CustomLTDInsurableIncomeOtherIncomePercentage = cmscensusParticipant.CustomLTDInsurableIncomeOtherIncomePercentage;

                    censusParticipantDto.IDICarrierID1 = (int?)cmscensusParticipant.IDICarrier1;
                    censusParticipantDto.IDICarrierID2 = (int?)cmscensusParticipant.IDICarrier2;
                    censusParticipantDto.IDICarrierID3 = (int?)cmscensusParticipant.IDICarrier3;
                    censusParticipantDto.IDICarrierID4 = (int?)cmscensusParticipant.IDICarrier4;
                    censusParticipantDto.IDICarrier1Description = cmscensusParticipant.IDICarrier1Description;
                    censusParticipantDto.IDICarrier2Description = cmscensusParticipant.IDICarrier2Description;
                    censusParticipantDto.IDICarrier3Description = cmscensusParticipant.IDICarrier3Description;
                    censusParticipantDto.IDICarrier4Description = cmscensusParticipant.IDICarrier4Description;
                    censusParticipantDto.IDIBenefitAmount1 = cmscensusParticipant.IDIBenefitAmount1;
                    censusParticipantDto.IDIBenefitAmount2 = cmscensusParticipant.IDIBenefitAmount2;
                    censusParticipantDto.IDIBenefitAmount3 = cmscensusParticipant.IDIBenefitAmount3;
                    censusParticipantDto.IDIBenefitAmount4 = cmscensusParticipant.IDIBenefitAmount4;
                    censusParticipantDto.IDIToBeReplaced1 = cmscensusParticipant.IDIToBeReplaced1;
                    censusParticipantDto.IDIToBeReplaced2 = cmscensusParticipant.IDIToBeReplaced2;
                    censusParticipantDto.IDIToBeReplaced3 = cmscensusParticipant.IDIToBeReplaced3;
                    censusParticipantDto.IDIToBeReplaced4 = cmscensusParticipant.IDIToBeReplaced4;
                    censusParticipantDto.IDIToBeReplacedAmount1 = cmscensusParticipant.IDIToBeReplacedAmount1;
                    censusParticipantDto.IDIToBeReplacedAmount2 = cmscensusParticipant.IDIToBeReplacedAmount2;
                    censusParticipantDto.IDIToBeReplacedAmount3 = cmscensusParticipant.IDIToBeReplacedAmount3;
                    censusParticipantDto.IDIToBeReplacedAmount4 = cmscensusParticipant.IDIToBeReplacedAmount4;
                    censusParticipantDto.PremiumPayerId1 = cmscensusParticipant.PremiumPayerId1;
                    censusParticipantDto.PremiumPayerId2 = cmscensusParticipant.PremiumPayerId2;
                    censusParticipantDto.PremiumPayerId3 = cmscensusParticipant.PremiumPayerId3;
                    censusParticipantDto.PremiumPayerId4 = cmscensusParticipant.PremiumPayerId4;
                    censusParticipantDto.IDIPolicyNumber1 = cmscensusParticipant.IDIPolicyNumber1;
                    censusParticipantDto.IDIPolicyNumber2 = cmscensusParticipant.IDIPolicyNumber2;
                    censusParticipantDto.IDIPolicyNumber3 = cmscensusParticipant.IDIPolicyNumber3;
                    censusParticipantDto.IDIPolicyNumber4 = cmscensusParticipant.IDIPolicyNumber4;
                    censusParticipantDto.EligibleCATCalculatedAmount = cmscensusParticipant.EligibleCATCalculatedAmount;
                    censusParticipantDto.BasePlanPreviousSolicitations = cmscensusParticipant.BasePlanPreviousSolicitations;
                    censusParticipantDto.VGSIPlanPreviousSolicitations = cmscensusParticipant.VGSIPlanPreviousSolicitations;
                    censusParticipantDto.ManualBenefitAmount = cmscensusParticipant.ManualBenefitAmount;
                    censusParticipantDto.ManualVGSIBuyUpBenefitAmount = cmscensusParticipant.ManualVGSIBuyUpBenefitAmount;
                    censusParticipantDto.MostRecentYearPaidW2Income = cmscensusParticipant.MostRecentYearPaidW2Income;
                    censusParticipantDto.IsSpecialHandlingRequired = cmscensusParticipant.IsSpecialHandlingRequired;
                    censusParticipantDto.SpecialHandlingComments = cmscensusParticipant.SpecialHandlingComments;
                    censusParticipantDto.AdditionalInfo1 = cmscensusParticipant.AdditionalInfo1;
                    censusParticipantDto.AdditionalInfo2 = cmscensusParticipant.AdditionalInfo2;
                    censusParticipantDto.OtherDisabilityInformation = cmscensusParticipant.OtherDisabilityInformation;
                    censusParticipantDto.IsOwnerIndicator = cmscensusParticipant.IsOwnerIndicator;
                    censusParticipantDto.ContractState = cmscensusParticipant.ContractState != null ? cmscensusParticipant.ContractState.GetCode() : string.Empty;
                    censusParticipantDto.CaseCompanyLocationName = (!string.IsNullOrWhiteSpace(cmscensusParticipant.CaseCompanyLocationName)) ?
                        cmscensusParticipant.CaseCompanyLocationName :
                        (cmscensusParticipant.PlanDesignRequestClass != null) ? GetDefaultCaseCompanyLocationName(cmscensusParticipant.PlanDesignRequestClass.PlanDesignRequest.Case.Id, cmscensusParticipant) : string.Empty;
                    censusParticipantDto.ParticipantCategoryCodeTypeId = (int?)cmscensusParticipant.ParticipantCategoryCodeType;
                    censusParticipantDto.ParticipantCategoryCodeTypeDescription = cmscensusParticipant.ParticipantCategoryCodeDescription;
                    censusParticipantDto.BuyUpParticipantCategoryCodeTypeId = (int?)cmscensusParticipant.BuyUpParticipantCategoryCodeType;
                    censusParticipantDto.BuyUpParticipantCategoryCodeTypeDescription = cmscensusParticipant.BuyUpParticipantCategoryCodeDescription;
                    censusParticipantDto.SocialSecurityNumber = cmscensusParticipant.SocialSecurityNumber;
                    censusParticipantDto.AAW = cmscensusParticipant.AAW;
                    censusParticipantDto.Citizenship = cmscensusParticipant.Citizenship;
                    //censusParticipantDto.IDIToBeIgnore1 = cmscensusParticipant.IDIToBeIgnore1;
                    //censusParticipantDto.IDIToBeIgnore2 = cmscensusParticipant.IDIToBeIgnore2;
                    //censusParticipantDto.IDIToBeIgnore3 = cmscensusParticipant.IDIToBeIgnore3;
                    //censusParticipantDto.IDIToBeIgnore4 = cmscensusParticipant.IDIToBeIgnore4;

                    censusParticipantDto.IDIToBeIgnore1 = false;
                    censusParticipantDto.IDIToBeIgnore2 = false;
                    censusParticipantDto.IDIToBeIgnore3 = false;
                    censusParticipantDto.IDIToBeIgnore4 = false;
                    censusParticipantDto.ManualRPPAmount = cmscensusParticipant.ManualRPPAmount;
                    censusParticipantDto.ManualBenefitAMBIncreaseAmount = cmscensusParticipant.ManualBenefitAMBIncreaseAmount;
                    censusParticipantDto.ManualRPPAMBIncreaseAmount = cmscensusParticipant.ManualRPPAMBIncreaseAmount;
                    censusParticipantDto.ManualVGSIBuyUpAMBIncreaseAmount = cmscensusParticipant.ManualVGSIBuyUpAMBIncreaseAmount;



                    if (cmscensusParticipant.PlanDesignRequestClass != null)
                    {
                        var cmsPDRSoldClassLTDCoverage = unitOfWork.Repository<PDRSoldClassLTDCoverage>().Linq().FirstOrDefault(c => c.PDRSoldClass.PlanDesignRequestClass.Id == cmscensusParticipant.PlanDesignRequestClass.Id && c.PDRSoldClass.IsActive);
                        if (cmsPDRSoldClassLTDCoverage != null)
                        {
                            censusParticipantDto.GroupLTDCoveredEarningsType = cmsPDRSoldClassLTDCoverage.GroupLTDCoveredEarningsType;
                        }
                        else
                        {
                            var cmsPlanDesignRequestClassLTDCoverage = unitOfWork.Repository<PlanDesignRequestClassLTDCoverage>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == cmscensusParticipant.PlanDesignRequestClass.Id);
                            if (cmsPlanDesignRequestClassLTDCoverage != null)
                            {
                                censusParticipantDto.GroupLTDCoveredEarningsType = cmsPlanDesignRequestClassLTDCoverage.GroupLTDCoveredEarningsType;
                            }
                        }
                    }
                   
                    var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => c.Participant.Id == censusParticipantId).OrderByDescending(x => x.Enrollment.Id).ToList();
                    var pdrSoldClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(x => x.PDRSoldClass.PlanDesignRequestClass.Id == cmscensusParticipant.PlanDesignRequestClass.Id);
                    var basePlan = pdrSoldClassPlan.FirstOrDefault(x => x.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    var voluntaryPlan = pdrSoldClassPlan.FirstOrDefault(x => x.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                    if (enrollmentParticipants.Any())
                    {
                        censusParticipantDto.EnrollmentStatusDto = enrollmentParticipants.Select(e => new EnrollementStatusDto
                        {
                            EnrollmentId = e.Enrollment.Id,
                            EnrollmentName = e.Enrollment.EnrollmentName,
                            BasePlanEnrollementStatusTypeId = (int?)e.BasePlanEnrollmentParticipantStatusType,
                            VGSIEnrollementStatusTypeId = (int?)e.VGSIPlanEnrollmentParticipantStatusType,
                            HasBuyUP = voluntaryPlan != null ? true : false,
                            EnrollmentEffectiveDate = e.Enrollment.EffectiveDate,
                            EnrollmentParticipantId = e.Id
                        }).OrderByDescending(x => x.EnrollmentId).ToList();
                       
                        foreach (EnrollmentParticipant enrollmentParticipant in enrollmentParticipants)
                        {                            
                            var enrollmentParticpantPolicyDto = new EnrollmentParticipantPolicyDto();

                            var basePolicy = enrollmentParticipant.Policies?.Where(j => j.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary)
                                    .OrderByDescending(i => i.Id).FirstOrDefault();

                            var buyupPolicy = enrollmentParticipant.Policies?.Where(j => j.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp)
                               .OrderByDescending(i => i.Id).FirstOrDefault();

                            if (enrollmentParticipant.SelectedEnrollmentPDRClassOption != null)
                            {                                                                                              
                                if (basePolicy != null)
                                {                                   
                                    var optionPlan = basePolicy.EnrollmentPDRClassOptionPlan?.EnrollmentPDRClassOptions?.OrderBy(i => i.Id).FirstOrDefault().OptionCode;
                                    censusParticipantDto.ParticipantSelectedOption.SelectedOptionCodeForBasePlanText = optionPlan;                                                                  
                                }
                                
                                if (buyupPolicy != null)
                                {                                   
                                    var optionPlan = buyupPolicy.EnrollmentPDRClassOptionPlan?.EnrollmentPDRClassOptions?.OrderBy(i => i.Id).FirstOrDefault().OptionCode;
                                    censusParticipantDto.ParticipantSelectedOption.SelectedOptionCodeForVoluntaryPlanText = optionPlan;                                                                      
                                }

                                var enrollmentPDRClass = unitOfWork.Repository<EnrollmentPDRClass>().Linq()
                                    .Where(p => p.Enrollment.Id == enrollmentParticipant.Enrollment.Id &&
                                                p.PlanDesignRequestClass.Id == enrollmentParticipant.Participant.PlanDesignRequestClass.Id)
                                    .SelectMany(c => c.EnrollmentPDRClassOptions)
                                    .Where(o => o.IsSelected)
                                    .SelectMany(o => o.EnrollmentPDRClassOptionPlans);

                                var selectedPlan = enrollmentParticipant.SelectedEnrollmentPDRClassOption?.EnrollmentPDRClassOptionPlans.FirstOrDefault();

                                if (selectedPlan != null)
                                {
                                    if (cmscensusParticipant.IsAMBIncreaseIndicator == true)
                                    {
                                        var enrollmentclass = enrollmentParticipant.SelectedEnrollmentPDRClassOption.EnrollmentPDRClass;
                                        enrollmentPDRClass = unitOfWork.Repository<EnrollmentPDRClass>().Linq()
                                            .Where(c => c.Id == enrollmentclass.Id)
                                            .SelectMany(c => c.EnrollmentPDRClassOptions)
                                            .Where(o => o.IsSelected)
                                            .SelectMany(o => o.EnrollmentPDRClassOptionPlans);
                                    }
                                    if (selectedPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp)
                                    {
                                        var basePlanForGSI = enrollmentPDRClass.Where(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).FirstOrDefault();
                                        if (basePlanForGSI != null)
                                        {
                                            censusParticipantDto.ParticipantSelectedOption.GSIPercentForBasePlan = basePlanForGSI.GSIPercentage;
                                            censusParticipantDto.ParticipantSelectedOption.MaximumBenefitAmountforBasePlan = basePlan.GSIAmount;
                                        }
                                        if (voluntaryPlan != null)
                                        {
                                            censusParticipantDto.ParticipantSelectedOption.GSIPercentForVoluntaryPlan = selectedPlan.GSIPercentage;
                                            censusParticipantDto.ParticipantSelectedOption.MaximumBenefitAmountForVoluntaryPlan = voluntaryPlan.GSIAmount;
                                        }
                                    }
                                    else
                                    {
                                        censusParticipantDto.ParticipantSelectedOption.GSIPercentForBasePlan = selectedPlan.GSIPercentage;
                                        censusParticipantDto.ParticipantSelectedOption.MaximumBenefitAmountforBasePlan = basePlan.GSIAmount;

                                        var volPlanForGSI = enrollmentPDRClass.Where(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp).FirstOrDefault();
                                        if (volPlanForGSI != null && censusParticipantDto.ParticipantSelectedOption.SelectedOptionCodeForVoluntaryPlan != null)
                                        {
                                            censusParticipantDto.ParticipantSelectedOption.GSIPercentForVoluntaryPlan = volPlanForGSI.GSIPercentage;
                                            censusParticipantDto.ParticipantSelectedOption.MaximumBenefitAmountForVoluntaryPlan = voluntaryPlan.GSIAmount;
                                        }
                                    }
                                }                                                                
                            }

                            if (basePolicy != null)
                            {                                
                                enrollmentParticpantPolicyDto.PrimaryPolicyNumber = basePolicy.PolicyNumber;
                                enrollmentParticpantPolicyDto.PrimaryPolicyStatus = basePolicy.PolicyStatusType.ToString();
                                enrollmentParticpantPolicyDto.EnrollmentParticipantId = basePolicy.EnrollmentParticipant.Id;
                                if (basePolicy.EnrollmentParticipantOptionPlan != null)
                                {
                                    enrollmentParticpantPolicyDto.EnrollmentParticipantPrimaryOptionPlanId = basePolicy.EnrollmentParticipantOptionPlan.Id;
                                    enrollmentParticpantPolicyDto.EnrollmentPDRClassOptionPlanId = basePolicy.EnrollmentPDRClassOptionPlan.Id;
                                }
                            }

                            if (buyupPolicy != null)
                            {                                
                                enrollmentParticpantPolicyDto.VGSIPolicyNumber = buyupPolicy.PolicyNumber;
                                enrollmentParticpantPolicyDto.VGSIPolicyStatus = buyupPolicy.PolicyStatusType.ToString();
                                enrollmentParticpantPolicyDto.EnrollmentParticipantBuyUpOptionPlanId = buyupPolicy.EnrollmentParticipantOptionPlan != null ? buyupPolicy.EnrollmentParticipantOptionPlan.Id : 0;
                            }

                            censusParticipantDto.EnrollmentParticipantPolicyDto.Add(enrollmentParticpantPolicyDto);
                            censusParticipantDto.ParticipantSelectedOption.EnrollmentId = enrollmentParticipant.Enrollment.Id;
                            censusParticipantDto.ParticipantSelectedOption.EnrollmentParticipantId = enrollmentParticipant.Id;
                            censusParticipantDto.ParticipantSelectedOptionDto.Add(censusParticipantDto.ParticipantSelectedOption);
                            censusParticipantDto.ParticipantSelectedOption = new ParticipantSelectedOptionDto();
                        }                        
                    }
                    
                    censusParticipantDto.ParticipantExistingPolicy = GetParticipantExistingPolicy(cmscensusParticipant);
                    censusParticipantDto.PlanDesignRequestClassLTDCoverageDto = GetInsurableIncomeDefinition(censusParticipantDto.PlanDesignRequestClassId);
                    censusParticipantDto.IsAMBIncreaseIndicator = cmscensusParticipant.IsAMBIncreaseIndicator;
                    censusParticipantDto.IsBuyUpAMBIncreaseIndicator = cmscensusParticipant.IsBuyUpAMBIncreaseIndicator;
                    censusParticipantDto.BaseAMBCalculatedAmount = cmscensusParticipant.BaseAMBCalculatedAmount;
                    censusParticipantDto.VGSIBuyUpAMBCalculatedAmount = cmscensusParticipant.VGSIBuyUpAMBCalculatedAmount;
                    censusParticipantDto.RPPAMBCalculatedAmount = cmscensusParticipant.RPPAMBCalculatedAmount;
                }
            }
            Log.TraceFormat("-GetCensusParticipantInformation  ParticipantId : " + censusParticipantId);
            return censusParticipantDto;
        }

        private string GetInsurableIncomeDefinition(PlanDesignRequestClass planDesignRequestClass, IUnitOfWork unitOfWork)
        {
            string insurableIncomeDefinition = string.Empty;

            var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == planDesignRequestClass.Id && c.IsActive == true);

            if (pdrSoldClass != null)
            {
                insurableIncomeDefinition = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault().InsurableIncomeDefinition;
            }
            else
            {
                insurableIncomeDefinition = planDesignRequestClass.InsurableIncomeDefinition;
            }

            return insurableIncomeDefinition;
        }

        private EnrollmentParticipantPolicyDto GetEnrollmentParticipantPolicy(IUnitOfWork unitOfWork, int censusParticipantId)
        {
            var enrollmentParticpantPolicyDto = new EnrollmentParticipantPolicyDto();
            var enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                .Where(c => c.Participant.Id == censusParticipantId)
                .OrderByDescending(c => c.Enrollment).FirstOrDefault();

            if (enrollmentParticipant != null)
            {
                var enrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().Where(c => c.EnrollmentParticipant.Id == enrollmentParticipant.Id).OrderByDescending(i => i.Id).Take(2).ToList();
                if (enrollmentParticipantPolicy.Any())
                {
                    var primaryPDRClassPlan = enrollmentParticipantPolicy.FirstOrDefault(c => c.EnrollmentPDRClassOptionPlan != null ? c.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary : false);
                    if (primaryPDRClassPlan != null)
                    {
                        enrollmentParticpantPolicyDto.PrimaryPolicyNumber = primaryPDRClassPlan.PolicyNumber;
                        enrollmentParticpantPolicyDto.PrimaryPolicyStatus = primaryPDRClassPlan.PolicyStatusType.ToString();
                    }
                    var buyUpPDRClassPlan = enrollmentParticipantPolicy.FirstOrDefault(c => c.EnrollmentPDRClassOptionPlan != null ? c.EnrollmentPDRClassOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp : false);
                    if (buyUpPDRClassPlan != null)
                    {
                        enrollmentParticpantPolicyDto.VGSIPolicyNumber = buyUpPDRClassPlan.PolicyNumber;
                        enrollmentParticpantPolicyDto.VGSIPolicyStatus = buyUpPDRClassPlan.PolicyStatusType.ToString();
                    }
                }
            }
            return enrollmentParticpantPolicyDto;
        }

        

        private ParticipantExistingPolicyDto GetParticipantExistingPolicy(Participant cmscensusParticipant)
        {
            Log.TraceFormat("+GetParticipantExistingPolicy");
            var participantExistingPolicyDto = new ParticipantExistingPolicyDto();
            var participantExistingPolicy = cmscensusParticipant.ParticipantExistingPolicies.FirstOrDefault();

            if (participantExistingPolicy != null)
            {
                var participantExistingPolicyDetails = participantExistingPolicy.ParticipantExistingPolicyDetails.GroupBy(c => c.PolicyNumber).Select(g => g.First()).ToList(); //why we need to that condition

                if (participantExistingPolicyDetails.Any())
                {
                    participantExistingPolicyDto.ParticipantExistingPolicyId = participantExistingPolicy.Id;
                    participantExistingPolicyDto.ParticipantId = cmscensusParticipant.Id;
                    if (participantExistingPolicyDetails.Where(c => c.CLOASPolicyStatus != "Rejected" && (c.CLOASPolicyStatus == "Inforce" || c.CLOASPolicyStatus == "Inforce-Claim" || c.CLOASPolicyStatus == "Pending")).Any())
                    {
                        participantExistingPolicyDto.GSIIDIBaseAMB = participantExistingPolicy.GSIIDIBaseAMB != null ? participantExistingPolicy.GSIIDIBaseAMB : null;
                        participantExistingPolicyDto.GSIRPPBaseAMB = participantExistingPolicy.GSIRPPBaseAMB != null ? participantExistingPolicy.GSIRPPBaseAMB : null;
                        participantExistingPolicyDto.FullyUnderwrittenIDI = participantExistingPolicy.FullyUnderwrittenIDI != null ? participantExistingPolicy.FullyUnderwrittenIDI : null;
                        participantExistingPolicyDto.FullyUnderwrittenRPP = participantExistingPolicy.FullyUnderwrittenRPP != null ? participantExistingPolicy.FullyUnderwrittenRPP : null;
                    }
                    participantExistingPolicyDto.ParticipantExistingPolicyDetails = participantExistingPolicyDetails.Select(e => new ParticipantExistingPolicyDetailDto
                    {
                        ParticipantExistingPolicyDetailId = e.Id,
                        ParticipantExistingPolicyId = e.ParticipantExistingPolicy.Id,
                        PolicyNumber = e.PolicyNumber != null ? e.PolicyNumber : null,
                        Product = e.Product != null ? e.Product : null,
                        PlanCode = e.PlanCode != null ? e.PlanCode : null,
                        MonthlyIndemnity = e.MonthlyIndemnity != null ? e.MonthlyIndemnity : null,
                        CLOASPolicyStatus = e.CLOASPolicyStatus != null ? e.CLOASPolicyStatus : null,
                        CLOASRejectionType = e.CLOASRejectionType != null ? e.CLOASRejectionType : null,
                        CaseNumber = e.CaseNumber != null ? e.CaseNumber : null,
                        PremiumPayer = e.PremiumPayer != null ? e.PremiumPayer : null,
                        PolicyEffectiveDate = e.PolicyEffectiveDate != null ? e.PolicyEffectiveDate : null,
                        AnnualizedPremium = e.AnnualizedPremium != null ? e.AnnualizedPremium : null,
                        ModalPremium = e.ModalPremium != null ? e.ModalPremium : null,
                        BillingModeTypeDescription = e.BillingModeTypeDescription != null ? e.BillingModeTypeDescription : null,
                        RiskClassTobaccoStatus = e.RiskClassTobaccoStatus != null ? e.RiskClassTobaccoStatus : null,
                        OccupationClassDescription = e.OccupationClassDescription != null ? e.OccupationClassDescription : null,
                        Discount = e.Discount != null ? e.Discount : null,
                        EliminationPeriodDescription = e.EliminationPeriodDescription != null ? e.EliminationPeriodDescription : null,
                        BenefitPeriodDescription = e.BenefitPeriodDescription != null ? e.BenefitPeriodDescription : null,
                        ContractStateDescription = e.ContractStateDescription != null ? e.ContractStateDescription : null,
                        ResidentStateDescription = e.ResidentStateDescription != null ? e.ResidentStateDescription : null,
                        DefinitionOfTotalDisabilityType = e.DefinitionOfTotalDisabilityType != null ? e.DefinitionOfTotalDisabilityType : null,
                        AMBAmount = e.AMBAmount != null ? e.AMBAmount : null,
                        MentalSubstanceLimitationTypeDescription = e.MentalSubstanceLimitationType != null ? e.MentalSubstanceLimitationType : null,
                        PreExistingConditionLimitationTypeDescription = e.PreExistingConditionLimitationType != null ? e.PreExistingConditionLimitationType : null,
                        IsPolicyMatch = e.IsPolicyMatch != null ? e.IsPolicyMatch : null,
                        IsTerminateAndReplace = e.IsTerminateAndReplace,
                        IsCompactState = e.IsCompactState,
                        TitanPriorCoverageSearchGrouping = e.TitanPriorCoverageSearchGrouping != null ? e.TitanPriorCoverageSearchGrouping : null,
                        ParticipantExistingPolicyRiders = e.ParticipantExistingPolicyRiders.Select(r => new ParticipantExistingPolicyRiderDto
                        {
                            ParticipantExistingPolicyRiderId = r.Id,
                            ParticipantExistingPolicyDetailId = r.ParticipantExistingPolicyDetail.Id,
                            RiderName = r.RiderName,
                            RiderValueDescription = r.RiderValueDescription,
                            RiderIndemnityAmountLabel = r.RiderIndemnityAmountLabel,
                            Amount = r.Amount
                        }).ToList()
                    }).ToList();
                    if (participantExistingPolicyDto.ParticipantExistingPolicyDetails.Any())
                    {
                        foreach (var existingPolicy in participantExistingPolicyDto.ParticipantExistingPolicyDetails)
                        {
                            PopulateParticipantExistingPolicyProducersandServicingAgency(existingPolicy, cmscensusParticipant.Id.ToString());
                        }
                    }
                }
            }
            Log.TraceFormat("+GetParticipantExistingPolicy");
            return participantExistingPolicyDto;
        }

        private void PopulateParticipantExistingPolicyProducersandServicingAgency(ParticipantExistingPolicyDetailDto existingPolicy, string participantId)
        {
            var cloasClientReferenceNumber = participantId;
            var policyNumber = existingPolicy.PolicyNumber;
            var policyProducers = _brokerService.GetServicingNonServicingProducers(policyNumber, cloasClientReferenceNumber);
            if (policyProducers.Any())
            {

                existingPolicy.ParticipantExistingPolicyProducers = policyProducers.Select(p =>
                                                                        new ParticipantExistingPolicyProducerDto()
                                                                        {
                                                                            CloasClientReferenceNumber = p.CloasClientReferenceNumber,
                                                                            IsServicingProducer = p.IsServicingProducer,
                                                                            PolicyNumber = p.PolicyNumber,
                                                                            ProducerName = p.ProducerName,
                                                                            ProducerPercent = p.ProducerPercent,
                                                                            ProducerWritingCode = p.ProducerWritingCode
                                                                        }).ToList();
                existingPolicy.ServicingAgency = existingPolicy.ParticipantExistingPolicyProducers.FirstOrDefault(p => p.IsServicingProducer);
            }
        }

        public void SaveReCalculations(IllustrationRequest request)
        {
            Log.TraceFormat("+SaveReCalculations");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignRequestClasses = unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(i => i.PlanDesignRequest.Id == request.PlanDesignRequestId);

                foreach (var illustrationRequestClass in request.Classes)
                {
                    var planDesignRequestClass = planDesignRequestClasses.FirstOrDefault(c => c.Id == illustrationRequestClass.TitanClassId);
                    if (planDesignRequestClass != null && planDesignRequestClass.CensusParticipants.Any())
                    {
                        ApplyRecalculationByPDRClass(unitOfWork, planDesignRequestClass);
                    }
                }
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveReCalculations");
        }


        private void ApplyRecalculationByPDRClass(IUnitOfWork unitOfWork, PlanDesignRequestClass planDesignRequestClass)
        {
            Log.TraceFormat("+ApplyRecalculationByParticipant");

            var preQuoteCalculationRequest = new BenefitAmountsCalculationRequest();

            var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(p => p.PlanDesignRequestClass.Id == planDesignRequestClass.Id && p.IsActive);
            if (pdrSoldClass != null && pdrSoldClass.PlanDesignRequestClass.CensusParticipants.Any())
            {
                _preQuoteCalculationManager.BuildPreQuoteCalculationRequestForSoldClass(pdrSoldClass, preQuoteCalculationRequest);
            }
            else
            {
                preQuoteCalculationRequest = _preQuoteCalculationManager.CreateCalculationRequestForPDRClass(planDesignRequestClass);
            }

            foreach (var participant in planDesignRequestClass.CensusParticipants)
            {
                if (pdrSoldClass != null && pdrSoldClass.PlanDesignRequestClass.CensusParticipants.Any())
                {
                    var pdrSoldClassPlan = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    preQuoteCalculationRequest.ClassCalculationRequest.PrimaryGSIAmount = pdrSoldClassPlan.GSIAmount;
                    preQuoteCalculationRequest.ClassCalculationRequest.ApprovedTotalGSIAmount = pdrSoldClassPlan.GSIAmount;
                }
                else
                {
                    var primarPlanProduct = planDesignRequestClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == false);

                    if (primarPlanProduct != null)
                    {
                        preQuoteCalculationRequest.ClassCalculationRequest.PrimaryGSIAmount = primarPlanProduct.GSIAmount;
                        preQuoteCalculationRequest.ClassCalculationRequest.ApprovedTotalGSIAmount = primarPlanProduct.GSIAmount;
                    }
                }

                preQuoteCalculationRequest.MostRecentW2IncomeAmount = participant.MostRecentYearPaidW2Income;
                preQuoteCalculationRequest.HomeState = participant.HomeState;
                preQuoteCalculationRequest.MostRecentSalaryAmount = participant.MostRecentSalaryAmount;
                preQuoteCalculationRequest.MostRecentPaidBonusAmount = participant.MostRecentPaidBonusAmount;
                preQuoteCalculationRequest.PriorPaidBonusAmount = participant.PriorPaidBonusAmount;
                preQuoteCalculationRequest.AdditionalPriorPaidBonusAmount = participant.AdditionalPriorPaidBonusAmount;
                preQuoteCalculationRequest.MostRecentPaidCommissionAmount = participant.MostRecentPaidCommissionAmount;
                preQuoteCalculationRequest.PriorPaidCommissionAmount = participant.PriorPaidCommissionAmount;
                preQuoteCalculationRequest.AdditionalPriorPaidCommissionAmount = participant.AdditionalPriorPaidCommissionAmount;
                preQuoteCalculationRequest.MostRecentPaidK1IncomeAmount = participant.MostRecentPaidK1IncomeAmount;
                preQuoteCalculationRequest.PriorPaidK1IncomeAmount = participant.PriorPaidK1IncomeAmount;
                preQuoteCalculationRequest.AdditionalPriorPaidK1IncomeAmount = participant.AdditionalPriorPaidK1IncomeAmount;
                preQuoteCalculationRequest.OtherIncomeAmount = participant.OtherIncomeAmount;
                preQuoteCalculationRequest.TotalEmployerOrEmployeeRetirementContributionAmount = participant.TotalEmployerOrEmployeeRetirementContributionAmount;
                preQuoteCalculationRequest.ParticipantDateOfBirth = participant.DateOfBirth;

                var idiReplacementRequests = new List<IDIReplacementPercentRequest>();
                idiReplacementRequests.Add(AssignReplacementPercentRequest(participant.IDIBenefitAmount1, participant.IDIToBeReplaced1, participant.IDICarrier1, participant.IDIToBeReplacedAmount1, participant.IDIToBeIgnore1));
                idiReplacementRequests.Add(AssignReplacementPercentRequest(participant.IDIBenefitAmount2, participant.IDIToBeReplaced2, participant.IDICarrier2, participant.IDIToBeReplacedAmount2, participant.IDIToBeIgnore2));
                idiReplacementRequests.Add(AssignReplacementPercentRequest(participant.IDIBenefitAmount3, participant.IDIToBeReplaced3, participant.IDICarrier3, participant.IDIToBeReplacedAmount3, participant.IDIToBeIgnore3));
                idiReplacementRequests.Add(AssignReplacementPercentRequest(participant.IDIBenefitAmount4, participant.IDIToBeReplaced4, participant.IDICarrier4, participant.IDIToBeReplacedAmount4, participant.IDIToBeIgnore4));
                preQuoteCalculationRequest.IDIReplacementPercentRequests = idiReplacementRequests;

                if (participant.ParticipantExistingPolicies.Any())
                {
                    var participantExistingPolicy = participant.ParticipantExistingPolicies.FirstOrDefault();
                    if (preQuoteCalculationRequest.IDIReplacementPercentRequests.Any())
                    {
                        decimal? idiGuardianBenefitAmount = preQuoteCalculationRequest.IDIReplacementPercentRequests.Where(i => i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Berkshire || i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Guardian)
                                                                                     .Sum(j => j.IDIBenefitAmount);
                        decimal? idiGuardianReplacementAmount = preQuoteCalculationRequest.IDIReplacementPercentRequests.Where(i => i.IsReplaceCoverage == true && (i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Berkshire || i.IDICarrier_Id == IDICoverageCarrierTypeEnum.Guardian))
                                                                                           .Sum(j => j.IDIReplacementAmount);

                        decimal? idiOtherBenefitAmount = preQuoteCalculationRequest.IDIReplacementPercentRequests.Where(i => i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Berkshire && i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Guardian)
                                                                                         .Sum(j => j.IDIBenefitAmount);
                        decimal? idiOtherReplacementAmount = preQuoteCalculationRequest.IDIReplacementPercentRequests.Where(i => i.IsReplaceCoverage == true && (i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Berkshire && i.IDICarrier_Id != IDICoverageCarrierTypeEnum.Guardian))
                                                                                            .Sum(j => j.IDIReplacementAmount);

                        preQuoteCalculationRequest.GSIIDIBaseAMBAmount = (idiGuardianBenefitAmount.HasValue ? idiGuardianBenefitAmount : 0.0m) - (idiGuardianReplacementAmount.HasValue ? idiGuardianReplacementAmount : 0.0m);
                        //Below line is not required as per NBTC-3088
                        //preQuoteCalculationRequest.FullyUnderWrittenIDIAmount = (idiOtherBenefitAmount.HasValue ? idiOtherBenefitAmount : 0.0m) - (idiOtherReplacementAmount.HasValue ? idiOtherReplacementAmount : 0.0m);
                    }

                    if (participantExistingPolicy.ParticipantExistingPolicyDetails.Any())
                    {
                        var policyDetails = participantExistingPolicy.ParticipantExistingPolicyDetails;
                        preQuoteCalculationRequest.BaseGSIMaxAmount = policyDetails.Where(i => i.PremiumPayer != null && i.PremiumPayer.ToUpper() == "EMPLOYER" && i.IsTerminateAndReplace == false).Sum(j => j.MonthlyIndemnity);
                        preQuoteCalculationRequest.VGSIBuyUpMaxAmount = policyDetails.Where(i => i.PremiumPayer != null && i.PremiumPayer.ToUpper() == "EMPLOYEE" && i.IsTerminateAndReplace == false).Sum(j => j.MonthlyIndemnity);
                    }

                    if (participantExistingPolicy.FullyUnderwrittenIDI != null && participantExistingPolicy.FullyUnderwrittenIDI > 0)
                    {
                        preQuoteCalculationRequest.FullyUnderWrittenIDIAmount = participantExistingPolicy.FullyUnderwrittenIDI;
                    }

                    if (participantExistingPolicy.GSIIDIBaseAMB != null && participantExistingPolicy.GSIIDIBaseAMB > 0)
                    {
                        preQuoteCalculationRequest.GSIIDIBaseAMBAmount = participantExistingPolicy.GSIIDIBaseAMB;
                    }

                    //Fixing INC2412851 - Fully Underwriten coverage  FUW not calculating correctly in Production - DFCT0051077
                    if (participantExistingPolicy.GSIIDIBaseAMB == null && (participantExistingPolicy.FullyUnderwrittenIDI != null && participantExistingPolicy.FullyUnderwrittenIDI > 0))
                    {
                        preQuoteCalculationRequest.GSIIDIBaseAMBAmount = 0;
                    }

                    preQuoteCalculationRequest.GSIRPPBaseAMBAmount = participantExistingPolicy.GSIRPPBaseAMB;
                    preQuoteCalculationRequest.FullyUnderWrittenRPPAmount = participantExistingPolicy.FullyUnderwrittenRPP;
                }

                CalculateAmountsForParticipant(participant, preQuoteCalculationRequest);

                unitOfWork.Repository<Participant>().Save(participant);
            }
            Log.TraceFormat("-ApplyRecalculationByParticipant");
        }

        public void CustomizedReCalculation(int planDesignRequestClassId, bool isSold)
        {
            Log.TraceFormat("+CustomizedReCalculation");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrClassId = planDesignRequestClassId;
                if (isSold)
                {
                    var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.Id == pdrClassId && c.IsActive);
                    if (pdrSoldClass != null)
                    {
                        pdrClassId = pdrSoldClass.PlanDesignRequestClass.Id;
                    }
                    else
                    {
                        pdrClassId = 0;
                    }
                }
                var censusParticipants = unitOfWork.Repository<Participant>().Linq().Where(c => c.PlanDesignRequestClass.Id == pdrClassId);
                if (censusParticipants != null)
                {
                    var selectedParticipants = censusParticipants.Select(i => i.Id).ToList();

                    PerformOperation(selectedParticipants, CensusManagerOperation.BenefitAmountCalculations);
                }
            }

            Log.TraceFormat("-CustomizedReCalculation");
        }

        public void RunEligibilityForPDR(int planDesignRequestId)
        {
            Log.TraceFormat("+RunEligibilityForPDR");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignRequestClasses = unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.PlanDesignRequest.Id == planDesignRequestId && c.IsActive);
                if (planDesignRequestClasses.Any())
                {
                    foreach (var planDesignRequestClass in planDesignRequestClasses)
                    {
                        Log.TraceFormat("+Looping through PlanDesignRequestClass. Id = " + planDesignRequestClass.Id);
                        var participants = unitOfWork.Repository<Participant>().Linq()
                            .Where(p => (p.PlanDesignRequestClass != null && p.PlanDesignRequestClass.Id == planDesignRequestClass.Id)
                            && (p.IsEligible == true || p.IsEligible == null) && p.IsActive == true).Select(c => c.Id).ToList();

                        if (participants.Any())
                        {
                            PerformOperation(participants, CensusManagerOperation.BenefitAmountCalculations);
                            PerformOperation(participants, CensusManagerOperation.EligibilityDetermination);
                        }
                        Log.TraceFormat("-Looping through PlanDesignRequestClass. Id = " + planDesignRequestClass.Id);
                    }
                }
            }
            Log.TraceFormat("-RunEligibilityForPDR");
        }

        public IList<IndividualDisabilityCoverageDto> GetIndividualDisabilityCoverageByCensusParticipantId(int censusParticipantId)
        {
            Log.TraceFormat("+GetIndividualDisabilityCoverageByCensusParticipantId");
            var individualDisabilityCoverageDetails = new List<IndividualDisabilityCoverageDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var listOfIDICoverage = unitOfWork.Repository<IndividualDisabilityCoverage>().Linq().Where(individualDisabilityCoverage => individualDisabilityCoverage.Participant.Id == censusParticipantId).ToList();
                individualDisabilityCoverageDetails = listOfIDICoverage.Select(individualDisabilityCoverageDto => new IndividualDisabilityCoverageDto
                {
                    ParticipantId = individualDisabilityCoverageDto.Participant.Id,
                    CarrierId = individualDisabilityCoverageDto.CarrierId,
                    Status = (IndividualDisabilityCoverageStatusTypeEnum)Enum.Parse(typeof(IndividualDisabilityCoverageStatusTypeEnum), individualDisabilityCoverageDto.Status, true),
                    BenefitAmount = individualDisabilityCoverageDto.BenefitAmount,
                    IsReplaceable = individualDisabilityCoverageDto.IsReplaceable,
                    ReplacementAmount = individualDisabilityCoverageDto.ReplacementAmount,
                    PremiumPayer = individualDisabilityCoverageDto.PremiumPayer,
                    PolicyNumber = individualDisabilityCoverageDto.PolicyNumber,
                    CreatedAt = individualDisabilityCoverageDto.CreatedAt,
                    CreatedBy = individualDisabilityCoverageDto.CreatedBy,
                    UpdatedAt = individualDisabilityCoverageDto.UpdatedAt,
                    UpdatedBy = individualDisabilityCoverageDto.UpdatedBy
                }).ToList();
            }
            Log.TraceFormat("-GetIndividualDisabilityCoverageByCensusParticipantId");
            return individualDisabilityCoverageDetails;
        }

        private IDIReplacementPercentRequest AssignReplacementPercentRequest(decimal? idiBenefitAmount, bool? isReplaceCoverage, IDICoverageCarrierTypeEnum? idiCoverageCarrier_Id, decimal? idiReplacementAmount, bool? isIgnoreCoverage)
        {
            var idiReplacementPercentRequest = new IDIReplacementPercentRequest
            {
                IDIBenefitAmount = idiBenefitAmount ?? 0.0m,
                IsReplaceCoverage = isReplaceCoverage,
                IDICarrier_Id = idiCoverageCarrier_Id,
                IDIReplacementAmount = idiReplacementAmount.HasValue ? idiReplacementAmount : 0.0m,
                IsIgnoreCoverage = isIgnoreCoverage
            };
            return idiReplacementPercentRequest;
        }

        private int? GetStateId(string stateName)
        {
            int? stateId = null;
            if (stateName == null) return stateId;
            var state = _lookupManager.GetValuesForEnum(StateTypeEnum.AK).Where(c => c.Code == stateName.Trim());
            if (state.Any())
            {
                stateId = state.First().Id;
            }
            return stateId;
        }

        private int? GetCarrierId(string carrierName)
        {
            int? carrierId = null;
            if (carrierName == null) return carrierId;
            var carrier = _lookupManager.GetValuesForEnum(IDICoverageCarrierTypeEnum.Ameritas).Where(c => c.Code == carrierName);
            if (carrier.Any())
            {
                carrierId = carrier.First().Id;
            }
            return carrierId;
        }

        private int? GetEmploymentStatusId(string employmentStatus)
        {
            int? employmentStatusId = null;
            if (employmentStatus == null) return employmentStatusId;
            var employmentStatusType = _lookupManager.GetValuesForEnum(EmploymentStatusTypeEnum.FullTime).Where(c => c.Description == employmentStatus.Trim());
            if (employmentStatusType.Any())
            {
                employmentStatusId = employmentStatusType.First().Id;
            }
            return employmentStatusId;
        }

        private static List<CensusPlanDesignRequestClassDto> GetFixedClassData(int censusPlanDesignRequestId)
        {
            Log.TraceFormat("+GetFixedClassData");

            List<CensusPlanDesignRequestClassDto> censusFixedClassDataList = new List<CensusPlanDesignRequestClassDto>();

            CensusPlanDesignRequestClassDto censusFixedClassErrorData = new CensusPlanDesignRequestClassDto
            {
                CensusPlanDesignRequestId = censusPlanDesignRequestId,
                CensusPlanDesignRequestClassId = (int)CensusClassTypeEnum.Error,
                CensusPlanDesignRequestClass = (CensusClassTypeEnum.Error).GetCode(),
                CensusRequestedEligiblePopulationText = "",
                CensusApprovedEligiblePopulationText = (CensusClassTypeEnum.Error).GetDescription()
            };

            censusFixedClassDataList.Add(censusFixedClassErrorData);

            CensusPlanDesignRequestClassDto censusFixedClassUnassignedData = new CensusPlanDesignRequestClassDto
            {
                CensusPlanDesignRequestId = censusPlanDesignRequestId,
                CensusPlanDesignRequestClassId = (int)CensusClassTypeEnum.Unassigned,
                CensusPlanDesignRequestClass = (CensusClassTypeEnum.Unassigned).GetCode(),
                CensusRequestedEligiblePopulationText = "",
                CensusApprovedEligiblePopulationText = (CensusClassTypeEnum.Unassigned).GetDescription()
            };
            censusFixedClassDataList.Add(censusFixedClassUnassignedData);

            CensusPlanDesignRequestClassDto censusFixedClassIneligibleData = new CensusPlanDesignRequestClassDto
            {
                CensusPlanDesignRequestId = censusPlanDesignRequestId,
                CensusPlanDesignRequestClassId = (int)CensusClassTypeEnum.Ineligible,
                CensusPlanDesignRequestClass = (CensusClassTypeEnum.Ineligible).GetCode(),
                CensusRequestedEligiblePopulationText = "",
                CensusApprovedEligiblePopulationText = (CensusClassTypeEnum.Ineligible).GetDescription()
            };
            censusFixedClassDataList.Add(censusFixedClassIneligibleData);

            CensusPlanDesignRequestClassDto censusFixedClassAllData = new CensusPlanDesignRequestClassDto
            {
                CensusPlanDesignRequestId = censusPlanDesignRequestId,
                CensusPlanDesignRequestClassId = (int)CensusClassTypeEnum.All,
                CensusPlanDesignRequestClass = (CensusClassTypeEnum.All).GetCode(),
                CensusRequestedEligiblePopulationText = "",
                CensusApprovedEligiblePopulationText = (CensusClassTypeEnum.All).GetDescription()
            };
            censusFixedClassDataList.Add(censusFixedClassAllData);

            Log.TraceFormat("-GetFixedClassData");

            return censusFixedClassDataList;

        }
        private void SaveEditedParticipantsToDatabase(List<EditParticipantDto> participants, List<EditEnrollmentParticipantDto> enrollmentParticipants)
        {
            Log.TraceFormat("+SaveEditedParticipantsToDatabase");

            try
            {
                var splittedParticipants = participants.ChunkBy(500);
                Parallel.ForEach(splittedParticipants, p =>
                {
                    var auditParticipants = p
                    .Select(x => new
                    {
                        ParticipantId = x.Participant_Id,
                        IsEligible = x.IsEligible,
                        InEligibleReasonId = x.InEligibleReason_Id,
                        IneligibleReason = x.IneligibleReason,
                        OtherReason = x.OtherReason
                    }).ToList();

                    var obj = "+SaveEditedParticipantsToDatabase : " + JsonConvert.SerializeObject(auditParticipants);
                    Log.Trace($"{obj}");
                });
            }
            catch (Exception e)
            {
                Log.Error(e);
            }

            string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");
            DataTable participantTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(participants));

            if (!enrollmentParticipants.Any())
            {
                enrollmentParticipants.Add(new EditEnrollmentParticipantDto
                {
                    EnrollmentParticipant_Id = -1
                });
            }

            DataTable enrollmentParticipantTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(enrollmentParticipants));

            using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
            {
                SqlCommand command = sqlConnection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 1500;//in seconds
                command.CommandText = "[cms].[USP_EditMultipleParticipant]";

                SqlParameter parameter1 = new SqlParameter();
                parameter1.ParameterName = "@ParticipantTableVariable";
                parameter1.SqlDbType = SqlDbType.Structured;
                parameter1.Value = participantTable;
                command.Parameters.Add(parameter1);

                SqlParameter parameter2 = new SqlParameter();
                parameter2.ParameterName = "@EnrollmentParticipantTableVariable";
                parameter2.SqlDbType = SqlDbType.Structured;
                parameter2.Value = enrollmentParticipantTable;
                command.Parameters.Add(parameter2);

                sqlConnection.Open();
                int numberOfRowsUpdated = command.ExecuteNonQuery();
            }

            Log.TraceFormat("-SaveEditedParticipantsToDatabase");
        }


        private PlanDesignRequestClassLTDCoverageDto GetInsurableIncomeDefinition(int planDesignRequestClassId)
        {
            var planDesignRequestClassLTDCoverageDto = new PlanDesignRequestClassLTDCoverageDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrSoldClassLTDCoverage = unitOfWork.Repository<PDRSoldClassLTDCoverage>().Linq().Where(x => x.PDRSoldClass.PlanDesignRequestClass.Id == planDesignRequestClassId && x.PDRSoldClass.IsActive).FirstOrDefault();

                if (pdrSoldClassLTDCoverage != null)
                {
                    planDesignRequestClassLTDCoverageDto.BaseSalaryPercentage = pdrSoldClassLTDCoverage.BaseSalaryPercentage.ToViewPercentage();
                    planDesignRequestClassLTDCoverageDto.BonusPercentage = pdrSoldClassLTDCoverage.BonusPercentage.ToViewPercentage();
                    planDesignRequestClassLTDCoverageDto.CommissionPercentage = pdrSoldClassLTDCoverage.CommissionPercentage.ToViewPercentage();
                    planDesignRequestClassLTDCoverageDto.K1EarningsPercentage = pdrSoldClassLTDCoverage.K1EarningsPercentage.ToViewPercentage();
                    planDesignRequestClassLTDCoverageDto.OtherIncomePercentage = pdrSoldClassLTDCoverage.OtherIncomePercentage.ToViewPercentage();
                }
                else
                {
                    var planDesignRequestClassLTDCoverage = unitOfWork.Repository<PlanDesignRequestClassLTDCoverage>().Linq().Where(x => x.PlanDesignRequestClass.Id == planDesignRequestClassId).FirstOrDefault();
                    if (planDesignRequestClassLTDCoverage != null)
                    {
                        planDesignRequestClassLTDCoverageDto.BaseSalaryPercentage = planDesignRequestClassLTDCoverage.BaseSalaryPercentage.ToViewPercentage();
                        planDesignRequestClassLTDCoverageDto.BonusPercentage = planDesignRequestClassLTDCoverage.BonusPercentage.ToViewPercentage();
                        planDesignRequestClassLTDCoverageDto.CommissionPercentage = planDesignRequestClassLTDCoverage.CommissionPercentage.ToViewPercentage();
                        planDesignRequestClassLTDCoverageDto.K1EarningsPercentage = planDesignRequestClassLTDCoverage.K1EarningsPercentage.ToViewPercentage();
                        planDesignRequestClassLTDCoverageDto.OtherIncomePercentage = planDesignRequestClassLTDCoverage.OtherIncomePercentage.ToViewPercentage();
                    }
                }
            }
            return planDesignRequestClassLTDCoverageDto;
        }

        private int? GetBenefitDeductionFrequencyId(string benefitDeductionFrequencyDescription)
        {
            int? benefitDeductionFrequencyId = null;
            if (string.IsNullOrEmpty(benefitDeductionFrequencyDescription))
            {
                return benefitDeductionFrequencyId;
            }
            var benefitDeductionFrequencyType = _lookupManager.GetValuesForEnum(BenefitDeductionFrequencyTypeEnum.Annual).Where(c => c.Description == benefitDeductionFrequencyDescription);
            if (benefitDeductionFrequencyType.Any())
            {
                benefitDeductionFrequencyId = benefitDeductionFrequencyType.First().Id;
            }
            return benefitDeductionFrequencyId;
        }

        private string GetDefaultCaseCompanyLocationName(int caseId, Participant participant)
        {
            string caseCompanyLocationName = string.Empty;
            var caseCompanyLocations = _lookupManager.GetCaseCompanyLocationList(caseId);
            if (caseCompanyLocations.Any())
            {
                if (participant.WorkStreet1 != null || participant.WorkStreet2 != null)
                {
                    var companyLocation = caseCompanyLocations.Where(c => c.Description == participant.WorkStreet1
                    || c.Description == participant.WorkStreet2
                    || c.Description.Contains(string.Concat(participant.WorkStreet1, participant.WorkStreet2))
                    || c.Description == string.Concat(participant.WorkStreet1, " ", participant.WorkStreet2)).FirstOrDefault();
                    if (companyLocation != null)
                    {
                        caseCompanyLocationName = companyLocation.Description;
                    }
                }
            }
            return caseCompanyLocationName;
        }

        private void MLDEParticipantChangeCheck(Participant participant, CensusParticipantDto censusParticipantDto)
        {
            // First check to see if the data has changed prior to looking into the database to see if there is an MDLE enrollment

        }

        private void RemoveAllOutsideCoverage(List<Participant> finalCensusParticipantList)
        {
            var userInfo = _securityManager.GetUserInfo(HttpContext.Current.User);
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork()) 
            {
                foreach (var censusParticipant in finalCensusParticipantList)
                {
                    var carriers = new List<CarrierInfoDto>
                    {
                        new CarrierInfoDto { Carrier = censusParticipant.IDICarrier1, PolicyNumber = censusParticipant.IDIPolicyNumber1, BenefitAmount = censusParticipant.IDIBenefitAmount1, CarrierDescription = censusParticipant.IDICarrier1Description, ToBeReplaced = censusParticipant.IDIToBeReplaced1, ToBeReplacedAmount = censusParticipant.IDIToBeReplacedAmount1, PremiumPayerId = censusParticipant.PremiumPayerId1 },
                        new CarrierInfoDto { Carrier = censusParticipant.IDICarrier2, PolicyNumber = censusParticipant.IDIPolicyNumber2, BenefitAmount = censusParticipant.IDIBenefitAmount2, CarrierDescription = censusParticipant.IDICarrier2Description, ToBeReplaced = censusParticipant.IDIToBeReplaced2, ToBeReplacedAmount = censusParticipant.IDIToBeReplacedAmount2, PremiumPayerId = censusParticipant.PremiumPayerId2 },
                        new CarrierInfoDto { Carrier = censusParticipant.IDICarrier3, PolicyNumber = censusParticipant.IDIPolicyNumber3, BenefitAmount = censusParticipant.IDIBenefitAmount3, CarrierDescription = censusParticipant.IDICarrier3Description, ToBeReplaced = censusParticipant.IDIToBeReplaced3, ToBeReplacedAmount = censusParticipant.IDIToBeReplacedAmount3, PremiumPayerId = censusParticipant.PremiumPayerId3 },
                        new CarrierInfoDto { Carrier = censusParticipant.IDICarrier4, PolicyNumber = censusParticipant.IDIPolicyNumber4, BenefitAmount = censusParticipant.IDIBenefitAmount4, CarrierDescription = censusParticipant.IDICarrier4Description, ToBeReplaced = censusParticipant.IDIToBeReplaced4, ToBeReplacedAmount = censusParticipant.IDIToBeReplacedAmount4, PremiumPayerId = censusParticipant.PremiumPayerId4 }
                    };

                    var inforceCarriers = carriers.Where(c => c.Carrier != null && (c.Carrier == IDICoverageCarrierTypeEnum.Guardian || c.Carrier == IDICoverageCarrierTypeEnum.Berkshire)).ToList();
                    var outsideCoverages = carriers.Where(c => c.Carrier != null && !(c.Carrier == IDICoverageCarrierTypeEnum.Guardian || c.Carrier == IDICoverageCarrierTypeEnum.Berkshire)).ToList();

                    while (inforceCarriers.Count < 4)
                    {
                        inforceCarriers.Add(new CarrierInfoDto { Carrier = null, PolicyNumber = null, BenefitAmount = null, CarrierDescription = null, ToBeReplaced = false, ToBeReplacedAmount = null, PremiumPayerId = null });
                    }

                    for (int index = 0; index < inforceCarriers.Count; index++)
                    {
                        CarrierInfoDto carrierInfo = inforceCarriers[index];
                        censusParticipant.GetType().GetProperty($"IDICarrier{index + 1}").SetValue(censusParticipant, carrierInfo.Carrier);
                        censusParticipant.GetType().GetProperty($"IDIPolicyNumber{index + 1}").SetValue(censusParticipant, carrierInfo.PolicyNumber);
                        censusParticipant.GetType().GetProperty($"IDIBenefitAmount{index + 1}").SetValue(censusParticipant, carrierInfo.BenefitAmount);
                        censusParticipant.GetType().GetProperty($"IDICarrier{index + 1}Description").SetValue(censusParticipant, carrierInfo.CarrierDescription);
                        censusParticipant.GetType().GetProperty($"IDIToBeReplaced{index + 1}").SetValue(censusParticipant, carrierInfo.ToBeReplaced);
                        censusParticipant.GetType().GetProperty($"IDIToBeReplacedAmount{index + 1}").SetValue(censusParticipant, carrierInfo.ToBeReplacedAmount);
                        censusParticipant.GetType().GetProperty($"PremiumPayerId{index + 1}").SetValue(censusParticipant, carrierInfo.PremiumPayerId);
                    }

                    if (outsideCoverages.Any())
                    {
                        foreach (var outsideCoverage in outsideCoverages)
                        {
                            var idiCoverage = new IndividualDisabilityCoverage
                            {
                                Participant = censusParticipant,
                                Status = IndividualDisabilityCoverageStatusTypeEnum.Deleted.ToString(),
                                CarrierId = (int?)outsideCoverage.Carrier,
                                BenefitAmount = outsideCoverage.BenefitAmount,
                                IsReplaceable = outsideCoverage.ToBeReplaced,
                                ReplacementAmount = outsideCoverage.ToBeReplacedAmount,
                                PremiumPayer = outsideCoverage.PremiumPayerId,
                                PolicyNumber = outsideCoverage.PolicyNumber,
                                CreatedBy = userInfo.Name,
                                CreatedAt = DateTime.Now,
                                UpdatedAt = DateTime.Now,
                                UpdatedBy = userInfo.Name
                            };

                            unitOfWork.Repository<IndividualDisabilityCoverage>().Save(idiCoverage);
                        }
                    }
                }
                unitOfWork.Commit();
            }
        }

        private decimal? GetManualBenefitAmount(int planDesignRequestClassId)
        {
            var classEligibilityConfigurationDto = GetClassEligibilityConfiguration(planDesignRequestClassId);
            return classEligibilityConfigurationDto.MinimumBenefitAmount;
        }
    }

    
    public class OSEIndicator
    {
        public bool IsOSE { get; set; }
        public int PDRClassID { get; set; }
    }


}
