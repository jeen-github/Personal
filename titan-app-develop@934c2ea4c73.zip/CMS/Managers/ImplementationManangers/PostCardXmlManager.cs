﻿using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.DataAccess;
using Logger.Static;
using CMS.Interfaces.Managers.ImplementationManagers;

namespace CMS.Managers.ImplementationManangers
{
    public class PostCardXmlManager : IPostCardXmlManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IPostCardXmlGenerator _postCardXmlGenerator;
        public PostCardXmlManager(IUnitOfWorkFactory unitOfWorkFactory, IPostCardXmlGenerator postCardXmlGenerator)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _postCardXmlGenerator = postCardXmlGenerator;
            
        }
        public void GeneratePostCardRequest(PostCardXmlGenerationRequest request)
        {
            Log.TraceFormat("+GeneratePostCardRequest");            
            _postCardXmlGenerator.EnqueueRequest(request);

            Log.TraceFormat("-GeneratePostCardRequest");
        }

       
    }
}
