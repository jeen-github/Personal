﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Utilities;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Managers.ImplementationManangers
{
    public class SolicitationDeclinesTaskManager : IWorkUnitHandler
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        public SolicitationDeclinesTaskManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.TraceFormat("+Execute");
            var enrollmentId = int.Parse(workUnit.InputData);
            List<ParticipantSolicitationDeclineCountDto> participants = new List<ParticipantSolicitationDeclineCountDto>();
            bool hasBuyUp = false;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(ep => ep.Enrollment.Id == enrollmentId).ToList();
                var buyUpPlan = unitOfWork.Repository<EnrollmentPDRClassOption>().Linq().Where(o => o.EnrollmentPDRClass.Enrollment.Id == enrollmentId
                && o.EnrollmentPDRClassOptionPlans.Any(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp));

                if (buyUpPlan.Any())
                {
                    hasBuyUp = true;
                }

                foreach(var p in enrollmentParticipants)
                {
                    var participantDto = new ParticipantSolicitationDeclineCountDto();
                    participantDto.Participant_Id = p.Participant.Id;
                    BuildBasePlanPreviousSolicitations(p, participantDto);
                    BuildVGSIPlanPreviousSolicitations(p, hasBuyUp, participantDto);
                    participants.Add(participantDto);
                }
            }

            if (participants.Any())
            {
                SaveParticipantSolicitationDeclineCountToDatabase(participants);
            }

            Log.TraceFormat("-Execute");
        }

        private void BuildBasePlanPreviousSolicitations(EnrollmentParticipant enrollmentParticipant, ParticipantSolicitationDeclineCountDto participantDto)
        {
            if (enrollmentParticipant.BasePlanEnrollmentParticipantStatusType == EnrollmentParticipantStatusTypeEnum.Accepted)
            {
                participantDto.BasePlanPreviousSolicitations = 0;
            }
            else
            {
                participantDto.BasePlanPreviousSolicitations = (enrollmentParticipant.Participant.BasePlanPreviousSolicitations != null) ? (enrollmentParticipant.Participant.BasePlanPreviousSolicitations + 1) : 1;
            }
        }

        private void BuildVGSIPlanPreviousSolicitations(EnrollmentParticipant enrollmentParticipant, bool hasBuyUp, ParticipantSolicitationDeclineCountDto participantDto)
        {
            if (enrollmentParticipant.VGSIPlanEnrollmentParticipantStatusType == EnrollmentParticipantStatusTypeEnum.Accepted)
            {
                participantDto.VGSIPlanPreviousSolicitations = 0;
            }
            else
            {
                if (hasBuyUp)
                {
                    participantDto.VGSIPlanPreviousSolicitations = (enrollmentParticipant.Participant.VGSIPlanPreviousSolicitations != null) ? (enrollmentParticipant.Participant.VGSIPlanPreviousSolicitations + 1) : 1;
                }
                else
                {
                    participantDto.VGSIPlanPreviousSolicitations = 0;
                }
            }
        }

        private void SaveParticipantSolicitationDeclineCountToDatabase(List<ParticipantSolicitationDeclineCountDto> participants)
        {
            Log.TraceFormat("+SaveParticipantSolicitationDeclineCountToDatabase");
            string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");

            DataTable participantTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(participants));
            if (participantTable.Rows.Count > 0)
            {
                using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
                {
                    SqlCommand command = sqlConnection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "[cms].[USP_UpdateParticipantSolicitationDeclineCount]";

                    SqlParameter parameter1 = new SqlParameter();
                    parameter1.ParameterName = "@ParticipantTableVariable";
                    parameter1.SqlDbType = SqlDbType.Structured;
                    parameter1.Value = participantTable;
                    command.Parameters.Add(parameter1);

                    sqlConnection.Open();
                    int numberOfRowsUpdated = command.ExecuteNonQuery();
                }
            }
            Log.TraceFormat("-SaveParticipantSolicitationDeclineCountToDatabase");
        }
    }

    public class ParticipantSolicitationDeclineCountDto
    {
        public int Participant_Id { get; set; }
        public int? BasePlanPreviousSolicitations { get; set; }
        public int? VGSIPlanPreviousSolicitations { get; set; }
    }
}