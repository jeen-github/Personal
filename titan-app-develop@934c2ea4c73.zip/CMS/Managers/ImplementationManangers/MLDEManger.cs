﻿using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.MLDEServices;
using CMS.Interfaces.Integrations.ProductLibraryServices;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Managers.DocumentManagers.DocumentGenerators;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Exceptions;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;
using Guardian.Mlde.Api.Models.Enums;
using Guardian.Mlde.Api.Models.ViewModels;
using Guardian.Mlde.Api.Models.ViewModels.Census;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using Guardian.Core.Entities.Product.Enums.EnumExtensions;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CMS.Interfaces.Managers.TaskManagers;
using CMS.Interfaces.Managers.SecurityManagers;
using System.Web;
using System.Web.UI;

namespace CMS.Managers.ImplementationManangers
{
    public class MLDEManger : IMLDEManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IConfiguration _configuration;
        private readonly IMLDEService _imldeService;
        private readonly IProductLibraryManager _productLibraryManager;
        private readonly IProductLibraryWebServiceClient _productLibraryWebServiceClient;
        private string ProductLibraryDatabaseConnection = AppSettingsReader.ReadAppSettingValue("ProductLibraryDatabaseConnection");
        private List<TablePremiumSeriesResponseCache> _premiumSeriesCache;
        private readonly ITaskManager _taskManager;
        private readonly ISecurityManager _securityManager;

        public MLDEManger(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager,
            IConfiguration configuration, IMLDEService mldeService, IProductLibraryManager productLibraryManager,
            IProductLibraryWebServiceClient productLibraryServiceClient, ITaskManager taskManager, ISecurityManager securityManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _workUnitManager = workUnitManager;
            _configuration = configuration;
            _imldeService = mldeService;
            _productLibraryManager = productLibraryManager;
            _productLibraryWebServiceClient = productLibraryServiceClient;
            _premiumSeriesCache = new List<TablePremiumSeriesResponseCache>();
            _taskManager = taskManager;
            _securityManager = securityManager;
        }

        public bool SendCaseData(int caseId)
        {
            Log.Trace("+MLDEManger.SendCaseData");
            bool sendStatus = false;

            try
            {
                var caseViewModel = GetCaseData(caseId);
                _imldeService.SendCaseData(caseViewModel);
                sendStatus = true;
            }
            catch (Exception ex)
            {
                Log.Error($"MLDEManger.SendCaseData: Error while sending case data to mlde system for the caseId {caseId}!", ex);
                sendStatus = false;
            }

            Log.Trace("-MLDEManger.SendCaseData");

            return sendStatus;
        }

        public void SendCensusData(EnrollmentMLDEStatusDto sendToMLDE)
        {
            Log.Trace("+MLDEManger.SendCensusData");
            CensusDataViewModel censusDataViewModel = new CensusDataViewModel();

            string mldeStatus = "Failed";
            bool mldeResponse = false;

            if (sendToMLDE.Status == "Success")
            {
                try
                {
                    var stopWatch = new Stopwatch();
                    stopWatch.Start();

                    censusDataViewModel = GetCensusData(sendToMLDE.caseId, sendToMLDE.EnrollmentId, sendToMLDE.SelectedParticipantIds);

                    stopWatch.Stop();
                    Log.Debug($"Finished creating upload viewmodel in {stopWatch.Elapsed.TotalSeconds} secs ({stopWatch.Elapsed.TotalMilliseconds} ms)");
                    //System.Diagnostics.Debug.WriteLine(JsonConvert.SerializeObject(censusDataViewModel));

                    // This will "fire and forget" the HTTP call to MLDE
                    Task.Run(() => _imldeService.SendCensusData(censusDataViewModel));
                    mldeResponse = true;
                }
                catch (Exception ex)
                {
                    Log.Error($"MLDEManger.SendCensusData: Error while sending census data to mlde system for the caseid {sendToMLDE.caseId}!", ex);
                    mldeResponse = false;
                }
                mldeStatus = mldeResponse == true ? "Success" : "Failed";
            }
            else
            {
                mldeStatus = "Validation Error";
            }

            using (var uw = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var sendToMlDEData = new EnrollmentMLDEStatus
                {
                    NumberofParticipants = sendToMLDE.SelectedParticipantIds.Count,
                    LastUpdated = DateTime.Now,
                    Sentby = sendToMLDE.Sentby,
                    Status = mldeStatus,
                    Enrollment_Id = sendToMLDE.EnrollmentId,
                    MLDEJson = !string.IsNullOrWhiteSpace(censusDataViewModel?.CMSCode) ? Newtonsoft.Json.JsonConvert.SerializeObject(censusDataViewModel) : null
                };

                uw.Repository<EnrollmentMLDEStatus>().Save(sendToMlDEData);
                uw.Commit();
            }

            Log.Trace("-MLDEManger.SendCensusData");
        }

        public CensusDataViewModel GetCensusData(int caseid, int enrollmentid, List<int> selectedParticipantIds)
        {
            Log.Trace("+MLDEManger.GetCensusData");

            CensusDataViewModel censusDataViewModel = new CensusDataViewModel();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseid);
                if (cmsCase == null) throw new ValidationException("Invalid case number");

                var currentEnrollment = unitOfWork.Repository<Enrollment>().Linq()
                   .FirstOrDefault(i => i.Id == enrollmentid);

                var currentEnrollmentOuput = unitOfWork.Repository<EnrollmentOutput>().Linq()
                  .FirstOrDefault(i => i.Enrollment.Id == enrollmentid);

                if (currentEnrollment == null) throw new ValidationException("There is no active enrollment for this case number!");

                var caseBrokers = cmsCase.CaseBrokers.Where(c => c.Case.Id == cmsCase.Id);
                var contactAddress = unitOfWork.Repository<ContactAddress>().Linq().Where(c => c.Case.Id == cmsCase.Id);

                var user = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(c => c.Id == cmsCase.EnrollmentManagerId);
                var enrollmentManagerContactAddress = unitOfWork.Repository<ContactAddress>().Linq().OrderByDescending(i => i.Id)
                      .FirstOrDefault(c => c.Case.Id == cmsCase.Id && c.ContactRoleType == ContactRoleTypeEnum.EnrollmentManager);

                var caseUnderwritingRequests = cmsCase.CaseUnderwritingRequests.FirstOrDefault(c => c.Case.Id == cmsCase.Id);
                PricingTypeEnum pricingType = caseUnderwritingRequests.PricingType != null ? caseUnderwritingRequests.PricingType.Value : PricingTypeEnum.PC2016;

                var annualReviewsForCase = unitOfWork.Repository<AnnualReview>()
                                                    .Linq().Where(c => c.Case.Id == cmsCase.Id
                                                    && (c.AnnualReviewStatusType == AnnualReviewStatusTypeEnum.Annual_Review_Approved
                                                    || c.AnnualReviewStatusType == AnnualReviewStatusTypeEnum.Annual_Review_Pending))
                                                    .OrderByDescending(a => a.CaseYear);

                var mostRecentAnnualReview = annualReviewsForCase.FirstOrDefault();
                var isNewCase = !annualReviewsForCase.Any(a => a.CaseYear != null);

                if (isNewCase)
                {
                    censusDataViewModel.CaseType = CaseTypeEnum.NewBusiness;
                    censusDataViewModel.RenewalYears = 1;
                }
                else
                {
                    censusDataViewModel.CaseType = CaseTypeEnum.Renewal;
                    var renewalYear = mostRecentAnnualReview == null || mostRecentAnnualReview.CaseYear == null ? 1 : (uint)mostRecentAnnualReview.CaseYear + 1;
                    censusDataViewModel.RenewalYears = (int)renewalYear;
                }

                censusDataViewModel.CMSCode = cmsCase.CaseNumber;
                censusDataViewModel.UseCompactApp = _productLibraryManager.IsCompactStateCase(cmsCase.Id);
                censusDataViewModel.EnrollmentId = currentEnrollment.Id;
                censusDataViewModel.EnrollmentName = currentEnrollment.EnrollmentName;
                censusDataViewModel.ProductType = pricingType.ToString();
                censusDataViewModel.EnrollmentStartDate = currentEnrollment.EnrollmentStartDate;
                censusDataViewModel.EnrollmentEndDate = currentEnrollment.EnrollmentEndDate;
                censusDataViewModel.EffectiveDate = currentEnrollment.EffectiveDate;
                censusDataViewModel.ExtensionEndDate = currentEnrollment.ExtensionEndDate;
                censusDataViewModel.IsActive = currentEnrollment.IsActive == null && currentEnrollment.EffectiveDate > DateTime.Now ? true : currentEnrollment.IsActive;


                censusDataViewModel.EnrollmentManager = new Guardian.Mlde.Api.Models.Domain.EnrollmentManager()
                {
                    FullName = user != null ? user.FirstName + " " + user.LastName : string.Empty,
                    EnrollmentContactEmailAddress = enrollmentManagerContactAddress?.Email,
                    EnrollmentContactPhoneNumber = enrollmentManagerContactAddress?.Phone,
                    EnrollmentManagerId = cmsCase?.EnrollmentManagerId,
                    EnrollmentContact = enrollmentManagerContactAddress?.ContactName
                };

                censusDataViewModel.Company = new CompanyViewModel()
                {
                    CompanyName = GetCompanyName(currentEnrollmentOuput, cmsCase),
                    SICCode = GetSisCodeAndName(cmsCase),
                    MainAddress = new AddressViewModel()
                    {
                        LocationName = "CompanyMain",
                        Street1 = cmsCase.CompanyAddressLine1 ?? string.Empty,
                        Street2 = cmsCase.CompanyAddressLine2 ?? string.Empty,
                        City = cmsCase.CompanyCity ?? string.Empty,
                        State = cmsCase.CompanyStateType != null ? cmsCase.CompanyStateType.Value.ToString() : string.Empty,
                        ZipCode = cmsCase.CompanyZipCode ?? string.Empty,
                        Country = "United States of America",
                        PhoneNumber = string.Empty,
                    },
                };

                censusDataViewModel.ProducersAndAgents = GetProducersAndAgents(caseBrokers, contactAddress);

                var stopwatch = new Stopwatch();
                var splitSelectedParticipantIds = selectedParticipantIds.ChunkBy(2000);
                foreach (var selectedParticipantIdSet in splitSelectedParticipantIds)
                {
                    stopwatch.Restart();

                    var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(x =>
                        x.Enrollment.Id == currentEnrollment.Id &&
                        x.MldeUploadStatusType == MldeUploadStatusTypeEnum.Valid &&
                        (x.Participant.IsEligible == true || x.Participant.InEligibleReason_Id == null) && x.Participant.IsActive == true
                    );
                    if (selectedParticipantIdSet != null && selectedParticipantIdSet.Count > 0)
                    {
                        enrollmentParticipants = enrollmentParticipants.Where(c => selectedParticipantIdSet.Contains(c.Id));
                    }

                    /* Original code
                    var pdrClasses = enrollmentParticipants.Select(c => c.Participant.PlanDesignRequestClass).Distinct();
                    var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(p => pdrClasses.Contains(p.PlanDesignRequestClass));
                    var enrollmentPDRClasses = currentEnrollment.Classes.Where(c => c.Enrollment.Id == currentEnrollment.Id);

                    if (censusDataViewModel.Groups == null) censusDataViewModel.Groups = new List<GroupViewModel>();
                    var groups = GetGroups(pdrSoldClass, enrollmentParticipants, cmsCase, caseBrokers, enrollmentPDRClasses);
                    
                    if (censusDataViewModel.Groups == null) censusDataViewModel.Groups = new List<GroupViewModel>();
                    censusDataViewModel.Groups.AddRange(groups);
                    */

                    var participantIds = enrollmentParticipants.Select(x => x.Participant.Id).ToList();
                    var pdrClassIds = unitOfWork.Repository<Participant>().Linq()
                        .Where(x => participantIds.Contains(x.Id))
                        .Select(x => x.PlanDesignRequestClass.Id)
                        .Distinct()
                        .ToList();

                    var pdrSoldClasses = unitOfWork.Repository<PDRSoldClass>().Linq()
                        .Where(x =>
                            x.PlanDesignRequestClass != null &&
                            pdrClassIds.Contains(x.PlanDesignRequestClass.Id))
                        .ToList();
                    var enrollmentPDRClasses = currentEnrollment.Classes.Where(c => c.Enrollment.Id == currentEnrollment.Id);
                    GetGroups2(censusDataViewModel, pdrSoldClasses, enrollmentParticipants, cmsCase, enrollmentPDRClasses);

                    stopwatch.Stop();
                    Log.Debug($"Processed chunk of {selectedParticipantIdSet.Count} participants in '{stopwatch.Elapsed.TotalSeconds}' seconds ('{stopwatch.Elapsed.TotalMilliseconds}' ms)");
                }
            }

            Log.Trace("-MLDEManger.GetCensusData");

            return censusDataViewModel;
        }       

        private void GetGroups2(
            CensusDataViewModel censusDataViewModel,
            List<PDRSoldClass> pdrSoldClasses,
            IQueryable<EnrollmentParticipant> enrollmentParticipentQuery,
            Case cmsCase,
            IEnumerable<EnrollmentPDRClass> enrollmentPDRClasss)
        {
            Log.TraceFormat("+MLDEManger.GetGroups2 CaseId: {0}", cmsCase.Id);

            if (censusDataViewModel.Groups == null) censusDataViewModel.Groups = new List<GroupViewModel>();
            var newGroupViewModels = new List<GroupViewModel>();
           
            foreach (var pdrSoldClass in pdrSoldClasses)
            {              

                // if the pdrClass doesn't exist in the censusDataViewModel groups yet,
                // then grab all the top level data, else we can skip it and just add
                // new enrollment participants. this is needed because of the participant
                // id split in the calling function
                bool isNewGroup = false;
                GroupViewModel group = null;
                if (censusDataViewModel.Groups.All(x => x.Name != pdrSoldClass.PlanDesignRequestClass.PlanDesignRequestClassName))
                {                 

                    var enrollmentPDRClass = enrollmentPDRClasss.Where(c => c.PlanDesignRequestClass.Id == pdrSoldClass.PlanDesignRequestClass.Id);
                    bool? isVGSIPlan = pdrSoldClass.PlanDesignRequestClass?.PlanDesignRequestClassProducts?.Any(x => x.IsGSIPlanIndicator == true) ?? false;
                    isNewGroup = true;

                    group = new GroupViewModel();
                    group.Name = pdrSoldClass.PlanDesignRequestClass.PlanDesignRequestClassName;
                    group.Description = pdrSoldClass.EligiblePopulationText;
                    group.IsVgsiPlanDesignType = isVGSIPlan;
                    group.EligibleParticipants = new List<ParticipantViewModel>();
                    group.PrimaryPlanDiscount = GetTotalDiscount(pdrSoldClass, PDRClassPlanTypeEnum.Primary);
                    group.BuyUpPlanDiscount = GetTotalDiscount(pdrSoldClass, PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                    group.LTDTaxability = GetLTDTaxabilityIndicator(pdrSoldClass);
                    group.AvailableOptions = GetAvailableOptions(enrollmentPDRClass);
                  
                    // Generate mock users for PDR Class/Group

                    var mockAMBEnrollmentParticipant = enrollmentParticipentQuery
                        .Where(c => c.Participant.PlanDesignRequestClass.Id == pdrSoldClass.PlanDesignRequestClass.Id 
                                 && c.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB)
                        .FirstOrDefault();

                    if (mockAMBEnrollmentParticipant != null)
                    {
                        GenerateMockUserGroups(group, pdrSoldClass, mockAMBEnrollmentParticipant, true);
                    }

                    var mockNonAmbEnrollmentParticipant = enrollmentParticipentQuery
                        .Where(c => c.Participant.PlanDesignRequestClass.Id == pdrSoldClass.PlanDesignRequestClass.Id
                        && c.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)
                        .FirstOrDefault();
                    if (mockNonAmbEnrollmentParticipant != null)
                    {                       
                        GenerateMockUserGroups(group, pdrSoldClass, mockNonAmbEnrollmentParticipant, false);
                    }

                    //If there is no non AMB particpant on the above selection then , create mock users based on the below condition.
                    if (mockNonAmbEnrollmentParticipant == null)
                    {
                        var mockEnrollmentParticipant = enrollmentParticipentQuery
                           .Where(c => c.Participant.PlanDesignRequestClass.Id == pdrSoldClass.PlanDesignRequestClass.Id)
                           .FirstOrDefault();
                        if (mockEnrollmentParticipant != null)
                        {
                            GenerateMockUserGroups(group, pdrSoldClass, mockEnrollmentParticipant, false);
                        }
                    }
                }
                else
                {
                    group = censusDataViewModel.Groups.FirstOrDefault(x => x.Name == pdrSoldClass.PlanDesignRequestClass.PlanDesignRequestClassName);
                    if (group == null) throw new Exception("Something went wrong creating censusDataViewModel. Could not find existing group.");
                }
                
                int employeeSalaryDefinitionTypeId = (int)GetEmployeeSalaryDefinitionType(pdrSoldClass);
                var participantData = enrollmentParticipentQuery
                    .Where(c => c.Participant.PlanDesignRequestClass.Id == pdrSoldClass.PlanDesignRequestClass.Id)
                    .Select(x => new
                    {
                        EnrollmentParticipantId = x.Id,
                        Status = x.Participant.ParticipantCategoryCodeType,
                        FirstName = x.Participant.FirstName,
                        LastName = x.Participant.LastName,
                        Suffix = x.Participant.Suffix,
                        EmailAddress = x.Participant.WorkEmail,
                        PayrollDeductionTypeId = x.Participant.ListBillNumber.BillingModeType,
                        DateOfBirth = x.Participant.DateOfBirth,
                        HomeStreet1 = x.Participant.HomeStreet1,
                        HomeStreet2 = x.Participant.HomeStreet2,
                        HomeCity = x.Participant.HomeCity,
                        HomeState = x.Participant.HomeState,
                        HomeDescription = x.Participant.HomeStateDescription,
                        HomeZipCode = x.Participant.HomeZipCode,
                        HomePhoneNumber = x.Participant.HomePhone,
                        WorkStreet1 = x.Participant.WorkStreet1,
                        WorkStreet2 = x.Participant.WorkStreet2,
                        WorkCity = x.Participant.WorkCity,
                        WorkState = x.Participant.WorkState,
                        WorkDescription = x.Participant.WorkStateDescription,
                        WorkZipCode = x.Participant.WorkZipCode,
                        WorkPhoneNumber = x.Participant.WorkLocationPhone,
                        ParticipantCategoryCodeType = x.Participant.ParticipantCategoryCodeType,
                        BuyUpParticipantCategoryCodeType = x.Participant.BuyUpParticipantCategoryCodeType
                    })
                    .ToList();
                
                //int count = 1;

                foreach (var participant in participantData)
                {                  
                    var participantViewModel = new ParticipantViewModel()
                    {
                        EnrollmentParticipantId = participant.EnrollmentParticipantId,
                        Status = participant.Status != null
                            ? (ParticipantStatusEnum)participant.Status
                            : ParticipantStatusEnum.NE,
                        FirstName = participant.FirstName,
                        LastName = participant.LastName,
                        Suffix = participant.Suffix,
                        EmailAddress = participant.EmailAddress,
                        PayrollDeductionTypeId = participant.PayrollDeductionTypeId != null
                            ? (PayrollDeductionTypeEnum)participant.PayrollDeductionTypeId
                            : PayrollDeductionTypeEnum.None,
                        EmployeeSalaryDefinitionTypeId = employeeSalaryDefinitionTypeId,
                        DateOfBirth = participant.DateOfBirth,
                        ParticipantCategoryCodeType = GetParticipantCategoryCodeType(participant.ParticipantCategoryCodeType),
                        BuyUpParticipantCategoryCodeType = GetParticipantCategoryCodeType(participant.BuyUpParticipantCategoryCodeType),
                        Addresses = new List<AddressViewModel>
                            {
                                new AddressViewModel
                                {
                                    LocationName = "Home",
                                    Street1 = participant.HomeStreet1 != null ? participant.HomeStreet1 : string.Empty,
                                    Street2 = participant.HomeStreet2 != null ? participant.HomeStreet2 : string.Empty,
                                    City = participant.HomeCity != null ? participant.HomeCity : string.Empty,
                                    State = participant.HomeState != null
                                        ? participant.HomeState.ToString()
                                        : (!string.IsNullOrEmpty(participant.HomeDescription)
                                            ? participant.HomeDescription
                                            : string.Empty),
                                    ZipCode = participant.HomeZipCode != null ? participant.HomeZipCode : string.Empty,
                                    Country = "United States of America",
                                    PhoneNumber = participant.HomePhoneNumber != null
                                        ? participant.HomePhoneNumber
                                        : string.Empty
                                },
                                new AddressViewModel
                                {
                                    LocationName = "Work",
                                    Street1 = participant.WorkStreet1 != null ? participant.WorkStreet1 : string.Empty,
                                    Street2 = participant.WorkStreet2 != null ? participant.WorkStreet2 : string.Empty,
                                    City = participant.WorkCity != null ? participant.WorkCity : string.Empty,
                                    State = participant.WorkState != null
                                        ? participant.WorkState.ToString()
                                        : (!string.IsNullOrEmpty(participant.WorkDescription)
                                            ? participant.WorkDescription
                                            : string.Empty),
                                    ZipCode = participant.WorkZipCode != null ? participant.WorkZipCode : string.Empty,
                                    Country = "United States of America",
                                    PhoneNumber = participant.WorkPhoneNumber != null
                                        ? participant.WorkPhoneNumber
                                        : string.Empty
                                }
                            }
                    };
                    group.EligibleParticipants.Add(participantViewModel);                   
                }

                if (isNewGroup) newGroupViewModels.Add(group);
            }

            censusDataViewModel.Groups.AddRange(newGroupViewModels);

            Log.TraceFormat("-MLDEManger.GetGroups2");
        }

        private void PopulateGroups(CensusDataViewModel censusDataViewModel, List<GroupViewModel> groups)
        {
            if (censusDataViewModel.Groups == null) censusDataViewModel.Groups = new List<GroupViewModel>();

            foreach (var group in groups)
            {
                // if the group doesn't exist in the viewmodel, then add the entire group,
                // else just add the new participants to the existing group
                if (censusDataViewModel.Groups.All(x => x.Name != group.Name))
                {
                    Log.Debug($"Adding new group '{group.Name}' with {group.EligibleParticipants.Count} enrollment participants");
                    censusDataViewModel.Groups.Add(group);
                }
                else
                {
                    Log.Debug($"Adding {group.EligibleParticipants.Count} enrollment participants to existing group '{group.Name}'");
                }
            }
        }

        private bool IsMockGroupAlreadyExists(GroupViewModel group)
        {
            //Log.TraceFormat("+MLDEManger.IsMockGroupAlreadyExists");

            bool isMockGroupExist = false;

            if (group.EligibleParticipants != null)
            {
                isMockGroupExist = group.EligibleParticipants.Any(i => i.EnrollmentParticipantId < 0);
            }
            //Log.TraceFormat("-MLDEManger.IsMockGroupAlreadyExists");

            return isMockGroupExist;

        }

        private void GenerateMockUserGroups(GroupViewModel group, PDRSoldClass pdrSoldClass, EnrollmentParticipant enrollmentParticipant, bool isSpecialMock)
        {
            Log.TraceFormat("-MLDEManger.GenerateMockUserGroups");

            int emailAddressCount = 0;
            int count = 0;

            var option1EnrolledParticipants = enrollmentParticipant.EnrollmentParticipantOptionPlans.
                    Where(c => c.StandardOptionCodeNonSmoker != null && c.StandardOptionCodeNonSmoker.Contains("Option 1") || (c.StandardOptionCodeSmoker != null && c.StandardOptionCodeSmoker.Contains("Option 1"))).Select(c => c.EnrollmentParticipant).ToList();

            var option2EnrolledParticipants = enrollmentParticipant.EnrollmentParticipantOptionPlans.
                    Where(c => c.StandardOptionCodeNonSmoker != null && c.StandardOptionCodeNonSmoker.Contains("Option 2") || (c.StandardOptionCodeSmoker != null && c.StandardOptionCodeSmoker.Contains("Option 2"))).Select(c => c.EnrollmentParticipant).ToList();

            var option3EnrolledParticipants = enrollmentParticipant.EnrollmentParticipantOptionPlans.
                    Where(c => c.StandardOptionCodeNonSmoker != null && c.StandardOptionCodeNonSmoker.Contains("Option 3") || (c.StandardOptionCodeSmoker != null && c.StandardOptionCodeSmoker.Contains("Option 3"))).Select(c => c.EnrollmentParticipant).ToList();

            var option1EnrolledParticipantPlans = option1EnrolledParticipants.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
            var maxOption1GSIAmount = option1EnrolledParticipantPlans.Max(c => c.TotalMonthlyBenefitAmount);
            var option1EnrolOption = option1EnrolledParticipantPlans.Where(c => c.TotalMonthlyBenefitAmount == maxOption1GSIAmount).ToList();
            var option1MockEnrolledParticiapnt = option1EnrolOption.Select(c => c.EnrollmentParticipant).FirstOrDefault();

            if (option1MockEnrolledParticiapnt != null)
            {
                count++;
                emailAddressCount++;
                BuildMockParticipant(option1MockEnrolledParticiapnt, group, count, emailAddressCount);
            }

            var option2EnrolledParticipantPlans = option2EnrolledParticipants.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
            var maxOption2GSIAmount = option2EnrolledParticipantPlans.Max(c => c.TotalMonthlyBenefitAmount);
            var option2EnrolOption = option2EnrolledParticipantPlans.Where(c => c.TotalMonthlyBenefitAmount == maxOption2GSIAmount).ToList();
            var option2MockEnrolledParticiapnt = option2EnrolOption.Select(c => c.EnrollmentParticipant).FirstOrDefault();

            if (option2MockEnrolledParticiapnt != null)
            {
                count++;
                emailAddressCount++;
                BuildMockParticipant(option2MockEnrolledParticiapnt, group, count, emailAddressCount);
            }

            var option3EnrolledParticipantPlans = option3EnrolledParticipants.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
            var maxOption3GSIAmount = option3EnrolledParticipantPlans.Max(c => c.TotalMonthlyBenefitAmount);
            var option3EnrolOption = option3EnrolledParticipantPlans.Where(c => c.TotalMonthlyBenefitAmount == maxOption3GSIAmount).ToList();
            var option3MockEnrolledParticiapnt = option3EnrolOption.Select(c => c.EnrollmentParticipant).FirstOrDefault();

            if (option3MockEnrolledParticiapnt != null)
            {
                count++;
                emailAddressCount++;
                BuildMockParticipant(option3MockEnrolledParticiapnt, group, count, emailAddressCount);
            }

            if (!isSpecialMock)
            {

                var participantAgeLimit30To40Plan = enrollmentParticipant.EnrollmentParticipantOptionPlans
                                                   .Where(e => e.EnrollmentParticipant.Participant.Age != null &&
                                                   e.EnrollmentParticipant.Participant.Age >= 30 && e.EnrollmentParticipant.Participant.Age <= 40).ToList();

                if (participantAgeLimit30To40Plan != null)
                {
                    if (participantAgeLimit30To40Plan.Count() > 0)
                    {
                        var participantAgeLimit30To40MaxGSIAmount = participantAgeLimit30To40Plan.Max(c => c.TotalMonthlyBenefitAmount);
                        var participantAgeLimit30To40EnrolOption = participantAgeLimit30To40Plan.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit30To40MaxGSIAmount).ToList();

                        GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit30To40EnrolOption);
                        var mockParticipantAgeLimit30To40 = participantAgeLimit30To40EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                        if (mockParticipantAgeLimit30To40 != null)
                        {
                            count++;
                            emailAddressCount++;
                            BuildMockParticipant(mockParticipantAgeLimit30To40, group, count, emailAddressCount);
                        }
                    }
                }

                var participantAgeLimit41To60Plans = enrollmentParticipant.EnrollmentParticipantOptionPlans
                                                     .Where(c => c.EnrollmentParticipant.Participant.Age != null &&
                                                     c.EnrollmentParticipant.Participant.Age >= 41 && c.EnrollmentParticipant.Participant.Age <= 60).ToList();
                if (participantAgeLimit41To60Plans != null)
                {
                    if (participantAgeLimit41To60Plans.Count() > 0)
                    {
                        var participantAgeLimit41To60MaxGSIAmount = participantAgeLimit41To60Plans.Max(c => c.TotalMonthlyBenefitAmount);
                        var participantAgeLimit41To60EnrolOption = participantAgeLimit41To60Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit41To60MaxGSIAmount).ToList();

                        GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit41To60EnrolOption);
                        var mockparticipantAgeLimit41To60 = participantAgeLimit41To60EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                        if (mockparticipantAgeLimit41To60 != null)
                        {
                            count++;
                            emailAddressCount++;
                            BuildMockParticipant(mockparticipantAgeLimit41To60, group, count, emailAddressCount);
                        }
                    }
                }


                var participantAgeLimit61To62Plans = enrollmentParticipant.EnrollmentParticipantOptionPlans
                                                     .Where(c => c.EnrollmentParticipant.Participant.Age != null &&
                                                     c.EnrollmentParticipant.Participant.Age >= 61 && c.EnrollmentParticipant.Participant.Age <= 62).ToList();
                if (participantAgeLimit61To62Plans != null)
                {
                    if (participantAgeLimit61To62Plans.Count() > 0)
                    {

                        var participantAgeLimit61To62MaxGSIAmount = participantAgeLimit61To62Plans.Max(c => c.TotalMonthlyBenefitAmount);
                        var participantAgeLimit61To62EnrolOption = participantAgeLimit61To62Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit61To62MaxGSIAmount).ToList();

                        GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit61To62EnrolOption);
                        var mockparticipantAgeLimit61To62 = participantAgeLimit61To62EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                        if (mockparticipantAgeLimit61To62 != null)
                        {
                            count++;
                            emailAddressCount++;
                            BuildMockParticipant(mockparticipantAgeLimit61To62, group, count, emailAddressCount);
                        }
                    }
                }

                var participantAgeLimit63To64Plans = enrollmentParticipant.EnrollmentParticipantOptionPlans
                                                      .Where(c => c.EnrollmentParticipant.Participant.Age != null &&
                                                      c.EnrollmentParticipant.Participant.Age >= 63 && c.EnrollmentParticipant.Participant.Age <= 64).ToList();
                if (participantAgeLimit63To64Plans != null)
                {
                    if (participantAgeLimit63To64Plans.Count() > 0)
                    {
                        var participantAgeLimit63To64MaxGSIAmount = participantAgeLimit63To64Plans.Max(c => c.TotalMonthlyBenefitAmount);
                        var participantAgeLimit63To64EnrolOption = participantAgeLimit63To64Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit63To64MaxGSIAmount).ToList();

                        GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit63To64EnrolOption);
                        var mockparticipantAgeLimit63To64 = participantAgeLimit63To64EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                        if (mockparticipantAgeLimit63To64 != null)
                        {
                            count++;
                            emailAddressCount++;
                            BuildMockParticipant(mockparticipantAgeLimit63To64, group, count, emailAddressCount);
                        }
                    }
                }

                var participantAgeLimit65To66Plans = enrollmentParticipant.EnrollmentParticipantOptionPlans
                                                    .Where(c => c.EnrollmentParticipant.Participant.Age != null &&
                                                    c.EnrollmentParticipant.Participant.Age >= 65 && c.EnrollmentParticipant.Participant.Age <= 66).ToList();
                if (participantAgeLimit65To66Plans != null)
                {
                    if (participantAgeLimit65To66Plans.Count() > 0)
                    {
                        var participantAgeLimit65To66MaxGSIAmount = participantAgeLimit65To66Plans.Max(c => c.TotalMonthlyBenefitAmount);
                        var participantAgeLimit65To66EnrolOption = participantAgeLimit65To66Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit65To66MaxGSIAmount).ToList();

                        GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit65To66EnrolOption);
                        var mockparticipantAgeLimit65To66 = participantAgeLimit65To66EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                        if (mockparticipantAgeLimit65To66 != null)
                        {
                            count++;
                            emailAddressCount++;
                            BuildMockParticipant(mockparticipantAgeLimit65To66, group, count, emailAddressCount);
                        }
                    }
                }

                var participantAgeLimit67OverPlans = enrollmentParticipant.EnrollmentParticipantOptionPlans
                                                     .Where(c => c.EnrollmentParticipant.Participant.Age != null && c.EnrollmentParticipant.Participant.Age >= 67).ToList();
                if (participantAgeLimit67OverPlans != null)
                {
                    if (participantAgeLimit67OverPlans.Count() > 0)
                    {
                        var participantAgeLimit67OverMaxGSIAmount = participantAgeLimit67OverPlans.Max(c => c.TotalMonthlyBenefitAmount);
                        var participantAgeLimit67OverEnrolOption = participantAgeLimit67OverPlans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit67OverMaxGSIAmount).ToList();

                        GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit67OverEnrolOption);
                        var mockparticipantAgeLimit67Over = participantAgeLimit67OverEnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                        if (mockparticipantAgeLimit67Over != null)
                        {
                            count++;
                            emailAddressCount++;
                            BuildMockParticipant(mockparticipantAgeLimit67Over, group, count, emailAddressCount);
                        }
                    }
                }


                if (option1MockEnrolledParticiapnt != null)
                {
                    if (count < 5)
                    {
                        for (int mockCount = count; mockCount < 5; mockCount++)
                        {
                            count++;
                            emailAddressCount++;
                            BuildMockParticipant(option1MockEnrolledParticiapnt, group, count, emailAddressCount);
                        }
                    }
                }
            }

            Log.TraceFormat("-MLDEManger.GenerateMockUserGroups");
        }

        private void BuildMockParticipant(EnrollmentParticipant enrolledParticipant, GroupViewModel group, int count, int emailAddressCount)
        {
            Log.TraceFormat("+MLDEManger.BuildMockParticipant");
            ParticipantViewModel participant = new ParticipantViewModel();
            participant.EnrollmentParticipantId = (enrolledParticipant.Id * 100 + count) * -1;

           
                //return;

            participant.Status = GetParticipantStatusCode(enrolledParticipant.Participant);

            if (enrolledParticipant.Participant.Gender.ToUpper().Trim() == "MALE" || enrolledParticipant.Participant.Gender.ToUpper().Trim() == "M")
            {
                participant.FirstName = "John";
            }
            else if (enrolledParticipant.Participant.Gender.ToUpper().Trim() == "FEMALE" || enrolledParticipant.Participant.Gender.ToUpper().Trim() == "F")
            {
                participant.FirstName = "Jane";
            }
            else
            {
                participant.FirstName = "Chris";
            }
            participant.LastName = "Smith";
            participant.Suffix = enrolledParticipant.Participant.Suffix != null
                                                            ? enrolledParticipant.Participant.Suffix : string.Empty;
            participant.EmailAddress = enrolledParticipant.Participant.WorkEmail != null
                                                            ? enrolledParticipant.Participant.WorkEmail : string.Empty;
            var Domain = enrolledParticipant.Participant.WorkEmail != null ? enrolledParticipant.Participant.WorkEmail : string.Empty;
            string domain = Domain.Split('@').ElementAtOrDefault(1);
            //participant.EmailAddress = "user" + emailAddressCount + "@" + domain;
            participant.EmailAddress = $"user{emailAddressCount}.{(enrolledParticipant.Id * 100 + count)}@{domain}";

            if (enrolledParticipant.Participant.DateOfBirth.Value != null)
            {
                participant.DateOfBirth = enrolledParticipant.Participant.DateOfBirth.Value;
            }
            participant.Addresses = new List<AddressViewModel>();
            participant.ParticipantCategoryCodeType = GetParticipantCategoryCodeType(enrolledParticipant.Participant.ParticipantCategoryCodeType);
            participant.BuyUpParticipantCategoryCodeType = GetParticipantCategoryCodeType(enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType);
            AddressViewModel homeaddress = new AddressViewModel();
            {
                homeaddress.LocationName = "Home";
                homeaddress.Street1 = "530 Main St";
                homeaddress.Street2 = string.Empty;
                homeaddress.City = "Parktown";
                homeaddress.State = "MA";
                homeaddress.ZipCode = enrolledParticipant.Participant.HomeZipCode != null ?
                                          enrolledParticipant.Participant.HomeZipCode : string.Empty;
                homeaddress.Country = "United States of America";
                homeaddress.PhoneNumber = "555-555-1212";

            }
            participant.Addresses.Add(homeaddress);


            AddressViewModel workaddress = new AddressViewModel();
            {
                workaddress.LocationName = "Work";
                workaddress.Street1 = "299 Lynn Lane";
                workaddress.Street2 = string.Empty;
                workaddress.City = "Wardsboro";
                workaddress.State = "MA";
                workaddress.ZipCode = enrolledParticipant.Participant.WorkZipCode != null ?
                                          enrolledParticipant.Participant.WorkZipCode : string.Empty;
                workaddress.Country = "United States of America";
                workaddress.PhoneNumber = "555-555-1212";

            }
            participant.Addresses.Add(workaddress);

            if (!group.EligibleParticipants.Any(i => i.EnrollmentParticipantId == participant.EnrollmentParticipantId))
            {
                group.EligibleParticipants.Add(participant);
            }

            Log.TraceFormat("-MLDEManger.BuildMockParticipant");

        }

        private void GetOption1EnrollmentParticipantOptionPlan(List<EnrollmentParticipantOptionPlan> enrollmentParticiapntOptionPlan)
        {
            if (enrollmentParticiapntOptionPlan != null)
            {
                if (enrollmentParticiapntOptionPlan.Count > 0)
                {
                    enrollmentParticiapntOptionPlan = enrollmentParticiapntOptionPlan.Where(c => c.StandardOptionCodeNonSmoker != null
                    && c.StandardOptionCodeNonSmoker.Contains("Option 1") || (c.StandardOptionCodeSmoker != null && c.StandardOptionCodeSmoker.Contains("Option 1"))).ToList();
                }
            }
        }

        private decimal GetTotalDiscount(PDRSoldClass pdrSoldClass, PDRClassPlanTypeEnum planTypeEnum)
        {
            Log.TraceFormat("+MLDEManger.GetTotalDiscount");

            var totalDiscount = 0;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                if (pdrSoldClass != null)
                {
                    var soldPDRClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().FirstOrDefault(c => c.PDRSoldClass.Id == pdrSoldClass.Id && c.PDRClassPlanType == planTypeEnum);

                    if (soldPDRClassPlan != null)
                    {
                        var baseDiscount = soldPDRClassPlan.BaseDiscountType != null ? int.Parse(soldPDRClassPlan.BaseDiscountType.Code) : 0;
                        var demographicDiscount = soldPDRClassPlan.DemographicDiscountType != null ? int.Parse(soldPDRClassPlan.DemographicDiscountType.Code) : 0;
                        var employerPaidDiscountCode = (soldPDRClassPlan.EmployerPaidDiscountType != null) ? soldPDRClassPlan.EmployerPaidDiscountType.Code : string.Empty;
                        int employerPaidDiscount = 0;
                        int.TryParse(employerPaidDiscountCode, out employerPaidDiscount);
                        totalDiscount = baseDiscount + demographicDiscount + employerPaidDiscount;
                    }
                    else
                    {
                        totalDiscount = 0;
                    }
                }
                else
                {
                    totalDiscount = 0;
                }
            }

            Log.TraceFormat("-MLDEManger.GetTotalDiscount");

            return totalDiscount;
        }

        private bool GetLTDTaxabilityIndicator(PDRSoldClass pdrSoldClass)
        {
            bool ltdTaxIndicator = false;

            var soldPdrLtdCoverage = pdrSoldClass.PDRSoldClassLTDCoverage.FirstOrDefault();
            if (soldPdrLtdCoverage != null)
            {
                if (((ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum)soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id) == (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid))
                {
                    if (soldPdrLtdCoverage.TypeOfPayType != null && (TaxabilityTypeEnum)soldPdrLtdCoverage.TypeOfPayType == (TaxabilityTypeEnum.Taxable))
                    {
                        ltdTaxIndicator = true;
                    }
                }
            }
            return ltdTaxIndicator;
        }

        private string[] GetAvailableOptions(IEnumerable<EnrollmentPDRClass> enrollmentPDRClasss)
        {
            string[] options = { string.Empty };
            List<string> list = new List<string>();

            var enrollmentPDRClassOptions = enrollmentPDRClasss.FirstOrDefault()?.EnrollmentPDRClassOptions;
            var selectedOptions = enrollmentPDRClassOptions.Where(i => i.IsSelected);

            foreach (var option in selectedOptions)
            {
                list.Add(option.OptionCode);
            }
            return options = list.ToArray();
        }

        private PayrollDeductionTypeEnum GetPayrollDeductionType(BillingModeTypeEnum? billingModeType)
        {
            var payrollDeductionType = PayrollDeductionTypeEnum.None;

            if (billingModeType != null)
            {
                switch (billingModeType)
                {
                    case BillingModeTypeEnum.Annual:
                        payrollDeductionType = PayrollDeductionTypeEnum.Annual;
                        break;
                    case BillingModeTypeEnum.DirectBillMonthly:
                        payrollDeductionType = PayrollDeductionTypeEnum.DirectBillMonthly;
                        break;
                    case BillingModeTypeEnum.Monthly:
                        payrollDeductionType = PayrollDeductionTypeEnum.Monthly;
                        break;
                    case BillingModeTypeEnum.MonthlyGOM:
                        payrollDeductionType = PayrollDeductionTypeEnum.MonthlyGOM;
                        break;
                    case BillingModeTypeEnum.Quarterly:
                        payrollDeductionType = PayrollDeductionTypeEnum.Quarterly;
                        break;
                    case BillingModeTypeEnum.Semi_Annual:
                        payrollDeductionType = PayrollDeductionTypeEnum.SemiAnnual;
                        break;
                }

            }

            return payrollDeductionType;

        }

        private EmployeeSalaryDefinitionTypeEnum GetGroupLTDEmployeeSalaryDefinitionType(PDRSoldClassLTDCoverage pdrSoldClassLTDCoverage)
        {
            var employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.None;

            var ltdCoveredEarningsType = pdrSoldClassLTDCoverage.GroupLTDCoveredEarningsType;

            if (ltdCoveredEarningsType == null || ltdCoveredEarningsType == 0)
            {
                ltdCoveredEarningsType = GetLTDCustomCoveredEarningsType(pdrSoldClassLTDCoverage);
            }

            if (ltdCoveredEarningsType != null)
            {
                switch (ltdCoveredEarningsType)
                {
                    case CoveredEarningsTypeEnum.BaseSalaryOnly:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalary;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusBonus;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusBonusPlusCommissions;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Commission:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusCommissions;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.K1Earnings;
                        break;
                    case CoveredEarningsTypeEnum.Other:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.Other;
                        break;
                    case CoveredEarningsTypeEnum.TotalCompensation:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.TotalCompensation;
                        break;
                    case CoveredEarningsTypeEnum.W_2Income:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.W2Earnings;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Commission_K_1Earnings:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusCommissionsPlusK1Earnings;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus_K_1Earnings:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusBonusPlusK1Earnings;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_K_1Earnings:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusK1Earnings;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings_and_bonus:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.K1EarningsPlusBonus;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings_Bonus_Commission:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.K1EarningsPlusBonusCommissions;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings_Commission:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.K1EarningsPlusCommissions;
                        break;
                }

            }

            return employeeSalaryDefinitionType;
        }

        private EmployeeSalaryDefinitionTypeEnum GetEmployeeSalaryDefinitionType(PDRSoldClass pdrSoldClass)
        {
            var employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.None;

            var coveredEarningsType = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault().CoveredEarningsType;

            if (coveredEarningsType == null || coveredEarningsType == 0)
            {
                coveredEarningsType = GetCustomCoveredEarningsType(pdrSoldClass.PDRSoldClassPlan?.FirstOrDefault()?.PDRSoldClassPlanCustomizedIDIInsurableIncomes);
            }

            if (coveredEarningsType != null)
            {
                switch (coveredEarningsType)
                {
                    case CoveredEarningsTypeEnum.BaseSalaryOnly:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalary;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusBonus;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusBonusPlusCommissions;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Commission:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusCommissions;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.K1Earnings;
                        break;
                    case CoveredEarningsTypeEnum.Other:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.Other;
                        break;
                    case CoveredEarningsTypeEnum.TotalCompensation:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.TotalCompensation;
                        break;
                    case CoveredEarningsTypeEnum.W_2Income:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.W2Earnings;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Commission_K_1Earnings:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusCommissionsPlusK1Earnings;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_Bonus_K_1Earnings:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusBonusPlusK1Earnings;
                        break;
                    case CoveredEarningsTypeEnum.BaseSalary_K_1Earnings:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.BaseSalaryPlusK1Earnings;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings_and_bonus:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.K1EarningsPlusBonus;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings_Bonus_Commission:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.K1EarningsPlusBonusCommissions;
                        break;
                    case CoveredEarningsTypeEnum.K_1Earnings_Commission:
                        employeeSalaryDefinitionType = EmployeeSalaryDefinitionTypeEnum.K1EarningsPlusCommissions;
                        break;
                }

            }

            return employeeSalaryDefinitionType;
        }

        private CoveredEarningsTypeEnum? GetCustomCoveredEarningsType(IList<PDRSoldClassPlanCustomizedIDIInsurableIncome> PDRSoldClassPlanCustomizedIDIInsurableIncomes)
        {
            CoveredEarningsTypeEnum? coveredEarningsTypeEnum = CoveredEarningsTypeEnum.Other;

            var pdrSoldClassPlanCustomizedIDIInsurableIncomes = PDRSoldClassPlanCustomizedIDIInsurableIncomes.FirstOrDefault();

            if (pdrSoldClassPlanCustomizedIDIInsurableIncomes != null)
            {
                if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BaseSalaryPercentage > 0 &&
                    pdrSoldClassPlanCustomizedIDIInsurableIncomes.BonusPercentage > 0 &&
                    pdrSoldClassPlanCustomizedIDIInsurableIncomes.CommissionPercentage > 0 &&
                    pdrSoldClassPlanCustomizedIDIInsurableIncomes.K1EarningsPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.TotalCompensation;

                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BaseSalaryPercentage > 0 &&
                         pdrSoldClassPlanCustomizedIDIInsurableIncomes.BonusPercentage > 0 &&
                         pdrSoldClassPlanCustomizedIDIInsurableIncomes.K1EarningsPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Bonus_K_1Earnings;

                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BaseSalaryPercentage > 0 &&
                         pdrSoldClassPlanCustomizedIDIInsurableIncomes.CommissionPercentage > 0 &&
                         pdrSoldClassPlanCustomizedIDIInsurableIncomes.K1EarningsPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Commission_K_1Earnings;
                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BaseSalaryPercentage > 0 &&
                         pdrSoldClassPlanCustomizedIDIInsurableIncomes.K1EarningsPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_K_1Earnings;
                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BonusPercentage > 0 &&
                         pdrSoldClassPlanCustomizedIDIInsurableIncomes.CommissionPercentage > 0 &&
                        pdrSoldClassPlanCustomizedIDIInsurableIncomes.K1EarningsPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.K_1Earnings_Bonus_Commission;
                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BonusPercentage > 0 &&
                        pdrSoldClassPlanCustomizedIDIInsurableIncomes.K1EarningsPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.K_1Earnings_and_bonus;
                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.CommissionPercentage > 0 &&
                        pdrSoldClassPlanCustomizedIDIInsurableIncomes.K1EarningsPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.K_1Earnings_Commission;
                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BaseSalaryPercentage > 0 &&
                   pdrSoldClassPlanCustomizedIDIInsurableIncomes.BonusPercentage > 0 &&
                   pdrSoldClassPlanCustomizedIDIInsurableIncomes.CommissionPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission;

                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BaseSalaryPercentage > 0 &&
                  pdrSoldClassPlanCustomizedIDIInsurableIncomes.BonusPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Bonus;

                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BaseSalaryPercentage > 0 &&
                 pdrSoldClassPlanCustomizedIDIInsurableIncomes.CommissionPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Commission;

                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BaseSalaryPercentage > 0 &&
                 pdrSoldClassPlanCustomizedIDIInsurableIncomes.CommissionPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Commission;

                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.BaseSalaryPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalaryOnly;

                }
                else if (pdrSoldClassPlanCustomizedIDIInsurableIncomes.K1EarningsPercentage > 0)
                {
                    coveredEarningsTypeEnum = CoveredEarningsTypeEnum.K_1Earnings;

                }
            }
            else
            {
                coveredEarningsTypeEnum = null;
            }

            return coveredEarningsTypeEnum;
        }

        private CoveredEarningsTypeEnum GetLTDCustomCoveredEarningsType(PDRSoldClassLTDCoverage pdrSoldClassLTDCoverage)
        {
            var ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.Other;
            if (pdrSoldClassLTDCoverage.BaseSalaryPercentage > 0 &&
                pdrSoldClassLTDCoverage.BonusPercentage > 0 &&
                pdrSoldClassLTDCoverage.CommissionPercentage > 0 &&
                pdrSoldClassLTDCoverage.K1EarningsPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.TotalCompensation;

            }
            else if (pdrSoldClassLTDCoverage.BaseSalaryPercentage > 0 &&
                pdrSoldClassLTDCoverage.BonusPercentage > 0 &&
                pdrSoldClassLTDCoverage.K1EarningsPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Bonus_K_1Earnings;

            }
            else if (pdrSoldClassLTDCoverage.BaseSalaryPercentage > 0 &&
                     pdrSoldClassLTDCoverage.CommissionPercentage > 0 &&
                     pdrSoldClassLTDCoverage.K1EarningsPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Commission_K_1Earnings;
            }
            else if (pdrSoldClassLTDCoverage.BaseSalaryPercentage > 0 &&
                     pdrSoldClassLTDCoverage.K1EarningsPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_K_1Earnings;
            }
            else if (pdrSoldClassLTDCoverage.BonusPercentage > 0 &&
                     pdrSoldClassLTDCoverage.CommissionPercentage > 0 &&
                    pdrSoldClassLTDCoverage.K1EarningsPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.K_1Earnings_Bonus_Commission;
            }
            else if (pdrSoldClassLTDCoverage.BonusPercentage > 0 &&
                    pdrSoldClassLTDCoverage.K1EarningsPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.K_1Earnings_and_bonus;
            }
            else if (pdrSoldClassLTDCoverage.CommissionPercentage > 0 &&
                    pdrSoldClassLTDCoverage.K1EarningsPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.K_1Earnings_Commission;
            }
            else if (pdrSoldClassLTDCoverage.BaseSalaryPercentage > 0 &&
               pdrSoldClassLTDCoverage.BonusPercentage > 0 &&
               pdrSoldClassLTDCoverage.CommissionPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission;

            }
            else if (pdrSoldClassLTDCoverage.BaseSalaryPercentage > 0 &&
              pdrSoldClassLTDCoverage.BonusPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Bonus;

            }
            else if (pdrSoldClassLTDCoverage.BaseSalaryPercentage > 0 &&
             pdrSoldClassLTDCoverage.CommissionPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Commission;

            }
            else if (pdrSoldClassLTDCoverage.BaseSalaryPercentage > 0 &&
             pdrSoldClassLTDCoverage.CommissionPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalary_Commission;

            }
            else if (pdrSoldClassLTDCoverage.BaseSalaryPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.BaseSalaryOnly;

            }
            else if (pdrSoldClassLTDCoverage.K1EarningsPercentage > 0)
            {
                ltdCoveredEarningsTypeEnum = CoveredEarningsTypeEnum.K_1Earnings;

            }

            return ltdCoveredEarningsTypeEnum;
        }

        private ParticipantStatusEnum GetParticipantStatusCode(Participant participant)
        {
            var cmsStatus = ParticipantStatusEnum.NE;

            if (participant.ParticipantCategoryCodeType != null)
            {
                switch (participant.ParticipantCategoryCodeType)
                {
                    case ParticipantCategoryCodeTypeEnum.AMB:
                        cmsStatus = ParticipantStatusEnum.AMB;
                        break;
                    case ParticipantCategoryCodeTypeEnum.NE:
                        cmsStatus = ParticipantStatusEnum.NE;
                        break;
                    case ParticipantCategoryCodeTypeEnum.PS:
                        cmsStatus = ParticipantStatusEnum.PS;
                        break;
                    case ParticipantCategoryCodeTypeEnum.FO:
                        cmsStatus = ParticipantStatusEnum.FO;
                        break;
                }
            }

            return cmsStatus;
        }

        private List<ProducerAgentViewModel> GetProducersAndAgents(IEnumerable<CaseBroker> caseBrokers, IQueryable<ContactAddress> contactAddress)
        {
            Log.TraceFormat("+MLDEManger.GetProducersAndAgents");
            List<ProducerAgentViewModel> listProducerAgentViewModel = new List<ProducerAgentViewModel>();

            foreach (var producer in caseBrokers)
            {
                ProducerAgentViewModel producerAgentViewModel = new ProducerAgentViewModel();

                if (IsCareerAgent(producer.BrokerWritingCode))
                {
                    producerAgentViewModel.Type = ProducerAgentTypeEnum.CareerAgent;
                }
                else
                {
                    producerAgentViewModel.Type = ProducerAgentTypeEnum.Producer;
                }
                producerAgentViewModel.WritingCode = producer.BrokerWritingCode != null ? producer.BrokerWritingCode : string.Empty;
                producerAgentViewModel.AgencyCode = producer.AgencyCode;
                producerAgentViewModel.AgencyName = producer.CompanyName != null ? producer.CompanyName : string.Empty;
                CaseBrokerState cbs = producer.CaseBrokerStates.FirstOrDefault();
                if (cbs != null)
                {
                    producerAgentViewModel.LeadProducer = (bool)producer.CaseBrokerStates.FirstOrDefault().IsPrimaryBrokerIndicator;
                }

                producerAgentViewModel.Title = string.Empty;
                producerAgentViewModel.Prefix = string.Empty;

                string s = producer.BrokerName != null ? producer.BrokerName : string.Empty;
                string[] values = s.Split(',');
                int index = 0;
                for (index = 0; index < values.Length; index++)
                {
                    values[index] = values[index].Trim();

                }
                if (index >= 2)
                {
                    producerAgentViewModel.FirstName = values[1].Length > 0 ? values[0] : string.Empty;
                    producerAgentViewModel.LastName = values[0].Length > 0 ? values[1] : string.Empty;
                }
                else
                {
                    producerAgentViewModel.FirstName = producer.BrokerName != null ? producer.BrokerName : string.Empty;
                    producerAgentViewModel.LastName = string.Empty;
                }

                IQueryable<ContactAddress> producerContact = null;

                if (contactAddress != null)
                {
                    if (!string.IsNullOrEmpty(producerAgentViewModel.FirstName) && !string.IsNullOrEmpty(producerAgentViewModel.LastName))
                    {
                        producerContact = contactAddress.Where(c => c.ContactRoleType == ContactRoleTypeEnum.Producer &&
                                                                    c.ContactName.Contains(
                                                                        producerAgentViewModel.FirstName) &&
                                                                    c.ContactName.Contains(
                                                                        producerAgentViewModel.LastName));
                    }
                    else
                    {
                        //This accounts for logic above that only loads firstname field.
                        producerContact = contactAddress.Where(c => c.ContactRoleType == ContactRoleTypeEnum.Producer &&
                                                                    c.ContactName.Contains(producerAgentViewModel.FirstName));
                    }
                }

                if (producerContact.Any())
                {
                    producerAgentViewModel.EmailAddress = producerContact.FirstOrDefault().Email != null ? producerContact.FirstOrDefault().Email : "undetermined@undetermined.com";
                }

                producerAgentViewModel.Address = new AddressViewModel();

                foreach (var contactAddres in producerContact)
                {
                    if (contactAddres != null)
                    {
                        AddressViewModel address = new AddressViewModel();
                        address.LocationName = "Work";
                        address.Street1 = contactAddres.AddressLine1 != null ? contactAddres.AddressLine1 : string.Empty;
                        address.Street2 = contactAddres.AddressLine2 != null ? contactAddres.AddressLine2 : string.Empty;
                        address.City = contactAddres.City != null ? contactAddres.City : string.Empty;
                        address.State = contactAddres.StateType != null ? contactAddres.StateType.Value.ToString() : string.Empty;
                        address.ZipCode = contactAddres.ZipCode != null ? contactAddres.ZipCode : string.Empty;
                        address.Country = "United States of America";
                        address.PhoneNumber = contactAddres.Phone != null ? contactAddres.Phone : string.Empty;
                        producerAgentViewModel.Address = address;
                    }
                }

                producerAgentViewModel.StateLicenses = new List<string>();
                foreach (var producerState in producer.CaseBrokerStates)
                {
                    if (producerState.IsLicensedIndicator == true)
                        producerAgentViewModel.StateLicenses.Add(producerState.StateType.ToString());
                }
                listProducerAgentViewModel.Add(producerAgentViewModel);
            }

            Log.TraceFormat("-MLDEManger.GetProducersAndAgents");
            return listProducerAgentViewModel;

        }

        private bool IsCareerAgent(string producerWritingCode)
        {
            Log.TraceFormat("+MLDEManger.IsCareerAgent");

            bool IsCareerAgentIndicator = false;
            //string WritingCode = String.Join(",", producerWritingCode);

            using (var sqlConnection = new SqlConnection(ProductLibraryDatabaseConnection))
            {
                SqlCommand command = sqlConnection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "[Extract].[USP_Get_Producer_CareerAgentIndicator]";
                command.Parameters.Add(new SqlParameter("ODSAgentContractIdentifier", producerWritingCode));

                sqlConnection.Open();

                SqlDataAdapter sda = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                sda.Fill(ds);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    IsCareerAgentIndicator = Convert.ToBoolean(ds.Tables[0].Rows[0][0]);
                }
            }

            Log.TraceFormat("-MLDEManger.IsCareerAgent");
            return IsCareerAgentIndicator;
        }
        private string GetCompanyName(EnrollmentOutput enrollOutput, Case cases)
        {
            string Compname;
            if (enrollOutput != null && !string.IsNullOrEmpty(enrollOutput.CompanyFriendlyName))
            {
                Compname = enrollOutput.CompanyFriendlyName;
            }
            else
            {
                Compname = cases.CompanyName ?? string.Empty;
            }

            return Compname;

        }

        private string GetSisCodeAndName(Case cmscase)
        {
            string SisCode = string.Empty;
            string Sisname = string.Empty;


            if (cmscase.CompanySicMajorGroupType != null)
            {
                SisCode = cmscase.CompanySicMajorGroupType.Code;

                SisCode = SisCode.Remove(0, 2);

                Sisname = ((CompanySicMajorGroupTypeEnum)cmscase.CompanySicMajorGroupType.Id).GetDescription().ToString();
            }

            return SisCode + "-" + Sisname;

        }

        public CaseViewModel GetCaseData(int caseId)
        {
            Log.Trace("+MLDEManger.GetCaseData");

            CaseViewModel caseViewModel = new CaseViewModel();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);

                if (cmsCase == null) throw new ValidationException("Invalid case number");

                var user = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(c => c.Id == cmsCase.EnrollmentManagerId);
                var enrollmentManagerContactAddress = unitOfWork.Repository<ContactAddress>().Linq().OrderByDescending(i => i.Id)
                      .FirstOrDefault(c => c.Case.Id == cmsCase.Id && c.ContactRoleType == ContactRoleTypeEnum.EnrollmentManager);

                var currentEnrollment = unitOfWork.Repository<Enrollment>().Linq().OrderByDescending(c => c.ExtensionEndDate).FirstOrDefault(c => c.Case.Id == cmsCase.Id && (c.IsActive == null || c.IsActive == true));
                if (currentEnrollment == null) throw new ValidationException("There is no active enrollment for this case number!");


                caseViewModel.CaseId = cmsCase.Id;
                caseViewModel.CaseNumber = cmsCase.CaseNumber;
                caseViewModel.CasePassword = string.Empty;
                caseViewModel.CaseType = string.Empty;
                caseViewModel.DepartureParagraph = string.Empty;
                caseViewModel.EmployeeReferenceType = string.Empty;
                caseViewModel.EmployeeReferenceTypeId = 0;

                caseViewModel.EnrollmentEndDate = currentEnrollment.EnrollmentEndDate;
                if (user != null)
                {
                    caseViewModel.EnrollmentManagerFullName = user.FirstName + " " + user.LastName;
                    caseViewModel.EnrollmentManagerId = cmsCase.EnrollmentManagerId;
                }
                else
                {
                    caseViewModel.EnrollmentManagerFullName = string.Empty;
                    caseViewModel.EnrollmentManagerId = 0;
                }

                caseViewModel.EnrollmentManagerEnrollmentContactEmailAddress = enrollmentManagerContactAddress.Email;
                caseViewModel.EnrollmentManagerEnrollmentContactPhoneNumber = enrollmentManagerContactAddress.Phone;
                caseViewModel.EnrollmentManagerEnrollmentContact = enrollmentManagerContactAddress.ContactName;

                caseViewModel.EnrollmentName = currentEnrollment.EnrollmentName;
                caseViewModel.EnrollmentStartDate = currentEnrollment.EnrollmentStartDate;
                caseViewModel.HasMarketingVideo = false;
                caseViewModel.LastUpdatedDate = null;
                caseViewModel.LTDTaxability = false;
                caseViewModel.MicrositeUrl = string.Empty;
                //caseViewModel.MonthlyIncomeType = string.Empty;
                //caseViewModel.MonthlyIncomeTypeId = MonthlyIncomeTypeEnum.None;
                caseViewModel.Name = string.Empty;
                caseViewModel.OpeningParagraph = string.Empty;
                caseViewModel.PayrollDeductionType = string.Empty;
                caseViewModel.PayrollDeductionTypeId = PayrollDeductionTypeEnum.None;
                caseViewModel.ProductName = string.Empty;
                caseViewModel.ProductType = string.Empty;
                caseViewModel.RenewalYears = null;
                caseViewModel.UseCompactApp = _productLibraryManager.IsCompactStateCase(cmsCase.Id);

            }
            Log.Trace("-MLDEManger.GetCaseData");

            return caseViewModel;
        }

        

        #region Enrollment Participant MLDE
        public EnrollmentParticipantMLDEDto GetParticipantData(int? enrollmentParticipantId)
        {
            EnrollmentParticipantMLDEDto enrollmentParticipantVM = new EnrollmentParticipantMLDEDto();

            int? mockEnrollmentParticipantId = 0;

            string emailSequenceNumber = string.Empty;

            bool isMockEnorllmentId = enrollmentParticipantId != null && enrollmentParticipantId < 0 ? true : false;

            if (isMockEnorllmentId)
            {
                mockEnrollmentParticipantId = enrollmentParticipantId;
                string sequenceNumber = string.Empty;
                enrollmentParticipantId = ParseEnorllmentParticipantId(enrollmentParticipantId.Value, out sequenceNumber);
                emailSequenceNumber = sequenceNumber;
            }

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {


                if (isMockEnorllmentId)
                {

                    enrollmentParticipantVM = BuildMockParticipant(enrollmentParticipantId.Value, mockEnrollmentParticipantId, emailSequenceNumber);
                }
                else
                {
                    enrollmentParticipantVM = (from EPO in unitOfWork.Repository<EnrollmentParticipantOptionPlan>().Linq()
                                               join EP in unitOfWork.Repository<EnrollmentParticipant>().Linq() on EPO.EnrollmentParticipant.Id equals EP.Id
                                               join P in unitOfWork.Repository<Participant>().Linq() on EP.Participant.Id equals P.Id
                                               where EP.Id == enrollmentParticipantId
                                               select new EnrollmentParticipantMLDEDto
                                               {
                                                   EnrollmentParticipantId = EP.Id,
                                                   CaseNumber = EP.Enrollment.Case.CaseNumber,
                                                   FirstName = P.FirstName,
                                                   MiddleName = P.MiddleInitial,
                                                   LastName = P.LastName,
                                                   Suffix = P.Suffix,
                                                   WorkEmail = P.WorkEmail,
                                                   DateOfBirth = P.DateOfBirth,
                                                   Gender = P.Gender,
                                                   Occupation = P.JobTitle,
                                                   HomeStreet1 = P.HomeStreet1,
                                                   HomeStreet2 = P.HomeStreet2,
                                                   HomeCity = P.HomeCity,
                                                   HomeStateDescription = P.HomeStateDescription,
                                                   HomeZipCode = P.HomeZipCode,
                                                   PhoneNumber = P.HomePhone,
                                                   WorkStreet1 = P.WorkStreet1,
                                                   WorkStreet2 = P.WorkStreet2,
                                                   WorkCity = P.WorkCity,
                                                   WorkStateDescription = P.WorkStateDescription,
                                                   WorkZipCode = P.WorkZipCode,
                                                   ContractState = P.ContractStateDescription,
                                                   IDIInsurableIncome = P.IDIInsurableIncomeCalculatedAmount,
                                                   Salary = P.MostRecentSalaryAmount,
                                                   BonusIncome = P.MostRecentPaidBonusAmount,
                                                   CommissionIncome = P.MostRecentPaidCommissionAmount,
                                                   OtherIncome = P.OtherIncomeAmount,
                                                   RetirementContribution = P.TotalEmployerOrEmployeeRetirementContributionAmount,
                                                   GLTDBenefitCaclulatedAmount = P.GLTDBenefitCalculatedAmount <= 1 ? 0 : Math.Round(Convert.ToDouble(P.GLTDBenefitCalculatedAmount), MidpointRounding.AwayFromZero),
                                                   GLTDReplaceCalculatedPercentage = P.GLTDReplacementCalculatedPercentage * 100,
                                                   //PremiumAmount = EPO.NonSmokerPremiumAmountAnnually,
                                                   PremiumAmount = EPO.NonSmokerPremiumAmountMonthly ?? 0,
                                                   BenefitAmount = EPO.BenefitAmountBaseMonthly ?? 0,
                                                   ExistingMonthlyPremiumAmount = GetExistingMonthlyPremiumAmount(EP, P.Census.Case, "Employer"),
                                                   ExistingMonthlyBuyUpPlanPremiumAmount = GetExistingMonthlyBuyUpPlanPremiumAmount(EP, P.Census.Case, "Employee"),
                                                   ExistingMonthlyBasePlanBenefitAmount = GetExistingMonthlyBenefitAmount(EP, P.Census.Case, "Employer"),
                                                   ExistingMonthlyBuyUpPlanBenefitAmount = GetExistingMonthlyBuyUpPlanBenefitAmount(EP, P.Census.Case, "Employee"),
                                                   IDIBaseReplace = EPO.IDIBaseReplacementCalculatedPercentage * 100,
                                                   GSIBaseReplace = EPO.GSIPercentage * 100,
                                                   IsMockParticipant = false,
                                                   ParticipantCategoryCodeType = GetParticipantCategoryCodeType(P.ParticipantCategoryCodeType),
                                                   BuyUpParticipantCategoryCodeType = GetParticipantCategoryCodeType(P.BuyUpParticipantCategoryCodeType),
                                                   MldeStatus =EP.MldeStatusType!=null ? EP.MldeStatusType.GetDescription() : string.Empty,
                                               }).FirstOrDefault();

                }

                if (enrollmentParticipantVM == null)
                {
                    Log.ErrorFormat($"-MLDEManger.Get EnrollmentParticipantId={enrollmentParticipantId} no participant details found!");
                    return null;// Request.CreateResponse(HttpStatusCode.NoContent);
                }

                var enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq().FirstOrDefault(c =>
                    c.Id == enrollmentParticipantId &&
                    (c.Participant.IsEligible == true ||
                     (c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.NoLongerInGroup &&
                      c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.ActivePolicyNoLongerInGroup &&
                      c.Participant.InEligibleReason_Id == null)
                    ));

                if (enrollmentParticipant == null)
                {
                    Log.WarnFormat($"-MLDEManger.Get EnrollmentParticipantId={enrollmentParticipantId} no enrollment Participant details found!");
                    throw new ValidationException("{\"ErrorCode\":\"NotEligible\", \"ErrorMessage\":\"Participant is not eligible for MLDE\"}");
                }
                if (enrollmentParticipant != null && enrollmentParticipant.MldeStatusType == MldeStatusTypeEnum.Complete)
                {
                    Log.WarnFormat($"-MLDEManger.Get EnrollmentParticipantId={enrollmentParticipantId} has already submitted the application!");
                    throw new ValidationException("{\"ErrorCode\":\"AppSubmitted\", \"ErrorMessage\":\"Application already submitted\"}");
                }
                if (!enrollmentParticipant.Participant.IsMicrositeAccess)
                {
                    Log.WarnFormat($"MicrositeAccess is not active for EnrollmentParticipantId:{enrollmentParticipantId}");
                    throw new ValidationException("{\"ErrorCode\":\"MicrositeAccessNotActive\", \"ErrorMessage\":\"MicrositeAccess is not active for current Participant\"}");
                }
                if (!(enrollmentParticipant.Participant.IsEligible == true))
                {
                    Log.WarnFormat($"EnrollmentParticipantId:{enrollmentParticipantId} is not eligible for MLDE");
                    throw new ValidationException("{\"ErrorCode\":\"NotEligible\", \"ErrorMessage\":\"Participant is not eligible for MLDE\"}");
                }
                if (enrollmentParticipant != null && enrollmentParticipant.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB
                    && enrollmentParticipant.MldeStatusType == MldeStatusTypeEnum.Accepted)
                {
                    Log.WarnFormat($"-MLDEManger.Get EnrollmentParticipantId={enrollmentParticipantId} has already accepted the application!");
                    throw new ValidationException("{\"ErrorCode\":\"AMBAccepted\", \"ErrorMessage\":\"AMB Application already accepted\"}");
                }
                var isEnrollmentInActive = enrollmentParticipant.Enrollment.IsActive == false;
                if (isEnrollmentInActive || enrollmentParticipant.Enrollment.ExtensionEndDate < DateTime.Now)
                {
                    Log.WarnFormat($"Assigned enrollment '{enrollmentParticipant.Enrollment.Id} - {enrollmentParticipant.Enrollment.EnrollmentName}' is no longer active this  EnrollmentParticipantId:{enrollmentParticipantId}!");
                    throw new ValidationException("{\"ErrorCode\":\"EnrollmentInactive\", \"ErrorMessage\":\"Assigned enrollment is no longer active for current Participant!\"}");
                }

                var cmsCase = enrollmentParticipant.Enrollment?.Case;

                var pdrClasses = enrollmentParticipant.Participant.PlanDesignRequestClass;

                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(i => i.PlanDesignRequestClass.Id == pdrClasses.Id);

                //var currentLTDs = AdditionalLtdDatabuilder(enrollmentParticipant, pdrSoldClass, cmsCase);

                var currentLTDs = CoverageDetailDataBuilder(enrollmentParticipant, pdrSoldClass, cmsCase);

                var MLDEStatus = unitOfWork.Repository<EnrollmentMLDEStatus>().Linq()
                    .OrderByDescending(i => i.Id)
                    .FirstOrDefault(p => p.Enrollment_Id == enrollmentParticipant.Enrollment.Id);

                var pdrSoldClassLTDCoverage = unitOfWork.Repository<PDRSoldClassLTDCoverage>().Linq().FirstOrDefault(p => p.PDRSoldClass.Id == pdrSoldClass.Id);

                var enrollmentPDRClasses = enrollmentParticipant.Enrollment.Classes;
                var enrollmentPDRClassesOption = unitOfWork.Repository<EnrollmentPDRClassOption>().Linq()
                    .FirstOrDefault(p => p.EnrollmentPDRClass.Id == enrollmentPDRClasses[0].Id && p.IsSelected == true);

                var enrollmentParticipantOptionPlan = unitOfWork.Repository<EnrollmentParticipantOptionPlan>().Linq()
                                                        .Where(i => i.EnrollmentParticipant.Id == enrollmentParticipantId).ToList();

                var enrollmentOuput = unitOfWork.Repository<EnrollmentOutput>().Linq()
                 .FirstOrDefault(i => i.Enrollment.Id == enrollmentParticipant.Enrollment.Id);

                enrollmentParticipantVM.EnrollmentId = enrollmentParticipant.Enrollment.Id;
                enrollmentParticipantVM.EnrollmentName = enrollmentParticipant.Enrollment.EnrollmentName;

                enrollmentParticipantVM.CompanyName = GetCompanyName(enrollmentOuput, cmsCase);

                enrollmentParticipantVM.EnrollmentStartDate = enrollmentParticipant.Enrollment.EnrollmentStartDate;
                enrollmentParticipantVM.EnrollmentEndDate = enrollmentParticipant.Enrollment.EnrollmentEndDate;
                enrollmentParticipantVM.CaseYear = unitOfWork.Repository<AnnualReview>().Linq()
                    .FirstOrDefault(x => x.Case.Id == cmsCase.Id)
                    ?.CaseYear + 1 ?? 1;

                enrollmentParticipantVM.MLDIGroup.GroupName = pdrClasses.PlanDesignRequestClassName;
                enrollmentParticipantVM.MLDIGroup.GroupDescription = pdrSoldClass.EligiblePopulationText;                        

                enrollmentParticipantVM.MLDIGroup.PrimaryPlanDesignType = GetPlanDesignType(pdrSoldClass?.PDRSoldClassPlan, PDRClassPlanTypeEnum.Primary);
                enrollmentParticipantVM.MLDIGroup.BuyUpPlanDesignType = GetPlanDesignType(pdrSoldClass?.PDRSoldClassPlan, PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                enrollmentParticipantVM.MLDIGroup.LTDCoverageEarnings = GetGroupLTDEmployeeSalaryDefinitionType(pdrSoldClassLTDCoverage).GetDescription();
                enrollmentParticipantVM.MLDIGroup.LTDPremiumPayerandTaxability = pdrSoldClassLTDCoverage.PremiumAndTaxpayerLiabilityType != null ?
                    ((ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum?)pdrSoldClassLTDCoverage.PremiumAndTaxpayerLiabilityType.Id).GetDescription() :
                    null;

                enrollmentParticipantVM.MLDIGroup.ApprovedCoverageEarnings = GetEmployeeSalaryDefinitionType(pdrSoldClass).GetDescription();
                enrollmentParticipantVM.MLDIGroup.ParticipantCount = MLDEStatus?.NumberofParticipants ?? 0;

                enrollmentParticipantVM.MLDIGroup.OptionOffered = enrollmentPDRClassesOption.OptionCode;
                var isVGSIPlan = pdrSoldClass.PlanDesignRequestClass?.PlanDesignRequestClassProducts?.Any(x => x.IsGSIPlanIndicator == true) ?? false;
                enrollmentParticipantVM.MLDIGroup.IsVgsiPlanDesignType = isVGSIPlan;
                enrollmentParticipantVM.MLDIGroup.MLDIAdditionalLtd = currentLTDs;
                enrollmentParticipantVM.MLDIGroup.MLDIQualifiedOffer = GetQualifiedOffers(enrollmentParticipant, pdrSoldClass, cmsCase, currentLTDs);


                var enrollmentParticipantPolicies = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq()
                    .OrderByDescending(i => i.Id)
                    .Where(i => i.EnrollmentParticipant.Id == enrollmentParticipantId);

                foreach (var enrollmentParticipantPolicy in enrollmentParticipantPolicies)
                {
                    if (enrollmentParticipantPolicy.EnrollmentParticipantOptionPlan != null)
                    {
                        if (enrollmentParticipantPolicy.EnrollmentParticipantOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary)
                        {
                            enrollmentParticipantVM.ParticipantBasePlanPolicyNumber = enrollmentParticipantPolicy.PolicyNumber;
                        }
                        else if (enrollmentParticipantPolicy.EnrollmentParticipantOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp)
                        {
                            enrollmentParticipantVM.ParticipantBuyUpPlanPolicyNumber = enrollmentParticipantPolicy.PolicyNumber;
                        }
                    }
                }

                #region Below logic is written sepcifically for the AMB classed out to Voluntary scenario (ER/VGSI)
                /* START: Below logic is written sepcifically for the AMB classed out to Voluntary scenario (ER/VGSI) */
                var pdrSoldClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(l => l.PDRSoldClass.Id == pdrSoldClass.Id).ToList();
                var basePlanType = pdrSoldClassPlan.FirstOrDefault(i => i.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);

                bool isVOLOnlyClassPolicy = false;
                if (basePlanType != null)
                {
                    if (basePlanType.PremiumPayerAndTaxabilityType?.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable)
                    {
                        isVOLOnlyClassPolicy = true;
                    }
                }

                if (isVOLOnlyClassPolicy)
                {
                    var volClassenrollmentParticipantPolicies = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq()
                   .OrderByDescending(i => i.Id).FirstOrDefault(i => i.EnrollmentParticipant.Id == enrollmentParticipantId); //pick the recent policy number

                    if (volClassenrollmentParticipantPolicies != null && volClassenrollmentParticipantPolicies.EnrollmentPDRClassOptionPlan != null)
                    {
                        if (volClassenrollmentParticipantPolicies?.EnrollmentPDRClassOptionPlan?.PDRClassPlanType == PDRClassPlanTypeEnum.Primary)
                        {
                            enrollmentParticipantVM.ParticipantBasePlanPolicyNumber = volClassenrollmentParticipantPolicies.PolicyNumber;
                            enrollmentParticipantVM.ParticipantBuyUpPlanPolicyNumber = null;
                        }                       
                    }
                }
                /* END: Above logic is written sepcifically for the AMB classed out to Voluntary scenario (ER/VGSI)*/
                #endregion
            }

            return enrollmentParticipantVM;
        }

        private string GetPlanDesignType(IList<PDRSoldClassPlan> pdrSoldClassPlan, PDRClassPlanTypeEnum pdrClassPlanType)
        {
            var planDesignType = pdrSoldClassPlan?.FirstOrDefault(plandesigntype => plandesigntype.PDRClassPlanType == pdrClassPlanType)?.PlanDesignType;
            return planDesignType == PlanDesignTypeEnum.CombinationPlan ? "Combination Plan" : planDesignType?.GetDescription();
        }
        
        public decimal? GetExistingMonthlyPremiumAmount(EnrollmentParticipant enrollmentParticipant, Case cmscase, string pdrClassPlanType)
        {
            decimal? modalPremiums = null;
            try
            {

                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {

                    bool isVOLOnlyClassPolicy = false;
                    var pdrClassId = enrollmentParticipant.Participant.PlanDesignRequestClass.Id;
                    var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(i => i.PlanDesignRequestClass.Id == pdrClassId);
                    var pdrSoldClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(l => l.PDRSoldClass.Id == pdrSoldClass.Id).ToList();

                    var basePlanType = pdrSoldClassPlan.FirstOrDefault(i => i.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    if (basePlanType != null)
                    {
                        if (basePlanType.PremiumPayerAndTaxabilityType?.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable)
                        {
                            isVOLOnlyClassPolicy = true;
                        }
                    }

                    if (isVOLOnlyClassPolicy)
                    {
                        var policyDetails = enrollmentParticipant.Participant.ParticipantExistingPolicies.SelectMany(c => c.ParticipantExistingPolicyDetails).ToList();
                        var policyInfo = policyDetails.Where(c => c.CaseNumber != null && c.CaseNumber.Trim() == cmscase.CaseNumber.Trim()
                        && c.CLOASPolicyStatus == "Inforce").ToList();

                        modalPremiums = policyInfo.Sum(c => c.ModalPremium);

                    }
                    else if (pdrClassPlanType == "Employer")
                    {
                        var policyDetails = enrollmentParticipant.Participant.ParticipantExistingPolicies.SelectMany(c => c.ParticipantExistingPolicyDetails).ToList();
                        var policyInfo = policyDetails.Where(c => c.CaseNumber != null && c.CaseNumber.Trim() == cmscase.CaseNumber.Trim()
                        && c.CLOASPolicyStatus == "Inforce" && c.PremiumPayer == "Employer").ToList();

                        modalPremiums = policyInfo.Sum(c => c.ModalPremium);
                    }

                }                
            }
            catch (Exception ex)
            {

                Log.Error($"MLDEManger.GetExistingMonthlyPremiumAmount: Error while getting existing monthly premium for the ParticipantId{enrollmentParticipant.Participant.Id}!", ex);
                modalPremiums = null;
            }

            return (modalPremiums != null && modalPremiums != 0) ? modalPremiums : null;
        }
        public decimal? GetExistingMonthlyBuyUpPlanPremiumAmount(EnrollmentParticipant enrollmentParticipant, Case cmscase, string pdrClassPlanType)
        {
            decimal? modalPremiums = null;
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {

                    bool isVOLOnlyClassPolicy = false;
                    var pdrClassId = enrollmentParticipant.Participant.PlanDesignRequestClass.Id;
                    var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(i => i.PlanDesignRequestClass.Id == pdrClassId);
                    var pdrSoldClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(l => l.PDRSoldClass.Id == pdrSoldClass.Id).ToList();

                    var basePlanType = pdrSoldClassPlan.FirstOrDefault(i => i.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    if (basePlanType != null)
                    {
                        if (basePlanType.PremiumPayerAndTaxabilityType?.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable)
                        {
                            isVOLOnlyClassPolicy = true;
                        }
                    }
                    
                    if (pdrClassPlanType == "Employee" && !isVOLOnlyClassPolicy)
                    {
                        var policyDetails = enrollmentParticipant.Participant.ParticipantExistingPolicies.SelectMany(c => c.ParticipantExistingPolicyDetails).ToList();
                        var policyInfo = policyDetails.Where(c => c.CaseNumber != null
                                                                           && c.CaseNumber.Trim() == cmscase.CaseNumber.Trim()
                                                                           && c.CLOASPolicyStatus == "Inforce" && c.PremiumPayer == "Employee").ToList();


                        modalPremiums = policyInfo.Sum(c => c.ModalPremium);
                    }
                }
            }
            catch (Exception ex)
            {

                Log.Error($"MLDEManger.GetExistingMonthlyBuyUpPlanPremiumAmount: Error while getting existing monthly premium for the ParticipantId{enrollmentParticipant.Participant.Id}!", ex);
                modalPremiums = null;
            }

            return (modalPremiums != null && modalPremiums != 0) ? modalPremiums : null;
        }
        public decimal? GetExistingMonthlyBenefitAmount(EnrollmentParticipant enrollmentParticipant, Case cmscase, string pdrClassPlanType)
        {
            decimal? monthlyIndemnity = null;
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {

                    bool isVOLOnlyClassPolicy = false;
                    var pdrClassId = enrollmentParticipant.Participant.PlanDesignRequestClass.Id;
                    var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(i => i.PlanDesignRequestClass.Id == pdrClassId);
                    var pdrSoldClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(l => l.PDRSoldClass.Id == pdrSoldClass.Id).ToList();

                    var basePlanType = pdrSoldClassPlan.FirstOrDefault(i => i.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    if (basePlanType != null)
                    {
                        if (basePlanType.PremiumPayerAndTaxabilityType?.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable)
                        {
                            isVOLOnlyClassPolicy = true;
                        }
                    }

                    if (isVOLOnlyClassPolicy)
                    {
                        var policyDetails = enrollmentParticipant.Participant.ParticipantExistingPolicies.SelectMany(c => c.ParticipantExistingPolicyDetails).ToList();
                        var policyInfo = policyDetails.Where(c => c.CaseNumber != null
                                                                           && c.CaseNumber.Trim() == cmscase.CaseNumber.Trim()
                                                                           && c.CLOASPolicyStatus == "Inforce").ToList();

                        monthlyIndemnity = policyInfo.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                    }
                    else if (pdrClassPlanType == "Employer")
                    {
                        var policyDetails = enrollmentParticipant.Participant.ParticipantExistingPolicies.SelectMany(c => c.ParticipantExistingPolicyDetails).ToList();
                        var policyInfo = policyDetails.Where(c => c.CaseNumber != null
                                                                           && c.CaseNumber.Trim() == cmscase.CaseNumber.Trim()
                                                                           && c.CLOASPolicyStatus == "Inforce" && c.PremiumPayer == "Employer").ToList();

                        monthlyIndemnity = policyInfo.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));
                    }
                }

            }
            catch (Exception ex)
            {

                Log.Error($"MLDEManger.GetExistingMonthlyBenefitAmount: Error while getting existing monthly premium for the ParticipantId{enrollmentParticipant.Participant.Id}!", ex);
                monthlyIndemnity = null;
            }

            return (monthlyIndemnity != null && monthlyIndemnity != 0) ? monthlyIndemnity : null;
        }
        public decimal? GetExistingMonthlyBuyUpPlanBenefitAmount(EnrollmentParticipant enrollmentParticipant, Case cmscase, string pdrClassPlanType)
        {
            decimal? monthlyIndemnity = null;
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {

                    bool isVOLOnlyClassPolicy = false;
                    var pdrClassId = enrollmentParticipant.Participant.PlanDesignRequestClass.Id;
                    var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(i => i.PlanDesignRequestClass.Id == pdrClassId);
                    var pdrSoldClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(l => l.PDRSoldClass.Id == pdrSoldClass.Id).ToList();

                    var basePlanType = pdrSoldClassPlan.FirstOrDefault(i => i.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    if (basePlanType != null)
                    {
                        if (basePlanType.PremiumPayerAndTaxabilityType?.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable)
                        {
                            isVOLOnlyClassPolicy = true;
                        }
                    }

                    if (pdrClassPlanType == "Employee" && !isVOLOnlyClassPolicy)
                    {
                        var policyDetails = enrollmentParticipant.Participant.ParticipantExistingPolicies.SelectMany(c => c.ParticipantExistingPolicyDetails).ToList();
                        var policyInfo = policyDetails.Where(c => c.CaseNumber != null
                                                                           && c.CaseNumber.Trim() == cmscase.CaseNumber.Trim()
                                                                           && c.CLOASPolicyStatus == "Inforce" && c.PremiumPayer == "Employee").ToList();

                        monthlyIndemnity = policyInfo.Sum(p => p.MonthlyIndemnity + (p.AMBAmount != null ? p.AMBAmount : 0.0m));

                    }
                }

            }
            catch (Exception ex)
            {

                Log.Error($"MLDEManger.GetExistingMonthlyBuyUpPlanBenefitAmount: Error while getting existing monthly premium for the ParticipantId{enrollmentParticipant.Participant.Id}!", ex);
                monthlyIndemnity = null;
            }

            return (monthlyIndemnity != null && monthlyIndemnity != 0) ? monthlyIndemnity : null;
        }
        public MLDEAMBDto GetAMBDataBasedOnMLDEPolicyNumber(MLDEAMBDto mldeAmbModel, EnrollmentParticipantPolicy enrollmentParticipantPolicy, EnrollmentParticipant enrollmentParticipant)
        {
            if (enrollmentParticipant.Enrollment != null &&
               (enrollmentParticipant.Enrollment.IsActive == null || enrollmentParticipant.Enrollment.IsActive == true) &&
               (enrollmentParticipant.Participant.IsEligible == null || enrollmentParticipant.Participant.IsEligible == true) &&
               (enrollmentParticipant.Participant.IsAMBIncreaseIndicator != null && enrollmentParticipant.Participant.IsAMBIncreaseIndicator == true) &&
               (enrollmentParticipant.IsNegativeEnrollmentProcessed != true))
            {
                Log.TraceFormat("+GetAMBDataBasedOnMLDEPolicyNumber");
                int slaHours = 24;

                var timeUtc = DateTime.UtcNow;
                TimeZoneInfo easternZone = null;
                try
                {
                    easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                }
                catch
                {
                    easternZone = TimeZoneInfo.FindSystemTimeZoneById("US/Eastern");
                }
                DateTime easternTime = TimeZoneInfo.ConvertTimeFromUtc(timeUtc, easternZone);

                mldeAmbModel.ProcessDate = _taskManager.GetNextWorkingDay(easternTime, slaHours);
                var cmsCase = enrollmentParticipantPolicy.EnrollmentParticipant.Enrollment.Case;
                if (cmsCase != null)
                {
                    mldeAmbModel.CaseName = cmsCase.CompanyName;
                    mldeAmbModel.CaseNumber = cmsCase.CaseNumber;
                    if (cmsCase.CaseUnderwritingRequests != null)
                    {
                        mldeAmbModel.IsCorpSitus = cmsCase.CaseUnderwritingRequests.FirstOrDefault().SitusType == SitusTypeEnum.Corporate ? true : false;
                    }
                }
                mldeAmbModel.ContractStateCode = enrollmentParticipant.Participant.ContractState != null ? enrollmentParticipant.Participant.ContractState.GetCode() : string.Empty;
                mldeAmbModel.PolicyNumber = enrollmentParticipantPolicy.PolicyNumber;
                mldeAmbModel.CmsId = enrollmentParticipant.Id;
                mldeAmbModel.AmbIndicator = (enrollmentParticipant.Participant.IsAMBIncreaseIndicator != null && enrollmentParticipant.Participant.IsAMBIncreaseIndicator == true) ? "Y" : "N";
                var enrollmentParticipantOptionPlan = enrollmentParticipantPolicy.EnrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault(a => a.PDRClassPlanType == enrollmentParticipantPolicy.EnrollmentPDRClassOptionPlan?.PDRClassPlanType);
                if (enrollmentParticipantOptionPlan != null)
                {
                    mldeAmbModel.AmbBenefitTypeId =
                        (int)enrollmentParticipantOptionPlan.Riders
                            .Select(r => r.BenefitType = BenefitTypeEnum.AdditionalMonthlyBenefit).FirstOrDefault();
                    mldeAmbModel.AmbBenefitPeriodCode = (enrollmentParticipantOptionPlan.BenefitPeriod != null)
                        ? enrollmentParticipantOptionPlan.BenefitPeriod.GetCode()
                        : string.Empty;

                    mldeAmbModel.AmbEliminationPeriodCode =
                        GetAMBEliminationPeriodCode(enrollmentParticipantOptionPlan.EliminationPeriod);

                    mldeAmbModel.AmbMonthlyBenefitAmount =
                        (enrollmentParticipantOptionPlan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                            ? enrollmentParticipant.Participant.RPPAMBCalculatedAmount
                            : ((enrollmentParticipantOptionPlan.PDRClassPlanType != null &&
                                enrollmentParticipantOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary)
                                ? enrollmentParticipant.Participant.BaseAMBCalculatedAmount
                                : enrollmentParticipant.Participant.VGSIBuyUpAMBCalculatedAmount);


                    if (enrollmentParticipantPolicy.EnrollmentParticipant.Enrollment.PricingType != null)
                        if (enrollmentParticipantPolicy.EnrollmentParticipantOptionPlan.PlanDesignType != null)
                            mldeAmbModel.ProductVarientID = (int)_productLibraryManager.GetProductVariantType(
                                enrollmentParticipantPolicy.EnrollmentParticipant.Enrollment.PricingType.Value,
                                enrollmentParticipantPolicy.EnrollmentParticipantOptionPlan.PlanDesignType.Value);


                    if (mldeAmbModel.ProductVarientID != null)
                        mldeAmbModel.TablePremiumSeriesCode = LookupTablePremiumSeries(
                            (int)mldeAmbModel.ProductVarientID, enrollmentParticipant.Participant.ContractState,
                            new List<int?>
                            {
                            mldeAmbModel.AmbBenefitTypeId
                            }).FirstOrDefault()
                            ?.TablePremiumSeriesCode;
                }
                mldeAmbModel.ContractStateCode = enrollmentParticipant.Participant.ContractState != null ? enrollmentParticipant.Participant.ContractState.GetCode() : string.Empty;
                mldeAmbModel.CmsId = enrollmentParticipant.Id;
                mldeAmbModel.EnrollmentParticipantPolicyId = enrollmentParticipantPolicy.Id;
                mldeAmbModel.ApplicationState = mldeAmbModel.ContractStateCode;
                mldeAmbModel.AmbIndicator = (enrollmentParticipant.Participant.IsAMBIncreaseIndicator != null && enrollmentParticipant.Participant.IsAMBIncreaseIndicator == true) ? "Y" : "N";
                mldeAmbModel.EmailAddress = enrollmentParticipant.Participant.WorkEmail ?? string.Empty;
                mldeAmbModel.InsuredsFirstName = enrollmentParticipant.Participant.FirstName;
                mldeAmbModel.InsuredsLastName = enrollmentParticipant.Participant.LastName;
                mldeAmbModel.EffectiveDate = enrollmentParticipant.Enrollment.EffectiveDate;

                Log.TraceFormat("-GetAMBDataBasedOnMLDEPolicyNumber");
            }


            return mldeAmbModel;
        }


        public MLDEAMBDto GetBuyUpAMBDataBasedOnMLDEPolicyNumber(MLDEAMBDto mldeAmbModel, EnrollmentParticipantPolicy enrollmentParticipantPolicy, EnrollmentParticipant enrollmentParticipant)
        {


            if (enrollmentParticipant.Enrollment != null &&
               (enrollmentParticipant.Enrollment.IsActive == null || enrollmentParticipant.Enrollment.IsActive == true) &&
               (enrollmentParticipant.Participant.IsEligible == null || enrollmentParticipant.Participant.IsEligible == true) &&
               enrollmentParticipant.Participant.IsBuyUpAMBIncreaseIndicator == true)
            {
                Log.TraceFormat("+GetBuyUpAMBDataBasedOnMLDEPolicyNumber");
                int slaHours = 24;

                var timeUtc = DateTime.UtcNow;
                TimeZoneInfo easternZone = null;
                try
                {
                    easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                }
                catch
                {
                    easternZone = TimeZoneInfo.FindSystemTimeZoneById("US/Eastern");
                }
                DateTime easternTime = TimeZoneInfo.ConvertTimeFromUtc(timeUtc, easternZone);

                mldeAmbModel.ProcessDate = _taskManager.GetNextWorkingDay(easternTime, slaHours);
                var cmsCase = enrollmentParticipantPolicy.EnrollmentParticipant.Enrollment.Case;
                if (cmsCase != null)
                {
                    mldeAmbModel.CaseName = cmsCase.CompanyName;
                    mldeAmbModel.CaseNumber = cmsCase.CaseNumber;
                    if (cmsCase.CaseUnderwritingRequests != null)
                    {
                        mldeAmbModel.IsCorpSitus = cmsCase.CaseUnderwritingRequests.FirstOrDefault().SitusType == SitusTypeEnum.Corporate ? true : false;
                    }
                }
                mldeAmbModel.ContractStateCode = enrollmentParticipant.Participant.ContractState != null ? enrollmentParticipant.Participant.ContractState.GetCode() : string.Empty;
                mldeAmbModel.PolicyNumber = enrollmentParticipantPolicy.PolicyNumber;
                mldeAmbModel.CmsId = enrollmentParticipant.Id;
                mldeAmbModel.AmbIndicator = "Y";

              var enrollmentParticipantOptionPlan = enrollmentParticipantPolicy.EnrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault(a => a.PDRClassPlanType == enrollmentParticipantPolicy.EnrollmentPDRClassOptionPlan?.PDRClassPlanType);
                if (enrollmentParticipantOptionPlan != null)
                {
                    mldeAmbModel.AmbBenefitTypeId =
                        (int)enrollmentParticipantOptionPlan.Riders
                            .Select(r => r.BenefitType = BenefitTypeEnum.AdditionalMonthlyBenefit).FirstOrDefault();
                    mldeAmbModel.AmbBenefitPeriodCode = (enrollmentParticipantOptionPlan.BenefitPeriod != null)
                        ? enrollmentParticipantOptionPlan.BenefitPeriod.GetCode()
                        : string.Empty;

                    mldeAmbModel.AmbEliminationPeriodCode =
                        GetAMBEliminationPeriodCode(enrollmentParticipantOptionPlan.EliminationPeriod);

                    mldeAmbModel.AmbMonthlyBenefitAmount =
                        (enrollmentParticipantOptionPlan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                            ? enrollmentParticipant.Participant.RPPAMBCalculatedAmount
                            : ((enrollmentParticipantOptionPlan.PDRClassPlanType != null &&
                                enrollmentParticipantOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary)
                                ? enrollmentParticipant.Participant.BaseAMBCalculatedAmount
                                : enrollmentParticipant.Participant.VGSIBuyUpAMBCalculatedAmount);


                    if (enrollmentParticipantPolicy.EnrollmentParticipant.Enrollment.PricingType != null)
                        if (enrollmentParticipantPolicy.EnrollmentParticipantOptionPlan.PlanDesignType != null)
                            mldeAmbModel.ProductVarientID = (int)_productLibraryManager.GetProductVariantType(
                                enrollmentParticipantPolicy.EnrollmentParticipant.Enrollment.PricingType.Value,
                                enrollmentParticipantPolicy.EnrollmentParticipantOptionPlan.PlanDesignType.Value);


                    if (mldeAmbModel.ProductVarientID != null)
                        mldeAmbModel.TablePremiumSeriesCode = LookupTablePremiumSeries(
                            (int)mldeAmbModel.ProductVarientID, enrollmentParticipant.Participant.ContractState,
                            new List<int?>
                            {
                            mldeAmbModel.AmbBenefitTypeId
                            }).FirstOrDefault()
                            ?.TablePremiumSeriesCode;
                }
                mldeAmbModel.EnrollmentParticipantPolicyId = enrollmentParticipantPolicy.Id;
                mldeAmbModel.ApplicationState = mldeAmbModel.ContractStateCode;
                mldeAmbModel.EmailAddress = enrollmentParticipant.Participant.WorkEmail ?? string.Empty;
                mldeAmbModel.InsuredsFirstName = enrollmentParticipant.Participant.FirstName;
                mldeAmbModel.InsuredsLastName = enrollmentParticipant.Participant.LastName;
                mldeAmbModel.EffectiveDate = enrollmentParticipant.Enrollment.EffectiveDate;

                Log.TraceFormat("-GetBuyUpAMBDataBasedOnMLDEPolicyNumber");
            }


            return mldeAmbModel;
        }



        public List<TablePremiumSeriesResponse> LookupTablePremiumSeries(int optionVmProductVariantAssociationId,
           StateTypeEnum? cmsParticipantContractState, List<int?> benefitTypes)
        {
            // Build Request for web service 
            var request = new TablePremiumSeriesRequest();
            var response = new List<TablePremiumSeriesResponse>();
            var newresponse = new List<TablePremiumSeriesResponse>();

            request.ProductVariantAssociationID = optionVmProductVariantAssociationId;
            if (cmsParticipantContractState != null) request.StateTypeID = (int)cmsParticipantContractState;
            request.Benefits = benefitTypes;

            //Check whether cached premimumseriesresponse have all benefittypeids that we are looking for
            bool? allBenefitsAvailable = false;
            List<int?> cachedBenefitTypes;
            List<int?> newBenefitTypes = null;
            if (_premiumSeriesCache?.Count > 0)
            {
                cachedBenefitTypes = _premiumSeriesCache?.First()?.TablePremiumSeriesResponse?
                    .Select(t => (int?)t.BenefitTypeID).ToList();
                newBenefitTypes = benefitTypes?.Except(cachedBenefitTypes).ToList();
                allBenefitsAvailable = !newBenefitTypes?.Any();
                request.Benefits = newBenefitTypes?.Count > 0 ? newBenefitTypes : benefitTypes;
            }

            response = _premiumSeriesCache?.FirstOrDefault(i => i.StateTypeID == request.StateTypeID &&
                                                                i.ProductVariantAssociationID == request.ProductVariantAssociationID)?.TablePremiumSeriesResponse;

            if (response == null || allBenefitsAvailable == false)
            {
                newresponse = _productLibraryWebServiceClient.GetTablePremiumSeriesCode(request);
                var tblPremiumSeriesResponse = _premiumSeriesCache?.Count > 0 ? _premiumSeriesCache?[0].TablePremiumSeriesResponse : null;

                if (response == null)
                {
                    _premiumSeriesCache?.Add(new TablePremiumSeriesResponseCache
                    {
                        StateTypeID = request.StateTypeID,
                        ProductVariantAssociationID = request.ProductVariantAssociationID,
                        TablePremiumSeriesResponse = newresponse
                    });
                }
                else
                {
                    if (tblPremiumSeriesResponse?.Count > 0)
                    {
                        tblPremiumSeriesResponse.AddRange(newresponse);
                        _premiumSeriesCache[0].TablePremiumSeriesResponse = tblPremiumSeriesResponse;
                    }
                }
            }

            return _premiumSeriesCache?.FirstOrDefault()?.TablePremiumSeriesResponse;
        }
        private string GetAMBEliminationPeriodCode(EliminationPeriodTypeEnum? eliminationPeriod)
        {
            string eliminationPeriodCode = string.Empty;
            if (eliminationPeriod != null)
            {
                if (eliminationPeriod == EliminationPeriodTypeEnum._180)
                {
                    eliminationPeriodCode = "180";
                }
                else if (eliminationPeriod == EliminationPeriodTypeEnum._360)
                {
                    eliminationPeriodCode = "360";
                }
                else if (eliminationPeriod == EliminationPeriodTypeEnum._720)
                {
                    eliminationPeriodCode = "720";
                }
                else if (eliminationPeriod == EliminationPeriodTypeEnum._090)
                {
                    eliminationPeriodCode = "090";
                }
            }
            return eliminationPeriodCode;
        }

        private string GetParticipantCategoryCodeType(ParticipantCategoryCodeTypeEnum? categoryCodeType)
        {
            string codeType = string.Empty;

            if (categoryCodeType == ParticipantCategoryCodeTypeEnum.AMB)
            {
                codeType = ParticipantCategoryCodeTypeEnum.AMB.ToString();
            }
            else if (categoryCodeType == ParticipantCategoryCodeTypeEnum.FO)
            {
                codeType = ParticipantCategoryCodeTypeEnum.FO.ToString();
            }
            else if (categoryCodeType == ParticipantCategoryCodeTypeEnum.NE)
            {
                codeType = ParticipantCategoryCodeTypeEnum.NE.ToString();
            }
            else if (categoryCodeType == ParticipantCategoryCodeTypeEnum.PS)
            {
                codeType = ParticipantCategoryCodeTypeEnum.PS.ToString();
            }

            return codeType;
        }

        private decimal? GetIDIReplacementPercentagee(List<EnrollmentParticipantOptionPlan> epo, string option)
        {
            decimal idiPercentage = 0.0m;

            var idiOption = epo.Where(i => i.StandardOptionCodeNonSmoker.ToLower().Contains(option.ToLower())).FirstOrDefault();
            if (idiOption != null)
            {
                idiPercentage = idiOption.IDIBaseReplacementCalculatedPercentage != null ? idiOption.IDIBaseReplacementCalculatedPercentage.Value * 100 : 0.0m;
            }
            return idiPercentage.Roundoff(2);
        }

        private int ParseEnorllmentParticipantId(int enrollmentParticipantId, out string sequenceNumber)
        {
            int parsedEnorllmentParticipantId = 0;
            if (enrollmentParticipantId.ToString().Length > 0 && enrollmentParticipantId < 0)
            {
                int.TryParse(enrollmentParticipantId.ToString().Substring(0, enrollmentParticipantId.ToString().Length - 2), out parsedEnorllmentParticipantId);
                parsedEnorllmentParticipantId = parsedEnorllmentParticipantId * -1;

                if (enrollmentParticipantId.ToString().Length > 2)
                {
                    sequenceNumber = enrollmentParticipantId.ToString().Substring(enrollmentParticipantId.ToString().Length - 2, 2);
                }
                else
                {
                    sequenceNumber = string.Empty;
                }

            }
            else
            {
                parsedEnorllmentParticipantId = enrollmentParticipantId;
                sequenceNumber = string.Empty;
            }

            return parsedEnorllmentParticipantId;

        }

        //private List<MLDIAdditionalLtdViewModel> AdditionalLtdDatabuilder(EnrollmentParticipant enrollmentParticipant, PDRSoldClass pdrSoldClass, Case cmscase)
        //{
        //    Log.TraceFormat("+MLDEManger.AdditionalLtdDatabuilder");

        //    using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
        //    {
        //        var existingCoverage = unitOfWork.Repository<ExistingCoverage>().Linq().FirstOrDefault(c => c.Case.Id == cmscase.Id);

        //        ParticipantExistingPolicy participantExistingPolicy = new ParticipantExistingPolicy();
        //        decimal BenifitTotal = 0;
        //        int BerkshireIDICount = 0;
        //        bool ReplaceTest = false;
        //        int BIDCount = 0;
        //        var bridgelineAdditionalLTDCoverages = enrollmentParticipant.BridgelineAdditionalLTDCoverage.FirstOrDefault();
        //        var EnrollParty = enrollmentParticipant.Participant;

        //        List<MLDIAdditionalLtdViewModel> additionalLTDs = new List<MLDIAdditionalLtdViewModel>();

        //        if (EnrollParty.IDICarrier1 != null)
        //        {
        //            MLDIAdditionalLtdViewModel additionalLTD1 = new MLDIAdditionalLtdViewModel();
        //            additionalLTD1.CarrierName = EnrollParty.IDICarrier1.GetDescription();
        //            additionalLTD1.BenefitAmount = CheckNull(EnrollParty.IDIBenefitAmount1);
        //            additionalLTD1.ReplacementCoverage = EnrollParty.IDIToBeReplaced1;
        //            additionalLTD1.ReplacementAmount = CheckNull(EnrollParty.IDIToBeReplacedAmount1);
        //            additionalLTD1.PolicyNumber = EnrollParty.IDIPolicyNumber1;

        //            if (EnrollParty.PremiumPayerId1 == (int)PremiumPayerTypeEnum.Employer)
        //            {
        //                additionalLTD1.PremiumPayor = PayorTypeRestriction.Employer.GetDescription();
        //            }
        //            else
        //            {
        //                additionalLTD1.PremiumPayor = PayorTypeRestriction.Employee.GetDescription();
        //            }
        //            additionalLTDs.Add(additionalLTD1);
        //        }


        //        if (EnrollParty.IDICarrier2 != null)
        //        {
        //            MLDIAdditionalLtdViewModel additionalLTD2 = new MLDIAdditionalLtdViewModel();
        //            additionalLTD2.CarrierName = EnrollParty.IDICarrier2.GetDescription();
        //            additionalLTD2.BenefitAmount = CheckNull(EnrollParty.IDIBenefitAmount2);
        //            additionalLTD2.ReplacementCoverage = EnrollParty.IDIToBeReplaced2;
        //            additionalLTD2.ReplacementAmount = CheckNull(EnrollParty.IDIToBeReplacedAmount2);
        //            additionalLTD2.PolicyNumber = EnrollParty.IDIPolicyNumber2;

        //            if (EnrollParty.PremiumPayerId2 == (int)PremiumPayerTypeEnum.Employer)
        //            {
        //                additionalLTD2.PremiumPayor = PayorTypeRestriction.Employer.GetDescription();
        //            }
        //            else
        //            {
        //                additionalLTD2.PremiumPayor = PayorTypeRestriction.Employee.GetDescription();
        //            }
        //            additionalLTDs.Add(additionalLTD2);
        //        }

        //        if (EnrollParty.IDICarrier3 != null)
        //        {
        //            MLDIAdditionalLtdViewModel additionalLTD3 = new MLDIAdditionalLtdViewModel();
        //            additionalLTD3.CarrierName = EnrollParty.IDICarrier3.GetDescription();
        //            additionalLTD3.BenefitAmount = CheckNull(EnrollParty.IDIBenefitAmount3);
        //            additionalLTD3.ReplacementCoverage = EnrollParty.IDIToBeReplaced3;
        //            additionalLTD3.ReplacementAmount = CheckNull(EnrollParty.IDIToBeReplacedAmount3);
        //            additionalLTD3.PolicyNumber = EnrollParty.IDIPolicyNumber3;

        //            if (EnrollParty.PremiumPayerId3 == (int)PremiumPayerTypeEnum.Employer)
        //            {
        //                additionalLTD3.PremiumPayor = PayorTypeRestriction.Employer.GetDescription();
        //            }
        //            else
        //            {
        //                additionalLTD3.PremiumPayor = PayorTypeRestriction.Employee.GetDescription();
        //            }
        //            additionalLTDs.Add(additionalLTD3);
        //        }

        //        if (EnrollParty.IDICarrier4 != null)
        //        {
        //            MLDIAdditionalLtdViewModel additionalLTD4 = new MLDIAdditionalLtdViewModel();
        //            additionalLTD4.CarrierName = EnrollParty.IDICarrier4.GetDescription();
        //            additionalLTD4.BenefitAmount = CheckNull(EnrollParty.IDIBenefitAmount4);
        //            additionalLTD4.ReplacementCoverage = EnrollParty.IDIToBeReplaced4;
        //            additionalLTD4.ReplacementAmount = CheckNull(EnrollParty.IDIToBeReplacedAmount4);
        //            additionalLTD4.PolicyNumber = EnrollParty.IDIPolicyNumber4;

        //            if (EnrollParty.PremiumPayerId4 == (int)PremiumPayerTypeEnum.Employer)
        //            {
        //                additionalLTD4.PremiumPayor = PayorTypeRestriction.Employer.GetDescription();
        //            }
        //            else
        //            {
        //                additionalLTD4.PremiumPayor = PayorTypeRestriction.Employee.GetDescription();
        //            }
        //            additionalLTDs.Add(additionalLTD4);
        //        }

        //        MLDIAdditionalLtdViewModel additionalLTD = new MLDIAdditionalLtdViewModel();
        //        //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();

        //        var existingPolicyCaseNumber = string.Empty;
        //        bool isBerhskireGSIPresent = false;
        //        bool isGroupLTDCoveragePresent = false;

        //        //  Allare Gurdian/ Berki and not checked 
        //        if (EnrollParty.IDIToBeReplaced1 == false && EnrollParty.IDIToBeReplaced2 == false && EnrollParty.IDIToBeReplaced3 == false
        //            && EnrollParty.IDIToBeReplaced4 == false
        //            && (EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
        //            && (EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
        //            && (EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
        //            && (EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
        //            )
        //        {
        //            additionalLTD.CarrierName = "Berkshire IDI";
        //            additionalLTD.SalaryMonthlyBenefit = (decimal)(EnrollParty.IDIBenefitAmount1 + EnrollParty.IDIBenefitAmount2 + EnrollParty.IDIBenefitAmount3 + EnrollParty.IDIBenefitAmount4);
        //            additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();
        //            additionalLTDs.Add(additionalLTD);

        //            additionalLTD = new MLDIAdditionalLtdViewModel();
        //            //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();
        //            additionalLTD.CarrierName = "Berkshire Combined";
        //            additionalLTD.SalaryMonthlyBenefit = (decimal)(EnrollParty.IDIBenefitAmount1 + EnrollParty.IDIBenefitAmount2 + EnrollParty.IDIBenefitAmount3 + EnrollParty.IDIBenefitAmount4);
        //            additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();

        //            additionalLTDs.Add(additionalLTD);
        //        }
        //        else
        //        {
        //            if ((EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian) && (EnrollParty.IDIToBeReplaced1 == true))
        //            {
        //                ReplaceTest = true;
        //            }
        //            else if ((EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian) && (EnrollParty.IDIToBeReplaced2 == true))
        //            {
        //                ReplaceTest = true;
        //            }
        //            else if ((EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian) && (EnrollParty.IDIToBeReplaced3 == true))
        //            {
        //                ReplaceTest = true;
        //            }
        //            else if ((EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian) && (EnrollParty.IDIToBeReplaced4 == true))
        //            {
        //                ReplaceTest = true;
        //            }

        //            var participantExistingPolicies = EnrollParty.ParticipantExistingPolicies;
        //            if (participantExistingPolicies.Any())
        //            {
        //                participantExistingPolicy = EnrollParty.ParticipantExistingPolicies.FirstOrDefault();
        //            }


        //            //IDIBenefitAmount1>0

        //            var isBerkshireIDITagToBeShown = CheckForValueInFullyUnderwrittenIDI(participantExistingPolicy);
        //            if (EnrollParty.IDIBenefitAmount1 != null && EnrollParty.IDIBenefitAmount1 > 0)
        //            {
        //                additionalLTD = new MLDIAdditionalLtdViewModel();
        //                //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();
        //                if (EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
        //                {
        //                    if (isBerkshireIDITagToBeShown)
        //                    {
        //                        additionalLTD.CarrierName = "Berkshire IDI";
        //                        additionalLTD.SalaryMonthlyBenefit = participantExistingPolicy.FullyUnderwrittenIDI.Value;
        //                        BenifitTotal += additionalLTD.SalaryMonthlyBenefit;

        //                        if (EnrollParty.IDIToBeReplaced1 != false)
        //                        {
        //                            additionalLTD.IsInternalReplacement = true;
        //                            additionalLTD.AmountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount1);
        //                            additionalLTD.UserSelectedReplacement = true;
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    isBerkshireIDITagToBeShown = true;
        //                    additionalLTD.CarrierName = EnrollParty.IDICarrier1 != null ? EnrollParty.IDICarrier1.GetDescription() : "";
        //                    additionalLTD.SalaryMonthlyBenefit = CheckNull(EnrollParty.IDIBenefitAmount1);

        //                    if (EnrollParty.IDIToBeReplaced1 != false)
        //                    {
        //                        additionalLTD.IsExternalReplacement = true;
        //                        additionalLTD.AmountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount1);
        //                        additionalLTD.UserSelectedReplacement = true;
        //                        if (existingCoverage != null)
        //                        {
        //                            additionalLTD.HexclForm = existingCoverage.EmployerOwned == false ? true : false;
        //                        }
        //                    }
        //                }
        //                if (isBerkshireIDITagToBeShown)
        //                {
        //                    additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();
        //                    additionalLTD.CoverageStatus = CoverageStatusRestriction.InForce.GetDescription();
        //                    additionalLTD.IsTaxableIncome = false;
        //                    additionalLTD.SalaryOnlyCoverage = false;

        //                    if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.FL)
        //                    {
        //                        if (EnrollParty.IDIToBeReplaced1 != null && EnrollParty.IDIToBeReplaced1 == true)
        //                        {
        //                            additionalLTD.FlReplacePolicyNumber = EnrollParty.IDIPolicyNumber1 != null ? EnrollParty.IDIPolicyNumber1 : "";

        //                            if (existingCoverage != null)
        //                            {
        //                                var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 : "";
        //                                var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 : "";
        //                                var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity : "";
        //                                var statusType = "";
        //                                if (existingCoverage.FloridaReplacementCompanyStateType != null)
        //                                {
        //                                    statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription();
        //                                }

        //                                var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
        //                                additionalLTD.FlReplaceCarrierAddress = Address1.ToString() + "," + Address2.ToString() + "," + city.ToString() + "," + statusType.ToString() + "," + Zipcode.ToString();
        //                            }
        //                        }
        //                    }

        //                    if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
        //                    {
        //                        if (existingCoverage.ColoradoReplacementType != null)
        //                        {
        //                            additionalLTD.CoReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
        //                            if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
        //                            {
        //                                additionalLTD.CoReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
        //                            }
        //                        }
        //                    }


        //                    if (EnrollParty.PremiumPayerId1 != null)
        //                    {
        //                        if (EnrollParty.PremiumPayerId1 == (int)PremiumPayerTypeEnum.Employer)
        //                        {

        //                            additionalLTD.EmployerPaysPremiums = true;
        //                            //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employer.GetDescription();
        //                        }
        //                        else
        //                        {
        //                            additionalLTD.EmployerPaysPremiums = false;
        //                            //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employee.GetDescription();
        //                        }
        //                    }

        //                    if (additionalLTD.CarrierName != "Berkshire IDI")
        //                    {
        //                        additionalLTDs.Add(additionalLTD);
        //                    }
        //                    else if (ReplaceTest)
        //                    {
        //                        additionalLTDs.Add(additionalLTD);
        //                    }
        //                    if (additionalLTD.CarrierName == "Berkshire IDI" && ReplaceTest == false)
        //                    {
        //                        BIDCount = 1;
        //                    }
        //                }
        //            }
        //            //End IDIBenefitAmount1

        //            //IDIBenefitAmount2>0
        //            isBerkshireIDITagToBeShown = CheckForValueInFullyUnderwrittenIDI(participantExistingPolicy);
        //            if (EnrollParty.IDIBenefitAmount2 != null && EnrollParty.IDIBenefitAmount2 > 0)
        //            {
        //                additionalLTD = new MLDIAdditionalLtdViewModel();
        //                //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();

        //                if (EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
        //                {
        //                    if (isBerkshireIDITagToBeShown)
        //                    {
        //                        additionalLTD.CarrierName = "Berkshire IDI";
        //                        additionalLTD.SalaryMonthlyBenefit = participantExistingPolicy.FullyUnderwrittenIDI.Value;
        //                        BenifitTotal += additionalLTD.SalaryMonthlyBenefit;
        //                        if (EnrollParty.IDIToBeReplaced2 != false)
        //                        {
        //                            additionalLTD.IsInternalReplacement = true;
        //                            additionalLTD.AmountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount2);
        //                            additionalLTD.UserSelectedReplacement = true;
        //                        }
        //                        BerkshireIDICount += BerkshireIDICount++;
        //                    }
        //                }
        //                else
        //                {
        //                    isBerkshireIDITagToBeShown = true;
        //                    additionalLTD.CarrierName = EnrollParty.IDICarrier2 != null ? EnrollParty.IDICarrier2.GetDescription() : "";
        //                    additionalLTD.SalaryMonthlyBenefit = CheckNull(EnrollParty.IDIBenefitAmount2);
        //                    if (EnrollParty.IDIToBeReplaced2 != false)
        //                    {
        //                        additionalLTD.IsExternalReplacement = true;
        //                        additionalLTD.AmountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount2);
        //                        additionalLTD.UserSelectedReplacement = true;
        //                        if (existingCoverage != null)
        //                        {
        //                            additionalLTD.HexclForm = existingCoverage.EmployerOwned == false ? true : false;
        //                        }
        //                    }
        //                }

        //                if (isBerkshireIDITagToBeShown)
        //                {
        //                    additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();
        //                    additionalLTD.CoverageStatus = CoverageStatusRestriction.InForce.GetDescription();
        //                    additionalLTD.IsTaxableIncome = false;
        //                    additionalLTD.SalaryOnlyCoverage = false;

        //                    if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.FL)
        //                    {
        //                        if (EnrollParty.IDIToBeReplaced2 != null && EnrollParty.IDIToBeReplaced2 == true)
        //                        {
        //                            additionalLTD.FlReplacePolicyNumber = EnrollParty.IDIPolicyNumber2 != null ? EnrollParty.IDIPolicyNumber2 : "";

        //                            if (existingCoverage != null)
        //                            {
        //                                var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 : "";
        //                                var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 : "";
        //                                var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity : "";
        //                                var statusType = "";
        //                                if (existingCoverage.FloridaReplacementCompanyStateType != null)
        //                                {
        //                                    statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription();
        //                                }

        //                                var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
        //                                additionalLTD.FlReplaceCarrierAddress = Address1.ToString() + "," + Address2.ToString() + "," + city.ToString() + "," + statusType.ToString() + "," + Zipcode.ToString();
        //                            }
        //                        }
        //                    }

        //                    if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
        //                    {
        //                        if (existingCoverage.ColoradoReplacementType != null)
        //                        {
        //                            additionalLTD.CoReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
        //                            if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
        //                            {
        //                                additionalLTD.CoReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
        //                            }
        //                        }
        //                    }

        //                    if (EnrollParty.PremiumPayerId2 != null)
        //                    {
        //                        if (EnrollParty.PremiumPayerId2 == (int)PremiumPayerTypeEnum.Employer)
        //                        {

        //                            additionalLTD.EmployerPaysPremiums = true;
        //                            //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employer.GetDescription();
        //                        }
        //                        else
        //                        {
        //                            additionalLTD.EmployerPaysPremiums = false;
        //                            //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employee.GetDescription();
        //                        }
        //                    }

        //                    if (additionalLTD.CarrierName != "Berkshire IDI")
        //                    {
        //                        additionalLTDs.Add(additionalLTD);
        //                    }
        //                    else if (ReplaceTest)
        //                    {
        //                        additionalLTDs.Add(additionalLTD);
        //                    }
        //                    if (additionalLTD.CarrierName == "Berkshire IDI" && ReplaceTest == false)
        //                    {
        //                        BIDCount = 2;
        //                    }
        //                }

        //            }
        //            //End IDIBenefitAmount2

        //            //IDIBenefitAmount3
        //            isBerkshireIDITagToBeShown = CheckForValueInFullyUnderwrittenIDI(participantExistingPolicy);
        //            if (EnrollParty.IDIBenefitAmount3 != null && EnrollParty.IDIBenefitAmount3 > 0)
        //            {

        //                additionalLTD = new MLDIAdditionalLtdViewModel();
        //                //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();
        //                if (EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
        //                {
        //                    if (isBerkshireIDITagToBeShown)
        //                    {
        //                        additionalLTD.CarrierName = "Berkshire IDI";
        //                        additionalLTD.SalaryMonthlyBenefit = participantExistingPolicy.FullyUnderwrittenIDI != null ? participantExistingPolicy.FullyUnderwrittenIDI.Value : 0;
        //                        BenifitTotal += additionalLTD.SalaryMonthlyBenefit;
        //                        if (EnrollParty.IDIToBeReplaced3 != false)
        //                        {
        //                            additionalLTD.IsInternalReplacement = true;
        //                            additionalLTD.AmountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount3);
        //                            additionalLTD.UserSelectedReplacement = true;
        //                        }
        //                        BerkshireIDICount += BerkshireIDICount++;
        //                    }
        //                }
        //                else
        //                {
        //                    isBerkshireIDITagToBeShown = true;
        //                    additionalLTD.CarrierName = EnrollParty.IDICarrier3 != null ? EnrollParty.IDICarrier3.GetDescription() : "";
        //                    additionalLTD.SalaryMonthlyBenefit = CheckNull(EnrollParty.IDIBenefitAmount3);
        //                    if (EnrollParty.IDIToBeReplaced3 != false)
        //                    {
        //                        additionalLTD.IsExternalReplacement = true;
        //                        additionalLTD.AmountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount3);
        //                        additionalLTD.UserSelectedReplacement = true;
        //                        if (existingCoverage != null)
        //                        {
        //                            additionalLTD.HexclForm = existingCoverage.EmployerOwned == false ? true : false;
        //                        }
        //                    }
        //                }

        //                if (isBerkshireIDITagToBeShown)
        //                {
        //                    additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();
        //                    additionalLTD.CoverageStatus = CoverageStatusRestriction.InForce.GetDescription();
        //                    additionalLTD.IsTaxableIncome = false;
        //                    additionalLTD.SalaryOnlyCoverage = false;

        //                    if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.FL)
        //                    {
        //                        if (EnrollParty.IDIToBeReplaced3 != null && EnrollParty.IDIToBeReplaced3 == true)
        //                        {
        //                            additionalLTD.FlReplacePolicyNumber = EnrollParty.IDIPolicyNumber3 != null ? EnrollParty.IDIPolicyNumber3 : "";

        //                            if (existingCoverage != null)
        //                            {
        //                                var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 : "";
        //                                var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 : "";
        //                                var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity : "";
        //                                var statusType = "";
        //                                if (existingCoverage.FloridaReplacementCompanyStateType != null)
        //                                {
        //                                    statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription();
        //                                }

        //                                var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
        //                                additionalLTD.FlReplaceCarrierAddress = Address1.ToString() + "," + Address2.ToString() + "," + city.ToString() + "," + statusType.ToString() + "," + Zipcode.ToString();
        //                            }
        //                        }
        //                    }

        //                    if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
        //                    {
        //                        if (existingCoverage.ColoradoReplacementType != null)
        //                        {
        //                            additionalLTD.CoReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
        //                            if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
        //                            {
        //                                additionalLTD.CoReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
        //                            }
        //                        }
        //                    }

        //                    if (EnrollParty.PremiumPayerId3 != null)
        //                    {
        //                        if (EnrollParty.PremiumPayerId3 == (int)PremiumPayerTypeEnum.Employer)
        //                        {

        //                            additionalLTD.EmployerPaysPremiums = true;
        //                            //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employer.GetDescription();
        //                        }
        //                        else
        //                        {
        //                            additionalLTD.EmployerPaysPremiums = false;
        //                            //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employee.GetDescription();
        //                        }
        //                    }

        //                    if (additionalLTD.CarrierName != "Berkshire IDI")
        //                    {
        //                        additionalLTDs.Add(additionalLTD);
        //                    }
        //                    else if (ReplaceTest)
        //                    {
        //                        additionalLTDs.Add(additionalLTD);
        //                    }
        //                    if (additionalLTD.CarrierName == "Berkshire IDI" && ReplaceTest == false)
        //                    {
        //                        BIDCount = 3;
        //                    }
        //                }
        //            }
        //            //End IDIBenefitAmount3

        //            //IDIBenefitAmount4
        //            isBerkshireIDITagToBeShown = CheckForValueInFullyUnderwrittenIDI(participantExistingPolicy);
        //            if (EnrollParty.IDIBenefitAmount4 != null && EnrollParty.IDIBenefitAmount4 > 0)
        //            {

        //                additionalLTD = new MLDIAdditionalLtdViewModel();
        //                //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();
        //                //additionalLTD.PolicySummary.Riders = null;
        //                if (EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
        //                {
        //                    if (isBerkshireIDITagToBeShown)
        //                    {
        //                        additionalLTD.CarrierName = "Berkshire IDI";
        //                        additionalLTD.SalaryMonthlyBenefit = participantExistingPolicy.FullyUnderwrittenIDI != null ? participantExistingPolicy.FullyUnderwrittenIDI.Value : 0;
        //                        BenifitTotal += additionalLTD.SalaryMonthlyBenefit;
        //                        if (EnrollParty.IDIToBeReplaced4 != false)
        //                        {
        //                            additionalLTD.IsInternalReplacement = true;
        //                            additionalLTD.AmountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount4);
        //                            additionalLTD.UserSelectedReplacement = true;
        //                        }
        //                        BerkshireIDICount += BerkshireIDICount++;
        //                    }
        //                }
        //                else
        //                {
        //                    isBerkshireIDITagToBeShown = true;
        //                    additionalLTD.CarrierName = EnrollParty.IDICarrier4 != null ? EnrollParty.IDICarrier4.GetDescription() : "";
        //                    additionalLTD.SalaryMonthlyBenefit = CheckNull(EnrollParty.IDIBenefitAmount4);
        //                    if (EnrollParty.IDIToBeReplaced4 != false)
        //                    {
        //                        additionalLTD.IsExternalReplacement = true;
        //                        additionalLTD.AmountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount4);
        //                        additionalLTD.UserSelectedReplacement = true;
        //                        if (existingCoverage != null)
        //                        {
        //                            additionalLTD.HexclForm = existingCoverage.EmployerOwned == false ? true : false;
        //                        }
        //                    }
        //                }
        //                if (isBerkshireIDITagToBeShown)
        //                {
        //                    additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();
        //                    additionalLTD.CoverageStatus = CoverageStatusRestriction.InForce.GetDescription();
        //                    additionalLTD.IsTaxableIncome = false;
        //                    additionalLTD.SalaryOnlyCoverage = false;


        //                    if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.FL)
        //                    {
        //                        if (EnrollParty.IDIToBeReplaced4 != null && EnrollParty.IDIToBeReplaced4 == true)
        //                        {
        //                            additionalLTD.FlReplacePolicyNumber = EnrollParty.IDIPolicyNumber4 != null ? EnrollParty.IDIPolicyNumber4 : "";

        //                            if (existingCoverage != null)
        //                            {
        //                                var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 : "";
        //                                var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 : "";
        //                                var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity : "";
        //                                var statusType = "";
        //                                if (existingCoverage.FloridaReplacementCompanyStateType != null)
        //                                {
        //                                    statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription();
        //                                }

        //                                var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
        //                                additionalLTD.FlReplaceCarrierAddress = Address1.ToString() + "," + Address2.ToString() + "," + city.ToString() + "," + statusType.ToString() + "," + Zipcode.ToString();
        //                            }
        //                        }
        //                    }

        //                    if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
        //                    {
        //                        if (existingCoverage.ColoradoReplacementType != null)
        //                        {
        //                            additionalLTD.CoReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
        //                            if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
        //                            {
        //                                additionalLTD.CoReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
        //                            }
        //                        }
        //                    }

        //                    if (EnrollParty.PremiumPayerId4 != null)
        //                    {
        //                        if (EnrollParty.PremiumPayerId4 == (int)PremiumPayerTypeEnum.Employer)
        //                        {

        //                            additionalLTD.EmployerPaysPremiums = true;
        //                            //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employer.GetDescription();
        //                        }
        //                        else
        //                        {
        //                            additionalLTD.EmployerPaysPremiums = false;
        //                            //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employee.GetDescription();
        //                        }
        //                    }

        //                    if (additionalLTD.CarrierName != "Berkshire IDI")
        //                    {
        //                        additionalLTDs.Add(additionalLTD);
        //                    }
        //                    else if (ReplaceTest)
        //                    {
        //                        additionalLTDs.Add(additionalLTD);
        //                    }
        //                    if (additionalLTD.CarrierName == "Berkshire IDI" && ReplaceTest == false)
        //                    {
        //                        BIDCount = 4;
        //                    }
        //                }
        //            }
        //            //End IDIBenefitAmount4

        //            if (BIDCount > 0)
        //            {
        //                additionalLTD = new MLDIAdditionalLtdViewModel();
        //                //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();
        //                additionalLTD.CarrierName = "Berkshire IDI";
        //                additionalLTD.SalaryMonthlyBenefit = BenifitTotal;
        //                additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();

        //                additionalLTDs.Add(additionalLTD);
        //            }

        //            if (participantExistingPolicies.Any())
        //            {
        //                var ParticipantExistingoliciesdetail = unitOfWork.Repository<ParticipantExistingPolicyDetail>().Linq()
        //                    .FirstOrDefault(c => c.ParticipantExistingPolicy.Id == participantExistingPolicy.Id
        //                    && (c.CLOASPolicyStatus != null && c.CLOASPolicyStatus.ToLower() == "inforce")); //Later to see which policies we need to take - Anu

        //                var terminatedPoliciesList = participantExistingPolicies.SelectMany(p => p.ParticipantExistingPolicyDetails).ToList().Where(c => c.IsTerminateAndReplace).ToList();

        //                if (terminatedPoliciesList.Any())
        //                {
        //                    foreach (ParticipantExistingPolicyDetail terminatedPolicyDetail in terminatedPoliciesList)
        //                    {
        //                        var GSIIDIBaseAMBamount = participantExistingPolicy.GSIIDIBaseAMB ?? 0;

        //                        additionalLTD = new MLDIAdditionalLtdViewModel();
        //                        existingPolicyCaseNumber = ParticipantExistingoliciesdetail.CaseNumber != null ? ParticipantExistingoliciesdetail.CaseNumber.Trim() ?? string.Empty : string.Empty;
        //                        isBerhskireGSIPresent = true;
        //                        //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();
        //                        //additionalLTD.PolicySummary.Riders = null;

        //                        if (terminatedPolicyDetail.Product.ToUpper() == "HAS PROVIDER PLUS")
        //                        {
        //                            additionalLTD.CarrierName = "Berkshire IDI";
        //                        }
        //                        else
        //                        {
        //                            additionalLTD.CarrierName = "Berkshire GSI";
        //                        }
        //                        additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();
        //                        additionalLTD.CoverageStatus = CoverageStatusRestriction.InForce.GetDescription();


        //                        if (ParticipantExistingoliciesdetail.PremiumPayer != null)
        //                        {
        //                            if (ParticipantExistingoliciesdetail.PremiumPayer == PayorTypeRestriction.Employee.ToString())
        //                            {
        //                                //additionalLTD.employerPaysPremiums = false;
        //                                //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employee.GetDescription();
        //                            }
        //                            else if (ParticipantExistingoliciesdetail.PremiumPayer == PayorTypeRestriction.Employer.ToString())
        //                            {
        //                                //    additionalLTD.employerPaysPremiums = true;
        //                                //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employer.GetDescription();
        //                            }
        //                            if (EnrollParty.ListBillNumber != null)
        //                            {
        //                                if (EnrollParty.ListBillNumber.BillingMethodType != null)
        //                                {
        //                                    if (EnrollParty.ListBillNumber.BillingMethodType == BillingMethodTypeEnum.DirectBill)
        //                                    {
        //                                        //additionalLTD.PolicySummary.PaymentMethod = PaymentMethodRestriction.DirectBill.GetDescription();
        //                                    }
        //                                    else
        //                                    {
        //                                        //additionalLTD.PolicySummary.PaymentMethod = PaymentMethodRestriction.PayrollDeducted.GetDescription();
        //                                    }

        //                                }
        //                            }
        //                            //additionalLTD.PolicySummary.PremiumPaymentPeriod = !string.IsNullOrWhiteSpace(ParticipantExistingoliciesdetail.BillingModeTypeDescription)
        //                               // ? GetPolicySummaryPayPeriod(ParticipantExistingoliciesdetail.BillingModeTypeDescription).GetDescription() : string.Empty;

        //                            //additionalLTD.PolicySummary.PremiumPerPaycheck = additionalLTD.PolicySummary.PaymentMethod == PaymentMethodRestriction.PayrollDeducted.GetDescription()
        //                             //   ? CheckNull(ParticipantExistingoliciesdetail.ModalPremium) : 0.0M;

        //                            //if (additionalLTD.PolicySummary.PremiumPaymentPeriod != null)
        //                            //{
        //                            //    if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly.GetDescription())
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //    }
        //                            //    else
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerMonth = 0.0M;
        //                            //    }

        //                            //    if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly.GetDescription())
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //    }
        //                            //    else
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerQuarter = 0.0M;
        //                            //    }

        //                            //    if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual.GetDescription())
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //    }
        //                            //    else
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerSemiannual = 0.0M;
        //                            //    }
        //                            //}

        //                            //additionalLTD.PolicySummary.PremiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);

        //                            //if (additionalLTD.PolicySummary.PayorType == PayorTypeRestriction.Employee.GetDescription())
        //                            //{
        //                            //    if (additionalLTD.PolicySummary.PaymentMethod == PaymentMethodRestriction.PayrollDeducted.GetDescription())
        //                            //    {
        //                            //        additionalLTD.PolicySummary.EmployeePremiumPerPaycheck = CheckNullable(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //    }
        //                            //    else
        //                            //    {
        //                            //        additionalLTD.PolicySummary.EmployeePremiumPerPaycheck = 0.0M;
        //                            //    }

        //                            //    if (additionalLTD.PolicySummary.PremiumPaymentPeriod != null)
        //                            //    {
        //                            //        if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly.GetDescription())
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployeePremiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //        }
        //                            //        else
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployeePremiumPerMonth = 0.0M;
        //                            //        }

        //                            //        if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly.GetDescription())
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployeePremiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //        }
        //                            //        else
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployeePremiumPerQuarter = 0.0M;
        //                            //        }

        //                            //        if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual.GetDescription())
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployeePremiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //        }
        //                            //        else
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployeePremiumPerSemiannual = 0.0M;
        //                            //        }
        //                            //    }
        //                            //    additionalLTD.PolicySummary.EmployeePremiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);
        //                            //}
        //                        }

        //                        if (ParticipantExistingoliciesdetail != null && ParticipantExistingoliciesdetail.ParticipantExistingPolicyRiders != null)
        //                        {
        //                            var participantExistingPolicyRiders = ParticipantExistingoliciesdetail.ParticipantExistingPolicyRiders.
        //                                Where(c => c.RiderValueDescription != "Not Include" && c.RiderValueDescription != "Not Included").ToList();

        //                            if (participantExistingPolicyRiders != null)
        //                            {
        //                                //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();
        //                                foreach (var raid in participantExistingPolicyRiders)
        //                                {
        //                                    MLDIQualifiedRidersViewModel rider = new MLDIQualifiedRidersViewModel();
        //                                    rider.RiderIdentifier = raid != null ? raid.RiderName : string.Empty;
        //                                    rider.MonthlyBenefit = CheckNullable(raid.Amount);

        //                                    //additionalLTD.PolicySummary.Riders.Add(rider);
        //                                }
        //                            }
        //                        }
        //                        additionalLTD.IsInternalReplacement = true;
        //                        additionalLTD.IsExternalReplacement = false;

        //                        var monthlyIndemnity = terminatedPolicyDetail.MonthlyIndemnity != null ? terminatedPolicyDetail.MonthlyIndemnity.Value : 0.0m;
        //                        var ambAmount = terminatedPolicyDetail.AMBAmount != null ? terminatedPolicyDetail.AMBAmount.Value : 0.0m;
        //                        var totalMonthlyAmount = monthlyIndemnity + ambAmount;
        //                        additionalLTD.AmountOfReplacement = totalMonthlyAmount;
        //                        additionalLTD.SalaryMonthlyBenefit = totalMonthlyAmount;
        //                        BenifitTotal += totalMonthlyAmount;

        //                        additionalLTD.FlReplacePolicyNumber = terminatedPolicyDetail.PolicyNumber;

        //                        if (existingCoverage != null)
        //                        {
        //                            var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 + ", " : "";
        //                            var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 + ", " : "";
        //                            var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity + ", " : "";
        //                            var statusType = "";
        //                            if (existingCoverage.FloridaReplacementCompanyStateType != null)
        //                            {
        //                                statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription() + ", ";
        //                            }

        //                            var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
        //                            additionalLTD.FlReplaceCarrierAddress = Address1.ToString() + Address2.ToString() + city.ToString() + statusType.ToString() + Zipcode.ToString();
        //                        }
        //                        if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
        //                        {
        //                            if (existingCoverage.ColoradoReplacementType != null)
        //                            {
        //                                additionalLTD.CoReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
        //                                if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
        //                                {
        //                                    additionalLTD.CoReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
        //                                }
        //                            }
        //                        }
        //                        additionalLTD.HexclForm = false;

        //                        if (additionalLTD != null && !string.IsNullOrWhiteSpace(additionalLTD.CarrierName))
        //                        {
        //                            additionalLTDs.Add(additionalLTD);
        //                        }
        //                    }
        //                }

        //                if (ParticipantExistingoliciesdetail != null)
        //                {
        //                    var GSIIDIBaseAMBamount = participantExistingPolicy.GSIIDIBaseAMB ?? 0;
        //                    if (GSIIDIBaseAMBamount > 0)
        //                    {
        //                        additionalLTD = new MLDIAdditionalLtdViewModel();
        //                        existingPolicyCaseNumber = ParticipantExistingoliciesdetail.CaseNumber != null ? ParticipantExistingoliciesdetail.CaseNumber.Trim() ?? string.Empty : string.Empty;
        //                        isBerhskireGSIPresent = true;
        //                        //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();

        //                        bool hasAmbPolicy = EnrollParty.IsAMBIncreaseIndicator == true ? true : false;

        //                        if (hasAmbPolicy)
        //                        {
        //                            //additionalLTD.PolicySummary.IsCompactState = ParticipantExistingoliciesdetail.IsCompactState != null ? ParticipantExistingoliciesdetail.IsCompactState.Value : false;
        //                        }

        //                        if (ParticipantExistingoliciesdetail.Product?.ToUpper() == "HAS PROVIDER PLUS")
        //                        {
        //                            additionalLTD.CarrierName = "Berkshire IDI";
        //                        }
        //                        else
        //                        {
        //                            additionalLTD.CarrierName = "Berkshire GSI";
        //                        }

        //                        additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();
        //                        additionalLTD.CoverageStatus = CoverageStatusRestriction.InForce.GetDescription();

        //                        additionalLTD.SalaryMonthlyBenefit = GSIIDIBaseAMBamount;
        //                        BenifitTotal += additionalLTD.SalaryMonthlyBenefit;

        //                        additionalLTD.FlReplacePolicyNumber = ParticipantExistingoliciesdetail.PolicyNumber;

        //                        //if (ParticipantExistingoliciesdetail.PremiumPayer != null)
        //                        //{
        //                        //    if (ParticipantExistingoliciesdetail.PremiumPayer == PayorTypeRestriction.Employee.ToString())
        //                        //    {
        //                        //        //additionalLTD.employerPaysPremiums = false;
        //                        //        //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employee.GetDescription();
        //                        //    }
        //                        //    else if (ParticipantExistingoliciesdetail.PremiumPayer == PayorTypeRestriction.Employer.ToString())
        //                        //    {
        //                        //        //    additionalLTD.employerPaysPremiums = true;
        //                        //        //additionalLTD.PolicySummary.PayorType = PayorTypeRestriction.Employer.GetDescription();
        //                        //    }
        //                        //    if (EnrollParty.ListBillNumber != null)
        //                        //    {
        //                        //        if (EnrollParty.ListBillNumber.BillingMethodType != null)
        //                        //        {
        //                        //            if (EnrollParty.ListBillNumber.BillingMethodType == BillingMethodTypeEnum.DirectBill)
        //                        //            {
        //                        //                //additionalLTD.PolicySummary.PaymentMethod = PaymentMethodRestriction.DirectBill.GetDescription();
        //                        //            }
        //                        //            else
        //                        //            {
        //                        //                //additionalLTD.PolicySummary.PaymentMethod = PaymentMethodRestriction.PayrollDeducted.GetDescription();
        //                        //            }

        //                        //        }
        //                        //    }
        //                            //additionalLTD.PolicySummary.PremiumPaymentPeriod = !string.IsNullOrWhiteSpace(ParticipantExistingoliciesdetail.BillingModeTypeDescription)
        //                            //    ? GetPolicySummaryPayPeriod(ParticipantExistingoliciesdetail.BillingModeTypeDescription).GetDescription() : string.Empty;

        //                            //additionalLTD.PolicySummary.PremiumPerPaycheck = additionalLTD.PolicySummary.PaymentMethod == PaymentMethodRestriction.PayrollDeducted.GetDescription()
        //                            //    ? CheckNull(ParticipantExistingoliciesdetail.ModalPremium) : 0.0M;

        //                            //if (additionalLTD.PolicySummary.PremiumPaymentPeriod != null)
        //                            //{
        //                            //    if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly.GetDescription())
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //    }
        //                            //    else
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerMonth = 0.0M;
        //                            //    }

        //                            //    if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly.GetDescription())
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //    }
        //                            //    else
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerQuarter = 0.0M;
        //                            //    }

        //                            //    if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual.GetDescription())
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //    }
        //                            //    else
        //                            //    {
        //                            //        additionalLTD.PolicySummary.PremiumPerSemiannual = 0.0M;
        //                            //    }
        //                            //}

        //                            //additionalLTD.PolicySummary.PremiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);

        //                            /**/
        //                            var Premiumpayertype1 = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault();
        //                            MLDIQualifiedOfferViewModel MldiQualifiedOffer = new MLDIQualifiedOfferViewModel();

        //                            foreach (var EPOP in enrollmentParticipant.EnrollmentParticipantOptionPlans)
        //                            {
        //                                if (EPOP != null)
        //                                {
        //                                    MldiQualifiedOffer.CMSStandardOfferCode = EPOP.StandardOptionCodeNonSmoker != null ? EPOP.StandardOptionCodeNonSmoker : "";
        //                                    MldiQualifiedOffer.BaseReplacementPercentage = EPOP.IDIBaseReplacementCalculatedPercentage != null ? (int)(EPOP.IDIBaseReplacementCalculatedPercentage.Value * 100) : 0; 
        //                                }
        //                                MldiQualifiedOffer.Type = QualifiedOfferTypeRestriction.IDI.GetDescription();

        //                                string s11 = EPOP.StandardOptionCodeNonSmoker != null ? EPOP.StandardOptionCodeNonSmoker : "";
        //                                string s12 = "VGSI";
        //                                string s13 = "IDI Option 1";
        //                                bool b1 = s11.Contains(s12);
        //                                bool c1 = s11.Contains(s13);

        //                                if (b1 && c1)
        //                                {
        //                                    MldiQualifiedOffer.PayorType = PayorTypeRestriction.Employer.GetDescription();
        //                                }
        //                                else if (b1 == true && c1 != true)
        //                                {
        //                                    MldiQualifiedOffer.PayorType = PayorTypeRestriction.Employee.GetDescription();
        //                                }
        //                                else
        //                                {
        //                                    if (Premiumpayertype1 != null)
        //                                    {
        //                                        MldiQualifiedOffer.PayorType = GetPayortype(Premiumpayertype1).GetDescription();
        //                                    }

        //                                }

        //                            }
        //                            //if (MldiQualifiedOffer.PayorType == PayorTypeRestriction.Employer.GetDescription() ||
        //                            //    MldiQualifiedOffer.PayorType == PayorTypeRestriction.Shared.GetDescription())
        //                            //{
        //                            //    if (additionalLTD.PolicySummary.PaymentMethod == PaymentMethodRestriction.PayrollDeducted.GetDescription())
        //                            //    {
        //                            //        additionalLTD.PolicySummary.EmployerPremiumPerPaycheck = CheckNullable(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //    }
        //                            //    else
        //                            //    {
        //                            //        additionalLTD.PolicySummary.EmployerPremiumPerPaycheck = 0.0M;
        //                            //    }

        //                            //    if (additionalLTD.PolicySummary.PremiumPaymentPeriod != null)
        //                            //    {
        //                            //        if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly.GetDescription())
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployerPremiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //        }
        //                            //        else
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployerPremiumPerMonth = 0.0M;
        //                            //        }

        //                            //        if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly.GetDescription())
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployerPremiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //        }
        //                            //        else
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployerPremiumPerQuarter = 0.0M;
        //                            //        }

        //                            //        if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual.GetDescription())
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployerPremiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                            //        }
        //                            //        else
        //                            //        {
        //                            //            additionalLTD.PolicySummary.EmployerPremiumPerSemiannual = 0.0M;
        //                            //        }
        //                            //    }
        //                            //    additionalLTD.PolicySummary.EmployerPremiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);
        //                            //}

        //                        //    if (MldiQualifiedOffer.PayorType == PayorTypeRestriction.Employee.GetDescription() ||
        //                        //        MldiQualifiedOffer.PayorType == PayorTypeRestriction.Shared.GetDescription())
        //                        //    {
        //                        //        if (additionalLTD.PolicySummary.PaymentMethod == PaymentMethodRestriction.PayrollDeducted.GetDescription())
        //                        //        {
        //                        //            additionalLTD.PolicySummary.EmployeePremiumPerPaycheck = CheckNullable(ParticipantExistingoliciesdetail.ModalPremium);
        //                        //        }
        //                        //        else
        //                        //        {
        //                        //            additionalLTD.PolicySummary.EmployeePremiumPerPaycheck = 0.0M;
        //                        //        }

        //                        //        if (additionalLTD.PolicySummary.PremiumPaymentPeriod != null)
        //                        //        {
        //                        //            if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly.GetDescription())
        //                        //            {
        //                        //                additionalLTD.PolicySummary.EmployeePremiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                        //            }
        //                        //            else
        //                        //            {
        //                        //                additionalLTD.PolicySummary.EmployeePremiumPerMonth = 0.0M;
        //                        //            }

        //                        //            if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly.GetDescription())
        //                        //            {
        //                        //                additionalLTD.PolicySummary.EmployeePremiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                        //            }
        //                        //            else
        //                        //            {
        //                        //                additionalLTD.PolicySummary.EmployeePremiumPerQuarter = 0.0M;
        //                        //            }

        //                        //            if (additionalLTD.PolicySummary.PremiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual.GetDescription())
        //                        //            {
        //                        //                additionalLTD.PolicySummary.EmployeePremiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
        //                        //            }
        //                        //            else
        //                        //            {
        //                        //                additionalLTD.PolicySummary.EmployeePremiumPerSemiannual = 0.0M;
        //                        //            }
        //                        //        }
        //                        //        additionalLTD.PolicySummary.EmployeePremiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);
        //                        //    }

        //                        //}

        //                        //if (ParticipantExistingoliciesdetail != null && ParticipantExistingoliciesdetail.ParticipantExistingPolicyRiders != null)
        //                        //{
        //                        //    var participantExistingPolicyRiders = ParticipantExistingoliciesdetail.ParticipantExistingPolicyRiders.
        //                        //        Where(c => c.RiderValueDescription != "Not Include" && c.RiderValueDescription != "Not Included").ToList();

        //                        //    if (participantExistingPolicyRiders != null)
        //                        //    {
        //                        //        additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();
        //                        //        foreach (var raid in participantExistingPolicyRiders)
        //                        //        {
        //                        //            MLDIQualifiedRidersViewModel rider = new MLDIQualifiedRidersViewModel();
        //                        //            rider.RiderIdentifier = raid != null ? raid.RiderName : string.Empty;
        //                        //            rider.MonthlyBenefit = CheckNullable(raid.Amount);

        //                        //            additionalLTD.PolicySummary.Riders.Add(rider);
        //                        //        }
        //                        //    }
        //                        //}
        //                        if (additionalLTD != null && !string.IsNullOrWhiteSpace(additionalLTD.CarrierName) && additionalLTD.SalaryMonthlyBenefit > 0)
        //                        {
        //                            additionalLTDs.Add(additionalLTD);
        //                        }
        //                    }
        //                }
        //            }


        //            if (BenifitTotal > 0)
        //            {
        //                var berkshireIDILTD = additionalLTDs.Any() ? additionalLTDs.Where(c => c.CarrierName == "Berkshire IDI") : null;
        //                if (berkshireIDILTD.Any())
        //                {
        //                    additionalLTD = new MLDIAdditionalLtdViewModel();
        //                    //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();

        //                    additionalLTD.CarrierName = "Berkshire Combined";
        //                    additionalLTD.SalaryMonthlyBenefit = BenifitTotal;
        //                    additionalLTD.CoverageCategory = CoverageCategoryRestriction.Individual.GetDescription();

        //                    additionalLTDs.Add(additionalLTD);
        //                }
        //            }

        //        }

        //        //LTD GROUP Node Creation

        //        if (enrollmentParticipant.Participant.LTDCalculatedAmount > 0)

        //        {
        //            var soldPdrLtdCoverage = pdrSoldClass.PDRSoldClassLTDCoverage.FirstOrDefault();
        //            if (soldPdrLtdCoverage != null)
        //            {
        //                additionalLTD = new MLDIAdditionalLtdViewModel();
        //                //additionalLTD.PolicySummary.Riders = new List<MLDIQualifiedRidersViewModel>();

        //                isGroupLTDCoveragePresent = true;
        //                additionalLTD.CarrierName = soldPdrLtdCoverage.CarrierText != null ? soldPdrLtdCoverage.CarrierText : "";//enrollmentParticipant.Participant.IDICarrier1Description != null ? enrollmentParticipant.Participant.IDICarrier1Description : "";
        //                additionalLTD.CoverageCategory = CoverageCategoryRestriction.Group.GetDescription();
        //                additionalLTD.CoverageStatus = CoverageStatusRestriction.InForce.GetDescription();
        //                additionalLTD.SalaryMonthlyBenefit = CheckNull(enrollmentParticipant.Participant.LTDCalculatedAmount);
        //                //(decimal)enrollmentParticipant.Participant.LTDCalculatedAmount : 00.00m;


        //                additionalLTD.MaxMonthlyBenefit = soldPdrLtdCoverage.GroupLTDCapAmount;
        //                if (((ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum)soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id) == (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid))
        //                {
        //                    if (soldPdrLtdCoverage.TypeOfPayType != null && (TaxabilityTypeEnum)soldPdrLtdCoverage.TypeOfPayType == (TaxabilityTypeEnum.Taxable))
        //                    {
        //                        additionalLTD.IsTaxableIncome = true;
        //                    }
        //                }

        //                additionalLTD.SalaryOnlyCoverage = soldPdrLtdCoverage.GroupLTDCoveredEarningsType == CoveredEarningsTypeEnum.BaseSalaryOnly ? true : false;
        //                additionalLTD.GroupLtdPercentage = soldPdrLtdCoverage.GroupLTDReplacementPercentage;
        //                additionalLTD.EmployerPaysPremiums = soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid
        //                                                     || soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable ?
        //                    true : false;
        //                additionalLTD.IsInternalReplacement = null;
        //                additionalLTD.IsExternalReplacement = null;
        //                //additionalLTD
        //                //additionalLTD.PolicySummary.SharedPremiumEmployerPercentage = additionalLTD.PolicySummary.SharedPremiumEmployerPercentage == null ?
        //                //                                                                0 : additionalLTD.PolicySummary.SharedPremiumEmployerPercentage;

        //                additionalLTDs.Add(additionalLTD);
        //            }
        //        }

        //        if (additionalLTDs.Any() && additionalLTDs.Count == 2)
        //        {
        //            if (isBerhskireGSIPresent && isGroupLTDCoveragePresent && cmscase.CaseNumber != existingPolicyCaseNumber)
        //            {
        //                additionalLTDs.Reverse();
        //            }
        //        }
        //        else if (additionalLTDs.Any() && additionalLTDs.Count > 2)
        //        {
        //            additionalLTDs = additionalLTDs.OrderBy(i => i.CarrierName).ToList();
        //        }

        //        Log.TraceFormat("-MLDEManger.AdditionalLtdDatabuilder");

        //        return additionalLTDs;
        //    }
        //}

        private List<MLDIAdditionalLtdViewModel> CoverageDetailDataBuilder(EnrollmentParticipant enrollmentParticipant, PDRSoldClass pdrSoldClass, Case cmscase)
        {
            Log.TraceFormat("+MLDEManger.AdditionalLtdDatabuilder");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var existingCoverage = unitOfWork.Repository<ExistingCoverage>().Linq().FirstOrDefault(c => c.Case.Id == cmscase.Id);

                ParticipantExistingPolicy participantExistingPolicy = new ParticipantExistingPolicy();

                // var bridgelineAdditionalLTDCoverages = enrollmentParticipant.BridgelineAdditionalLTDCoverage.FirstOrDefault();
                var EnrollParty = enrollmentParticipant.Participant;

                List<MLDIAdditionalLtdViewModel> additionalLTDs = new List<MLDIAdditionalLtdViewModel>();

                // Let's start with added the Group LTD Coverage first.  Note: This is at PDR level.  No option to replace this coverage. 

                if (enrollmentParticipant.Participant.LTDCalculatedAmount > 0)

                {
                    var additionalLTD = new MLDIAdditionalLtdViewModel();

                    var soldPdrLtdCoverage = pdrSoldClass.PDRSoldClassLTDCoverage.FirstOrDefault();

                    if (soldPdrLtdCoverage != null)
                    {
                        additionalLTD = new MLDIAdditionalLtdViewModel();

                        additionalLTD.CarrierName = soldPdrLtdCoverage.CarrierText != null ? soldPdrLtdCoverage.CarrierText : "";
                        additionalLTD.CoverageCategory = CoverageCategoryRestriction.Group.GetDescription();
                        additionalLTD.CoverageStatus = CoverageStatusRestriction.InForce.GetDescription();
                        additionalLTD.SalaryMonthlyBenefit = Math.Round(Convert.ToDouble(CheckNull(enrollmentParticipant.Participant.LTDCalculatedAmount)), MidpointRounding.AwayFromZero);
                        additionalLTD.MaxMonthlyBenefit = soldPdrLtdCoverage.GroupLTDCapAmount;

                        if (((ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum)soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id) == (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid))
                        {
                            if (soldPdrLtdCoverage.TypeOfPayType != null && (TaxabilityTypeEnum)soldPdrLtdCoverage.TypeOfPayType == (TaxabilityTypeEnum.Taxable))
                            {
                                additionalLTD.IsTaxableIncome = true;
                            }
                        }

                        additionalLTD.SalaryOnlyCoverage = soldPdrLtdCoverage.GroupLTDCoveredEarningsType == CoveredEarningsTypeEnum.BaseSalaryOnly ? true : false;
                        additionalLTD.GroupLtdPercentage = soldPdrLtdCoverage.GroupLTDReplacementPercentage;
                        additionalLTD.EmployerPaysPremiums = soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid
                                                             || soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable ?
                            true : false;

                        additionalLTDs.Add(additionalLTD);
                    }
                }

                //Now let's get the Invidual coverages. 

                if (EnrollParty.IDICarrier1 != null)
                {
                    AddIDILTDCoverageCarrier(ref additionalLTDs, EnrollParty.IDICarrier1, EnrollParty.IDIBenefitAmount1, EnrollParty.IDIToBeReplaced1, EnrollParty.IDIToBeReplacedAmount1, EnrollParty.IDIPolicyNumber1, EnrollParty.PremiumPayerId1);
                }

                if (EnrollParty.IDICarrier2 != null)
                {
                    AddIDILTDCoverageCarrier(ref additionalLTDs, EnrollParty.IDICarrier2, EnrollParty.IDIBenefitAmount2, EnrollParty.IDIToBeReplaced2, EnrollParty.IDIToBeReplacedAmount2, EnrollParty.IDIPolicyNumber2, EnrollParty.PremiumPayerId2);
                }

                if (EnrollParty.IDICarrier3 != null)
                {
                    AddIDILTDCoverageCarrier(ref additionalLTDs, EnrollParty.IDICarrier3, EnrollParty.IDIBenefitAmount3, EnrollParty.IDIToBeReplaced3, EnrollParty.IDIToBeReplacedAmount3, EnrollParty.IDIPolicyNumber3, EnrollParty.PremiumPayerId3);
                }

                if (EnrollParty.IDICarrier4 != null)
                {
                    AddIDILTDCoverageCarrier(ref additionalLTDs, EnrollParty.IDICarrier4, EnrollParty.IDIBenefitAmount4, EnrollParty.IDIToBeReplaced4, EnrollParty.IDIToBeReplacedAmount4, EnrollParty.IDIPolicyNumber4, EnrollParty.PremiumPayerId4);
                }

                Log.TraceFormat("-MLDEManger.AdditionalLtdDatabuilder");

                return additionalLTDs;
            }
        }

        private void AddIDILTDCoverageCarrier(ref List<MLDIAdditionalLtdViewModel> additionalLTDs, IDICoverageCarrierTypeEnum? carrierName, decimal? benefitAmount,
            bool? replacementCoverage, decimal? replacementAmount, string policyNumber, int? premiumPayerId1)
        {
            MLDIAdditionalLtdViewModel additionalLTD = new MLDIAdditionalLtdViewModel();

            additionalLTD.CarrierName = carrierName.GetDescription();
            additionalLTD.BenefitAmount = CheckNull(benefitAmount);
            additionalLTD.ReplacementCoverage = replacementCoverage;
            additionalLTD.ReplacementAmount = CheckNull(replacementAmount);
            additionalLTD.PolicyNumber = policyNumber;

            if (premiumPayerId1 == (int)PremiumPayerTypeEnum.Employer)
            {
                additionalLTD.PremiumPayor = PayorTypeRestriction.Employer.GetDescription();
            }
            else
            {
                additionalLTD.PremiumPayor = PayorTypeRestriction.Employee.GetDescription();
            }
            bool hexclForm = replacementCoverage != null ? (bool)replacementCoverage : false;
            if (hexclForm)
            {
                additionalLTD.HexclForm = true;
            }
            else
            {
                additionalLTD.HexclForm = false;
            }
            additionalLTDs.Add(additionalLTD);
        }

        private List<MLDIQualifiedOfferViewModel> GetQualifiedOffers(EnrollmentParticipant enrolledParticipant, PDRSoldClass pdrSoldClas, Case cmsCase, List<MLDIAdditionalLtdViewModel> currentLTDs)
        {
            Log.TraceFormat("+MLDEManger.GetQualifiedOffers");
            var isCompactState = cmsCase.CaseUnderwritingRequests.FirstOrDefault().IsCompactState;

            var gsiLTDs = currentLTDs?.Where(i => i.CarrierName == "Berkshire GSI");
            bool isVgsiPlan = pdrSoldClas.PDRSoldClassPlan.Any(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

            List<MLDIQualifiedOfferViewModel> listMldiQualifiedOffers = new List<MLDIQualifiedOfferViewModel>();
            {

                foreach (var EPOP in enrolledParticipant.EnrollmentParticipantOptionPlans)
                {

                    int setcounti1 = 0; int setcountj1 = 0;
                    int setcounti2 = 0; int setcountj2 = 0;
                    int setcounti3 = 0; int setcountj3 = 0;
                    int setcounti4 = 0; int setcountj4 = 0;
                    int setcounti11 = 0; int setcountj11 = 0;
                    int setcounti12 = 0; int setcountj12 = 0;
                    int setcounti13 = 0; int setcountj13 = 0;
                    int setcounti14 = 0; int setcountj14 = 0;
                    int setcountsevrsmk = 0; int setcountsevrnon = 0;
                    int setcounti114 = 0; int setcountj114 = 0;
                    //int setcountcatB12 = 0; int setcountcatB22 = 0;
                    //int setcountcatE12 = 0; int setcountcatE22 = 0;

                    //-NOnSmokers QualifiedOffer

                    bool option1Eligible = EPOP.EnrollmentParticipant.Participant.EnrollmentOption1IsEligible != null ? (bool)EPOP.EnrollmentParticipant.Participant.EnrollmentOption1IsEligible : false;
                    bool option2Eligible = EPOP.EnrollmentParticipant.Participant.EnrollmentOption2IsEligible != null ? (bool)EPOP.EnrollmentParticipant.Participant.EnrollmentOption2IsEligible : false;
                    bool option3Eligible = EPOP.EnrollmentParticipant.Participant.EnrollmentOption3IsEligible != null ? (bool)EPOP.EnrollmentParticipant.Participant.EnrollmentOption3IsEligible : false;

                    if (!option1Eligible)
                    {
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 1"))
                        {
                            continue;
                        }
                    }
                    if (!option2Eligible)
                    {
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 2"))
                        {
                            continue;
                        }
                    }
                    if (!option3Eligible)
                    {
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 3"))
                        {
                            continue;
                        }
                    }

                    var Premiumpayertype1 = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault();



                    bool IsCostShare = Premiumpayertype1.PremiumPayerAndTaxabilityType != null ? (Premiumpayertype1.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare) : false;

                    MLDIQualifiedOfferViewModel MldiQualifiedOffer = new MLDIQualifiedOfferViewModel();
                    {

                        if (EPOP != null)
                        {
                            MldiQualifiedOffer.CMSStandardOfferCode = EPOP.StandardOptionCodeNonSmoker != null ? EPOP.StandardOptionCodeNonSmoker : "";
                            MldiQualifiedOffer.BaseReplacementPercentage = EPOP.IDIBaseReplacementCalculatedPercentage != null ? (int)(EPOP.IDIBaseReplacementCalculatedPercentage.Value * 100) : 0;
                        }
                        if (Premiumpayertype1 != null)
                        {
                            string PlanDesignType = Premiumpayertype1.PlanDesignType != null ? Premiumpayertype1.PlanDesignType.ToString() : null;

                            MldiQualifiedOffer.Type = PlanDesignType == "StandAloneRPPPlan" ? "RPPStandalone" : QualifiedOfferTypeRestriction.IDI.GetDescription();

                        }

                        string s11 = EPOP.StandardOptionCodeNonSmoker != null ? EPOP.StandardOptionCodeNonSmoker : "";
                        string s12 = "VGSI";
                        string s13 = "IDI Option 1";
                        bool b1 = s11.Contains(s12);
                        bool c1 = s11.Contains(s13);

                        if (b1 && c1)
                        {
                            MldiQualifiedOffer.PayorType = PayorTypeRestriction.Employer.GetDescription();
                        }
                        else if (b1 == true && c1 != true)
                        {
                            MldiQualifiedOffer.PayorType = PayorTypeRestriction.Employee.GetDescription();
                        }
                        else
                        {
                            if (Premiumpayertype1 != null)
                            {
                                MldiQualifiedOffer.PayorType = GetPayortype(Premiumpayertype1).GetDescription();
                            }

                        }



                        if (Premiumpayertype1 != null)
                        {
                            // MldiQualifiedOffer.payorType = GetPayortype(Premiumpayertype1);

                            if (enrolledParticipant.Participant.ListBillNumber != null && enrolledParticipant.Participant.ListBillNumber.BillingMethodType != null)
                            {
                                if (enrolledParticipant.Participant.ListBillNumber.BillingMethodType == BillingMethodTypeEnum.DirectBill)
                                {
                                    MldiQualifiedOffer.PaymentMethod = PaymentMethodRestriction.DirectBill.GetDescription();
                                }
                                else
                                {
                                    MldiQualifiedOffer.PaymentMethod = PaymentMethodRestriction.PayrollDeducted.GetDescription();
                                }
                            }

                            if ((MldiQualifiedOffer.PayorType == PayorTypeRestriction.Employer.GetDescription()) ||
                                (MldiQualifiedOffer.PayorType == PayorTypeRestriction.Employee.GetDescription()))
                            {
                                //   MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.PayrollDeducted;

                                if (enrolledParticipant.Participant.ListBillNumber != null)
                                {
                                    MldiQualifiedOffer.PremiumPaymentPeriod = GetPayPeriod(enrolledParticipant.Participant.ListBillNumber).GetDescription();
                                }
                            }
                            else
                            {
                                // MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.DirectBill;
                                if (enrolledParticipant.Participant.ListBillNumber != null)
                                {
                                    MldiQualifiedOffer.PremiumPaymentPeriod = GetPayPeriod(enrolledParticipant.Participant.ListBillNumber).GetDescription();
                                }
                                // cmsCase.ListBillNumbers.FirstOrDefault().BillingMethodType != null ? (PaymentMethodRestriction)cmsCase.ListBillNumbers.FirstOrDefault().BillingMethodType : PaymentMethodRestriction.PayrollDeducted;
                            }
                        }
                        MldiQualifiedOffer.PremiumPerPaycheck = CheckNull(EPOP.NonSmokerPremiumAmountPaycheck);

                        MldiQualifiedOffer.PremiumPerMonth = CheckNull(EPOP.NonSmokerPremiumAmountMonthly);

                        MldiQualifiedOffer.PremiumPerQuarter = CheckNull(EPOP.NonSmokerPremiumAmountQuarterly);

                        MldiQualifiedOffer.PremiumPerSemiannual = CheckNull(EPOP.NonSmokerPremiumAmountSemiannually);

                        MldiQualifiedOffer.PremiumPerAnnual = CheckNullable(EPOP.NonSmokerPremiumAmountAnnually);

                        MldiQualifiedOffer.TotalMonthlyBenefit = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.TotalMonthlyBenefitAmount) : 0;


                        MldiQualifiedOffer.PolicyFee = (enrolledParticipant.Participant.IsPushtoNewProviderChoicePolicyIndicator == true ||
                                enrolledParticipant.Participant.IsAMBIncreaseIndicator == true) ? "15.00" : "30.00";


                        if (MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.TotalMonthlyBenefit = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                    && ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ||
                                                                         enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.TotalMonthlyBenefitAmount) : 0;
                            MldiQualifiedOffer.PolicyFee = (enrolledParticipant.Participant.IsBuyUpPushtoNewProviderChoicePolicyIndicator == true ||
                                enrolledParticipant.Participant.IsBuyUpAMBIncreaseIndicator == true) ? "15.00" : "30.00";
                        }


                        switch (MldiQualifiedOffer.PayorType)
                        {
                            case "Shared":
                                MldiQualifiedOffer.EmployeePremiumPerPaycheck = CheckNullable(EPOP.NonSmokerEmployeePremiumAmountPaycheck);
                                MldiQualifiedOffer.EmployeePremiumPerMonth = CheckNullable(EPOP.NonSmokerEmployeePremiumPerMonth);
                                MldiQualifiedOffer.EmployeePremiumPerQuarter = CheckNullable(EPOP.NonSmokerEmployeePremiumQuarterly);
                                MldiQualifiedOffer.EmployeePremiumPerSemiannual = CheckNullable(EPOP.NonSmokerEmployeePremiumSemiannually);
                                MldiQualifiedOffer.EmployeePremiumPerAnnual = CheckNullable(EPOP.NonSmokerEmployeePremiumAnnually);

                                MldiQualifiedOffer.EmployerPremiumPerPaycheck = CheckNullable(EPOP.NonSmokerEmployerPremiumAmountPaycheck);
                                MldiQualifiedOffer.EmployerPremiumPerMonth = CheckNullable(EPOP.NonSmokerEmployerPremiumPerMonth);
                                MldiQualifiedOffer.EmployerPremiumPerQuarter = CheckNullable(EPOP.NonSmokerEmployerPremiumQuarterly);
                                MldiQualifiedOffer.EmployerPremiumPerSemiAnnual = CheckNullable(EPOP.NonSmokerEmployerPremiumSemiannually);
                                MldiQualifiedOffer.EmployerPremiumPerAnnual = CheckNullable(EPOP.NonSmokerEmployerPremiumAnnually);
                                break;
                            case "Employer":
                                MldiQualifiedOffer.EmployeePremiumPerPaycheck = 0;
                                MldiQualifiedOffer.EmployeePremiumPerMonth = 0;
                                MldiQualifiedOffer.EmployeePremiumPerQuarter = 0;
                                MldiQualifiedOffer.EmployeePremiumPerSemiannual = 0;
                                MldiQualifiedOffer.EmployeePremiumPerAnnual = 0;

                                MldiQualifiedOffer.EmployerPremiumPerPaycheck = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerMonth = CheckNullable(EPOP.NonSmokerEmployerPremiumPerMonth);
                                MldiQualifiedOffer.EmployerPremiumPerQuarter = CheckNullable(EPOP.NonSmokerEmployerPremiumQuarterly);
                                MldiQualifiedOffer.EmployerPremiumPerSemiAnnual = CheckNullable(EPOP.NonSmokerEmployerPremiumSemiannually);
                                MldiQualifiedOffer.EmployerPremiumPerAnnual = CheckNullable(EPOP.NonSmokerEmployerPremiumAnnually);
                                break;
                            default:
                                MldiQualifiedOffer.EmployeePremiumPerPaycheck = CheckNullable(EPOP.NonSmokerPremiumAmountPaycheck);
                                MldiQualifiedOffer.EmployeePremiumPerMonth = CheckNullable(EPOP.NonSmokerPremiumAmountMonthly);
                                MldiQualifiedOffer.EmployeePremiumPerQuarter = CheckNullable(EPOP.NonSmokerPremiumAmountQuarterly);
                                MldiQualifiedOffer.EmployeePremiumPerSemiannual = CheckNullable(EPOP.NonSmokerPremiumAmountSemiannually);
                                MldiQualifiedOffer.EmployeePremiumPerAnnual = CheckNullable(EPOP.NonSmokerPremiumAmountAnnually);

                                MldiQualifiedOffer.EmployerPremiumPerPaycheck = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerMonth = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerQuarter = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerSemiAnnual = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerAnnual = 0M;
                                break;
                        }

                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 1") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 1"))
                        {
                            MldiQualifiedOffer.OrderPosition = 1;
                        }
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 2") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 2"))
                        {
                            MldiQualifiedOffer.OrderPosition = 3;
                        }
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 3") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.OrderPosition = 5;
                        }

                        MldiQualifiedOffer.IsProViderChoice = true;

                        if (EPOP.BenefitPeriod != null)
                        {
                            if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                            {

                                MldiQualifiedOffer.BenefitPeriodAge = 65;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                            {
                                MldiQualifiedOffer.BenefitPeriodAge = 67;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                            {
                                MldiQualifiedOffer.BenefitPeriodAge = 70;
                            }

                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                            {
                                MldiQualifiedOffer.BenefitPeriodYears = 2;

                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                            {
                                MldiQualifiedOffer.BenefitPeriodYears = 5;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                            {
                                MldiQualifiedOffer.BenefitPeriodYears = 10;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                            {
                                MldiQualifiedOffer.BenefitPeriodYears = 1;
                            }

                        }

                        if (EPOP.EliminationPeriod != null)
                        {
                            if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                            {
                                MldiQualifiedOffer.EliminationPeriodDays = 180;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                            {
                                MldiQualifiedOffer.EliminationPeriodDays = 360;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                            {
                                MldiQualifiedOffer.EliminationPeriodDays = 720;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                            {
                                MldiQualifiedOffer.EliminationPeriodDays = 90;
                            }

                        }
                        var EMPPP = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault();
                        if (EMPPP != null)
                        {
                            MldiQualifiedOffer.SharedPremiumEmployerPercentage = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault().EmployerPaidPremium != null ? pdrSoldClas.PDRSoldClassPlan.FirstOrDefault().EmployerPaidPremium : 0M;
                        }
                        MldiQualifiedOffer.IsTobaccoRates = false;
                        MldiQualifiedOffer.DiscountPercentage = EPOP.Discount ?? 0;
                        MldiQualifiedOffer.BaseMonthlyBenefit = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.BenefitAmountBaseMonthly) : 0;
                        MldiQualifiedOffer.BaseMonthlyPremium = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.NonSmokerPremiumAmountBaseMonthly) : 0;
                        MldiQualifiedOffer.IsProViderChoice = true;
                        MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.ParticipantCategoryCodeType) : 0;
                        MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? enrolledParticipant.Participant.ParticipantCategoryCodeType.GetDescription() : string.Empty;
                        // NON-smoker Rider

                        if (MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null ? enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType.GetDescription() : string.Empty;

                            if (MldiQualifiedOffer.OptionClassType == string.Empty)
                            {
                                MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? enrolledParticipant.Participant.ParticipantCategoryCodeType.GetDescription() : string.Empty;
                            }

                            MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType) : 0;

                            if (MldiQualifiedOffer.OptionClassTypeOrder == 0)
                            {
                                MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.ParticipantCategoryCodeType) : 0;
                            }

                            MldiQualifiedOffer.BaseMonthlyBenefit = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                   && (enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB || enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.BenefitAmountBaseMonthly) : 0;
                            MldiQualifiedOffer.BaseMonthlyPremium = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                   && (enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB || enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.NonSmokerPremiumAmountBaseMonthly) : 0;
                        }

                        MldiQualifiedOffer.Riders = new List<MLDIQualifiedRidersViewModel>();

                        MLDIQualifiedRidersViewModel MldiQualifiedRider = null;
                        PreExistingConditionLimitTypeEnum peclt;
                        MentalSubstanceLimitationEnum MentalSubstance;


                        MldiQualifiedRider = new MLDIQualifiedRidersViewModel();

                        peclt = EPOP.PreExistingConditionLimitType;
                        MentalSubstance = EPOP.MentalSubstanceLimitationType;
                        if (peclt == PreExistingConditionLimitTypeEnum.None)
                        {
                            if (setcounti1 < 1)
                            {

                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "NOPREX";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcounti1++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._3_12)
                        {
                            if (setcounti2 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "PREX-3";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcounti2++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._6_12)
                        {
                            if (setcounti3 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "PREX-6";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcounti3++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._12_12)
                        {
                            if (setcounti4 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "PREX-12";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcounti4++;
                            }
                        }

                        if (MentalSubstance == MentalSubstanceLimitationEnum._6Month)
                        {
                            if (setcounti11 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ExtMental-6";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcounti11++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._24Month
                            || MentalSubstance == MentalSubstanceLimitationEnum._24MonthsGSI)
                        {
                            if (setcounti12 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ExtMental-24";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcounti12++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._Nolimitation)
                        {
                            if (setcounti13 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ExtMental";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcounti13++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._12Month)
                        {
                            if (setcounti14 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ExtMental-12";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcounti14++;
                            }

                        }

                        var pexconltDisablity = EPOP.DefinitionOfDisabilityType;
                        if (setcounti114 < 1)
                        {

                            if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "EnhancedMedSpec";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "TOOSR";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TrueOwnOccupation ||
                                     pexconltDisablity == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "TOOR";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation ||
                                pexconltDisablity == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupationME)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "EOOR";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "TOOR-2YRMod";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "MOOR-2YrMod";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            setcounti114++;
                        }

                        foreach (var EPOPR in EPOP.Riders)
                        {
                            if (EPOPR.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)
                            {
                                CreateAMBRiders(EPOPR, enrolledParticipant, pdrSoldClas, MldiQualifiedOffer, false, EPOP, isVgsiPlan);
                            }

                            if (isCompactState == false)
                            {

                                if (EPOPR.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                {


                                    if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                    {
                                        MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                        MldiQualifiedRider.RiderIdentifier = "CAT16b";
                                        MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                        MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                        if (EPOP.BenefitPeriod != null)
                                        {

                                            if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                            {

                                                MldiQualifiedRider.BenefitPeriodAge = 65;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                            {
                                                MldiQualifiedRider.BenefitPeriodAge = 67;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                            {
                                                MldiQualifiedRider.BenefitPeriodAge = 70;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 2;

                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 5;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 10;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                            {
                                                MldiQualifiedOffer.BenefitPeriodYears = 1;
                                            }
                                        }

                                        if (EPOP.EliminationPeriod != null)
                                        {

                                            if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 180;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 360;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 720;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 90;
                                            }
                                        }
                                        MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                    }
                                }

                            }
                            else
                            {
                                if (setcountsevrnon < 1)
                                {
                                    if (isCompactState == true)
                                    {
                                        if (EPOPR.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                        {

                                            MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                            MldiQualifiedRider.RiderIdentifier = "SevereDisability";
                                            MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                            MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                            MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                            if (EPOP.BenefitPeriod != null)
                                            {

                                                if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                                {

                                                    MldiQualifiedRider.BenefitPeriodAge = 65;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodAge = 67;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodAge = 70;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodYears = 2;

                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodYears = 5;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodYears = 10;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                                {
                                                    MldiQualifiedOffer.BenefitPeriodYears = 1;
                                                }

                                            }

                                            if (EPOP.EliminationPeriod != null)
                                            {

                                                if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                                {
                                                    MldiQualifiedRider.EliminationPeriod = 180;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                                {
                                                    MldiQualifiedRider.EliminationPeriod = 360;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                                {
                                                    MldiQualifiedRider.EliminationPeriod = 720;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                                {
                                                    MldiQualifiedRider.EliminationPeriod = 90;
                                                }
                                            }
                                            MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                            setcountsevrnon++;
                                        }

                                    }
                                }

                            }
                            //Cat16B end

                            if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                    MldiQualifiedRider.RiderIdentifier = "CAT16e";
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);

                                    if (EPOP.BenefitPeriod != null)
                                    {
                                        if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                        {
                                            MldiQualifiedRider.BenefitPeriodAge = 65;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                        {
                                            MldiQualifiedRider.BenefitPeriodAge = 67;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                        {
                                            MldiQualifiedRider.BenefitPeriodAge = 70;
                                        }

                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 2;

                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 5;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 10;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                        {
                                            MldiQualifiedOffer.BenefitPeriodYears = 1;
                                        }

                                    }

                                    if (EPOP.EliminationPeriod != null)
                                    {

                                        if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 180;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 360;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 720;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 90;
                                        }

                                    }
                                    MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitAmountMonthly != null && EPOPR.BenefitAmountMonthly > 0)
                            {

                                if (EPOPR.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit)
                                {
                                    if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                    {
                                        MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                        MldiQualifiedRider.RiderIdentifier = "RPP";
                                        MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                        MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                        MldiQualifiedRider.BenefitPeriodAge = 65;

                                        if (EPOPR.EliminationPeriodType != null)
                                        {
                                            if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 180;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 360;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 720;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 90;
                                            }
                                        }
                                        MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                    }
                                }
                                else if (EPOPR.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                    MldiQualifiedRider.RiderIdentifier = "RPP";
                                    if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                    {
                                        MldiQualifiedRider.MonthlyPremium = 0;
                                        MldiQualifiedRider.AnnualPremium = 0;
                                    }
                                    else
                                    {
                                        MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                    }
                                    MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                }
                            }
                            if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedResidualDisability)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "EnhancedRes";
                                MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }

                            else if (EPOPR.BenefitType == BenefitTypeEnum.BasicResidualDisability)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "BasicRes";
                                MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ShortTermRes";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "COLA-6";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving3PercentCompound)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "COLA-3";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving4YearDelayed)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "COLA-4Yr";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }


                            if (EPOPR.BenefitType == BenefitTypeEnum.UnemploymentPremiumWaiver)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "UnempWaiver";
                                MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                    MldiQualifiedRider.RiderIdentifier = "SIS";
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                    MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                }
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.LumpSumIndemnityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "LSDB";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.BasicPartialDisabilityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "BasicPart";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "EnhancedPart";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }


                            if (EPOPR.BenefitType == BenefitTypeEnum.StudentLoanProtection)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                    MldiQualifiedRider.RiderIdentifier = "SLP";
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);

                                    //if (gsiLTDs.Count() > 0)
                                    //{
                                    //    var slpRiderBenefitAmt = gsiLTDs?.FirstOrDefault()?.PolicySummary?.Riders?.FirstOrDefault(i => i.RiderIdentifier.Contains("SLP"))?.MonthlyBenefit;
                                    //    MldiQualifiedRider.MonthlyBenefit = CheckNullable(slpRiderBenefitAmt);
                                    //}
                                    //else
                                    //{
                                    MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                    //}

                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                    //MldiQualifiedRider.benefitPeriodAge = EPOPR.BenefitPeriodType != null ? (uint)(BenefitPeriodTypeEnum)EPOPR.BenefitPeriodType.Value : 0;
                                    if (EPOPR.BenefitPeriodType != null)
                                    {
                                        if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                                        {

                                            MldiQualifiedRider.BenefitPeriodAge = 65;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                                        {
                                            MldiQualifiedRider.BenefitPeriodAge = 67;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                                        {
                                            MldiQualifiedRider.BenefitPeriodAge = 70;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 2;

                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 5;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 10;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 15;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                        {
                                            MldiQualifiedOffer.BenefitPeriodYears = 1;
                                        }

                                    }
                                    //MldiQualifiedRider.eliminationPeriod = EPOPR.EliminationPeriodType != null ? (uint)(EliminationPeriodTypeEnum)EPOPR.EliminationPeriodType : 00;
                                    if (EPOPR.EliminationPeriodType != null)
                                    {

                                        if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 180;
                                        }
                                        else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 360;
                                        }
                                        else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 720;
                                        }
                                        else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 90;
                                        }

                                    }

                                    MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.SupplementalBenefitTermRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "SBT";
                                MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);

                                //if (gsiLTDs.Count() > 0)
                                //{
                                //    var sbtRiderBenefitAmt = gsiLTDs?.FirstOrDefault()?.PolicySummary?.Riders?.FirstOrDefault(i => i.RiderIdentifier.Contains("SBT"))?.MonthlyBenefit;
                                //    MldiQualifiedRider.MonthlyBenefit = CheckNullable(sbtRiderBenefitAmt);
                                //}
                                //else
                                //{
                                MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                //}

                                MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                // MldiQualifiedRider.benefitPeriodAge = EPOPR.BenefitPeriodType != null ? (uint)(BenefitPeriodTypeEnum)EPOPR.BenefitPeriodType.Value : 0;
                                if (EPOPR.BenefitPeriodType != null)
                                {
                                    if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                                    {

                                        MldiQualifiedRider.BenefitPeriodAge = 65;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                                    {
                                        MldiQualifiedRider.BenefitPeriodAge = 67;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                                    {
                                        MldiQualifiedRider.BenefitPeriodAge = 70;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                    {
                                        MldiQualifiedRider.BenefitPeriodYears = 2;

                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                    {
                                        MldiQualifiedRider.BenefitPeriodYears = 5;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                                    {
                                        MldiQualifiedRider.BenefitPeriodYears = 10;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                                    {
                                        MldiQualifiedRider.BenefitPeriodYears = 15;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                    {
                                        MldiQualifiedOffer.BenefitPeriodYears = 1;
                                    }

                                }
                                //MldiQualifiedRider.eliminationPeriod = EPOPR.EliminationPeriodType != null ? (uint)(EliminationPeriodTypeEnum)EPOPR.EliminationPeriodType : 00;
                                if (EPOPR.EliminationPeriodType != null)
                                {

                                    if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                    {
                                        MldiQualifiedRider.EliminationPeriod = 180;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                    {
                                        MldiQualifiedRider.EliminationPeriod = 360;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                    {
                                        MldiQualifiedRider.EliminationPeriod = 720;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                    {
                                        MldiQualifiedRider.EliminationPeriod = 90;
                                    }

                                }


                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                        }
                    }


                    //-Smokers QualifiedOffer



                    listMldiQualifiedOffers.Add(MldiQualifiedOffer);

                    MldiQualifiedOffer = new MLDIQualifiedOfferViewModel();
                    {

                        MldiQualifiedOffer.CMSStandardOfferCode = EPOP.StandardOptionCodeSmoker != null ? EPOP.StandardOptionCodeSmoker : "";
                        MldiQualifiedOffer.BaseReplacementPercentage = EPOP.IDIBaseReplacementCalculatedPercentage != null ? (int)(EPOP.IDIBaseReplacementCalculatedPercentage.Value * 100) : 0;
                        //MldiQualifiedOffer.Type = QualifiedOfferTypeRestriction.IDI.GetDescription();
                        var Premiumpayertype = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault();
                        if (Premiumpayertype != null)
                        {
                            string PlanDesignType = Premiumpayertype.PlanDesignType != null ? Premiumpayertype.PlanDesignType.ToString() : null;

                            MldiQualifiedOffer.Type = PlanDesignType == "StandAloneRPPPlan" ? "RPPStandalone" : QualifiedOfferTypeRestriction.IDI.GetDescription();

                        }
                        string s1 = EPOP.StandardOptionCodeSmoker != null ? EPOP.StandardOptionCodeSmoker : "";
                        string s2 = "VGSI";
                        string s3 = "IDI Option 1";
                        bool b = s1.Contains(s2);
                        bool c = s1.Contains(s3);

                        if (b && c)
                        {
                            MldiQualifiedOffer.PayorType = PayorTypeRestriction.Employer.GetDescription();
                        }
                        else if (b == true && c != true)
                        {
                            MldiQualifiedOffer.PayorType = PayorTypeRestriction.Employee.GetDescription();
                        }
                        else
                        {
                            if (Premiumpayertype1 != null)
                            {
                                MldiQualifiedOffer.PayorType = GetPayortype(Premiumpayertype1).GetDescription();
                            }

                        }

                        if (Premiumpayertype != null)
                        {
                            // MldiQualifiedOffer.payorType = GetPayortype(Premiumpayertype1);

                            if ((MldiQualifiedOffer.PayorType == PayorTypeRestriction.Employer.GetDescription()) ||
                                (MldiQualifiedOffer.PayorType == PayorTypeRestriction.Employee.GetDescription()))
                            {
                                // MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.PayrollDeducted;
                                if (enrolledParticipant.Participant.ListBillNumber != null)
                                {
                                    MldiQualifiedOffer.PremiumPaymentPeriod = GetPayPeriod(enrolledParticipant.Participant.ListBillNumber).GetDescription();

                                }

                            }
                            else
                            {
                                // MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.DirectBill;
                                if (enrolledParticipant.Participant.ListBillNumber != null)
                                {
                                    MldiQualifiedOffer.PremiumPaymentPeriod = GetPayPeriod(enrolledParticipant.Participant.ListBillNumber).GetDescription();
                                }
                            }

                            if (enrolledParticipant.Participant.ListBillNumber != null && enrolledParticipant.Participant.ListBillNumber.BillingMethodType != null)
                            {
                                if (enrolledParticipant.Participant.ListBillNumber.BillingMethodType == BillingMethodTypeEnum.DirectBill)
                                {
                                    MldiQualifiedOffer.PaymentMethod = PaymentMethodRestriction.DirectBill.GetDescription();
                                }
                                else
                                {
                                    MldiQualifiedOffer.PaymentMethod = PaymentMethodRestriction.PayrollDeducted.GetDescription();
                                }
                            }
                        }

                        MldiQualifiedOffer.PremiumPerPaycheck = CheckNull(EPOP.SmokerPremiumAmountPaycheck);
                        MldiQualifiedOffer.PremiumPerMonth = CheckNull(EPOP.SmokerPremiumAmountMonthly);
                        MldiQualifiedOffer.PremiumPerQuarter = CheckNullable(EPOP.SmokerPremiumAmountQuarterly);
                        MldiQualifiedOffer.PremiumPerSemiannual = CheckNullable(EPOP.SmokerPremiumAmountSemiannually);
                        MldiQualifiedOffer.PremiumPerAnnual = CheckNullable(EPOP.SmokerPremiumAmountAnnually);
                        MldiQualifiedOffer.TotalMonthlyBenefit = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.TotalMonthlyBenefitAmount) : 0;

                        MldiQualifiedOffer.PolicyFee = (enrolledParticipant.Participant.IsPushtoNewProviderChoicePolicyIndicator == true ||
                            enrolledParticipant.Participant.IsAMBIncreaseIndicator == true) ? "15.00" : "30.00";


                        if (MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.TotalMonthlyBenefit = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                    && ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ||
                                                                         enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.TotalMonthlyBenefitAmount) : 0;


                            MldiQualifiedOffer.PolicyFee = (enrolledParticipant.Participant.IsBuyUpPushtoNewProviderChoicePolicyIndicator == true ||
                                enrolledParticipant.Participant.IsBuyUpAMBIncreaseIndicator == true) ? "15.00" : "30.00";
                        }

                        switch (MldiQualifiedOffer.PayorType)
                        {
                            case "Shared":
                                MldiQualifiedOffer.EmployeePremiumPerPaycheck = CheckNullable(EPOP.SmokerEmployeePremiumAmountPaycheck);
                                MldiQualifiedOffer.EmployeePremiumPerMonth = CheckNull(EPOP.SmokerEmployeePremiumPerMonth);
                                MldiQualifiedOffer.EmployeePremiumPerQuarter = CheckNull(EPOP.SmokerEmployeePremiumQuarterly);
                                MldiQualifiedOffer.EmployeePremiumPerSemiannual = CheckNull(EPOP.SmokerEmployeePremiumSemiannually);
                                MldiQualifiedOffer.EmployeePremiumPerAnnual = CheckNull(EPOP.SmokerEmployeePremiumAnnually);

                                MldiQualifiedOffer.EmployerPremiumPerPaycheck = CheckNullable(EPOP.SmokerEmployerPremiumAmountPaycheck);
                                MldiQualifiedOffer.EmployerPremiumPerMonth = CheckNullable(EPOP.SmokerEmployerPremiumPerMonth);
                                MldiQualifiedOffer.EmployerPremiumPerQuarter = CheckNullable(EPOP.SmokerEmployerPremiumQuarterly);
                                MldiQualifiedOffer.EmployerPremiumPerSemiAnnual = CheckNullable(EPOP.SmokerEmployerPremiumSemiannually);
                                MldiQualifiedOffer.EmployerPremiumPerAnnual = CheckNullable(EPOP.SmokerEmployerPremiumAnnually);
                                break;
                            case "Employer":
                                MldiQualifiedOffer.EmployeePremiumPerPaycheck = 0;
                                MldiQualifiedOffer.EmployeePremiumPerMonth = 0;
                                MldiQualifiedOffer.EmployeePremiumPerQuarter = 0;
                                MldiQualifiedOffer.EmployeePremiumPerSemiannual = 0;
                                MldiQualifiedOffer.EmployeePremiumPerAnnual = 0;

                                MldiQualifiedOffer.EmployerPremiumPerPaycheck = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerMonth = CheckNullable(EPOP.SmokerEmployerPremiumPerMonth);
                                MldiQualifiedOffer.EmployerPremiumPerQuarter = CheckNullable(EPOP.SmokerEmployerPremiumQuarterly);
                                MldiQualifiedOffer.EmployerPremiumPerSemiAnnual = CheckNullable(EPOP.SmokerEmployerPremiumSemiannually);
                                MldiQualifiedOffer.EmployerPremiumPerAnnual = CheckNullable(EPOP.SmokerEmployerPremiumAnnually);
                                break;
                            default:
                                MldiQualifiedOffer.EmployeePremiumPerPaycheck = CheckNull(EPOP.SmokerPremiumAmountPaycheck);
                                MldiQualifiedOffer.EmployeePremiumPerMonth = CheckNull(EPOP.SmokerPremiumAmountMonthly);
                                MldiQualifiedOffer.EmployeePremiumPerQuarter = CheckNull(EPOP.SmokerPremiumAmountQuarterly);
                                MldiQualifiedOffer.EmployeePremiumPerSemiannual = CheckNull(EPOP.SmokerPremiumAmountSemiannually);
                                MldiQualifiedOffer.EmployeePremiumPerAnnual = CheckNull(EPOP.SmokerPremiumAmountAnnually);

                                MldiQualifiedOffer.EmployerPremiumPerPaycheck = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerMonth = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerQuarter = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerSemiAnnual = 0M;
                                MldiQualifiedOffer.EmployerPremiumPerAnnual = 0M;
                                break;
                        }



                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 1") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 1"))
                        {
                            MldiQualifiedOffer.OrderPosition = 2;
                        }
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 2") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 2"))
                        {
                            MldiQualifiedOffer.OrderPosition = 4;
                        }
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 3") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.OrderPosition = 6;
                        }


                        MldiQualifiedOffer.IsProViderChoice = true;


                        if (EPOP.BenefitPeriod != null)
                        {
                            if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                            {

                                MldiQualifiedOffer.BenefitPeriodAge = 65;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                            {
                                MldiQualifiedOffer.BenefitPeriodAge = 67;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                            {
                                MldiQualifiedOffer.BenefitPeriodAge = 70;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                            {
                                MldiQualifiedOffer.BenefitPeriodYears = 2;

                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                            {
                                MldiQualifiedOffer.BenefitPeriodYears = 5;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                            {
                                MldiQualifiedOffer.BenefitPeriodYears = 10;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                            {
                                MldiQualifiedOffer.BenefitPeriodYears = 1;
                            }

                        }

                        if (EPOP.EliminationPeriod != null)
                        {

                            if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                            {
                                MldiQualifiedOffer.EliminationPeriodDays = 180;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                            {
                                MldiQualifiedOffer.EliminationPeriodDays = 360;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                            {
                                MldiQualifiedOffer.EliminationPeriodDays = 720;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                            {
                                MldiQualifiedOffer.EliminationPeriodDays = 90;
                            }

                        }
                        MldiQualifiedOffer.SharedPremiumEmployerPercentage = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault().EmployerPaidPremium != null ? pdrSoldClas.PDRSoldClassPlan.FirstOrDefault().EmployerPaidPremium : 0M;

                        MldiQualifiedOffer.IsTobaccoRates = true;
                        MldiQualifiedOffer.DiscountPercentage = CheckNullable(EPOP.Discount);
                        MldiQualifiedOffer.BaseMonthlyBenefit = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.BenefitAmountBaseMonthly) : 0;
                        MldiQualifiedOffer.BaseMonthlyPremium = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.SmokerPremiumAmountBaseMonthly) : 0;
                        MldiQualifiedOffer.IsProViderChoice = true;
                        MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? enrolledParticipant.Participant.ParticipantCategoryCodeType.GetDescription() : string.Empty;
                        MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.ParticipantCategoryCodeType) : 0;

                        if (MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null ? enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType.GetDescription() : string.Empty;

                            if (MldiQualifiedOffer.OptionClassType == string.Empty)
                            {
                                MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? enrolledParticipant.Participant.ParticipantCategoryCodeType.GetDescription() : string.Empty;
                            }

                            MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType) : 0;

                            if (MldiQualifiedOffer.OptionClassTypeOrder == 0)
                            {
                                MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.ParticipantCategoryCodeType) : 0;
                            }

                            MldiQualifiedOffer.BaseMonthlyBenefit = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                   && (enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB || enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.BenefitAmountBaseMonthly) : 0;


                            MldiQualifiedOffer.BaseMonthlyPremium = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                   && (enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB || enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.SmokerPremiumAmountBaseMonthly) : 0;
                        }
                        MldiQualifiedOffer.Riders = new List<MLDIQualifiedRidersViewModel>();
                        MLDIQualifiedRidersViewModel MldiQualifiedRider = null;
                        PreExistingConditionLimitTypeEnum peclt;
                        MentalSubstanceLimitationEnum MentalSubstance;
                        MldiQualifiedRider = new MLDIQualifiedRidersViewModel();

                        peclt = EPOP.PreExistingConditionLimitType;
                        MentalSubstance = EPOP.MentalSubstanceLimitationType;

                        if (peclt == PreExistingConditionLimitTypeEnum.None)
                        {
                            if (setcountj1 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "NOPREX";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcountj1++;
                            }
                        }

                        else if (peclt == PreExistingConditionLimitTypeEnum._3_12)
                        {
                            if (setcountj2 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "PREX-3";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcountj2++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._6_12)
                        {
                            if (setcountj3 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "PREX-6";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcountj3++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._12_12)
                        {
                            if (setcountj4 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "PREX-12";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcountj4++;
                            }
                        }



                        if (MentalSubstance == MentalSubstanceLimitationEnum._6Month)
                        {
                            if (setcountj11 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ExtMental-6";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcountj11++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._24Month
                             || MentalSubstance == MentalSubstanceLimitationEnum._24MonthsGSI)
                        {
                            if (setcountj12 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ExtMental-24";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcountj12++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._Nolimitation)
                        {
                            if (setcountj13 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ExtMental";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcountj13++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._12Month)
                        {
                            if (setcountj14 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ExtMental-12";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                setcountj14++;
                            }
                        }

                        var pexconltDisablity = EPOP.DefinitionOfDisabilityType;

                        if (setcountj114 < 1)
                        {

                            if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "EnhancedMedSpec";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "TOOSR";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TrueOwnOccupation ||
                                     pexconltDisablity == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "TOOR";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation ||
                                pexconltDisablity == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupationME)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "EOOR";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "TOOR-2YRMod";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "MOOR-2YrMod";
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            setcountj114++;
                        }

                        foreach (var EPOPR in EPOP.Riders)
                        {
                            if (EPOPR.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)
                            {
                                if (MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.CMSStandardOfferCode.Contains("Option 3"))
                                {
                                    CreateAMBRiders(EPOPR, enrolledParticipant, pdrSoldClas, MldiQualifiedOffer, true, EPOP, isVgsiPlan);
                                }

                            }

                            if (isCompactState == false)
                            {

                                if (EPOPR.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                {
                                    if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                    {
                                        MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                        MldiQualifiedRider.RiderIdentifier = "CAT16b";
                                        MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);// != null ? EPOPR.SmokerPremiumAmountMonthly : 00.00m;
                                        MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);// != null ? EPOPR.BenefitAmountMonthly : 00.00m;
                                        MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual); // != null ? EPOPR.SmokerPremiumAmountAnnual : 00.00m;
                                        if (EPOP.BenefitPeriod != null)
                                        {
                                            if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                            {
                                                MldiQualifiedRider.BenefitPeriodAge = 65;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                            {
                                                MldiQualifiedRider.BenefitPeriodAge = 67;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                            {
                                                MldiQualifiedRider.BenefitPeriodAge = 70;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 2;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 5;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 10;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                            {
                                                MldiQualifiedOffer.BenefitPeriodYears = 1;
                                            }
                                        }

                                        if (EPOP.EliminationPeriod != null)
                                        {
                                            if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 180;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 360;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 720;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 90;
                                            }
                                        }
                                        MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                    }
                                }

                            }
                            else
                            {

                                if (setcountsevrsmk < 1)
                                {
                                    if (isCompactState == true)
                                    {
                                        if (EPOPR.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                        {
                                            MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                            MldiQualifiedRider.RiderIdentifier = "SevereDisability";
                                            MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                            MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                            MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                            MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                            if (EPOP.BenefitPeriod != null)
                                            {

                                                if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                                {

                                                    MldiQualifiedRider.BenefitPeriodAge = 65;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodAge = 67;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodAge = 70;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodYears = 2;

                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodYears = 5;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                                {
                                                    MldiQualifiedRider.BenefitPeriodYears = 10;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                                {
                                                    MldiQualifiedOffer.BenefitPeriodYears = 1;
                                                }
                                            }

                                            if (EPOP.EliminationPeriod != null)
                                            {

                                                if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                                {
                                                    MldiQualifiedRider.EliminationPeriod = 180;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                                {
                                                    MldiQualifiedRider.EliminationPeriod = 360;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                                {
                                                    MldiQualifiedRider.EliminationPeriod = 720;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                                {
                                                    MldiQualifiedRider.EliminationPeriod = 90;
                                                }
                                            }
                                            MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                            setcountsevrsmk++;
                                        }

                                    }
                                }
                            }//Cat16B end



                            if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                    MldiQualifiedRider.RiderIdentifier = "CAT16e";
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                    if (EPOP.BenefitPeriod != null)
                                    {
                                        if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                        {
                                            MldiQualifiedRider.BenefitPeriodAge = 65;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                        {
                                            MldiQualifiedRider.BenefitPeriodAge = 67;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                        {
                                            MldiQualifiedRider.BenefitPeriodAge = 70;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 2;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 5;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                        {
                                            MldiQualifiedRider.BenefitPeriodYears = 10;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                        {
                                            MldiQualifiedOffer.BenefitPeriodYears = 1;
                                        }
                                    }

                                    if (EPOP.EliminationPeriod != null)
                                    {
                                        if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 180;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 360;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 720;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                        {
                                            MldiQualifiedRider.EliminationPeriod = 90;
                                        }
                                    }
                                    MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitAmountMonthly != null && EPOPR.BenefitAmountMonthly > 0)
                            {

                                if (EPOPR.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit)
                                {
                                    if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                    {
                                        MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                        MldiQualifiedRider.RiderIdentifier = "RPP";
                                        MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                        MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                        MldiQualifiedRider.BenefitPeriodAge = 65;

                                        if (EPOPR.EliminationPeriodType != null)
                                        {
                                            if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 180;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 360;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 720;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 90;
                                            }
                                        }
                                        MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                    }
                                }
                                else if (EPOPR.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                    MldiQualifiedRider.RiderIdentifier = "RPP";
                                    if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                    {
                                        MldiQualifiedRider.MonthlyPremium = 0;
                                        MldiQualifiedRider.AnnualPremium = 0;
                                    }
                                    else
                                    {
                                        MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                    }
                                    MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedResidualDisability)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "EnhancedRes";
                                MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }

                            else if (EPOPR.BenefitType == BenefitTypeEnum.BasicResidualDisability)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "BasicRes";
                                MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "ShortTermRes";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }



                            if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "COLA-6";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving3PercentCompound)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "COLA-3";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving4YearDelayed)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "COLA-4Yr";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.UnemploymentPremiumWaiver)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "UnempWaiver";
                                MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                    MldiQualifiedRider.RiderIdentifier = "SIS";
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                    MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                }
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.LumpSumIndemnityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "LSDB";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.BasicPartialDisabilityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "BasicPart";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "EnhancedPart";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.MonthlyPremium = 0;
                                    MldiQualifiedRider.AnnualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }



                            if (EPOPR.BenefitType == BenefitTypeEnum.StudentLoanProtection)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                    {
                                        MldiQualifiedRider.RiderIdentifier = "SLP";
                                        MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                        MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                        // MldiQualifiedRider.benefitPeriodAge = EPOPR.BenefitPeriodType != null ? (uint)(BenefitPeriodTypeEnum)EPOPR.BenefitPeriodType.Value : 0;
                                        if (EPOPR.BenefitPeriodType != null)
                                        {
                                            if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                                            {

                                                MldiQualifiedRider.BenefitPeriodAge = 65;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                                            {
                                                MldiQualifiedRider.BenefitPeriodAge = 67;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                                            {
                                                MldiQualifiedRider.BenefitPeriodAge = 70;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 2;

                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 5;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 10;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                                            {
                                                MldiQualifiedRider.BenefitPeriodYears = 15;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                            {
                                                MldiQualifiedOffer.BenefitPeriodYears = 1;
                                            }
                                        }
                                        //MldiQualifiedRider.eliminationPeriod = EPOPR.EliminationPeriodType != null ? (uint)(EliminationPeriodTypeEnum)EPOPR.EliminationPeriodType : 00;
                                        if (EPOPR.EliminationPeriodType != null)
                                        {

                                            if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 180;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 360;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 720;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.EliminationPeriod = 90;
                                            }
                                        }
                                    }
                                    MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.SupplementalBenefitTermRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRidersViewModel();
                                MldiQualifiedRider.RiderIdentifier = "SBT";
                                MldiQualifiedRider.MonthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                MldiQualifiedRider.MonthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                MldiQualifiedRider.AnnualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                //MldiQualifiedRider.benefitPeriodAge = EPOPR.BenefitPeriodType != null ? (uint)(BenefitPeriodTypeEnum)EPOPR.BenefitPeriodType.Value : 0;
                                if (EPOPR.BenefitPeriodType != null)
                                {
                                    if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                                    {
                                        MldiQualifiedRider.BenefitPeriodAge = 65;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                                    {
                                        MldiQualifiedRider.BenefitPeriodAge = 67;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                                    {
                                        MldiQualifiedRider.BenefitPeriodAge = 70;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                    {
                                        MldiQualifiedRider.BenefitPeriodYears = 2;

                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                    {
                                        MldiQualifiedRider.BenefitPeriodYears = 5;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                                    {
                                        MldiQualifiedRider.BenefitPeriodYears = 10;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                                    {
                                        MldiQualifiedRider.BenefitPeriodYears = 15;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                    {
                                        MldiQualifiedOffer.BenefitPeriodYears = 1;
                                    }

                                }
                                //MldiQualifiedRider.eliminationPeriod = EPOPR.EliminationPeriodType != null ? (uint)(EliminationPeriodTypeEnum)EPOPR.EliminationPeriodType : 00;
                                if (EPOPR.EliminationPeriodType != null)
                                {

                                    if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                    {
                                        MldiQualifiedRider.EliminationPeriod = 180;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                    {
                                        MldiQualifiedRider.EliminationPeriod = 360;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                    {
                                        MldiQualifiedRider.EliminationPeriod = 720;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                    {
                                        MldiQualifiedRider.EliminationPeriod = 90;
                                    }

                                }

                                MldiQualifiedOffer.Riders.Add(MldiQualifiedRider);
                            }

                        }
                    }

                    listMldiQualifiedOffers.Add(MldiQualifiedOffer);
                }//foreach
                if (listMldiQualifiedOffers.Any())
                {
                    listMldiQualifiedOffers = listMldiQualifiedOffers.OrderBy(c => c.OrderPosition).ToList();
                }

            }

            Log.TraceFormat("-MLDEManger.GetQualifiedOffers");

            return listMldiQualifiedOffers;
        }
        private EnrollmentParticipantMLDEDto BuildMockParticipant(int enrollmentParticipantId, int? mockEnrollmentParticipantId, string sequenceNumber)
        {
            Log.TraceFormat("+MLDEManger.BuildMockParticipant");

            EnrollmentParticipantMLDEDto mockEnrollmentParticipantVM = new EnrollmentParticipantMLDEDto();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {                
                var mockEnrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                                            .Where(i => i.Id == enrollmentParticipantId).FirstOrDefault();

                if (mockEnrollmentParticipant == null) throw new ValidationException("{\"ErrorCode\":\"NotFound\", \"ErrorMessage\":\"No record found for current Participant\"}");

                var mockEnrollmentParticipantOptionPlan = unitOfWork.Repository<EnrollmentParticipantOptionPlan>().Linq()
                                                            .Where(i => i.EnrollmentParticipant.Id == mockEnrollmentParticipant.Id).FirstOrDefault();
                var mockParticipant = unitOfWork.Repository<Participant>().Linq().Where(i => i.Id == mockEnrollmentParticipant.Participant.Id).FirstOrDefault();

                mockEnrollmentParticipantVM.EnrollmentParticipantId = mockEnrollmentParticipantId.Value;
                mockEnrollmentParticipantVM.CaseNumber = mockEnrollmentParticipant.Enrollment.Case.CaseNumber;
                mockEnrollmentParticipantVM.Gender = mockParticipant.Gender;
                if (mockParticipant.Gender.ToUpper().Trim() == "MALE" || mockParticipant.Gender.ToUpper().Trim() == "M")
                {
                    mockEnrollmentParticipantVM.FirstName = "John";
                }
                else if (mockParticipant.Gender.ToUpper().Trim() == "FEMALE" || mockParticipant.Gender.ToUpper().Trim() == "F")
                {
                    mockEnrollmentParticipantVM.FirstName = "Jane";
                }
                else
                {
                    mockEnrollmentParticipantVM.FirstName = "Chris";
                }

                mockEnrollmentParticipantVM.MiddleName = mockParticipant.MiddleInitial;
                mockEnrollmentParticipantVM.LastName = "Smith";
                mockEnrollmentParticipantVM.Suffix = mockParticipant.Suffix;

                var Domain = mockParticipant.WorkEmail != null ? mockParticipant.WorkEmail : string.Empty;
                string domain = Domain.Split('@').ElementAtOrDefault(1);
                //mockEnrollmentParticipantVM.WorkEmail = "user" + emailAddressCount++ + "@" + domain;
                mockEnrollmentParticipantVM.WorkEmail = $"user{Convert.ToInt32(sequenceNumber)}.{enrollmentParticipantId}{sequenceNumber}@{domain}";
                mockEnrollmentParticipantVM.DateOfBirth = mockParticipant.DateOfBirth;
                mockEnrollmentParticipantVM.Occupation = mockParticipant.JobTitle;

                mockEnrollmentParticipantVM.HomeStreet1 = "530 Main St";
                mockEnrollmentParticipantVM.HomeStreet2 = string.Empty;
                mockEnrollmentParticipantVM.HomeCity = "Parktown";
                mockEnrollmentParticipantVM.HomeStateDescription = "MA";
                mockEnrollmentParticipantVM.HomeZipCode = mockParticipant.HomeZipCode;
                mockEnrollmentParticipantVM.PhoneNumber = "555-555-1212";

                mockEnrollmentParticipantVM.WorkStreet1 = "299 Lynn Lane";
                mockEnrollmentParticipantVM.WorkStreet2 = string.Empty;
                mockEnrollmentParticipantVM.WorkCity = "Wardsboro";
                mockEnrollmentParticipantVM.WorkStateDescription = "MA";
                mockEnrollmentParticipantVM.WorkZipCode = mockParticipant.WorkZipCode;
                mockEnrollmentParticipantVM.ContractState = mockParticipant.ContractStateDescription;
                mockEnrollmentParticipantVM.IDIInsurableIncome = mockParticipant.IDIInsurableIncomeCalculatedAmount;
                mockEnrollmentParticipantVM.Salary = mockParticipant.MostRecentSalaryAmount;
                mockEnrollmentParticipantVM.BonusIncome = mockParticipant.MostRecentPaidBonusAmount;
                mockEnrollmentParticipantVM.CommissionIncome = mockParticipant.MostRecentPaidCommissionAmount;
                mockEnrollmentParticipantVM.OtherIncome = mockParticipant.OtherIncomeAmount;
                mockEnrollmentParticipantVM.RetirementContribution = mockParticipant.TotalEmployerOrEmployeeRetirementContributionAmount;
                mockEnrollmentParticipantVM.GLTDBenefitCaclulatedAmount = Math.Round(Convert.ToDouble(mockParticipant.GLTDBenefitCalculatedAmount), MidpointRounding.AwayFromZero);
                mockEnrollmentParticipantVM.GLTDReplaceCalculatedPercentage = mockParticipant.GLTDReplacementCalculatedPercentage * 100;
                mockEnrollmentParticipantVM.PremiumAmount = mockEnrollmentParticipantOptionPlan?.NonSmokerPremiumAmountMonthly ?? 0;
                mockEnrollmentParticipantVM.BenefitAmount = mockEnrollmentParticipantOptionPlan?.BenefitAmountBaseMonthly ?? 0;
                mockEnrollmentParticipantVM.IDIBaseReplace = mockEnrollmentParticipantOptionPlan?.IDIBaseReplacementCalculatedPercentage * 100;
                mockEnrollmentParticipantVM.GSIBaseReplace = mockEnrollmentParticipantOptionPlan?.GSIPercentage * 100;                
                mockEnrollmentParticipantVM.IsMockParticipant = true;
                mockEnrollmentParticipantVM.ParticipantCategoryCodeType = GetParticipantCategoryCodeType(mockEnrollmentParticipant.Participant?.ParticipantCategoryCodeType);
                mockEnrollmentParticipantVM.BuyUpParticipantCategoryCodeType = GetParticipantCategoryCodeType(mockEnrollmentParticipant.Participant?.BuyUpParticipantCategoryCodeType);
                mockEnrollmentParticipantVM.ExistingMonthlyPremiumAmount = GetExistingMonthlyPremiumAmount(mockEnrollmentParticipant, mockEnrollmentParticipant.Participant.Census.Case, "Employer");
                mockEnrollmentParticipantVM.ExistingMonthlyBuyUpPlanPremiumAmount = GetExistingMonthlyBuyUpPlanPremiumAmount(mockEnrollmentParticipant, mockEnrollmentParticipant.Participant.Census.Case, "Employee");
                mockEnrollmentParticipantVM.ExistingMonthlyBasePlanBenefitAmount = GetExistingMonthlyBenefitAmount(mockEnrollmentParticipant, mockEnrollmentParticipant.Participant.Census.Case, "Employer");
                mockEnrollmentParticipantVM.ExistingMonthlyBuyUpPlanBenefitAmount = GetExistingMonthlyBuyUpPlanBenefitAmount(mockEnrollmentParticipant, mockEnrollmentParticipant.Participant.Census.Case, "Employee");

            }

            Log.TraceFormat("-MLDEManger.BuildMockParticipant");

            return mockEnrollmentParticipantVM;

        }
        private void CreateAMBRiders(EnrollmentParticipantOptionPlanRider epopr, EnrollmentParticipant enrolledParticipant,
                                   PDRSoldClass pdrSoldClass, MLDIQualifiedOfferViewModel offer, bool isSmoker, EnrollmentParticipantOptionPlan epop, bool isVgsiPlanType)
        {
            ParticipantCategoryCodeTypeEnum? participantCategoryCodeType = new ParticipantCategoryCodeTypeEnum();

            bool isOffer1 = false;

            if (offer.CMSStandardOfferCode.Contains("Option 2") || offer.CMSStandardOfferCode.Contains("Option 3"))
            {
                isOffer1 = false;
                if (isVgsiPlanType)
                {
                    participantCategoryCodeType = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType;
                }
                else
                {
                    participantCategoryCodeType = enrolledParticipant.Participant.ParticipantCategoryCodeType;
                }
            }
            else
            {
                isOffer1 = true;
                participantCategoryCodeType = enrolledParticipant.Participant.ParticipantCategoryCodeType;
            }

            if (participantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB)
            {
                var ambRider = new MLDIQualifiedRidersViewModel();
                ambRider.RiderIdentifier = "AMBR";

                var basePlan = pdrSoldClass.PDRSoldClassPlan.Where(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).FirstOrDefault();
                var vgsiPlan = pdrSoldClass.PDRSoldClassPlan.Where(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp).FirstOrDefault();

                var enrollmentBaseParticipantOptionPlan = enrolledParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                var enrollmentVgsiParticipantOptionPlan = enrolledParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                if (basePlan != null && basePlan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                {
                    ambRider.MonthlyBenefit = enrolledParticipant.Participant.RPPAMBCalculatedAmount ?? 0;
                }
                else
                {
                    if (vgsiPlan != null && !isOffer1)
                    {
                        ambRider.MonthlyBenefit = enrollmentVgsiParticipantOptionPlan?.AMBCalculatedAmount ?? 0;
                    }
                    else
                    {
                        ambRider.MonthlyBenefit = enrollmentBaseParticipantOptionPlan?.AMBCalculatedAmount ?? 0;
                    }
                }
                ambRider.MonthlyPremium = isSmoker ? CheckNullable(epopr.SmokerPremiumAmountMonthly) : CheckNullable(epopr.NonSmokerPremiumAmountMonthly);

                ambRider.AnnualPremium = isSmoker ? CheckNullable(epopr.SmokerPremiumAmountAnnual) : CheckNullable(epopr.NonSmokerPremiumAmountAnnual);
                if (epopr.BenefitPeriodType != null)
                {
                    if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                    {

                        ambRider.BenefitPeriodAge = 65;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                    {
                        ambRider.BenefitPeriodAge = 67;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                    {
                        ambRider.BenefitPeriodAge = 70;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || epopr.BenefitPeriodType == BenefitPeriodTypeEnum.M24)
                    {
                        ambRider.BenefitPeriodYears = 2;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || epopr.BenefitPeriodType == BenefitPeriodTypeEnum.M60)
                    {
                        ambRider.BenefitPeriodYears = 5;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                    {
                        ambRider.BenefitPeriodYears = 10;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                    {
                        ambRider.BenefitPeriodYears = 15;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || epopr.BenefitPeriodType == BenefitPeriodTypeEnum.M12)
                    {
                        ambRider.BenefitPeriodYears = 1;
                    }

                }
                if (epopr.EliminationPeriodType != null)
                {

                    if (epopr.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                    {
                        ambRider.EliminationPeriod = 180;
                    }
                    else if (epopr.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                    {
                        ambRider.EliminationPeriod = 360;
                    }
                    else if (epopr.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                    {
                        ambRider.EliminationPeriod = 720;
                    }
                    else if (epopr.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                    {
                        ambRider.EliminationPeriod = 90;
                    }

                }

                if (basePlan.PremiumPayerAndTaxabilityType != null && basePlan.PremiumPayerAndTaxabilityType.Id == (int?)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                {
                    if (!isSmoker)
                    {
                        ambRider.CSEEPremiumPaidPerMonth = CheckNullable(epop.NonSmokerEmployeePremiumPerMonth);
                        ambRider.CSERPremiumPaidPerMonth = CheckNullable(epop.NonSmokerEmployerPremiumPerMonth);
                        ambRider.CSEEPremiumPaidPerPaycheck = CheckNullable(epop.NonSmokerEmployeePremiumAmountPaycheck);
                        ambRider.CSERPremiumPaidPerPaycheck = CheckNullable(epop.NonSmokerEmployerPremiumAmountPaycheck);
                    }
                    else
                    {
                        ambRider.CSEEPremiumPaidPerMonth = CheckNullable(epop.SmokerEmployeePremiumPerMonth);
                        ambRider.CSERPremiumPaidPerMonth = CheckNullable(epop.SmokerEmployerPremiumPerMonth);
                        ambRider.CSEEPremiumPaidPerPaycheck = CheckNullable(epop.SmokerEmployeePremiumAmountPaycheck);
                        ambRider.CSERPremiumPaidPerPaycheck = CheckNullable(epop.SmokerEmployerPremiumAmountPaycheck);
                    }
                }

                if (ambRider.MonthlyPremium > 0 && ambRider.AnnualPremium > 0)
                {
                    offer.Riders.Add(ambRider);
                }
                else
                {

                    Log.Debug($"+MLDEManger.CreateAMBRiders : Skipping AMBR rider tags as premium is zero for Enrollment ParticipantId '{enrolledParticipant.Id}'");
                }
            }
        }
        public int GetOptionClassTypeOrder(ParticipantCategoryCodeTypeEnum? participantCodeType)
        {
            int optionClassTypeOrder = 0;
            switch (participantCodeType)
            {
                case ParticipantCategoryCodeTypeEnum.NE:
                    optionClassTypeOrder = 1;
                    break;
                case ParticipantCategoryCodeTypeEnum.PS:
                    optionClassTypeOrder = 2;
                    break;
                case ParticipantCategoryCodeTypeEnum.FO:
                    optionClassTypeOrder = 3;
                    break;
                case ParticipantCategoryCodeTypeEnum.AMB:
                    optionClassTypeOrder = 4;
                    break;

            }
            return optionClassTypeOrder;
        }
        private decimal? CheckNullable(decimal? input)
        {
            if (input != null && input > 0)
            {
                return input;
            }
            else
            {
                return 0m;
            }

        }

        private decimal CheckNull(decimal? input)
        {
            if (input != null && input > 0)
            {

                decimal val = input ?? 0;
                return val;
            }
            else
            {
                return 0m;
            }

        }

        private PremiumPaymentPeriodRestriction? GetPolicySummaryPayPeriod(string billingModeTypeDescription)
        {
            PremiumPaymentPeriodRestriction policySummaryPayPeriod = new PremiumPaymentPeriodRestriction();
            if (billingModeTypeDescription == "Half Yearly")
            {
                policySummaryPayPeriod = PremiumPaymentPeriodRestriction.Semiannual;
            }
            else if (billingModeTypeDescription == "Monthly")
            {
                policySummaryPayPeriod = PremiumPaymentPeriodRestriction.Monthly;
            }
            else if (billingModeTypeDescription == "Quarterly")
            {
                policySummaryPayPeriod = PremiumPaymentPeriodRestriction.Quarterly;
            }
            else if (billingModeTypeDescription == "Yearly")
            {
                policySummaryPayPeriod = PremiumPaymentPeriodRestriction.Annually;
            }

            return policySummaryPayPeriod;
        }

        private PayorTypeRestriction GetPayortype(PDRSoldClassPlan pdrSoldClassPlans)
        {

            PayorTypeRestriction Payorenumtype = new PayorTypeRestriction();
            if (pdrSoldClassPlans.PremiumPayerAndTaxabilityType.Id == Convert.ToInt16(ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid))
            {
                Payorenumtype = PayorTypeRestriction.Employer;
            }
            else if (pdrSoldClassPlans.PremiumPayerAndTaxabilityType.Id == Convert.ToInt16(ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare))
            {
                Payorenumtype = PayorTypeRestriction.Shared;
            }
            else if (pdrSoldClassPlans.PremiumPayerAndTaxabilityType.Id == Convert.ToInt16(ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable))
            {
                Payorenumtype = PayorTypeRestriction.Employee;
            }
            else
            {
                Payorenumtype = PayorTypeRestriction.Employee;
            }


            return Payorenumtype;
        }

        private bool CheckForValueInFullyUnderwrittenIDI(ParticipantExistingPolicy participantExistingPolicy)
        {
            bool isBerkshireIDITagToBeShown = false;

            if (participantExistingPolicy.FullyUnderwrittenIDI != null && participantExistingPolicy.FullyUnderwrittenIDI > 0)
            {
                isBerkshireIDITagToBeShown = true;
            }
            return isBerkshireIDITagToBeShown;
        }

        private PremiumPaymentPeriodRestriction? GetPayPeriod(ListBillNumber listbilnumbers)
        {
            if (listbilnumbers.BillingModeType == null) return null;


            PremiumPaymentPeriodRestriction PayPeriod = new PremiumPaymentPeriodRestriction();
            if (listbilnumbers.BillingModeType == BillingModeTypeEnum.Annual)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Annually;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.Semi_Annual)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Semiannual;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.Quarterly)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Quarterly;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.Monthly)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Monthly;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.MonthlyGOM)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Monthly;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.DirectBillMonthly)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Monthly;
            }

            return PayPeriod;

        }

        #endregion

        public void SendEnrollmentData(int enrollmentId)
        {
            Log.Trace("+MLDEManger.SendEnrollmentData");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentMLDEStatusQuery = unitOfWork.Repository<EnrollmentMLDEStatus>().Linq().Where(enrollmentMLDEStatus => enrollmentMLDEStatus.Enrollment_Id == enrollmentId);
                if (!enrollmentMLDEStatusQuery.Any())
                {
                    Log.Trace("-MLDEManger.SendEnrollmentData: No records found for the given enrollmentId.");
                    return;
                }

                try
                {
                    var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(enrollmentItem => enrollmentItem.Id == enrollmentId);
                    var userInfo = _securityManager.GetUserInfo(HttpContext.Current.User);
                    var enrollmentMLDEDto = new EnrollmentMLDEDto
                    {
                        EnrollmentName = enrollment.EnrollmentName,
                        EnrollmentStartDate = enrollment.EnrollmentStartDate,
                        EnrollmentEndDate = enrollment.EnrollmentEndDate,
                        EffectiveDate = enrollment.EffectiveDate,
                        ExtensionEndDate = enrollment.ExtensionEndDate,
                        Active = enrollment.IsActive == null && enrollment.EffectiveDate > DateTime.Now ? true : enrollment.IsActive
                    };
                    var patchViewModelV2 = new PatchViewModelV2
                    {
                        ObjectIdProperty = "EnrollmentId",
                        ObjectIdValue = enrollmentId.ToString(),
                        PatchObject = enrollmentMLDEDto,
                        UserId = userInfo.Name
                    };
                    _imldeService.SendEnrollmentData(patchViewModelV2);

                }
                catch (Exception ex)
                {
                    Log.Error($"MLDEManger.SendEnrollmentData: Error while sending enrollment data to mlde system for the enrollmentId {enrollmentId}!", ex);
                }
            }

            Log.Trace("-MLDEManger.SendEnrollmentData");
        }

    }
}
