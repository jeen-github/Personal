﻿using CMS.Interfaces.Managers.ImplementationManagers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Logger.Static;
using Common.Exceptions;
using System.Collections;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Interfaces.DataAccess;
using System.Text.RegularExpressions;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Interfaces.Managers.ITAdminManagers;

namespace CMS.Managers.ImplementationManangers
{
    public class EnrollmentManagerValidator
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        public EnrollmentManagerValidator(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public void ValidateEnrollmentData(EnrollmentDto request)
        {
            Log.TraceFormat("+ValidateEnrollmentData");
            var errorMessages = new List<string>();
            ValidateEnrollmentName(errorMessages, request);
            ValidateEnrollmentStartDate(errorMessages, request);
            ValidateEnrollmentEndDate(errorMessages, request);
            ValidateEnrollmentExtensionEndDate(errorMessages, request);
            ValidateEnrollmentEffectiveDate(errorMessages, request);
            ValidateEnrollmentMethodType(errorMessages, request);
            ValidateProductType(errorMessages, request);
            ValidateEnrollmentWebAddress(request, errorMessages);

            if (request.IsAddOnIndicator)
            {
                ValidateCensusParticipant(errorMessages, request);
            }
            else
            {
                ValidateEnrollmentClasses(errorMessages, request);
            }
            Log.TraceFormat("-ValidateEnrollmentData");
            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }


        public void ValidateEnrollmentStartDate(List<string> errorMessages, EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+ValidateEnrollmentStartDate");
            if (enrollmentDto.EnrollmentStartDate == null)
            {
                errorMessages.Add("Please enter the Enrollment Start Date.");
            }

            Log.TraceFormat("-ValidateEnrollmentStartDate");
        }
        public void ValidateEnrollmentEndDate(List<string> errorMessages, EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+ValidateEnrollmentEndDate");
            if (enrollmentDto.EnrollmentEndDate == null)
            {
                errorMessages.Add("Please enter the Enrollment End Date.");
            }
            else if ((enrollmentDto.EnrollmentEndDate <= enrollmentDto.EnrollmentStartDate))
            {
                errorMessages.Add("Enrollment End Date must be greater than Enrollment Start Date.");
            }
            Log.TraceFormat("-ValidateEnrollmentEndDate");
        }

        public void ValidateEnrollmentWebAddress(EnrollmentDto enrollmentDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateEnrollmentWebAddress");

            if (!string.IsNullOrEmpty(enrollmentDto.EnrollmentWebsite))
            {
                bool result = false;
                var url = enrollmentDto.EnrollmentWebsite;
                if (url.ToLower().StartsWith("www."))
                {
                    url = "http://" + url;
                }
                Uri uriResult;
                result = Uri.TryCreate(url, UriKind.Absolute, out uriResult)
                    && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);

                if (!result) errorMessages.Add("Please provide a valid enrollment web address");
            }

            Log.TraceFormat("-ValidateEnrollmentWebAddress");
        }

        public void ValidateEnrollmentExtensionEndDate(List<string> errorMessages, EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+ValidateEnrollmentExtensionEndDate");
            if (enrollmentDto.ExtensionEndDate == null)
            {
                errorMessages.Add("Please enter the Enrollment Extension End Date.");
            }
            else if ((enrollmentDto.ExtensionEndDate <= enrollmentDto.EnrollmentEndDate))
            {
                errorMessages.Add("Enrollment Extension End Date must be greater than Enrollment End Date.");
            }
            Log.TraceFormat("-ValidateEnrollmentExtensionEndDate");
        }

        public void ValidateEnrollmentEffectiveDate(List<string> errorMessages, EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+ValidateEnrollmentEffectiveDate");
            if (enrollmentDto.EffectiveDate == null)
            {
                errorMessages.Add("Please enter the Enrollment Effective Date.");
            }
            else if ((enrollmentDto.EffectiveDate <= enrollmentDto.ExtensionEndDate))
            {
                errorMessages.Add("Enrollment Effective Date must be greater than Enrollment Extension End Date.");
            }
            Log.TraceFormat("-ValidateEnrollmentEffectiveDate");
        }

        public void ValidateEnrollmentName(List<string> errorMessages, EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+ValidateEnrollmentName");
            if (string.IsNullOrWhiteSpace(enrollmentDto.EnrollmentName))
            {
                errorMessages.Add("Please enter the Enrollment Name.");
            }
            else if (enrollmentDto.Mode)
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var enrollments = unitOfWork.Repository<Enrollment>().Linq().Where(c => c.Case.Id == enrollmentDto.CaseId);
                    if (enrollments.Count() > 0)
                    {
                        if (enrollments.Any(s => s.EnrollmentName.ToLower() == enrollmentDto.EnrollmentName.ToLower()))
                        {
                            errorMessages.Add("Enrollment Name must be unique.");
                        }
                    }
                }
                Log.TraceFormat("-ValidateEnrollmentName");
            }
        }

        public void ValidateEnrollmentMethodType(List<string> errorMessages, EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+ValidateEnrollmentMethodType");

            if (enrollmentDto.EnrollmentMethodTypeId == 0)
            {
                errorMessages.Add("Please select the Enrollment Type.");
            }

            var PlanDesignRequestClassProductDto = new PlanDesignRequestClassProductDto();

            if (enrollmentDto.SelectedClasses.Any())
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    foreach (var objclass in enrollmentDto.SelectedClasses)
                    {
                        var PlanDesignRequestClassProduct = unitOfWork.Repository<PDRSoldClassPlan>().Linq()
                            .Where(c => c.PDRSoldClass.PlanDesignRequestClass.Id == objclass).FirstOrDefault();
                        PlanDesignRequestClassProductDto.IsOneStepEnrollmentIndicator = PlanDesignRequestClassProduct.IsOneStepEnrollmentIndicator != false ?
                            PlanDesignRequestClassProduct.IsOneStepEnrollmentIndicator : false;
                        
                        if ((PlanDesignRequestClassProductDto.IsOneStepEnrollmentIndicator == true) && (enrollmentDto.EnrollmentMethodTypeId != (int)EnrollmentMethodTypeEnum.OneStep))
                        {
                            if (!errorMessages.Contains("For one-step enrollments, enrollment type must be one-step."))
                            {
                                errorMessages.Add("For one-step enrollments, enrollment type must be one-step.");
                            }
                        }
                        else if ((PlanDesignRequestClassProductDto.IsOneStepEnrollmentIndicator == false) && (enrollmentDto.EnrollmentMethodTypeId == (int)EnrollmentMethodTypeEnum.OneStep))
                        {
                            if (!errorMessages.Contains("This is not identified as a one-step enrollment, enrollment type cannot be one-step."))
                            {
                                errorMessages.Add("This is not identified as a one-step enrollment, enrollment type cannot be one-step.");
                            }
                        }

                        if ((PlanDesignRequestClassProduct.IsDirectCoverageIndicator == true) && (enrollmentDto.EnrollmentMethodTypeId != (int)EnrollmentMethodTypeEnum.DirectCoverage))
                        {
                            if (!errorMessages.Contains("Enrollment selected on PDR screen is Direct Coverage, therefore Enrollment Type must be Direct Coverage."))
                            {
                                errorMessages.Add("Enrollment selected on PDR screen is Direct Coverage, therefore Enrollment Type must be Direct Coverage.");
                            }
                        }
                        else if ((PlanDesignRequestClassProduct.IsDirectCoverageIndicator == false) && (enrollmentDto.EnrollmentMethodTypeId == (int)EnrollmentMethodTypeEnum.DirectCoverage))
                        {
                            if (!errorMessages.Contains("Enrollment selected on PDR screen is not Direct Coverage, therefore Enrollment Type cannot be Direct Coverage."))
                            {
                                errorMessages.Add("Enrollment selected on PDR screen is not Direct Coverage, therefore Enrollment Type cannot be Direct Coverage.");
                            }
                        }

                    }
                }              
                           
            }
            Log.TraceFormat("-ValidateEnrollmentMethodType");
        }

        public void ValidateProductType(List<string> errorMessages, EnrollmentDto enrollmentDto)
        {
            var caseUnderWrittingRequestDto = new CaseUnderwritingRequestDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseUnderWrittingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == enrollmentDto.CaseId);
                caseUnderWrittingRequestDto.PricingTypeId = caseUnderWrittingRequest.PricingType != null ? (int?)caseUnderWrittingRequest.PricingType : null;
            }
            Log.TraceFormat("+ValidateProductType");
            if (enrollmentDto.PricingTypeId == 0 || enrollmentDto.PricingTypeId == null)
            {
                errorMessages.Add("Please select the Product Type.");
            }
            else if ((enrollmentDto.PricingTypeId != caseUnderWrittingRequestDto.PricingTypeId))
            {
                errorMessages.Add("Product Type on the Plan Design tab and Product  on Edit Enrollment screen do not match. Please review and change to the appropriate state approved product.");
            }

            Log.TraceFormat("-ValidateProductType");       
        }

        public void ValidateEnrollmentClasses(List<string> errorMessages, EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+ValidateEnrollmentClasses");
            if (!enrollmentDto.SelectedClasses.Any())
            {
                errorMessages.Add("At least 1 class must be selected.");
            }
            Log.TraceFormat("-ValidateEnrollmentClasses");
        }

        public void ValidateCensusParticipant(List<string> errorMessages, EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+ValidateCensusParticipant");
            if (!enrollmentDto.SelectedCensusParticipant.Any())
            {
                errorMessages.Add("At least 1 participant must be selected.");
            }
            Log.TraceFormat("-ValidateCensusParticipant");
        }

        public void ValidateEnrollmentMilestoneData(EnrollmentMilestoneDto request)
        {
            Log.TraceFormat("+ValidateEnrollmentMilestoneData");

            var errorMessages = new List<string>();
            ValidateEnrollmentMilestoneDueDate(errorMessages, request);
            ValidateEnrollmentMilestoneName(errorMessages, request);
            ValidateEnrollmentMilestoneEffectiveDate(errorMessages, request);

            Log.TraceFormat("-ValidateEnrollmentMilestoneData");
            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }

        public void ValidateEnrollmentMilestoneDueDate(List<string> errorMessages, EnrollmentMilestoneDto enrollmentMilestoneDto)
        {
            Log.TraceFormat("+ValidateEnrollmentMilestoneDueDate");
            if ((enrollmentMilestoneDto.MilestoneDueDate <= enrollmentMilestoneDto.MilestoneStartDate))
            {
                errorMessages.Add("Milestone Due Date must be greater than Milestone Start Date.");
            }
            Log.TraceFormat("-ValidateEnrollmentMilestoneDueDate");
        }

        public void ValidateEnrollmentMilestoneName(List<string> errorMessages, EnrollmentMilestoneDto enrollmentMilestoneDto)
        {
            Log.TraceFormat("+ValidateEnrollmentMilestoneName");
            if (string.IsNullOrWhiteSpace(enrollmentMilestoneDto.EnrollmentMilestoneName))
            {
                errorMessages.Add("Please enter the Milestone Name.");
            }
            else
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var enrollmentMilestones = unitOfWork.Repository<EnrollmentMilestone>().Linq().Where(c => c.Enrollment.Id == enrollmentMilestoneDto.EnrollmentId);
                    if (enrollmentMilestones.Any())
                    {
                        if (enrollmentMilestones.Any(s => s.EnrollmentMilestoneName.ToLower() == enrollmentMilestoneDto.EnrollmentMilestoneName.ToLower() && s.Id != enrollmentMilestoneDto.EnrollmentMilestoneId))
                        {
                            errorMessages.Add("Milestone Name must be unique.");
                        }

                    }
                }
            }
            Log.TraceFormat("-ValidateEnrollmentMilestoneName");
        }

        public void ValidateEnrollmentOptionRequest(EnrollmentPDRClassDto request)
        {
            Log.TraceFormat("+ValidateEnrollmentOptionRequest");

            var errorMessages = new List<string>();
            var i = 0;
            foreach (var option in request.EnrollmentPDRClassOptions)
            {
                i++;
                var messageFor = "Option " + i.ToString();
                ValidateEnrollmentPDRClassOptionPlan(errorMessages, option.EnrollmentPDRClassOptionPlans[0], messageFor);

            }

            Log.TraceFormat("-ValidateEnrollmentOptionRequest");

            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }


        public void ValidateEnrollmentPDRClassOptionPlan(List<string> listOfError, EnrollmentPDRClassOptionPlanDto enrollmentPDRClassOptionPlanDto, string messageFor)
        {
            Log.TraceFormat("+ValidateEnrollmentPDRClassOptionPlan");
            if (enrollmentPDRClassOptionPlanDto != null)
            {
                if (enrollmentPDRClassOptionPlanDto.GSIPercentage > enrollmentPDRClassOptionPlanDto.MaxGSIPercentage)
                {
                    listOfError.Add(string.Format("Enter any GSI Percentage not to exceed {0:C2} approved by UW for {2}.", enrollmentPDRClassOptionPlanDto.MaxGSIPercentage, enrollmentPDRClassOptionPlanDto.GSIPercentage, messageFor));
                }
                else if (enrollmentPDRClassOptionPlanDto.GSIPercentage < enrollmentPDRClassOptionPlanDto.MinGSIPercentage)
                {
                    listOfError.Add(string.Format("Enter any GSI Percentage not to exceed {0:C2} approved by UW for {2}.", enrollmentPDRClassOptionPlanDto.MinGSIPercentage, enrollmentPDRClassOptionPlanDto.GSIPercentage, messageFor));
                }
                if (enrollmentPDRClassOptionPlanDto.EnrollmentPDRClassOptionPlanRiders != null)
                {

                    foreach (var planRider in enrollmentPDRClassOptionPlanDto.EnrollmentPDRClassOptionPlanRiders)
                    {
                        if (planRider.Amount > planRider.MaxAmount)
                        {
                            listOfError.Add(string.Format("Can enter any {0} Amount not to exceed {1:C2} approved by UW for {3}.", planRider.DisplayName, planRider.MaxAmount, planRider.MinAmount, messageFor));
                        }
                        else if (planRider.Amount < planRider.MinAmount)
                        {
                            listOfError.Add(string.Format("Can enter any {0} Amount not to exceed {1:C2} approved by UW for {3}.", planRider.DisplayName, planRider.MaxAmount, planRider.MinAmount, messageFor));
                        }
                    }
                }
            }
            Log.TraceFormat("-ValidateEnrollmentPDRClassOptionPlan");
        }

        public void ValidateTaxRateDefault(EnrollmentOutputDto enrollmentOutputDto)
        {
            Log.TraceFormat("+ValidateTaxRateDefault");

            var errorMessages = new List<string>();
            ValidateTaxRateDefault(errorMessages, enrollmentOutputDto);
            if (errorMessages.Any()) throw new ValidationException(errorMessages);

            Log.TraceFormat("-ValidateTaxRateDefault");
        }

        public void ValidateTaxRateDefault(List<string> errorMessages, EnrollmentOutputDto enrollmentOutputDto)
        {
            Log.TraceFormat("+ValidateTaxRateDefault");
            if (enrollmentOutputDto.EnrollmentOutputShowTypeId == (int)EnrollmentOutputShowTypeEnum.NetIncome)
            {
                if (enrollmentOutputDto.TaxRatePercentage < 0 || enrollmentOutputDto.TaxRatePercentage > 1)
                {
                    errorMessages.Add("Please enter a valid Tax Rate.");
                }
            }
            Log.TraceFormat("-ValidateTaxRateDefault");
        }

        public void ValidateEnrollmentMilestoneEffectiveDate(List<string> errorMessages, EnrollmentMilestoneDto enrollmentMilestoneDto)
        {
            Log.TraceFormat("+ValidateEnrollmentMilestoneEffectiveDate");
            if (enrollmentMilestoneDto.MilestoneDueDate >= enrollmentMilestoneDto.EnrollmentEffectiveDate)
            {
                errorMessages.Add("Milestone Due Date cannot be greater than the Enrollment Effective Date.");
            }
            if (enrollmentMilestoneDto.MilestoneStartDate >= enrollmentMilestoneDto.EnrollmentEffectiveDate)
            {
                errorMessages.Add("Milestone Start Date cannot be greater than the Enrollment Effective Date.");
            }
            Log.TraceFormat("-ValidateEnrollmentMilestoneEffectiveDate");
        }
    }
}
