﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.FileNetDocumentRepositories;
using CMS.Interfaces.Integrations.IndexWSServices;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Utilities;
using Logger.Static;
using Newtonsoft.Json;
using NHibernate.Linq;

namespace CMS.Managers.ImplementationManangers
{
    public class PolicyNumberUpdationManager : IWorkUnitHandler, IPolicyNumberUpdationManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IFileNetDocumentRepository _fileNetDocumentRepository;

        public PolicyNumberUpdationManager(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager, 
            IFileNetDocumentRepository fileNetDocumentRepository)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _workUnitManager = workUnitManager;
            _fileNetDocumentRepository = fileNetDocumentRepository;
        }

        public void EnqueueRequest(PolicyGenerationRequestDto policyGenerationRequest)
        {
            Log.TraceFormat("+EnqueueRequest");

            _workUnitManager.CreateWorkUnit(WorkUnitType.PolicyNumberFilenetUpdation, string.Join(",", JsonConvert.SerializeObject(policyGenerationRequest)));

            Log.TraceFormat("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.DebugFormat("+PolicyNumberUpdationManager");

            var request = JsonConvert.DeserializeObject<PolicyGenerationRequestDto>(workUnit.InputData);

            var splittedEnrollmentParticipantsIds = request.SelectedEnrollmentParticipantIds.ChunkBy(1000);

            Log.DebugFormat($"PolicyNumberUpdationManager: Filenet updation started for the OneStep participants for the work unit id {workUnit.Id}");

            foreach (var enrollmentParticipantIds in splittedEnrollmentParticipantsIds)
            {
                var enrollmentParticipants = new List<EnrollmentParticipant>();
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                        .Where(x => enrollmentParticipantIds.Contains(x.Id))
                        .Fetch(x => x.Enrollment)
                        .Fetch(x => x.Policies)
                        .ToList();
                }

                foreach (var enrollmentParticipant in enrollmentParticipants)
                {
                    if (enrollmentParticipant.Other != null)
                    {
                        int applicationId = enrollmentParticipant.Other.Id; //this if for Application form
                        
                        if (enrollmentParticipant.Policies != null && enrollmentParticipant.Policies.Count > 0)
                        {
                            string policyNumber = enrollmentParticipant.Policies?.FirstOrDefault().PolicyNumber;

                            var documentUploadRequest = CreateFileNetUpdateRequest(applicationId, policyNumber, request.GeneratedBy);

                            if (!string.IsNullOrEmpty(documentUploadRequest.FileNetDocumentId) && !string.IsNullOrEmpty(documentUploadRequest.PolicyNumber))
                            {
                                bool response = _fileNetDocumentRepository.UpdateExistingFileNetDocument(documentUploadRequest);

                                Log.DebugFormat($"PolicyNumberUpdationManager: Filenet updated for {documentUploadRequest.PolicyNumber}, enrollmentparticipant {enrollmentParticipant.Id} for the ApplicationId {applicationId}");
                            }
                            else
                            {
                                Log.DebugFormat($"PolicyNumberUpdationManager: Filenet updation failed for {documentUploadRequest.PolicyNumber} with enrollmentparticipant {enrollmentParticipant.Id} for the ApplicationId {applicationId}, newfilenet Guid not present.");
                                Log.DebugFormat($"PolicyNumberUpdationManager: Application file:{applicationId} not generated yet try again in 120s");
                                throw new RetryWorkUnitException(TimeSpan.FromSeconds(120));
                            }
                        }
                        else
                        {
                            Log.DebugFormat($"PolicyNumberUpdationManager: Filenet updation failed for enrollmentparticipant {enrollmentParticipant.Id} for the ApplicationId {applicationId}, PolicyNumber not present.");
                        }
                    }
                    else
                    {
                        Log.DebugFormat($"PolicyNumberUpdationManager: Filenet updation failed for the enrollmentparticipant {enrollmentParticipant.Id} for the work unit id {workUnit.Id}, ApplicationId not present");                       
                    }
                }
            }
                
            Log.DebugFormat($"-PolicyNumberUpdationManager: Filenet updation completed for the participants for the work unit id {workUnit.Id}"); 
        }

        private FileNetDocUploadRequest CreateFileNetUpdateRequest(int documentId, string policyNumber, string generatedBy)
        {
            Log.TraceFormat("PolicyNumberUpdationManager: +CreateFileNetUploadRequest:{0}", documentId);
            FileNetDocUploadRequest uploadRequest = null;
            
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var document = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == documentId);
                if (document == null) throw new ApplicationException("PolicyNumberUpdationManager: Application Document not found for the id:" + documentId);

                var enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                                        .FirstOrDefault(x => x.Other.Id == documentId);

                string agencycode = enrollmentParticipant?.Enrollment?.Case?.CaseBrokers?.Where(i => i.AgencyCode != null)?.FirstOrDefault()?.AgencyCode;
                string casenumber = enrollmentParticipant?.Enrollment?.Case?.CaseNumber;


                uploadRequest = new FileNetDocUploadRequest(
                            document.NewFileNetDocumentId,
                            policyNumber,
                            casenumber,
                            CaseDocumentTypeEnum.Application,
                            enrollmentParticipant?.Participant?.FirstName,
                            enrollmentParticipant?.Participant?.LastName,
                            true,
                            agencycode,
                            enrollmentParticipant?.Participant?.SocialSecurityNumber,
                            generatedBy,
                            enrollmentParticipant?.Id
                            );
            }

            Log.TraceFormat("PolicyNumberUpdationManager: -CreateFileNetUploadRequest:{0}", documentId);
            return uploadRequest;
        }

    }
}
