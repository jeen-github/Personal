﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.ImplementationManagers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplementationManangers
{
    public class ImplementationManager: IImplementationManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public ImplementationManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }
    }
}
