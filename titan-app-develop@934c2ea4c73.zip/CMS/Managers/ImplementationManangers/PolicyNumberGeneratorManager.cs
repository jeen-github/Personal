﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.IndexWSServices;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using Newtonsoft.Json;
using NHibernate.Linq;

namespace CMS.Managers.ImplementationManangers
{
    public class PolicyNumberGeneratorManager : IWorkUnitHandler, IPolicyNumberGenerationManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IIndexWSService _indexWSService;
        private readonly IPolicyNumberUpdationManager _policyNumberUpdationManager;


        public PolicyNumberGeneratorManager(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager, 
            IIndexWSService indexWSService, IPolicyNumberUpdationManager policyNumberUpdationManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _workUnitManager = workUnitManager;
            _indexWSService = indexWSService;
            _policyNumberUpdationManager = policyNumberUpdationManager;
        }

        public void EnqueueRequest(PolicyGenerationRequestDto policyGenerationRequest)
        {
            Log.TraceFormat("+EnqueueRequest");

            _workUnitManager.CreateWorkUnit(WorkUnitType.PolicyNumberGeneration, string.Join(",", JsonConvert.SerializeObject(policyGenerationRequest)));

            Log.TraceFormat("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.DebugFormat("+PolicyNumberGeneratorManager");

            var request = JsonConvert.DeserializeObject<PolicyGenerationRequestDto>(workUnit.InputData);

            try
            {
                var splittedEnrollmentParticipantsIds = request.SelectedEnrollmentParticipantIds.ChunkBy(1000);

                Log.DebugFormat($"PolicyNumberGeneratorManager: Policy number generation started for the OneStep participants for the work unit id {workUnit.Id}");

                Parallel.ForEach(splittedEnrollmentParticipantsIds, enrollmentParticipantIds =>
                {  
                    var enrollmentParticipants = new List<EnrollmentParticipant>();
                    using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                    {
                        enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                            .Where(x => enrollmentParticipantIds.Contains(x.Id))                            
                            .Fetch(x => x.Participant)
                            .Fetch(x => x.Enrollment)                           
                            .ThenFetch(x => x.Case)
                            .ThenFetch(x => x.CaseBrokers)
                            .ToList();


                        foreach (var enrollmentParticipant in enrollmentParticipants)
                        {
                            var policies = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().FirstOrDefault(i => i.EnrollmentParticipant.Id == enrollmentParticipant.Id);
                            if (string.IsNullOrEmpty(policies?.PolicyNumber))
                            {
                                var responseDto = _indexWSService.CreatePolicyNumber(enrollmentParticipant);
                                UpdatePolicyDetails(responseDto);
                            }
                            else
                            {
                                Log.DebugFormat($"PolicyNumberGeneratorManager: Policynumber already exist for the enrollmentparticipant {enrollmentParticipant.Id}, skipping generating new policy number");
                            }
                        }
                    }
                               
                });

                Log.DebugFormat($"PolicyNumberGeneratorManager: Policy number generation completed for the OneStep participants for the work unit id {workUnit.Id}");

            }
            catch (Exception e)
            {
                Log.Error($"PolicyNumberGeneratorManager: Error while generating policy numbers for work unit {workUnit.Id}!", e);
            }
            if(request.IsDirectCoverageEnrollment)
            {
                if(request.SitusState == StateTypeEnum.CA || request.SitusState == StateTypeEnum.FL)
                {
                    _policyNumberUpdationManager.EnqueueRequest(request); // Create a new work unit to Update New policy number into filenet.
                }
            }
            else
            {
                _policyNumberUpdationManager.EnqueueRequest(request); // Create a new work unit to Update New policy number into filenet.
            }
            
            Log.DebugFormat("-PolicyNumberGeneratorManager");
        }

        public void UpdatePolicyDetails(PolicyGenerationDto model)
        { 
            Log.DebugFormat("+UpdatePolicyDetails EnrollmentParticipantId={0} Policy={1} SelectedOptionId={2}",
                model.EnrollmentParticipantId, model.PolicyNumber, model.SelectedOptionId);

            try 
            {
                int enrollmentParticipantId = model.EnrollmentParticipantId;

                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq().FirstOrDefault(p => p.Id == enrollmentParticipantId);
                    if (enrollmentParticipant == null)
                    {
                        throw new Exception("UpdatePolicyDetails - " + "Enrollment Participant not found. Id=" + enrollmentParticipantId);                        
                    }

                    enrollmentParticipant.SocialSecurityNumber = model.Ssn;
                    enrollmentParticipant.BasePlanEnrollmentParticipantStatusType = EnrollmentParticipantStatusTypeEnum.Accepted;

                    //Skip updating the new policy number if already exist!
                    if (!enrollmentParticipant.Policies.Any())
                    {
                        Log.DebugFormat("UpdatePolicyDetails - Set plan status base:{0} buyup:{1}", enrollmentParticipant.BasePlanEnrollmentParticipantStatusType, enrollmentParticipant.VGSIPlanEnrollmentParticipantStatusType);

                        var enrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().FirstOrDefault(p =>
                            p.EnrollmentParticipant.Id == enrollmentParticipantId && p.PolicyNumber == model.PolicyNumber);

                        if (enrollmentParticipantPolicy == null)
                        {
                            Log.DebugFormat("UpdatePolicyDetails - Add new policy number to EnrollmentParticipantPolicy");
                            enrollmentParticipantPolicy = new EnrollmentParticipantPolicy { EnrollmentParticipant = enrollmentParticipant, PolicyNumber = model.PolicyNumber };
                            enrollmentParticipant.Policies.Add(enrollmentParticipantPolicy);
                        }

                        var anyPoliciesHavePlansAssigned = enrollmentParticipant.Policies.Any(p => p.EnrollmentPDRClassOptionPlan != null);

                        EnrollmentPDRClassOptionPlan policyOptionPlan = null;

                        if (!string.IsNullOrEmpty(model.SelectedOptionId))
                        {
                            Log.DebugFormat("UpdatePolicyDetails - SelectedOptionId={0}", model.SelectedOptionId);

                            var optionName = GetOptionName(model.SelectedOptionId);
                            Log.DebugFormat("OptionName={0}", optionName);

                            var pdrClassOption = unitOfWork.Repository<EnrollmentPDRClass>().Linq()
                                .Where(p => p.Enrollment.Id == enrollmentParticipant.Enrollment.Id &&
                                            p.PlanDesignRequestClass.Id == enrollmentParticipant.Participant.PlanDesignRequestClass.Id)
                                .SelectMany(c => c.EnrollmentPDRClassOptions)
                                .FirstOrDefault(o => o.IsSelected && o.OptionCode == optionName);

                            if (pdrClassOption == null)
                            {
                                var errorMessage = string.Format("Cannot find PDR Class Option with option name:'{0}'", optionName);
                                throw new Exception("UpdatePolicyDetails - " + errorMessage);
                            }

                            var optionBasePlan = pdrClassOption.EnrollmentPDRClassOptionPlans.FirstOrDefault(p => p.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                            var optionBuyUpPlan = pdrClassOption.EnrollmentPDRClassOptionPlans.FirstOrDefault(p => p.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                            policyOptionPlan = optionBuyUpPlan ?? optionBasePlan;
                            Log.DebugFormat("UpdatePolicyDetails - Has buy up plan={0}", optionBuyUpPlan != null);
                        }

                        enrollmentParticipantPolicy.EnrollmentPDRClassOptionPlan = policyOptionPlan;

                        if (policyOptionPlan != null)
                        {
                            enrollmentParticipantPolicy.EnrollmentParticipantOptionPlan = unitOfWork.Repository<EnrollmentParticipantOptionPlan>().Linq()
                                .FirstOrDefault(e => e.EnrollmentPDRClassOptionPlan.Id == policyOptionPlan.Id &&
                                                     e.EnrollmentParticipant.Id == enrollmentParticipantId);
                        }

                        unitOfWork.Repository<EnrollmentParticipant>().Save(enrollmentParticipant);
                        unitOfWork.Commit();
                    }
                    else
                    {
                        Log.Warn($"-Policynumber already exist for the enrollmentparticipant {enrollmentParticipant.Id}, skipping generating new policy number");
                    }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("UpdatePolicyDetails - " + ex);
            }            
            
            Log.DebugFormat("-UpdatePolicyDetails Id={0}", model.EnrollmentParticipantId);            
        }


        public string GetOptionName(string selectedOptionId)
        {
            var indexOfOptionString = selectedOptionId.IndexOf("Option", StringComparison.InvariantCultureIgnoreCase);
            return selectedOptionId.Substring(indexOfOptionString);
        }

    }
}
