﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Managers.DocumentManagers.DocumentGenerators;
using CMS.Model.Attributes;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Common.Utilities;
using Logger.Static;
using Renci.SshNet;

namespace CMS.Managers.ImplementationManangers
{
    public class EmailCampaignManager : IEmailCampaignManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;        
        private readonly IConfiguration _configuration;
        private readonly Dictionary<int, String> _caseTypeDictionary;


        public EmailCampaignManager(IUnitOfWorkFactory unitOfWorkFactory, IConfiguration configuration)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _configuration = configuration;
            _caseTypeDictionary = new Dictionary<int, string>();

        }

        public string GenerateCsv(int enrollmentId, int enrollmentEmailId)
        {
            Log.Trace($"+EmailCampaignManager.GenerateCsv - enrollmentId: {enrollmentId}, enrollmentEmailId: {enrollmentEmailId}");

            var participants = GetCsvData(enrollmentId, enrollmentEmailId);
            string csvString = BuildCsvString(participants);

            Log.Trace("-EmailCampaignManager.GenerateCsv");

            return csvString;
        }

        private List<EmailCampaignParticipantDto> GetCsvData(int enrollmentId, int enrollmentEmailId)
        {
            Log.Trace($"+EmailCampaignManager.GetCsvData - enrollmentId: {enrollmentId}, enrollmentEmailId: {enrollmentEmailId}");

            List<EmailCampaignParticipantDto> participants;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentEntity = unitOfWork.Repository<Enrollment>().Linq()
                    .FirstOrDefault(x => x.Id == enrollmentId);
                if (enrollmentEntity == null)
                    throw new Exception($"Error generating email campaign CSV data! Enrollment with id {enrollmentId} not found.");

                var enrollmentEmailEntity = unitOfWork.Repository<EnrollmentEmail>().Linq()
                    .FirstOrDefault(x => x.Id == enrollmentEmailId);
                if (enrollmentEmailEntity == null)
                    throw new Exception($"Error generating email campaign CSV data! Enrollment email record with id {enrollmentEmailId} not found.");

                // get all unique participant data
                participants = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                    .Where(x => x.Enrollment.Id == enrollmentId && x.MldeStatusType.HasValue)
                    .Where(ParticipantDataFilter)
                    .Select(ParticipantDataSelect)
                    .ToList();

                // get case type
                var enrollment = unitOfWork.Repository<Enrollment>().Linq()
                    .FirstOrDefault(x => x.Id == enrollmentId);
                string caseType = GetCaseType(enrollment);

                // get common data
                string companyName = enrollmentEntity.Case.CompanyName;
                string companyLogoFileName = $"{enrollmentId}-logofile";
                string enrollmentStartDate = enrollmentEntity.EnrollmentStartDate.ToShortDateString();
                string enrollmentEndDate = enrollmentEntity.EnrollmentEndDate.ToShortDateString();
                string contactPhoneNumber = enrollmentEmailEntity.Contact.Phone;
                string contactEmail = enrollmentEmailEntity.Contact.Email;
                string emailType = enrollmentEmailEntity.EnrollmentEmailType.ToString();
                string emailSendDate = enrollmentEmailEntity.SendDate?.AddMinutes(30).ToString("G");
                string enrollmentName = enrollmentEntity.EnrollmentName;

                // add common data to all participant data
                foreach (var participant in participants)
                {
                    participant.CompanyName = companyName;
                    participant.EnrollmentName = enrollmentName;
                    participant.CompanyLogoFileName = companyLogoFileName;
                    participant.EnrollmentStartDate = enrollmentStartDate;
                    participant.EnrollmentEndDate = enrollmentEndDate;
                    participant.ContactPhoneNumber = contactPhoneNumber;
                    participant.ContactEmail = contactEmail;
                    participant.EmailType = emailType;
                    participant.EmailSendDate = emailSendDate;
                    participant.CaseType = caseType;

                    // format MldeStatus to just be the code
                    participant.MldeStatus = !string.IsNullOrEmpty(participant.MldeStatus) && participant.MldeStatus.Length > 0 ? 
                        participant.MldeStatus.Substring(0, 1) :
                        null;
                }

                // add the rows for CC recipients
                var mockParticipant = participants.FirstOrDefault();
                int seq = 1;
                if (!string.IsNullOrEmpty(enrollmentEmailEntity.Cc))
                {
                    List<string> ccEmails = enrollmentEmailEntity.Cc.Split(';').ToList();
                    foreach (var ccEmail in ccEmails)
                    {
                        DateTime dt = DateTime.Now;
                        string datetime = dt.ToString("MMddHHmmss");
                        int uniqueEpid = 0;
                        int.TryParse(datetime, out uniqueEpid);
                        Thread.Sleep(1000);

                        var ccParticipant = new EmailCampaignParticipantDto
                        {
                            CompanyName = companyName,
                            EnrollmentName = enrollmentName,
                            EnrollmentParticipantId = (uniqueEpid * 100),
                            CompanyLogoFileName = companyLogoFileName,
                            EnrollmentStartDate = enrollmentStartDate,
                            EnrollmentEndDate = enrollmentEndDate,
                            ContactPhoneNumber = contactPhoneNumber,
                            ContactEmail = contactEmail,
                            Email = ccEmail,
                            EmailType = emailType,
                            EmailSendDate = emailSendDate,
                            CaseType = caseType,
                            MldeStatus = "C",
                            ParticipantClass = mockParticipant != null ? mockParticipant.ParticipantClass : "Class 1",
                            ParticipantCategoryCode = mockParticipant != null ? mockParticipant.ParticipantCategoryCode : "NE",
                            FirstName = "John",
                            MiddleInitial = "X",
                            LastName = "Smith",
                            Address1 = "100 Main St.",
                            Address2 = null,
                            City = "New York",
                            State = "NY",
                            ZipCode = "12345"
                        };
                        participants.Add(ccParticipant);
                        seq++;
                    }
                }
            }
            
            Log.Trace($"-EmailCampaignManager.GetCsvData");

            return participants;
        }

        private string BuildCsvString(List<EmailCampaignParticipantDto> participants)
        {
            Log.Trace("+EmailCampaignManager.BuildCsvString");

            var csvString = string.Empty;
            var participantProperties = typeof(EmailCampaignParticipantDto).GetProperties();
                       

            // add the header row
            foreach (var property in participantProperties)
            {
                var attributes = property.GetCustomAttributes(typeof(CsvHeaderAttribute), false);
                var csvHeaderAttribute = (CsvHeaderAttribute)attributes.FirstOrDefault();
                if (csvHeaderAttribute != null)
                {
                    csvString += csvHeaderAttribute.Value + "|";
                }
                else
                {
                    csvString += property.Name + "|";
                }
            }
            csvString += Environment.NewLine;

            // add the data rows
            foreach (var participant in participants)
            {
                foreach (var property in participantProperties)
                {
                    csvString += property.GetValue(participant) + "|";
                }
                csvString += Environment.NewLine;
            }

            Log.Trace("-EmailCampaignManager.BuildCsvString");

            return csvString;
        }

        public Expression<Func<EnrollmentParticipant, bool>> ParticipantDataFilter
        {
            get
            {
                return ep => ep!=null && (ep.Participant.IsEligible == null || ep.Participant.IsEligible == true);
            }
        }

        public Expression<Func<EnrollmentParticipant, EmailCampaignParticipantDto>> ParticipantDataSelect => ep => new EmailCampaignParticipantDto
        {

            EnrollmentParticipantId =  ep.Id,
            FirstName = ep.Participant.FirstName,
            MiddleInitial = ep.Participant.MiddleInitial,
            LastName = ep.Participant.LastName,
            Email = ep.Participant.WorkEmail,
            Address1 = ep.Participant.HomeStreet1,
            Address2 = ep.Participant.HomeStreet2,
            City = ep.Participant.HomeCity,
            State = ep.Participant.HomeStateDescription,
            ZipCode = ep.Participant.HomeZipCode,
            MldeStatus = ep.MldeStatusTypeEntity != null ? ep.MldeStatusTypeEntity.DisplayText : null,
            ParticipantClass = ep.Participant.PlanDesignRequestClass != null ? ep.Participant.PlanDesignRequestClass.PlanDesignRequestClassName: null,
            ParticipantCategoryCode = ep.Participant.ParticipantCategoryCodeDescription

        };

        public string GetCaseType(Enrollment enrollment)
        {
            Log.TraceFormat("+EmailCampaignManager.GetCaseType");

            string caseType = string.Empty;
          
            if (_caseTypeDictionary.ContainsKey(enrollment.Id)) return _caseTypeDictionary[enrollment.Id];

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                int caseId = unitOfWork.Repository<Model.Entities.Case>().Linq().FirstOrDefault(i => i.Id == enrollment.Case.Id).Id;
                int planDesignRequestId = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(j => j.Case.Id == caseId).Id;
                int planDesignSoldClassId = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(k => k.PlanDesignRequest.Id == planDesignRequestId).Id;
                var pdrSoldClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(l => l.PDRSoldClass.Id == planDesignSoldClassId).ToList();
                
                if (pdrSoldClassPlan.Any())
                {
                    var basePlanType = pdrSoldClassPlan.FirstOrDefault(i => i.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    var buyUpPlanType = pdrSoldClassPlan.FirstOrDefault(i => i.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                    if (basePlanType != null)
                    {
                        if (basePlanType.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                        {
                            caseType = "RPP";
                        }
                        else
                        {
                            caseType = PremiumPayorType(basePlanType.PremiumPayerAndTaxabilityType, false);
                        }
                    }

                    if (buyUpPlanType != null)
                    {                        
                        caseType = PremiumPayorType(basePlanType.PremiumPayerAndTaxabilityType, true);
                    }
                }
            }

            _caseTypeDictionary[enrollment.Id] = caseType;

            Log.TraceFormat("-EmailCampaignManager.GetCaseType");

            return caseType;
        }

        private string PremiumPayorType(ExistingCoveragePremiumAndTaxpayerLiabilityType premiumPayorType, bool hasBuyUp)
        {
            string payerType = string.Empty;

            if (premiumPayorType != null)
            {
                switch (premiumPayorType.Id)
                {
                    case (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare:
                        payerType = "Cost Share";
                        break;
                    case (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid:
                        if (hasBuyUp == true)
                        {
                            //mappedType.Add(ListBillPremiumPayerTypeEnum.EmployerwithVGSI);
                            payerType = "ER/VGSI";
                        }
                        else
                        {
                            //mappedType.Add(ListBillPremiumPayerTypeEnum.Employer);
                            payerType = "ER-paid";
                        }
                        break;
                    case (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable:
                        //mappedType.Add(ListBillPremiumPayerTypeEnum.Employer);
                        //mappedType.Add(ListBillPremiumPayerTypeEnum.Employee);
                        payerType = "ER-paid";
                        break;
                    case (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable:
                        //mappedType.Add(ListBillPremiumPayerTypeEnum.Employee);
                        payerType = "Buy-up";
                        break;
                }
            }

            return payerType;
        }

        public bool UploadSalesForceCSVToAxway(string csvData, int enrollmentEmailId, string fileName)
        {
            Log.TraceFormat("+EmailCampaignManager:UploadSalesForceCSVToAxway enrollmentEmailId:{0}", enrollmentEmailId);

            string host = _configuration.ExtreamAxwayStfpHostName;
            string port = _configuration.ExtreamAxwayStfpHostPort;
            string remotePath = _configuration.SalesForceStfpHostPath;
            string username = _configuration.ExtreamAxwayCredentials.UserName;
            string password = _configuration.ExtreamAxwayCredentials.Password;

            bool success = true;

            try
            {
                var connectionInfo = new ConnectionInfo(host, port, new PasswordAuthenticationMethod(username, password));

                using (var stfpClient = new SftpClient(connectionInfo))
                {
                    if (Debugger.IsAttached)
                    {
                        return success;
                    }

                    stfpClient.Connect();

                    var fileBytes = System.Text.Encoding.UTF8.GetBytes(csvData);

                    using (MemoryStream memoryStream = new MemoryStream(fileBytes))
                    {
                        stfpClient.BufferSize = 4 * 1024; // bypass Payload error large files
                        stfpClient.UploadFile(memoryStream, remotePath + fileName);
                    }

                    Thread.Sleep(1000);

                    stfpClient.Disconnect();
                }
            }
            catch (Exception ex)
            {
                success = false;
                Log.ErrorFormat($"EmailCampaignManager:UploadSalesForceCSVToAxway: Error sending salesforce csvdata {csvData}, EnrollmentEmailId {enrollmentEmailId} to Axway ftp path", ex);
            }

            Log.TraceFormat("-EmailCampaignManager:UploadSalesForceCSVToAxway enrollmentEmailId:{0}", enrollmentEmailId);

            return success;
        }

        public void SendPreviewEmailsRequest(int enrollmentParticipantId, string recipientEmail)
        {
            Log.Trace($"EmailCampaignManager.SendPreviewEmailsRequest - enrollmentParticipant: {enrollmentParticipantId}, recipientEmail: {recipientEmail}");

            try
            {
                string caseNumber;
                int? enrollmentId;
                var enrollmentEmail = new EnrollmentEmail();
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    caseNumber = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                        .FirstOrDefault(x => x.Id == enrollmentParticipantId)
                        ?.Enrollment
                        ?.Case
                        ?.CaseNumber;
                    enrollmentId = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                        .FirstOrDefault(x => x.Id == enrollmentParticipantId)
                        ?.Enrollment                        
                        ?.Id;
                    enrollmentEmail = unitOfWork.Repository<EnrollmentEmail>().LinqWithTimeOut().FirstOrDefault(i => i.Enrollment.Id == enrollmentId);
                }
                string fileName = $"preview_MLDE_{caseNumber}.csv";

                var previewCsv = GeneratePreviewCsv(enrollmentParticipantId, recipientEmail);
                
                CreateCaseDocument(enrollmentEmail, previewCsv, fileName);

                string host = _configuration.ExtreamAxwayStfpHostName;
                string port = _configuration.ExtreamAxwayStfpHostPort;
                string remotePath = _configuration.SalesForceStfpHostPath;
                string username = _configuration.ExtreamAxwayCredentials.UserName;
                string password = _configuration.ExtreamAxwayCredentials.Password;

                var connectionInfo = new ConnectionInfo(host, port, new PasswordAuthenticationMethod(username, password));
                using (var stfpClient = new SftpClient(connectionInfo))
                {
                    if (Debugger.IsAttached)
                    {
                        return;
                    }

                    var fileBytes = System.Text.Encoding.UTF8.GetBytes(previewCsv);

                    stfpClient.Connect();
                    using (MemoryStream memoryStream = new MemoryStream(fileBytes))
                    {
                        stfpClient.BufferSize = 4 * 1024; // bypass Payload error large files
                        stfpClient.UploadFile(memoryStream, remotePath + fileName);
                    }
                    stfpClient.Disconnect();
                }
            }
            catch (Exception e)
            {
                Log.Error("An error occurred attempting to send Axway/Salesforce the preview email request!", e);
            }

            Log.Trace("-EmailCampaignManager.SendPreviewEmailsRequest");
        }

        public string GeneratePreviewCsv(int enrollmentParticipantId, string recipientEmail)
        {
            Log.Trace($"+EmailCampaignManager.GeneratePreviewCsv - enrollmentParticipantId: {enrollmentParticipantId}, recipientEmail: {recipientEmail}");

            var participants = GetPreviewEmailData(enrollmentParticipantId, recipientEmail);
            string csvString = BuildCsvString(participants);
            
            Log.Trace("-EmailCampaignManager.GeneratePreviewCsv");
            
            return csvString;
        }

        private List<EmailCampaignParticipantDto> GetPreviewEmailData(int enrollmentParticipantId, string recipientEmail)
        {
            Log.Trace($"+EmailCampaignManager.GetPreviewEmailData - enrollmentParticipantId: {enrollmentParticipantId}, recipientEmail: {recipientEmail}");

            List<EmailCampaignParticipantDto> previewEmails = new List<EmailCampaignParticipantDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                // get data from database
                var enrollmentParticipantEntity = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                    .FirstOrDefault(x => x.Id == enrollmentParticipantId);
                if (enrollmentParticipantEntity == null)
                    throw new Exception($"Error generating preview emails CSV data! Enrollment participant with id {enrollmentParticipantId} not found.");

                var enrollmentEntity = enrollmentParticipantEntity.Enrollment;
                var enrollmentEmailEntities = unitOfWork.Repository<EnrollmentEmail>().Linq()
                    .Where(x => x.Enrollment.Id == enrollmentEntity.Id)
                    .ToList();

                // convert participant to object used for csv
                var enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                    .Where(x => x.Id == enrollmentParticipantId)
                    .Select(ParticipantDataSelect)
                    .FirstOrDefault();
                if (enrollmentParticipant == null)
                    throw new Exception($"Error generating preview emails CSV data! An issue occurred building the CSV object for enrollment participant with id {enrollmentParticipantId}.");
                
                // scrub PII data
                enrollmentParticipant.FirstName = "John";
                enrollmentParticipant.MiddleInitial = "X";
                enrollmentParticipant.LastName = "Smith";
                enrollmentParticipant.Address1 = "100 Main St.";
                enrollmentParticipant.Address2 = null;
                enrollmentParticipant.City = "New York";
                enrollmentParticipant.State = "NY";
                enrollmentParticipant.ZipCode = "12345";

                // get case type
                var enrollment = unitOfWork.Repository<Enrollment>().Linq()
                    .FirstOrDefault(x => x.Id == enrollmentParticipantEntity.Enrollment.Id);
                string caseType = GetCaseType(enrollment);

                // get common data
                string caseNumber = enrollmentEntity.Case.CaseNumber;
                string companyName = enrollmentEntity.Case.CompanyName;
                string companyLogoFileName = $"{enrollmentEntity.Id}-logofile";
                string enrollmentStartDate = enrollmentEntity.EnrollmentStartDate.ToShortDateString();
                string enrollmentEndDate = enrollmentEntity.EnrollmentEndDate.ToShortDateString();
                string sendDateString = DateTime.Now.AddMinutes(30).ToString("G");
                string enrollmentName = enrollmentEntity.EnrollmentName;

                if (enrollmentEmailEntities.Count > 0)
                {
                    foreach (var enrollmentEmailEntity in enrollmentEmailEntities)
                    {
                        var participant = new EmailCampaignParticipantDto(enrollmentParticipant)
                        {
                            EmailSendDate = sendDateString,
                            Email = recipientEmail,
                            EmailType = enrollmentEmailEntity.EnrollmentEmailType.ToString(),
                            ContactEmail = enrollmentEmailEntity.Contact?.Email,
                            ContactPhoneNumber = enrollmentEmailEntity.Contact?.Phone,
                            CompanyName = companyName,
                            CompanyLogoFileName = companyLogoFileName,
                            EnrollmentStartDate = enrollmentStartDate,
                            EnrollmentEndDate = enrollmentEndDate,
                            CaseType = caseType,
                            EnrollmentName = enrollmentName
                        };

                        participant.MldeStatus = !string.IsNullOrEmpty(participant.MldeStatus) && participant.MldeStatus.Length > 0 ?
                            participant.MldeStatus.Substring(0, 1) :
                            null;

                        previewEmails.Add(participant);
                    }
                }
                else
                {
                    var enrollmentContactEntity = unitOfWork.Repository<ContactAddress>().Linq()
                        .FirstOrDefault(c =>
                            c.Case.Id == enrollmentEntity.Case.Id &&
                            c.ContactRoleType == ContactRoleTypeEnum.EnrollmentContact);
                    foreach (var enrollmentEmailType in Enum.GetNames(typeof(EnrollmentEmailTypeEnum)))
                    {
                        var participant = new EmailCampaignParticipantDto(enrollmentParticipant)
                        {
                            EmailSendDate = sendDateString,
                            Email = recipientEmail,
                            EmailType = enrollmentEmailType,
                            ContactEmail = enrollmentContactEntity?.Email,
                            ContactPhoneNumber = enrollmentContactEntity?.Phone,
                            CompanyName = companyName,
                            CompanyLogoFileName = companyLogoFileName,
                            EnrollmentStartDate = enrollmentStartDate,
                            EnrollmentEndDate = enrollmentEndDate,
                            EnrollmentName = enrollmentName
                        };

                        participant.MldeStatus = !string.IsNullOrEmpty(participant.MldeStatus) && participant.MldeStatus.Length > 0 ?
                            participant.MldeStatus.Substring(0, 1) :
                            null;

                        previewEmails.Add(participant);
                    }
                }
            }

            Log.Trace("-EmailCampaignManager.GetPreviewEmailData");

            return previewEmails;
        }

        public void CreateCaseDocument(EnrollmentEmail enrollmentEmail, string csvData, string fileName)
        {
            Log.TraceFormat("+EmailCampaignManager:CreateCaseDocument: EnrollmentEmailId:{0} ", enrollmentEmail?.Id);

            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var cmsCase = unitOfWork.Repository<Model.Entities.Case>().Linq().FirstOrDefault(i => i.Id == enrollmentEmail.Enrollment.Case.Id);
                    var emailType = enrollmentEmail?.EnrollmentEmailType != null ? enrollmentEmail?.EnrollmentEmailType.GetDescription() : string.Empty;
                    var caseDocument = new CaseDocument
                    {
                        Case_Id = cmsCase.Id,
                        CreationDateTime = DateTime.Now,
                        CaseDocumentType = CaseDocumentTypeEnum.EMail,
                        FileMimeType = FileMimeTypeUtility.GetMimeType(ExtreamDocumentType.CSV.ToString()),
                        CaseDocumentRequest = null,
                        FileBytes = System.Text.Encoding.UTF8.GetBytes(csvData),
                        //DocumentName = enrollmentEmail == null ? fileName : $"SalesForce {emailType} CSV",
                        DocumentName =  fileName,
                        FileName = fileName
                    };
                    unitOfWork.Repository<CaseDocument>().Save(caseDocument);
                    unitOfWork.Commit();


                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat($"EmailCampaignManager:CreateCaseDocument: Error in CreateCaseDocument()", ex);
            }

            Log.TraceFormat("-EmailCampaignManager:CreateCaseDocument");
        }
    }
}
