﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Interfaces.Managers.LookupManagers;
using Logger.Static;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;

namespace CMS.Managers.ImplementationManangers
{
    public class BridgelineMessageManager : IBridgelineMessageManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly ILookupManager _lookupManager;

        public BridgelineMessageManager(IUnitOfWorkFactory unitOfWorkFactory, ILookupManager lookupManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _lookupManager = lookupManager;
        }

        public void UpdateEnrollmentParticipantStatus(string enrollmentParticipantStatuses)
        {
            Log.TraceFormat("+UpdateEnrollmentParticipantStatus");

            DataTable dataTable = (DataTable)JsonConvert.DeserializeObject(enrollmentParticipantStatuses, (typeof(DataTable)));

            string CMSDatabaseConnection = Common.Utilities.AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");

            using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
            {
                SqlCommand command = sqlConnection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "[cms].[USP_UpdateParticipantEnrollmentStatuses]";

                SqlParameter parameter = new SqlParameter();
                parameter.ParameterName = "@TableVariable";
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.Value = dataTable;

                command.Parameters.Add(parameter);

                sqlConnection.Open();
                int numberOfRowsUpdated = command.ExecuteNonQuery();
            }            

            Log.TraceFormat("-UpdateEnrollmentParticipantStatus");
        }
    }
}
