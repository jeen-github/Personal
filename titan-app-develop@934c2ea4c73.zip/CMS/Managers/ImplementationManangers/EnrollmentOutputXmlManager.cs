﻿using CMS.Interfaces.Common;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.BrokerDataServices;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Exceptions;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;
using Guardian.Core.Entities.Product.Enums.EnumExtensions;
using Logger.Static;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Managers.ImplementationManangers
{
    public class EnrollmentOutputXmlManager : IEnrollmentOutputXmlManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IEnrollmentKitXmlGenerator _enrollmentKitXmlGenerator;
        private readonly IBridgelineXmlGenerator _bridgelineXmlManager;
        private readonly IBrokerDataClient _brokerDataService;
        public EnrollmentOutputXmlManager(IUnitOfWorkFactory unitOfWorkFactory, IEnrollmentKitXmlGenerator enrollmentKitXmlGenerator,
            IBridgelineXmlGenerator bridgelineXmlManager, IBrokerDataClient brokerDataService)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _enrollmentKitXmlGenerator = enrollmentKitXmlGenerator;
            _bridgelineXmlManager = bridgelineXmlManager;
            _brokerDataService = brokerDataService;
        }
        public void GenerateEnrollmentKitRequest(EnrollmentKitXmlGenerationRequest request)
        {
            Log.TraceFormat("+GenerateEnrollmentKitRequest");
            StateTypeEnum? situsState = StateTypeEnum.UN;          
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var isCompactState = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId).IsCompactState;
                if (isCompactState == null)
                {
                    throw new ValidationException("Please select Compact State as Yes or No in Plan Design Request.");
                }

                var caseUnderWrittingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId);

                if (caseUnderWrittingRequest != null)
                {
                    situsState = caseUnderWrittingRequest.StateType != null ? caseUnderWrittingRequest.StateType : null;
                }
                var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(e => e.Id == request.EnrollmentId);
                if (enrollment.EnrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.DirectCoverage)
                {
                    request.IsDirectCoverageEnrollment = true;
                }
                else if(enrollment.EnrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.OneStep)
                {
                    request.IsOneStepEnrollment = true;
                }                          
            }
            request.SitusState = situsState;            
            _enrollmentKitXmlGenerator.EnqueueRequest(request);

            Log.TraceFormat("-GenerateEnrollmentKitRequest");
        }

        public ValidationMessageDto ValidateEnrollmentOutputXmlData(CaseCommonXmlGenerationRequest request, bool isBridgeLineXml)
        {
            var messageDto = new ValidationMessageDto();

            var errorMessages = new List<string>();
            var hasServicingProducerVoilation = true;

            var splittedParticipantsIds = request.ParticipantIds.ChunkBy(1000);
            Parallel.ForEach(splittedParticipantsIds, obj =>
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                                                        .Where(c => (c.Enrollment.Id == request.EnrollmentId) && obj.Contains(c.Id)).ToList();

                    var participants = enrollmentParticipants.Select(c => c.Participant);

                    ValidateHomeState(errorMessages, participants);

                    ValidatePrimaryProducer(request.CaseId, errorMessages, unitOfWork, enrollmentParticipants);

                    var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == request.EnrollmentId);

                    if ((EnrollmentMethodTypeEnum)enrollment.EnrollmentMethodType.Id == EnrollmentMethodTypeEnum.PaperOnline || (EnrollmentMethodTypeEnum)enrollment.EnrollmentMethodType.Id == EnrollmentMethodTypeEnum.Online)
                    {
                        ValidateWorkEmailAddress(errorMessages, participants);

                        ValidateDuplicateEmailAddress(errorMessages, participants);
                    }

                    if (isBridgeLineXml)
                    {
                        hasServicingProducerVoilation = ValidateServicingProducer(request.CaseId, errorMessages, unitOfWork, participants);

                        if (enrollment.AMBType != null && enrollment.AMBType == AMBTypeEnum.Negative)
                        {
                            ValidateAMBParticipants(errorMessages, participants);
                        }
                    }

                    if (errorMessages.Any())
                    {
                        messageDto.ShowAlertWindow = true;
                        messageDto.IsPaperTypeEnrollment = (EnrollmentMethodTypeEnum)enrollment.EnrollmentMethodType.Id == EnrollmentMethodTypeEnum.Paper ? ByPassAlertMessagesForPaperEnrollment(request.CaseId, unitOfWork, errorMessages) : false;
                        if (hasServicingProducerVoilation)
                        {
                            messageDto.IsPaperTypeEnrollment = false;
                        }
                        messageDto.ErrorMessages = errorMessages;
                    }
                }
            });
            return messageDto;
        }

        private bool ValidateServicingProducer(int caseId, List<string> errorMessages, IUnitOfWork unitOfWork, IEnumerable<Participant> participants)
        {
            var inputErrorMessageCount = errorMessages.Count;
            var participantExistingPolicies = participants.Where(p => p.ParticipantExistingPolicies.Count > 0 && p.IsAMBIncreaseIndicator == true).Select(p => p.ParticipantExistingPolicies.FirstOrDefault());
            if (participantExistingPolicies.Any())
            {
                var policyNumbers = participantExistingPolicies.SelectMany(pe => pe.ParticipantExistingPolicyDetails).Where(pd => pd.CLOASPolicyStatus == "Inforce" && pd.Product == "Provider Choice").Select(pd => pd.PolicyNumber).ToList();

                var servicingProducers = _brokerDataService.GetServicingProducers(policyNumbers);

                if (servicingProducers.Any())
                {
                    var addressBookProducers = unitOfWork.Repository<ContactAddress>().Linq().Where(ap => ap.ContactRoleType == ContactRoleTypeEnum.Producer && ap.Case.Id == caseId && ap.ContactName != null).Select(ap => ap.ContactName.ToUpper()).ToList();

                    var notInAdressBookServicingProducers = servicingProducers.Where(sp =>
                        !(addressBookProducers.Contains(sp.ProducerName != null ? sp.ProducerName.ToUpper() : string.Empty)
                        || addressBookProducers.Contains((sp.FirstName != null ? sp.FirstName.ToUpper() : string.Empty) + " " + (sp.LastName != null ? sp.LastName.ToUpper() : string.Empty)))).ToList();

                    foreach (var notInAdressBookProducer in notInAdressBookServicingProducers)
                    {
                        errorMessages.Add("Producer \"" + notInAdressBookProducer.ProducerName + " - " + notInAdressBookProducer.ProducerWritingCode + "\" needs to be added to the address book");
                    }
                }
            }
            return errorMessages.Count > inputErrorMessageCount;
        }

        private bool ByPassAlertMessagesForPaperEnrollment(int caseId, IUnitOfWork unitOfWork, List<string> errorMessages)
        {
            bool message = false;
            var caseUnderWritingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == caseId);
            if (caseUnderWritingRequest != null)
            {
                var situsType = caseUnderWritingRequest.SitusType;
                var homeStateErrorMessage = errorMessages.Where(s => s.Contains("Home state is missing for participant ")).FirstOrDefault();
                var validProducerErrorMessage = errorMessages.Where(s => s.Contains("A valid producer is missing for the following states ")).FirstOrDefault();

                if (situsType == SitusTypeEnum.Corporate)
                {
                    message = true;
                }
                else if ((situsType == SitusTypeEnum.Multi_State || situsType == SitusTypeEnum.Residence) && validProducerErrorMessage != null)
                {
                    message = true;
                }
                else if (situsType == SitusTypeEnum.Residence && (homeStateErrorMessage != null || validProducerErrorMessage != null))
                {
                    message = false;
                }
            }
            return message;
        }

        public void SaveBridgelineXml(BridgelineXmlDto bridgelineXmlDto)
        {
            Log.TraceFormat("+SaveBridgelinexml");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == bridgelineXmlDto.EnrollmentId);

                var bridgeLineXml = new BridgelineXml
                {
                    Name = bridgelineXmlDto.BridgelineXmlName,
                    GeneratedBy = bridgelineXmlDto.GeneratedBy,
                    Enrollment = enrollment
                };

                unitOfWork.Repository<BridgelineXml>().Save(bridgeLineXml);
                unitOfWork.Commit();

                var bridgelineXmlRequest = new CaseCommonXmlGenerationRequest
                {
                    CaseId = bridgelineXmlDto.CaseId,
                    EnrollmentId = bridgelineXmlDto.EnrollmentId,
                    RequestId = bridgeLineXml.Id,
                    ParticipantIds = bridgelineXmlDto.SelectedIds
                };
                _bridgelineXmlManager.EnqueueRequest(bridgelineXmlRequest);
            }

            Log.TraceFormat("-SaveBridgelinexml");
        }

        private void ValidateDuplicateEmailAddress(List<string> errorMessages, IEnumerable<Participant> participants)
        {
            var duplicateWorkEmail = participants.Where(x => !string.IsNullOrWhiteSpace(x.WorkEmail)).GroupBy(c => c.WorkEmail)
                                                                 .Where(gr => gr.Count() > 1 && gr.Key != null)
                                                                 .Select(gr => gr.Key);

            if (duplicateWorkEmail != null)
            {
                foreach (var emailAddress in duplicateWorkEmail)
                {
                    var groupedParticipants = participants.Where(c => c.WorkEmail == emailAddress);
                    foreach (var p in groupedParticipants)
                    {
                        errorMessages.Add("Duplicate email address is found for participant " + p.LastName + " " + p.FirstName + " with participant ID " + p.EmployeeId);
                    }
                }
            }
        }

        private void ValidateWorkEmailAddress(List<string> errorMessages, IEnumerable<Participant> participants)
        {
            var workEmails = participants.Where(c => c.WorkEmail == null || c.WorkEmail == string.Empty).ToList();

            if (workEmails != null)
            {
                foreach (var p in workEmails)
                {
                    errorMessages.Add("Work email address is missing for participant " + p.LastName + " " + p.FirstName + " with participant ID " + p.EmployeeId);
                }
            }
        }

        private List<StateTypeEnum> BuildStateIds(CaseUnderwritingRequest caseUnderWrittingRequest, List<EnrollmentParticipant> enrollmentParticipants)
        {
            var stateIds = new List<StateTypeEnum>();

            if (caseUnderWrittingRequest.SitusType == SitusTypeEnum.Corporate)
            {
                if (caseUnderWrittingRequest.StateType != null)
                {
                    stateIds.Add((StateTypeEnum)caseUnderWrittingRequest.StateType);
                }
            }
            else if (caseUnderWrittingRequest.SitusType == SitusTypeEnum.Multi_State)
            {
                if (caseUnderWrittingRequest.StateType != null)
                {
                    stateIds.Add((StateTypeEnum)caseUnderWrittingRequest.StateType);
                }

                if (caseUnderWrittingRequest.SitusMultiState1Type != null)
                {
                    stateIds.Add((StateTypeEnum)caseUnderWrittingRequest.SitusMultiState1Type);
                }
                if (caseUnderWrittingRequest.SitusMultiState2Type != null)
                {
                    stateIds.Add((StateTypeEnum)caseUnderWrittingRequest.SitusMultiState2Type);
                }
                if (caseUnderWrittingRequest.SitusMultiState3Type != null)
                {
                    stateIds.Add((StateTypeEnum)caseUnderWrittingRequest.SitusMultiState3Type);
                }
            }
            else
            {
                stateIds = enrollmentParticipants.Where(c => c.Participant.HomeState != null).Select(c => (StateTypeEnum)c.Participant.HomeState).Distinct().ToList();
            }

            return stateIds;
        }

        private void ValidatePrimaryProducer(int caseId, List<string> errorMessages, IUnitOfWork unitOfWork, List<EnrollmentParticipant> enrollmentParticipants)
        {
            var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
            var caseUnderWrittingRequest = cmsCase.CaseUnderwritingRequests.FirstOrDefault();
            var stateIds = new List<StateTypeEnum>();
            if (caseUnderWrittingRequest != null)
            {
                stateIds = BuildStateIds(caseUnderWrittingRequest, enrollmentParticipants);
            }

            if (stateIds.Count > 0)
            {
                var caseBrokerStates = cmsCase.CaseBrokers.SelectMany(c => c.CaseBrokerStates).Where(c => c.IsPrimaryBrokerIndicator == true).ToList();

                List<StateTypeEnum> caseBrokerStateIds = caseBrokerStates.Select(c => (StateTypeEnum)c.StateType).ToList();
                List<StateTypeEnum> residenceCaseBrokerStateIds = new List<StateTypeEnum>();

                if (caseBrokerStates != null && caseBrokerStates.Count > 0)
                {
                    var brokerStates = new List<CaseBrokerState>();
                    if (stateIds.Count == 1)
                    {
                        brokerStates = caseBrokerStates.Where(s => s.StateType == stateIds.FirstOrDefault()).ToList();
                        if (brokerStates != null && brokerStates.Count == 0)
                        {
                            string brokerStatesError = string.Join(", ", stateIds.Select(c => c.GetCode()));
                            if (!string.IsNullOrEmpty(brokerStatesError))
                            {
                                errorMessages.Add("A valid producer is missing for the following states " + brokerStatesError);
                            }
                        }
                    }
                    else
                    {
                        foreach (var caseBrokerId in stateIds)
                        {
                            if (!caseBrokerStateIds.Contains(caseBrokerId))
                            {
                                residenceCaseBrokerStateIds.Add(caseBrokerId);
                            }
                        }
                        if (residenceCaseBrokerStateIds.Count > 0)
                        {
                            string brokerStatesError = string.Join(", ", residenceCaseBrokerStateIds.Select(c => c.GetCode()));
                            if (!string.IsNullOrEmpty(brokerStatesError))
                            {
                                errorMessages.Add("A valid producer is missing for the following states " + brokerStatesError);
                            }
                        }
                    }
                }
                else
                {
                    string participantsStatesError = string.Join(", ", stateIds.Select(c => c.GetCode()));
                    if (!string.IsNullOrEmpty(participantsStatesError))
                    {
                        errorMessages.Add("A valid producer is missing for the following states " + participantsStatesError);
                    }
                }
            }
        }

        private void ValidateHomeState(List<string> errorMessages, IEnumerable<Participant> participants)
        {
            var homestateMissedParticipnats = participants.Where(c => c.HomeState == null).ToList();

            if (homestateMissedParticipnats != null)
            {
                foreach (var p in homestateMissedParticipnats)
                {
                    errorMessages.Add("Home state is missing for participant " + p.LastName + " " + p.FirstName + " with participant ID " + p.EmployeeId);
                }
            }
        }

        private void ValidateAMBParticipants(List<string> errorMessages, IEnumerable<Participant> participants)
        {
            if (participants.Any())
            {
                var ambParticipants = participants.Where(c => c.IsAMBIncreaseIndicator != null && c.IsAMBIncreaseIndicator == true);

                if (ambParticipants.Any())
                {
                    errorMessages.Add("Negative Enrollment has been selected for AMB participants unable to run xml.");
                }
            }
        }
    }
}
