﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Glic.CudbapiclientNuget;
using Glic.CudbapiclientNuget.Models.Requests;
using Glic.CudbapiclientNuget.Models.Response;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using Newtonsoft.Json;
using NHibernate.Linq;
using Client = Glic.CudbapiclientNuget.Models.Requests.Client;
using ProductTypeEnum = Glic.CudbapiclientNuget.Models.Requests.ProductTypeEnum;
using Transaction = Glic.CudbapiclientNuget.Models.Requests.Transaction;

namespace CMS.Managers.ImplementationManangers
{
    public class CUDBManager : ICUDBManager, IWorkUnitHandler
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IConfiguration _configuration;
        private readonly string _apigeeOAuthTokenUrl;
        private readonly string _cudbApiBaseUrl;
        private readonly string _cudbUsername;
        private readonly string _cudbPassword;

        public CUDBManager(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager, IConfiguration configuration)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _workUnitManager = workUnitManager;
            _configuration = configuration;
            _apigeeOAuthTokenUrl = _configuration.ApigeeOAuthTokenUrl;
            _cudbApiBaseUrl = _configuration.CUDBApiBaseUrl;
            _cudbUsername = _configuration.CUDBCredentials.UserName;
            _cudbPassword = _configuration.CUDBCredentials.Password;
        }

        public void EnqueueRequest(string policyNumber, string eventType)
        {
            Log.Trace("+EnqueueRequest");

            var eDeliveryEventDto = new eDeliveryEventDto
            {
                PolicyNumber = policyNumber,
                EventType = eventType.ToLower()
            };

            _workUnitManager.CreateWorkUnit(WorkUnitType.CUDBRequest, JsonConvert.SerializeObject(eDeliveryEventDto));

            Log.Trace("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.Trace("+Execute");

            try
            {
                var request = JsonConvert.DeserializeObject<eDeliveryEventDto>(workUnit.InputData);

                if (request == null)
                {
                    Log.Error("CUDBManager work unit input is null!");
                    return;
                }
                
                if (request.EventType == "delivery_allsigned")
                {
                    MibDirDatabaseData data;
                    using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                    {
                        data = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq()
                            .Where(x => x.PolicyNumber == request.PolicyNumber)
                            .Fetch(x => x.EnrollmentParticipantOptionPlan)
                            .Fetch(x => x.EnrollmentParticipant)
                            .ThenFetch(x => x.Participant)
                            .Select(x => new MibDirDatabaseData
                            {
                                FirstName = x.EnrollmentParticipant.Participant.FirstName,
                                LastName = x.EnrollmentParticipant.Participant.LastName,
                                MiddleName = x.EnrollmentParticipant.Participant.MiddleInitial,
                                Suffix = x.EnrollmentParticipant.Participant.Suffix,
                                ParticipantSsn = x.EnrollmentParticipant.Participant.SocialSecurityNumber,
                                EnrollmentParticipantSsn = x.EnrollmentParticipant.SocialSecurityNumber,
                                Gender = x.EnrollmentParticipant.Participant.Gender,
                                DateOfBirth = x.EnrollmentParticipant.Participant.DateOfBirth,
                                ResidenceState = x.EnrollmentParticipant.Participant.HomeState != null ?
                                    Enum.GetName(typeof(StateTypeEnum), x.EnrollmentParticipant.Participant.HomeState) :
                                    null,
                                ResidenceZipCode = x.EnrollmentParticipant.Participant.HomeZipCode,
                                OccupationType = x.EnrollmentParticipant.Participant.Occupation,
                                PolicyNumber = x.PolicyNumber,
                                BenefitAmount = x.EnrollmentParticipantOptionPlan.BenefitAmountBaseMonthly  // or MonthlyBenefitAmount or TotalMonthlyBenefitAmount???? (AppEntry uses BenefitAmountBaseMonthly to code to CLOAS via the AppEntryController.GetCaseClasses(), so we'll use that for now)
                            })
                            .FirstOrDefault();

                        // Check if it's a One-Step Enrollment
                        if (data != null)
                        {
                            EnrollmentMethodType enrollmentMethodType = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq()
                                .Where(x => x.PolicyNumber == request.PolicyNumber)
                                .Fetch(x => x.EnrollmentParticipant)
                                .ThenFetch(x => x.Enrollment)
                                .Select(x => x.EnrollmentParticipant.Enrollment.EnrollmentMethodType)
                                .FirstOrDefault();
                            data.IsOneStepEnrollment = enrollmentMethodType != null && enrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.OneStep;
                        }
                    }

                    if (data != null)
                    {
                        var cudbRequest = CreateMibDirSubmissionRequest(data);
                        SendMibDirSubmissionRequest(cudbRequest);
                    }
                    else
                    {
                        Log.Warn($"EnrollmentParticipantPolicy record associated to policy number '{request.PolicyNumber}' cannot be found!");
                    }
                }
            }
            catch (Exception e)
            {
                Log.Error($"Exception occurred when calling CUDB for work unit {workUnit.Id}!", e);
            }

            Log.Trace("-Execute");
        }

        private MibDirSubmissionRequest CreateMibDirSubmissionRequest(MibDirDatabaseData data)
        {
            Log.Trace("+CreateMibDirSubmissionRequest");

            MibDirSubmissionRequest request = new MibDirSubmissionRequest
            {
                Transaction = new Transaction
                {
                    SourceSystem = "Titan",
                    LineOfBusiness = "IDI",
                    DistributionChannel = DistributionChannelTypeEnum.Intermediary    // pull this from the database somewhere? can it be different?
                },
                SelectedServices = new SelectedServices
                {
                    MibService = MibServiceTypeEnum.DIRS,
                    MibFollowUpIndicator = false
                },
                Client = new Client
                {
                    FirstName = data.FirstName,
                    LastName = data.LastName,
                    MiddleName = data.MiddleName,
                    Prefix = null,
                    Suffix = data.Suffix,
                    TaxId = data.IsOneStepEnrollment ? data.ParticipantSsn : data.EnrollmentParticipantSsn,     // if EnrollmentMethodType is 'one-step', then use Participant.SocialSecurityNumber, else use EnrollmentParticipant.SocialSecurityNumber
                    DateOfBirth = data.DateOfBirth,
                    ResidenceState = data.ResidenceState,
                    ResidenceCountry = !string.IsNullOrEmpty(data.ResidenceState) ? (ResidenceCountryEnum?)ResidenceCountryEnum.USA : null,
                    ResidenceZipCode = data.ResidenceZipCode,
                    OccupationType = data.OccupationType
                },
                ApplicationInfoType = new ApplicationInfoType
                {
                    TrackingId = data.PolicyNumber
                },
                Policy = new Policy
                {
                    PolicyNumber = data.PolicyNumber,
                    ProductType = ProductTypeEnum.DisabilityIncomeReplacementLongTerm,
                    PolicyStatus = PolicyStatusEnum.Active,
                    HoldingForm = HoldingFormEnum.GroupVoluntary
                },
                Coverage = new Coverage
                {
                    BenefitAmountMaximum = data.BenefitAmount,
                    BenefitMode = BenefitModeEnum.Monthly   // confirmed with Todd Hinds that all Titan policies have a 'Monthly' benefit mode
                }
            };

            // Calculated request values
            switch (data.Gender?.ToLower())
            {
                case "m":
                case "male":
                    request.Client.Gender = GenderTypeEnum.Male;
                    break;
                case "f":
                case "female":
                    request.Client.Gender = GenderTypeEnum.Female;
                    break;
                default:
                    request.Client.Gender = null;
                    break;
            }

            if (!string.IsNullOrEmpty(request.Client.TaxId))
                request.Client.GovernmentIdType = GovernmentIdTypeEnum.SSN; // not sure if Titan distinguishes between SSN and TIN

            Log.Trace("-CreateMibDirSubmissionRequest");

            return request;
        }

        private void SendMibDirSubmissionRequest(MibDirSubmissionRequest cudbRequest)
        {
            Log.Trace("+SendMibDirSubmissionRequest");

            try
            {
                var cudbApiClient = new CUDBApiClient(_cudbApiBaseUrl, _apigeeOAuthTokenUrl, _cudbUsername, _cudbPassword);

                UWDataResponse response = cudbApiClient.SubmitMibDirRecord(cudbRequest);

                if (response.OrderStatus == "SUCCESS")
                {
                    Log.Debug($"DIR record submission for policy '{cudbRequest.Policy.PolicyNumber}' to CUDB/CUW api succeeded. Transaction id: '{response.Transaction.TransactionReferenceGuid}', CUW order id: {response.UWData.OrderId}");
                }
                else if (response.OrderStatus == "FAILURE")
                {
                    Log.Error($"DIR record submission for policy '{cudbRequest.Policy.PolicyNumber}' to CUDB/CUW api failed! Transaction id: '{response.Transaction.TransactionReferenceGuid}'");

                    var rawMibXmlResponse = response.UWData.UWDataBlob;

                    try
                    {
                        // Attempt to reduce size of raw MIB xml response to log it

                        // Remove all '\n' characters and whitespace between tags
                        rawMibXmlResponse = Regex.Replace(rawMibXmlResponse, "\n([^<]*)", "");

                        // Remove top level XML standard tag (<?xml version="1.0" encoding="UTF-8" standalone="yes"?>) to reduce size
                        int indexOfFirstAcordTag = rawMibXmlResponse.IndexOf("<TXLife", StringComparison.InvariantCulture);
                        rawMibXmlResponse = rawMibXmlResponse.Substring(indexOfFirstAcordTag, rawMibXmlResponse.Length - indexOfFirstAcordTag);

                        // Response is around 1250 characters or longer depending on the amount of errors
                        Log.Error($"Raw MIB xml response: {rawMibXmlResponse}");
                    }
                    catch (Exception e)
                    {
                        Log.Error("Exception occurred attempting to log raw MIB xml response!", e);
                    }
                }
                else
                {
                    Log.Error($"CUDB/CUW api returned an unknown response of '{response.OrderStatus}' for transaction id '{cudbRequest.Transaction.TransactionReferenceGuid}'");
                }
            }
            catch (Exception e)
            {
                Log.Error($"Exception occurred during DIR record submission to CUDB/CUW api for policy '{cudbRequest.Policy.PolicyNumber}'!", e);
            }

            Log.Trace("-SendMibDirSubmissionRequest");
        }
    }

    public class MibDirDatabaseData
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string Suffix { get; set; }
        public string ParticipantSsn { get; set; }
        public string EnrollmentParticipantSsn { get; set; }
        public string Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string ResidenceState { get; set; }
        public string ResidenceZipCode { get; set; }
        public string OccupationType { get; set; }
        public bool IsOneStepEnrollment { get; set; }
        public string PolicyNumber { get; set; }
        public decimal? BenefitAmount { get; set; }
    }
}
