﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.ImplementationManangers
{
    public class PostEnrollmentManager : IWorkUnitHandler
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly ICaseManager _caseManager;
        public PostEnrollmentManager(IUnitOfWorkFactory unitOfWorkFactory, ICaseManager caseManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _caseManager = caseManager;
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.TraceFormat("+PostEnrollmentManager.Execute WU Id {0}", workUnit.Id);

            if (!string.IsNullOrEmpty(workUnit.InputData))
            {
                var enrollmentId = int.Parse(workUnit.InputData);

                if (enrollmentId > 0)
                {
                    using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                    {
                        var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(e => e.Id == enrollmentId);

                        var request = new CaseStatusDto
                        {
                            CaseId = enrollment.Case.Id,
                            CaseStatusType = CaseStatusTypeEnum.PostEnrollment,
                            PlanDesignRequestStatusType = null,
                        };

                        _caseManager.SaveCaseStatusAndPDRStatus(request);
                    }
                }
            }
            Log.TraceFormat("-PostEnrollmentManager.Execute");
        }
    }
}
