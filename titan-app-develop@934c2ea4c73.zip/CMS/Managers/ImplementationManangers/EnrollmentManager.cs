﻿using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CensusManagers;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Interfaces.Managers.TaskManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Common.Exceptions;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using static CMS.Interfaces.Managers.ImplementationManagers.EnrollmentDto;

namespace CMS.Managers.ImplementationManangers
{
    public class EnrollmentManager : IEnrollmentManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly EnrollmentManagerValidator _enrollmentManagerValidator;
        private readonly ITaskManager _taskManger;
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IBridgelineXmlGenerator _bridgelineXmlManager;
        private readonly IEnrollmentToolDocumentGenerator _enrollmentToolDocumentGenerator;
        private readonly IDocumentManager _documentManager;
        private readonly IProductLibraryManager _productLibraryManager;
        private readonly IConfiguration _configuration;

        public EnrollmentManager(
            IUnitOfWorkFactory unitOfWorkFactory,
            EnrollmentManagerValidator enrollmentManagerValidator,
            ITaskManager taskManger,
            IWorkUnitManager workUnitManager,
            IBridgelineXmlGenerator bridgelineXmlManager, IEnrollmentToolDocumentGenerator enrollmentToolDocumentGenerator,
            IDocumentManager documentManager, IProductLibraryManager productLibraryManager, IConfiguration configuration)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _enrollmentManagerValidator = enrollmentManagerValidator;
            _taskManger = taskManger;
            _workUnitManager = workUnitManager;
            _bridgelineXmlManager = bridgelineXmlManager;
            _enrollmentToolDocumentGenerator = enrollmentToolDocumentGenerator;
            _documentManager = documentManager;
            _productLibraryManager = productLibraryManager;
            _configuration = configuration;
        }

        public List<EnrollmentDto> GetEnrollmentDetails(int caseId, bool showAll)
        {
            Log.TraceFormat("+GetEnrollmentDetails");
            bool isBPDocumentValid = false;

            var enrollmentDtos = new List<EnrollmentDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                Expression<Func<Enrollment, bool>> showAllQuery = e => e.Case.Id == caseId;
                Expression<Func<Enrollment, bool>> excludeClosedEnrollmentQuery = e => e.EffectiveDate >= DateTime.Now;
                Expression<Func<Enrollment, bool>> excludeInactiveEnrollments = e => e.IsActive == null || e.IsActive == true;

                var predicate = PredicateBuilder.True<Enrollment>();

                predicate = predicate.And(showAllQuery);

                if (!showAll)
                {
                    predicate = predicate.And(excludeClosedEnrollmentQuery).And(excludeInactiveEnrollments);
                }

                var enrollments = unitOfWork.Repository<Enrollment>().LinqWithTimeOut().Where(predicate);
                var benefitPremiumDocument = unitOfWork.Repository<BenefitPremiumDocument>().Linq();
                var auditDataLog = unitOfWork.Repository<AuditDataLog>().Linq().Where(i => i.Case.Id == caseId);
                var census = unitOfWork.Repository<Census>().Linq().Where(i => i.Case.Id == caseId);

                var caseUnderwritingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().LinqWithTimeOut().Where(i => i.Case.Id == caseId).FirstOrDefault();


                if (enrollments.Any())
                {
                    foreach (var enrollmentitem in enrollments)
                    {
                        var enrollmentDtoItem = new EnrollmentDto();
                        var SelectedClassIds = enrollmentitem.Classes.Where(p => p.PlanDesignRequestClass != null).Select(p => p.PlanDesignRequestClass.Id).ToList();
                        if (SelectedClassIds.Count > 0)
                        {

                            var pdrSoldClasses = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => SelectedClassIds.Contains(c.PlanDesignRequestClass.Id) && c.IsActive);
                            if (pdrSoldClasses.Any())
                            {
                                enrollmentDtoItem.HasActiveSoldClass = true;
                            }
                            enrollmentDtoItem.CaseId = enrollmentitem.Case.Id;
                            enrollmentDtoItem.EnrollmentId = enrollmentitem.Id;
                            enrollmentDtoItem.IsActive = enrollmentitem.IsActive ?? true;
                            enrollmentDtoItem.SolicitationDeclinesTaskWorkUnitId = enrollmentitem.SolicitationDeclinesTaskWorkUnit != null ? enrollmentitem.SolicitationDeclinesTaskWorkUnit.Id : 0;
                            enrollmentDtoItem.EnrollmentName = enrollmentitem.EnrollmentName;
                            enrollmentDtoItem.EnrollmentStartDate = enrollmentitem.EnrollmentStartDate;
                            enrollmentDtoItem.EnrollmentEndDate = enrollmentitem.EnrollmentEndDate;
                            enrollmentDtoItem.ExtensionEndDate = enrollmentitem.ExtensionEndDate;
                            enrollmentDtoItem.EffectiveDate = enrollmentitem.EffectiveDate;
                            enrollmentDtoItem.IsAddOnIndicator = enrollmentitem.IsAddOnIndicator;
                            enrollmentDtoItem.EnrollmentMethodTypeId = enrollmentitem.EnrollmentMethodType.Id;
                            enrollmentDtoItem.SelectedClasses = enrollmentitem.Classes.Where(c => c.PlanDesignRequestClass != null).Select(c => c.PlanDesignRequestClass.Id).ToList();
                            enrollmentDtoItem.IsFullEnrollmentMilestones = enrollmentitem.IsFullEnrollmentMilestones;
                            enrollmentDtoItem.FriendlyName = enrollmentitem.FriendlyName;
                            enrollmentDtoItem.EnrollmentWebsite = enrollmentitem.EnrollmentWebsite;
                            enrollmentDtoItem.IsEDeliveryIndicator = enrollmentitem.IsEDeliveryIndicator;
                            enrollmentDtoItem.IsLiveChatIndicator = enrollmentitem.IsLiveChatIndicator;
                            enrollmentDtoItem.IsCourtesyCallsIndicator = enrollmentitem.IsCourtesyCallsIndicator;
                            enrollmentDtoItem.IsVoiceMailDropIndicator = enrollmentitem.IsVoiceMailDropIndicator;
                            enrollmentDtoItem.IsSuspendedToAutoCode = enrollmentitem.IsSuspendedToAutoCode;
                            enrollmentDtoItem.IsCallCenterOrIndividualReachOutIndicator = enrollmentitem.IsCallCenterOrIndividualReachOutIndicator;
                            if (enrollmentitem.PricingType == null)
                            {
                                enrollmentDtoItem.PricingTypeId = caseUnderwritingRequest.PricingType != null ? (int)caseUnderwritingRequest.PricingType : 0;
                                enrollmentDtoItem.hasEnrollmentProductType = false;
                            }
                            else
                            {
                                enrollmentDtoItem.PricingTypeId = enrollmentitem.PricingType != null ? (int?)enrollmentitem.PricingType : 0;
                                enrollmentDtoItem.hasEnrollmentProductType = true;
                            }
                            enrollmentDtos.Add(enrollmentDtoItem);
                        }
                    }

                    if (enrollmentDtos.Any())
                    {
                        foreach (var enrollmentDto in enrollmentDtos)
                        {
                            //Rule 1: If a B&P document has never been generated at all, prevent enrollment documents from being produced.
                            var benefitPremuimGenerated = benefitPremiumDocument.Where(c => c.Enrollment.Id == enrollmentDto.EnrollmentId && c.GeneratedDateTime != null).OrderByDescending(j => j.Id).FirstOrDefault();

                            isBPDocumentValid = benefitPremuimGenerated == null ? false : true;

                            //Rule 2: Case Enrollment Effective date has changed
                            if (isBPDocumentValid)
                            {
                                isBPDocumentValid = benefitPremuimGenerated.EffectiveDate == enrollmentDto.EffectiveDate ? true : false;
                            }

                            //Rule 3: If any field on the sold PDRs have been updated                       
                            if (isBPDocumentValid)
                            {
                                isBPDocumentValid = auditDataLog.Where(i => i.Case.Id == enrollmentDto.CaseId && i.RecordedDate > benefitPremuimGenerated.GeneratedDateTime
                                                                    && (i.EntityTypeName == "CMS.Model.Entities.PDRSoldClassPlan"
                                                                         || i.EntityTypeName == "CMS.Model.Entities.PDRSoldClass"
                                                                         || i.EntityTypeName == "CMS.Model.Entities.PDRSoldClassCompanyRetirementPlan"
                                                                         || i.EntityTypeName == "CMS.Model.Entities.PDRSoldClassLTDCoverage"
                                                                         || i.EntityTypeName == "CMS.Model.Entities.PDRSoldClassPlanCustomizedIDIInsurableIncome"
                                                                         || i.EntityTypeName == "CMS.Model.Entities.PDRSoldClassPlanRiders")).Count() == 0 ? true : false;
                            }

                            //Rule 4: Any changes on the Enrollment Options 1 2 or 3                         
                            if (isBPDocumentValid)
                            {
                                isBPDocumentValid = auditDataLog.Where(i => i.Case.Id == enrollmentDto.CaseId
                                                                         && i.RecordedDate > benefitPremuimGenerated.GeneratedDateTime
                                                                         && (i.EntityTypeName == "CMS.Model.Entities.EnrollmentPDRClassOption"
                                                                            || i.EntityTypeName == "CMS.Model.Entities.EnrollmentPDRClassOptionPlan"
                                                                            || i.EntityTypeName == "CMS.Model.Entities.EnrollmentPDRClassOptionPlanRider")).Count() == 0 ? true : false;
                            }

                            //Rule 5:A new census has been received and reconciled                           
                            if (isBPDocumentValid)
                            {
                                isBPDocumentValid = census.Where(c => c.ReceivedDateTime > benefitPremuimGenerated.GeneratedDateTime && c.IsActiveIndicator == true).Count() == 0 ? true : false;
                            }

                            //Rule 6:Billing mode changes      
                            if (isBPDocumentValid)
                            {
                                isBPDocumentValid = auditDataLog.Where(i => i.Case.Id == enrollmentDto.CaseId && i.RecordedDate > benefitPremuimGenerated.GeneratedDateTime && i.EntityTypeName == "CMS.Model.Entities.ListBillNumber" && i.PropertyName == "BillingModeType").Count() == 0 ? true : false;
                            }

                            //enrollmentDto.IsBenefitAndPremiumGenerated = isBPDocumentValid; //TODO: Commented Temporarily to enable the Enrollment Kit Buttons.
                            enrollmentDto.IsBenefitAndPremiumGenerated = true;
                        }
                    }
                }

                Log.TraceFormat("-GetEnrollmentDetails");

                return enrollmentDtos;
            }
        }

        public int GetPDRPricingType(int caseId)
        {
            Log.TraceFormat("+GetPDRPricingType");

            int pricingTypeId = 0;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseUnderwritingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().Where(i => i.Case.Id == caseId).FirstOrDefault();

                if (caseUnderwritingRequest != null)
                {
                    pricingTypeId = caseUnderwritingRequest.PricingType != null ? (int)caseUnderwritingRequest.PricingType : 0;
                }
            }

            Log.TraceFormat("-GetPDRPricingType");

            return pricingTypeId;
        }
        public bool IsCompactStateCase(int caseid)
        {
            return _productLibraryManager.IsCompactStateCase(caseid);
        }

        public ImplementationDto GetImplementationUserDetails(int caseId)
        {
            Log.TraceFormat("+GetEnrollmentDetails");

            ImplementationDto implementationDto = new ImplementationDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                if (cmsCase != null)
                {
                    implementationDto.ImplementationAnalystId = cmsCase.ImplementationAnalystId;
                    implementationDto.EnrollmentManagerId = cmsCase.EnrollmentManagerId;
                }

                Log.TraceFormat("-GetEnrollmentDetails");

                return implementationDto;

            }
        }
        public int SaveEnrollmentDetails(EnrollmentDto request)
        {
            Log.TraceFormat("+SaveEnrollmentDetails");          
            int enrollmentId = 0;
            _enrollmentManagerValidator.ValidateEnrollmentData(request);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var taskSLAType = unitOfWork.Repository<TaskSLAType>().Linq();
                var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == request.EnrollmentId);
                if (enrollment == null)
                {
                    enrollment = new Enrollment();

                    enrollment.Case = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);

                    var validatedMilestoneConfigurations = EnrollmentMilestoneSetupData(request);

                    var milestoneConfigurations = unitOfWork.Repository<EnrollmentMilestoneConfiguration>().Linq()
                        .Where(c => c.EnrollmentMethodType.Id == request.EnrollmentMethodTypeId && c.IsAddOnIndicator == request.IsAddOnIndicator)
                        .OrderBy(c => c.SortOrder)
                        .ToList();

                    CreateMilestoneAndAssignTasks(request, enrollment, milestoneConfigurations, validatedMilestoneConfigurations);

                    TimeSpan timeSpan = request.EffectiveDate.Value - DateTime.UtcNow;

                    var workUnitId = _workUnitManager.CreateWorkUnit(WorkUnitType.SolicitationDeclinesTask, request.EnrollmentId.ToString(), timeSpan);
                    request.SolicitationDeclinesTaskWorkUnitId = workUnitId;
                    enrollment.SolicitationDeclinesTaskWorkUnit = unitOfWork.Repository<WorkUnit>().Linq().FirstOrDefault(c => c.Id == workUnitId);

                    TimeSpan timeSpanEnrollmentStartDate = request.EnrollmentStartDate.Value - DateTime.UtcNow;
                    var enrollmentInProgressWorkUnitId = _workUnitManager.CreateWorkUnit(WorkUnitType.EnrollmentInProgress, request.EnrollmentId.ToString(), timeSpanEnrollmentStartDate);

                    TimeSpan timeSpanExtentionEndDate = request.ExtensionEndDate.Value.AddDays(1) - DateTime.UtcNow;
                    var postEnrollmentWorkUnitId = _workUnitManager.CreateWorkUnit(WorkUnitType.PostEnrollment, request.EnrollmentId.ToString(), timeSpanExtentionEndDate);

                    request.StartDateTaskWorkUnitId = enrollmentInProgressWorkUnitId;
                    request.ExtensionEndDateTaskWorkUnitId = postEnrollmentWorkUnitId;
                    enrollment.StartDateTaskWorkUnit = unitOfWork.Repository<WorkUnit>().Linq().FirstOrDefault(c => c.Id == enrollmentInProgressWorkUnitId);
                    enrollment.ExtensionEndDateTaskWorkUnit = unitOfWork.Repository<WorkUnit>().Linq().FirstOrDefault(c => c.Id == postEnrollmentWorkUnitId);
                }

				enrollment.EnrollmentName = request.EnrollmentName;

                enrollment.EnrollmentStartDate = request.EnrollmentStartDate.Value;
                enrollment.EnrollmentEndDate = DateTimeHelper.GetNormalizedDateTime(request.EnrollmentEndDate.Value);
                enrollment.ExtensionEndDate = DateTimeHelper.GetNormalizedDateTime(request.ExtensionEndDate.Value);
                enrollment.EffectiveDate = DateTimeHelper.GetNormalizedDateTime(request.EffectiveDate.Value);

                enrollment.IsAddOnIndicator = request.IsAddOnIndicator;
                enrollment.EnrollmentMethodType = unitOfWork.Repository<EnrollmentMethodType>().Linq().FirstOrDefault(c => c.Id == request.EnrollmentMethodTypeId);
                enrollment.IsFullEnrollmentMilestones = request.IsFullEnrollmentMilestones;
                enrollment.FriendlyName = request.FriendlyName;
                enrollment.EnrollmentWebsite = request.EnrollmentWebsite;
                enrollment.IsEDeliveryIndicator = request.IsEDeliveryIndicator;
                enrollment.IsLiveChatIndicator = request.IsLiveChatIndicator;
                enrollment.IsCourtesyCallsIndicator = request.IsCourtesyCallsIndicator;
                enrollment.IsCallCenterOrIndividualReachOutIndicator = request.IsCallCenterOrIndividualReachOutIndicator;
                enrollment.IsVoiceMailDropIndicator = request.IsVoiceMailDropIndicator;
                enrollment.IsSuspendedToAutoCode = request.IsSuspendedToAutoCode;


                enrollment.PricingType = request.PricingTypeId != null ? (PricingTypeEnum)request.PricingTypeId : PricingTypeEnum.PC2016;

                request.StartDateTaskWorkUnitId = request.StartDateTaskWorkUnitId.HasValue ? request.StartDateTaskWorkUnitId : (enrollment.StartDateTaskWorkUnit != null ? enrollment.StartDateTaskWorkUnit.Id : 0);
                request.ExtensionEndDateTaskWorkUnitId = request.ExtensionEndDateTaskWorkUnitId.HasValue ? request.ExtensionEndDateTaskWorkUnitId : (enrollment.ExtensionEndDateTaskWorkUnit != null ? enrollment.ExtensionEndDateTaskWorkUnit.Id : 0);

                if (request.IsAddOnIndicator)
                {
                    var selectedClass = unitOfWork.Repository<Participant>().Linq().Where(c => request.SelectedCensusParticipant.Contains(c.Id)).Select(c => c.PlanDesignRequestClass.Id).Distinct().ToList();
                    request.SelectedClasses = selectedClass;
                    SaveEnrollmentCensusParticipants(request, unitOfWork, enrollment);
                }

                var addedClasses = new List<int>();
                var deletedClasses = new List<int>();
                SaveEnrollmentPlanDesignRequestClasses(request, unitOfWork, enrollment, out addedClasses, out deletedClasses);

                unitOfWork.Repository<Enrollment>().Save(enrollment);

                if (!request.IsAddOnIndicator)
                {
                    if ((addedClasses != null && addedClasses.Count > 0) || (deletedClasses != null && deletedClasses.Count > 0))
                    {
                        SaveEnrolledCensusParticipants(enrollment.Id, addedClasses, deletedClasses, unitOfWork);
                    }
                }

                unitOfWork.Commit();

                enrollmentId = enrollment.Id;
            }
            request.EnrollmentId = enrollmentId;

            UpdateSolicitationDeclinesTaskWorkUnit(request);

            UpdateEnrollmentTaskWorkUnit(request);

            Log.TraceFormat("-SaveEnrollmentDetails");
            return enrollmentId;
        }

        public void UpdateSolicitationDeclinesTaskWorkUnit(EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+UpdateSolicitationDeclinesTaskWorkUnit");

            WorkUnitDto workUnitDto = new WorkUnitDto();
            workUnitDto.WorkUnitId = enrollmentDto.SolicitationDeclinesTaskWorkUnitId.HasValue ? enrollmentDto.SolicitationDeclinesTaskWorkUnitId.Value : 0;
            workUnitDto.StartDate = enrollmentDto.EffectiveDate;
            workUnitDto.HandlerName = WorkUnitType.SolicitationDeclinesTask.ToString();
            workUnitDto.InputData = enrollmentDto.EnrollmentId.ToString();
            _workUnitManager.UpdateWorkUnit(workUnitDto);

            Log.TraceFormat("-UpdateSolicitationDeclinesTaskWorkUnit");
        }

        private void CreateTasksEnrollmentEffectiveDateDifference(int caseId, int enrollmentId, IUnitOfWork unitOfWork)
        {

            var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == enrollmentId);

            var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => c.Enrollment.Id == enrollmentId);

            var dateComparision = (enrollment.EffectiveDate - enrollment.ExtensionEndDate).TotalDays <= 20;

            var isAnyParticipantHasBillingMethodNotEqualtoDirectBill = enrollmentParticipants.Where(ep => ep.Participant.ListBillNumber != null
                                                                    && ep.Participant.ListBillNumber.BillingMethodType != BillingMethodTypeEnum.DirectBill).Any();

            if (dateComparision && isAnyParticipantHasBillingMethodNotEqualtoDirectBill)
            {
                var listBillNumbers = enrollmentParticipants.Select(ep => ep.Participant.ListBillNumber)
                                    .Where(bn => bn != null && bn.BillingMethodType != BillingMethodTypeEnum.DirectBill).Distinct().ToList();

                var taskSLA = unitOfWork.Repository<TaskSLAType>().Linq();
                var taskSLAFor20DaysDifference = taskSLA.Where(i => i.ShortDescription == "20DaysDifference").FirstOrDefault();

                foreach (var listBillNumber in listBillNumbers)
                {
                    //var taskName = string.Format("There is 20 days or less between the Extension End Date and the Effective Date for {0} and {1}", enrollment.EnrollmentName, listBillNumber.BillNumber);
                    //_taskManger.CreateTask(caseId, taskName, UserGroup.Group_BillingSpecialist, null, TimeSpan.FromDays(10));

                    if (taskSLAFor20DaysDifference != null)
                    {
                        var taskName = string.Format(taskSLAFor20DaysDifference.TaskName, enrollment.EnrollmentName, listBillNumber.BillNumber);
                        _taskManger.CreateTask(caseId, taskName, UserGroup.Group_BillingSpecialist, null, taskSLAFor20DaysDifference.SLAInHours, taskSLAFor20DaysDifference.isSameDayResponseRequired);
                    }
                }
            }
        }

        private List<EnrollmentMilestone> EnrollmentMilestoneSetupData(EnrollmentDto request)
        {
            Log.TraceFormat("+EnrollmentMilestoneSetupAndValidatingData");
            var errorMessages = new List<string>();
            var enrollmentMilestones = new List<EnrollmentMilestone>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var milestoneConfigurations = unitOfWork.Repository<EnrollmentMilestoneConfiguration>().Linq().Where(c => c.EnrollmentMethodType.Id == request.EnrollmentMethodTypeId && c.IsAddOnIndicator == request.IsAddOnIndicator).OrderBy(c => c.SortOrder);

                foreach (var enrollmentMilestoneConfiguration in milestoneConfigurations)
                {
                    var milestone = new EnrollmentMilestone();
                    milestone.EnrollmentMilestoneName = enrollmentMilestoneConfiguration.MilestoneName;

                    switch (enrollmentMilestoneConfiguration.MilestoneName)
                    {
                        case "Promotional Period":
                            milestone.MilestoneDueDate = request.EnrollmentStartDate.Value.AddDays(-1);
                            enrollmentMilestones.Add(milestone);
                            break;
                        case "Enrollment Week 1":
                            milestone.MilestoneStartDate = request.EnrollmentStartDate;
                            milestone.MilestoneDueDate = request.EnrollmentStartDate.Value.AddDays(6);
                            milestone.MilestoneDueDate = milestone.MilestoneDueDate > request.EnrollmentEndDate ? request.EnrollmentEndDate : milestone.MilestoneDueDate;
                            enrollmentMilestones.Add(milestone);
                            break;
                        case "Enrollment Week 2":
                            milestone.MilestoneStartDate = request.EnrollmentStartDate.Value.AddDays(7);
                            milestone.MilestoneDueDate = request.EnrollmentStartDate.Value.AddDays(13);
                            milestone.MilestoneDueDate = milestone.MilestoneDueDate > request.EnrollmentEndDate ? request.EnrollmentEndDate : milestone.MilestoneDueDate;
                            enrollmentMilestones.Add(milestone);
                            break;
                        case "Enrollment Week 3":
                            if (request.EnrollmentEndDate > request.EnrollmentStartDate.Value.AddDays(13))
                            {
                                milestone.MilestoneStartDate = request.EnrollmentStartDate.Value.AddDays(14);
                                milestone.MilestoneDueDate = request.EnrollmentStartDate.Value.AddDays(20);
                                milestone.MilestoneDueDate = milestone.MilestoneDueDate > request.EnrollmentEndDate ? request.EnrollmentEndDate : milestone.MilestoneDueDate;
                                enrollmentMilestones.Add(milestone);
                            }
                            break;
                        case "Enrollment Week 4":
                            if ((request.EnrollmentEndDate.Value - request.EnrollmentStartDate.Value).TotalDays >= 25)
                            {
                                milestone.MilestoneStartDate = request.EnrollmentStartDate.Value.AddDays(21);
                                milestone.MilestoneDueDate = request.EnrollmentStartDate.Value.AddDays(25);
                                milestone.MilestoneDueDate = milestone.MilestoneDueDate > request.EnrollmentEndDate ? request.EnrollmentEndDate : milestone.MilestoneDueDate;
                                enrollmentMilestones.Add(milestone);
                            }
                            break;
                        case "Extension Week 1":
                            milestone.MilestoneStartDate = request.EnrollmentEndDate.Value.AddDays(1);
                            milestone.MilestoneDueDate = request.EnrollmentEndDate.Value.AddDays(7);
                            milestone.MilestoneDueDate = milestone.MilestoneDueDate > request.ExtensionEndDate ? request.ExtensionEndDate : milestone.MilestoneDueDate;
                            enrollmentMilestones.Add(milestone);
                            break;
                        case "Extension Week 2":
                            if ((request.ExtensionEndDate.Value - request.EnrollmentEndDate.Value.AddDays(1)).TotalDays >= 14)
                            {
                                milestone.MilestoneStartDate = request.EnrollmentEndDate.Value.AddDays(8);
                                milestone.MilestoneDueDate = request.ExtensionEndDate;
                                enrollmentMilestones.Add(milestone);
                            }
                            break;
                        case "Post Enrollment":
                            milestone.MilestoneStartDate = request.ExtensionEndDate.Value.AddDays(1);
                            enrollmentMilestones.Add(milestone);
                            break;
                        case "Enrollment Period":
                            milestone.MilestoneStartDate = request.EnrollmentStartDate;
                            milestone.MilestoneDueDate = request.ExtensionEndDate;
                            enrollmentMilestones.Add(milestone);
                            break;
                        case "Enrollment Review":
                            milestone.MilestoneStartDate = GetEnrollmentReviewMilestoneStartDateByCase(request.CaseId);
                            enrollmentMilestones.Add(milestone);
                            break;
                        default:
                            enrollmentMilestones.Add(milestone);
                            break;
                    }
                }
            }
            Log.TraceFormat("-EnrollmentMilestoneSetupAndValidatingData");
            if (errorMessages.Any()) throw new ValidationException(errorMessages);
            return enrollmentMilestones;
        }

        public void SaveImplementationUserDetails(ImplementationDto request)
        {
            Log.TraceFormat("+SaveImplementationUserDetails");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var implementationCaseDetails = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                if (implementationCaseDetails != null)
                {
                    implementationCaseDetails.ImplementationAnalystId = request.ImplementationAnalystId;
                    implementationCaseDetails.EnrollmentManagerId = request.EnrollmentManagerId;
                    _taskManger.UpdateTask(request.CaseId, request.EnrollmentManagerId, request.ImplementationAnalystId);
                    unitOfWork.Repository<Case>().Save(implementationCaseDetails);
                    unitOfWork.Commit();
                }
            }
            Log.TraceFormat("-SaveImplementationUserDetails");
        }

        public bool CheckFileContent(int caseDocumentId, int caseId)
        {
            Log.TraceFormat("+CheckFileContent");
            var contentExists = false;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var dbDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == caseDocumentId && c.Case_Id == caseId);
                if (dbDocument == null) throw new ApplicationException("Case document not found!");
                string filename = dbDocument.CaseDocumentRequest.RequestFileName?? dbDocument.CaseDocumentRequest.RequestFileName.ToString();


                var extreamUploaded = unitOfWork.Repository<WorkUnit>().Linq().OrderByDescending(q => q.Id).Where(c => c.InputData==dbDocument.CaseDocumentRequest.Id.ToString()
                                       && c.HandlerName.Equals("ExtreamFileUpload")).FirstOrDefault();

                if (extreamUploaded == null || extreamUploaded.Retries==5) throw new ValidationException("Document Failed to generate. Please try to generate it again");

                var retries = unitOfWork.Repository<WorkUnit>().Linq().Where(c => c.InputData.Equals(filename) 
                && c.HandlerName.Equals("ExtreamFileDownload")).Select(x => x.Retries).FirstOrDefault();

                
                contentExists = (dbDocument.FileNetDocumentId == null && dbDocument.FileBytes == null) ? false : true;
                if (!contentExists && retries < 5)
                {
                    throw new ValidationException("The document request has been submitted to Exstream, we are checking every 10 minutes for the output, we have tried "+retries+" out of 5 times so far. Please be patient while we the system continues checking");
                }
                else if (!contentExists && retries == 5)
                {
                    throw new ValidationException("Document Failed to generate. Please try to generate it again");
                }
            }
            Log.TraceFormat("-CheckFileContent");
            return contentExists;
        }


        public string GetSitusState(int caseId)
        {
            Log.TraceFormat("+GetSitusState");

            string situsState = null;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseUnderWrittingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == caseId);

                if (caseUnderWrittingRequest != null)
                {
                    situsState = caseUnderWrittingRequest.StateType != null ? caseUnderWrittingRequest.StateType.ToString() : null;
                }

                if (string.IsNullOrEmpty(situsState))
                    throw new Exception("SitusState not found!");
            }
            Log.TraceFormat("-GetSitusState");

            return situsState;
        }

        public string GetMldeJson(int enrollmentMldeStatusId)
        {
            Log.TraceFormat("+MldeJsonContent");

            string mldeJson;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                mldeJson = unitOfWork.Repository<EnrollmentMLDEStatus>().Linq()
                    .FirstOrDefault(c => c.Id == enrollmentMldeStatusId)
                    ?.MLDEJson;

                if (string.IsNullOrEmpty(mldeJson)) 
                    throw new Exception("MldeStatus Json not found!");
            }
            Log.TraceFormat("-MldeJsonContent");

            return mldeJson;
        }

        public List<EnrollmentCensusParticipantDto> GetEnrollmentParticipantInformationByCaseId(int caseId)
        {
            Log.TraceFormat("+GetEnrollmentParticipantInformationByCaseId");

            var existingAddonParticipantsDto = new List<EnrollmentCensusParticipantDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var existingAddonParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(ecp => ecp.Enrollment.IsAddOnIndicator && ecp.Enrollment.Case.Id == caseId);

                if (existingAddonParticipants.Any())
                {
                    existingAddonParticipantsDto = existingAddonParticipants.Select(t => new EnrollmentCensusParticipantDto
                    {
                        EnrollmentCensusParticipantId = t.Id,
                        CensusParticipantId = t.Participant.Id,
                        EmployeeId = t.Participant.EmployeeId,
                        FirstName = t.Participant.FirstName,
                        LastName = t.Participant.LastName,

                    }).ToList();
                }

                Log.TraceFormat("-GetEnrollmentParticipantInformationByCaseId");
                return existingAddonParticipantsDto;
            }
        }

        public List<CensusParticipantDto> GetAddOnCensusParticipantInformationByCaseId(int caseId)
        {
            Log.TraceFormat("+GetAddOnCensusParticipantInformationByCaseId");

            var validAddOnCensusParticipantsDto = new List<CensusParticipantDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pdrSoldClassIds = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Case.Id == caseId && c.IsActive
                                && c.PlanDesignRequestClass.IsActive).Select(c => c.PlanDesignRequestClass.Id).Distinct().ToList();
                Log.TraceFormat("Added LinqWithTimeOut in GetAddOnCensusParticipantInformationByCaseId function");
                var validAddOnCensusParticipants = unitOfWork.Repository<Participant>().LinqWithTimeOut().Where(p => p.Census.PlanDesignRequest.Case.Id == caseId
                                    && p.Census.PlanDesignRequest.IsActive
                                    && (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null) && p.IsActive == true
                                    && (p.PlanDesignRequestClass != null && pdrSoldClassIds.Contains(p.PlanDesignRequestClass.Id))
                                    && p.EnrollmentCensusParticipants.Count == 0);
                if (validAddOnCensusParticipants.Any())
                {
                    validAddOnCensusParticipantsDto = validAddOnCensusParticipants.Select(t => new CensusParticipantDto
                    {
                        CensusParticipantId = t.Id,
                        EmployeeId = t.EmployeeId,
                        FirstName = t.FirstName,
                        LastName = t.LastName,
                    }).ToList();
                }
            }

            Log.TraceFormat("-GetAddOnCensusParticipantInformationByCaseId");
            return validAddOnCensusParticipantsDto;
        }

        public List<EnrollmentMilestoneDto> GetEnrollmentMilestoneDetails(int enrollmentId)
        {
            var milestoneDto = new List<EnrollmentMilestoneDto>();
            Log.TraceFormat("+GetEnrollmentMilestoneDetails");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                //loaded all milestone to memory to get exact count of tasks
                var milestones = unitOfWork.Repository<EnrollmentMilestone>().Linq().Where(c => c.Enrollment.Id == enrollmentId).ToList();
                if (milestones.Any())
                {
                    milestoneDto = milestones.Select(t => new EnrollmentMilestoneDto
                    {
                        EnrollmentMilestoneId = t.Id,
                        EnrollmentId = t.Enrollment.Id,
                        EnrollmentMilestoneName = t.EnrollmentMilestoneName,
                        MilestoneStartDate = t.MilestoneStartDate,
                        MilestoneDueDate = t.MilestoneDueDate,
                        EnrollmentMilestoneTasks = (t.EnrollmentMilestoneTasks != null) ? t.EnrollmentMilestoneTasks.Select(p => new EnrollmentMilestoneTaskDto
                        {
                            EnrollmentMilestoneTaskId = p.Id,
                            EnrollmentMilestoneId = t.Id,
                            CmsTaskId = p.Task.Id,
                            IsCompleted = p.Task.IsCompletedIndicator,
                            CompletedDate = p.Task.CompletedDate
                        }).ToList() : null,
                    }).OrderBy(i => i.MilestoneStartDate).ThenBy(i => i.EnrollmentMilestoneName).ToList();
                }
            }
            Log.TraceFormat("-GetEnrollmentMilestoneDetails");
            return milestoneDto;
        }

        public List<EnrollmentMeetingDto> GetEnrollmentMeetingDetails(int enrollmentId)
        {
            var enrollmentMeetingDto = new List<EnrollmentMeetingDto>();
            Log.TraceFormat("+GetEnrollmentMeetingDetails");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentMeetings = unitOfWork.Repository<EnrollmentMeeting>().Linq().Where(c => c.Enrollment.Id == enrollmentId).ToList();
                if (enrollmentMeetings.Any())
                {
                    enrollmentMeetingDto = enrollmentMeetings.Select(i => new EnrollmentMeetingDto
                    {
                        EnrollmentMeetingId = i.Id,
                        EnrollmentId = i.Enrollment.Id,
                        MeetingDateTime = i.MeetingDateTime,
                        TimeZone = i.TimeZone,
                        Location = i.Location,
                        Room = i.Room,
                        PhoneOrOther = i.PhoneOrOther
                    }
                    ).OrderBy(j => j.MeetingDateTime).ToList();
                }
            }

            Log.TraceFormat("-GetEnrollmentMeetingDetails");
            return enrollmentMeetingDto;
        }

        public int SaveEnrollmentMilestone(EnrollmentMilestoneDto request)
        {
            Log.TraceFormat("+SaveEnrollmentMilestone");
            int enrollmentMilestoneId = 0;
            _enrollmentManagerValidator.ValidateEnrollmentMilestoneData(request);
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentMilestone = unitOfWork.Repository<EnrollmentMilestone>().Linq().FirstOrDefault(c => c.Id == request.EnrollmentMilestoneId);
                if (enrollmentMilestone == null)
                {
                    enrollmentMilestone = new EnrollmentMilestone();
                    enrollmentMilestone.Enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == request.EnrollmentId);
                }
                enrollmentMilestone.EnrollmentMilestoneName = request.EnrollmentMilestoneName;
                enrollmentMilestone.MilestoneStartDate = request.MilestoneStartDate;
                enrollmentMilestone.MilestoneDueDate = request.MilestoneDueDate;
                unitOfWork.Repository<EnrollmentMilestone>().Save(enrollmentMilestone);
                enrollmentMilestoneId = enrollmentMilestone.Id;
                unitOfWork.Commit();
            }
            Log.TraceFormat("-SaveEnrollmentMilestone");
            return enrollmentMilestoneId;
        }

        public EnrollmentDto GetEnrollmentOptionDetails(int enrollmentId)
        {
            var enrollmentDto = new EnrollmentDto();
            Log.TraceFormat("+GetEnrollmentOptionDetails");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == enrollmentId);
                if (enrollment != null)
                {
                    List<PlanDesignRequestClassDto> listofClasses = new List<PlanDesignRequestClassDto>();
                    enrollmentDto.EnrollmentId = enrollment.Id;
                    enrollmentDto.EffectiveDate = enrollment.EffectiveDate;
                    enrollmentDto.EnrollmentMethodTypeId = enrollment.EnrollmentMethodType.Id;
                    enrollmentDto.IsAttested = enrollment.IsAttested;
                    enrollmentDto.CaseId = enrollment.Case.Id;
                    if (enrollment.IsAddOnIndicator)
                    {
                        listofClasses = enrollment.CensusParticipants.Select(t => new PlanDesignRequestClassDto
                        {
                            PlanDesignRequestClassId = t.Participant.PlanDesignRequestClass.Id,
                            PlanDesignRequestId = t.Participant.PlanDesignRequestClass.PlanDesignRequest.Id,
                            PlanDesignRequestClassName = t.Participant.PlanDesignRequestClass.PlanDesignRequestClassName,
                            PlanDesignRequestHeaderName = t.Participant.PlanDesignRequestClass.PlanDesignRequest.GAPlanDesignRequestId != null ?
                                                          t.Participant.PlanDesignRequestClass.PlanDesignRequest.GAPlanDesignRequestId :
                                                          t.Participant.PlanDesignRequestClass.PlanDesignRequest.RequestHeaderName,
                            ApprovedEligiblePopulationText = t.Participant.PlanDesignRequestClass.ApprovedEligiblePopulationText,
                        }).GroupBy(c => c.PlanDesignRequestClassId, (key, c) => c.FirstOrDefault()).ToList();
                    }
                    else
                    {
                        listofClasses = enrollment.Classes.Where(c => c.PlanDesignRequestClass != null).Select(t => new PlanDesignRequestClassDto
                        {
                            PlanDesignRequestClassId = t.PlanDesignRequestClass.Id,
                            PlanDesignRequestId = t.PlanDesignRequestClass.PlanDesignRequest.Id,
                            PlanDesignRequestClassName = t.PlanDesignRequestClass.PlanDesignRequestClassName,
                            PlanDesignRequestHeaderName = t.PlanDesignRequestClass.PlanDesignRequest.GAPlanDesignRequestId != null ?
                                                          t.PlanDesignRequestClass.PlanDesignRequest.GAPlanDesignRequestId :
                                                          t.PlanDesignRequestClass.PlanDesignRequest.RequestHeaderName,
                            ApprovedEligiblePopulationText = t.PlanDesignRequestClass.ApprovedEligiblePopulationText,
                        }).ToList();
                    }
                    enrollmentDto.PlanDesignRequestClassDto = listofClasses;
                }
            }

            Log.TraceFormat("-GetEnrollmentOptionDetails");
            return enrollmentDto;
        }

        public EnrollmentDto GetEnrollmentOptionSoldClassDetails(int enrollmentId, int pdrClassId)
        {
            Log.TraceFormat("+GetEnrollmentOptionSoldClassDetails");
            var enrollmentDto = new EnrollmentDto();
            var enrollmentClassDto = new EnrollmentClassDto();
            enrollmentDto.EnrollmentId = enrollmentId;
            enrollmentDto.PlanDesignRequestClassId = pdrClassId;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignSoldRequestClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == pdrClassId && c.IsActive);

                if (planDesignSoldRequestClass != null)
                {
                    var enrollmentPDRClass = unitOfWork.Repository<EnrollmentPDRClass>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == planDesignSoldRequestClass.PlanDesignRequestClass.Id && c.Enrollment.Id == enrollmentId);
                    var enrollmentPDRClassOptions = enrollmentPDRClass.EnrollmentPDRClassOptions.ToList();
                    enrollmentClassDto.StandardPackageTypeId = enrollmentPDRClass.StandardPackageType != null ? (int?)enrollmentPDRClass.StandardPackageType.Id : null;
                    if (enrollmentPDRClassOptions.Any())
                    {
                        enrollmentClassDto.EnrollmentPDRClassOptionDtos = enrollmentPDRClassOptions.Select(t => new EnrollmentPDRClassOptionDto
                        {
                            EnrollmentPDRClassId = t.EnrollmentPDRClass.Id,
                            EnrollmentPDRClassOptionId = t.Id,
                            OptionCode = t.OptionCode,
                            IsSelected = t.IsSelected,
                            StandardOptionCodeNonSmoker = t.StandardOptionCodeNonSmoker,
                            StandardOptionCodeSmoker = t.StandardOptionCodeSmoker,
                            EnrollmentPDRClassOptionPlans = t.EnrollmentPDRClassOptionPlans.Select(c => new EnrollmentPDRClassOptionPlanDto
                            {
                                EnrollmentPDRClassOptionId = t.Id,
                                EnrollmentPDRClassOptionPlanId = c.Id,
                                BenefitPeriodTypeId = (int)c.BenefitPeriod,
                                PDRClassPlanTypeId = (int)c.PDRClassPlanType,
                                GSIPercentage = c.GSIPercentage,
                                CoveredEarningsTypeId = (int?)c.CoveredEarningsType,
                                CoveredEarningsBonusOnlyTypeId = (int?)c.CoveredEarningsBonusOnlyType,
                                ReplacementRatio = c.ReplacementRatio,
                                Discount = c.Discount,
                                EliminationPeriodTypeId = c.EliminationPeriod != null ? (int?)c.EliminationPeriod : null,
                                MinimumBenefitAmount = c.MinimumBenefitAmount,
                                DefinitionOfDisabilityTypeId = (int)c.DefinitionOfDisabilityType,
                                MentalSubstanceLimitationTypeId = (int)c.MentalSubstanceLimitationType,
                                PreExistingConditionLimitTypeId = (int)c.PreExistingConditionLimitType,
                                EnrollmentPDRClassOptionPlanRiders = c.EnrollmentPDRClassOptionPlanRiders.Select(pr => new EnrollmentPDRClassOptionPlanRiderDto
                                {
                                    BenefitGroupId = (int)pr.BenefitGroupType,
                                    EnrollmentPDRClassOptionPlanRiderId = pr.Id,
                                    EnrollmentPDRClassOptionPlanId = pr.EnrollmentPDRClassOptionPlan.Id,
                                    Amount = pr.Amount,
                                    BenefitTypeId = (int?)pr.BenefitType,
                                    BenefitPeriodId = (int?)pr.BenefitPeriodType,
                                    EliminationPeriodId = (int?)pr.EliminationPeriodType
                                }).ToList(),
                            }).ToList(),
                        }).ToList();
                    }

                    if (planDesignSoldRequestClass != null)
                    {
                        var primaryPlan = planDesignSoldRequestClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                        if (primaryPlan != null)
                        {
                            if (primaryPlan.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid ||
                                primaryPlan.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                            {
                                enrollmentClassDto.PremiumPayerAndTaxabilityTypeId = primaryPlan.PremiumPayerAndTaxabilityType.Id;
                                enrollmentClassDto.PrimaryGsiAmount = primaryPlan.GSIAmount;
                            }
                            else if (primaryPlan.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable ||
                                     primaryPlan.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable)
                            {
                                enrollmentClassDto.ISBuyUpPlan = false;
                                enrollmentClassDto.PremiumPayerAndTaxabilityTypeId = primaryPlan.PremiumPayerAndTaxabilityType.Id;
                                enrollmentClassDto.PrimaryGsiAmount = primaryPlan.GSIAmount;
                            }
                            EnrollmentClassPlanDto enrollmentClassPrimaryPlanDto = new EnrollmentClassPlanDto
                            {
                                PlanDesignTypeId = (int?)primaryPlan.PlanDesignType,
                                PDRClassPlanType = primaryPlan.PDRClassPlanType,
                                BenefitPeriodTypeId = (int?)primaryPlan.BenefitPeriod,
                                CoveredEarningsTypeId = (int?)primaryPlan.CoveredEarningsType,
                                CoveredEarningsBonusOnlyTypeId = (int?)primaryPlan.CoveredEarningsBonusOnlyType,
                                DefinitionOfDisabilityTypeId = (int)primaryPlan.DefinitionOfDisabilityType,
                                EliminationPeriodTypeId = (int?)primaryPlan.EliminationPeriod,
                                GSIAmount = primaryPlan.GSIAmount,
                                CoveredEarningsPercentage = 100,
                                MentalSubstanceLimitationTypeId = (int)primaryPlan.MentalSubstanceLimitationType,
                                BaseDiscountTypeId = (primaryPlan.BaseDiscountType != null) ? (int?)primaryPlan.BaseDiscountType.Id : null,
                                DemographicDiscountTypeId = primaryPlan.DemographicDiscountType != null ? (int?)primaryPlan.DemographicDiscountType.Id : null,


                                EmployerPaidDiscountTypeId = primaryPlan.EmployerPaidDiscountType != null ? (int?)primaryPlan.EmployerPaidDiscountType.Id : null,


                                PreExistingConditionLimitTypeId = (int)primaryPlan.PreExistingConditionLimitType,
                                MaximumReplacementRatio = primaryPlan.MaximumReplacementRatio,
                                EnrollmentClassPlanRiderDto = primaryPlan.PDRSoldClassPlanRiders.Select(t => new EnrollmentClassPlanRiderDto
                                {
                                    PDRSoldClassPlanRiderId = t.Id,
                                    PDRSoldClassPlanId = t.PDRSoldClassPlan.Id,
                                    ApprovedAmount = t.ApprovedAmount,
                                    BenefitTypeId = (int)t.BenefitType,
                                    BenefitGroupTypeId = (int)t.BenefitGroupType,
                                    BenefitPeriodTypeId = (int?)t.BenefitPeriodType,
                                    EliminationPeriodTypeId = (int?)t.EliminationPeriodType
                                }).ToList()
                            };

                            enrollmentClassDto.EnrollmentClassPlanDtos.Add(enrollmentClassPrimaryPlanDto);
                        }

                        var buyUpPlan = planDesignSoldRequestClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                        if (buyUpPlan != null)
                        {
                            enrollmentClassDto.ISBuyUpPlan = true;
                            enrollmentClassDto.VoluntaryGsiAmount = buyUpPlan.GSIAmount;
                            enrollmentClassDto.TotalMaxGSIAmount = buyUpPlan.TotalMaxGSIAmount;

                            EnrollmentClassPlanDto enrollmentClassBuyUpPlanDto = new EnrollmentClassPlanDto
                            {
                                PlanDesignTypeId = (int?)buyUpPlan.PlanDesignType,
                                PDRClassPlanType = buyUpPlan.PDRClassPlanType,
                                BenefitPeriodTypeId = (int?)buyUpPlan.BenefitPeriod,
                                CoveredEarningsTypeId = (int?)buyUpPlan.CoveredEarningsType,
                                CoveredEarningsBonusOnlyTypeId = (int?)buyUpPlan.CoveredEarningsBonusOnlyType,
                                DefinitionOfDisabilityTypeId = (int)buyUpPlan.DefinitionOfDisabilityType,
                                EliminationPeriodTypeId = (int?)buyUpPlan.EliminationPeriod,
                                GSIAmount = buyUpPlan.GSIAmount,
                                MentalSubstanceLimitationTypeId = (int)buyUpPlan.MentalSubstanceLimitationType,
                                BaseDiscountTypeId = (buyUpPlan.BaseDiscountType != null) ? (int?)buyUpPlan.BaseDiscountType.Id : null,
                                DemographicDiscountTypeId = buyUpPlan.DemographicDiscountType != null ? (int?)buyUpPlan.DemographicDiscountType.Id : null,

                                EmployerPaidDiscountTypeId = buyUpPlan.EmployerPaidDiscountType != null ? (int?)buyUpPlan.EmployerPaidDiscountType.Id : null,

                                CoveredEarningsPercentage = 100,
                                PreExistingConditionLimitTypeId = (int)buyUpPlan.PreExistingConditionLimitType,
                                MaximumReplacementRatio = buyUpPlan.ReplacementPercentage,
                                EnrollmentClassPlanRiderDto = buyUpPlan.PDRSoldClassPlanRiders.Select(t => new EnrollmentClassPlanRiderDto
                                {
                                    PDRSoldClassPlanRiderId = t.Id,
                                    PDRSoldClassPlanId = t.PDRSoldClassPlan.Id,
                                    ApprovedAmount = t.ApprovedAmount,
                                    BenefitTypeId = (int)t.BenefitType,
                                    BenefitGroupTypeId = (int)t.BenefitGroupType,
                                    BenefitPeriodTypeId = (int?)t.BenefitPeriodType,
                                    EliminationPeriodTypeId = (int?)t.EliminationPeriodType
                                }).ToList()
                            };
                            enrollmentClassDto.EnrollmentClassPlanDtos.Add(enrollmentClassBuyUpPlanDto);
                        }
                    }
                    enrollmentDto.EnrollmentClassDto = enrollmentClassDto;
                }
            }

            Log.TraceFormat("-GetEnrollmentOptionSoldClassDetails");
            return enrollmentDto;
        }

        public void SaveEnrollmentPDRClassOption(EnrollmentPDRClassDto request)
        {
            Log.TraceFormat("+SaveEnrollmentPDRClassOption");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentPDRClass = unitOfWork.Repository<EnrollmentPDRClass>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == request.PlanDesignRequestClassId && c.Enrollment.Id == request.EnrollmentId);
                var standardPackageTypes = unitOfWork.Repository<StandardPackageType>().Linq().ToList();

                if (enrollmentPDRClass == null) throw new ValidationException("Plandesign request class is not enrolled!");

                _enrollmentManagerValidator.ValidateEnrollmentOptionRequest(request);

                if (request.EnrollmentPDRClassOptions != null)
                {
                    SaveEnrollmentOptionAndPlans(request, unitOfWork, enrollmentPDRClass);

                    var standardPackageType = standardPackageTypes.FirstOrDefault(c => c.Id == request.StandardPackageTypeId);

                    enrollmentPDRClass.StandardPackageType = standardPackageType;

                    unitOfWork.Repository<EnrollmentPDRClass>().Save(enrollmentPDRClass);
                    unitOfWork.Commit();
                }
            }

            Log.TraceFormat("-SaveEnrollmentPDRClassOption");
        }

        public StandardPackageConfigurationDto GetStandardPackageConfigration(int standardPackageTypeId)
        {
            Log.TraceFormat("+GetStandardPackageConfigration");
            var standardPackageConfigurationDto = new StandardPackageConfigurationDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var standardPackageOptions = unitOfWork.Repository<StandardPackageOption>().Linq().Where(po => po.StandardPackageType.Id == standardPackageTypeId);
                standardPackageConfigurationDto.StandardPackageTypeId = standardPackageTypeId;
                if (standardPackageOptions.Any())
                {
                    standardPackageConfigurationDto.StandardPackageOptions = standardPackageOptions.Select(t => new StandardPackageOptionDto
                    {
                        StandardPackageOption_Id = t.Id,
                        GSIPercentage = t.GSIPercentage,
                        OptionNumber = t.OptionNumber,
                        StandardPackageOptionRiders = t.StandardPackageOptionRiders.Select(r => new StandardPackageOptionRiderDto
                        {
                            BenefitGroup_Id = r.BenefitGroup_Id,
                            IsRequired = r.IsRequired == 0 ? false : true,
                            StandardPackageOptionRider_Id = r.StandardPackageOptionRider_Id,
                            StandardPackageOption_Id = r.standardPackageOption.Id
                        }).ToList()
                    }).ToList();
                }

            }
            Log.TraceFormat("-GetStandardPackageConfigration");
            return standardPackageConfigurationDto;
        }

        public List<BenefitPremiumDocumentDto> GetBenefitPremiumDocuments(int enrollmentId)
        {
            Log.TraceFormat("+GetBenefitPremiumDocuments", enrollmentId);
            var BenefitPremiumDocumentDtos = new List<BenefitPremiumDocumentDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var benefitPremiumDocument = unitOfWork.Repository<BenefitPremiumDocument>().Linq().Where(c => c.Enrollment.Id == enrollmentId
                && (c.PdfDocument != null ? c.PdfDocument.IsDeleted == false : true)).ToList();

                if (benefitPremiumDocument.Any())
                {
                    BenefitPremiumDocumentDtos = benefitPremiumDocument.Select(x => new BenefitPremiumDocumentDto
                    {
                        BenefitPremiumDocumentId = x.Id,
                        EnrollmentId = x.Enrollment.Id,
                        ApprovedBy = x.ApprovedBy,
                        ApprovedDateTime = x.ApprovedDateTime,
                        BenefitPremiumDocumentStatusTypeId = x.BenefitPremiumDocumentStatusType != null ? (int?)x.BenefitPremiumDocumentStatusType : null,
                        BenefitPremiumName = x.BenefitPremiumName,
                        EffectiveDate = x.EffectiveDate,
                        ExcelDocumentId = x.ExcelDocument != null ? (int?)x.ExcelDocument.Id : null,
                        PdfDocumentId = x.PdfDocument != null ? (int?)x.PdfDocument.Id : null,
                        GeneratedBy = x.GeneratedBy,
                        GeneratedDateTime = x.GeneratedDateTime,
                        IsActiveIndicator = x.IsActiveIndicator,
                    }).ToList();
                }
            }
            Log.TraceFormat("-GetBenefitPremiumDocuments", enrollmentId);

            return BenefitPremiumDocumentDtos;

        }
        public List<EnrollmentToolDto> GetEnrollmentToolDocuments(int enrollmentId)
        {
            Log.TraceFormat("+GetEnrollmentToolDocuments", enrollmentId);
            var enrollmentToolDtos = new List<EnrollmentToolDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentToolDocument = unitOfWork.Repository<EnrollmentTool>().Linq().Where(c => c.Enrollment.Id == enrollmentId && (c.PdfDocument != null ? c.PdfDocument.IsDeleted == false : true));
                if (enrollmentToolDocument.Any())
                {
                    enrollmentToolDtos = enrollmentToolDocument.Select(enrollmentToolDto => new EnrollmentToolDto
                    {
                        EnrollmentToolDocumentId = enrollmentToolDto.Id,
                        EnrollmentId = enrollmentToolDto.Enrollment.Id,
                        EnrollmentToolName = enrollmentToolDto.EnrollmentToolName,
                        GeneratedDateTime = enrollmentToolDto.GeneratedDateTime,
                        GeneratedBy = enrollmentToolDto.GeneratedBy,
                        EffectiveDate = enrollmentToolDto.EffectiveDate,
                        PdfDocumentId = enrollmentToolDto.PdfDocument != null ? enrollmentToolDto.PdfDocument.Id : (long?)null,
                        ExcelDocumentId = enrollmentToolDto.ExcelDocument != null ? enrollmentToolDto.ExcelDocument.Id : (long?)null,
                        IsActiveIndicator = enrollmentToolDto.IsActiveIndicator

                    }).ToList();
                }
            }
            Log.TraceFormat("-GetEnrollmentToolDocuments", enrollmentId);

            return enrollmentToolDtos;

        }

        public EnrollmentOutputDto GetEnrollmentOutputDetails(int enrollmentId)
        {
            Log.TraceFormat("+GetEnrollmentOutputDetails");
            EnrollmentOutputDto enrollmentOutputDto = null;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentOutput = unitOfWork.Repository<EnrollmentOutput>().Linq().FirstOrDefault(eo => eo.Enrollment.Id == enrollmentId);
                if (enrollmentOutput != null)
                {
                    enrollmentOutputDto = new EnrollmentOutputDto();
                    enrollmentOutputDto.EnrollmentOutputId = enrollmentOutput.Id;
                    enrollmentOutputDto.EnrollmentId = enrollmentOutput.Enrollment.Id;
                    enrollmentOutputDto.CompanyFriendlyName = enrollmentOutput.CompanyFriendlyName;
                    enrollmentOutputDto.IsOmitPageNumbers = enrollmentOutput.IsOmitPageNumbers;
                    enrollmentOutputDto.IsIncludeGLTDDefinition = enrollmentOutput.IsIncludeGLTDDefinition;
                    enrollmentOutputDto.IsIncludeGLTDTaxabilityLanguage = enrollmentOutput.IsIncludeGLTDTaxabilityLanguage;
                    enrollmentOutputDto.ReturnContactAddressId = enrollmentOutput.ReturnAddress != null ? (int?)enrollmentOutput.ReturnAddress.Id : null;
                    enrollmentOutputDto.IsCoverLetterIncluded = enrollmentOutput.IsCoverLetterIncluded;
                    enrollmentOutputDto.SalutationTypeId = enrollmentOutput.EnrollmentOutputSalutationType != null ? (int?)enrollmentOutput.EnrollmentOutputSalutationType.Id : null;
                    enrollmentOutputDto.SalutationText = enrollmentOutput.SalutationText;
                    enrollmentOutputDto.IsShowReplacementPercentage = enrollmentOutput.IsShowReplacementPercentage;
                    enrollmentOutputDto.AlternateReplacementPercentText = enrollmentOutput.AlternateReplacementPercentText;
                    enrollmentOutputDto.EmployeeTypeId = enrollmentOutput.EnrollmentOutputEmployeeType != null ? (int?)enrollmentOutput.EnrollmentOutputEmployeeType.Id : null;
                    enrollmentOutputDto.CustomEmployeeTypeText = enrollmentOutput.CustomEmployeeTypeText;
                    enrollmentOutputDto.IsCompanyLetterhead = enrollmentOutput.IsCompanyLetterhead;
                    enrollmentOutputDto.IsCompanyLogo = enrollmentOutput.IsCompanyLogo;
                    enrollmentOutputDto.IsSignature = enrollmentOutput.IsSignature;
                    enrollmentOutputDto.ApplicationReturnInstructions = enrollmentOutput.ApplicationReturnInstructions;
                    enrollmentOutputDto.ContactAddressOneId = enrollmentOutput.ContactOne != null ? (int?)enrollmentOutput.ContactOne.Id : null;
                    enrollmentOutputDto.ContactAddressTwoId = enrollmentOutput.ContactTwo != null ? (int?)enrollmentOutput.ContactTwo.Id : null;
                    enrollmentOutputDto.EnrollmentOutputIncomeDefinitionTypeId = enrollmentOutput.EnrollmentOutputIncomeDefinitionType != null ? (int?)enrollmentOutput.EnrollmentOutputIncomeDefinitionType : null;
                    enrollmentOutputDto.OtherIncomeDefinitionText = enrollmentOutput.OtherIncomeDefinitionText;
                    enrollmentOutputDto.EnrollmentOutputShowTypeId = enrollmentOutput.EnrollmentOutputShowType != null ? (int?)enrollmentOutput.EnrollmentOutputShowType : null;
                    enrollmentOutputDto.TaxRatePercentage = enrollmentOutput.TaxRatePercentage;
                    enrollmentOutputDto.EnrollmentOutputIncomeDisplayTypeId = enrollmentOutput.EnrollmentOutputIncomeDisplayType != null ? (int?)enrollmentOutput.EnrollmentOutputIncomeDisplayType.Id : null;
                    enrollmentOutputDto.EnrollmentOutputPremiumDisplayTypeId = enrollmentOutput.EnrollmentOutputPremiumDisplayType != null ? (int?)enrollmentOutput.EnrollmentOutputPremiumDisplayType.Id : null;
                    enrollmentOutputDto.IsDOB = enrollmentOutput.IsDOB;
                    enrollmentOutputDto.IsSSN = enrollmentOutput.IsSSN;
                    enrollmentOutputDto.IsCompensation = enrollmentOutput.IsCompensation;
                    enrollmentOutputDto.ResponseRequiredText = enrollmentOutput.ResponseRequiredText;
                    enrollmentOutputDto.IsPrepaidEnvelope = enrollmentOutput.IsPrepaidEnvelope;
                    enrollmentOutputDto.HRContactId = enrollmentOutput.HRContact != null ? (int?)enrollmentOutput.HRContact.Id : null;
                    enrollmentOutputDto.Passcode = enrollmentOutput.Enrollment?.Passcode;
                    enrollmentOutputDto.IsBridgeLineDocumentSent = IsBridgelineXmlDocumentSent(enrollmentId);
                }
            }
            Log.TraceFormat("-GetEnrollmentOutputDetails");
            return enrollmentOutputDto;
        }

        public void SaveEnrollmentOutputDetails(EnrollmentOutputDto request)
        {
            Log.TraceFormat("+SaveEnrollmentOutputDetails");
            _enrollmentManagerValidator.ValidateTaxRateDefault(request);
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentOutput = unitOfWork.Repository<EnrollmentOutput>().Linq().FirstOrDefault(eo => eo.Enrollment.Id == request.EnrollmentId);
                if (enrollmentOutput == null)
                {
                    enrollmentOutput = new EnrollmentOutput();
                    enrollmentOutput.Enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(e => e.Id == request.EnrollmentId);
                }
                enrollmentOutput.CompanyFriendlyName = request.CompanyFriendlyName;
                enrollmentOutput.IsOmitPageNumbers = request.IsOmitPageNumbers;
                enrollmentOutput.IsIncludeGLTDDefinition = request.IsIncludeGLTDDefinition;
                enrollmentOutput.IsIncludeGLTDTaxabilityLanguage = request.IsIncludeGLTDTaxabilityLanguage;
                enrollmentOutput.ReturnAddress = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(a => a.Id == request.ReturnContactAddressId);
                enrollmentOutput.IsCoverLetterIncluded = request.IsCoverLetterIncluded;
                enrollmentOutput.EnrollmentOutputSalutationType = unitOfWork.Repository<EnrollmentOutputSalutationType>().Linq().FirstOrDefault(a => a.Id == request.SalutationTypeId);
                enrollmentOutput.SalutationText = request.SalutationText;
                enrollmentOutput.IsShowReplacementPercentage = request.IsShowReplacementPercentage;
                enrollmentOutput.AlternateReplacementPercentText = request.AlternateReplacementPercentText;
                enrollmentOutput.EnrollmentOutputEmployeeType = unitOfWork.Repository<EnrollmentOutputEmployeeType>().Linq().FirstOrDefault(a => a.Id == request.EmployeeTypeId);
                enrollmentOutput.CustomEmployeeTypeText = request.CustomEmployeeTypeText;
                enrollmentOutput.IsCompanyLetterhead = request.IsCompanyLetterhead;
                enrollmentOutput.IsCompanyLogo = request.IsCompanyLogo;
                enrollmentOutput.IsSignature = request.IsSignature;
                enrollmentOutput.ApplicationReturnInstructions = request.ApplicationReturnInstructions;
                enrollmentOutput.ContactOne = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(a => a.Id == request.ContactAddressOneId);
                enrollmentOutput.ContactTwo = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(a => a.Id == request.ContactAddressTwoId);
                enrollmentOutput.EnrollmentOutputIncomeDefinitionType = (EnrollmentOutputIncomeDefinitionTypeEnum?)request.EnrollmentOutputIncomeDefinitionTypeId;
                enrollmentOutput.OtherIncomeDefinitionText = request.OtherIncomeDefinitionText;
                enrollmentOutput.EnrollmentOutputShowType = (EnrollmentOutputShowTypeEnum?)request.EnrollmentOutputShowTypeId;
                enrollmentOutput.TaxRatePercentage = request.TaxRatePercentage;
                enrollmentOutput.EnrollmentOutputIncomeDisplayType = unitOfWork.Repository<EnrollmentOutputIncomeDisplayType>().Linq().FirstOrDefault(a => a.Id == request.EnrollmentOutputIncomeDisplayTypeId);
                enrollmentOutput.EnrollmentOutputPremiumDisplayType = unitOfWork.Repository<EnrollmentOutputPremiumDisplayType>().Linq().FirstOrDefault(a => a.Id == request.EnrollmentOutputPremiumDisplayTypeId);
                enrollmentOutput.IsDOB = request.IsDOB;
                enrollmentOutput.IsSSN = request.IsSSN;
                enrollmentOutput.IsCompensation = request.IsCompensation;
                enrollmentOutput.ResponseRequiredText = request.ResponseRequiredText;
                enrollmentOutput.IsPrepaidEnvelope = request.IsPrepaidEnvelope;
                enrollmentOutput.HRContact = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(a => a.Id == request.HRContactId);
                enrollmentOutput.Enrollment.Passcode = request.Passcode;

                unitOfWork.Repository<EnrollmentOutput>().Save(enrollmentOutput);
                unitOfWork.Commit();
            }
            Log.TraceFormat("-SaveEnrollmentOutputDetails");
        }

        private void CreateMilestoneAndAssignTasks(EnrollmentDto request, Enrollment enrollment, List<EnrollmentMilestoneConfiguration> milestoneConfigurations, List<EnrollmentMilestone> enrollmentMilestones)
        {
            Log.TraceFormat("+CreateMilestoneAndAssignTasks");
			//var tasks = CreateTasks(request.CaseId, milestoneConfigurations);

			foreach (var enrollmentMilestone in enrollmentMilestones)
			{
				var enrollmentMilestoneConfiguration = milestoneConfigurations.FirstOrDefault(c => c.MilestoneName == enrollmentMilestone.EnrollmentMilestoneName);
				enrollmentMilestone.Enrollment = enrollment;
				foreach (var task in enrollmentMilestoneConfiguration.EnrollmentMilestoneTaskConfigurations)
				{
					foreach (var userGroup in task.UserGroups)
					{
						var milestoneTask = new EnrollmentMilestoneTask();
						milestoneTask.EnrollmentMilestone = enrollmentMilestone;
						//milestoneTask.Task = tasks.FirstOrDefault(c => c.TaskName == task.TaskName.Trim() && c.AssignedToUserGroup.Id == userGroup.UserGroup.Id);
						//enrollmentMilestone.EnrollmentMilestoneTasks.Add(milestoneTask);
					}
				}
				enrollment.EnrollmentMilestones.Add(enrollmentMilestone);
			}
			Log.TraceFormat("-CreateMilestoneAndAssignTasks");
        }

        private List<CmsTask> CreateTasks(int caseId, List<EnrollmentMilestoneConfiguration> enrollmentMilestoneConfigurations)
        {
            var tasks = new List<CmsTask>();
            Log.TraceFormat("+CreateTasks");

			foreach (var enrollmentMilestoneConfiguration in enrollmentMilestoneConfigurations)
			{
				foreach (var task in enrollmentMilestoneConfiguration.EnrollmentMilestoneTaskConfigurations)
				{
					foreach (var userGroup in task.UserGroups)
					{
						var cmsTask = new CmsTask();
						var assignedUserId = (userGroup.UserGroup.Id == UserGroup.Group_Underwriting) ? _taskManger.GetAssignedUserId(caseId) : null;
						cmsTask = _taskManger.SaveTask(caseId, task.TaskName.Trim(), userGroup.UserGroup.Id, assignedUserId, task.TaskSLAInHours, false);
						tasks.Add(cmsTask);
					}
				}
			}

			Log.TraceFormat("-CreateTasks");
            return tasks;
        }

        private void SaveEnrollmentCensusParticipants(EnrollmentDto request, IUnitOfWork unitOfWork, Enrollment enrollment)
        {
            Log.TraceFormat("+SaveEnrollmentCensusParticipants");

            var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => c.Enrollment.Id == enrollment.Id).ToList();
            var existingParticipants = enrollmentParticipants.Select(c => c.Participant.Id).ToList();
            var newAndExistingParticipants = request.SelectedCensusParticipant;
            var newParticipants = newAndExistingParticipants.Where(n => !existingParticipants.Contains(n));
            var censusParticipants = unitOfWork.Repository<Participant>().Linq().Where(c => newParticipants.Contains(c.Id));

            AddCensusParticipantsToEnrollment(enrollment, censusParticipants);

            var deletedParticipants = enrollmentParticipants.Where(l => !newAndExistingParticipants.Contains(l.Participant.Id)).ToList();
            foreach (var deletedParticipant in deletedParticipants)
            {
                enrollment.CensusParticipants.Remove(deletedParticipant);
            }

            Log.TraceFormat("-SaveEnrollmentCensusParticipants");
        }

        private void SaveEnrollmentPlanDesignRequestClasses(EnrollmentDto request, IUnitOfWork unitOfWork, Enrollment enrollment, out List<int> addedClassIds, out List<int> deletedClassIds)
        {
            Log.TraceFormat("+SaveEnrollmentPlanDesignRequestClasses");
            var newlyAddedClassIds = request.SelectedClasses;
            deletedClassIds = new List<int>();
            if (enrollment.Classes.Any())
            {
                var existingClassIds = enrollment.Classes.Select(enPdrC => enPdrC.PlanDesignRequestClass.Id).ToList();
                var removedClassIds = existingClassIds.Where(exc => !request.SelectedClasses.Contains(exc));
                deletedClassIds = removedClassIds.ToList();

                foreach (var removedClassId in removedClassIds)
                {
                    enrollment.Classes.Remove(enrollment.Classes.FirstOrDefault(c => c.Enrollment.Id == enrollment.Id && c.PlanDesignRequestClass.Id == removedClassId));
                }

                var remainingClassIds = existingClassIds.Where(exc => request.SelectedClasses.Contains(exc));

                foreach (var remainingClassId in remainingClassIds)
                {
                    newlyAddedClassIds.Remove(remainingClassId);
                }
            }
            AddPdrClassesToEnrollment(unitOfWork, enrollment, newlyAddedClassIds);
            addedClassIds = newlyAddedClassIds.ToList();

            Log.TraceFormat("-SaveEnrollmentPlanDesignRequestClasses");
        }

        private void AddPdrClassesToEnrollment(IUnitOfWork unitOfWork, Enrollment enrollment, List<int> newlyAddedClassIds)
        {
            Log.TraceFormat("+AddPdrClassesToEnrollment");

            var planDesignRequestClasses = unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => newlyAddedClassIds.Contains(c.Id));
            foreach (var classId in newlyAddedClassIds)
            {
                var pdrClass = planDesignRequestClasses.FirstOrDefault(c => c.Id == classId);
                var enrollmentPdrClass = new EnrollmentPDRClass();
                enrollmentPdrClass.PlanDesignRequestClass = pdrClass;
                enrollmentPdrClass.Enrollment = enrollment;
                enrollment.Classes.Add(enrollmentPdrClass);
            }

            Log.TraceFormat("-AddPdrClassesToEnrollment");
        }

        private void AddCensusParticipantsToEnrollment(Enrollment enrollment, IQueryable<Participant> censusParticipants)
        {
            Log.TraceFormat("+AddCensusParticipantsToEnrollment");

            foreach (var participant in censusParticipants)
            {
                var enrolledParticipant = new EnrollmentParticipant();
                enrolledParticipant.Enrollment = enrollment;
                enrolledParticipant.Participant = participant;
                enrollment.CensusParticipants.Add(enrolledParticipant);
            }

            Log.TraceFormat("-AddCensusParticipantsToEnrollment");
        }

        private void SaveEnrolledCensusParticipants(int enrollmentId, List<int> addedClasses, List<int> deletedClasses, IUnitOfWork unitOfWork)
        {
            Log.TraceFormat(String.Format("+SaveEnrolledCensusParticipants, EnrollmentId: {0} AddClassCount: {1} DeleteClassCount: {2}", enrollmentId, addedClasses.Count(), deletedClasses.Count()));

            object[] parameters = new object[3];
            parameters[0] = enrollmentId;
            parameters[1] = string.Join(",", addedClasses.Select(c => c));
            parameters[2] = string.Join(",", deletedClasses.Select(c => c));

            unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_AddEnrollmentCensusParticipant] :@EnrollmentId, :@AddedClasses, :@DeletedClasses", parameters);

            Log.TraceFormat("-SaveEnrolledCensusParticipants");
        }
        private void SaveEnrollmentOptionAndPlans(EnrollmentPDRClassDto request, IUnitOfWork unitOfWork, EnrollmentPDRClass enrollmentPDRClass)
        {
            Log.TraceFormat("+SaveEnrollmentOptionAndPlans");

            var enrollmentPDRClassOptions = unitOfWork.Repository<EnrollmentPDRClassOption>().Linq().Where(c => c.EnrollmentPDRClass.Id == enrollmentPDRClass.Id);
            var pdrSoldClass = unitOfWork.Repository<PDRSoldClassPlan>().Linq();
            var pdrSoldClassforPrimary = pdrSoldClass.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary && c.PDRSoldClass.PlanDesignRequestClass.Id == enrollmentPDRClass.PlanDesignRequestClass.Id);
            var pdrSoldClassforVoluntary = pdrSoldClass.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp && c.PDRSoldClass.PlanDesignRequestClass.Id == enrollmentPDRClass.PlanDesignRequestClass.Id);

            //TODO : Below linq, unique record to be retrieved, business to answer this. For now getting top row to assign XMLOfferType string to both Standard Options.
            var standardOfferCodeConfiguration = unitOfWork.Repository<StandardOfferCodeConfiguration>().Linq()
                                                        .FirstOrDefault(x => (x.PlanDesignType == pdrSoldClassforPrimary.PlanDesignType)
                                                        && (x.PremiumPayerAndTaxabilityType == (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum)pdrSoldClassforPrimary.PremiumPayerAndTaxabilityType.Id)
                                                        && (x.VGSIPlanDesignType == (pdrSoldClassforVoluntary != null ? (PlanDesignGSITypeEnum?)pdrSoldClassforVoluntary.PlanDesignType : null)));

            foreach (var option in request.EnrollmentPDRClassOptions)
            {
                var classOption = enrollmentPDRClassOptions.FirstOrDefault(c => c.Id == option.EnrollmentPDRClassOptionId);
                if (classOption == null)
                {
                    classOption = new EnrollmentPDRClassOption();
                    classOption.EnrollmentPDRClass = enrollmentPDRClass;
                    enrollmentPDRClass.EnrollmentPDRClassOptions.Add(classOption);
                }
                classOption.OptionCode = option.OptionCode;
                classOption.IsSelected = option.IsSelected;

                classOption.StandardOptionCodeNonSmoker = standardOfferCodeConfiguration != null ? standardOfferCodeConfiguration.XMLOfferTypeNonSmoker + option.OptionCode : null;
                classOption.StandardOptionCodeSmoker = standardOfferCodeConfiguration != null ? standardOfferCodeConfiguration.XMLOfferTypeSmoker + option.OptionCode : null;

                var optionPlan = option.EnrollmentPDRClassOptionPlans.FirstOrDefault();
                var enrollmentPDRClassOptionPlan = classOption.EnrollmentPDRClassOptionPlans.FirstOrDefault(c => c.Id == optionPlan.EnrollmentPDRClassOptionPlanId);
                if (enrollmentPDRClassOptionPlan == null)
                {
                    enrollmentPDRClassOptionPlan = new EnrollmentPDRClassOptionPlan();
                    classOption.EnrollmentPDRClassOptionPlans.Add(enrollmentPDRClassOptionPlan);
                }
                enrollmentPDRClassOptionPlan.PDRClassPlanType = (PDRClassPlanTypeEnum)optionPlan.PDRClassPlanTypeId;
                enrollmentPDRClassOptionPlan.GSIPercentage = optionPlan.GSIPercentage ?? null;
                enrollmentPDRClassOptionPlan.CoveredEarningsType = optionPlan.CoveredEarningsTypeId != null ? (CoveredEarningsTypeEnum?)optionPlan.CoveredEarningsTypeId : null;
                enrollmentPDRClassOptionPlan.CoveredEarningsBonusOnlyType = optionPlan.CoveredEarningsBonusOnlyTypeId != null ? (CoveredEarningsBonusOnlyTypeEnum?)optionPlan.CoveredEarningsBonusOnlyTypeId : null;
                enrollmentPDRClassOptionPlan.ReplacementRatio = optionPlan.ReplacementRatio ?? null;
                enrollmentPDRClassOptionPlan.Discount = optionPlan.Discount ?? null;
                enrollmentPDRClassOptionPlan.EliminationPeriod = optionPlan.EliminationPeriodTypeId != 0 ? (EliminationPeriodTypeEnum?)optionPlan.EliminationPeriodTypeId : null;
                enrollmentPDRClassOptionPlan.BenefitPeriod = optionPlan.BenefitPeriodTypeId != 0 ? (BenefitPeriodTypeEnum?)optionPlan.BenefitPeriodTypeId : null;
                enrollmentPDRClassOptionPlan.MinimumBenefitAmount = optionPlan.MinimumBenefitAmount ?? null;
                enrollmentPDRClassOptionPlan.DefinitionOfDisabilityType = (DefinitionOfDisabilityTypeEnum)optionPlan.DefinitionOfDisabilityTypeId;
                enrollmentPDRClassOptionPlan.MentalSubstanceLimitationType = (MentalSubstanceLimitationEnum)optionPlan.MentalSubstanceLimitationTypeId;
                enrollmentPDRClassOptionPlan.PreExistingConditionLimitType = (PreExistingConditionLimitTypeEnum)optionPlan.PreExistingConditionLimitTypeId;

                SaveEnrollmentOptionPlanRiders(unitOfWork, optionPlan, enrollmentPDRClassOptionPlan);

            }
            Log.TraceFormat("-SaveEnrollmentOptionAndPlans");
        }

        private void SaveEnrollmentOptionPlanRiders(IUnitOfWork unitOfWork, EnrollmentPDRClassOptionPlanDto optionPlan, EnrollmentPDRClassOptionPlan enrollmentPDRClassOptionPlan)
        {
            Log.TraceFormat("+SaveEnrollmentOptionPlanRiders");

            var enrollmentOptionPlanRiders = unitOfWork.Repository<EnrollmentPDRClassOptionPlanRider>().Linq().Where(c => c.EnrollmentPDRClassOptionPlan.Id == optionPlan.EnrollmentPDRClassOptionPlanId).ToList();

            foreach (var rider in optionPlan.EnrollmentPDRClassOptionPlanRiders)
            {
                var enrollmentPDRClassOptionPlanRider = enrollmentOptionPlanRiders.FirstOrDefault(c => c.Id == rider.EnrollmentPDRClassOptionPlanRiderId);
                if (enrollmentPDRClassOptionPlanRider == null)
                {
                    enrollmentPDRClassOptionPlanRider = new EnrollmentPDRClassOptionPlanRider();
                    enrollmentPDRClassOptionPlanRider.EnrollmentPDRClassOptionPlan = enrollmentPDRClassOptionPlan;
                    enrollmentPDRClassOptionPlan.EnrollmentPDRClassOptionPlanRiders.Add(enrollmentPDRClassOptionPlanRider);
                }

                enrollmentPDRClassOptionPlanRider.BenefitGroupType = (BenefitGroupTypeEnum)rider.BenefitGroupId;
                enrollmentPDRClassOptionPlanRider.BenefitType = (BenefitTypeEnum)rider.BenefitTypeId;
                enrollmentPDRClassOptionPlanRider.EliminationPeriodType = rider.EliminationPeriodId != null ? (EliminationPeriodTypeEnum?)rider.EliminationPeriodId : null;
                enrollmentPDRClassOptionPlanRider.BenefitPeriodType = rider.BenefitPeriodId != null ? (BenefitPeriodTypeEnum?)rider.BenefitPeriodId : null;
                enrollmentPDRClassOptionPlanRider.Amount = rider.Amount;
            }

            var newAndExistingRidersIds = optionPlan.EnrollmentPDRClassOptionPlanRiders.Select(d => d.EnrollmentPDRClassOptionPlanRiderId).ToList();
            var deletedRiders = enrollmentOptionPlanRiders.Where(l => !newAndExistingRidersIds.Contains(l.Id)).ToList();
            foreach (var deletedRider in deletedRiders)
            {
                enrollmentPDRClassOptionPlan.EnrollmentPDRClassOptionPlanRiders.Remove(deletedRider);
            }

            Log.TraceFormat("-SaveEnrollmentOptionPlanRiders");
        }

        private DateTime? GetEnrollmentReviewMilestoneStartDateByCase(int caseId)
        {
            Log.TraceFormat("+GetEnrollmentReviewMilestoneStartDateByCase");

            DateTime? offerletterSignedDate = null;
            DateTime? gltdBookReceivedDate = null;
            DateTime? reEnrollmentReceivedDate = null;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseOfferLetter = unitOfWork.Repository<OfferLetter>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.Case.Id == caseId && c.IsReleasedToGA);

                if (caseOfferLetter != null)
                {
                    offerletterSignedDate = caseOfferLetter.OfferLetterSignedDate;
                }

                var caseDocument = unitOfWork.Repository<CaseDocument>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.Case_Id == caseId && c.CaseDocumentType == CaseDocumentTypeEnum.GLTDBook);

                if (caseDocument != null)
                {
                    gltdBookReceivedDate = caseDocument.CreationDateTime;
                }

                var caseCensus = unitOfWork.Repository<Census>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.PlanDesignRequest.Case.Id == caseId && c.IsActiveIndicator == false);

                if (caseCensus != null)
                {
                    reEnrollmentReceivedDate = caseCensus.ReceivedDateTime;
                }
            }

            DateTime? maxDate1 = null;
            DateTime? maxDate = null;
            if (offerletterSignedDate.HasValue && gltdBookReceivedDate.HasValue && reEnrollmentReceivedDate.HasValue)
            {
                maxDate1 = GetMaxDate((DateTime)offerletterSignedDate, (DateTime)gltdBookReceivedDate);
                maxDate = GetMaxDate((DateTime)maxDate1, (DateTime)reEnrollmentReceivedDate);
            }
            else if (offerletterSignedDate.HasValue && gltdBookReceivedDate.HasValue && reEnrollmentReceivedDate.HasValue == false)
            {
                maxDate = GetMaxDate((DateTime)offerletterSignedDate, (DateTime)gltdBookReceivedDate);
            }
            else if (offerletterSignedDate.HasValue && gltdBookReceivedDate.HasValue == false && reEnrollmentReceivedDate.HasValue)
            {
                maxDate = GetMaxDate((DateTime)offerletterSignedDate, (DateTime)reEnrollmentReceivedDate);
            }
            else if (offerletterSignedDate.HasValue == false && gltdBookReceivedDate.HasValue && reEnrollmentReceivedDate.HasValue)
            {
                maxDate = GetMaxDate((DateTime)gltdBookReceivedDate, (DateTime)reEnrollmentReceivedDate);
            }
            else if (offerletterSignedDate.HasValue && gltdBookReceivedDate.HasValue == false && reEnrollmentReceivedDate.HasValue == false)
            {
                maxDate = offerletterSignedDate;
            }
            else if (offerletterSignedDate.HasValue == false && gltdBookReceivedDate.HasValue && reEnrollmentReceivedDate.HasValue == false)
            {
                maxDate = gltdBookReceivedDate;
            }
            else if (offerletterSignedDate.HasValue == false && gltdBookReceivedDate.HasValue == false && reEnrollmentReceivedDate.HasValue)
            {
                maxDate = reEnrollmentReceivedDate;
            }

            Log.TraceFormat("-GetEnrollmentReviewMilestoneStartDateByCase");

            return maxDate;
        }

        private DateTime GetMaxDate(DateTime date1, DateTime date2)
        {
            int result = DateTime.Compare(date1, date2);

            if (result < 0)
            {
                return date2;
            }
            else if (result == 0)
            {
                return date1;
            }
            else
            {
                return date1;
            }
        }

        public void SaveEnrollmentToolDocuments(EnrollmentToolDto enrollmentToolDto)
        {
            Log.TraceFormat("+SaveEnrollmentToolDto");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {

                var caseDocument = unitOfWork.Repository<CaseDocument>().Linq();
                var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == enrollmentToolDto.EnrollmentId);
                var enrollmentParticipents = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => c.Enrollment.Id == enrollment.Id && c.Participant.IsActive == true && 
                        (c.Participant.IsEligible == true || (c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.NoLongerInGroup &&
                        c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.ActivePolicyNoLongerInGroup && c.Participant.InEligibleReason_Id == null))).Select(c => c.Id).ToList();

                var isCompactState = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == enrollment.Case.Id).IsCompactState;
                if (isCompactState == null)
                {
                    throw new ValidationException("Please select Compact State as Yes or No in Plan Design Request.");
                }

                var splittedParticipantIds = enrollmentParticipents.ChunkBy(2000).ToList();

                if (splittedParticipantIds != null)
                {
                    for (var splittedParticipantIterator = 0; splittedParticipantIterator < splittedParticipantIds.Count; splittedParticipantIterator++)
                    {
                        EnrollmentTool enrollmentTool = SaveEnrollmentTool(enrollmentToolDto, unitOfWork, caseDocument, enrollment, splittedParticipantIterator);

                        if (_enrollmentToolDocumentGenerator != null)
                        {
                            var participantIds = splittedParticipantIds[splittedParticipantIterator].ToList();

                            var enrollmentToolXmlRequest = new CaseCommonXmlGenerationRequest
                            {
                                CaseId = enrollment.Case.Id,
                                EnrollmentId = enrollmentToolDto.EnrollmentId,
                                RequestId = enrollmentTool.Id,
                                EnrollmentToolName = enrollmentTool.EnrollmentToolName,
                                ParticipantIds = participantIds,
                            };
                            _enrollmentToolDocumentGenerator.EnqueueRequest(enrollmentToolXmlRequest);
                        }
                    }
                    unitOfWork.Commit();
                }
            }
            Log.TraceFormat("-SaveEnrollmentToolDto");
        }

        private EnrollmentTool SaveEnrollmentTool(EnrollmentToolDto enrollmentToolDto, IUnitOfWork unitOfWork, IQueryable<CaseDocument> caseDocument, Enrollment enrollment, int splittedParticipantIterator)
        {
            var enrollmentTool = unitOfWork.Repository<EnrollmentTool>().Linq().FirstOrDefault(x => x.Id == enrollmentToolDto.EnrollmentToolDocumentId);

            if (enrollmentTool == null)
            {
                enrollmentTool = new EnrollmentTool();
                enrollmentTool.Enrollment = enrollment;
            }
            enrollmentTool.EnrollmentToolName = enrollmentToolDto.EnrollmentToolName + "_" + (splittedParticipantIterator + 1);
            enrollmentTool.GeneratedDateTime = enrollmentToolDto.GeneratedDateTime;
            enrollmentTool.GeneratedBy = enrollmentToolDto.GeneratedBy;
            enrollmentTool.EffectiveDate = enrollment.EffectiveDate;
            enrollmentTool.PdfDocument = caseDocument.FirstOrDefault(x => x.Id == enrollmentToolDto.PdfDocumentId);
            enrollmentTool.ExcelDocument = caseDocument.FirstOrDefault(x => x.Id == enrollmentToolDto.ExcelDocumentId);
            enrollmentTool.IsActiveIndicator = true;
            unitOfWork.Repository<EnrollmentTool>().Save(enrollmentTool);
            return enrollmentTool;
        }

        public EnrollmentKitPackageDto GetEnrollmentKitPackageConfiguration(List<int> selectedParticipants, int enrollmentId)
        {
            Log.TraceFormat("+GetEnrollmentKitPackageConfiguration");
            var splittedParticipantsIds = selectedParticipants.ChunkBy(150);

            var enrollmentKitPackage = new EnrollmentKitPackageDto();
            Parallel.ForEach(splittedParticipantsIds, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, obj =>
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => (c.Enrollment.Id == enrollmentId) && obj.Contains(c.Id)).ToList();
                    var soldclassIds = enrollmentParticipants.Select(d => d.Participant.PlanDesignRequestClass.Id).ToList();
                    var pdrSoldClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().Where(c => soldclassIds.Contains(c.PDRSoldClass.PlanDesignRequestClass.Id)).ToList();
                    var participantsListBillNumber = enrollmentParticipants.Select(c => c.Participant.ListBillNumber).ToList();
                    var directBill = unitOfWork.Repository<ListBillNumber>().Linq().Any(c => participantsListBillNumber.Contains(c) && c.IsDirectBill);

                    if (pdrSoldClassPlan.Any())
                    {
                        if (pdrSoldClassPlan.Exists(c => c.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan))
                        {
                            enrollmentKitPackage.EnrollmentKitPackageId.Add((int)EnrollmentKitTypeEnum.RPP_Authorization_and_Irrevocable_Assignment);
                            enrollmentKitPackage.EnrollmentKitPackageId.Add((int)EnrollmentKitTypeEnum.RPP_Disclosure_Statement);
                        }
                        if (pdrSoldClassPlan.Exists(c => c.PDRSoldClassPlanRiders.Any(p => p.BenefitGroupType == BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit)))
                        {
                            enrollmentKitPackage.EnrollmentKitPackageId.Add((int)EnrollmentKitTypeEnum.RPP_Rider_Authorization_and_Irrevocable_Assignment);
                            enrollmentKitPackage.EnrollmentKitPackageId.Add((int)EnrollmentKitTypeEnum.RPP_Rider_Disclosure_Statement);
                        }
                    }
                    if (enrollmentParticipants.Any())
                    {
                        if (enrollmentParticipants.Exists(c => c.Participant.ContractState == StateTypeEnum.NY))
                        {
                            enrollmentKitPackage.EnrollmentKitPackageId.Add((int)EnrollmentKitTypeEnum.Reg_194_Disclosure);
                        }
                    }
                    if (directBill)
                    {
                        enrollmentKitPackage.EnrollmentKitPackageId.Add((int)EnrollmentKitTypeEnum.Guard_O_Matic_Authorization);
                    }
                }
            });
            Log.TraceFormat("-GetEnrollmentKitPackageConfiguration");
            return enrollmentKitPackage;
        }
        public bool IsBridgelineXmlDocumentSent(int enrollmentId)
        {
            Log.TraceFormat("+IsBridgelineXmlDocumentSent", enrollmentId);
            bool isDocumentXmlExists = false;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var bridgelineXml = unitOfWork.Repository<BridgelineXml>().Linq().Where(c => c.Enrollment.Id == enrollmentId && c.Status== "Sent to Bridgeline");
                if (bridgelineXml.Count() > 0)
                {
                    isDocumentXmlExists = true;
                }
            }
            Log.TraceFormat("-IsBridgelineXmlDocumentSent", enrollmentId);
            return isDocumentXmlExists;
        }
        public List<BridgelineXmlDto> GetBridgelineXmlDocuments(int enrollmentId)
        {
            Log.TraceFormat("+GetBridgelineXmlDocuments", enrollmentId);
            var bridgelineXmlDocuments = new List<BridgelineXmlDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var bridgelineXml = unitOfWork.Repository<BridgelineXml>().Linq().Where(c => c.Enrollment.Id == enrollmentId);
                if (bridgelineXml.Any())
                {
                    bridgelineXmlDocuments = bridgelineXml.Select(x => new BridgelineXmlDto
                    {
                        BridgelineXmlId = x.Id,
                        EnrollmentId = x.Enrollment.Id,
                        BridgelineXmlName = x.Name,
                        GeneratedBy = x.GeneratedBy,
                        GeneratedDateTime = x.GeneratedDateTime,
                        Status = x.Status,
                        FileContent = x.FileContent != null ? "present" : null
                    }).ToList();
                }
            }
            Log.TraceFormat("-GetBridgelineXmlDocuments", enrollmentId);

            return bridgelineXmlDocuments;
        }

        public FileNetConfig GetFilenetConfig()
        {
           FileNetConfig filenetConfig = new FileNetConfig
           {
                FilenetSearchBaseUrl = _configuration.FilenetSearchBaseUrl,
                FilenetDocId = _configuration.FilenetDocId
            };
            return filenetConfig;
        }

        public void SendToBridgeLine(BridgelineXmlDto bridgelineXmlDto)
        {
            Log.TraceFormat("+SendToBridgeLineXmlDocuments", bridgelineXmlDto.EnrollmentId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var bridgelineXml = unitOfWork.Repository<BridgelineXml>().Linq();
                var selectedXmls = bridgelineXml.Where(c => bridgelineXmlDto.SelectedIds.Contains(c.Id)).ToList();
                if (selectedXmls != null)
                {
                    foreach (BridgelineXml selectedXml in selectedXmls)
                    {
                        _workUnitManager.CreateWorkUnit(WorkUnitType.BridgelineFileAxwayUpload, selectedXml.Id.ToString());

                        selectedXml.GeneratedBy = bridgelineXmlDto.GeneratedBy;
                        selectedXml.GeneratedDateTime = DateTime.Now;
                        selectedXml.Status = "In Process";
                        unitOfWork.Repository<BridgelineXml>().Save(selectedXml);
                    }
                    unitOfWork.Commit();
                }
            }

            Log.TraceFormat("-SendToBridgeLineXmlDocuments", bridgelineXmlDto.EnrollmentId);
        }

        public void DeleteEenrollmentXml(int? bridgelineXmlId)
        {
            Log.TraceFormat("+DeleteEenrollmentXml", bridgelineXmlId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var bridgelineXmlDocument = unitOfWork.Repository<BridgelineXml>().Linq().FirstOrDefault(c => c.Id == bridgelineXmlId);
                if (bridgelineXmlDocument != null && bridgelineXmlDocument.Status != "Sent to Bridgeline")
                {
                    unitOfWork.Repository<BridgelineXml>().Delete(bridgelineXmlDocument);
                }
                unitOfWork.Commit();
            }

            Log.TraceFormat("-DeleteEenrollmentXml", bridgelineXmlId);
        }


        public List<string> ValidateDeliverDocument(List<int> enrollmentParticipantIds, IList<CaseDocumentTypeEnum> selectedDocumentTypes)
        {
            Log.TraceFormat("+ValidateDeliverDocument");
            List<string> errorMessages = new List<string>();            
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                List<List<int>> splittedParticipants = enrollmentParticipantIds.ChunkBy(2000);                
                foreach (var obj in splittedParticipants)
                {
                    var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(e => obj.ToList().Contains(e.Id));
                    foreach (var docType in selectedDocumentTypes)
                    {
                        switch (docType)
                        {
                            case CaseDocumentTypeEnum.AnnouncementLetters:
                                var aparticipants = enrollmentParticipants.Where(e => e.Announcement == null || (e.Announcement != null && e.Announcement.FileNetDocumentId == null && e.Announcement.FileBytes == null));
                                if (aparticipants.Any())
                                {
                                    errorMessages.AddRange(BuildErrorMessage(aparticipants, CaseDocumentTypeEnum.AnnouncementLetters));
                                }
                                break;
                            case CaseDocumentTypeEnum.EnrollmentKit:
                                var kparticipants = enrollmentParticipants.Where(e => e.Kit == null || (e.Kit != null && e.Kit.FileNetDocumentId == null && e.Kit.FileBytes == null));
                                if (kparticipants.Any())
                                {
                                    errorMessages.AddRange(BuildErrorMessage(kparticipants, CaseDocumentTypeEnum.EnrollmentKit));
                                }
                                break;
                            case CaseDocumentTypeEnum.Sweep:
                                var sparticipants = enrollmentParticipants.Where(e => e.Sweep == null || (e.Sweep != null && e.Sweep.FileNetDocumentId == null && e.Sweep.FileBytes == null));
                                if (sparticipants.Any())
                                {
                                    errorMessages.AddRange(BuildErrorMessage(sparticipants, CaseDocumentTypeEnum.Sweep));
                                }
                                break;
                            case CaseDocumentTypeEnum.Other:                                
                                var otherparticipants = enrollmentParticipants.Where(e => e.Other == null || (e.Other != null && e.Other.FileNetDocumentId == null && e.Other.FileBytes == null));
                                if (otherparticipants.Any())
                                {
                                    errorMessages.AddRange(BuildErrorMessage(otherparticipants, CaseDocumentTypeEnum.Other));
                                }
                                break;
                        }

                    }
                }
            }
            Log.TraceFormat("-ValidateDeliverDocument");
            return errorMessages;
        }
       
        public byte[] GetZipDocumentsBytes(List<int> enrollmentParticipantIds, IList<CaseDocumentTypeEnum> selectedDocumentTypes)
        {
            Log.TraceFormat("+GetZipDocumentsBytes");
            var zipRequests = new List<EnrollmentDocumnetsZipRequest>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(e => enrollmentParticipantIds.Contains(e.Id)).ToList();

                foreach (var enrollmentParticipant in enrollmentParticipants)
                {
                    var zipRequest = new EnrollmentDocumnetsZipRequest();
                    zipRequest.Participant = new CensusParticipantDto
                    {
                        CensusParticipantId = enrollmentParticipant.Participant.Id,
                        EmployeeId = enrollmentParticipant.Participant.EmployeeId,
                        FirstName = enrollmentParticipant.Participant.FirstName,
                        LastName = enrollmentParticipant.Participant.LastName
                    };

                    zipRequest.EnrollmentParticipantDeliverDocumentStatus = new EnrollmentParticipantDeliverDocumentStatusDto();
                    zipRequest.EnrollmentParticipantDeliverDocumentStatus.EnrollmentParticipantId = enrollmentParticipant.Id;
                    zipRequest.EnrollmentParticipantDeliverDocumentStatus.KitStatus = enrollmentParticipant.KitStatus;
                    zipRequest.EnrollmentParticipantDeliverDocumentStatus.AnnouncementStatus = enrollmentParticipant.AnnouncementStatus;
                    zipRequest.EnrollmentParticipantDeliverDocumentStatus.SweepStatus = enrollmentParticipant.SweepStatus;
                    zipRequest.EnrollmentParticipantDeliverDocumentStatus.OtherStatus = enrollmentParticipant.OtherStatus;
                    foreach (var docType in selectedDocumentTypes)
                    {
                        switch (docType)
                        {
                            case CaseDocumentTypeEnum.AnnouncementLetters:
                                if (enrollmentParticipant.Announcement != null)
                                {
                                    if (enrollmentParticipant.Announcement.FileNetDocumentId != null)
                                    {
                                        var docResonse = _documentManager.DownloadDocument(enrollmentParticipant.Announcement.Id, enrollmentParticipant.Announcement.Case_Id);
                                        if (docResonse != null && docResonse.Content != null && docResonse.Content.Length > 0)
                                        {
                                            enrollmentParticipant.Announcement.FileBytes = docResonse.Content;
                                        }
                                    }
                                    if (enrollmentParticipant.Announcement.FileBytes != null && enrollmentParticipant.Announcement.FileBytes.Length > 0)
                                    {
                                        zipRequest.DocumentsToZip.Add(enrollmentParticipant.Announcement);
                                        zipRequest.EnrollmentParticipantDeliverDocumentStatus.AnnouncementStatus = "Downloaded";
                                    }

                                }
                                break;
                            case CaseDocumentTypeEnum.EnrollmentKit:
                                if (enrollmentParticipant.Kit != null)
                                {
                                    if (enrollmentParticipant.Kit.FileNetDocumentId != null)
                                    {
                                        var docResonse = _documentManager.DownloadDocument(enrollmentParticipant.Kit.Id, enrollmentParticipant.Kit.Case_Id);
                                        if (docResonse != null && docResonse.Content != null && docResonse.Content.Length > 0)
                                        {
                                            enrollmentParticipant.Kit.FileBytes = docResonse.Content;
                                        }
                                    }
                                    if (enrollmentParticipant.Kit.FileBytes != null && enrollmentParticipant.Kit.FileBytes.Length > 0)
                                    {
                                        zipRequest.DocumentsToZip.Add(enrollmentParticipant.Kit);
                                        zipRequest.EnrollmentParticipantDeliverDocumentStatus.KitStatus = "Downloaded";
                                    }

                                }
                                break;
                            case CaseDocumentTypeEnum.Sweep:
                                if (enrollmentParticipant.Sweep != null)
                                {
                                    if (enrollmentParticipant.Sweep.FileNetDocumentId != null)
                                    {
                                        var docResonse = _documentManager.DownloadDocument(enrollmentParticipant.Sweep.Id, enrollmentParticipant.Sweep.Case_Id);
                                        if (docResonse != null && docResonse.Content != null && docResonse.Content.Length > 0)
                                        {
                                            enrollmentParticipant.Sweep.FileBytes = docResonse.Content;
                                        }
                                    }
                                    if (enrollmentParticipant.Sweep.FileBytes != null && enrollmentParticipant.Sweep.FileBytes.Length > 0)
                                    {
                                        zipRequest.DocumentsToZip.Add(enrollmentParticipant.Sweep);
                                        zipRequest.EnrollmentParticipantDeliverDocumentStatus.SweepStatus = "Downloaded";
                                    }

                                }
                                break;
                            case CaseDocumentTypeEnum.Other:
                                if (enrollmentParticipant.Other != null)
                                {
                                    if (enrollmentParticipant.Other.FileNetDocumentId != null)
                                    {
                                        var docResonse = _documentManager.DownloadDocument(enrollmentParticipant.Other.Id, enrollmentParticipant.Other.Case_Id);
                                        if (docResonse != null && docResonse.Content != null && docResonse.Content.Length > 0)
                                        {
                                            enrollmentParticipant.Other.FileBytes = docResonse.Content;
                                        }
                                    }
                                    if (enrollmentParticipant.Other.FileBytes != null && enrollmentParticipant.Other.FileBytes.Length > 0)
                                    {
                                        zipRequest.DocumentsToZip.Add(enrollmentParticipant.Other);
                                        zipRequest.EnrollmentParticipantDeliverDocumentStatus.OtherStatus = "Downloaded";
                                    }

                                }
                                break;
                        }
                    }

                    if (zipRequest.DocumentsToZip.Count > 0)
                    {
                        zipRequests.Add(zipRequest);
                    }

                }
            }

            var compressedBytes = ZipParticipantDocuments(zipRequests);

            if (zipRequests.Any())
            {
                UpdateEnrollmentParticipantDeliverDocumentStatus(zipRequests);
            }

            Log.TraceFormat("-GetZipDocumentsBytes");
            return compressedBytes;
        }

        private byte[] ZipParticipantDocuments(IList<EnrollmentDocumnetsZipRequest> requests)
        {
            Log.TraceFormat("+ZipParticipantDocuments");
            byte[] compressedBytes;
            using (var outStream = new MemoryStream())
            {
                using (var archive = new ZipArchive(outStream, ZipArchiveMode.Create, true))
                {
                    foreach (var request in requests)
                    {
                        var p = request.Participant;
                        foreach (var document in request.DocumentsToZip)
                        {
                            var extn = document.FileName != null ? document.FileName.Split('.')[1] : string.Empty;
                            var documentType = document.CaseDocumentType.GetDescription();
                            string fileName = string.Format("{0} - {1}, {2} - {3}.{4}", p.EmployeeId, p.LastName, p.FirstName, documentType, extn);
                            byte[] fileBytes = document.FileBytes;
                            var fileInArchive = archive.CreateEntry(fileName, CompressionLevel.Optimal);
                            using (var entryStream = fileInArchive.Open())
                            using (var fileToCompressStream = new MemoryStream(fileBytes))
                            {
                                fileToCompressStream.CopyTo(entryStream);
                            }
                        }
                    }
                }
                compressedBytes = outStream.ToArray();
            }
            Log.TraceFormat("-ZipParticipantDocuments");
            return compressedBytes;
        }
        public void DeleteSelectedDocuments(List<int> enrollmentParticipantIds, IList<CaseDocumentTypeEnum> selectedDocumentTypes)
        {
            Log.TraceFormat("+DeleteSelectedDocuments");
            List<string> participantList = new List<string>();
            var splittedParticipantsIds = enrollmentParticipantIds.ChunkBy(50);
            Parallel.ForEach(splittedParticipantsIds, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, obj =>
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(e => enrollmentParticipantIds.Contains(e.Id)).Select(participant => new EnrollmentParticipantDeleteDocumentStatusDto
                    {
                        EnrollmentParticipantId = participant.Id,
                        EmployeeId = participant.Participant.EmployeeId,
                        KitId = participant.Kit != null ? (int?)participant.Kit.Id : null,
                        KitApproved = participant.KitApproved,
                        KitStatus = participant.KitStatus,
                        AnnouncementId = participant.Announcement != null ? (int?)participant.Announcement.Id : null,
                        AnnouncementApproved = participant.AnnouncementApproved,
                        AnnouncementStatus = participant.AnnouncementStatus,
                        SweepId = participant.Sweep != null ? (int?)participant.Sweep.Id : null,
                        SweepApproved = participant.SweepApproved,
                        SweepStatus = participant.SweepStatus,
                    }).ToList();

                    foreach (var enrollmentParticipant in enrollmentParticipants)
                    {
                        var isParticipantHasDocumentDownloaded = false;
                        if ((enrollmentParticipant.AnnouncementStatus != null && enrollmentParticipant.AnnouncementStatus.ToUpper() == "DOWNLOADED")
                            || (enrollmentParticipant.KitStatus != null && enrollmentParticipant.KitStatus.ToUpper() == "DOWNLOADED")
                            || (enrollmentParticipant.SweepStatus != null && enrollmentParticipant.SweepStatus.ToUpper() == "DOWNLOADED"))
                        {
                            isParticipantHasDocumentDownloaded = true;
                        }
                        foreach (var docType in selectedDocumentTypes)
                        {
                            if (isParticipantHasDocumentDownloaded == true) break;
                            switch (docType)
                            {
                                case CaseDocumentTypeEnum.AnnouncementLetters:
                                    if (enrollmentParticipant.AnnouncementId != null)
                                    {
                                        enrollmentParticipant.AnnouncementId = null;
                                        enrollmentParticipant.AnnouncementApproved = null;
                                        enrollmentParticipant.AnnouncementStatus = null;
                                    }
                                    break;
                                case CaseDocumentTypeEnum.EnrollmentKit:
                                    if (enrollmentParticipant.KitId != null)
                                    {
                                        enrollmentParticipant.KitId = null;
                                        enrollmentParticipant.KitApproved = null;
                                        enrollmentParticipant.KitStatus = null;
                                    }
                                    break;
                                case CaseDocumentTypeEnum.Sweep:

                                    if (enrollmentParticipant.SweepId != null)
                                    {
                                        enrollmentParticipant.SweepId = null;
                                        enrollmentParticipant.SweepApproved = null;
                                        enrollmentParticipant.SweepStatus = null;
                                    }
                                    break;
                            }
                        }
                        if (isParticipantHasDocumentDownloaded == true)
                        {
                            participantList.Add(enrollmentParticipant.EmployeeId);
                        }
                    }
                    if (enrollmentParticipants.Any())
                    {
                        UpdateEnrollmentParticipantDeleteDocument(enrollmentParticipants);
                    }
                }
            });
            if (participantList.Count > 0)
            {
                var strError = string.Format("Cannot delete documents which have been delivered for participants : {0}", string.Join(",", participantList.ToArray()));
                throw new ValidationException(strError);
            }
            Log.TraceFormat("-DeleteSelectedDocuments");
        }

        private void UpdateEnrollmentParticipantDeliverDocumentStatus(IList<EnrollmentDocumnetsZipRequest> requests)
        {
            Log.TraceFormat("+UpdateEnrollmentParticipantDeliverDocumentStatus");

            var enrollmentParticipantDeliverDocumentStatus = requests.Select(r => r.EnrollmentParticipantDeliverDocumentStatus).ToList();

            DataTable deliverdocumentStatusTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(enrollmentParticipantDeliverDocumentStatus));

            string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");

            using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
            {
                SqlCommand command = sqlConnection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "[cms].[USP_UpdateEnrollmentParticipantDeliverDocumentStatus]";

                SqlParameter parameter = new SqlParameter();
                parameter.ParameterName = "@EnrollmentParticipantTableVariable";
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.Value = deliverdocumentStatusTable;

                command.Parameters.Add(parameter);

                sqlConnection.Open();

                int numberOfRowsUpdated = command.ExecuteNonQuery();
            }

            Log.TraceFormat("-UpdateEnrollmentParticipantDeliverDocumentStatus");
        }
        private void UpdateEnrollmentParticipantDeleteDocument(List<EnrollmentParticipantDeleteDocumentStatusDto> requests)
        {
            Log.TraceFormat("+UpdateEnrollmentParticipantDeleteDocument");

            DataTable deletedocumentStatusTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(requests));

            string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");

            using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
            {
                SqlCommand command = sqlConnection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "[cms].[USP_UpdateEnrollmentParticipantDeleteDocument]";

                SqlParameter parameter = new SqlParameter();
                parameter.ParameterName = "@EnrollmentParticipantTableVariable";
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.Value = deletedocumentStatusTable;

                command.Parameters.Add(parameter);

                sqlConnection.Open();

                int numberOfRowsUpdated = command.ExecuteNonQuery();
            }

            Log.TraceFormat("-UpdateEnrollmentParticipantDeleteDocument");
        }

        private List<string> BuildErrorMessage(IQueryable<EnrollmentParticipant> participants, CaseDocumentTypeEnum documentType)
        {
            List<string> errorMessages = new List<string>();
            foreach (var p in participants)
            {
                errorMessages.Add(string.Format("{0} {1} {2} does not yet have {3} ready for delivery", p.Participant.EmployeeId, p.Participant.FirstName, p.Participant.LastName, documentType.GetDescription()));
            }
            return errorMessages;
        }

        public void UpdateEnrollmentParticipantsBasedOnCensus(int enrollmentId)
        {
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(c => c.Id == enrollmentId && (c.IsActive == null || c.IsActive == true));

                if (enrollment != null)
                {
                    if (!enrollment.IsAddOnIndicator)
                    {
                        var censusParticipants = enrollment.Classes.
                                                SelectMany(c => c.PlanDesignRequestClass.CensusParticipants).Where(c => c.IsEligible == null || c.IsEligible == true);

                        var enrolledParticipants = enrollment.CensusParticipants.Select(c => c.Participant.Id).ToList();
                        var addedCensusParticipantList = censusParticipants.Select(c => c.Id).Except(enrolledParticipants).ToList();

                        List<int> participantList = new List<int>();

                        if (addedCensusParticipantList.Count > 0)
                        {
                            participantList = addedCensusParticipantList;
                        }

                        List<EnrollmentParticipantDto> enrollmentParticipantDtoList = new List<EnrollmentParticipantDto>();
                        if (participantList.Count > 0)
                        {
                            foreach (var censusParticipantId in participantList)
                            {
                                var pdrClassId = censusParticipants.Where(c => censusParticipantId == c.Id).
                                    Select(c => c.PlanDesignRequestClass.Id).FirstOrDefault();
                                var enrollmentParticipantDto = new EnrollmentParticipantDto
                                {
                                    EnrollmentId = enrollmentId,
                                    CensusParticipantId = censusParticipantId,
                                    PlanDesignRequestClassId = pdrClassId
                                };

                                enrollmentParticipantDtoList.Add(enrollmentParticipantDto);
                            }

                            AddEnrollmentParticipants(enrollmentParticipantDtoList);
                        }
                    }
                        
                }
            }
        }

        private void AddEnrollmentParticipants(List<EnrollmentParticipantDto> requests)
        {
            DataTable deletedocumentStatusTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(requests));

            string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");

            using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
            {
                SqlCommand command = sqlConnection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "[cms].[USP_AddEnrollmentParticipantByCenus]";

                SqlParameter parameter = new SqlParameter();
                parameter.ParameterName = "@EnrollmentParticipantTableVariable";
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.Value = deletedocumentStatusTable;

                command.Parameters.Add(parameter);

                sqlConnection.Open();

                int numberOfRowsUpdated = command.ExecuteNonQuery();
            }

        }


        private void SaveEnrolledCensusParticipants(int enrollmentId, int participantId, int pdrClassId, IUnitOfWork unitOfWork)
        {
            object[] parameters = new object[3];
            parameters[0] = enrollmentId;
            parameters[1] = participantId;
            parameters[2] = pdrClassId;

            unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_AddEnrollmentParticipantByCenus] :@Enrollment_Id, :@Particiapant_Id, :@PdrC", parameters);

            unitOfWork.Commit();
        }

        private void UpdateEnrollmentTaskWorkUnit(EnrollmentDto enrollmentDto)
        {
            Log.TraceFormat("+UpdateEnrollmentTaskWorkUnit");

            if (enrollmentDto.StartDateTaskWorkUnitId.HasValue)
            {
                TimeSpan timeSpanEnrollmentStartDate = enrollmentDto.EnrollmentStartDate.Value - DateTime.UtcNow;
                if (enrollmentDto.StartDateTaskWorkUnitId > 0)
                {
                    WorkUnitDto workUnitDto = new WorkUnitDto()
                    {
                        WorkUnitId = enrollmentDto.StartDateTaskWorkUnitId.Value,
                        StartDate = DateTime.UtcNow.Add(timeSpanEnrollmentStartDate),
                        HandlerName = WorkUnitType.EnrollmentInProgress.ToString(),
                        InputData = enrollmentDto.EnrollmentId.ToString(),
                    };
                    _workUnitManager.UpdateWorkUnit(workUnitDto);
                }
            }

            if (enrollmentDto.ExtensionEndDateTaskWorkUnitId.HasValue)
            {
                TimeSpan timeSpanExtentionEndDate = enrollmentDto.ExtensionEndDate.Value.AddDays(1) - DateTime.UtcNow;
                if (enrollmentDto.ExtensionEndDateTaskWorkUnitId > 0)
                {
                    WorkUnitDto workUnitDto = new WorkUnitDto()
                    {
                        WorkUnitId = enrollmentDto.ExtensionEndDateTaskWorkUnitId.Value,
                        StartDate = DateTime.UtcNow.Add(timeSpanExtentionEndDate),
                        HandlerName = WorkUnitType.PostEnrollment.ToString(),
                        InputData = enrollmentDto.EnrollmentId.ToString(),
                    };
                    _workUnitManager.UpdateWorkUnit(workUnitDto);
                }
            }

            Log.TraceFormat("-UpdateEnrollmentTaskWorkUnit");
        }


        public bool MakeInactive(int enrollmentId)
        {
            Log.TraceFormat("+MakeInactive");
            var result = false;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollment = unitOfWork.Repository<Enrollment>().Linq().FirstOrDefault(e => e.Id == enrollmentId);
                if (enrollment == null)
                {
                    throw new ValidationException("Please select enrollment to make inactive!");
                }
                unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_MakeEnrollmentInactive] " + enrollmentId);
                unitOfWork.Commit();
                result = true;
            }
            Log.TraceFormat("-MakeInactive");
            return result;
        }

        public void DeleteSelectedBenefitPremium(List<int> benefitPremiumIds)
        {
            Log.TraceFormat("+DeleteSelectedBenefitPremium");

            foreach (var id in benefitPremiumIds)
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {

                    var benefitPremium = unitOfWork.Repository<BenefitPremiumDocument>().Linq().Where(e => e.Id == id).FirstOrDefault();
                    if (benefitPremium != null)
                    {
                        var dbDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == benefitPremium.PdfDocument.Id);
                        if (dbDocument == null) throw new ApplicationException("Case document not found!");
                        dbDocument.IsDeleted = true;
                        dbDocument.CaseDocumentRequest.ExtreamRequest = null;
                        unitOfWork.Repository<CaseDocument>().Save(dbDocument);
                        unitOfWork.Commit();
                    }
                }
            }
            Log.TraceFormat("-DeleteSelectedBenefitPremium");
        }

        public void DeleteSelectedEnrollmentTools(List<int> enrollmentToolIds)
        {
            Log.TraceFormat("+DeleteSelectedEnollmentTool");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                foreach (var id in enrollmentToolIds)
                {
                    var enrollmentTool = unitOfWork.Repository<EnrollmentTool>().Linq().Where(e => e.Id == id).FirstOrDefault();
                    if (enrollmentTool != null)
                    {
                        var dbDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == enrollmentTool.PdfDocument.Id);
                        if (dbDocument == null) throw new ApplicationException("Case document not found!");
                        dbDocument.IsDeleted = true;
                        unitOfWork.Repository<CaseDocument>().Save(dbDocument);
                    }
                }
                unitOfWork.Commit();
            }
            Log.TraceFormat("-DeleteSelectedEnollmentTool");
        }

    }
   



    public class EnrollmentDocumnetsZipRequest
    {
        public int CaseId { get; set; }
        public CensusParticipantDto Participant { get; set; }
        public EnrollmentParticipantDeliverDocumentStatusDto EnrollmentParticipantDeliverDocumentStatus { get; set; }
        public List<CaseDocument> DocumentsToZip { get; set; }

        public EnrollmentDocumnetsZipRequest()
        {
            DocumentsToZip = new List<CaseDocument>();
        }
    }

}
