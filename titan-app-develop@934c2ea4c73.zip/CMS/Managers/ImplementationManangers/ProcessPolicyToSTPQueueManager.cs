﻿using System;
using System.Linq;
using System.Threading.Tasks;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.MLAppEntryServices;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.Managers.ImplementationManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Utilities;
using Logger.Static;
using Newtonsoft.Json;
using NHibernate.Linq;

namespace CMS.Managers.ImplementationManangers
{
    public class ProcessPolicyToSTPQueueManager : IWorkUnitHandler, IProcessPolicyToSTPQueueManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IAppEntryService _appEntryService;
        private readonly IPolicyNumberUpdationManager _policyNumberUpdationManager;

        public ProcessPolicyToSTPQueueManager(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager, 
            IAppEntryService appEntryService, IPolicyNumberUpdationManager policyNumberUpdationManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _workUnitManager = workUnitManager;
            _appEntryService = appEntryService;
            _policyNumberUpdationManager = policyNumberUpdationManager;
        }

        public void EnqueueRequest(PolicyGenerationRequestDto participantDataRequest)
        {
            Log.TraceFormat("+EnqueueRequest");

            _workUnitManager.CreateWorkUnit(WorkUnitType.ProcessPolicyToSTPQueue, string.Join(",", JsonConvert.SerializeObject(participantDataRequest)));

            Log.TraceFormat("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.DebugFormat("+ProcessPolicyToSTPQueueManager");

            var request = JsonConvert.DeserializeObject<PolicyGenerationRequestDto>(workUnit.InputData);

            try
            {
                WorkItemSendRequest workitemvm = new WorkItemSendRequest();
                StpPostRequest stpPostRequest = new StpPostRequest();               

                var splittedEnrollmentParticipantsIds = request.SelectedEnrollmentParticipantIds.ChunkBy(1000);
                
                Log.DebugFormat($"ProcessPolicyToSTPQueueManager: Processing started for the STP Queue process for the work unit id {workUnit.Id}");

                Enrollment enrollment = null;
                if (request.IsDirectCoverageEnrollment)
                {
                    enrollment = _unitOfWorkFactory.CreateUnitOfWork().Repository<Enrollment>().Linq().Where(i => i.Id == request.EnrollmentId
                                                   && i.EnrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.DirectCoverage
                                                   && (i.IsActive == null || i.IsActive == true)).Fetch(i => i.Case).FirstOrDefault();
                    if (enrollment == null)
                    {
                        Log.DebugFormat($"ProcessPolicyToSTPQueueManager: Skipping STP Queue process. No active directcoverage enrollment for the case number {request.CaseId} and Enrollment id {request.EnrollmentId} ");
                        throw new Exception($"ProcessPolicyToSTPQueueManager: STP Queue process aborted due to invalid enrollment for the case number {request.CaseId}");
                    }
                }
                else if (request.IsOneStepEnrollment)
                {
                    enrollment = _unitOfWorkFactory.CreateUnitOfWork().Repository<Enrollment>().Linq().Where(i => i.Id == request.EnrollmentId
                                                   && i.EnrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.OneStep
                                                   && (i.IsActive == null || i.IsActive == true)).Fetch(i => i.Case).FirstOrDefault();

                    if (enrollment == null)
                    {
                        Log.DebugFormat($"ProcessPolicyToSTPQueueManager: Skipping STP Queue process. No active onestep enrollment for the case number {request.CaseId} and Enrollment id {request.EnrollmentId} ");
                        throw new Exception($"ProcessPolicyToSTPQueueManager: STP Queue process aborted due to invalid enrollment for the case number {request.CaseId}");
                    }
                }

                

                Parallel.ForEach(splittedEnrollmentParticipantsIds, enrollmentParticipantIds =>
                {                   
                    using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                    {                       
                        foreach (var enrollmentparticipantid in enrollmentParticipantIds)
                        {                            
                            var cmsParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                                    .Where(c => c.Id == enrollmentparticipantid)
                                                    .Select(c => new { FirstName = c.Participant.FirstName, LastName = c.Participant.LastName }).FirstOrDefault();

                            if (cmsParticipant == null)
                            {
                                Log.DebugFormat($"ProcessPolicyToSTPQueueManager: Skipping STP Queue process. Invalid participant with case number {request.CaseId} and Enrollment id {request.EnrollmentId} ");
                                break;
                            }

                            var cmsEnrollmentParticipantPolicy = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq()
                                                                  .Where(i => i.EnrollmentParticipant.Id == enrollmentparticipantid && i.EnrollmentParticipant.Enrollment.Id == request.EnrollmentId)
                                                                  .Select(i => new { PolicyNumber = i.PolicyNumber, Id = i.Id }).FirstOrDefault();

                            if (cmsEnrollmentParticipantPolicy == null)
                            {
                                Log.DebugFormat($"ProcessPolicyToSTPQueueManager: Skipping STP Queue process. Invalid policy number with participant id { enrollmentparticipantid } case number {request.CaseId} and Enrollment id {request.EnrollmentId}");
                                break;
                            }

                            workitemvm.ApplicationTrackingId = cmsEnrollmentParticipantPolicy.Id;
                            workitemvm.ParticipantCMSID = Convert.ToString(enrollmentparticipantid);
                            workitemvm.CaseNumber = enrollment.Case.CaseNumber;
                            workitemvm.CaseName = enrollment.Case.CompanyName;
                            workitemvm.InsuredFirstName = cmsParticipant.FirstName;
                            workitemvm.InsuredLastName = cmsParticipant.LastName;
                            if (request.IsOneStepEnrollment)
                            {
                                workitemvm.DocumentType = WorkitemDocumentTypeEnum.OneStepEnrollment;
                            }
                            else if(request.IsDirectCoverageEnrollment)
                            {
                                workitemvm.DocumentType = WorkitemDocumentTypeEnum.DirectCoverageEnrollment;
                            }
                            workitemvm.PolicyNumber = cmsEnrollmentParticipantPolicy.PolicyNumber;
                            stpPostRequest.PolicyNumber = cmsEnrollmentParticipantPolicy.PolicyNumber;
                            stpPostRequest.CaseNumber = enrollment.Case.CaseNumber;
                            stpPostRequest.CallerID = "Titan";
                            stpPostRequest.StpStatus = StpStatusEnum.IGO;
                            stpPostRequest.EnrollmentParticipantId = enrollmentparticipantid;
                            _appEntryService.SendWorkItem(workitemvm);
                            _appEntryService.SendPolicyToMLAppStp(stpPostRequest);
                        }
                    }                    

                });

                Log.DebugFormat($"ProcessPolicyToSTPQueueManager: Processing complete for the STP Queue process for the work unit id {workUnit.Id}");
                
            }
            catch (Exception e)
            {
                Log.Error($"ProcessPolicyToSTPQueueManager: Error in STP processing for work unit with id {workUnit.Id}!", e);
            }

            _policyNumberUpdationManager.EnqueueRequest(request); // Create a new work unit to Update New policy number into filenet.

            Log.DebugFormat("-ProcessPolicyToSTPQueueManager");
        }
    }
}