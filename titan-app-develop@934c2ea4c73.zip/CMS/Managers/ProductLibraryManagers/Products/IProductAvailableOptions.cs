﻿using System.Collections.Generic;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.PlanManagers.Products
{
    public interface IProductAvailableOptions
    {
        List<EliminationPeriodTypeEnum> GetEliminationPeriods(EliminationPeriodTypeEnum eliminationPeriod);
        List<BenefitPeriodTypeEnum> GetBenefitPeriods(BenefitPeriodTypeEnum benefitPeriod);
        List<DefinitionOfDisabilityTypeEnum> GetDefinitionOfDisabilities(DefinitionOfDisabilityTypeEnum definitionOfDisability);
        List<MentalSubstanceLimitationEnum> GetMentalSubstances(MentalSubstanceLimitationEnum mentalSubstance);
        List<PreExistingConditionLimitTypeEnum> GetPreExistingConditionLimits(PreExistingConditionLimitTypeEnum condition);
        RiderApprovedOptions GetRiderOptions(BenefitTypeEnum benefitType, EliminationPeriodTypeEnum? eliminationPeriod, BenefitPeriodTypeEnum? benefitPeriod, decimal? amount);
    }
}