﻿namespace CMS.Managers.PlanManagers.Products
{
    public interface IProductSampleQuoteOptions
    {
        
    }
}