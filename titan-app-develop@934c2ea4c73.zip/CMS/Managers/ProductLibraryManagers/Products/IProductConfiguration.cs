﻿namespace CMS.Managers.PlanManagers.Products
{
    public interface IProductConfiguration
    {
        IProductOptions Options { get; set; }
        IProductAvailableOptions AvailableOptions { get; set; }
        IProductSampleQuoteOptions SampleQuoteOptions { get; set; }
    }
}