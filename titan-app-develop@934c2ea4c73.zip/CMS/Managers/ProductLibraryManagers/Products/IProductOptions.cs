﻿using System.Collections.Generic;
using CMS.Interfaces.Common;
using CMS.Interfaces.Managers.PlanManagers;

namespace CMS.Managers.PlanManagers.Products
{
    public interface IProductOptions
    {
        List<IdDisplayNameDto> DefinitionOfDisabilityTypes { get; set; }
        List<IdDisplayNameDto> MentalOrSubstanceLimitationTypes { get; set; }
        List<IdDisplayNameDto> PreExistingLimitationTypes { get; set; }
        List<IdDisplayNameDto> PDRDiscountTypes { get; set; }
        List<IdDisplayNameDto> EliminationPeriodTypes { get; set; }
        List<IdDisplayNameDto> BenefitPeriodTypes { get; set; }
        List<PlanDesignRequestClassRiderGroupDto> GetPlanDesignRiders();
    }
}