﻿using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Common;
using CMS.Interfaces.Integrations.ProductLibraryServices;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using Guardian.Core.Entities.Product.Enums;
using Guardian.Core.Entities.Product.Enums.EnumExtensions;
using Logger.Static;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Managers.ProductLibraryManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Interfaces.DataAccess;
using Newtonsoft.Json;
using CMS.Interfaces.Integrations.PremiumCalculationServices.ServiceContracts;

namespace CMS.Managers.PlanManagers
{
    public class ProductLibraryManager : IProductLibraryManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IProductLibraryService _productLibraryService;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;
        static List<StateTypeEnum> _nonApprovedStates = new List<StateTypeEnum>
            {
                StateTypeEnum.UN
            };
        public ProductLibraryManager(IProductLibraryService productLibraryService, IEligibilityConfigurationManager eligibilityConfigurationManager, IUnitOfWorkFactory unitOfWorkFactory)
        {
            _productLibraryService = productLibraryService;
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public bool IsCompactStateCase(int caseid)
        {
            Log.TraceFormat("+IsCompactStateCase");
            bool isCompactState = false;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var underWritingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(i => i.Case.Id == caseid);
                if (underWritingRequest != null)
                {
                    isCompactState = underWritingRequest.IsCompactState != null ? underWritingRequest.IsCompactState.Value : false;
                }
            }

            Log.TraceFormat("-IsCompactStateCase");
            return isCompactState;
        }      

        public bool IsCAStateCase(int caseid)
        {
            Log.TraceFormat("+IsCAStateCase");
            bool isCAState = false;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var underWritingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(i => i.Case.Id == caseid);
                if (underWritingRequest != null)
                {
                    isCAState = underWritingRequest.StateType != null ? (underWritingRequest.StateType == StateTypeEnum.CA ? true : false) : false;
                }
            }

            Log.TraceFormat("-IsCAStateCase");
            return isCAState;
        }


        public ProductValidationResult ValidateProduct(ProductValidationRequest request, int? pricingTypeId)
        {
            Log.TraceFormat("+ValidateProduct");

            var response = new ProductValidationResult();

            VerifyBaseBenefitAvailability(request, response, pricingTypeId);

            VerifyOccClassAndPartialRiderCombination(request, response);

            VerifyRiderStateAvailability(request, response, pricingTypeId);

            VerifyRiderCombinationsAvailability(request, response, pricingTypeId);

            Log.TraceFormat("-ValidateProduct");
            return response;
        }

        public bool IsEligibleForBaseBenefit(ProductEligibilityRequest request, int? pricingTypeId)
        {
            return _productLibraryService.IsEligibleForBaseBenefit(
                (int)request.ProductVariantId,
                request.StateId,
                request.InsuredAge,
                FixDefinitionOfDisabilityTypeEnum(request.DefinitionOfDisabilityTypeId),
                request.EliminationPeriodTypeId,
                request.BenefitPeriodTypeId,
                request.MentalSubstanceLimitationId,
                request.OccupationClassTypeId,
                request.IsCompactState, pricingTypeId);
        }

        public ProductEligibilityRiderResponse GetRiderEligibility(List<RiderBenefitDto> ridersInfo, ProductEligibilityRiderRequest request)
        {
            return new ProductLibraryRiderDowngradeRules().GetRiderEligibility(ridersInfo, request);
        }

        private void VerifyRiderStateAvailability(ProductValidationRequest request, ProductValidationResult response, int? pricingTypeId)
        {
            Log.TraceFormat("+VerifyRiderStateAvailability");

            var stateAvailableRiders = _productLibraryService.GetAvailableRidersInformation(
                (int)request.ProductVariantId,
                request.Age,
                request.State,
                FixDefinitionOfDisabilityTypeEnum(request.DefinitionOfDisability),
                request.EliminationPeriod,
                _productLibraryService.FixBenefitPeriod(request.BenefitPeriod),
                request.MentalSubstanceLimitation,
                request.OccupationClass, request.IsCompactState, pricingTypeId);

            var stateAvailableRiderIds = stateAvailableRiders.Select(r => (int)r.Benefit).ToList();
            var requestedRiderIds = request.BenefitValidationRequests.Select(r => (int)r.BenefitType).ToList();

            var notAvailableRiderIds = requestedRiderIds.Where(r => !stateAvailableRiderIds.Contains(r));

            foreach (var notAvailableRiderId in notAvailableRiderIds)
            {
                response.IsValid = false;
                response.ValidationMessages.Add(string.Format("'{0}' is not available in state '{1}'", ((BenefitTypeEnum)notAvailableRiderId).GetDescription(), request.State));
            }

            var remainingRiders = request.BenefitValidationRequests.Where(r => (r.BenefitPeriod != null || r.EliminationPeriod != null) && stateAvailableRiderIds.Contains((int)r.BenefitType)).ToList();

            foreach (var remainingRider in remainingRiders)
            {
                var hasStateAvailableRiderBenefitPeriod = remainingRider.BenefitPeriod != null ? stateAvailableRiders.FirstOrDefault(r => r.Benefit == remainingRider.BenefitType).BenefitProperties.Any(b => b.BenefitPeriod == remainingRider.BenefitPeriod) : true;

                var hasStateAvailableRiderEliminationPeriod = remainingRider.EliminationPeriod != null ? stateAvailableRiders.FirstOrDefault(r => r.Benefit == remainingRider.BenefitType).BenefitProperties.Any(b => b.EliminationPeriod == remainingRider.EliminationPeriod) : true;

                if (!hasStateAvailableRiderBenefitPeriod)
                {
                    response.IsValid = false;
                    response.ValidationMessages.Add(string.Format("'{0}' benefit period is not available for the rider '{1}' ", remainingRider.BenefitPeriod.GetDescription(), remainingRider.BenefitType.GetDescription()));
                }

                if (!hasStateAvailableRiderEliminationPeriod)
                {
                    response.IsValid = false;
                    response.ValidationMessages.Add(string.Format("'{0}' elimination period is not available for the rider '{1}' ", remainingRider.EliminationPeriod.GetDescription(), remainingRider.BenefitType.GetDescription()));
                }
            }

            Log.TraceFormat("-VerifyRiderStateAvailability");
        }

        public List<int> GetRidersAvailabilityByState(ProductValidationRequest request)
        {
            Log.TraceFormat("+GetRidersAvailabilityByState");

            var stateAvailableRiders = _productLibraryService.GetRiders(
                (int)request.ProductVariantId,
                request.Age,
                request.State,
                FixDefinitionOfDisabilityTypeEnum(request.DefinitionOfDisability),
                request.EliminationPeriod,
                _productLibraryService.FixBenefitPeriod(request.BenefitPeriod),
                request.MentalSubstanceLimitation,
                request.OccupationClass,
                request.OccupationGroup,
                request.IsCompactState, 1);

            var stateAvailableRiderIds = stateAvailableRiders.Select(r => r.Id).ToList();

            Log.TraceFormat("-GetRidersAvailabilityByState");

            return stateAvailableRiderIds;
        }

        private void VerifyRiderCombinationsAvailability(ProductValidationRequest request, ProductValidationResult response, int? pricingTypeId)
        {
            Log.TraceFormat("+VerifyRiderCombinationsAvailability");

            var options = _productLibraryService.GetOptions((int)request.ProductVariantId, request.State, request.Age, request.IsCompactState , pricingTypeId);
            var requestedRiderIds = request.BenefitValidationRequests.Select(b => (int)b.BenefitType).ToList();
            var processedRiderIds = new List<int>();

            foreach (var requestedRiderId in requestedRiderIds)
            {
                if (processedRiderIds.Contains(requestedRiderId)) continue;

                var availableRiderIds = _productLibraryService.GetRidersForSelection(options.BaseBenefitId, request.FormCode, 
                    requestedRiderId, requestedRiderIds, request.IsCompactState, request.State, pricingTypeId);

                var unavailableRiderIds = requestedRiderIds.Where(r => r != requestedRiderId).Except(availableRiderIds).ToList();
                if (unavailableRiderIds.Any())
                {
                    foreach (var unavailableRiderId in unavailableRiderIds)
                    {
                        response.IsValid = false;
                        response.ValidationMessages.Add(string.Format("Rider {0} and {1} cannot be combined",
                            ((BenefitTypeEnum)requestedRiderId).GetDescription(), ((BenefitTypeEnum)unavailableRiderId).GetDescription()));

                        processedRiderIds.Add(unavailableRiderId);
                    }
                }
            }

            Log.TraceFormat("-VerifyRiderCombinationsAvailability");
        }

        public List<PlanDesignRequestClassRiderGroupDto> GetPlanDesignRiders()
        {
            Log.TraceFormat("+GetPlanDesignRiders");
            var eligibilityConfigurationClassDto = new EligibilityConfigurationDto();
            eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
            Log.TraceFormat("-GetPlanDesignRiders");
            return new List<PlanDesignRequestClassRiderGroupDto>
            {
                new PlanDesignRequestClassRiderGroupDto
                {
                    BenefitGroup = new IdDisplayNameDto { Id = (int)BenefitGroupTypeEnum.PartialDisability, DisplayName = "Partial/Residual Disability" },
                    Riders = new List<PlanDesignRequestClassRiderDto>
                    {
                        new PlanDesignRequestClassRiderDto {
                            BenefitTypes = new List<BenefitTypeEnum>
                            {
                                BenefitTypeEnum.EnhancedPartialDisabilityRider,
                                BenefitTypeEnum.BasicPartialDisabilityRider,
                                BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider
                            },
                            SelectedBenefitType = (int)BenefitTypeEnum.EnhancedPartialDisabilityRider
                        },
                    },
                    IsSelected = true
                },
                new PlanDesignRequestClassRiderGroupDto
                {
                    BenefitGroup = new IdDisplayNameDto { Id = (int)BenefitGroupTypeEnum.CatastrophicDisabilityBenefit, DisplayName = "Catastrophic Disability (CAT)" },
                    Riders = new List<PlanDesignRequestClassRiderDto>
                    {
                        new PlanDesignRequestClassRiderDto {
                            BenefitTypes = new List<BenefitTypeEnum>
                            {
                                BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider,
                                BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider
                            },
                            SelectedBenefitType = (int)BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider
                        },
                    },
                    IsSelected = true,
                    IndemnitityAmountMessage = eligibilityConfigurationClassDto.CATLimitAmount !=null ? "Approved Amount up to $" + string.Format("{0:n0}", eligibilityConfigurationClassDto.CATLimitAmount) : "Approved Amount up to $12,500"
                },
                new PlanDesignRequestClassRiderGroupDto
                {
                    BenefitGroup = new IdDisplayNameDto { Id = (int)BenefitGroupTypeEnum.CostOfLivingAdjustment, DisplayName = "Cost of Living Adjustment (COLA)" },
                    Riders = new List<PlanDesignRequestClassRiderDto>
                    {
                        new PlanDesignRequestClassRiderDto {
                            BenefitTypes = new List<BenefitTypeEnum>
                            {
                                BenefitTypeEnum.CostOfLiving6PercentMaximum,
                                BenefitTypeEnum.CostOfLiving3PercentCompound,
                                BenefitTypeEnum.CostOfLiving4YearDelayed
                            },
                            SelectedBenefitType = (int)BenefitTypeEnum.CostOfLiving6PercentMaximum
                        },
                    },
                    IsSelected = true
                },
                new PlanDesignRequestClassRiderGroupDto
                {
                    BenefitGroup = new IdDisplayNameDto { Id = (int)BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit, DisplayName = "Retirement Protection Plus (RPP) " },
                    Riders = new List<PlanDesignRequestClassRiderDto>
                    {
                        new PlanDesignRequestClassRiderDto
                        {
                            BenefitTypes = new List<BenefitTypeEnum>
                            {
                                BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit,
                            },
                            EliminationPeriods = new List<EliminationPeriodTypeEnum>
                            {
                                EliminationPeriodTypeEnum._180,
                                EliminationPeriodTypeEnum._360
                            },
                            SelectedBenefitType = (int)BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit,
                            SelectedEliminationPeriod = (int)EliminationPeriodTypeEnum._180
                        },
                    },
                    IsSelected = true,
                    ShowBenefitType=false,
                    IndemnitityAmountMessage = "Approved amount up to $" + string.Format("{0:n0}",eligibilityConfigurationClassDto.RPPMaximumIndemnityAmount) + " ($" + string.Format("{0:n0}",eligibilityConfigurationClassDto.RPPMaximumIndemnityAmountUnderAge49) + " Age 49 & Under)"
                },
                new PlanDesignRequestClassRiderGroupDto
                {
                    BenefitGroup = new IdDisplayNameDto { Id = (int)BenefitGroupTypeEnum.StudentLoanProtectionRider, DisplayName = "Student Loan Protection (SLP)" },
                    Riders = new List<PlanDesignRequestClassRiderDto>
                    {
                        new PlanDesignRequestClassRiderDto
                        {
                            BenefitTypes = new List<BenefitTypeEnum>
                            {
                                BenefitTypeEnum.StudentLoanProtection,
                            },
                            EliminationPeriods = new List<EliminationPeriodTypeEnum>
                            {
                                EliminationPeriodTypeEnum._090,
                                EliminationPeriodTypeEnum._180
                            },
                            BenefitPeriods = new List<BenefitPeriodTypeEnum>
                            {
                                BenefitPeriodTypeEnum.Y15,
                                BenefitPeriodTypeEnum.Y10,
                            },
                            SelectedBenefitType = (int)BenefitTypeEnum.StudentLoanProtection,
                            SelectedEliminationPeriod = (int)EliminationPeriodTypeEnum._090,
                            SelectedBenefitPeriod = (int)BenefitPeriodTypeEnum.Y15
                        },
                    },
                    IsSelected = true,
                    HasIndemnitityAmountIndicator=true,
                    IndemnitityAmountMessage = "Approved Amount up to $2,500",
                    ShowBenefitType=false
                },
                new PlanDesignRequestClassRiderGroupDto
                {
                    BenefitGroup = new IdDisplayNameDto { Id = (int)BenefitGroupTypeEnum.SupplementalBenefit, DisplayName = "Supplemental Benefit Term Rider (SBT)" },
                    Riders = new List<PlanDesignRequestClassRiderDto>
                    {
                        new PlanDesignRequestClassRiderDto
                        {
                            BenefitTypes = new List<BenefitTypeEnum>
                            {
                                BenefitTypeEnum.SupplementalBenefitTermRider,
                            },
                            EliminationPeriods = new List<EliminationPeriodTypeEnum>
                            {
                                EliminationPeriodTypeEnum._090,
                                EliminationPeriodTypeEnum._180
                            },
                            BenefitPeriods = new List<BenefitPeriodTypeEnum>
                            {
                                BenefitPeriodTypeEnum.Y15,
                                BenefitPeriodTypeEnum.Y10,
                            },
                            SelectedBenefitType = (int)BenefitTypeEnum.SupplementalBenefitTermRider,
                            SelectedEliminationPeriod = (int)EliminationPeriodTypeEnum._090,
                            SelectedBenefitPeriod = (int)BenefitPeriodTypeEnum.Y15
                        },
                    },
                    HasIndemnitityAmountIndicator=true,
                    IndemnitityAmountMessage = "Approved Amount up to $2,000",
                    ShowBenefitType=false
                },
                new PlanDesignRequestClassRiderGroupDto
                {
                    BenefitGroup = new IdDisplayNameDto{ Id = (int)BenefitGroupTypeEnum.UnemploymentPremiumWaiver, DisplayName ="Unemployment Waiver Premium" },
                    Riders = new List<PlanDesignRequestClassRiderDto>
                    {
                        new PlanDesignRequestClassRiderDto
                        {
                            BenefitTypes = new List<BenefitTypeEnum>
                            {
                                BenefitTypeEnum.UnemploymentPremiumWaiver
                            },
                            SelectedBenefitType = (int)BenefitTypeEnum.UnemploymentPremiumWaiver
                        },
                    },
                    HasIndemnitityAmountIndicator = false,
                    HasRider = false
                },
                new PlanDesignRequestClassRiderGroupDto
                {
                    BenefitGroup = new IdDisplayNameDto{ Id = (int)BenefitGroupTypeEnum.Endorsement, DisplayName = "Serious Illness Benefit" },
                    Riders = new List<PlanDesignRequestClassRiderDto>
                    {
                        new PlanDesignRequestClassRiderDto
                        {
                            BenefitTypes = new List<BenefitTypeEnum>
                            {
                                BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement
                            },
                            SelectedBenefitType = (int)BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement
                        }
                    },
                    HasRider = false
                },
                new PlanDesignRequestClassRiderGroupDto
                {
                    BenefitGroup = new IdDisplayNameDto{ Id = (int)BenefitGroupTypeEnum.ExtendedBenefits, DisplayName = "Lump Sum Indemnity Rider" },
                    Riders = new List<PlanDesignRequestClassRiderDto>
                    {
                        new PlanDesignRequestClassRiderDto
                        {
                            BenefitTypes = new List<BenefitTypeEnum>
                            {
                                BenefitTypeEnum.LumpSumIndemnityRider
                            },
                            SelectedBenefitType = (int)BenefitTypeEnum.LumpSumIndemnityRider
                        }
                    },
                    HasRider = false
                },
            };
        }

        public BenefitTypeEnum FixBenefitTypeEnum(BenefitTypeEnum bt)
        {
            switch (bt)
            {
                case BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit:
                    return BenefitTypeEnum.ProViderPlusRetirementProtection;
            }
            return bt;
        }

        public DefinitionOfDisabilityTypeEnum FixDefinitionOfDisabilityTypeEnum(DefinitionOfDisabilityTypeEnum ddt)
        {
            switch (ddt)
            {
                case DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation:
                    return DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupationME;
            }
            return ddt;

        }

        public List<DefinitionOfDisabilityTypeEnum> FixDefinitionOfDisabilityTypeEnum(List<DefinitionOfDisabilityTypeEnum> definitionOfDisabilityTypeEnumList)
        {
            List<DefinitionOfDisabilityTypeEnum> modifiedDefinitionOfDisabilityTypeEnum = new List<DefinitionOfDisabilityTypeEnum>();

            foreach (var definitionOfDisabilityTypeEnum in definitionOfDisabilityTypeEnumList)
            {
                if ((DefinitionOfDisabilityTypeEnum)definitionOfDisabilityTypeEnum == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupationME)
                {
                    modifiedDefinitionOfDisabilityTypeEnum.Add(DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation);
                }
                else
                {
                    modifiedDefinitionOfDisabilityTypeEnum.Add((DefinitionOfDisabilityTypeEnum)definitionOfDisabilityTypeEnum);
                }
            }

            return modifiedDefinitionOfDisabilityTypeEnum;
        }

        public ProductEligibilityResponse GetEligibleBaseBenefit(ProductEligibilityRequest request, int? pricingTypeId)
        {
            if (request.OutcomeMessages == null) //Calling DOD logic before Base benefit validation
            {
                request.OutcomeMessages = new List<string>();
            }
            request = ValidateDefinitionOfDisability(request);

            bool isEligible = IsEligibleForBaseBenefit(request, pricingTypeId);

            int counter = 0; //To avoid infinite loop - Should break eligible validation reach max 10 for a request.

            while (!isEligible)
            {
                if (request.OutcomeMessages == null)
                {
                    request.OutcomeMessages = new List<string>();
                }

                var newRequest = AdjustProductEligibilityRequest(request);
                if (newRequest.IsInEligible)
                {
                    break;
                }
                request = newRequest;
                isEligible = IsEligibleForBaseBenefit(request, pricingTypeId);
                counter++;
                if (counter >= 10)
                {
                    request.OutcomeMessages.Add("Product library validation returns false for the input. Age : " + request.InsuredAge
                        + ", Benefit period : " + request.BenefitPeriodTypeId.GetDescription() 
                        + ", Elimination period : " + request.EliminationPeriodTypeId.GetDescription()
                        + ", Definition of Disability : " + request.DefinitionOfDisabilityTypeId.GetDescription() 
                        + ", Mental Substance Limitation : " + request.MentalSubstanceLimitationId.GetDescription()
                        + ", Occupation class : " + request.OccupationClassTypeId.GetDescription() 
                        + ", State : " + request.StateId.GetDescription()
                        + ", Product Variant Id : " + request.ProductVariantId
                        );
                    break;
                }
            }

            var response = CreateProductEligibilityResponse(request);
            response.IsEligible = isEligible;

            return response;
        }

        private ProductEligibilityRequest AdjustProductEligibilityRequest(ProductEligibilityRequest request)
        {

            request = ValidateIneligibleOptionByEPandState(request);

            if (!request.IsInEligible)
            {
                request = ValidateBenefitPeriodByAge(request);
            }

            if (!request.IsInEligible)
            {
                request = ValidateBPandEPByState(request);
            }

            if (!request.IsInEligible)
            {
                request = ValidateDefinitionOfDisability(request);
            }

            if (!request.IsInEligible)
            {
                request = ValidateMentalSubstanceByContractState(request);
            }

            return request;

        }

        private ProductEligibilityResponse CreateProductEligibilityResponse(ProductEligibilityRequest request)
        {
            var response = new ProductEligibilityResponse
            {
                BenefitPeriodTypeId = request.BenefitPeriodTypeId,
                EliminationPeriodTypeId = request.EliminationPeriodTypeId,
                DefinitionOfDisabilityTypeId = request.DefinitionOfDisabilityTypeId,
                MentalSubstanceLimitationId = request.MentalSubstanceLimitationId,
                OutcomeMessages = request.OutcomeMessages,
                InsuredAge = request.InsuredAge,
            };
            return response;
        }

        public List<RiderBenefitDto> GetAvailableRidersInformation(ProductEligibilityRequest request, int? pricingTypeId)
        {
            return _productLibraryService.GetAvailableRidersInformation(
                (int)request.ProductVariantId,
                request.InsuredAge,
                request.StateId,
                FixDefinitionOfDisabilityTypeEnum(request.DefinitionOfDisabilityTypeId),
                request.EliminationPeriodTypeId,
                request.BenefitPeriodTypeId,
                request.MentalSubstanceLimitationId,
                request.OccupationClassTypeId, request.IsCompactState, pricingTypeId);
        }

        private ProductEligibilityRequest ValidateIneligibleOptionByEPandState(ProductEligibilityRequest request)
        {
           if (request.EliminationPeriodTypeId == EliminationPeriodTypeEnum._720
                                                && (request.StateId == StateTypeEnum.DE || request.StateId == StateTypeEnum.CA))
            {
                request.OutcomeMessages.Add("Ineligible for option - due to Elimination period " + request.EliminationPeriodTypeId.GetDescription() + " and State " + request.StateId);
                request.IsInEligible = true;
                //return null;
            }

            return request;
        }

        private ProductEligibilityRequest ValidateBenefitPeriodByAge(ProductEligibilityRequest request)
        {
            if (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A67 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.V70)
            {
                if (request.InsuredAge >= 18 && request.InsuredAge <= 66)
                {
                    // Participants are eligible
                }
                else if (request.InsuredAge >= 67 && request.InsuredAge <= 74)
                {
                    request.OutcomeMessages.Add("Decrease Benefit from Benefit period " + request.BenefitPeriodTypeId.GetDescription() + " to " + BenefitPeriodTypeEnum.Y02.GetDescription() + " due to participant insured age " + request.InsuredAge);
                    request.BenefitPeriodTypeId = BenefitPeriodTypeEnum.Y02;// Decrease to 2 year
                }
                else if (request.InsuredAge >= 75 && request.InsuredAge <= 80)
                {
                    request.OutcomeMessages.Add("Decrease Benefit from Benefit period " + request.BenefitPeriodTypeId.GetDescription() + " to " + BenefitPeriodTypeEnum.Y01.GetDescription() + " due to participant insured age " + request.InsuredAge);
                    request.BenefitPeriodTypeId = BenefitPeriodTypeEnum.Y01; //decrease 1 year
                }
            }
            else if (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10
                || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02)
            {
                if (request.InsuredAge >= 18 && request.InsuredAge <= 55)
                {
                    // Participants are eligible
                }
                else if (request.InsuredAge >= 56 && request.InsuredAge <= 60)
                {
                    if (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05
                        || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02)
                    {
                        //eligible
                    }
                    else
                    {
                        request.OutcomeMessages.Add("Decrease Benefit from Benefit period " + request.BenefitPeriodTypeId.GetDescription() + " to " + BenefitPeriodTypeEnum.Y05.GetDescription() + " due to participant insured age " + request.InsuredAge);
                        request.BenefitPeriodTypeId = BenefitPeriodTypeEnum.Y05; // Decrease to 5 year
                    }

                }
                else if (request.InsuredAge >= 61 && request.InsuredAge <= 64)
                {
                    if (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02)
                    {
                        //eligible
                    }
                    else //do we need to adjust this value
                    {
                        request.OutcomeMessages.Add("Decrease Benefit from Benefit period " + request.BenefitPeriodTypeId.GetDescription() + " to " + BenefitPeriodTypeEnum.Y02.GetDescription() + " due to participant insured age " + request.InsuredAge);
                        request.BenefitPeriodTypeId = BenefitPeriodTypeEnum.Y02;
                    }

                }
                else if (request.InsuredAge >= 65 && request.InsuredAge <= 74)
                {
                    if (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02)
                    {
                        //eligible
                    }
                    else
                    {
                        request.OutcomeMessages.Add("Decrease Benefit from Benefit period " + request.BenefitPeriodTypeId.GetDescription() + " to " + BenefitPeriodTypeEnum.Y02.GetDescription() + " due to participant insured age " + request.InsuredAge);
                        request.BenefitPeriodTypeId = BenefitPeriodTypeEnum.Y02;
                    }
                }
                else if (request.InsuredAge >= 75 && request.InsuredAge <= 80)
                {
                    if (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y01)
                    {
                        //eligible
                    }
                    else
                    {
                        request.OutcomeMessages.Add("Decrease Benefit from Benefit period " + request.BenefitPeriodTypeId.GetDescription() + " to " + BenefitPeriodTypeEnum.Y01.GetDescription() + " due to participant insured age " + request.InsuredAge);
                        request.BenefitPeriodTypeId = BenefitPeriodTypeEnum.Y01;
                    }
                }
            }
            return request;
        }

        private ProductEligibilityRequest ValidateBPandEPByState(ProductEligibilityRequest request)
        {
            if (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02 && request.EliminationPeriodTypeId == EliminationPeriodTypeEnum._360
                && (request.StateId == StateTypeEnum.DE))
            {
                request.OutcomeMessages.Add("Ineligible for option - due to Benefit period " + request.BenefitPeriodTypeId.GetDescription() + " , State "
                    + request.StateId + " and Elimination period " + request.EliminationPeriodTypeId.GetDescription());
                request.IsInEligible = true;
            }
            else if (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y01
                && (request.EliminationPeriodTypeId == EliminationPeriodTypeEnum._360 || request.EliminationPeriodTypeId == EliminationPeriodTypeEnum._720)
                && request.StateId == StateTypeEnum.NY)
            {
                request.OutcomeMessages.Add("Ineligible for option - due to Benefit period " + request.BenefitPeriodTypeId.GetDescription() + " , State "
                    + request.StateId + " and Elimination period " + request.EliminationPeriodTypeId.GetDescription());
                request.IsInEligible = true;
            }

            return request;
        }

        private ProductEligibilityRequest ValidateDefinitionOfDisability(ProductEligibilityRequest request)
        {
            //Commented code will be used in Release 2. Definiton of Disability downgrade logic need to apply though Product library base benefit service 
           
            {
                if (request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc
                    && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y01 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02))
                {
                    request.OutcomeMessages.Add("Changed Definition of Disability from " + request.DefinitionOfDisabilityTypeId + " to " + DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc);
                    request.DefinitionOfDisabilityTypeId = DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc;
                }
                else if (((request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc
                    || request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc)
                    && (request.OccupationClassTypeId == OccupationClassTypeEnum._1 || request.OccupationClassTypeId == OccupationClassTypeEnum._2
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._3 || request.OccupationClassTypeId == OccupationClassTypeEnum._4
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._5 || request.OccupationClassTypeId == OccupationClassTypeEnum._6)))
                {
                    request.OutcomeMessages.Add("Changed Definition of Disability from " + request.DefinitionOfDisabilityTypeId + " to " + DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty
                        + " due to combination of Definiton of Disability and Occupation class " + request.OccupationClassTypeId.GetDescription());
                    request.DefinitionOfDisabilityTypeId = DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty;
                }
                else if (((request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc
                    || request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty)
                    && (request.OccupationClassTypeId == OccupationClassTypeEnum._3D || request.OccupationClassTypeId == OccupationClassTypeEnum._4D)))

                {
                    request.OutcomeMessages.Add("Changed Definition of Disability from " + request.DefinitionOfDisabilityTypeId + " to " + DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc
                        + " due to combination of Definiton of Disability and Occupation class " + request.OccupationClassTypeId.GetDescription());
                    request.DefinitionOfDisabilityTypeId = DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc;
                }
                else if (((request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty
                    || request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc)
                    && (request.OccupationClassTypeId == OccupationClassTypeEnum._1M || request.OccupationClassTypeId == OccupationClassTypeEnum._2M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._3M || request.OccupationClassTypeId == OccupationClassTypeEnum._4M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._5M || request.OccupationClassTypeId == OccupationClassTypeEnum._6M)
                    && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A67 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.V70)
                    && (request.HasPartialRider) && (request.InsuredAge < 67) && (!_nonApprovedStates.Contains(request.StateId))))
                {
                    request.OutcomeMessages.Add("Changed Definition of Disability from " + request.DefinitionOfDisabilityTypeId + " to " + DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc
                        + " due to combination of Definiton of Disability and Occupation class " + request.OccupationClassTypeId.GetDescription());
                    request.DefinitionOfDisabilityTypeId = DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc;
                }
                else if (((request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty
                    || request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc)
                    && (request.OccupationClassTypeId == OccupationClassTypeEnum._1M || request.OccupationClassTypeId == OccupationClassTypeEnum._2M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._3M || request.OccupationClassTypeId == OccupationClassTypeEnum._4M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._5M || request.OccupationClassTypeId == OccupationClassTypeEnum._6M)
                    && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10
                        || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02)
                    && (request.HasPartialRider) && (request.InsuredAge < 65) && (!_nonApprovedStates.Contains(request.StateId))))
                {
                    request.OutcomeMessages.Add("Changed Definition of Disability from " + request.DefinitionOfDisabilityTypeId + " to " + DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc
                        + " due to combination of Definiton of Disability and Occupation class " + request.OccupationClassTypeId.GetDescription());
                    request.DefinitionOfDisabilityTypeId = DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc;
                }
                else if (((request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty
                    || request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc)
                    && (request.OccupationClassTypeId == OccupationClassTypeEnum._1M || request.OccupationClassTypeId == OccupationClassTypeEnum._2M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._3M || request.OccupationClassTypeId == OccupationClassTypeEnum._4M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._5M || request.OccupationClassTypeId == OccupationClassTypeEnum._6M)
                    && (!request.HasPartialRider)))
                {
                    request.OutcomeMessages.Add("Changed Definition of Disability from " + request.DefinitionOfDisabilityTypeId + " to " + DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc
                        + " due to combination of Definiton of Disability and Occupation class " + request.OccupationClassTypeId.GetDescription());
                    request.DefinitionOfDisabilityTypeId = DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc;
                }
                else if (((request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty
                    || request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc)
                    && (request.OccupationClassTypeId == OccupationClassTypeEnum._1M || request.OccupationClassTypeId == OccupationClassTypeEnum._2M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._3M || request.OccupationClassTypeId == OccupationClassTypeEnum._4M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._5M || request.OccupationClassTypeId == OccupationClassTypeEnum._6M)
                    && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A67 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.V70)
                    && (request.HasPartialRider) && (request.InsuredAge > 66) && (!_nonApprovedStates.Contains(request.StateId))))
                {
                    request.OutcomeMessages.Add("Changed Definition of Disability from " + request.DefinitionOfDisabilityTypeId + " to " + DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc
                        + " due to combination of Definiton of Disability and Occupation class " + request.OccupationClassTypeId.GetDescription());
                    request.DefinitionOfDisabilityTypeId = DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc;
                }
                else if (((request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty
                    || request.DefinitionOfDisabilityTypeId == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc)
                    && (request.OccupationClassTypeId == OccupationClassTypeEnum._1M || request.OccupationClassTypeId == OccupationClassTypeEnum._2M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._3M || request.OccupationClassTypeId == OccupationClassTypeEnum._4M
                        || request.OccupationClassTypeId == OccupationClassTypeEnum._5M || request.OccupationClassTypeId == OccupationClassTypeEnum._6M)
                    && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10
                        || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02)
                    && (request.HasPartialRider) && (request.InsuredAge > 64) && (!_nonApprovedStates.Contains(request.StateId))))
                {
                    request.OutcomeMessages.Add("Changed Definition of Disability from " + request.DefinitionOfDisabilityTypeId + " to " + DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc
                        + " due to combination of Definiton of Disability and Occupation class " + request.OccupationClassTypeId.GetDescription());
                    request.DefinitionOfDisabilityTypeId = DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc;
                }               
            }

            return request;
        }

        private ProductEligibilityRequest ValidatePreExistingConditionLimit(ProductEligibilityRequest request)
        {
            if (request.StateId == StateTypeEnum.WY && (request.PreExistingConditionLimitTypeId == PreExistingConditionLimitTypeEnum._12_12 
                || request.PreExistingConditionLimitTypeId == PreExistingConditionLimitTypeEnum._6_12))
            {
                request.OutcomeMessages.Add(" Decrease benefit Pre-Existing Condition Limit from " + request.PreExistingConditionLimitTypeId + " to " + PreExistingConditionLimitTypeEnum._3_12);
                request.PreExistingConditionLimitTypeId = PreExistingConditionLimitTypeEnum._3_12;
            }          

            return request;
        }
        
        private ProductEligibilityRequest ValidateMentalSubstanceByContractState(ProductEligibilityRequest request)
        {
            if (request.StateId == StateTypeEnum.CA && request.MentalSubstanceLimitationId == MentalSubstanceLimitationEnum._Nolimitation)
            {
                request.OutcomeMessages.Add("Changed Benefit from " + request.MentalSubstanceLimitationId.GetDescription() + " to " + MentalSubstanceLimitationEnum._24Month.GetDescription() + " due to state " + request.StateId);
                request.MentalSubstanceLimitationId = MentalSubstanceLimitationEnum._24Month;
            }
            return request;
        }

       
        public ProductValidationResult ValidatePDRProduct(PlanDesignDto request, Case cmsCase)
        {
            var selectedClass = request.PlanDesignRequests.First().SelectedClass;

            if (selectedClass == null) return new ProductValidationResult();

            List<PlanDesignRequestClassRiderDto> classRiderDtos = new List<PlanDesignRequestClassRiderDto>();
            List<BenefitValidationRequest> benefitValidationRequests = new List<BenefitValidationRequest>();

            bool? isGsiBuyup = (selectedClass.IsApprovedVoluntaryGSIBuyUpPlan != null && selectedClass.IsApprovedVoluntaryGSIBuyUpPlan == true) ? true : false;
            PlanDesignRequestClassProductDto classProductDto;
            GetPlanDesignProduct(selectedClass, out classRiderDtos, benefitValidationRequests, false, out classProductDto);

            ProductValidationRequest productValidationRequest;

            productValidationRequest = new ProductValidationRequest(
                            (StateTypeEnum)GetCaseStateType(request.CaseUnderwritingRequest, cmsCase),
                            (PlanDesignTypeEnum)selectedClass.ApprovedPlanDesignTypeId,
                            (BenefitPeriodTypeEnum)selectedClass.ApprovedBenefitPeriodTypeId,
                            (EliminationPeriodTypeEnum)selectedClass.ApprovedEliminationPeriodTypeId,
                            (DefinitionOfDisabilityTypeEnum)classProductDto.DefinitionOfDisabilityTypeId,
                            (PreExistingConditionLimitTypeEnum)classProductDto.PreExistingConditionLimitTypeId,
                            (MentalSubstanceLimitationEnum)classProductDto.MentalSubstanceLimitationTypeId,
                            benefitValidationRequests, request.CaseUnderwritingRequest.IsCompactState.Value,
                            GetProductVariantType((PricingTypeEnum)request.CaseUnderwritingRequest.PricingTypeId, (PlanDesignTypeEnum)selectedClass.ApprovedPlanDesignTypeId)
                        );

            ProductValidationResult resultPrimary = ValidateProduct(productValidationRequest, request.CaseUnderwritingRequest.PricingTypeId);


            ProductValidationResult resultGsiBuyup = null;
            if (isGsiBuyup == true)
            {
                benefitValidationRequests = new List<BenefitValidationRequest>();
                GetPlanDesignProduct(selectedClass, out classRiderDtos, benefitValidationRequests, true, out classProductDto);

                productValidationRequest = new ProductValidationRequest(
                                            (StateTypeEnum)GetCaseStateType(request.CaseUnderwritingRequest, cmsCase),
                                            (PlanDesignGSITypeEnum)selectedClass.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId,
                                            (BenefitPeriodTypeEnum)classProductDto.BenefitPeriodTypeId,
                                            (EliminationPeriodTypeEnum)classProductDto.EliminationPeriodTypeId,
                                            (DefinitionOfDisabilityTypeEnum)classProductDto.DefinitionOfDisabilityTypeId,
                                            (PreExistingConditionLimitTypeEnum)classProductDto.PreExistingConditionLimitTypeId,
                                            (MentalSubstanceLimitationEnum)classProductDto.MentalSubstanceLimitationTypeId,
                                            benefitValidationRequests, request.CaseUnderwritingRequest.IsCompactState.Value,
                                            GetProductVariantType((PricingTypeEnum)request.CaseUnderwritingRequest.PricingTypeId, (PlanDesignTypeEnum)selectedClass.ApprovedVoluntaryGSIBuyUpPlanDesignTypeId)
                                        );

                resultGsiBuyup = ValidateProduct(productValidationRequest, request.CaseUnderwritingRequest.PricingTypeId);
            }

            if (resultGsiBuyup != null)
            {
                for (var i = 0; i < resultGsiBuyup.ValidationMessages.Count; i++)
                {
                    resultGsiBuyup.ValidationMessages[i] += " for BuyUp Plan";
                }
                resultPrimary.ValidationMessages.AddRange(resultGsiBuyup.ValidationMessages);
            }

            return resultPrimary;
        }

        private void GetPlanDesignProduct(PlanDesignRequestClassDto selectedClass, out List<PlanDesignRequestClassRiderDto> classRiderDtos, List<BenefitValidationRequest> benefitValidationRequests, bool? isGsiBuyup, out PlanDesignRequestClassProductDto classProductDto)
        {
            classProductDto = selectedClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == isGsiBuyup);
            classRiderDtos = selectedClass.PlanDesignRequestClassRiders.Where(c => c.IsGSIPlanIndicator == isGsiBuyup).ToList();
            if (classRiderDtos.Any())
            {
                foreach (var riderDto in classRiderDtos)
                {
                    var benefitValidationRequest = new BenefitValidationRequest();
                    benefitValidationRequest.BenefitPeriod = (BenefitPeriodTypeEnum?)riderDto.SelectedBenefitPeriod;
                    benefitValidationRequest.EliminationPeriod = (EliminationPeriodTypeEnum?)riderDto.SelectedEliminationPeriod;
                    benefitValidationRequest.BenefitType = (BenefitTypeEnum)riderDto.SelectedBenefitType;
                    benefitValidationRequests.Add(benefitValidationRequest);
                }
            }

            var benefitrequest = new BenefitValidationRequest();
            benefitrequest.BenefitType = _productLibraryService.FixPreExistingConditionLimitationType((PreExistingConditionLimitTypeEnum)classProductDto.PreExistingConditionLimitTypeId);
            benefitValidationRequests.Add(benefitrequest);
        }

        private StateTypeEnum? GetCaseStateType(CaseUnderwritingRequestDto caseUnderwritingRequestDto, Case cmsCase)
        {
            StateTypeEnum? caseStateType = null;

            var caseCompanyLocation = cmsCase.CaseCompanyLocations.OrderByDescending(i => i.Id).FirstOrDefault();

            if (caseUnderwritingRequestDto.SitusTypeId == (int)SitusTypeEnum.Corporate || caseUnderwritingRequestDto.SitusTypeId == (int)SitusTypeEnum.Multi_State)
            {
                caseStateType = (StateTypeEnum)caseUnderwritingRequestDto.StateTypeId;
            }
            else
            {
                caseStateType = caseCompanyLocation != null ? caseCompanyLocation.StateType : StateTypeEnum.UN;
            }

            return caseStateType;

        }

        private void VerifyBaseBenefitAvailability(ProductValidationRequest request, ProductValidationResult response, int? pricingTypeId)
        {
            Log.TraceFormat("+VerifyBaseBenefitAvailability");

            var options = _productLibraryService.GetBaseBenefitOptions((int)request.ProductVariantId, request.State, request.Age,
                FixDefinitionOfDisabilityTypeEnum(request.DefinitionOfDisability), request.EliminationPeriod,
                _productLibraryService.FixBenefitPeriod(request.BenefitPeriod),
                request.MentalSubstanceLimitation, request.OccupationClass, request.IsCompactState, pricingTypeId);

            var requestedRiderIds = request.BenefitValidationRequests.Select(b => (int)b.BenefitType).ToList();

            var benefitPeriod = options.BenefitPeriods.FirstOrDefault(c => c.Id == (int)_productLibraryService.FixBenefitPeriod(request.BenefitPeriod));
            if (benefitPeriod == null)
            {
                response.IsValid = false;
                response.ValidationMessages.Add(string.Format("'{0}' is not available in state '{1}'", ((BenefitPeriodTypeEnum)request.BenefitPeriod).GetDescription(), request.State));
            }

            var eliminationPeriod = options.EliminationPeriods.FirstOrDefault(c => c.Id == (int)request.EliminationPeriod);
            if (eliminationPeriod == null)
            {
                response.IsValid = false;
                response.ValidationMessages.Add(string.Format("'{0}' is not available in state '{1}'", (request.EliminationPeriod).GetDescription(), request.State));
            }

            var definitionofDisability = options.DefinitionOfDisabilities.FirstOrDefault(c => c.Id == (int)FixDefinitionOfDisabilityTypeEnum(request.DefinitionOfDisability));
            if (definitionofDisability == null)
            {
                response.IsValid = false;
                response.ValidationMessages.Add(string.Format("'{0}' is not available in state '{1}'", (request.DefinitionOfDisability).GetDescription(), request.State));
            }

            var mentalSubstance = options.MentalSubstances.FirstOrDefault(c => c.Id == (int)request.MentalSubstanceLimitation);
            if (mentalSubstance == null)
            {
                response.IsValid = false;
                response.ValidationMessages.Add(string.Format("'{0}' is not available in state '{1}'", (request.MentalSubstanceLimitation).GetDescription(), request.State));
            }

            Log.TraceFormat("-VerifyBaseBenefitAvailability");
        }

        public ProductEligibilityRequest GetNextAvailableDefinitionOfDisabilities(ProductEligibilityRequest request)
        {
            var definitionOfDisabilities = new List<DefinitionOfDisabilityTypeEnum> { DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc,
                DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc,
                DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty, DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc,
                DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation, DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc };

            if (definitionOfDisabilities.Contains(request.DefinitionOfDisabilityTypeId) && request.DefinitionOfDisabilityTypeId != DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc)
            {
                request.OutcomeMessages.Add("Decrease Definition of Disability Benefit from " + request.DefinitionOfDisabilityTypeId.GetDescription());
                request.DefinitionOfDisabilityTypeId = definitionOfDisabilities.Skip(definitionOfDisabilities.ToList().IndexOf(request.DefinitionOfDisabilityTypeId) + 1).Take(1).FirstOrDefault();
            }
            return request;
        }

        public List<BenefitTypeEnum> GetPreExistingConditionLimitEndorsement()
        {
            var list = new[] { BenefitTypeEnum.PreExistingConditionLimitationEndorsementNoPrex, BenefitTypeEnum.PreExistingConditionLimitationEndorsementPrex12,
                BenefitTypeEnum.PreExistingConditionLimitationEndorsementPrex3, BenefitTypeEnum.PreExistingConditionLimitationEndorsementPrex6};

            return list.ToList();
        }

        public ProductEligibilityRequest GetEligiblePreExistingEndorsement(ProductEligibilityRequest request, List<RiderBenefitDto> ridersInfo)
        {
            var productEligibilityRequest = ValidatePreExistingConditionLimit(request);

            var orignalProductEligibilityRequest = productEligibilityRequest;

            bool endorsementResponse = IsEligiblePreExistingEndorsement(productEligibilityRequest.PreExistingConditionLimitTypeId, ridersInfo);

            while (!endorsementResponse)
            {
                var newRequest = GetNextAvailableEndorsementRider(productEligibilityRequest);

                if ((newRequest.PreExistingConditionLimitTypeId == request.PreExistingConditionLimitTypeId) || newRequest.PreExistingConditionLimitTypeId == 0)
                {
                    productEligibilityRequest.OutcomeMessages.Add("There is no next available PreExisting Condition Limitation.");
                    break;
                }
                productEligibilityRequest = newRequest;

                endorsementResponse = IsEligiblePreExistingEndorsement(productEligibilityRequest.PreExistingConditionLimitTypeId, ridersInfo);
            }

            if (productEligibilityRequest.OutcomeMessages.Contains("There is no next available PreExisting Condition Limitation."))
            {
                Log.Debug($"GetEligiblePreExistingEndorsement {JsonConvert.SerializeObject(productEligibilityRequest)}");
                productEligibilityRequest = orignalProductEligibilityRequest;
            }

            return productEligibilityRequest;
        }

        private bool IsEligiblePreExistingEndorsement(PreExistingConditionLimitTypeEnum request, List<RiderBenefitDto> ridersInfo)
        {
            var benefit = _productLibraryService.FixPreExistingConditionLimitationType(request);

            return ridersInfo.Any(c => c.Benefit == benefit);
        }

        public ProductEligibilityRequest GetNextAvailableEndorsementRider(ProductEligibilityRequest request)
        {
            var productEligibilityRequest = request;

            var PreExistingConditionRiders = new[] { PreExistingConditionLimitTypeEnum.None, PreExistingConditionLimitTypeEnum._3_12, PreExistingConditionLimitTypeEnum._6_12, PreExistingConditionLimitTypeEnum._12_12 };
            if (PreExistingConditionRiders.Contains(request.PreExistingConditionLimitTypeId))
            {
                productEligibilityRequest.OutcomeMessages.Add("Decreased from rider " + request.PreExistingConditionLimitTypeId);
                productEligibilityRequest.PreExistingConditionLimitTypeId = PreExistingConditionRiders.Skip(PreExistingConditionRiders.ToList().IndexOf(request.PreExistingConditionLimitTypeId) + 1).Take(1).FirstOrDefault();
            }

            return productEligibilityRequest;
        }
        private void VerifyOccClassAndPartialRiderCombination(ProductValidationRequest request, ProductValidationResult response)
        {
            bool hasPartialRider = request.BenefitValidationRequests.Any(c => c.BenefitType == BenefitTypeEnum.EnhancedPartialDisabilityRider || c.BenefitType == BenefitTypeEnum.BasicPartialDisabilityRider);

            bool isValid = _productLibraryService.OccClassAndDefOfDisabilityCheck(request.OccupationClass, request.DefinitionOfDisability, hasPartialRider, false);

            if (!isValid)
            {
                response.IsValid = false;
                response.ValidationMessages.Add("Verify definition of disability and partial rider combination");
            }
        }

        public ProductVariantTypeEnum GetProductVariantType(PricingTypeEnum pricingType, PlanDesignTypeEnum planDesignType)
        {
            Log.TraceFormat("+GetProductVariantType planDesignType={0}", planDesignType);
            ProductVariantTypeEnum ProductVariantType = new ProductVariantTypeEnum();
            switch (pricingType)
            {
                case PricingTypeEnum.PC2016:
                    ProductVariantType = planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan ? ProductVariantTypeEnum.RPP : ProductVariantTypeEnum.IDI;
                    break;
                case PricingTypeEnum.PC2019:
                    ProductVariantType = planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan ? ProductVariantTypeEnum.RPP2019 : ProductVariantTypeEnum.IDI2019;
                    break;
                case PricingTypeEnum.PC2023:
                    ProductVariantType = planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan ? ProductVariantTypeEnum.RPP2023 : ProductVariantTypeEnum.IDI2023;
                    break;
                default:
                    break;
            }

            Log.TraceFormat("-GetProductVariantType planDesignType={0}", planDesignType);
            return ProductVariantType;
        }

        public PricingTypeEnum GetPricingTypeEnum(int caseId)
        {
            Log.TraceFormat("+GetPricingTypeEnum caseId={0}", caseId);
            PricingTypeEnum pricingType = new PricingTypeEnum();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmscase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);

                var underwitingRequest = cmscase.CaseUnderwritingRequests.OrderByDescending(x => x.Id).FirstOrDefault();

                if (underwitingRequest != null && underwitingRequest.PricingType != null)
                {
                    pricingType = (PricingTypeEnum)underwitingRequest.PricingType;
                }
                else
                {
                    pricingType = PricingTypeEnum.PC2016;
                }
            }
            Log.TraceFormat("-GetPricingTypeEnum caseId={0}", caseId);
            return pricingType;
        }

        public ProductType GetProductType(PricingTypeEnum pricingTypeEnum)
        {
            var productType = ProductType.ProviderChoice2016;
            switch (pricingTypeEnum)
            {
                case PricingTypeEnum.PC2016:
                    productType = ProductType.ProviderChoice2016;
                    break;
                case PricingTypeEnum.PC2019:
                    productType = ProductType.ProviderChoice2019;
                    break;
                case PricingTypeEnum.PC2023:
                    productType = ProductType.ProviderChoice2023;
                    break;
            }
            return productType;
        }
    }
}