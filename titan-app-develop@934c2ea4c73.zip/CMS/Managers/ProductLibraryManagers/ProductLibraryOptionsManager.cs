﻿using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Integrations.ProductLibraryServices;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using System.Diagnostics;

namespace CMS.Managers.PlanManagers
{
    public class ProductLibraryOptionsManager : IProductLibraryOptionsManager
    {
        private readonly IProductLibraryService _productLibraryService;
        private BaseBenefitOptions _baseBenefitOptions;
        private readonly IProductLibraryManager _productLibraryManager;

        public ProductLibraryOptionsManager(IProductLibraryService productLibraryService, IProductLibraryManager productLibraryManager)
        {
            _productLibraryService = productLibraryService;
            _productLibraryManager = productLibraryManager;
        }

        public void Initialize(StateTypeEnum state, PlanDesignTypeEnum planDesignType, DefinitionOfDisabilityTypeEnum definitionOfDisability, bool isCompactState, PricingTypeEnum pricingType)
        {
            Log.TraceFormat("+Initialize planDesignType={0}", planDesignType);
            var productVariantId = _productLibraryManager.GetProductVariantType(pricingType, planDesignType);
            _baseBenefitOptions = _productLibraryService.GetBaseBenefitOptions((int)productVariantId, state, 35, GetOccupationClassType(definitionOfDisability), isCompactState , (int)pricingType);
            Log.TraceFormat("-Initialize planDesignType={0}", planDesignType);
        }

        public List<EliminationPeriodTypeEnum> GetEliminationPeriods(EliminationPeriodTypeEnum eliminationPeriod)
        {
            var eliminationPeriods = new[] { EliminationPeriodTypeEnum._090, EliminationPeriodTypeEnum._180, EliminationPeriodTypeEnum._360, EliminationPeriodTypeEnum._720 };
            return eliminationPeriods.SkipWhile(e => e != eliminationPeriod).ToList().Intersect(_baseBenefitOptions.EliminationPeriods.AsEnumerable()).ToList();
        }

        public List<EliminationPeriodTypeEnum> GetRPPEliminationPeriods(EliminationPeriodTypeEnum eliminationPeriod)
        {
            var eliminationPeriods = new[] { EliminationPeriodTypeEnum._180, EliminationPeriodTypeEnum._360 };
            return eliminationPeriods.SkipWhile(e => e != eliminationPeriod).ToList();
        }
        public List<BenefitPeriodTypeEnum> GetBenefitPeriods(BenefitPeriodTypeEnum benefitPeriod)
        {
            var benefitPeriods = new[] { BenefitPeriodTypeEnum.Y02, BenefitPeriodTypeEnum.Y05, BenefitPeriodTypeEnum.Y10, BenefitPeriodTypeEnum.A65, BenefitPeriodTypeEnum.A67, BenefitPeriodTypeEnum.V70 };
            var result = benefitPeriods.TakeWhile(b => b != benefitPeriod).ToList();
            result.Add(benefitPeriod);
            if (_baseBenefitOptions != null)
            {
                for (var index = 0; index < _baseBenefitOptions.BenefitPeriods.Count; index++)
                {
                    if (_baseBenefitOptions.BenefitPeriods[index] == BenefitPeriodTypeEnum.M24)
                    {
                        _baseBenefitOptions.BenefitPeriods[index] = BenefitPeriodTypeEnum.Y02;
                    }
                    else if (_baseBenefitOptions.BenefitPeriods[index] == BenefitPeriodTypeEnum.M60)
                    {
                        _baseBenefitOptions.BenefitPeriods[index] = BenefitPeriodTypeEnum.Y05;
                    }
                }
            }
            return result.Intersect(_baseBenefitOptions.BenefitPeriods.AsEnumerable()).ToList();
        }

        public List<DefinitionOfDisabilityTypeEnum> GetDefinitionOfDisabilities(DefinitionOfDisabilityTypeEnum definitionOfDisability)
        {
            var definitionOfDisabilities = new List<DefinitionOfDisabilityTypeEnum>();

            if (definitionOfDisability == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc ||
                definitionOfDisability == DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc ||
                definitionOfDisability == DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc)
                definitionOfDisabilities = new List<DefinitionOfDisabilityTypeEnum> { definitionOfDisability };

            if (definitionOfDisability == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty)
                definitionOfDisabilities = new List<DefinitionOfDisabilityTypeEnum> { DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty, DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc, DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation, DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc };

            if (definitionOfDisability == DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc)
                definitionOfDisabilities = new List<DefinitionOfDisabilityTypeEnum> { DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc, DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation, DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc };

            if (_productLibraryManager.FixDefinitionOfDisabilityTypeEnum(definitionOfDisability) == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupationME)
                definitionOfDisabilities = new List<DefinitionOfDisabilityTypeEnum> { DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation, DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc };

            return definitionOfDisabilities.Intersect(_productLibraryManager.FixDefinitionOfDisabilityTypeEnum(_baseBenefitOptions.DefinitionOfDisabilities).AsEnumerable()).ToList();
        }

        public List<MentalSubstanceLimitationEnum> GetMentalSubstances(MentalSubstanceLimitationEnum mentalSubstance, bool isCompactState, PlanDesignTypeEnum planDesignType, int stateId)
        {
            //var list = new List<MentalSubstanceLimitationEnum> { MentalSubstanceLimitationEnum._Nolimitation, MentalSubstanceLimitationEnum._24Month, MentalSubstanceLimitationEnum._12Month, MentalSubstanceLimitationEnum._6Month };

            var list = new[] { MentalSubstanceLimitationEnum._NA };

            if (stateId == (int)StateTypeEnum.CA)
            {
                list = new[] { MentalSubstanceLimitationEnum._Nolimitation, MentalSubstanceLimitationEnum._24Month };
            }
            else
            {

                if (isCompactState)
                {                   
                        list = new[] { MentalSubstanceLimitationEnum._Nolimitation, MentalSubstanceLimitationEnum._24Month, MentalSubstanceLimitationEnum._12Month };                                  
                }
                else
                {                    
                        list = new[] { MentalSubstanceLimitationEnum._Nolimitation, MentalSubstanceLimitationEnum._24Month, MentalSubstanceLimitationEnum._6Month };                                     
                }
            }

            if (planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                if (mentalSubstance == MentalSubstanceLimitationEnum._Nolimitation)
                {
                    return list.Reverse().ToList();
                }
                else if (mentalSubstance == MentalSubstanceLimitationEnum._12Month && isCompactState)
                {                    
                    list = new[] { MentalSubstanceLimitationEnum._12Month };
                    return list.ToList();
                }
                else if (mentalSubstance == MentalSubstanceLimitationEnum._6Month && !isCompactState)
                {
                    list = new[] { MentalSubstanceLimitationEnum._6Month };
                    return list.ToList();
                }
                else if (mentalSubstance == MentalSubstanceLimitationEnum._24Month)
                {
                    if (isCompactState)
                    {
                        list = new[] { MentalSubstanceLimitationEnum._24Month, MentalSubstanceLimitationEnum._12Month };
                        return list.Reverse().ToList();
                    }
                    else
                    {
                        if (stateId == (int)StateTypeEnum.CA)
                        {
                            list = new[] { MentalSubstanceLimitationEnum._24Month };
                        }
                        else
                        {
                            list = new[] { MentalSubstanceLimitationEnum._24Month, MentalSubstanceLimitationEnum._6Month };
                        }
                        return list.Reverse().ToList();
                    }
                }               
                else
                {
                    return list.Reverse().SkipWhile(e => e != mentalSubstance).Intersect(_baseBenefitOptions.MentalSubstances.AsEnumerable().Reverse()).ToList();
                }
            }
            else
            {
                return list.SkipWhile(e => e != mentalSubstance).Intersect(_baseBenefitOptions.MentalSubstances.AsEnumerable()).ToList();
            }
        }

        public List<PreExistingConditionLimitTypeEnum> GetPreExistingConditionLimits(PreExistingConditionLimitTypeEnum condition, ProductValidationRequest request, int? pricingType)
        {
            Log.TraceFormat("+GetPreExistingConditionLimits pricingType={0}", pricingType);
            var definitionOfDisability = _productLibraryManager.FixDefinitionOfDisabilityTypeEnum(request.DefinitionOfDisability);

            Stopwatch st4 = new Stopwatch();
            st4.Start();
            var stateAvailableRiders = _productLibraryService.GetAvailableRidersInformation(
                   (int)request.ProductVariantId,
                   request.Age,
                   request.State,
                   definitionOfDisability,
                   request.EliminationPeriod,
                   _productLibraryService.FixBenefitPeriod(request.BenefitPeriod),
                   request.MentalSubstanceLimitation,
                   request.OccupationClass, request.IsCompactState, pricingType);

            st4.Stop();

            Log.Debug($"GetAvailableRidersInformation took : '{st4.Elapsed.TotalSeconds}' seconds ('{st4.Elapsed.TotalMilliseconds}' milliseconds) to execute.");
            st4.Reset();
            var preExistingCondEndorsement = _productLibraryManager.GetPreExistingConditionLimitEndorsement();

            var stateAvailablepreExistingCondEndorsements = stateAvailableRiders.Where(c => c.BenefitGroup == BenefitGroupTypeEnum.Endorsement
                                                                && preExistingCondEndorsement.Contains(c.Benefit)).ToList();

            var list = new List<PreExistingConditionLimitTypeEnum>();
            foreach (var preEndorsement in stateAvailablepreExistingCondEndorsements)
            {
                switch (preEndorsement.Benefit)
                {
                    case BenefitTypeEnum.PreExistingConditionLimitationEndorsementNoPrex:
                        list.Add(PreExistingConditionLimitTypeEnum.None);
                        continue;
                    case BenefitTypeEnum.PreExistingConditionLimitationEndorsementPrex3:
                        list.Add(PreExistingConditionLimitTypeEnum._3_12);
                        continue;
                    case BenefitTypeEnum.PreExistingConditionLimitationEndorsementPrex6:
                        list.Add(PreExistingConditionLimitTypeEnum._6_12);
                        continue;
                    case BenefitTypeEnum.PreExistingConditionLimitationEndorsementPrex12:
                        list.Add(PreExistingConditionLimitTypeEnum._12_12);
                        continue;
                }
            }

            Log.TraceFormat("-GetPreExistingConditionLimits pricingType={0}", pricingType);
            return list.SkipWhile(e => e != condition).ToList();
        }
        
        public RiderApprovedOptions GetRiderOptions(BenefitTypeEnum benefitType, EliminationPeriodTypeEnum? eliminationPeriod, BenefitPeriodTypeEnum? benefitPeriod, decimal? amount)
        {
            var result = new RiderApprovedOptions { BenefitType = benefitType, EliminationPeriod = eliminationPeriod, BenefitPeriod = benefitPeriod };

            var partialRiders = new[] { BenefitTypeEnum.Unknown, BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider, BenefitTypeEnum.BasicPartialDisabilityRider, BenefitTypeEnum.EnhancedPartialDisabilityRider };
            if (partialRiders.Contains(benefitType))
            {
                result.Benefits = partialRiders.TakeWhile(p => p != benefitType).ToList();
                result.Benefits.Add(benefitType);
            }

            var catRiders = new[] { BenefitTypeEnum.Unknown, BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider, BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider };
            if (catRiders.Contains(benefitType))
            {
                result.Benefits = catRiders.TakeWhile(p => p != benefitType).ToList();
                result.ApprovedAmountMin = 1000;
                result.ApprovedAmountMax = amount;
                result.Benefits.Add(benefitType);
            }

            var colaRiders = new[] { BenefitTypeEnum.Unknown, BenefitTypeEnum.CostOfLiving4YearDelayed, BenefitTypeEnum.CostOfLiving3PercentCompound, BenefitTypeEnum.CostOfLiving6PercentMaximum };
            if (colaRiders.Contains(benefitType))
            {
                result.Benefits = colaRiders.TakeWhile(p => p != benefitType).ToList();
                //D-01299 
                if (benefitType == BenefitTypeEnum.CostOfLiving4YearDelayed)
                {
                    result.Benefits.Add(BenefitTypeEnum.CostOfLiving3PercentCompound);
                }
                result.Benefits.Add(benefitType);
            }

            if (benefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit)
            {
                result.Benefits = null;

                if (eliminationPeriod != null)
                {
                    var eliminationPeriods = new[] { EliminationPeriodTypeEnum._180, EliminationPeriodTypeEnum._360, EliminationPeriodTypeEnum._UN };
                    result.EliminationPeriods = eliminationPeriods.SkipWhile(e => e != eliminationPeriod.Value).ToList();
                }
                result.ApprovedAmountMin = 250;
                result.ApprovedAmountMax = amount;
            }

            if (benefitType == BenefitTypeEnum.StudentLoanProtection || benefitType == BenefitTypeEnum.SupplementalBenefitTermRider)
            {
                result.Benefits = null;

                if (eliminationPeriod != null)
                {
                    var eliminationPeriods = new[] { EliminationPeriodTypeEnum._090, EliminationPeriodTypeEnum._180 };
                    result.EliminationPeriods = eliminationPeriods.SkipWhile(e => e != eliminationPeriod.Value).ToList();
                }
                if (benefitPeriod != null)
                {
                    //D-01301  && D-01303
                    var benefitPeriods = new[] { BenefitPeriodTypeEnum.Y15, BenefitPeriodTypeEnum.Y10 };
                    result.BenefitPeriods = benefitPeriods.SkipWhile(e => e != benefitPeriod.Value).ToList();
                }
                result.ApprovedAmountMin = 250;
                result.ApprovedAmountMax = amount;
            }

            if (benefitType == BenefitTypeEnum.UnemploymentPremiumWaiver)
            {
                result.Benefits = null;
                result.ApprovedAmountMin = amount;
                result.ApprovedAmountMax = amount;
            }

            return result;
        }

        private OccupationClassTypeEnum GetOccupationClassType(DefinitionOfDisabilityTypeEnum definitionOfDisability)
        {
            if (definitionOfDisability == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc)
            {
                return OccupationClassTypeEnum._6M;
            }
            else if (definitionOfDisability == DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc)
            {
                return OccupationClassTypeEnum._4D;
            }
            else
            {
                return OccupationClassTypeEnum._6;
            }
        }
    }
}