﻿using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Integrations.ProductLibraryServices;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Model.Extensions;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.ProductLibraryManagers
{
    public class ProductLibraryRiderDowngradeRules
    {
        public ProductEligibilityRiderResponse GetRiderEligibility(List<RiderBenefitDto> ridersInfo, ProductEligibilityRiderRequest request)
        {
            var requestResponse = ValidateEligibleRiderBenefit(ridersInfo, request);

            while (!requestResponse.Value.IsEligible)
            {
                var nextRequest = GetNextAvailableRider(request);
                if (nextRequest.Equals(request) || nextRequest.BenefitType == BenefitTypeEnum.Unknown)
                {
                    request.OutcomeMessages.Add("There is not a valid decreased option for that rider - " + request.BenefitType.GetDescription() + " - it will be removed. ");
                    break;
                }
                request = nextRequest;
                requestResponse = ValidateEligibleRiderBenefit(ridersInfo, request);
            }

            var response = new ProductEligibilityRiderResponse
            {
                OutcomeMessages = request.OutcomeMessages,
                BenefitType = request.BenefitType,
                BenefitAmount = request.BenefitAmount,
                BenefitPeriodTypeId = request.BenefitPeriodTypeId,
                InsuredAge = request.InsuredAge,
                RiderBenefitPeriodTypeId = request.RiderBenefitPeriodTypeId,
                RiderEliminationPeriodTypeId = request.RiderEliminationPeriodTypeId,
                BenefitGroupType = request.BenefitGroupType,
            };
            response.IsEligible = requestResponse.Value.IsEligible;

            return response;
        }

        private ProductEligibilityRiderRequest GetNextAvailableRider(ProductEligibilityRiderRequest request)
        {
            var productEligibilityRiderRequest = request;

            var partialRiders = new[] { BenefitTypeEnum.EnhancedPartialDisabilityRider, BenefitTypeEnum.BasicPartialDisabilityRider, BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider };
            if (partialRiders.Contains(request.BenefitType))
            {
                productEligibilityRiderRequest.OutcomeMessages.Add("Decreased from rider " + request.BenefitType.GetDescription());
                productEligibilityRiderRequest.BenefitType = partialRiders.Skip(partialRiders.ToList().IndexOf(request.BenefitType) + 1).Take(1).FirstOrDefault();
            }

            var catRiders = new[] { BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider, BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider };
            if (catRiders.Contains(request.BenefitType))
            {
                productEligibilityRiderRequest.OutcomeMessages.Add("Decreased from rider " + request.BenefitType.GetDescription());
                productEligibilityRiderRequest.BenefitType = catRiders.Skip(catRiders.ToList().IndexOf(request.BenefitType) + 1).Take(1).FirstOrDefault();
            }

            var colaRiders = new[] { BenefitTypeEnum.CostOfLiving6PercentMaximum, BenefitTypeEnum.CostOfLiving3PercentCompound, BenefitTypeEnum.CostOfLiving4YearDelayed };
            if (colaRiders.Contains(request.BenefitType))
            {
                productEligibilityRiderRequest.OutcomeMessages.Add("Decreased from rider " + request.BenefitType.GetDescription());
                productEligibilityRiderRequest.BenefitType = colaRiders.Skip(colaRiders.ToList().IndexOf(request.BenefitType) + 1).Take(1).FirstOrDefault();
            }

            if (request.BenefitType == BenefitTypeEnum.StudentLoanProtection && request.OutcomeMessages.Count == 0)
            {
                productEligibilityRiderRequest.OutcomeMessages.Add("Changed benefit from " + request.BenefitType.GetDescription() + " to " + BenefitTypeEnum.SupplementalBenefitTermRider);
                productEligibilityRiderRequest.BenefitType = BenefitTypeEnum.SupplementalBenefitTermRider;
            }

            if (request.BenefitType == BenefitTypeEnum.SupplementalBenefitTermRider && request.OutcomeMessages.Count == 0)
            {
                productEligibilityRiderRequest.OutcomeMessages.Add("Changed benefit from " + request.BenefitType.GetDescription() + " to " + BenefitTypeEnum.StudentLoanProtection);
                productEligibilityRiderRequest.BenefitType = BenefitTypeEnum.StudentLoanProtection;
            }
            return productEligibilityRiderRequest;
        }

        private ProductEligibilityRiderRequest? ValidateEligibleRiderBenefit(List<RiderBenefitDto> ridersInfo, ProductEligibilityRiderRequest request)
        {
            ProductEligibilityRiderRequest? resultRequest = request;

            var riderAvailable = ridersInfo.FirstOrDefault(c => c.Benefit == request.BenefitType);

            if (riderAvailable != null)
            {

                if (request.BenefitType == BenefitTypeEnum.EnhancedPartialDisabilityRider
                    || request.BenefitType == BenefitTypeEnum.BasicPartialDisabilityRider
                    || request.BenefitType == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                {
                    resultRequest = ValidatePartialResidualDisability(request);
                }

                else if (request.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider
                         || request.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                {
                    resultRequest = ValidateCat(request);
                }
                else if (request.BenefitType == BenefitTypeEnum.CostOfLiving6PercentMaximum
                         || request.BenefitType == BenefitTypeEnum.CostOfLiving3PercentCompound || request.BenefitType == BenefitTypeEnum.CostOfLiving4YearDelayed)
                {
                    resultRequest = ValidateCola(request);
                }
                else if (request.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit)
                {
                    resultRequest = ValidateRpp(request);
                }
                else if (request.BenefitType == BenefitTypeEnum.StudentLoanProtection || request.BenefitType == BenefitTypeEnum.SupplementalBenefitTermRider)
                {
                    resultRequest = ValidateTermRiders(request);
                }
                else if (request.BenefitType == BenefitTypeEnum.UnemploymentPremiumWaiver || request.BenefitType == BenefitTypeEnum.LumpSumIndemnityRider)
                {
                    resultRequest = ValidateLumpSumAndUnemployment(request);
                }
                else if (request.BenefitType == BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement)
                {
                    request.IsEligible = true;
                    resultRequest = request;
                }
            }
            return resultRequest;
        }

        private ProductEligibilityRiderRequest ValidateTermRiders(ProductEligibilityRiderRequest request)
        {
            if (request.InsuredAge >= 46 && request.RiderBenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10)
            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }

            else if (request.InsuredAge >= 41 && request.RiderBenefitPeriodTypeId == BenefitPeriodTypeEnum.Y15)
            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }
            else
            {
                request.IsEligible = true;
            }
            return request;
        }
        private ProductEligibilityRiderRequest ValidateLumpSumAndUnemployment(ProductEligibilityRiderRequest request)
        {
            if (request.InsuredAge >= 56
                && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05
                || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65
                || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A67 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.V70))
            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age  " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }
            else
            {
                request.IsEligible = true;
            }
            return request;
        }

        private ProductEligibilityRiderRequest ValidateRpp(ProductEligibilityRiderRequest request)
        {
            if (request.InsuredAge >= 63
                && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05
                || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65
                || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A67 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.V70))
            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age  " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }
            else
            {
                request.IsEligible = true;
            }
            return request;
        }

        private ProductEligibilityRiderRequest ValidateCola(ProductEligibilityRiderRequest request)
        {
            if ((request.BenefitType == BenefitTypeEnum.CostOfLiving6PercentMaximum
                || request.BenefitType == BenefitTypeEnum.CostOfLiving3PercentCompound)
                && request.InsuredAge >= 63
                && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05
                    || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65))

            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age  " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }
            else if (request.BenefitType == BenefitTypeEnum.CostOfLiving4YearDelayed
                     && request.InsuredAge >= 61
                     && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05
                         || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65))

            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age  " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }

            else if ((request.BenefitType == BenefitTypeEnum.CostOfLiving6PercentMaximum
                     || request.BenefitType == BenefitTypeEnum.CostOfLiving3PercentCompound)
                     && request.InsuredAge >= 65
                     && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A67 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.V70))

            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age  " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }
            else if (request.BenefitType == BenefitTypeEnum.CostOfLiving4YearDelayed
                     && request.InsuredAge >= 63
                     && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A67 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.V70))

            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }
            else
            {
                request.IsEligible = true;
            }
            return request;
        }

        private ProductEligibilityRiderRequest ValidateCat(ProductEligibilityRiderRequest request)
        {
            if (request.InsuredAge >= 65
                && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05
                    || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65))
            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }

            else if (request.InsuredAge >= 67
                     && (request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A67 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.V70))

            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }
            else
            {
                request.IsEligible = true;
            }
            return request;
        }

        private ProductEligibilityRiderRequest ValidatePartialResidualDisability(ProductEligibilityRiderRequest request)
        {
            if ((request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y02 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y05
                 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.Y10 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A65
                 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.A67 || request.BenefitPeriodTypeId == BenefitPeriodTypeEnum.V70)
                && request.InsuredAge >= 67)
            {
                request.IsEligible = false;
                request.OutcomeMessages.Add("Rider to be removed due to Insured Age " + request.InsuredAge + " and Benefit period  " + request.BenefitPeriodTypeId.GetDescription());
            }
            else
            {
                request.IsEligible = true;
            }
            return request;
        }
    }
}