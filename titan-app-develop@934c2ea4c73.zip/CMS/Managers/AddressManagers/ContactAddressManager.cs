﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.AddressManagers;
using CMS.Model.Entities;
using Common.Exceptions;
using Logger.Static;
using System.Collections.Generic;
using System.Linq;


namespace CMS.Managers.AddressManagers
{
    public class AddressManager : IAddressManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public AddressManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }
        public List<AddressDto> GetAddressContactDetails(int caseId)
        {
            Log.TraceFormat("+GetAddressContactDetails caseId={0}", caseId);

            var addressDtoList = new List<AddressDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var address = unitOfWork.Repository<Address>().Linq().Where(c => c.Case.Id == caseId);
                if (address == null) throw new ValidationException("Case not found!");
                addressDtoList = address.Select(c => new AddressDto {
                    AddressId = c.Id,
                    CaseId = c.Case.Id,
                    ContactRoleTypeId = c.ContactRoleType != null ? c.ContactRoleType.Id : 0,
                    ContactName = c.ContactName,
                    AddressCategory = c.AddressCategories.Select(x => new AddressCategoryDto {
                        AddressCategoryId = x.Id,
                        IsPrimary = x.IsPrimary,
                        AddressId = x.Address.Id,
                        IsSelected = x.IsSelect,
                        AddressCategoryTypeId = x.AddressCategoryType != null ? x.AddressCategoryType.Id : 0
                    }).ToList()
                }).ToList();
                
            }
            Log.TraceFormat("-GetAddressContactDetails caseId={0}", caseId);
            return addressDtoList;
        }
    }
}
