namespace CMS.Managers.GAMessageManagers
{
    public class GaIncomingMessage
    {
        public string MessageId { get; set; }
        public string MessageType { get; set; }
        public string GACaseId { get; set; }
        public string GAPDRId { get; set; }
        public string GACensusInfoId { get; set; }
        public string TitanCaseId { get; set; }
        public string GACaseSubmissionId { get; set; }
        public dynamic Payload { get; set; }
    }
}