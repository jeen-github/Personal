﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.QueueMessagingServices;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.CensusManagers;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Interfaces.Managers.GAMessageManagers;
using CMS.Interfaces.Managers.GAMessageManagers.OutgoingMessages;
using CMS.Interfaces.Managers.LookupManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.TaskManagers;
using CMS.Managers.GAMessageManagers.IncomingMessageHandlers;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.IO;
using CMS.Interfaces.Managers.BusinessManagers;

namespace CMS.Managers.GAMessageManagers
{
    public class GaMessageManager : IGaMessageManager
    {
        public IQueueMessagingClient QueueMessagingClient { get; set; }
        public IUnitOfWorkFactory UnitOfWorkFactory { get; set; }
        public ICaseManager CaseManager { get; set; }
        public ICompanyManager CompanyManager { get; set; }
        public ICaseExistingCoverageManager ExistingCoverageManager { get; set; }
        public ICaseBrokerManager BrokerManager { get; set; }
        public ITaskManager TaskManager { get; set; }
        public IPlanDesignRequestManager PlanDesignRequestManager { get; set; }
        public ICensusManager CensusManager { get; set; }
        public ILookupManager LookupManager { get; set; }
        public IIllustrationManager IllustrationManager { get; set; }
        public IDocumentManager DocumentManager { get; set; }
        public IWholesalerManager WholesalerManager { get; set; }

        public GaMessageManager(
            IQueueMessagingClient queueMessagingClient,
            IUnitOfWorkFactory unitOfWorkFactory,
            ICaseManager caseManager,
            ICompanyManager companyManager,
            ICaseExistingCoverageManager existingCoverageManager,
            ICaseBrokerManager brokerManager,
            ITaskManager taskManager,
            IPlanDesignRequestManager planDesignRequestManager,
            ICensusManager censusManager, ILookupManager lookupManager,
            IIllustrationManager illustrationManager,
            IDocumentManager documentManager,
            IWholesalerManager wholesalerManager)
        {
            QueueMessagingClient = queueMessagingClient;
            UnitOfWorkFactory = unitOfWorkFactory;
            CaseManager = caseManager;
            CompanyManager = companyManager;
            ExistingCoverageManager = existingCoverageManager;
            BrokerManager = brokerManager;
            TaskManager = taskManager;
            PlanDesignRequestManager = planDesignRequestManager;
            CensusManager = censusManager;
            LookupManager = lookupManager;
            IllustrationManager = illustrationManager;
            DocumentManager = documentManager;
            WholesalerManager = wholesalerManager;
        }

        public void PullAndProcessMessage()
        {
            string messageString;
            if (Debugger.IsAttached)
            {
                messageString = File.ReadAllText(@"D:\IndividualDisability\Development\CMS\Main\CMS\Managers\GAMessageManager\EMPCENSUSINFO.txt");
                //messageString = File.ReadAllText(@"D:\IndividualDisability\Development\CMS\Main\CMS\Managers\GAMessageManager\CENSUSINFO.txt");
                messageString = File.ReadAllText(@"D:\IndividualDisability\Development\CMS\Main\CMS\Managers\GAMessageManager\EMPCENSUSINFO - C37867.txt");
            }
            else
            {
                messageString = PullMessageFromQueue();
            }

                     

            if (string.IsNullOrEmpty(messageString))
            {
                //Log.Info("No message in the GA queue");
                return;
            }

            ProcessMessage(messageString);
        }

        private string PullMessageFromQueue()
        {
            var message = string.Empty;

            try
            {
                message = QueueMessagingClient.PullMessage();
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR pulling message from GA queue", ex);
            }

            return message;
        }

        public void ProcessMessage(string messageString)
        {
            Log.TraceFormat("+ProcessMessage");

            var messageHistoryManager = new GaMessageHistoryManager(UnitOfWorkFactory);

            try
            {
                messageHistoryManager.SaveMessageToHistory(messageString);

                var message = GaIncomingMessageParser.ParseMessageHeader(messageString);

                messageHistoryManager.UpdateMessageHistory(message);

                var messageHandlerFactory = new IncomeMessageHandlerFactory(this);
                var handler = messageHandlerFactory.CreateMessageHandler(message);
                handler.ProcessMessage(message);

                messageHistoryManager.UpdateMessageHistoryWithSuccess();
            }
            catch (Exception ex)
            {
                Log.FatalFormat("ERROR processing message from GA queue", ex);
                messageHistoryManager.UpdateMessageHistory(ex);
            }

            Log.TraceFormat("-ProcessMessage");
        }

        public void SendMessage(GaOutgoingMessage message)
        {
            Log.TraceFormat("+SendMessage");

            var messageHistoryManager = new GaMessageHistoryManager(UnitOfWorkFactory);

            try
            {
                var messageString = JsonConvert.SerializeObject(message);

                messageHistoryManager.SaveMessageToHistory(messageString, message);

                QueueMessagingClient.PushMessage(messageString);

                messageHistoryManager.UpdateMessageHistoryWithSuccess();
            }
            catch (Exception ex)
            {
                Log.FatalFormat("ERROR pushing message to GA queue", ex);
                messageHistoryManager.UpdateMessageHistory(ex);
            }

            Log.TraceFormat("-SendMessage");
        }
    }
}