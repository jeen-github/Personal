﻿using System;
using CMS.Interfaces.Managers.GAMessageManagers;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using CMS.Model.Entities;
using Logger.Static;
using CMS.Interfaces.Managers.CensusManagers;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Model.Enums;
using CMS.Interfaces.DataAccess;
using System.Threading;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.CensusMessageHandler
{
    public class SaveCensusMessageHandler : MessageHandlerBase
    {
        private readonly IGaMessageManager _gaMessageManager;
        public const int ThreadSleepSecs = 30000;
        public SaveCensusMessageHandler(IGaMessageManager gaMessageManager) : base(gaMessageManager)
        {
            _gaMessageManager = gaMessageManager;
        }

        public override bool CanHandle(GaIncomingMessage header)
        {
            return header.MessageType.Equals("CENSUSINFO", StringComparison.InvariantCultureIgnoreCase)
                || header.MessageType.Equals("EMPCENSUSINFO", StringComparison.InvariantCultureIgnoreCase);
        }

        public override void ProcessMessage(GaIncomingMessage messageString)
        {
            Log.Trace("+SaveCensusMessageHandler.ProcessMessage");

            if (string.IsNullOrEmpty(messageString.GACaseId))
            {
                Log.WarnFormat("GACaseId is null or empty");
                return;
            }

            if (!messageString.MessageType.Equals("EMPCENSUSINFO"))
            {
                if (string.IsNullOrEmpty(messageString.GAPDRId))
                {
                    Log.WarnFormat("GAPDRId is null or empty");
                    return;
                }

                if (string.IsNullOrEmpty(messageString.GACensusInfoId))
                {
                    Log.WarnFormat("GACensusInfoId is null or empty");
                    return;
                }
            }
            if (messageString.Payload == null)
            {
                Log.WarnFormat("Payload is null or empty");
                return;
            }

            IList<Payload> message = JsonConvert.DeserializeObject<IList<Payload>>(messageString.Payload.ToString());

            using (var unitOfWork = _gaMessageManager.UnitOfWorkFactory.CreateUnitOfWork())
            {
                
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.GACaseId == messageString.GACaseId);
                if (cmsCase == null)
                {
                    cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.CaseNumber == messageString.GACaseId);
                    if (cmsCase == null)
                    {
                        Log.WarnFormat("Not received Case information for the census.");
                        return;
                    }
                }


                if (messageString.MessageType.Equals("CENSUSINFO"))
                {
                    Log.Trace("+SaveCensusMessageHandler.CensusMessage Processed before processing PDR message");

                    try
                    {
                        for (var noOfRetry = 1; noOfRetry < 6; noOfRetry++)
                        {
                            Log.Trace(string.Format("+SaveCensusMessageHandler.CensusMessage : Processing CensusMessage message GaCaseId {0} GaPDRId: {1} RetryCount: {2}", messageString.GACaseId, messageString.GAPDRId, noOfRetry));

                            var messageHistoryPdrStatus = unitOfWork.Repository<GaMessageHistory>().Linq()
                                                    .Any(c => c.GaCaseId == messageString.GACaseId && c.GaPDRId == messageString.GAPDRId
                                                    && c.ProcessEndTime != null && c.MessageType.Trim().ToUpper() == "NewPDR" && c.IsSuccessIndicator == true);
                            if (messageHistoryPdrStatus)
                            {
                                Log.Trace(string.Format("+SaveCensusMessageHandler.CensusMessage : Processing CensusMessage message GaCaseId {0} GaPDRId: {1} RetryCount: {2} SucessStatus: {2}", messageString.GACaseId, messageString.GAPDRId, noOfRetry, messageHistoryPdrStatus));
                                break;
                            }
                            else
                            {
                                //Delay
                                Log.TraceFormat(string.Format("+SaveCensusMessageHandler.CensusMessage: Wait added for {0} seconds.", ThreadSleepSecs));
                                Thread.Sleep(ThreadSleepSecs);
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        Log.Error("+SaveCensusMessageHandler.CensusMessage - " + ex);
                    }
                }

                var planDesignRequest = cmsCase.PlanDesignRequests.FirstOrDefault(c => c.GAPlanDesignRequestId == messageString.GAPDRId);

                var isEmployerCensus = messageString.MessageType.Equals("EMPCENSUSINFO");
                Log.TraceFormat("isEmployerCensus={0}", isEmployerCensus);
                if (isEmployerCensus)
                {
                    // assign the last sold PDR if there is one
                    planDesignRequest = cmsCase.PlanDesignRequests.Where(c => c.GAPlanDesignRequestId == messageString.GAPDRId).FirstOrDefault();

                    if (planDesignRequest == null)
                    {
                        Log.TraceFormat("+SaveCensusMessageHandler.ProcessMessage: Processing EmployerCensus file: GAPdrID not found in Titan, switching to alternate query. TitanCaseId:{0} GAPdrId:{1}", cmsCase.Id, messageString.GAPDRId);
                        int pdrId = 0;
                        int.TryParse(messageString.GAPDRId, out pdrId);
                        planDesignRequest = cmsCase.PlanDesignRequests.Where(c => c.Id == pdrId).FirstOrDefault();
                        if (planDesignRequest != null)
                        {
                            Log.TraceFormat("+SaveCensusMessageHandler.ProcessMessage: Processing EmployerCensus file: GAPdrID found in alternate search. TitanCaseId:{0} TitanPdrId:{1}", cmsCase.Id, pdrId);
                        }
                        else
                        {
                            Log.TraceFormat("+SaveCensusMessageHandler.ProcessMessage: Processing EmployerCensus file: GAPdrID not found. TitanCaseId:{0} TitanPdrId:{1}", cmsCase.Id, pdrId);
                        }
                    }
                }

                var censusDto = new CensusDto
                {
                    CaseId = cmsCase.Id,
                    GACensusId = messageString.GACensusInfoId,
                    PlanDesignRequestId = planDesignRequest != null ? planDesignRequest.Id : -1,
                    ReceivedDateTime = DateTime.Now,
                    IsActiveIndicator = !isEmployerCensus, // the employer censuses are always marked as Inactive
                    GAPlanDesignRequestId = messageString.GAPDRId
                };

                Log.TraceFormat("+SaveCensusMessageHandler.ProcessMessage: CaseId:{0} PdrId:{1} ", censusDto.CaseId, censusDto.PlanDesignRequestId);

                censusDto.CensusParticipants = BuildCensusParticipants(message, censusDto.CensusId);

                _gaMessageManager.CensusManager.SaveCensusInfo(censusDto, isEmployerCensus);

            }

            Log.Trace("-SaveCensusMessageHandler.ProcessMessage");
        }

        private List<CensusParticipantDto> BuildCensusParticipants(IList<Payload> message, int censusId)
        {
            var censusParticipants = new List<CensusParticipantDto>();
            int mostRecentYear = DateTime.Now.Year;
            int priorYear = mostRecentYear - 1;
            int additionalYear = priorYear - 1;
            bool? isOwner = null;

            foreach (var participant in message)
            {
                var censusParticipantDto = new CensusParticipantDto();              
                bool? hasCitizenship = false;
                bool? isMicrositeAccess = true;

                censusParticipantDto.CensusId = censusId;
                censusParticipantDto.EligibleClass = participant.eligiblePDRClass.ToString();
                censusParticipantDto.EmployeeId = participant.employeeID;

                censusParticipantDto.FirstName = participant.employeeFirstName != null ? participant.employeeFirstName.Trim() : null;
                censusParticipantDto.LastName = participant.employeeLastName != null ? participant.employeeLastName.Trim() : null;
                censusParticipantDto.MiddleInitial = participant.employeeMiddleInitial != null ? participant.employeeMiddleInitial.Trim() : null;
                censusParticipantDto.Suffix = participant.employeeSuffix != null ? participant.employeeSuffix.Trim() : null;

                censusParticipantDto.HomeStreet1 = participant.homeAddressStreet1;
                censusParticipantDto.HomeStreet2 = participant.homeAddressStreet2;
                censusParticipantDto.HomeCity = participant.homeAddressCity;
                censusParticipantDto.HomeStateDescription = participant.homeAddressState != null ? participant.homeAddressState.Trim() : null;
                censusParticipantDto.HomeZipCode = participant.homeAddressZipCode != null ? participant.homeAddressZipCode.PadLeft(5, '0') : null;
                censusParticipantDto.WorkStreet1 = participant.workAddressStreet1;
                censusParticipantDto.WorkStreet2 = participant.workAddressStreet2;
                censusParticipantDto.WorkCity = participant.workAddressCity;
                censusParticipantDto.WorkStateDescription = participant.workAddressState != null ? participant.workAddressState.Trim().ToUpper() : null;
                censusParticipantDto.WorkStreet1 = participant.workAddressStreet1;
                censusParticipantDto.WorkZipCode = participant.workAddressZipCode != null ? participant.workAddressZipCode.PadLeft(5, '0') : null;
                censusParticipantDto.WorkLocationPhone = participant.workPhone;
                censusParticipantDto.WorkLocationExtension = participant.workExtension;
                censusParticipantDto.WorkEmail = participant.businessEmailAddress;
                censusParticipantDto.WorkStopCode = participant.workMailStop;

                censusParticipantDto.DateOfBirth = GetDateTimeValue(participant.dateOfBirth);
                censusParticipantDto.DateOfHire = GetDateTimeValue(participant.dateOfHire);
                censusParticipantDto.Gender = string.IsNullOrEmpty(participant.gender) ? string.Empty : GetGender(participant.gender);
                censusParticipantDto.JobTitle = participant.occupation;
                censusParticipantDto.BoardCertification = participant.boardCertification;

                censusParticipantDto.MostRecentPaidBonusAmount = participant.mostRecentYearPaidBonus;
                censusParticipantDto.PriorPaidBonusAmount = participant.priorYearBonus;
                censusParticipantDto.AdditionalPriorPaidBonusAmount = participant.additionalPriorYearBonus;
                censusParticipantDto.MostRecentPaidCommissionAmount = participant.mostRecentYearPaidCommissions;
                censusParticipantDto.PriorPaidCommissionAmount = participant.priorYearCommissions;
                censusParticipantDto.AdditionalPriorPaidCommissionAmount = participant.additionalPriorYearCommissions != null ? (decimal)GetIntValue(participant.additionalPriorYearCommissions.ToString()) : (decimal?)null;
                censusParticipantDto.MostRecentPaidK1IncomeAmount = participant.mostRecentYearPaidK1Income;
                censusParticipantDto.PriorPaidK1IncomeAmount = participant.priorYearK1Income;
                censusParticipantDto.AdditionalPriorPaidK1IncomeAmount = participant.additionalPriorK1Income;
                censusParticipantDto.OtherIncomeAmount = participant.otherIncome;
                censusParticipantDto.TotalEmployerOrEmployeeRetirementContributionAmount = participant.totalEmployerEmployeeRetirementContributions;

                censusParticipantDto.GroupLTDClass = participant.groupLTDClassWithinYourCompany;

                censusParticipantDto.IDICarrier1Description = participant.otherIDICarrier1;
                censusParticipantDto.IDIBenefitAmount1 = participant.otherIDIBenefitAmount1;
                censusParticipantDto.IDIToBeReplaced1 = GetIDICoverageReplaceFlag(participant.isOtherIDIcoveragetobeReplaced1);
                censusParticipantDto.IDIToBeReplacedAmount1 = participant.amountofCoveragetobeReplaced1;
                censusParticipantDto.IDIPolicyNumber1 = participant.policyofCoveragetobeReplaced1;
                censusParticipantDto.IDICarrier2Description = participant.otherIDICarrier2;
                censusParticipantDto.IDIBenefitAmount2 = participant.otherIDIBenefitAmount2;
                censusParticipantDto.IDIToBeReplaced2 = GetIDICoverageReplaceFlag(participant.isOtherIDIcoveragetobeReplaced2);
                censusParticipantDto.IDIToBeReplacedAmount2 = participant.amountofCoveragetobeReplaced2;
                censusParticipantDto.IDIPolicyNumber2 = participant.policyofCoveragetobeReplaced2;
                censusParticipantDto.IDICarrier3Description = participant.otherIDICarrier3;
                censusParticipantDto.IDIBenefitAmount3 = participant.otherIDIBenefitAmount3;
                censusParticipantDto.IDIToBeReplaced3 = GetIDICoverageReplaceFlag(participant.isOtherIDIcoveragetobeReplaced3);
                censusParticipantDto.IDIToBeReplacedAmount3 = participant.amountofCoveragetobeReplaced3;
                censusParticipantDto.IDIPolicyNumber3 = participant.policyofCoveragetobeReplaced3;

                censusParticipantDto.BenefitDeductionFrequencyDescription = participant.benefitDeductionFrequency != null ? participant.benefitDeductionFrequency.Trim() : string.Empty;
                censusParticipantDto.Age = (!string.IsNullOrEmpty(participant.dateOfBirth) ? (DateTime.Now.Year - (int?)GetDateTimeValue(participant.dateOfBirth).Value.Year) : null);
                censusParticipantDto.MostRecentSalaryAmount = participant.currentYearSalary;
                censusParticipantDto.EmploymentStatus = participant?.employmentStatus?.Trim();

                censusParticipantDto.OtherDisabilityInformation = participant.otherDisabilityInformation;
                if (participant.owner != null && participant.owner != string.Empty)
                {
                    if (participant.owner.ToLower().Trim() == "yes" || participant.owner.ToLower().Trim() == "y" || participant.owner.ToLower().Trim() == "true" || participant.owner.ToLower().Trim() == "1" || participant.owner.ToLower().Trim() == "t")
                    {
                        isOwner = true;
                    }
                    if (participant.owner.ToLower().Trim() == "no" || participant.owner.ToLower().Trim() == "n" || participant.owner.ToLower().Trim() == "false" || participant.owner.ToLower().Trim() == "0" || participant.owner.ToLower().Trim() == "f")
                    {
                        isOwner = false;
                    }
                }
                censusParticipantDto.IsOwnerIndicator = isOwner;

                censusParticipantDto.MostRecentPaidBonusYear = mostRecentYear;
                censusParticipantDto.PriorPaidBonusYear = priorYear;
                censusParticipantDto.AdditionalPriorPaidBonusYear = additionalYear;
                censusParticipantDto.MostRecentPaidCommissionYear = mostRecentYear;
                censusParticipantDto.PriorPaidCommissionYear = priorYear;
                censusParticipantDto.AdditionalPriorPaidCommissionYear = additionalYear;
                censusParticipantDto.MostRecentPaidK1IncomeYear = mostRecentYear;
                censusParticipantDto.PriorPaidK1IncomeYear = priorYear;
                censusParticipantDto.AdditionalPriorPaidK1IncomeYear = additionalYear;

                censusParticipantDto.MostRecentYearPaidW2Income = participant.mostRecentYearPaidW2Income;
                censusParticipantDto.AdditionalInfo1 = participant.additionalInfo1;
                censusParticipantDto.AdditionalInfo2 = participant.additionalInfo2;
                censusParticipantDto.SocialSecurityNumber = participant.ssn?.Trim();
                              
                censusParticipantDto.WeeklyHoursWorked = participant.hoursworked;  

                if (participant.citizenship?.Trim() != null && participant.citizenship?.Trim() != string.Empty)
                {
                    if (participant.citizenship.ToLower().Trim() == "yes" || participant.citizenship.ToLower().Trim() == "y"
                        || participant.citizenship.ToLower().Trim() == "true"
                        || participant.citizenship.ToLower().Trim() == "1" || participant.citizenship.ToLower().Trim() == "t" || participant.citizenship.ToLower().Contains("us") )
                    {
                        hasCitizenship = true;
                    }
                    if (participant.citizenship.ToLower().Trim() == "no" || participant.citizenship.ToLower().Trim() == "n" 
                        || participant.citizenship.ToLower().Trim() == "false" 
                        || participant.citizenship.ToLower().Trim() == "0" || participant.citizenship.ToLower().Trim() == "f")
                    {
                        hasCitizenship = false;
                    }
                }
                censusParticipantDto.Citizenship = hasCitizenship;

                //Changes to be for NBTDI-70
                // censusParticipantDto.IsMicrositeAccess = true;

               

                // generate the participant identifier if it's NULL
                censusParticipantDto.EmployeeId = !string.IsNullOrEmpty(censusParticipantDto.EmployeeId) ?
                    censusParticipantDto.EmployeeId :
                    GenerateEmployeeId(censusParticipantDto.FirstName, censusParticipantDto.LastName, censusParticipantDto.DateOfBirth).ToString();

                //Changes to be for NBTAB-5111
                censusParticipantDto.ManualBenefitAmount = participant.manualBenefit != null ? (decimal)GetIntValue(participant.manualBenefit.ToString()) : (decimal?)null;
                censusParticipantDto.ManualAMBAmount = participant.manualAMB != null ? (decimal)GetIntValue(participant.manualAMB.ToString()) : (decimal?)null;
                censusParticipantDto.ManualBuyUpBenefitAmount = participant.manualBuyUpBenefit != null ? (decimal)GetIntValue(participant.manualBuyUpBenefit.ToString()) : (decimal?)null;
                censusParticipantDto.ManualBuyUpAMBAmount = participant.manualBuyUpAMB != null ? (decimal)GetIntValue(participant.manualBuyUpAMB.ToString()) : (decimal?)null;
                censusParticipantDto.ManualRPPAmount = participant.manualRPP != null ? (decimal)GetIntValue(participant.manualRPP.ToString()) : (decimal?)null;
                censusParticipantDto.ManualRPPAMBAmount = participant.manualRPPAMB != null ? (decimal)GetIntValue(participant.manualRPPAMB.ToString()) : (decimal?)null;
                censusParticipantDto.OccClass = participant.occClass;
                censusParticipantDto.CLOASOccupationCode = participant.occCode;
                censusParticipantDto.Occupation = participant.occupation;
                if (participant.micrositeAccess?.Trim() != null && participant.micrositeAccess?.Trim() != string.Empty)
                {
                    if (participant.micrositeAccess.ToLower().Trim() == "yes" || participant.micrositeAccess.ToLower().Trim() == "y"
                        || participant.micrositeAccess.ToLower().Trim() == "true"
                        || participant.micrositeAccess.ToLower().Trim() == "1" || participant.micrositeAccess.ToLower().Trim() == "t")
                    {
                        isMicrositeAccess = true;
                    }
                    if (participant.micrositeAccess.ToLower().Trim() == "no" || participant.micrositeAccess.ToLower().Trim() == "n"
                        || participant.micrositeAccess.ToLower().Trim() == "false"
                        || participant.micrositeAccess.ToLower().Trim() == "0" || participant.micrositeAccess.ToLower().Trim() == "f")
                    {
                        isMicrositeAccess = false;
                    }
                }
                censusParticipantDto.IsMicrositeAccess = isMicrositeAccess;

                censusParticipants.Add(censusParticipantDto);
            }

            return censusParticipants;
        }

        private DateTime? GetDateTimeValue(string inputValue)
        {
            DateTime value = DateTime.Now;
            if (DateTime.TryParse(inputValue, out value))
            {
                return value;
            }
            else
            {
                return null;
            }
        }
        private int GetIntValue(string inputValue)
        {
            int value = 0;
            int.TryParse(inputValue, out value);
            return value;
        }

        private int GenerateEmployeeId(string firstName, string lastName, DateTime? dateOfBirth)
        {
            return (!string.IsNullOrEmpty(firstName) ? firstName.GetHashCode() : 0) +
                   (!string.IsNullOrEmpty(lastName) ? lastName.GetHashCode() : 0) +
                   (dateOfBirth != null ? dateOfBirth.GetHashCode() : 0) + Guid.NewGuid().GetHashCode();
        }

        private string GetGender(string gender)
        {
            string result = gender;
            if (gender.ToUpper().Trim() == "MALE")
            {
                result = "M";
            }
            else if (gender.ToUpper().Trim() == "FEMALE")
            {
                result = "F";
            }
            return result;
        }
        private bool GetIDICoverageReplaceFlag(string otherIDIcoveragetobeReplaced)
        {
            bool replacementCoverage = false;
            if (!string.IsNullOrEmpty(otherIDIcoveragetobeReplaced))
            {
                if (otherIDIcoveragetobeReplaced.ToUpper().Trim() == "Y" || otherIDIcoveragetobeReplaced.ToUpper().Trim() == "YES")
                {
                    replacementCoverage = true;
                }
                else if (otherIDIcoveragetobeReplaced.ToUpper().Trim() == "N" || otherIDIcoveragetobeReplaced.ToUpper().Trim() == "NO")
                {
                    replacementCoverage = false;
                }
            }
            return replacementCoverage;
        }
    }
}
