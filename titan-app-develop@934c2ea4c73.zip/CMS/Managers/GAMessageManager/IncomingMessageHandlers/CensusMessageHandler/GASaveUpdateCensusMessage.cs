﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.CensusMessageHandler
{
    class GASaveUpdateCensusMessage
    {
    }


    public class Payload
    {
        public string employeeID { get; set; }
        public string employeeFirstName { get; set; }
        public string employeeLastName { get; set; }
        public string employeeMiddleInitial { get; set; }
        public string employeeSuffix { get; set; }
        public string homeAddressStreet1 { get; set; }
        public string homeAddressStreet2 { get; set; }
        public string homeAddressCity { get; set; }
        public string homeAddressState { get; set; }
        public string homeAddressZipCode { get; set; }
        public string workAddressStreet1 { get; set; }
        public string workAddressStreet2 { get; set; }
        public string workAddressCity { get; set; }
        public string workAddressState { get; set; }
        public string workAddressZipCode { get; set; }
        public string workMailStop { get; set; }
        public string dateOfBirth { get; set; }
        public string dateOfHire { get; set; }
        public string gender { get; set; }
        public string employmentStatus { get; set; }
        public string occupation { get; set; }
        public string owner { get; set; }
        public string boardCertification { get; set; }
        public string workPhone { get; set; }
        public string workExtension { get; set; }
        public string businessEmailAddress { get; set; }
        public decimal? currentYearSalary { get; set; }
        public decimal? mostRecentYearPaidBonus { get; set; }
        public decimal? priorYearBonus { get; set; }
        public decimal? additionalPriorYearBonus { get; set; }
        public decimal? mostRecentYearPaidCommissions { get; set; }
        public decimal? priorYearCommissions { get; set; }
        public decimal? additionalPriorYearCommissions { get; set; }
        public decimal? mostRecentYearPaidK1Income { get; set; }
        public decimal? priorYearK1Income { get; set; }
        public decimal? additionalPriorK1Income { get; set; }
        public decimal? otherIncome { get; set; }
        public decimal? totalEmployerEmployeeRetirementContributions { get; set; }
        public int eligiblePDRClass { get; set; }
        public int? groupLTDClassWithinYourCompany { get; set; }
        public decimal? otherIDIBenefitAmount1 { get; set; }
        public string otherIDICarrier1 { get; set; }
        public string isOtherIDIcoveragetobeReplaced1 { get; set; }
        public decimal? amountofCoveragetobeReplaced1 { get; set; }
        public string policyofCoveragetobeReplaced1 { get; set; }
        public decimal? otherIDIBenefitAmount2 { get; set; }
        public string otherIDICarrier2 { get; set; }
        public string isOtherIDIcoveragetobeReplaced2 { get; set; }
        public decimal? amountofCoveragetobeReplaced2 { get; set; }
        public string policyofCoveragetobeReplaced2 { get; set; }
        public decimal? otherIDIBenefitAmount3 { get; set; }
        public string otherIDICarrier3 { get; set; }
        public string isOtherIDIcoveragetobeReplaced3 { get; set; }
        public decimal? amountofCoveragetobeReplaced3 { get; set; }
        public string policyofCoveragetobeReplaced3 { get; set; }
        public string otherDisabilityInformation { get; set; }
        public string benefitDeductionFrequency { get; set; }
        public decimal? mostRecentYearPaidW2Income { get; set; }
        public string additionalInfo1 { get; set; }
        public string additionalInfo2 { get; set; }
        public string ssn { get; set; }
        //public string aaw { get; set; }
        public string citizenship { get; set; }
        public decimal? hoursworked { get; set; }
        public decimal? manualBenefit { get; set; }
        public decimal? manualAMB { get; set; }
        public decimal? manualBuyUpBenefit { get; set; }
        public decimal? manualBuyUpAMB { get; set; }
        public decimal? manualRPP { get; set; }
        public decimal? manualRPPAMB { get; set; }
        public string occClass { get; set; }
        public string occCode { get; set; }
        public string micrositeAccess { get; set; }


    }

    public class RootObject
    {
        public string GACaseId { get; set; }
        public string GAPDRId { get; set; }
        public string GACensusInfoId { get; set; }
        public string MessageType { get; set; }
        public string MessageId { get; set; }
        public List<Payload> Payload { get; set; }
    }

}
