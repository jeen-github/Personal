﻿using CMS.Interfaces.Managers.GAMessageManagers;
using CMS.Managers.GAMessageManagers.IncomingMessageHandlers.CaseMessageHandler;
using CMS.Managers.GAMessageManagers.IncomingMessageHandlers.CensusMessageHandler;
using CMS.Managers.GAMessageManagers.IncomingMessageHandlers.PDRMessageHandler;
using CMS.Managers.GAMessageManagers.IncomingMessageHandlers.QuoteLikelyToSellHandler;
using CMS.Managers.GAMessageManagers.IncomingMessageHandlers.UploadFileMessageHandler;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers
{
    public class IncomeMessageHandlerFactory 
    {
        public readonly IGaMessageManager GAMessageManager;
        private readonly List<MessageHandlerBase> _incomeMessageHandlers;

        public IncomeMessageHandlerFactory(IGaMessageManager gaMessageManager)
        {
            GAMessageManager = gaMessageManager;

            _incomeMessageHandlers = new List<MessageHandlerBase>
            {
                new SaveCaseMessageHandler(gaMessageManager),
                new SavePDRMessageHandler(gaMessageManager),
                new SaveCensusMessageHandler(gaMessageManager),
                new QuoteLTSHandler(gaMessageManager),
                new SaveUploadFileMessageHandler(gaMessageManager),
                new SaveCaseSubmissionHandler(gaMessageManager),
            };
        }

        public MessageHandlerBase CreateMessageHandler(GaIncomingMessage header)
        {
            if (header == null || string.IsNullOrEmpty(header.MessageType)) throw new ApplicationException("Empty message type!");

            var handler = _incomeMessageHandlers.FirstOrDefault(h => h.CanHandle(header));

            if (handler != null) return handler;

            var error = string.Format("Unknown message type:'{0}'", header.MessageType);
            Log.Error(error);
            throw new ApplicationException(error);
        }
    }
}