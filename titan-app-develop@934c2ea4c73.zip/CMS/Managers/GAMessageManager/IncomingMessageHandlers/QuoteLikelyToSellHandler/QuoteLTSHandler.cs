﻿using CMS.Interfaces.Managers.GAMessageManagers;
using CMS.Model.Entities;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Linq;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.QuoteLikelyToSellHandler
{
    public class QuoteLTSHandler : MessageHandlerBase
    {
        private readonly IGaMessageManager _gaMessageManager;

        public QuoteLTSHandler(IGaMessageManager gaMessageManager) : base(gaMessageManager)
        {
            _gaMessageManager = gaMessageManager;
        }

        public override bool CanHandle(GaIncomingMessage header)
        {
            return header.MessageType.Equals("QuoteLikelyToSell", StringComparison.InvariantCultureIgnoreCase);
        }

        public override void ProcessMessage(GaIncomingMessage messageString)
        {
            Log.TraceFormat("+QuoteLikelyToSell message received!");

            if (string.IsNullOrEmpty(messageString.GACaseId))
            {
                Log.WarnFormat("GACaseId is null or empty");
                return;
            }

            if (messageString.Payload == null)
            {
                Log.WarnFormat("Payload is null or empty");
                return;
            }

            Payload message = JsonConvert.DeserializeObject<Payload>(messageString.Payload.ToString());

            using (var unitOfWork = _gaMessageManager.UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.GACaseId == messageString.GACaseId);

                if (cmsCase != null)
                {
                    var pdr = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Case.Id == cmsCase.Id && c.GAPlanDesignRequestId == messageString.GAPDRId);
                    if (pdr != null)
                    {
                        var illustration = unitOfWork.Repository<Illustration>().Linq().FirstOrDefault(c => c.PlanDesignRequest.Id == pdr.Id && c.Id == GetIntValue(message.titanQuoteId));
                        if (illustration != null)
                        {
                            _gaMessageManager.IllustrationManager.SaveMostLikelyToSellQuoteFromGA(illustration.Id, message.ltsFlag);
                        }
                        else
                        {
                            Log.WarnFormat("Titan Quote Id does not exist or is incorrect.");
                        }
                    }
                }
            }
            Log.TraceFormat("-QuoteLikelyToSell message received!");
        }
        private int GetIntValue(string inputValue)
        {
            int value = 0;
            int.TryParse(inputValue, out value);
            return value;
        }
    }
}