﻿namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.QuoteLikelyToSellHandler
{
    class GASaveUpdateQuoteLikelyToSell
    {
    }

    public class Payload
    {
        public string titanQuoteId { get; set; }
        public bool ltsFlag { get; set; }
    }

    public class RootObject
    {
        public string GACaseId { get; set; }
        public string MessageType { get; set; }
        public string MessageId { get; set; }
        public string GAPDRId { get; set; }
        public Payload Payload { get; set; }
    }
}
