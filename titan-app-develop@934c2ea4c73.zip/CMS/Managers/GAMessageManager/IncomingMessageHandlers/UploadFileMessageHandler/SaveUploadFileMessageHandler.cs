﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Interfaces.Managers.GAMessageManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Linq;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.UploadFileMessageHandler
{
    public class SaveUploadFileMessageHandler : MessageHandlerBase
    {
        private readonly IGaMessageManager _gaMessageManager;

        public SaveUploadFileMessageHandler(IGaMessageManager gaMessageManager) : base(gaMessageManager)
        {
            _gaMessageManager = gaMessageManager;
        }

        public override bool CanHandle(GaIncomingMessage header)
        {
            return header.MessageType.Equals("UploadFile", StringComparison.InvariantCultureIgnoreCase);
        }

        public override void ProcessMessage(GaIncomingMessage messageString)
        {
            Log.TraceFormat("+UploadFile message received!");
            if (string.IsNullOrEmpty(messageString.GACaseId))
            {
                Log.WarnFormat("CaseNumber is null or empty");
                return;
            }

            if (messageString.Payload == null)
            {
                Log.WarnFormat("Payload is null or empty");
                return;
            }

            Payload message = JsonConvert.DeserializeObject<Payload>(messageString.Payload.ToString());

            using (var unitOfWork = _gaMessageManager.UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.GACaseId == messageString.GACaseId);

                if (cmsCase != null)
                {
                    var caseDocumentType = message.DocumentType.GetValueFromDescription<CaseDocumentTypeEnum>();

                    Log.TraceFormat("+GA Document Type - " + caseDocumentType.ToString() + " - " + cmsCase.Id);

                    if (!string.IsNullOrWhiteSpace(message.DocumentType))
                    {
                        switch (message.DocumentType.ToUpper())
                        {
                            case "CEN":
                                caseDocumentType = CaseDocumentTypeEnum.Census;
                                break;
                            case "ENRCEN":
                                caseDocumentType = CaseDocumentTypeEnum.EnrollmentCensus;
                                break;
                            case "RENRCEN":
                                caseDocumentType = CaseDocumentTypeEnum.ReEnrollmentCensus;
                                break;
                            case "AOCEN":
                                caseDocumentType = CaseDocumentTypeEnum.AddOnCensus;
                                break;
                            case "SOLD CASE SUBMISSION":
                                caseDocumentType = CaseDocumentTypeEnum.SoldCaseSubmission;
                                break;
                        }
                    }

                    var documentSaveRequest = new DocumentSaveRequest
                    {
                        CaseNumber = cmsCase.CaseNumber,
                        CaseDocumentType = caseDocumentType == default(CaseDocumentTypeEnum) ? CaseDocumentTypeEnum.Other : caseDocumentType,
                        FileName = message.FileName,
                        FileMimeType = message.FileMimeType,
                        UploadedByGALdapUser = message.UploaderLdapUserId,
                        UploadedByGALdapUserRole = message.UploaderLdapRole,
                        FileContent = Convert.FromBase64String(message.FileContent),
                        IsExternalDocument = true,
                        GAPDRId = messageString.GAPDRId ?? ""
                    };

                    _gaMessageManager.DocumentManager.SaveDocument(documentSaveRequest);

                    if (documentSaveRequest.CaseDocumentType == CaseDocumentTypeEnum.OfferLetter || documentSaveRequest.CaseDocumentType==CaseDocumentTypeEnum.SoldCaseSubmission)
                    {
                        SendNotification(cmsCase, unitOfWork, documentSaveRequest.CaseDocumentType);
                    }

                    
                }
            }
            Log.TraceFormat("-UploadFile message received!");
        }

        private void SendNotification(Case cmsCase, IUnitOfWork unitOfWork, CaseDocumentTypeEnum docType)
        {
            var taskSLA = unitOfWork.Repository<TaskSLAType>().Linq();
            switch (docType)
            {
                case CaseDocumentTypeEnum.OfferLetter:
                    
                    var taskSLAForSoldOfferUpload = taskSLA.Where(i => i.ShortDescription == "SoldOfferUpload").FirstOrDefault();

                    if (taskSLAForSoldOfferUpload != null)
                    {
                        var taskName = string.Format(taskSLAForSoldOfferUpload.TaskName, cmsCase.CaseNumber);
                        var assignedUserId = _gaMessageManager.TaskManager.GetAssignedUserId(cmsCase.Id);
                        _gaMessageManager.TaskManager.CreateTask(cmsCase.Id, taskName, UserGroup.Group_Underwriting,
                            assignedUserId, taskSLAForSoldOfferUpload.SLAInHours,
                            taskSLAForSoldOfferUpload.isSameDayResponseRequired);
                    }

                    break;
            }

        }
    }
}
