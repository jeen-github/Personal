﻿namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.UploadFileMessageHandler
{
    class GASaveUploadFile
    {
    }

    public class Payload
    {
        public string UploadedDateTime { get; set; }
        public string UploaderLdapUserId { get; set; }
        public string UploaderLdapRole { get; set; }
        public string DocumentType { get; set; }
        public string FileName { get; set; }
        public string FileMimeType { get; set; }
        public string FileContent { get; set; }
    }

    public class RootObject
    {
        public string GACaseId { get; set; }
        public string MessageId { get; set; }
        public string MessageType { get; set; }
        public string GAPDRId { get; set; }
        public Payload Payload { get; set; }
    }
}
