﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.GAMessageManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.PDRMessageHandler
{
    class SavePDRMessageHandler : MessageHandlerBase
    {
        private readonly IGaMessageManager _gaMessageManager;

        public SavePDRMessageHandler(IGaMessageManager gaMessageManager) : base(gaMessageManager)
        {
            _gaMessageManager = gaMessageManager;
        }

        public override bool CanHandle(GaIncomingMessage header)
        {
            return header.MessageType.Equals("NewPDR", StringComparison.InvariantCultureIgnoreCase);
        }

        public override void ProcessMessage(GaIncomingMessage messageString)
        {
            Log.Trace("+SavePDRMessageHandler.ProcessMessage");

            if (string.IsNullOrEmpty(messageString.GACaseId))
            {
                Log.WarnFormat("GACaseId is null or empty");
                return;
            }

            if (messageString.Payload == null)
            {
                Log.WarnFormat("Payload is null or empty");
                return;
            }

            Payload message = JsonConvert.DeserializeObject<Payload>(messageString.Payload.ToString());            

            using (var unitOfWork = _gaMessageManager.UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.GACaseId == messageString.GACaseId);

                if (string.IsNullOrEmpty(message.GAPDRId))
                {
                    Log.WarnFormat("GAPDRId is null or empty");
                    return;
                }

                if (cmsCase != null)
                {
                    var planDesignDto = new PlanDesignDto();
                    planDesignDto.CaseUnderwritingRequest = BuildUnderWritingRequest(message, cmsCase.Id);

                    var planDesignRequest = BuildPlanDesignRequest(message, cmsCase.Id);

                    var planDesignRequestId = 0;
                    planDesignRequest.RequestHeaderName = message.GAPDRId; //GetRequestHeaderName(message, unitOfWork, cmsCase, out planDesignRequestId);
                    planDesignRequest.PlanDesignRequestId = planDesignRequestId;

                    planDesignDto.PlanDesignRequests = new List<PlanDesignRequestDto>();
                    planDesignDto.PlanDesignRequests.Add(planDesignRequest);

                    planDesignRequest.PlanDesignRequestId = _gaMessageManager.PlanDesignRequestManager.SavePlanDesignRequestFromGA(planDesignDto, false);
                    
                    var planDesignRequestClasses = BuildPlanDesignRequestClass(message, planDesignRequest.PlanDesignRequestId, unitOfWork);

                    foreach (var requestClass in planDesignRequestClasses)
                    {
                        planDesignRequest.SelectedClass = requestClass;
                        _gaMessageManager.PlanDesignRequestManager.SavePlanDesignRequestFromGA(planDesignDto, true);
                    }
                    
                    UpdateCensusPDR(message.GAPDRId, cmsCase.Id, unitOfWork);

                    if (planDesignRequest.PlanDesignRequestId > 0)
                    {
                        UpdateTaskWithPDRId(cmsCase.Id, unitOfWork, planDesignRequest.PlanDesignRequestId);
                    }
                    
                }
            }

            UpdateGAMessageHistoryWithGaPDRId(messageString.MessageId, message.GAPDRId, messageString.GACaseId);

            Log.Trace("-SavePDRMessageHandler.ProcessMessage");
        }

        private void UpdateTaskWithPDRId(int caseId, IUnitOfWork unitOfWork, int pdrId)
        {
            Log.TraceFormat("+UpdateTaskWithPDRId: PDR Id:{0} CaseId:{1}", pdrId, caseId);

            var cmsTask = unitOfWork.Repository<CmsTask>().Linq().Where(c => c.Case.Id == caseId && c.IsCompletedIndicator == false && c.TaskName == "Revised Case Received" && c.PlanDesignRequest == null).OrderByDescending(t => t.Id).FirstOrDefault();

            if (cmsTask != null)
            {
                var cmsPlanDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Id == pdrId);
                cmsTask.PlanDesignRequest = cmsPlanDesignRequest;
                unitOfWork.Repository<CmsTask>().Save(cmsTask);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-UpdateTaskWithPDRId: PDR Id:{0} CaseId:{1}", pdrId, caseId);
        }
        private void UpdateCensusPDR(string gaPdrId, int caseId, IUnitOfWork unitOfWork)
        {
            Log.TraceFormat("+UpdateCensusPDR: GaPdrId:{0} CaseId:{1}", gaPdrId, caseId);

            var censusWithoutPdrIdList = unitOfWork.Repository<Census>().Linq()
                .Where(c => c.Case.Id == caseId && c.GAPlanDesignRequestId == gaPdrId && c.PlanDesignRequest == null)
                .ToList();

            if (censusWithoutPdrIdList.Any())
            {
                var pdr = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(p => p.Case.Id == caseId && p.GAPlanDesignRequestId == gaPdrId && p.IsActive == true);
                if (pdr == null)
                {
                    Log.WarnFormat("No PDR with GAPdrId={0} found!", gaPdrId);
                    return;
                }

                foreach (var census in censusWithoutPdrIdList)
                {
                    Log.TraceFormat("Census id:{0} set pdr id:{1}", census.Id, pdr.Id);
                    census.PlanDesignRequest = pdr;
                    unitOfWork.Repository<Census>().Save(census);
                }
                
                unitOfWork.Commit();
            }

            Log.TraceFormat("-UpdateCensusPDR");
        }

        private void UpdateGAMessageHistoryWithGaPDRId(string gaMessageId, string gaPDRId, string gaCaseId)
        {
            Log.TraceFormat("+UpdateGAMessageHistoryWithGaPDRId: GaMessageId:{0} GaPDRId:{1} GaCaseId:{2}", gaMessageId, gaPDRId, gaCaseId);

            if (string.IsNullOrEmpty(gaPDRId))
            {
                Log.WarnFormat("+UpdateGAMessageHistoryWithGaPDRId: GAPDRId is null or empty");
                return;
            }

            using (var unitOfWork = _gaMessageManager.UnitOfWorkFactory.CreateUnitOfWork())
            {
                var gaMesageHistory = unitOfWork.Repository<GaMessageHistory>().Linq().FirstOrDefault(i => i.MessageId == gaMessageId && i.GaCaseId == gaCaseId);

                if (gaMesageHistory != null)
                {
                    gaMesageHistory.GaPDRId = gaPDRId;
                    unitOfWork.Repository<GaMessageHistory>().Save(gaMesageHistory);
                    unitOfWork.Commit();
                }
            }

            Log.TraceFormat("-UpdateGAMessageHistoryWithGaPDRId");
        }

        private string GetRequestHeaderName(Payload message, IUnitOfWork unitOfWork, Case cmsCase, out int planDesignRequestId)
        {
            Log.TraceFormat("+GetRequestHeaderName");
            string requestHeaderName = string.Empty;
            planDesignRequestId = 0;
            var pdrExists = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(c => c.Case.Id == cmsCase.Id && c.GAPlanDesignRequestId == message.GAPDRId);

            if (pdrExists == null)
            {
                var cmsPlanDesignRequest = unitOfWork.Repository<PlanDesignRequest>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.Case.Id == cmsCase.Id);
                int requestNo = 0;
                if (cmsPlanDesignRequest != null)
                {
                    if (!string.IsNullOrEmpty(cmsPlanDesignRequest.RequestHeaderName))
                    {
                        if (cmsPlanDesignRequest.RequestHeaderName.Contains("Request"))
                        {
                            string[] headerName = cmsPlanDesignRequest.RequestHeaderName.Split(' ');
                            requestNo = (int)GetIntValue(headerName[1]);
                        }
                    }
                }
                requestHeaderName = "Request " + (++requestNo);
            }
            else
            {
                requestHeaderName = pdrExists.RequestHeaderName;
                planDesignRequestId = pdrExists.Id;
            }
            Log.TraceFormat("-GetRequestHeaderName");
            return requestHeaderName;
        }

        private CaseUnderwritingRequestDto BuildUnderWritingRequest(Payload message, int caseId)
        {            
            Log.TraceFormat("+BuildUnderWritingRequest: CaseId:{0}", caseId);
            CaseUnderwritingRequestDto caseUnderwritingRequestDto = new CaseUnderwritingRequestDto()
            {
                CaseId = caseId,
                SitusTypeId = message.residentStateFlag == true ? (int)SitusTypeEnum.Residence : (int)SitusTypeEnum.Corporate,
                StateTypeId = GetIntValue(message.selectedStateId)
            };

            Log.TraceFormat("-BuildUnderWritingRequest");
            return caseUnderwritingRequestDto;
        }

        private PlanDesignRequestDto BuildPlanDesignRequest(Payload message, int caseId)
        {            
            Log.TraceFormat("+BuildPlanDesignRequest: CaseId:{0} GAPdrId:{1} GAPdrName:{2}", caseId, message.GAPDRId, message.pdrName);

            PlanDesignRequestDto planDesignRequestDto = new PlanDesignRequestDto();
            planDesignRequestDto.CaseId = caseId;
            planDesignRequestDto.GAPlanDesignRequestId = message.GAPDRId;
            planDesignRequestDto.IllustrationEffectiveDate = Convert.ToDateTime(message.effDate);
            planDesignRequestDto.PDRName = message.pdrName;
            planDesignRequestDto.IsActive = true;
            planDesignRequestDto.PlanDesignRequestStatusType = PlanDesignRequestStatusTypeEnum.UnderwritingReview;

            Log.TraceFormat("-BuildPlanDesignRequest");
            return planDesignRequestDto;
        }
        private List<PlanDesignRequestClassDto> BuildPlanDesignRequestClass(Payload message, int planDesignRequestId, IUnitOfWork unitOfWork)
        {
            Log.TraceFormat("+BuildPlanDesignRequestClass");

            List<PlanDesignRequestClassDto> planDesignRequestClasses = new List<PlanDesignRequestClassDto>();

            var requestClasses = unitOfWork.Repository<PlanDesignRequestClass>().Linq().Where(c => c.PlanDesignRequest.Id == planDesignRequestId);
            
            if (message.pdrClass.Any())
            {
                foreach (var pdrClass in message.pdrClass)
                {
                    if (pdrClass.underwritingReqDTO != null)
                    {
                        Log.TraceFormat("+BuildPlanDesignRequestClass: GAPDRClassId:{0} planDesignRequestId:{1}", pdrClass.gaPdrClassID.ToString(), planDesignRequestId);                        

                        var reqClass = requestClasses.FirstOrDefault(c => c.GAPlanDesignRequestClassId == pdrClass.gaPdrClassID.ToString());
                        PlanDesignRequestClassDto classDto = new PlanDesignRequestClassDto();
                        if (reqClass != null)
                        {
                            classDto.PlanDesignRequestClassId = reqClass.Id;
                        }
                        classDto.GAPlanDesignRequestClassId = pdrClass.gaPdrClassID.ToString();
                        classDto.RequestedPlanDesignTypeId = GetIntValue(pdrClass.underwritingReqDTO.planDesignId);
                        classDto.RequestedEligiblePopulationText = pdrClass.underwritingReqDTO.eligiblePopulation;
                        classDto.RequestedMaximumReplacementRatio = GetDecimalValue(pdrClass.underwritingReqDTO.maxReplaceRatio);
                        classDto.RequestedEliminationPeriodId = GetIntValue(pdrClass.underwritingReqDTO.eliminationPeriodId);
                        classDto.RequestedBenefitPeriodId = GetIntValue(pdrClass.underwritingReqDTO.benefitPeriodId);
                        classDto.RequestedLTDPercentage = pdrClass.underwritingReqDTO.ltdPercent != null ? (decimal?)GetDecimalValue(pdrClass.underwritingReqDTO.ltdPercent.ToString()) : null;
                        classDto.RequestedIDIPercentage = pdrClass.underwritingReqDTO.idiPercent != null ? (decimal?)GetDecimalValue(pdrClass.underwritingReqDTO.idiPercent.ToString()) : null;
                        classDto.RequestedRetirementContributionsTypeId = pdrClass.underwritingReqDTO.retirementContributionId != null ? (int?)GetIntValue(pdrClass.underwritingReqDTO.retirementContributionId.ToString()) : null;
                        classDto.RequestedCoveredEarningsPercentage = pdrClass.underwritingReqDTO.retContCoveredEarningPercent != null ? (decimal?)GetIntValue(pdrClass.underwritingReqDTO.retContCoveredEarningPercent.ToString()) : null;
                        classDto.RequestedAnnualContributions = pdrClass.underwritingReqDTO.annualContribution != null ? (int?)GetIntValue(pdrClass.underwritingReqDTO.annualContribution.ToString()) : null;
                        classDto.RequestedPremiumPayerAndTaxabilityTypeId = GetIntValue(pdrClass.underwritingReqDTO.premiumPayerId);
                        classDto.RequestedTaxabilityTypeId = GetIntValue(pdrClass.underwritingReqDTO.employerPaidTaxId);
                        classDto.RequestedCostShareTaxabilityTypeId = GetIntValue(pdrClass.underwritingReqDTO.CostShareTaxability);
                        classDto.RequestedEmployerPaidPremium = GetIntValue(pdrClass.underwritingReqDTO.EmployerPaid);
                        classDto.RequestedEmployeePaidPremium = GetIntValue(pdrClass.underwritingReqDTO.EmployeePaid);
                        classDto.RequestedTypeOfShareTypeId = GetIntValue(pdrClass.underwritingReqDTO.PercentOfPremAmt);
                        classDto.RequestedEmployerPaysupto = GetIntValue(pdrClass.underwritingReqDTO.MonthlyEmployerUpTo);
                        classDto.IsRequestedVoluntaryGSIBuyUpPlan = pdrClass.underwritingReqDTO.voluntayGSIBuyupPlan;
                        classDto.RequestedLTDCoversNext = pdrClass.underwritingReqDTO.ltdCoverNext != null ? (decimal?)GetDecimalValue(pdrClass.underwritingReqDTO.ltdCoverNext.ToString()) : null;
                        classDto.RequestedIDICovers1st = pdrClass.underwritingReqDTO.idiCoverfirst != null ? (decimal?)GetDecimalValue(pdrClass.underwritingReqDTO.idiCoverfirst.ToString()) : null;
                        classDto.RequestedFlatRate_Other = pdrClass.underwritingReqDTO.flatBenefitPlanOptionOther != null ? (int?)GetIntValue(pdrClass.underwritingReqDTO.flatBenefitPlanOptionOther.ToString()) : null;
                        classDto.RequestedFlatRateType_Id = pdrClass.underwritingReqDTO.flatBenefitPlanOptionId != null ? (int?)GetIntValue(pdrClass.underwritingReqDTO.flatBenefitPlanOptionId.ToString()) : null;
                        classDto.RequestedCoveredEarningsBonusOnlyTypeId = GetIntValue(pdrClass.underwritingReqDTO.planDesignId) == (int)PlanDesignTypeEnum.BonusOnlyPlan ? GetIntValue(pdrClass.underwritingReqDTO.coveredEarningsId) : (int?)null;
                        classDto.RequestedCoveredEarningsTypeId = GetIntValue(pdrClass.underwritingReqDTO.planDesignId) != (int)PlanDesignTypeEnum.BonusOnlyPlan ? GetIntValue(pdrClass.underwritingReqDTO.coveredEarningsId) : (int?)null;
                        classDto.RequestedVoluntaryGSIBuyUpPlanDesignTypeId = GetIntValue(pdrClass.underwritingReqDTO.GSIBuyUpPlanDesignId);
                        classDto.RequestedGSIBuyUpReplacementPercentage = GetIntValue(pdrClass.underwritingReqDTO.GSIBuyUpMaxReplacementRatio);
                        classDto.RequestedGSIBuyUpCoveredEarningsTypeId = pdrClass.underwritingReqDTO.GSIBuyUpCoveredEarningsId != null && classDto.RequestedVoluntaryGSIBuyUpPlanDesignTypeId != (int)PlanDesignGSITypeEnum.BonusOnlyPlan ? (int?)GetIntValue(pdrClass.underwritingReqDTO.GSIBuyUpCoveredEarningsId.ToString()) : null;
                        classDto.RequestedGSIBuyUpCoveredEarningsBonusOnlyTypeId = pdrClass.underwritingReqDTO.GSIBuyUpCoveredEarningsId != null && classDto.RequestedVoluntaryGSIBuyUpPlanDesignTypeId == (int)PlanDesignGSITypeEnum.BonusOnlyPlan ? (int?)GetIntValue(pdrClass.underwritingReqDTO.GSIBuyUpCoveredEarningsId.ToString()) : null;
                        classDto.RequestedGSIBuyUpCoveredEarningsTypeOther = pdrClass.underwritingReqDTO.GSIBuyUpCoveredEarningsOther != null ? pdrClass.underwritingReqDTO.GSIBuyUpCoveredEarningsOther.ToString() : string.Empty;
                        classDto.RequestedCoveredEarningsTypeOther = pdrClass.underwritingReqDTO.coveredEarningsOther;
                        classDto.CaseCompanyRetirementPlans = BuildCaseCompanyRetirementPlans(pdrClass.underwritingReqDTO.retirementPlanDescId);
                        classDto.PlanDesignRequestClassLTDCoverage = pdrClass.groupLtdDTO != null ? BuildLTDCoverageInfo(pdrClass) : null;

                        if(classDto.RequestedPlanDesignTypeId != (int)PlanDesignTypeEnum.StandAloneRPPPlan)
                        {
                            classDto.RequestedRetirementContributionsTypeId = pdrClass.underwritingReqDTO.retirementContributionOptionId != null ? GetIntValue(pdrClass.underwritingReqDTO.retirementContributionOptionId) : null;
                            classDto.RequestedAnnualContributions = pdrClass.underwritingReqDTO.annualContributionOption != null ? (int?)GetIntValue(pdrClass.underwritingReqDTO.annualContributionOption) : null;
                            if (!string.IsNullOrEmpty(pdrClass.underwritingReqDTO.coveredEarningsOptionId))
                            {
                                classDto.RequestedRppRiderCoveredEarningsTypeId = GetIntValue(pdrClass.underwritingReqDTO.coveredEarningsOptionId);
                                classDto.RequestedRppRiderCoveredEarningsTypeOther = pdrClass.underwritingReqDTO.retContCoveredEarningOtherOption;
                                classDto.RequestedCoveredEarningsPercentage = pdrClass.underwritingReqDTO.retContCoveredEarningPercentOption != null ? GetIntValue(pdrClass.underwritingReqDTO.retContCoveredEarningPercentOption) : null;
                            }
                        }
                        classDto.IsActive = true;
                        planDesignRequestClasses.Add(classDto);
                    }
                }
            }

            Log.TraceFormat("-BuildPlanDesignRequestClass");
            return planDesignRequestClasses;
        }

        private IList<CaseCompanyRetirementPlanDto> BuildCaseCompanyRetirementPlans(List<string> retirementPlanDescId)
        {
            Log.TraceFormat("+BuildCaseCompanyRetirementPlans");
            IList<CaseCompanyRetirementPlanDto> listCaseCompanyRetirementplan = new List<CaseCompanyRetirementPlanDto>();

            if (retirementPlanDescId == null)
            {
                return listCaseCompanyRetirementplan;
            }

            if (retirementPlanDescId.Any())
            {
                foreach (var retirementPlan in retirementPlanDescId)
                {
                    CaseCompanyRetirementPlanDto caseCompanyRetirementPlanDto = new CaseCompanyRetirementPlanDto();
                    caseCompanyRetirementPlanDto.CompanyRetirementPlanTypeId = GetIntValue(retirementPlan);
                    caseCompanyRetirementPlanDto.IsChecked = true;
                    listCaseCompanyRetirementplan.Add(caseCompanyRetirementPlanDto);
                }
            }
            Log.TraceFormat("-BuildCaseCompanyRetirementPlans");
            return listCaseCompanyRetirementplan;
        }

        private PlanDesignRequestClassLTDCoverageDto BuildLTDCoverageInfo(PdrClass pdrClass)
        {
            Log.TraceFormat("+BuildLTDCoverageInfo");

            PlanDesignRequestClassLTDCoverageDto ltdCoverageDto = new PlanDesignRequestClassLTDCoverageDto();

            ltdCoverageDto.EligiblePopulationText = pdrClass.underwritingReqDTO.eligiblePopulation;

            int? carrierId = GetIntValue(pdrClass.groupLtdDTO.carrierId);
            if (carrierId != null)
            {
                ltdCoverageDto.CarrierText = GetCarrierName((int)carrierId);
            }

            if (GetIntValue(pdrClass.groupLtdDTO.eliminationPeriod) != null)
            {
                ltdCoverageDto.EliminationPeriodDays = (int)GetIntValue(pdrClass.groupLtdDTO.eliminationPeriod);
            }
            if (GetIntValue(pdrClass.groupLtdDTO.benefitPeriod) != null)
            {
                ltdCoverageDto.BenefitPeriodDays = (int)GetIntValue(pdrClass.groupLtdDTO.benefitPeriod);
            }
            if (GetIntValue(pdrClass.groupLtdDTO.premiumPayerId) != null)
            {
                ltdCoverageDto.PremiumAndTaxpayerLiabilityTypeId = (int)GetIntValue(pdrClass.groupLtdDTO.premiumPayerId);
            }

            ltdCoverageDto.GroupLTDReplacementPercentage = GetDecimalValue(pdrClass.groupLtdDTO.replacementPercent);
            ltdCoverageDto.GroupLTDCapAmount = GetDecimalValue(pdrClass.groupLtdDTO.ltdCap);
            ltdCoverageDto.IsLTDPlanExistingIndicator = pdrClass.groupLtdDTO.ltdPlanChange;
            ltdCoverageDto.AdditionalDetailsText = pdrClass.groupLtdDTO.addtionalComments != null ? pdrClass.groupLtdDTO.addtionalComments.ToString() : string.Empty;
            if (GetIntValue(pdrClass.groupLtdDTO.coveredEarningsId) != null)
            {
                ltdCoverageDto.GroupLTDCoveredEarningsTypeId = (int)GetIntValue(pdrClass.groupLtdDTO.coveredEarningsId);
            }

            ltdCoverageDto.IsVoluntaryLTDBuyUpIndicator = pdrClass.groupLtdDTO.vltdBuyUpPlan;
            ltdCoverageDto.LTDBuyUpReplacementPercentage = pdrClass.groupLtdDTO.totalReplacementPercent != null ? (decimal?)GetDecimalValue(pdrClass.groupLtdDTO.totalReplacementPercent.ToString()) : null;
            ltdCoverageDto.LTDBuyUpLTDCapAmount = pdrClass.groupLtdDTO.totalLTDCap != null ? (decimal?)GetDecimalValue(pdrClass.groupLtdDTO.totalLTDCap.ToString()) : null;
            ltdCoverageDto.TypeOfPayTypeId = pdrClass.groupLtdDTO.employerPaidTax != null ? (int?)GetIntValue(pdrClass.groupLtdDTO.employerPaidTax.ToString()) : null;
            ltdCoverageDto.GroupLTDCoveredEarningsTypeOther = pdrClass.groupLtdDTO.coveredEarningsOther;
            ltdCoverageDto.LTDBuyUpCoveredEarningsTypeOther = pdrClass.groupLtdDTO.coveredEarningsLTDOther != null ? pdrClass.groupLtdDTO.coveredEarningsLTDOther.ToString() : null;
            ltdCoverageDto.LTDBuyUpCoveredEarningsTypeId = pdrClass.groupLtdDTO.coveredEarningsLtdId != null ? (int?)GetIntValue(pdrClass.groupLtdDTO.coveredEarningsLtdId.ToString()) : null;

            Log.TraceFormat("-BuildLTDCoverageInfo");
            return ltdCoverageDto;
        }

        private int? GetIntValue(string inputValue)
        {
            int value = 0;
            if (int.TryParse(inputValue, NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out value))
            {
                return value;
            }
            return null;
        }

        private decimal GetDecimalValue(string inputValue)
        {
            decimal value = 0.00M;
            decimal.TryParse(inputValue, out value);
            return value;
        }

        private string GetCarrierName(int carrierId)
        {
            string carrierName = string.Empty;
            
            var carriers = _gaMessageManager.LookupManager.GetValuesForType(typeof(ExistingIndividualDisabilityCoverageType));
            if(carriers != null)
            {
                carrierName = carriers.FirstOrDefault(c => c.Id == carrierId).Description;
            }
            
            return carrierName;
        }
    }
}
