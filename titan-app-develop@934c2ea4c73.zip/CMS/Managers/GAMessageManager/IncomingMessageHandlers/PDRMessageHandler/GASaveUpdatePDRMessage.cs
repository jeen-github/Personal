﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.PDRMessageHandler
{
    class GASaveUpdatePDRMessage
    {
    }

    public class UnderwritingReqDTO
    {
        public string eligiblePopulation { get; set; }
        public string planDesignId { get; set; }
        public string maxReplaceRatio { get; set; }
        public string coveredEarningsId { get; set; }
        public string coveredEarningsOther { get; set; }
        public string eliminationPeriodId { get; set; }
        public string benefitPeriodId { get; set; }
        public object ltdPercent { get; set; }
        public object idiPercent { get; set; }
        public object idiCoverfirst { get; set; }
        public object ltdCoverNext { get; set; }
        public object flatBenefitPlanOptionId { get; set; }
        public object flatBenefitPlanOptionOther { get; set; }
        public object retirementContributionId { get; set; }
        public object annualContribution { get; set; }
        public object retContCoveredEarningPercent { get; set; }
        public string retirementContributionOptionId { get; set; }
        public string annualContributionOption { get; set; }
        public string retContCoveredEarningPercentOption { get; set; }
        public string retContCoveredEarningOtherOption { get; set; }
        public string coveredEarningsOptionId { get; set; }
        public string premiumPayerId { get; set; }
        public string retirementPlanDescOther { get; set; }
        public bool actContributionCensus { get; set; }
        public bool voluntayGSIBuyupPlan { get; set; }
        public string employerPaidTaxId { get; set; }
        public List<string> retirementPlanDescId { get; set; }
        public string GSIBuyUpPlanDesignId { get; set; }
        public string GSIBuyUpMaxReplacementRatio { get; set; }
        public object GSIBuyUpCoveredEarningsOther { get; set; }
        public object GSIBuyUpCoveredEarningsId { get; set; }
        public string CostShareTaxability { get; set; }
        public string EmployerPaid { get; set; }
        public string EmployeePaid { get; set; }
        public string MonthlyEmployerUpTo { get; set; }
        public string PercentOfPremAmt { get; set; }
    }

    public class GroupLtdDTO
    {
        public string carrierId { get; set; }
        public string carrierOtherTxt { get; set; }
        public string eliminationPeriod { get; set; }
        public string benefitPeriod { get; set; }
        public string replacementPercent { get; set; }
        public string ltdCap { get; set; }
        public string coveredEarningsId { get; set; }
        public string coveredEarningsOther { get; set; }
        public string premiumPayerId { get; set; }
        public object employerPaidTax { get; set; }
        public bool vltdBuyUpPlan { get; set; }
        public object totalReplacementPercent { get; set; }
        public object totalLTDCap { get; set; }
        public object coveredEarningsLtdId { get; set; }
        public object coveredEarningsLTDOther { get; set; }
        public bool ltdPlanChange { get; set; }
        public object addtionalComments { get; set; }
    }

    public class PdrClass
    {
        public int gaPdrClassID { get; set; }
        public UnderwritingReqDTO underwritingReqDTO { get; set; }
        public GroupLtdDTO groupLtdDTO { get; set; }
    }

    public class Payload
    {
        public string pdrName { get; set; }
        public string selectedStateId { get; set; }
        public bool residentStateFlag { get; set; }
        public string effDate { get; set; }
        public List<PdrClass> pdrClass { get; set; }
        public string GAPDRId { get; set; }
    }

    public class RootObject
    {
        public string GACaseId { get; set; }
        public string MessageType { get; set; }
        public string MessageId { get; set; }
        public Payload Payload { get; set; }
    }

}
