﻿using System;
using CMS.Interfaces.Managers.GAMessageManagers;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.DataAccess;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Managers.GAMessageManagers.OutgoingMessages;
using CMS.Model.Enums;
using Newtonsoft.Json;
using CMS.Model.Entities;
using Logger.Static;
using Common.Exceptions;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers
{
    public class SaveCaseMessageHandler : MessageHandlerBase
    {
        private readonly IGaMessageManager _gaMessageManager;

        public SaveCaseMessageHandler(IGaMessageManager gaMessageManager) : base(gaMessageManager)
        {
            _gaMessageManager = gaMessageManager;
        }

        public override bool CanHandle(GaIncomingMessage header)
        {
            return header.MessageType.Equals("SaveCase", StringComparison.InvariantCultureIgnoreCase)
                || header.MessageType.Equals("NewCase", StringComparison.InvariantCultureIgnoreCase)
                || header.MessageType.Equals("SubmitCase", StringComparison.InvariantCultureIgnoreCase)
                || header.MessageType.Equals("UpdateCase", StringComparison.InvariantCultureIgnoreCase);
        }

        public override void ProcessMessage(GaIncomingMessage messageString)
        {
            Log.Trace("+SaveCaseMessageHandler.ProcessMessage");
            bool isError = false;
            if (string.IsNullOrEmpty(messageString.GACaseId))
            {
                Log.WarnFormat("GACaseId is null or empty");
                return;
            }

            if (messageString.Payload == null)
            {
                Log.WarnFormat("Payload is null or empty");
                return;
            }

            Payload message = JsonConvert.DeserializeObject<Payload>(messageString.Payload.ToString());

            using (var unitOfWork = _gaMessageManager.UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.GACaseId == messageString.GACaseId);

                var caseDto = new CaseDto
                {
                    CaseId = cmsCase != null ? cmsCase.Id : 0,
                    GACaseId = messageString.GACaseId,
                    CaseStatusTypeId = cmsCase == null ? (int)CaseStatusTypeEnum.Inquiry : (int)cmsCase.CaseStatusType,
                };

                caseDto.CaseNumber = GetCaseNumber(cmsCase, message);

                var isEmployeeClientCreated = false;
                caseDto.CompanyId = (cmsCase != null && cmsCase.Company != null) ? cmsCase.Company.Id : GenerateEmployerClient(message, unitOfWork, ref isEmployeeClientCreated);

                ParseCaseCarriers(message, caseDto);
                ParseCaseProducts(message, caseDto);
                ParseCompanyInfo(message, caseDto);

                var caseId = _gaMessageManager.CaseManager.SaveCaseCompanyFromGA(caseDto);

                ParseAndSaveExistingCoverage(message, unitOfWork, caseId);
                try
                {
                    ParseAndSaveCaseBrokers(message, caseId);
                }
                catch (Exception ex)
                {
                    isError = true;
                    Log.FatalFormat("ERROR processing message from GA queue.", ex);
                    //messageHistoryManager.UpdateMessageHistory(ex);
                }

                var taskSLA = unitOfWork.Repository<TaskSLAType>().Linq();
                var taskSLAForNewCase = taskSLA.Where(i => i.ShortDescription == "NewCase").FirstOrDefault();
                var taskSLAForReviseCase = taskSLA.Where(i => i.ShortDescription == "ReviseCase").FirstOrDefault();

                var assignedUserId = _gaMessageManager.BrokerManager.GetUnderwriterByAffiliationOrRegion(caseId);

                if (taskSLAForNewCase != null && taskSLAForReviseCase != null)
                {
                    var taskType = cmsCase == null ? taskSLAForNewCase : taskSLAForReviseCase;
                    _gaMessageManager.TaskManager.CreateTask(caseId, taskType.TaskName, UserGroup.Group_Underwriting, assignedUserId, taskType.SLAInHours, taskType.isSameDayResponseRequired);

                    if (!string.IsNullOrEmpty(caseDto.CaseNumber))
                    {
                        _gaMessageManager.SendMessage(new GaOutgoingMessage
                        {
                            MessageType = "CaseNumber",
                            GACaseId = messageString.GACaseId,
                            TitanCaseNumber = caseDto.CaseNumber,
                            MessageId = Guid.NewGuid().ToString()
                        });
                    }
                }
            }
            if (isError)
            {
                throw new BusinessException("Producer Data Exception", "Producer data not found.");
            }
            Log.Trace("-SaveCaseMessageHandler.ProcessMessage");
        }

        private string GetCaseNumber(Case cmsCase, Payload payload)
        {
            if (cmsCase != null) return cmsCase.CaseNumber;

            var additionalText = payload.additionalComments;
            var isExistingCmsCase = !string.IsNullOrEmpty(additionalText) && additionalText.Trim().StartsWith("cms:", StringComparison.InvariantCultureIgnoreCase);
            Log.WarnFormat("IsExistingCmsCase={0}", isExistingCmsCase);

            return isExistingCmsCase ? ParseCmsCaseNumberFromAdditionalComments(payload) : _gaMessageManager.CaseManager.GenerateCaseNumber();
        }

        private string ParseCmsCaseNumberFromAdditionalComments(Payload payload)
        {
            var additionalText = payload.additionalComments;
            var parts = additionalText.Split(':');
            return parts.Length > 1 ? parts[1].Trim().ToUpperInvariant() : null;
        }

        private int? GenerateEmployerClient(Payload message, IUnitOfWork unitOfWork, ref bool isEmployeeClientCreated)
        {
            Log.Trace("+GenerateEmployerClient");
            int? companyId = null;
            var cmsCase = unitOfWork.Repository<Case>().Linq()
                           .FirstOrDefault(c => c.CompanyName == message.companyInfo.companyName
                                            && c.CompanyZipCode == (message.companyInfo.zipCode != null ? message.companyInfo.zipCode.PadLeft(5, '0') : null)
                                            && c.Company != null);
            if (cmsCase == null)
            {
                CompanyDto company = new CompanyDto();
                company.EmployerClientId = _gaMessageManager.CompanyManager.GenerateEmployerClientNumber();
                companyId = _gaMessageManager.CompanyManager.SaveEmployerClient(company);
                isEmployeeClientCreated = true;
            }
            else
            {
                companyId = cmsCase.Company.Id;
            }
            Log.Trace("-GenerateEmployerClient");
            return companyId;
        }

        private void ParseAndSaveCaseBrokers(Payload message, int caseId)
        {
            Log.TraceFormat("+SaveCaseBrokers");

            if (message.brokerDetail == null) return;

            List<CaseBrokerDto> caseBrokers = new List<CaseBrokerDto>();
            foreach (var broker in message.brokerDetail)
            {
                var producerDto = new CaseBrokerDto
                {
                    CaseId = caseId,
                    BrokerName = broker.brokerName
                };

                if (!string.IsNullOrEmpty(broker.affiliationsId))
                {
                    int gaAffiliationsId = GetIntValue(broker.affiliationsId);
                    if (gaAffiliationsId > 0)
                    {
                        producerDto.BrokerAffiliationTypeId = gaAffiliationsId;
                    }
                }

                producerDto.AgencyCode = broker.agencyCode;

                if (!string.IsNullOrEmpty(broker.regionalGroupOfficeCode))
                {
                    int rgoId = GetIntValue(broker.regionalGroupOfficeCode);
                    if (rgoId > 0)
                    {
                        producerDto.WholesalerRegionOfficeId = rgoId;
                    }
                }

                producerDto.CompanyName = broker.companyName;
                producerDto.BrokerWritingCode = broker.writingCode;
                producerDto.IsFromGA = true;
                if (!string.IsNullOrEmpty(broker.brokerName)
                    || !string.IsNullOrEmpty(broker.writingCode)
                    || !string.IsNullOrEmpty(broker.agencyCode)
                    || !string.IsNullOrEmpty(broker.regionalGroupOfficeCode))
                {
                    caseBrokers.Add(producerDto);
                }
            }

            if (caseBrokers.Any())
            {
                var brokerDto = new BrokerDto
                {
                    CaseId = caseId,
                    CaseBrokers = caseBrokers
                };
                _gaMessageManager.BrokerManager.SaveBrokerInfoGA(brokerDto, true);

                var caseBroker = caseBrokers.FirstOrDefault();
                caseBroker.CaseId = caseId;
                _gaMessageManager.WholesalerManager.SaveCaseWholesalerInformationFromGA(caseBroker);
            }

            Log.TraceFormat("-SaveCaseBrokers");
        }

        private void ParseCaseCarriers(Payload message, CaseDto caseDto)
        {
            Log.TraceFormat("+SaveCaseCarriers");
            var caseCarriers = new List<CaseCarrierDto>();

            if (message.companyInfo.competitionCase && message.companyInfo.carrier != null)
            {
                foreach (var carrierId in message.companyInfo.carrier)
                {
                    var caseCarrierDto = new CaseCarrierDto();
                    if (!string.IsNullOrEmpty(carrierId))
                    {
                        int gaCarrierId = GetIntValue(carrierId);
                        if (gaCarrierId > 0)
                        {
                            caseCarrierDto.ExistingIndividualDisabilityCoverageTypeId = gaCarrierId;
                        }
                    }
                    caseCarrierDto.IsCompetition = true;
                    caseCarriers.Add(caseCarrierDto);
                }
            }

            caseDto.CaseCarriers = caseCarriers;
            Log.TraceFormat("-SaveCaseCarriers");
        }

        private void ParseAndSaveExistingCoverage(Payload message, IUnitOfWork unitOfWork, int caseId)
        {
            Log.TraceFormat("+SaveExistingCoverage");

            if (message.existingCoverage == null) return;

            var existingCoverageDto = new ExistingCoverageDto();
            var existingCoverage = unitOfWork.Repository<CMS.Model.Entities.ExistingCoverage>().Linq().FirstOrDefault(c => c.Case.Id == caseId);
            if (existingCoverage != null)
            {
                existingCoverageDto.Id = existingCoverage.Id;
            }

            existingCoverageDto.CaseId = caseId;
            existingCoverageDto.IsExistingGuranteedIssueCoverageIndicator = message.existingCoverage.guaranteedIssueCoverage;
            existingCoverageDto.ExistingIndividualDisabilityEligiblePopulation = message.existingCoverage.eligiblePopulation;
            if (!string.IsNullOrEmpty(message.existingCoverage.carrierId))
            {
                int gaCarrierId = GetIntValue(message.existingCoverage.carrierId);
                if (gaCarrierId > 0)
                {
                    existingCoverageDto.ExistingIndividualDisabilityCoverageTypeId = gaCarrierId;
                }
            }

            if (!string.IsNullOrEmpty(message.existingCoverage.gsiAmount))
            {
                decimal gaGSIAmount = GetDecimalValue(message.existingCoverage.gsiAmount);
                if (gaGSIAmount > 0)
                {
                    existingCoverageDto.GSIAmount = gaGSIAmount;
                }
            }

            if (!string.IsNullOrEmpty(message.existingCoverage.lastTimeEnrolled))
            {
                int gaLastTimeEnrolled = GetIntValue(message.existingCoverage.lastTimeEnrolled);
                if (gaLastTimeEnrolled > 0)
                {
                    existingCoverageDto.LastTimeEnrolled = gaLastTimeEnrolled;
                }
            }

            if (!string.IsNullOrEmpty(message.existingCoverage.premiumPayerId))
            {
                int gaPremiumPayerId = GetIntValue(message.existingCoverage.premiumPayerId);
                if (gaPremiumPayerId > 0)
                {
                    existingCoverageDto.ExistingIndividualDisabilityPremiumPayerTypeId = gaPremiumPayerId;
                }
            }

            if (!string.IsNullOrEmpty(message.existingCoverage.reasonOutToMarketId))
            {
                int gaReasonOutToMarketId = GetIntValue(message.existingCoverage.reasonOutToMarketId);
                if (gaReasonOutToMarketId > 0)
                {
                    existingCoverageDto.ExistingIndividualDisabilityReasonOutMarketTypeId = gaReasonOutToMarketId;
                    existingCoverageDto.ReasonOutMarketTypeDate = GetIntValue(message.existingCoverage.reasonOutToMarketDate);
                    existingCoverageDto.ReasonOutMarketTypeOther = message.existingCoverage.reasonOutToMarketOtherText;
                }
            }

            existingCoverageDto.ExistingIndividualDisabilityAdditionalDetailsText = message.existingCoverage.additionalDetails;

            _gaMessageManager.ExistingCoverageManager.SaveExistingCoverage(existingCoverageDto, true);

            Log.TraceFormat("-SaveExistingCoverage");
        }

        private void ParseCompanyInfo(Payload message, CaseDto caseDto)
        {
            Log.TraceFormat("+SaveCompanyInfo");

            if (message.companyInfo == null) return;

            caseDto.CompanyName = message.companyInfo.companyName;
            caseDto.CompanyAddressLine1 = message.companyInfo.address1;
            caseDto.CompanyAddressLine2 = message.companyInfo.address2;
            caseDto.CompanyCity = message.companyInfo.city;
            caseDto.CompanyZipCode = message.companyInfo.zipCode != null ? message.companyInfo.zipCode.PadLeft(5, '0') : null;
            caseDto.IsTheCompanyAlreadyGuardianGroupClientIndicator = message.companyInfo.guardianGroupAlready;

            if (!string.IsNullOrEmpty(message.companyInfo.selectedStateId))
            {
                int gaSelectedStateId = GetIntValue(message.companyInfo.selectedStateId);
                if (gaSelectedStateId > 0)
                {
                    caseDto.CompanyStateTypeId = gaSelectedStateId;
                }
            }
            caseDto.CompanyNatureOfBusiness = message.companyInfo.businessNature;
            caseDto.CompanyWebAddress = message.companyInfo.businessWebAddress;
            if (!string.IsNullOrEmpty(message.companyInfo.businessEntityId))
            {
                int gaBusinessEntityId = GetIntValue(message.companyInfo.businessEntityId);
                if (gaBusinessEntityId > 0)
                {
                    caseDto.CompanyBusinessEntityTypeId = gaBusinessEntityId;
                }
            }
            caseDto.CompanyBusinessEntityUnknownComments = message.companyInfo.businessEntityUnknown;
            caseDto.AdditionalCommentsText = message.additionalComments;
            caseDto.IsFromGA = true;
            Log.TraceFormat("-SaveCompanyInfo");
        }

        private void ParseCaseProducts(Payload message, CaseDto caseDto)
        {
            Log.TraceFormat("+SaveCaseProducts");
            var caseCompanyProducts = new List<CaseCompanyGuardianProductDto>();
            if (message.companyInfo.guardianGroupAlready && message.companyInfo.guardianProducts != null)
            {
                foreach (var companyProduct in message.companyInfo.guardianProducts)
                {
                    var caseCompanyProductDto = new CaseCompanyGuardianProductDto();
                    caseCompanyProductDto.CaseId = caseDto.CaseId;
                    caseCompanyProductDto.CompanyGuardianProductTypeId = companyProduct.productId;
                    caseCompanyProductDto.IsAlreadyAGuardianGroupClientIndicator = companyProduct.selProductValue == "Y" ? true : false;
                    caseCompanyProductDto.IsCurrentlyQuotingGuardianGroupProductIndicator = companyProduct.selProductValue == "N" ? true : false;
                    caseCompanyProducts.Add(caseCompanyProductDto);
                }
            }
            caseDto.CaseCompanyGuardianProducts = caseCompanyProducts;
            Log.TraceFormat("-SaveCaseProducts");
        }

        private int GetIntValue(string inputValue)
        {
            int value = 0;
            int.TryParse(inputValue, out value);
            return value;
        }

        private decimal GetDecimalValue(string inputValue)
        {
            decimal value = 0.00M;
            decimal.TryParse(inputValue, out value);
            return value;
        }
    }
}