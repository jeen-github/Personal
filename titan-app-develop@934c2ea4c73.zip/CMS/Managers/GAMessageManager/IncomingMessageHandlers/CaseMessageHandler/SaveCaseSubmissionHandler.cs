﻿using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.GAMessageManagers;
using CMS.Model.Entities;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.CaseMessageHandler
{
    public class SaveCaseSubmissionHandler : MessageHandlerBase
    {

        private readonly IGaMessageManager _gaMessageManager;

        public SaveCaseSubmissionHandler(IGaMessageManager gaMessageManager) : base(gaMessageManager)
        {
            _gaMessageManager = gaMessageManager;
        }

        public override bool CanHandle(GaIncomingMessage header)
        {
            return header.MessageType.Equals("CASESUBMISSIONINFO", StringComparison.InvariantCultureIgnoreCase);
        }

        public override void ProcessMessage(GaIncomingMessage messageString)
        {
            Log.Trace("+SaveCaseSubmissionHandler.ProcessMessage");

            if (string.IsNullOrEmpty(messageString.GACaseId))
            {
                Log.WarnFormat("GACaseId is null or empty");
                return;
            }

            if (messageString.Payload == null)
            {
                Log.WarnFormat("Payload is null or empty");
                return;
            }

            Payload message = JsonConvert.DeserializeObject<Payload>(messageString.Payload.ToString());

            using (var unitOfWork = _gaMessageManager.UnitOfWorkFactory.CreateUnitOfWork())
            {
                var TitanCaseId = messageString.TitanCaseId;
                var GACaseId = messageString.GACaseId;
                var GACaseSubmissionId = messageString.GACaseSubmissionId;
                var MessageType = messageString.MessageType;
                var MessageId = messageString.MessageId;
                int caseId = _gaMessageManager.CaseManager.GetCaseId(messageString.GACaseId);
                var GACaseSubmissionDto = BuildGACaseSubmissionDto(message, TitanCaseId, GACaseId, GACaseSubmissionId, MessageType, MessageId);
                _gaMessageManager.CaseManager.SaveGACaseSubmission(GACaseSubmissionDto);
            }

            Log.Trace("-SaveCaseSubmissionHandler.ProcessMessage");
        }

        private GACaseSubmissionDto BuildGACaseSubmissionDto(Payload message, string TitanCaseId, string GACaseId, string GACaseSubmissionId, string MessageType, string MessageId)
        {
            var gaCaseSubmissionDto = new GACaseSubmissionDto();

            gaCaseSubmissionDto.TitanCaseNumber = TitanCaseId;
            gaCaseSubmissionDto.GACaseId = GACaseId;
            gaCaseSubmissionDto.GACaseSubmissionId = GACaseSubmissionId;
            gaCaseSubmissionDto.MessageType = MessageType;
            gaCaseSubmissionDto.MessageId = MessageId;
            gaCaseSubmissionDto.CaseSubmissionName = message.caseSubmissionName;
            gaCaseSubmissionDto.RegionName = message.regionName;
            gaCaseSubmissionDto.ExternalWholesaler = message.externalWholesaler;
            gaCaseSubmissionDto.Note = message.note;
            gaCaseSubmissionDto.EnrollmentType = message.enrollmentType;
            gaCaseSubmissionDto.ProposedEnrollStartDate = GetDateTimeValue(message.proposedEnrollStartDate);
            gaCaseSubmissionDto.ProposedEnrollEndDate = GetDateTimeValue(message.proposedEnrollEndDate);
            gaCaseSubmissionDto.ProposedExtensionEndDate = GetDateTimeValue(message.proposedExtensionEndDate);
            gaCaseSubmissionDto.ProposedEffectiveDate = GetDateTimeValue(message.proposedEffectiveDate);
            gaCaseSubmissionDto.IsLicenseingCaseUtilizeCorpIndicator = message.licenseingCaseUtilizeCorp;
            gaCaseSubmissionDto.IsLicenseingCaseUtilizeIndProdIndicator = message.licenseingCaseUtilizeIndProd;
            gaCaseSubmissionDto.IsLicenseingCaseUtilizeIndOtherIndicator = message.licenseingCaseUtilizeIndOther;
            gaCaseSubmissionDto.CorporationName = Convert.ToString(message.corporationName);
            gaCaseSubmissionDto.CorpWritingCode = Convert.ToString(message.corpWritingCode);
            gaCaseSubmissionDto.SubProducerName = Convert.ToString(message.subProducerName);
            gaCaseSubmissionDto.SubProdWritingCode = Convert.ToString(message.subProdWritingCode);
            gaCaseSubmissionDto.IsWritingCodeInProcessIndicator = message.writingCodeInProcess;
            gaCaseSubmissionDto.AgencyCode = Convert.ToString(message.agencyCode);
            gaCaseSubmissionDto.RgoCode = Convert.ToString(message.rgoCode);
            gaCaseSubmissionDto.IndividualProducerName = Convert.ToString(message.indProdName);
            gaCaseSubmissionDto.IndividualProducerWritingCode = Convert.ToString(message.indProdWritingCode);
            gaCaseSubmissionDto.IsIndividualProducerWritingCodeInProcessIndicator = message.indProdWrCodeInProcess;
            gaCaseSubmissionDto.IndividualProducerAgencyCode = Convert.ToString(message.indProdAgencyCode);
            gaCaseSubmissionDto.IndividualProducerRGOCode = Convert.ToString(message.indProdRGOCode);
            gaCaseSubmissionDto.OtherDISpecialistName = Convert.ToString(message.diSpecialistName);
            gaCaseSubmissionDto.OtherDISpecialiastNumber = Convert.ToString(message.diSpecialiastNumber);
            gaCaseSubmissionDto.OtherGroupSaleRepName = Convert.ToString(message.grpSaleRepName);
            gaCaseSubmissionDto.OtherGroupSaleRepNumber = Convert.ToString(message.grpSaleRepNumber);
            gaCaseSubmissionDto.EnrollmentMethodType_Id = GetEnrollmentMethodTypeId(message.enrollmentDetails);
            gaCaseSubmissionDto.ClientName = message.clientName;
            gaCaseSubmissionDto.ClientPhone = message.clientPhone;
            gaCaseSubmissionDto.ClientEmail = message.clientEmail;
            gaCaseSubmissionDto.EnrollmentName = message.enrollName;
            gaCaseSubmissionDto.EnrollmentPhone = message.enrollPhone;
            gaCaseSubmissionDto.EnrollmentEmail = message.enrollEmail;
            gaCaseSubmissionDto.IsEnrollmentKitDeliveryOptionIndicator = message.enrollmentKitDeliveryOption;
            gaCaseSubmissionDto.IsMailDeliveryOptionIndicator = message.mailDeliveryOption;
            gaCaseSubmissionDto.EmailName = Convert.ToString(message.emailName);
            gaCaseSubmissionDto.EmailAddress = Convert.ToString(message.emailAddress);
            gaCaseSubmissionDto.MailName = Convert.ToString(message.mailname);
            gaCaseSubmissionDto.MailAttention = Convert.ToString(message.mailAttention);
            gaCaseSubmissionDto.MailAddress = Convert.ToString(message.mailAddress);
            gaCaseSubmissionDto.MailCity = Convert.ToString(message.mailCity);
            gaCaseSubmissionDto.MailState = Convert.ToString(message.mailState);
            gaCaseSubmissionDto.MailZipCode = message.mailZipCode != null ? Convert.ToString(message.mailZipCode).PadLeft(5, '0') : null;
            gaCaseSubmissionDto.MailDeliveryInstruction = Convert.ToString(message.mailDeliveryinstruction);
            gaCaseSubmissionDto.IsMaterialsContactInformationIndicator = message.materialsContactInfo;

            return gaCaseSubmissionDto;
        }

        private int GetEnrollmentMethodTypeId(string enrollmentDetails)
        {
            if (enrollmentDetails == "Paper Enrollment")
            {
                return 1;
            }
            else if (enrollmentDetails == "Online Enrollment")
            {
                return 2;
            }
            else
            {
                return 3;
            }
        }

        private DateTime? GetDateTimeValue(string inputValue)
        {
            DateTime value = DateTime.Now;
            if (DateTime.TryParse(inputValue, out value))
            {
                return value;
            }
            else
            {
                return null;
            }
        }
    }
}
