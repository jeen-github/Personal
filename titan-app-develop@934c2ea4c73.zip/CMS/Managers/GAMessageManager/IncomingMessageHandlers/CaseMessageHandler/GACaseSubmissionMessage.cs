﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers.CaseMessageHandler
{
    public class Payload
    {
        public string caseSubmissionName { get; set; }
        public string regionName { get; set; }
        public string externalWholesaler { get; set; }
        public string note { get; set; }
        public string enrollmentType { get; set; }
        public string proposedEnrollStartDate { get; set; }
        public string proposedEnrollEndDate { get; set; }
        public string proposedExtensionEndDate { get; set; }
        public string proposedEffectiveDate { get; set; }
        public bool licenseingCaseUtilizeCorp { get; set; }
        public bool licenseingCaseUtilizeIndProd { get; set; }
        public bool licenseingCaseUtilizeIndOther { get; set; }
        public object corporationName { get; set; }
        public object corpWritingCode { get; set; }
        public object subProducerName { get; set; }
        public object subProdWritingCode { get; set; }
        public bool writingCodeInProcess { get; set; }
        public object agencyCode { get; set; }
        public object rgoCode { get; set; }
        public object indProdName { get; set; }
        public object indProdWritingCode { get; set; }
        public bool indProdWrCodeInProcess { get; set; }
        public object indProdAgencyCode { get; set; }
        public object indProdRGOCode { get; set; }
        public object diSpecialistName { get; set; }
        public object diSpecialiastNumber { get; set; }
        public object grpSaleRepName { get; set; }
        public object grpSaleRepNumber { get; set; }
        public string enrollmentDetails { get; set; }
        public string clientName { get; set; }
        public string clientPhone { get; set; }
        public string clientEmail { get; set; }
        public string enrollName { get; set; }
        public string enrollPhone { get; set; }
        public string enrollEmail { get; set; }
        public bool enrollmentKitDeliveryOption { get; set; }
        public bool mailDeliveryOption { get; set; }
        public object emailName { get; set; }
        public object emailAddress { get; set; }
        public object mailname { get; set; }
        public object mailAttention { get; set; }
        public object mailAddress { get; set; }
        public object mailCity { get; set; }
        public object mailState { get; set; }
        public object mailZipCode { get; set; }
        public object mailDeliveryinstruction { get; set; }
        public bool materialsContactInfo { get; set; }
    }
    public class RootObject
    {
        public string TitanCaseId { get; set; }
        public string GACaseId { get; set; }
        public string GACaseSubmissionId { get; set; }
        public string MessageType { get; set; }
        public string MessageId { get; set; }
        public Payload Payload { get; set; }
    }


}
