﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers
{
    public class GAMessageDto
    {

    }
    public class CompanyInfo
    {
        public string companyName { get; set; }
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string city { get; set; }
        public string zipCode { get; set; }
        public string selectedStateId { get; set; }
        public string businessNature { get; set; }
        public string businessWebAddress { get; set; }
        public string businessEntityId { get; set; }
        public string businessEntityUnknown { get; set; }
        public bool guardianGroupAlready { get; set; }
        public bool competitionCase { get; set; }
        public List<string> carrier { get; set; }
        public List<GuardianProduct> guardianProducts { get; set; }
    }

    public class ExistingCoverage
    {
        public bool guaranteedIssueCoverage { get; set; }
        public string eligiblePopulation { get; set; }
        public string gsiAmount { get; set; }
        public string lastTimeEnrolled { get; set; }
        public string additionalDetails { get; set; }
        public string reasonOutToMarketDate { get; set; }
        public string carrierId { get; set; }
        public string premiumPayerId { get; set; }
        public string reasonOutToMarketId { get; set; }
        public string reasonOutToMarketOtherText { get; set; }
    }

    public class BrokerDetail
    {
        public string brokerName { get; set; }
        public string affiliationsId { get; set; }
        public string agencyCode { get; set; }
        public string regionalGroupOfficeCode { get; set; }
        public string companyName { get; set; }
        public string writingCode { get; set; }
    }

    public class Payload 
    {
        public string additionalComments { get; set; }
        public CompanyInfo companyInfo { get; set; }
        public ExistingCoverage existingCoverage { get; set; }
        public List<BrokerDetail> brokerDetail { get; set; }
    }

    public class GuardianProduct
    {
        public int productId { get; set; }
        public string selProductValue { get; set; }
    }

  


}
