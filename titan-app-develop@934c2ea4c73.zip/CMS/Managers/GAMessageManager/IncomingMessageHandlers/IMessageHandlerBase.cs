﻿using CMS.Interfaces.Managers.GAMessageManagers;

namespace CMS.Managers.GAMessageManagers.IncomingMessageHandlers
{
    public abstract class MessageHandlerBase
    {
        protected readonly IGaMessageManager GaMessageManager;

        public MessageHandlerBase(IGaMessageManager gaMessageManager)
        {
            GaMessageManager = gaMessageManager;
        }

        public abstract bool CanHandle(GaIncomingMessage header);

        public abstract void ProcessMessage(GaIncomingMessage messageString);
    }
}