﻿using System;
using System.Dynamic;
using Common.Exceptions;
using Logger.Static;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace CMS.Managers.GAMessageManagers
{
    public class GaIncomingMessageParser
    {
        public static GaIncomingMessage ParseMessageHeader(string messageString)
        {
            Log.TraceFormat("+ParseMessageHeader");

            var message = JsonConvert.DeserializeObject<GaIncomingMessage>(messageString);

            Log.TraceFormat("-ParseMessageHeader");
            return message;
        }
    }
}
    