﻿using System;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.GAMessageManagers.OutgoingMessages;
using CMS.Model.Entities;
using Logger.Static;

namespace CMS.Managers.GAMessageManagers
{
    public class GaMessageHistoryManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public int MessageHistoryId { get; set; }

        public GaMessageHistoryManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        internal void SaveMessageToHistory(string messageString)
        {
            Log.TraceFormat("+SaveMessageToHistory");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var messageHistory = new GaMessageHistory();

                messageHistory.ReceivedDateTime = DateTime.Now;
                messageHistory.MessageBody = messageString;

                unitOfWork.Repository<GaMessageHistory>().Save(messageHistory);
                unitOfWork.Commit();

                MessageHistoryId = messageHistory.Id;
            }

            Log.TraceFormat("-SaveMessageToHistory");
        }

        internal void SaveMessageToHistory(string messageString, GaOutgoingMessage message)
        {
            Log.TraceFormat("+SaveMessageToHistory");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var messageHistory = new GaMessageHistory
                {
                    ReceivedDateTime = DateTime.Now,
                    MessageBody = messageString,
                    MessageType = message.MessageType,
                    GaCaseId = message.GACaseId,
                    MessageId = message.MessageId
                };
                
                unitOfWork.Repository<GaMessageHistory>().Save(messageHistory);
                unitOfWork.Commit();

                MessageHistoryId = messageHistory.Id;
            }

            Log.TraceFormat("-SaveMessageToHistory");
        }

        internal void UpdateMessageHistory(GaIncomingMessage message)
        {
            Log.TraceFormat("+SaveMessageToHistory");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var messageHistory = unitOfWork.Repository<GaMessageHistory>().Linq().FirstOrDefault(m => m.Id == MessageHistoryId);
                if (messageHistory == null) return;
                
                messageHistory.MessageId = message.MessageId;
                messageHistory.MessageType = message.MessageType;
                messageHistory.GaCaseId = message.GACaseId;
                messageHistory.GaPDRId = message.GAPDRId;

                unitOfWork.Repository<GaMessageHistory>().Save(messageHistory);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveMessageToHistory");
        }

        internal void UpdateMessageHistory(Exception ex)
        {
            Log.TraceFormat("+SaveMessageToHistory");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var messageHistory = unitOfWork.Repository<GaMessageHistory>().Linq().FirstOrDefault(m => m.Id == MessageHistoryId);
                if (messageHistory == null) return;

                messageHistory.IsSuccessIndicator = false;
                messageHistory.ErrorMessage = string.Format("{0} {1}", ex.Message, ex.StackTrace);
                messageHistory.ProcessEndTime = DateTime.Now;
                unitOfWork.Repository<GaMessageHistory>().Save(messageHistory);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveMessageToHistory");
        }

        internal void UpdateMessageHistoryWithSuccess()
        {
            Log.TraceFormat("+SaveMessageToHistory");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var messageHistory = unitOfWork.Repository<GaMessageHistory>().Linq().FirstOrDefault(m => m.Id == MessageHistoryId);
                if (messageHistory == null) return;

                messageHistory.IsSuccessIndicator = true;
                messageHistory.ProcessEndTime = DateTime.Now;

                unitOfWork.Repository<GaMessageHistory>().Save(messageHistory);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveMessageToHistory");
        }
    }
}