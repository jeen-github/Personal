﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Security.Claims;
using System.Security.Principal;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.UserProfileServices;
using CMS.Interfaces.Managers.SecurityManagers;
using CMS.Interfaces.Managers.TaskManagers;
using CMS.Model.Entities;
using Common.Exceptions;
using Logger.Static;

namespace SecurityManagers
{
    public class SecurityManager : ISecurityManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IUserProfileServiceClient _userProfileServiceClient;

        public SecurityManager(IUnitOfWorkFactory unitOfWorkFactory, IUserProfileServiceClient userProfileServiceClient)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _userProfileServiceClient = userProfileServiceClient;
        }

        public UserInfoDto GetUserInfo(string ldapUserId)
        {
            Log.TraceFormat("+GetUserInfo ldapUserId={0}", ldapUserId);

            UserInfoDto userInfo;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var user = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(u => u.LdapUserName == ldapUserId);
                if (user == null) throw new SecurityException("User not provisioned");

                userInfo = new UserInfoDto
                {
                    TitanUserId = user.Id,
                    LdapUserId = user.LdapUserName,
                    Name = string.Format("{0} {1}", user.FirstName, user.LastName)
                };
            }

            Log.TraceFormat("-GetUserInfo");

            return userInfo;
        }

        public List<UserInfoDto> GetEnrollmentManagerAndAnalystsInfo()
        {
            Log.TraceFormat("+GetEnrollmentManagerAndAnalystsInfo");

            List<UserInfoDto> userInfoList;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                int[] applicableUserGroupIds = { UserGroup.Group_EnrollmentManager, UserGroup.Group_Implementation_Analyst };
                userInfoList = unitOfWork.Repository<CmsUser>().Linq()
                    .Where(user => user.UserGroups.Any(userGroup => applicableUserGroupIds.Contains(userGroup.Id)))
                    .OrderBy(user => user.LastName)
                    .Select(user => new UserInfoDto
                    {
                        TitanUserId = user.Id,
                        Name = $"{user.FirstName} {user.LastName}"
                    })
                    .ToList();
            }

            Log.TraceFormat("-GetEnrollmentManagerAndAnalystsInfo");

            return userInfoList;
        }

        public UserInfoDto GetUserInfo(IPrincipal principal)
        {
            var user = principal as ClaimsPrincipal;
            if (user == null) throw new BusinessException("Security error!", "Current user is null or not of ClaimsPrincipal type");

            var userInfo = new UserInfoDto();

            userInfo.TitanUserId = int.Parse(GetClaim(user.Claims, UserInfoDto.TitanUserIdClaimName));
            userInfo.LdapUserId = GetClaim(user.Claims, UserInfoDto.LdapUserIdClaimName);
            userInfo.Name = GetClaim(user.Claims, UserInfoDto.NameClaimName);

            return userInfo;
        }

        public List<Claim> GetClaims(UserInfoDto userInfo)
        {
            var claims = new List<Claim>();

            claims.Add(new Claim(UserInfoDto.TitanUserIdClaimName, userInfo.TitanUserId.ToString()));
            claims.Add(new Claim(UserInfoDto.LdapUserIdClaimName, userInfo.LdapUserId));
            claims.Add(new Claim(UserInfoDto.NameClaimName, userInfo.Name));

            return claims;
        }

        public void RefreshUserRoles(string ldapUserId)
        {
            Log.TraceFormat("+RefreshUserRoles ldapUserId={0}", ldapUserId);

            try
            {
                using (var uw = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var currentUser = GetUserFromDb(ldapUserId, uw);

                    var daysSinceLastModification = (DateTime.Now - currentUser.ModificationTime).TotalDays;
                    var shouldCheckUserRoles = daysSinceLastModification > 1;
                    Log.TraceFormat("ldapUserId={0} shouldCheckUserRoles={1}", ldapUserId, shouldCheckUserRoles);
                    if (shouldCheckUserRoles)
                    {
                        var currentUserDbRoles = currentUser.UserGroups.Where(g => g.LdapGroupIndicator).Select(g => g.GroupName.ToLower()).ToList();
                        var currentUserProfileRoles = GetRoleFromUserProfile(ldapUserId, currentUser);

                        var newRoles = currentUserProfileRoles.Except(currentUserDbRoles).ToList();
                        var removedRoles = currentUserDbRoles.Except(currentUserProfileRoles).ToList();
                        Log.TraceFormat("Added roles:{0} Removed roles:{1}", string.Join(",", newRoles), string.Join(",", removedRoles));

                        if (newRoles.Any())
                        {
                            AddNewRoles(currentUser, newRoles, uw);
                        }

                        if (removedRoles.Any())
                        {
                            RemoveRoles(currentUser, removedRoles);
                        }

                        currentUser.ModificationTime = DateTime.Now;
                        uw.Repository<CmsUser>().Save(currentUser);
                        uw.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Failed to refresh user roles data", ex);
            }

            Log.TraceFormat("-RefreshUserRoles ldapUserId={0}", ldapUserId);
        }

        private CmsUser GetUserFromDb(string ldapUserId, IUnitOfWork unitOfWork)
        {
            var user = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(u => u.LdapUserName == ldapUserId);

            if (user == null)
            {
                user = new CmsUser() { LdapUserName = ldapUserId };
            }

            return user;
        }

        private void AddNewRoles(CmsUser user, IList<string> newRoles, IUnitOfWork unitOfWork)
        {
            var titanRoles = unitOfWork.Repository<UserGroup>().Linq().ToDictionary(k => k.GroupName, v => v);
            foreach (var role in newRoles)
            {
                user.UserGroups.Add(titanRoles[role]);
            }
        }

        private void RemoveRoles(CmsUser user, List<string> removedRoles)
        {
            foreach (var removedRole in removedRoles)
            {
                user.UserGroups = user.UserGroups.Where(userGroup => userGroup.GroupName != removedRole).ToList();
            }
        }

        private List<string> GetRoleFromUserProfile(string ldapUserId, CmsUser user)
        {
            try
            {
                var profile = _userProfileServiceClient.GetUserProfile(ldapUserId);

                user.FirstName = profile.FirstName;
                user.LastName = profile.LastName;
                user.EmailAddress = profile.EmailAddress;

                return profile.LdapUserGroups
                    .Select(g => g.ToLowerInvariant())
                    .Where(g => g.StartsWith("titan"))
                    .ToList();
            }
            catch (Exception e)
            {
                Log.Fatal("UserProfile service unavailable", e);
                throw;
            }
        }

        private string GetClaim(IEnumerable<Claim> claims, string claimName)
        {
            var claim = claims.FirstOrDefault(c => c.Type == claimName);
            return claim != null ? claim.Value : string.Empty;
        }

        public IList<UserGroup> GetUserGroups(string ldapUserId)
        {
            var userGroups = new List<UserGroup>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var user = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(u => u.LdapUserName == ldapUserId);
                if (user == null) throw new SecurityException("User not provisioned");
                userGroups = user.UserGroups.Select(c => new UserGroup
                {
                    Id = c.Id,
                    DisplayName = c.DisplayName,
                    GroupName = c.GroupName,
                }).ToList();
            }
            return userGroups;
        }


        public List<UserInfoDto> GetUsersByGroup(int usergroupId)
        {
            Log.TraceFormat("+GetUsersByGroup");

            List<UserInfoDto> userInfo = new List<UserInfoDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsUser = unitOfWork.Repository<CmsUser>().Linq().ToList();

                userInfo = unitOfWork.Repository<CmsUser>().Linq().Where(c => c.UserGroups.Where(ug => ug.Id == usergroupId).Count() > 0).Select(t => new UserInfoDto
                {
                    TitanUserId = t.Id,
                    Name = string.Format("{0} {1}", t.FirstName, t.LastName)
                }).ToList();
            }

            Log.TraceFormat("-GetUsersByGroup");

            return userInfo;
        }

        public List<UserGroupDto> GetUserGroupForTask()
        {
            var userGroups = new List<UserGroupDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                userGroups = unitOfWork.Repository<UserGroup>().Linq().Where(c => c.GroupName == "titan_underwriter_manager"
                                                                               || c.GroupName == "titan_underwriter"
                                                                               || c.GroupName == "titan_implementation_analyst"
                                                                               || c.GroupName == "titan_implementation_manager"
                                                                               || c.GroupName == "titan_implementation_supervisor"
                                                                               || c.GroupName == "titan_billing_specialist"
                                                                               || c.GroupName == "titan_policyissue_specialist"
                                                                               || c.GroupName == "titan_billing_manager"
                                                                               || c.GroupName == "titan_quality_manager"
                                                                               || c.GroupName == "titan_quality_specialist"
                                                                               || c.GroupName == "titan_tech_support")
                                                                               .Select(ug => new UserGroupDto
                                                                               {
                                                                                   Id = ug.Id,
                                                                                   Name = ug.DisplayName
                                                                               }).ToList();
            }

            return userGroups;

        }

        public List<int> GetAccessableRolesByByUser(string ldapUserId)
        {
            var userGroupIds = new List<int>();
            var subUserGroupIds = new List<int>();

            var userGroups = GetUserGroups(ldapUserId);
            if (userGroups.Any())
            {
                userGroupIds = userGroups.Select(usr => usr.Id).Distinct().ToList();

                foreach (var userGroupId in userGroupIds)
                {
                    if (userGroupId == UserGroup.Group_UnderwritingManager)
                    {
                        subUserGroupIds.Add(UserGroup.Group_Underwriting);
                    }
                    else if (userGroupId == UserGroup.Group_Implementation_Analyst)
                    {
                        subUserGroupIds.Add(UserGroup.Group_EnrollmentManager);
                    }
                    else if (userGroupId == UserGroup.Group_EnrollmentManager)
                    {
                        subUserGroupIds.Add(UserGroup.Group_Implementation_Analyst);
                    }
                    else if (userGroupId == UserGroup.Group_EnrollmentSupervisor)
                    {
                        subUserGroupIds.Add(UserGroup.Group_EnrollmentManager);
                        subUserGroupIds.Add(UserGroup.Group_Implementation_Analyst);
                    }
                    else if (userGroupId == UserGroup.Group_BillingManager)
                    {
                        subUserGroupIds.Add(UserGroup.Group_BillingSpecialist);
                        subUserGroupIds.Add(UserGroup.Group_PolicyIssueSpecialist);
                    }
                    else if (userGroupId == UserGroup.Group_QualitySpecialist || userGroupId == UserGroup.Group_QualityManager)
                    {
                        subUserGroupIds.Add(UserGroup.Group_Underwriting);
                        subUserGroupIds.Add(UserGroup.Group_UnderwritingManager);
                        subUserGroupIds.Add(UserGroup.Group_EnrollmentManager);
                        subUserGroupIds.Add(UserGroup.Group_Implementation_Analyst);
                        subUserGroupIds.Add(UserGroup.Group_EnrollmentSupervisor);
                        subUserGroupIds.Add(UserGroup.Group_BillingSpecialist);
                        subUserGroupIds.Add(UserGroup.Group_BillingManager);
                        subUserGroupIds.Add(UserGroup.Group_PolicyIssueSpecialist);
                    }
                }
            }

            return userGroupIds.Concat(subUserGroupIds).ToList();
        }

        public List<ConfidentialCaseUserGroupDto> GetConfidentialCaseUserGroup()
        {
            Log.TraceFormat("+GetConfidentialCaseUserGroup");

            var userGroupsList = new List<ConfidentialCaseUserGroupDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var userGroups = unitOfWork.Repository<ConfidentialCaseUserGroupType>().Linq();

                if (userGroups == null) throw new SecurityException("ConfidentialCaseUserGroup not provisioned");

                var confidentialCaseGroupDto = userGroups.Select(c => new ConfidentialCaseUserGroupDto
                {
                    UserGroupId = c.UserGroup_Id,
                    IsActiveIndicator = c.IsActiveIndicator,

                }).ToList();

                Log.TraceFormat("-GetConfidentialCaseUserGroup");

                return confidentialCaseGroupDto;
            }
            
        }
    }
}
