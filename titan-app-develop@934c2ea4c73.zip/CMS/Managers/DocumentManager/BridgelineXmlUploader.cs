﻿using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using Common.Utilities;
using Logger.Static;
using RestSharp;
using System;
using System.Linq;
using System.Text;

namespace CMS.Managers.DocumentManagers
{
    public class BridgelineXmlUploader : IAxwayFileUploader, IWorkUnitHandler
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IConfiguration _configuration;
        private readonly IWorkUnitManager _workUnitManager;

        public BridgelineXmlUploader(IUnitOfWorkFactory unitOfWorkFactory, IConfiguration configuration, IWorkUnitManager workUnitManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _configuration = configuration;
            _workUnitManager = workUnitManager;
        }

        public void Execute(WorkUnit workUnit)
        {
            var nextDocumentId = int.Parse(workUnit.InputData);
            UploadBridgelineXMLToAxway(nextDocumentId);
        }

        public void UploadBridgelineXMLToAxway(int nextDocumentId)
        {
            Log.TraceFormat("+SendDocumentRequestToAxway bridgelineDocumentId:{0}", nextDocumentId);
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var bridgelineXML = unitOfWork.Repository<BridgelineXml>().Linq().FirstOrDefault(c => c.Id == nextDocumentId);
                    if (bridgelineXML != null)
                    {
                        SendToFTP(bridgelineXML.Name, Encoding.UTF8.GetBytes(bridgelineXML.FileContent));

                        bridgelineXML.Status = "Sent to Bridgeline";
                        unitOfWork.Repository<BridgelineXml>().Save(bridgelineXML);
                        unitOfWork.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error sending files to Axway", ex);
                throw new RetryWorkUnitException(TimeSpan.FromMinutes(1), ex);
            }
            Log.TraceFormat("-SendDocumentRequestToAxway bridgelineDocumentId:{0}", nextDocumentId);
        }

        private void SendToFTP(string fileName, byte[] fileContent)
        {
            Log.TraceFormat("+SendFileToHttp FileName={0}", fileName);
            try
            {
                var restClient = new RestServiceClient(_configuration.AxwayBridgelineXmlUploadUrl,
                    _configuration.ExtreamAxwayCredentials.UserName, _configuration.ExtreamAxwayCredentials.Password);

                var restRequest = new RestRequest { Method = Method.POST };
                restRequest.AddFileBytes("titan", fileContent, fileName, "application/xml");

                restClient.SendRequest(restRequest);
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Failed to upload Bridgeline XML:{0}", ex, fileName);
                throw;
            }
            Log.TraceFormat("-SendFileToHttp FileName={0}", fileName);
        }
    }
}