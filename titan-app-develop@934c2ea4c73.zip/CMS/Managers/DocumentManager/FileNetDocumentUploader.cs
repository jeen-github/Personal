﻿using System;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.FileNetDocumentRepositories;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Logger.Static;
using Timer = System.Timers.Timer;

namespace CMS.Managers.DocumentManagers
{
    public class FileNetDocumentUploader : IFileNetDocumentUploader
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;        
        private readonly IFileNetDocumentRepository _fileNetDocumentRepository;
        private Timer _databasePollingTimer;

        public FileNetDocumentUploader(IUnitOfWorkFactory unitOfWorkFactory, IFileNetDocumentRepository fileNetDocumentRepository)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _fileNetDocumentRepository = fileNetDocumentRepository;
        }

        public void StartFileNetDocumentUploader()
        {
            Log.TraceFormat("+StartFileNetDocumentUploader");

            _databasePollingTimer = new Timer { Interval = 1000 };
            _databasePollingTimer.AutoReset = false;            

            _databasePollingTimer.Elapsed += (object sender, System.Timers.ElapsedEventArgs e) =>
            {
                ProcessDocument();
                _databasePollingTimer.Start();
            };

            _databasePollingTimer.Start();

            Log.TraceFormat("-StartFileNetDocumentUploader");
        }

        public void StopFileNetDocumentUploader()
        {
            Log.TraceFormat("StopFileNetDocumentUploader");

            if (_databasePollingTimer != null)
            {
                _databasePollingTimer.Enabled = false;
                _databasePollingTimer.Stop();
            }
        }

        private void ProcessDocument()
        {
            int? nextDocumentId = null;
            try
            {
                nextDocumentId = GetNextDocumentId();
                //nextDocumentId = 646961; //comes from  [TITAN_UAT_DB].[cms].[CaseDocument]

                if (nextDocumentId == null) return;

                Log.TraceFormat("Extracted to upload document id:{0}", nextDocumentId);

                FileNetDocUploadResponse documentUploadResponse = new FileNetDocUploadResponse();

                var documentUploadRequest = CreateFileNetUploadRequest(nextDocumentId.Value);                

                if (documentUploadRequest.IsNBApps)
                { 
                    documentUploadResponse = _fileNetDocumentRepository.UploadDocumentToNBApps(documentUploadRequest); 
                }
                else
                { 
                    documentUploadResponse = _fileNetDocumentRepository.UploadDocument(documentUploadRequest); 
                }
                

                SaveFileNetDocumentNumber(nextDocumentId.Value, documentUploadResponse);
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error in FileNetDocumentUploader", ex);
                IncreaseUploadRetriesNumber(nextDocumentId);
            }
        }

        private int? GetNextDocumentId()
        {
            int? nextDocumentId = null;
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    nextDocumentId = unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_GetNextDocumentFileNetRequest]").FirstOrDefault();
                    unitOfWork.Commit();

                    //nextDocumentId = 534070;
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR calling [USP_GetNextDocumentFileNetRequest]", ex);
            }

            return nextDocumentId;
        }

        private FileNetDocUploadRequest CreateFileNetUploadRequest(int documentId)
        {
            Log.TraceFormat("+CreateFileNetUploadRequest:{0}", documentId);
            FileNetDocUploadRequest uploadRequest = null;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var document = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == documentId);
                if (document == null) throw new ApplicationException("Document not found with id:" + documentId);

                var enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq().FirstOrDefault(c => c.Other.Id == documentId);
                
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == document.Case_Id);
                if (cmsCase == null) throw new ApplicationException("Case not found with id:" + document.Case_Id);

                var fileNetDocumentType = GetFileNetDocumentType(document.FileMimeType);

                var docClassRequest = GetdocumentClass(documentId);

                if (docClassRequest.isNBApps)
                {
                    uploadRequest = new FileNetDocUploadRequest(
                         cmsCase.CaseNumber,
                         CaseDocumentTypeEnum.Application,
                         document.DocumentName ?? document.FileName,
                         fileNetDocumentType,
                         document.FileBytes,
                         document.FileMimeType,
                         docClassRequest.ParticipantFirstName,
                         docClassRequest.ParticipantLastName,
                         docClassRequest.PolicyNumber,
                         docClassRequest.isNBApps,
                         docClassRequest.AgencyCode,
                         docClassRequest.SSN,
                         "titansystem", enrollmentParticipant?.Id
                         );
                }
                else
                {
                    uploadRequest = new FileNetDocUploadRequest(
                        cmsCase.CaseNumber,
                        document.CaseDocumentType,
                        document.DocumentName ?? document.FileName,
                        fileNetDocumentType,
                        document.FileBytes,
                        document.FileMimeType
                        );
                }
            }

            Log.TraceFormat("-CreateFileNetUploadRequest:{0}", documentId);
            return uploadRequest;
        }        

        private void SaveFileNetDocumentNumber(int documentId, FileNetDocUploadResponse uploadResponse)
        {
            Log.TraceFormat("+SaveFileNetDocumentNumber: DocId:{0} FileNetId:{1}", documentId, uploadResponse.DocumentNumber);
            
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var document = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == documentId);
                if (document == null) throw new ApplicationException("Document not found with id:" + documentId);

                document.FileNetDocumentId = uploadResponse.DocumentNumber;
                document.NewFileNetDocumentId = uploadResponse.NewDocumentNumber;
                document.FileBytes = null;

                unitOfWork.Repository<CaseDocument>().Save(document);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveFileNetDocumentNumber:{0}", documentId);
        }

        private void IncreaseUploadRetriesNumber(int? documentId)
        {
            Log.TraceFormat("+IncreaseUploadRetriesNumber:{0}", documentId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var document = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == documentId);
                if (document == null) throw new ApplicationException("Document not found with id:" + documentId);

                document.IsFileNetUploadedIndicator = false;
                document.FileNetUploadRetries++;

                unitOfWork.Repository<CaseDocument>().Save(document);
            }

            Log.TraceFormat("-IncreaseUploadRetriesNumber:{0}", documentId);
        }

        private FileNetDocumentContentType GetFileNetDocumentType(string documentFileMimeType)
        {
            if (documentFileMimeType.ToLowerInvariant().Contains("pdf")) return FileNetDocumentContentType.PDF;            
            if (documentFileMimeType.ToLowerInvariant().Contains("postscript")) return FileNetDocumentContentType.EPS;

            if (documentFileMimeType.ToLowerInvariant().Contains("excel")) return FileNetDocumentContentType.XLS;
            if (documentFileMimeType.ToLowerInvariant().Contains("spreadsheetml.sheet")) return FileNetDocumentContentType.XLSX;
            if (documentFileMimeType.ToLowerInvariant().Contains("powerpoint")) return FileNetDocumentContentType.PPT;
            if (documentFileMimeType.ToLowerInvariant().Contains("presentationml.presentation")) return FileNetDocumentContentType.PPTX;             
            if (documentFileMimeType.ToLowerInvariant().Contains("word")) return FileNetDocumentContentType.DOC;
            if (documentFileMimeType.ToLowerInvariant().Contains("wordprocessingml.document")) return FileNetDocumentContentType.DOCX;
            if (documentFileMimeType.ToLowerInvariant().Contains("csv")) return FileNetDocumentContentType.TXT;
            if (documentFileMimeType.ToLowerInvariant().Contains("text")) return FileNetDocumentContentType.TXT;

            if (documentFileMimeType.ToLowerInvariant().Contains("png")) return FileNetDocumentContentType.PNG;
            if (documentFileMimeType.ToLowerInvariant().Contains("jpg")) return FileNetDocumentContentType.JPG;
            if (documentFileMimeType.ToLowerInvariant().Contains("jpeg")) return FileNetDocumentContentType.JPEG;
            if (documentFileMimeType.ToLowerInvariant().Contains("tif")) return FileNetDocumentContentType.TIF;
            if (documentFileMimeType.ToLowerInvariant().Contains("tiff")) return FileNetDocumentContentType.TIFF;
            if (documentFileMimeType.ToLowerInvariant().Contains("gif")) return FileNetDocumentContentType.GIF;
            
            throw new ApplicationException("MIME type not supported by FileNet: " + documentFileMimeType);
        }

        private NBAppsRequest GetdocumentClass(int? documentId)
        {
            Log.TraceFormat("+GetdocumentClass:{0}", documentId);
            NBAppsRequest request = new NBAppsRequest();

            try 
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                                         .FirstOrDefault(x => x.Other.Id == documentId);

                    // This below if logic is only for DC enollment types.
                    if (enrollmentParticipant == null)
                    {
                        enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                                         .FirstOrDefault(x => x.Kit.Id == documentId);

                        if (enrollmentParticipant != null)
                        {
                            var enrollment = unitOfWork.Repository<Enrollment>().Linq()
                                                                .FirstOrDefault(x => x.Id == enrollmentParticipant.Enrollment.Id);

                            if (enrollment.EnrollmentMethodType.Id != (int)EnrollmentMethodTypeEnum.DirectCoverage)
                            {
                                enrollmentParticipant = null;
                            }
                        }
                    }

                    if (enrollmentParticipant != null && enrollmentParticipant.Enrollment != null)
                    {
                        var enrollment = unitOfWork.Repository<Enrollment>().Linq()
                                                             .FirstOrDefault(x => x.Id == enrollmentParticipant.Enrollment.Id);
                        if (enrollment.EnrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.OneStep || enrollment.EnrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.DirectCoverage)
                        {
                            request.isNBApps = true;
                            request.ParticipantFirstName = enrollmentParticipant?.Participant?.FirstName;
                            request.ParticipantLastName = enrollmentParticipant?.Participant?.LastName;
                            request.SSN = enrollmentParticipant.Participant.SocialSecurityNumber;
                            request.AgencyCode = enrollmentParticipant.Enrollment?.Case?.CaseBrokers.Where(i => i.AgencyCode != null)?.FirstOrDefault().AgencyCode;
                            if (enrollmentParticipant.Policies.Any())
                            {
                                Log.TraceFormat($"GetdocumentClass: PolicyNumber found for the participant for the kit id {documentId}");
                                request.PolicyNumber = enrollmentParticipant?.Policies.FirstOrDefault().PolicyNumber;
                            }
                            else
                            {
                                Log.TraceFormat($"GetdocumentClass: PolicyNumber not found for the participant for the kit id {documentId}, assigning a temp policynumber");
                                request.PolicyNumber = "Z99999"; //Temp policy number
                            }
                        }
                        else { request.isNBApps = false; }
                    }
                    else { request.isNBApps = false; }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat($"GetdocumentClass: Unable to determine Document class for the participants for the kit id {documentId} exception {ex.Message}");
            }
            
            Log.TraceFormat("-GetdocumentClass:{0}", documentId);
            
            return request;           
        }       
    }

    public class NBAppsRequest
    {       
        public string ParticipantLastName { get; set; }
        public string ParticipantFirstName { get; set; }
        public bool isNBApps { get; set; }
        public string PolicyNumber { get; set; }
        public string AgencyCode { get; set; }
        public string SSN { get; set; }
    }
}
