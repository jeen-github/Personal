﻿using System;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Model.Entities;
using Logger.Static;
using Timer = System.Timers.Timer;
using CMS.Interfaces.Configurations;
using Newtonsoft.Json;
using CMS.Interfaces.Managers.ImplementationManagers;
using System.Diagnostics;
using CMS.DataAccess.Repositories;
using CMS.Managers.DocumentManagers.DocumentGenerators;
using Common.Utilities;
using CMS.Model.Enums;
using CMS.Model.Extensions;

namespace CMS.Managers.DocumentManagers
{
    public class AxwaySalesForceUploader : IAxwaySalesForceUploader
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IConfiguration _configuration;
        private readonly IEmailCampaignManager _iEmailCampaignManager;
        private Timer _databasePollingTimer;


        public AxwaySalesForceUploader(IUnitOfWorkFactory unitOfWorkFactory, IConfiguration configuration, IEmailCampaignManager iEmailCampaignManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _configuration = configuration;
            _iEmailCampaignManager = iEmailCampaignManager;
        }       

        public void StartSalesForceDocumentUploader()
        {
            Log.TraceFormat("+StartSalesForceDocumentUploader");

            if (Debugger.IsAttached)
            {
                ProcessAxwayCSVDocument();
            }

            _databasePollingTimer = new Timer { Interval = 100000 };
            _databasePollingTimer.AutoReset = false;

            _databasePollingTimer.Elapsed += (object sender, System.Timers.ElapsedEventArgs e) =>
            {
                ProcessAxwayCSVDocument();
                _databasePollingTimer.Start();
            };

            _databasePollingTimer.Start();

            Log.TraceFormat("-StartSalesForceDocumentUploader");
        }

        public void ProcessAxwayCSVDocument()
        {
            Log.TraceFormat("+ProcessAxwayCSVDocument");

            var objErollmentEmail = new EnrollmentEmail();
            int triggerHour = _configuration.ExtreamAxwayStfpJobTriggerHour; // This will send the CSV file at an exact hour in a day

            int? emailEnrollmentId = ExtractEnrollmentEmailIds();
            if (emailEnrollmentId == null) return;

            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var enrollmentEmailList = unitOfWork.Repository<EnrollmentEmail>().LinqWithTimeOut().Where(i => i.Id == emailEnrollmentId);
                    if (enrollmentEmailList == null || !enrollmentEmailList.Any()) return;

                    foreach (var enrollmentEmail in enrollmentEmailList)
                    {
                        if (enrollmentEmail.SendDate <= DateTime.Now)
                        {
                            objErollmentEmail = enrollmentEmail;
                            var caseNumber = unitOfWork.Repository<Case>().Linq().FirstOrDefault(i => i.Id == enrollmentEmail.Enrollment.Case.Id).CaseNumber;

                            string fileName = "MLDE_" + caseNumber + ".csv";

                            var csvData = _iEmailCampaignManager.GenerateCsv(enrollmentEmail.Enrollment.Id, enrollmentEmail.Id);

                            if (_iEmailCampaignManager.UploadSalesForceCSVToAxway(csvData, enrollmentEmail.Id, fileName))
                            {
                                Log.TraceFormat($"AxwaySalesForceUploader:SendCSVRefreshFile: filename: {fileName}, csvdata: {csvData}, EnrollmentEmailId: {enrollmentEmail.Id} ");
                                
                                _iEmailCampaignManager.CreateCaseDocument(enrollmentEmail, csvData, fileName);                                                                

                                SaveCSVUploadStatus(enrollmentEmail, true);
                            }
                            else
                            {
                                SaveCSVUploadStatus(enrollmentEmail, false);
                            }
                        }                        
                    }
                }               
            }
            catch (Exception ex)
            {
                Log.ErrorFormat($"AxwaySalesForceUploader: Error in ProcessAxwayCSVDocument {JsonConvert.SerializeObject(objErollmentEmail)}", ex);               
            }

            Log.TraceFormat("-ProcessAxwayCSVDocument");
        }

        private int? ExtractEnrollmentEmailIds()
        {
            int? ids = null;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentEmailListId = unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_GetEnrollmentEmailId]");
                ids = enrollmentEmailListId[0];
            }

            return ids;
        }      

        private void SaveCSVUploadStatus(EnrollmentEmail enrollmentEmail, bool isProcessed)
        {
            Log.TraceFormat("+AxwaySalesForceUploader:SaveCSVUploadStatus: EnrollmentEmailId:{0} ", enrollmentEmail.Id);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentEmailData = unitOfWork.Repository<EnrollmentEmail>().Linq().FirstOrDefault(c => c.Id == enrollmentEmail.Id);
                if (enrollmentEmailData == null) throw new ApplicationException("EnrollmentEmail data not found for Id:" + enrollmentEmailData.Id);
               
                enrollmentEmailData.IsProcessed = isProcessed;
                if (isProcessed)
                {
                    enrollmentEmailData.ProcessedDatetime = DateTime.Now;
                }
                else
                { 
                    enrollmentEmailData.ProcessedDatetime = null; 
                }

                unitOfWork.Repository<EnrollmentEmail>().Save(enrollmentEmailData);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-AxwaySalesForceUploader:SaveCSVUploadStatus: EnrollmentEmail {0}", enrollmentEmail.Id);
        }
        
    }   
}
