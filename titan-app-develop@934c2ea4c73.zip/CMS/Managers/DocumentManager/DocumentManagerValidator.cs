﻿using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Model.Enums;
using Common.Exceptions;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMS.Managers.DocumentManagers
{
    public class DocumentManagerValidator
    {
        public void ValidateCaseDocumentRequest(CaseDocumentDto request)
        {
            Log.TraceFormat("+ValidateCaseDocumentRequest");

            var errorMessages = new List<string>();

            ValidateFileExtensions(errorMessages, request);
            ValidateFileSize(errorMessages, request);

            if (errorMessages.Any()) throw new ValidationException(errorMessages);

            Log.TraceFormat("-ValidateCaseDocumentRequest");
        }

        public void ValidateFileExtensions(List<string> errorMessages, CaseDocumentDto caseDocumentDto)
        {
            Log.TraceFormat("+ValidateFileExtensions");

            var validFileExtension = GetValidFileExtensions(caseDocumentDto.CaseDocumentType);

            if (!validFileExtension.Contains(caseDocumentDto.FileExtension.ToLower()) && caseDocumentDto.CaseDocumentType!= Convert.ToInt32(CaseDocumentTypeEnum.CompanyLogo))
            {
                errorMessages.Add("The file type can not be uploaded to Titan!");
            }            
            Log.TraceFormat("-ValidateFileExtensions");
        }

        private List<string> GetValidFileExtensions(int CaseDocumentType)
        {
            var validFileExtensions = new List<string>();
            if (CaseDocumentType == Convert.ToInt32(CaseDocumentTypeEnum.CompanyLogo))
            {
                validFileExtensions.AddRange(".jpeg".Split(','));
            }
            else
            {
                validFileExtensions.AddRange(".pdf,.doc,.docx,.csv,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.gif,.tiff,.tif,.eps".Split(','));
            }
            return validFileExtensions;
        }

        public void ValidateFileSize(List<string> errorMessages, CaseDocumentDto caseDocumentDto)
        {
            Log.TraceFormat("+ValidateFileSize");

            if (caseDocumentDto.FileBytes != null)
            {
                if (caseDocumentDto.FileBytes.Length > 52428800)
                {
                    errorMessages.Add("Please upload the files less than 50 MB!");
                }               
            }
            Log.TraceFormat("-ValidateFileSize");
        }
    }
}
