﻿using System;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Integrations.FileNetDocumentRepositories;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Model.Entities;
using Logger.Static;
using System.Collections.Generic;
using CMS.Model.Extensions;
using CMS.Model.Enums;
using CMS.Interfaces.Managers.CaseManagers;
using System.Threading.Tasks;

namespace CMS.Managers.DocumentManagers
{
    public class DocumentManager : IDocumentManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IFileNetDocumentRepository _fileNetDocumentRepository;
        private readonly DocumentManagerValidator _documentManagerValidator;
        private readonly ICaseManager _caseManager;

        public DocumentManager(IUnitOfWorkFactory unitOfWorkFactory, IFileNetDocumentRepository fileNetDocumentRepository,
            DocumentManagerValidator documentManagerValidator, ICaseManager caseManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _fileNetDocumentRepository = fileNetDocumentRepository;
            _documentManagerValidator = documentManagerValidator;
            _caseManager = caseManager;
        }

        public int SaveDocument(DocumentSaveRequest request)
        {
            Log.TraceFormat("+SaveDocument - " + request.CaseNumber + " - " + request.CaseDocumentType);

            int documentId = 0;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.CaseNumber == request.CaseNumber);
                if (cmsCase == null) throw new ApplicationException(string.Format("Case number '{0}' not found", request.CaseNumber));

                var documentVersion = 1;
                if (request.PreviousVersionDocumentId != null)
                {
                    var previousDocumentVersion = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == request.PreviousVersionDocumentId.Value);
                    if (previousDocumentVersion != null)
                    {
                        documentVersion = previousDocumentVersion.Version++;
                    }
                }

                var doc = new CaseDocument
                {
                    Case_Id = cmsCase.Id,
                    CaseDocumentType = request.CaseDocumentType,
                    CreationDateTime = DateTime.Now,
                    CreatedByUser = request.CreateByCmsUser,
                    DocumentName = request.DocumentName,
                    FileMimeType = request.FileMimeType,
                    FileName = request.FileName,
                    UploadedByGALdapUser = request.UploadedByGALdapUser,
                    UploadedByGALdapUserRole = request.UploadedByGALdapUserRole,
                    IsExternalIndicator = request.IsExternalDocument,
                    PreviousVersionCaseDocument_Id = request.PreviousVersionDocumentId,
                    Version = documentVersion,
                    FileBytes = request.FileContent,
                    GAPDRId = request.GAPDRId != null ? request.GAPDRId : "0"
                };

                unitOfWork.Repository<CaseDocument>().Save(doc);
                unitOfWork.Commit();

                if(request.CaseDocumentType == CaseDocumentTypeEnum.OfferLetter) // Including this code here, because it supports in future while upload offer letter manualy
                {
                    var requestCaseStatus = new CaseStatusDto
                    {
                        CaseId = cmsCase.Id,
                        CaseStatusType = CaseStatusTypeEnum.OfferAccepted,
                        PlanDesignRequestStatusType = null,
                    };
                    _caseManager.SaveCaseStatusAndPDRStatus(requestCaseStatus);
                }

                documentId = doc.Id;
            }

            Log.TraceFormat("-SaveDocument - " + request.CaseNumber + " - " + request.CaseDocumentType);

            return documentId;
        }

        public DocumentDownloadResponse DownloadDocument(int caseDocumentId, int caseId)
        {
            Log.TraceFormat("+DownloadDocument");

            var response = new DocumentDownloadResponse { CaseDocumentId = caseDocumentId };

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var dbDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == caseDocumentId && c.Case_Id == caseId);

                if (dbDocument == null) throw new ApplicationException("Case document not found!");
                if (dbDocument.FileNetDocumentId == null && dbDocument.FileBytes == null) throw new ApplicationException("Document content not available!");

                response.FileNetDocumentId = dbDocument.FileNetDocumentId;
                response.NewFileNetDocumentId = dbDocument.NewFileNetDocumentId;
                response.ContentMimeType = dbDocument.FileMimeType;
                response.FileName = dbDocument.FileName;

                if (dbDocument.FileBytes != null)
                {
                    response.Content = dbDocument.FileBytes;
                }

                //if (dbDocument.FileNetDocumentId != null || string.IsNullOrEmpty(dbDocument.NewFileNetDocumentId))
                if (dbDocument.FileBytes == null)
                {
                    var fileNetDowloadDocResponse = _fileNetDocumentRepository.DownloadDocument(new FileNetDocDownloadRequest { OldDocumentId = dbDocument.FileNetDocumentId.Value, NewDocumentId =  dbDocument.NewFileNetDocumentId });
                    response.Content = fileNetDowloadDocResponse.Content;
                    response.NewFileNetDocumentId = fileNetDowloadDocResponse.NewFileNetDocumentId;

                    if (!string.IsNullOrEmpty(fileNetDowloadDocResponse.NewFileNetDocumentId) && response.FileNetDocumentId != 0)
                    {
                        Log.Trace("+NewFileNet DownloadDocument document found and saved for, Old FilenetId: " + response.FileNetDocumentId + ", New Document FilenetId: " + response.NewFileNetDocumentId);
                        dbDocument.NewFileNetDocumentId = response.NewFileNetDocumentId;
                        dbDocument.FileNetDocumentId = 0; //setting this to zero is a must.
                        unitOfWork.Repository<CaseDocument>().Save(dbDocument);
                        unitOfWork.Commit();
                    }
                }
            }

            Log.TraceFormat("-DownloadDocument");

            return response;
        }

        public List<CaseDocumentDto> GetDocumentsSubmittedByGA(int caseId)
        {
            Log.TraceFormat("+GetDocumentsSubmittedByGA");
            var caseDocumentsDtos = new List<CaseDocumentDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                caseDocumentsDtos = unitOfWork.Repository<CaseDocument>().Linq()
                    .Where(c => c.Case_Id == caseId && c.IsExternalIndicator && !c.IsDeleted)
                    .Select(t => new CaseDocumentDto
                    {
                        CaseDocumentId = t.Id,
                        FileName = t.FileName,
                        FileMimeType = t.FileMimeType,
                        CaseDocumentType = (int)t.CaseDocumentType,
                        UploadedDateTime = t.CreationDateTime,
                        GAPDRId = t.GAPDRId != null ? t.GAPDRId : "0"
                    }).ToList();
            }

            Log.TraceFormat("-GetDocumentsSubmittedByGA");
            return caseDocumentsDtos;
        }

        public void DeleteDocumentByGA(int caseDocumentId, int caseId)
        {
            Log.TraceFormat("+DeleteDocumentByGA");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var dbDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == caseDocumentId && c.Case_Id == caseId);
                if (dbDocument == null) throw new ApplicationException("Case document not found!");
                if (dbDocument.FileNetDocumentId == null && dbDocument.FileBytes == null) throw new ApplicationException("Document content not available!");

                dbDocument.IsDeleted = true;
                unitOfWork.Repository<CaseDocument>().Save(dbDocument);
                unitOfWork.Commit();
            }
            Log.TraceFormat("-DeleteDocumentByGA");
        }

        public List<CaseDocumentDto> GetDocumentsByCaseId(int caseId)
        {
            Log.TraceFormat("+GetDocumentsByCaseId");
            var caseDocumentsDtos = new List<CaseDocumentDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseDocumentsDtosList = unitOfWork.Repository<CaseDocument>().Linq()
                    .Where(c => c.Case_Id == caseId && !c.IsDeleted && (c.FileNetDocumentId != null || c.FileBytes != null) &&
                    (!(c.CaseDocumentType == CaseDocumentTypeEnum.ProductSummary
                    || c.CaseDocumentType == CaseDocumentTypeEnum.Illustration
                    || c.CaseDocumentType == CaseDocumentTypeEnum.ProgramSummary
                    || c.CaseDocumentType == CaseDocumentTypeEnum.OfferLetter
                    || c.CaseDocumentType == CaseDocumentTypeEnum.BenefitAndPremium
                    || c.CaseDocumentType == CaseDocumentTypeEnum.EnrollmentTool
                    || c.CaseDocumentType == CaseDocumentTypeEnum.EnrollmentKit
                    || c.CaseDocumentType == CaseDocumentTypeEnum.Sweep
                    || (c.CaseDocumentType == CaseDocumentTypeEnum.Other && c.CaseDocumentRequest != null)
                    )))
                    .OrderByDescending(c => c.CreationDateTime);

                Parallel.ForEach(caseDocumentsDtosList, obj =>
                {
                    var objDto = new CaseDocumentDto();
                    objDto.CaseDocumentId = obj.Id;
                    objDto.FileName = obj.FileName;
                    objDto.DocumentName = obj.DocumentName;
                    objDto.FileMimeType = obj.FileMimeType;
                    objDto.CaseDocumentType = (int)obj.CaseDocumentType;
                    //objDto.CaseDocumentTypeEnum = GetCaseDocumentType(obj.Id, obj.CaseDocumentType);
                    objDto.CaseDocumentTypeEnum =  obj.CaseDocumentType;
                    objDto.UploadedDateTime = obj.CreationDateTime;
                    caseDocumentsDtos.Add(objDto);

                });
            }
            if (caseDocumentsDtos.Any())
            {
                caseDocumentsDtos.ForEach(cd => cd.CaseDocumentTypeDescription = cd?.CaseDocumentTypeEnum.GetDescription());
            }
            Log.TraceFormat("-GetDocumentsByCaseId");
            return caseDocumentsDtos;
        }

        private CaseDocumentTypeEnum GetCaseDocumentType(int caseDocumentId, CaseDocumentTypeEnum oldCaseDocumentType)
        {
            Log.TraceFormat("+GetCaseDocumentType DocumentId: " + caseDocumentId);

            CaseDocumentTypeEnum newCaseDocumentType = CaseDocumentTypeEnum.Other;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentParticipant = unitOfWork.Repository<EnrollmentParticipant>().Linq().FirstOrDefault(i => i.Kit != null && i.Kit.Id == caseDocumentId);

                if (enrollmentParticipant == null) return oldCaseDocumentType;

                var ambType = enrollmentParticipant != null ? enrollmentParticipant.Enrollment.AMBType : null;
                var isAmbIncrease = enrollmentParticipant != null ? enrollmentParticipant.Participant.IsAMBIncreaseIndicator : null;

                if ((ambType != null && ambType == AMBTypeEnum.Negative) && (isAmbIncrease != null && isAmbIncrease == true))
                {
                    newCaseDocumentType = CaseDocumentTypeEnum.NegativeEnrollmentLetter;
                }
                else
                {
                    newCaseDocumentType = oldCaseDocumentType;
                }
            }
            Log.TraceFormat("-GetCaseDocumentType DocumentId: " + caseDocumentId);

            return newCaseDocumentType;
        }

        public void DeleteDocument(int caseDocumentId)
        {
            Log.TraceFormat("+DeleteDocument");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var dbDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == caseDocumentId);
                if (dbDocument == null) throw new ApplicationException("Case document not found!");
                dbDocument.IsDeleted = true;
                unitOfWork.Repository<CaseDocument>().Save(dbDocument);
                unitOfWork.Commit();
            }
            Log.TraceFormat("-DeleteDocument");
        }

        public void SaveDocumentName(int caseDocumentId, string documentName)
        {
            Log.TraceFormat("+SaveDocumentName");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var dbDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == caseDocumentId);
                if (dbDocument == null) throw new ApplicationException("Case document not found!");
                dbDocument.DocumentName = documentName;
                unitOfWork.Repository<CaseDocument>().Save(dbDocument);
                unitOfWork.Commit();
            }
            Log.TraceFormat("-SaveDocumentName");
        }

        public void SaveDocumentsInTitan(CaseDocumentDto caseDocumentDto)
        {
            Log.TraceFormat("+SaveDocumentsInTitan");

            _documentManagerValidator.ValidateCaseDocumentRequest(caseDocumentDto);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseDocument= new CaseDocument();
                if ((CaseDocumentTypeEnum)caseDocumentDto.CaseDocumentType == CaseDocumentTypeEnum.CompanyLogo)
                {
                     caseDocument = unitOfWork.Repository<CaseDocument>().Linq().OrderByDescending(x => x.Id).FirstOrDefault(c => c.Case_Id == caseDocumentDto.caseId && c.CaseDocumentType == CaseDocumentTypeEnum.CompanyLogo && !c.IsDeleted);

                }
                else
                {
                     caseDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == caseDocumentDto.CaseDocumentId);
                }
                if (caseDocument == null)
                {
                    caseDocument = new CaseDocument();
                    caseDocument.Case_Id = caseDocumentDto.caseId;
                }

                caseDocument.CaseDocumentType = (CaseDocumentTypeEnum)caseDocumentDto.CaseDocumentType;
                caseDocument.DocumentName = caseDocumentDto.DocumentName;
                caseDocument.FileName = caseDocumentDto.FileName;
                caseDocument.FileMimeType = caseDocumentDto.FileMimeType;
                caseDocument.FileBytes = caseDocumentDto.FileBytes;
                caseDocument.CreationDateTime = caseDocumentDto.UploadedDateTime.Value;

                unitOfWork.Repository<CaseDocument>().Save(caseDocument);
                unitOfWork.Commit();
            }
            Log.TraceFormat("-SaveDocumentsInTitan");
        }

        public string GetCompanylogoDetails(int caseId, int documentTypeId)
        {
            Log.TraceFormat("+GetCompanylogoDetails");
            var logoname = "";
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var chkcompanylogo = unitOfWork.Repository<CaseDocument>().Linq().OrderByDescending(x => x.Id).FirstOrDefault(c => c.Case_Id == caseId && Convert.ToInt32(c.CaseDocumentType) == documentTypeId && !c.IsDeleted);
                if (chkcompanylogo != null)
                {
                    logoname = chkcompanylogo.FileName;
                }
            }

            Log.TraceFormat("-GetCompanylogoDetails");
            return logoname;
        }
    }
}