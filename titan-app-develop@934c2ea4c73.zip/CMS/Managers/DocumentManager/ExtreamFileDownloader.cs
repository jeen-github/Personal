﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using Common.Utilities;
using Logger.Static;
using Newtonsoft.Json;
using RestSharp;
using NHibernate.Linq;
using System.Diagnostics;
using System.Threading;

namespace CMS.Managers.DocumentManagers
{
    public class ExtreamFileDownloader : IExtreamFileDownloader, IWorkUnitHandler
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IConfiguration _configuration;

        public ExtreamFileDownloader(IUnitOfWorkFactory unitOfWorkFactory, IConfiguration configuration)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _configuration = configuration;
        }

        public void Execute(WorkUnit workUnit)
        {
            var stopwatchfiledownload = new Stopwatch();
            stopwatchfiledownload.Start();

            var expectedApiFileName = workUnit.InputData;

            var expectedApiFileNameList = expectedApiFileName.Split(new string[] { "," }, StringSplitOptions.None);

            foreach(var filename in expectedApiFileNameList)
            {
                DownloadFiles(filename);
            }

            stopwatchfiledownload.Stop();
            Log.Debug($"ExtreamFileDownloader WorkUnitId-'{workUnit.Id}' for '{stopwatchfiledownload.Elapsed.TotalMinutes}' minutes '{stopwatchfiledownload.Elapsed.TotalSeconds}' seconds");
        }

        public void DownloadFiles(string expectedApiFileName)
        {
            Log.TraceFormat("+DownloadFiles API:{0}", expectedApiFileName);

            var availableApiFileList = DownloadApiFileList();

            if (!availableApiFileList.Contains(expectedApiFileName))
            {
                Log.WarnFormat("File:{0} not generated yet try again in 90s", expectedApiFileName);
                throw new RetryWorkUnitException(TimeSpan.FromSeconds(90));
            }
                        
            var apiFileContent = DownloadApiFileContent(expectedApiFileName);
            var fileNames = GetFileNamesFromApiFile(expectedApiFileName, apiFileContent);

            foreach (var fileName in fileNames)
            {
                var rawBytes = DownloadFileContent(fileName);
                SaveDocumentToDatabase(fileName, rawBytes);
            }

            Log.TraceFormat("-DownloadFiles API:{0}", expectedApiFileName);
        }

        private List<string> DownloadApiFileList()
        {
            var apiFileList = new List<string>();
            try
            {
                var restClient = new RestServiceClient(_configuration.ExtreamAxwayApiDownloadUrl,
                    _configuration.ExtreamAxwayCredentials.UserName, _configuration.ExtreamAxwayCredentials.Password);

                //Log.Trace("+ExtremeFileDownloader: Url: " + _configuration.ExtreamAxwayApiDownloadUrl
                //    + "; Username: " + _configuration.ExtreamAxwayCredentials.UserName
                //    + "; Password: " + _configuration.ExtreamAxwayCredentials.Password
                //    );

                var restRequest = new RestRequest { Method = Method.GET };

                var response = restClient.SendRequest(restRequest);
                var fileList = JsonConvert.DeserializeObject<Files>(response.Content);

                apiFileList = fileList.files.Select(file => file.fileName).ToList();

                if (apiFileList.Any())
                    Log.TraceFormat("Downloaded APIs={0}", string.Join(",", apiFileList));
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error getting API file list", ex);
            }

            return apiFileList;
        }
       
        private byte[] DownloadFileContent(string fileName)
        {
            Log.TraceFormat("+DownloadFileContent FileName:{0}", fileName);
            byte[] fileContent = null;

            try
            {
                var restClient = new RestServiceClient(_configuration.ExtreamAxwayFileDownloadUrl + "/" + fileName,
                    _configuration.ExtreamAxwayCredentials.UserName, _configuration.ExtreamAxwayCredentials.Password);

                var restRequest = new RestRequest { Method = Method.GET };

                var response = restClient.SendRequestAsync(restRequest);
                fileContent = response.RawBytes;
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error to download file:{0}", ex, fileName);
            }

            Log.TraceFormat("-DownloadFileContent FileName:{0}", fileName);
            return fileContent;
        }

                

        private string DownloadApiFileContent(string fileName)
        {
            Log.TraceFormat("+DownloadApiFileContent FileName:{0}", fileName);
            string fileContent = null;

            try
            {
                var restClient = new RestServiceClient(_configuration.ExtreamAxwayApiDownloadUrl + "/" + fileName,
                    _configuration.ExtreamAxwayCredentials.UserName, _configuration.ExtreamAxwayCredentials.Password);

                var restRequest = new RestRequest { Method = Method.GET };

                var response = restClient.SendRequestAsync(restRequest);
                fileContent = response.Content;
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error download API file:{0}", ex, fileName);
            }

            Log.TraceFormat("-DownloadApiFileContent FileName:{0}", fileName);
            return fileContent;
        }
       

        private List<string> GetFileNamesFromApiFile(string apiFileName, string apiFileContent)
        {
            Log.TraceFormat("+GetFileNamesFromApiFile FileName:{0} Content:{1}", apiFileName, apiFileContent);

            var results = new List<string>();
            try
            {
                var xDocument = XDocument.Parse(apiFileContent);
                results = xDocument.Descendants("file").Select(f => f.Value).ToList();
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error parsing Extream API file:{0} content:{1}", ex, apiFileName, apiFileContent);
            }

            Log.TraceFormat("-GetFileNamesFromApiFile");
            return results;
        }

        public void SaveDocumentToDatabase(string documentFileName, byte[] documentFileBytes)
        {
            Log.TraceFormat("+SaveDocumentToDatabase File:{0}", documentFileName);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(d => d.FileName == documentFileName);

                if (caseDocument == null)
                {
                    Log.WarnFormat("FileName:{0} not found in the CaseDocument table!", documentFileName);
                    return;
                }

                caseDocument.FileBytes = documentFileBytes;
                unitOfWork.Repository<CaseDocument>().Save(caseDocument);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveDocumentToDatabase File:{0}", documentFileName);
        }
    }


    public class Files
    {
        public File[] files { get; set; }
    }

    public class File
    {
        public string fileName { get; set; }
        public long lastModifiedTime { get; set; }
        public int size { get; set; }
        public bool isDirectory { get; set; }
        public bool isRegularFile { get; set; }
        public bool isSymbolicLink { get; set; }
        public bool isOther { get; set; }
        public string group { get; set; }
        public string owner { get; set; }
        public string permissions { get; set; }
    }

}