﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using CMS.Interfaces.Configurations;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Utilities;
using Logger.Static;
using NHibernate.Linq;
using RestSharp;

namespace CMS.Managers.DocumentManagers
{
    public class ExtreamFileUploader : IExtreamFileUploader, IWorkUnitHandler
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly IConfiguration _configuration;        
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IExtreamFileDownloader _extreamFileReceiver;

        public ExtreamFileUploader(IUnitOfWorkFactory unitOfWorkFactory, IConfiguration configuration, IWorkUnitManager workUnitManager, IExtreamFileDownloader extreamFileReceiver)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _configuration = configuration;
            _workUnitManager = workUnitManager;
            _extreamFileReceiver = extreamFileReceiver;
        }

        public void Execute(WorkUnit workUnit)
        {
            var stopwatchfileupload = new Stopwatch();
            stopwatchfileupload.Start();

            var nextDocumentId = int.Parse(workUnit.InputData);
            UploadDocumentToExtream(nextDocumentId);

            stopwatchfileupload.Stop();
            Log.Debug($"ExtreamFileUploader WorkUnitId-'{workUnit.Id}' for '{stopwatchfileupload.Elapsed.TotalMinutes}' minutes '{stopwatchfileupload.Elapsed.TotalSeconds}' seconds");
        }

        public void UploadDocumentToExtream(int nextDocumentId)
        {
            Log.TraceFormat("+SendDocumentRequestToExtream caseDocumentId:{0}", nextDocumentId);

            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var document = unitOfWork.Repository<CaseDocumentRequest>().Linq().Fetch(d => d.Documents).FirstOrDefault(c => c.Id == nextDocumentId);
                    
                    var documentList = unitOfWork.Repository<CaseDocument>().Linq().Where(c => c.CaseDocumentRequest.Id == nextDocumentId).Select(i=>i.FileName);

                    var caseNumber = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == document.Case_Id);

                    //if (_configuration.ExtreamDropFakeFiles) DropFakeFiles(document);
                    string fileList = string.Empty;

                    if (documentList.Any() && documentList.Count() > 1)
                    {
                        foreach (var file in documentList)
                        {
                            if (file.Contains("Sweep"))
                            {
                                if (!fileList.Contains(document.RequestFileName.Replace("EnrollmentKit", "Sweep")))
                                {
                                    fileList += document.RequestFileName.Replace("EnrollmentKit", "Sweep") + ",";
                                }
                            }
                            else if (file.Contains("Other"))
                            {
                                if (!fileList.Contains(document.RequestFileName.Replace("EnrollmentKit", "Other")))
                                {
                                    fileList += document.RequestFileName.Replace("EnrollmentKit", "Other") + ",";
                                }
                            }
                            else
                            {
                                if (!fileList.Contains(document.RequestFileName))
                                {
                                    fileList += document.RequestFileName + ",";
                                }                                
                            }                            
                        }
                        fileList = fileList.Remove(fileList.Length - 1);
                    }
                   SendFileToHttp(_configuration.ExtreamAxwayFileUrl, document.RequestFileName, Encoding.UTF8.GetBytes(document.ExtreamRequest));

                    var responseFileName = document.RequestFileName.Replace(".xml", "");
                    string commandCenterApiName = string.Empty;
                    if (document.CaseDocumentType == CaseDocumentTypeEnum.PostCard)
                    {
                         commandCenterApiName= _configuration.ExtreamAxwayCCJobNameForPostCard;
                    }  
                    else
                    {
                        commandCenterApiName = _configuration.ExtreamAxwayCCJobName;
                    }

                    var apiFileBytes = CreateCommandCenterApiFile(document.CaseDocumentType, document.RequestFileName, responseFileName, commandCenterApiName,
                        caseNumber.CaseNumber, document.Documents[0].DocumentName);                    

                    var apiFileName = "api_" + document.RequestFileName;
                    SendFileToHttp(_configuration.ExtreamAxwayApiUrl, apiFileName, apiFileBytes);
                    if (document.CaseDocumentType != CaseDocumentTypeEnum.PostCard)
                    {
                        if (fileList.Length > 0)
                        {
                            _workUnitManager.CreateWorkUnit(WorkUnitType.ExtreamFileDownload, fileList, TimeSpan.FromSeconds(45));
                        }
                        else
                        {
                            _workUnitManager.CreateWorkUnit(WorkUnitType.ExtreamFileDownload, document.RequestFileName, TimeSpan.FromSeconds(45));
                        }
                    }
                    
                    
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error sending files to Extream", ex);
                throw new RetryWorkUnitException(TimeSpan.FromMinutes(1), ex);
            }

            Log.TraceFormat("-SendDocumentRequestToExtream caseDocumentId:{0}", nextDocumentId);
        }

        private byte[] CreateCommandCenterApiFile(CaseDocumentTypeEnum documentType, string requestFileName, string responseFileName, string commandCenterApiName, string caseNumber, string documentName)
        {
            var fileNetDocName = !string.IsNullOrEmpty(documentName) ? 
                documentName.Substring(0, Math.Min(documentName.Length, 100)) : documentType.ToString();
            var containApostrophe = !string.IsNullOrEmpty(fileNetDocName) ? fileNetDocName.Contains("'") : false;
            if (containApostrophe)
            {
                fileNetDocName = fileNetDocName.Replace("'", "&apos;");
            }
            var fileContent = string.Format(
                        @"<?xml version='1.0'?>" +
                        @"<action xmlns='http://www.hp.com/go/exstream/schema/cc-actions'>" +
                        @"    <type>CREATE_JOB</type>" +
                        @"        <attribute name='job_definition_name' value='{3}'/>" +
                        @"        <attribute name='overridden_variables'>" +
                        @"            <map>" +
                        @"                <entry name='DriverFileName' value='{0}'/>" +
                        @"                <entry name='FileTemplate' value='{1}'/>" +
                        @"                <entry name='ResponseFileName' value='{2}'/>" +
                        @"                <entry name='InputSource' value='Titan'/>" +
                        @"                <entry name='ScanDate' value='{4:MM/dd/yyyy}'/>" +
                        @"                <entry name='CaseNumber' value='{5}'/>" +
                        @"                <entry name='DocumentType' value='{1}'/>" +
                        @"                <entry name='DocumentName' value='{6}'/>" +
                        @"            </map>" +
                        @"       </attribute>" +
                        @"</action>",
                    requestFileName, documentType, responseFileName, commandCenterApiName, DateTime.Today, caseNumber, fileNetDocName);

            return Encoding.UTF8.GetBytes(fileContent);
        }

        private void SendFileToHttp(string extreamAxwayFileUrl, string fileName, byte[] fileContent)
        {
            Log.TraceFormat("+SendFileToHttp FileName={0}", fileName);

            try
            {
                var restClient = new RestServiceClient(extreamAxwayFileUrl,
                    _configuration.ExtreamAxwayCredentials.UserName, _configuration.ExtreamAxwayCredentials.Password);

                var restRequest = new RestRequest { Method = Method.POST };
                restRequest.AddFileBytes("titan", fileContent, fileName, "application/xml");

                restClient.SendRequest(restRequest);
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Failed to upload {0}", ex, fileName);
                throw;
            }

            Log.TraceFormat("-SendFileToHttp FileName={0}", fileName);
        }
        
        private void DropFakeFiles(CaseDocumentRequest document)
        {
            try
            {
                List<string> documentNames;
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    documentNames = unitOfWork.Repository<CaseDocumentRequest>().Linq()
                        .Where(c => c.Id == document.Id).
                        SelectMany(c => c.Documents).
                        Select(d => d.FileName).
                        ToList();
                }

                string apiFileContent = @"<files>";
                foreach (var documentName in documentNames)
                {
                    var fakeDocumentBytes = GetFakeDocumentBytes(document.CaseDocumentType.ToString(), documentName);                    
                    _extreamFileReceiver.SaveDocumentToDatabase(documentName, fakeDocumentBytes);
                    apiFileContent += @"<file>" + documentName + @"</file>";
                }
                apiFileContent += @"</files>";                
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Fail to drop the fake files", ex);
            }
        }

        private byte[] GetFakeDocumentBytes(string documentType, string documentName)
        {
            string extension = "";
            if (documentName.ToLower().Contains(".pdf")) extension = ".pdf";
            if (documentName.ToLower().Contains(".xls")) extension = ".xls";
            if (documentName.ToLower().Contains(".xslt")) extension = ".xls";
            if (documentName.ToLower().Contains(".doc")) extension = ".doc";
            if (documentName.ToLower().Contains(".docx")) extension = ".docx";

            string resourceName = string.Format("CMS.Managers.DocumentManagers.Resources.{0}{1}", documentType, extension);

            var stream = Assembly.GetAssembly(typeof(ExtreamFileUploader)).GetManifestResourceStream(resourceName);
            if (stream == null) throw new Exception("Unable to load resource " + resourceName);

            using (MemoryStream ms = new MemoryStream())
            {
                stream.CopyTo(ms);
                return ms.ToArray();
            }
        }        
    }

    
}
