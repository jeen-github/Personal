﻿using System;
using System.IO;
using System.Linq;
using System.Xml;
using CMS.Interfaces.DataAccess;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Utilities;
using Logger.Static;
using System.Xml.Serialization;
using System.Text;
using System.Xml.Linq;
using CMS.Interfaces.Managers.ProductLibraryManagers;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public abstract class DocumentGenerator
    {
        protected readonly IUnitOfWorkFactory UnitOfWorkFactory;
        private readonly IProductLibraryManager _productLibraryManager;

        protected DocumentGenerator(IUnitOfWorkFactory unitOfWorkFactory, IProductLibraryManager productLibraryManager)
        {
            UnitOfWorkFactory = unitOfWorkFactory;
            _productLibraryManager = productLibraryManager;
        }

        protected CaseDocumentRequest CreateCaseDocumentRequest(string docRequestXml, Case cmsCase, CaseDocumentTypeEnum caseDocumentType)
        {
            Log.TraceFormat("+CreateCaseDocumentRequest CaseId {0}" , cmsCase.Id);

            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var caseDocumentRequest = new CaseDocumentRequest
                {
                    Case_Id = cmsCase.Id,
                    ExtreamRequest = docRequestXml,
                    CaseDocumentType = caseDocumentType,
                    RequestDateTime = DateTime.Now
                };
                unitOfWork.Repository<CaseDocumentRequest>().Save(caseDocumentRequest);

                caseDocumentRequest.RequestFileName = CreateFileName(cmsCase.CaseNumber, caseDocumentRequest.Id, caseDocumentType, ExtreamDocumentType.XML, null);
                caseDocumentRequest.RequestFileName = caseDocumentRequest.RequestFileName.Replace("_Rate_Sheet", "");
                unitOfWork.Repository<CaseDocumentRequest>().Save(caseDocumentRequest);

                unitOfWork.Commit();

                Log.TraceFormat("-CreateCaseDocumentRequest CaseId {0}", cmsCase.Id);

                return caseDocumentRequest;
            }
        }

        public bool IsCompactState(int caseId)
        {            
           return _productLibraryManager.IsCompactStateCase(caseId);
        }

        protected CaseDocument CreateCaseDocument(CaseDocumentRequest caseDocumentRequest, Case cmsCase, CaseDocumentTypeEnum caseDocumentType, ExtreamDocumentType extreamDocumentType, int? participantId = null, string documentName = null)
        {            
            Log.TraceFormat("+CreateCaseDocument CaseId {0}", cmsCase.Id);
            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var caseDocument = new CaseDocument
                {
                    Case_Id = cmsCase.Id,
                    CreationDateTime = DateTime.Now,
                    CaseDocumentType = caseDocumentType,
                    FileMimeType = FileMimeTypeUtility.GetMimeType(extreamDocumentType.ToString()),
                    CaseDocumentRequest = caseDocumentRequest
                };
                unitOfWork.Repository<CaseDocument>().Save(caseDocument);
                caseDocument.DocumentName = !string.IsNullOrWhiteSpace(documentName) ? documentName.Replace("&","") : null;
                caseDocument.FileName = CreateFileName(cmsCase.CaseNumber, caseDocumentRequest.Id, caseDocumentType, extreamDocumentType, participantId);
                unitOfWork.Repository<CaseDocument>().Save(caseDocument);

                unitOfWork.Commit();

                Log.TraceFormat("-CreateCaseDocument CaseId {0}", cmsCase.Id);

                return caseDocument;
            }
        }

        public string CreateFileName(string caseNumber, int caseDocumentRequestId, CaseDocumentTypeEnum caseDocumentType, ExtreamDocumentType extreamDocumentType, int? participantId = null)
        {
            var suffix = "";
            var caseDocumentTypeName = caseDocumentType.ToString();
            var fileExtension = extreamDocumentType.ToString().ToLower();
            switch (caseDocumentType)
            {
                case CaseDocumentTypeEnum.Illustration:
                    suffix = "_Rate_Sheet";
                    break;
                case CaseDocumentTypeEnum.ProductSummary:
                    caseDocumentTypeName = CaseDocumentTypeEnum.Illustration.ToString();
                    suffix = "_Product_Summary";
                    break;
                case CaseDocumentTypeEnum.ProgramSummary:
                    caseDocumentTypeName = CaseDocumentTypeEnum.Illustration.ToString();
                    suffix = "_Program_Summary";
                    break;
                case CaseDocumentTypeEnum.OfferLetter:
                    caseDocumentTypeName = CaseDocumentTypeEnum.OfferLetter.ToString();
                    suffix = "_Offer_Letter";
                    break;
                case CaseDocumentTypeEnum.Sweep:
                    caseDocumentTypeName = CaseDocumentTypeEnum.Sweep.ToString();
                    suffix = "";
                    break;
                case CaseDocumentTypeEnum.EnrollmentKit:
                    caseDocumentTypeName = CaseDocumentTypeEnum.EnrollmentKit.ToString();
                    suffix = "";
                    break;
                case CaseDocumentTypeEnum.AnnouncementLetters:
                    caseDocumentTypeName = CaseDocumentTypeEnum.AnnouncementLetters.ToString();
                    suffix = "";
                    break;
                case CaseDocumentTypeEnum.Other:
                    caseDocumentTypeName = CaseDocumentTypeEnum.Other.ToString();
                    suffix = "";
                    break;
                case CaseDocumentTypeEnum.ProducerCertification:
                    caseDocumentTypeName = CaseDocumentTypeEnum.ProducerCertification.ToString();
                    suffix = "";
                    break;
                case CaseDocumentTypeEnum.PostCard:
                    caseDocumentTypeName = CaseDocumentTypeEnum.PostCard.ToString();
                    suffix = "";
                    break;
            }

            return participantId == null ?
                string.Format("{0}_{1}_{2}.{3}", caseNumber, caseDocumentTypeName, caseDocumentRequestId + suffix, fileExtension) :
                string.Format("{0}_{1}_{2}_{4}.{3}", caseNumber, caseDocumentTypeName, caseDocumentRequestId + suffix, fileExtension, participantId.Value);
        }

        protected string SerializeObject<T>(T input) where T : class
        {
            Log.Trace("+SerializeObject");

            //string result = null;
            var result = new StringBuilder();
            XmlSerializer serializer = new XmlSerializer(typeof(T));
           

            using (Stream stream = new MemoryStream())
            {
                using (XmlTextWriter xtWriter = new XmlTextWriter(stream, Encoding.UTF8))
                {
                    serializer.Serialize(xtWriter, input);
                    xtWriter.Flush();
                    stream.Seek(0, SeekOrigin.Begin);

                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        //result = reader.ReadToEnd();
                        result.Append(reader.ReadToEnd());
                    }
                }
            }
            Log.Trace("-SerializeObject");
            return result.ToString();
        }

        protected string RemoveAMBRRiderTagsFromXML(string serializedXml)
        {
            string updatedXML = serializedXml;

            if (serializedXml != null)
            {
                var xmlDocument = XDocument.Parse(serializedXml);

                var ambrRider = xmlDocument.Descendants("qualifiedRider").Elements().Where(c => c.Name == "riderIdentifier").Select(c => c.Value).ToList();

                if (ambrRider.Count() > 0)
                {
                    if (!ambrRider.Contains("AMBR"))
                    {
                        var csEEPremiumPaidPerMonth = xmlDocument.Descendants().Where(o => o.Name.LocalName == "csEEPremiumPaidPerMonth");
                        csEEPremiumPaidPerMonth.Remove();

                        var csERPremiumPaidPerMonth = xmlDocument.Descendants().Where(o => o.Name.LocalName == "csERPremiumPaidPerMonth");
                        csERPremiumPaidPerMonth.Remove();

                        var csEEPremiumPaidPerPaycheck = xmlDocument.Descendants().Where(o => o.Name.LocalName == "csEEPremiumPaidPerPaycheck");
                        csEEPremiumPaidPerPaycheck.Remove();

                        var csERPremiumPaidPerPaycheck = xmlDocument.Descendants().Where(o => o.Name.LocalName == "csERPremiumPaidPerPaycheck");
                        csERPremiumPaidPerPaycheck.Remove();
                    }
                    else
                    {
                        var otherRiders = xmlDocument.Descendants("qualifiedRider").Elements().Where(c => c.Name == "riderIdentifier" && c.Value != "AMBR").ToList();

                        foreach(var rider in otherRiders)
                        {
                            var csEEPremiumPaidPerMonth = rider.Parent.Descendants().Where(o => o.Name.LocalName == "csEEPremiumPaidPerMonth");
                            csEEPremiumPaidPerMonth.Remove();

                            var csERPremiumPaidPerMonth = rider.Parent.Descendants().Where(o => o.Name.LocalName == "csERPremiumPaidPerMonth");
                            csERPremiumPaidPerMonth.Remove();

                            var csEEPremiumPaidPerPaycheck = rider.Parent.Descendants().Where(o => o.Name.LocalName == "csEEPremiumPaidPerPaycheck");
                            csEEPremiumPaidPerPaycheck.Remove();

                            var csERPremiumPaidPerPaycheck = rider.Parent.Descendants().Where(o => o.Name.LocalName == "csERPremiumPaidPerPaycheck");
                            csERPremiumPaidPerPaycheck.Remove();


                        }
                    }
                }

                var printFiletag = xmlDocument.Descendants("prefilledForms").Elements().Where(c => c.Name == "printFile").Select(c => c.Value).ToList();
                if (printFiletag.Count() > 0)
                {
                    if (printFiletag.Contains("N"))
                    {
                        var printFile = xmlDocument.Descendants("prefilledForms").Elements().Where(c => c.Name == "printFile");
                        printFile.Remove();
                    }
                }
                    serializedXml = xmlDocument.ToString();
                updatedXML = serializedXml;
            }

            return updatedXML;
        }

        protected string ReplaceXmlNodeName(string response)
        {
            Log.Trace("+ReplaceXmlNodeName");
            string result = null;
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(response);
            XmlNodeList producerAgentNodeList = xmlDoc.SelectNodes("//*[starts-with(name(), 'producerAgent')]");
            foreach (XmlNode producerAgentNode in producerAgentNodeList)
            {
                XmlNodeList personalInformationNodeList = producerAgentNode.SelectNodes("//*[starts-with(name(), 'personalInformation')]");
                foreach (XmlNode personalInformationNode in personalInformationNodeList)
                {
                    if(personalInformationNode.SelectSingleNode("lastName") == null && personalInformationNode.SelectSingleNode("type").InnerText == "ProducerAgent")
                    {
                        XmlNode firstNameNode = personalInformationNode.SelectSingleNode("firstName");
                        XmlNode lastNameNode = xmlDoc.CreateElement("lastName");
                        lastNameNode.InnerXml = firstNameNode.InnerXml;
                        personalInformationNode.InsertBefore(lastNameNode, firstNameNode);
                        personalInformationNode.RemoveChild(firstNameNode);
                    }
                }
            }
            using (StringWriter stringWriter = new StringWriter())
            {
                using (XmlTextWriter xmlTextWriter = new XmlTextWriter(stringWriter))
                {
                    xmlDoc.WriteTo(xmlTextWriter);
                    xmlTextWriter.Flush();
                }
                result = stringWriter.GetStringBuilder().ToString();
            }
            Log.Trace("-ReplaceXmlNodeName");
            return result;
        }

        protected bool IsBlankBPRequestPresent(string serializedXml)
        {
            Log.Trace("+IsBlankBPRequestPresent");
            bool isBlank = false;

            string updatedXML = serializedXml;
            try {

                if (serializedXml != null)
                {
                    var xmlDocument = XDocument.Parse(serializedXml);
                    isBlank = !xmlDocument.Descendants("BPRequest").Elements().Where(c => c.Name == "Options").Any();
                }
            }
            catch (Exception ex)
            {
                Log.Error("+IsBlankBPRequestPresent: " + ex.Message);
            }
            
            Log.Trace("-IsBlankBPRequestPresent");
            return isBlank;
        }

        protected Case GetCase(int caseId)
        {
            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                return unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
            }
        }
    }

    public enum ExtreamDocumentType
    {
        XML,
        PDF,
        XLS,
        DOC,
        DOCX,
        CSV,
        TXT
    }
}