﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class ProducerCertificationDocumentRequest
    {
        public string CaseName { get; set; }
        public string CaseState { get; set; }
        [XmlElement("CaseBrokerRequest")]
        public List<CaseBrokerRequest> CaseBrokerRequest { get; set; }
    }

    public class CaseBrokerRequest
    {
        [XmlElement("CaseBrokerStateRequest")]
        public List<CaseBrokerStateRequest> CaseBrokerStateRequest { get; set; }
    }

    public class CaseBrokerStateRequest
    {
        public string CaseBrokerState { get; set; }
        public string ProducerCorporateName { get; set; }
        public decimal? CorporateProducerSplit { get; set; }
        public string CorporateProducerCode { get; set; }
        public bool? IsCorporateServicingProducer { get; set; }
        public string ProducerName { get; set; }
        public decimal? ProducerSplit { get; set; }
        public string ProducerCode { get; set; }        
        public bool? IsServicingProducer { get; set; }
    }
}
