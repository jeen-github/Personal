﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    [System.Xml.Serialization.XmlRoot("ExtreamDocumentXML", IsNullable = false)]
    public class EnrollmentToolXml : EnrollmentKitXml
    {
        public EnrollmentToolXml()
        {
            ExstreamRequestType = "EnrollmentTool";
        }
    }
}
