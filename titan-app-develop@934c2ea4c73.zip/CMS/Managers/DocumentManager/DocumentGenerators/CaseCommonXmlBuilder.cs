﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Guardian.Core.Entities.Product.Enums;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using Logger.Static;
using Newtonsoft.Json;
using Common.Utilities;
using System.Data;
using System.Data.SqlClient;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class CaseCommonXmlBuilder
    {
        public IUnitOfWorkFactory UnitOfWorkFactory { get; private set; }
        private string ProductLibraryDatabaseConnection = AppSettingsReader.ReadAppSettingValue("ProductLibraryDatabaseConnection");
        private static readonly DateTime feb2318 = Convert.ToDateTime("02/23/2018");
        private string exstreamRequestDocumentType = string.Empty;
        
        public CaseCommonXmlBuilder(IUnitOfWorkFactory unitOfWorkFactory)
        {
            UnitOfWorkFactory = unitOfWorkFactory;
        }
        
        public void CreateCase(CaseCommonXmlGenerationRequest request, MLDICase mldiCase, string exstreamRequestType)
        {
            Log.TraceFormat("+CreateCase CaseId : {0} EnrollmentId: {1}", request.CaseId, request.EnrollmentId);
            var startTime = DateTime.Now;

            exstreamRequestDocumentType = exstreamRequestType;
            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var caseBrokers = cmsCase.CaseBrokers.Where(c => c.Case.Id == request.CaseId);
                var caseUnderwritingRequests = cmsCase.CaseUnderwritingRequests.FirstOrDefault(c => c.Case.Id == request.CaseId);
                var enrollment = cmsCase.CaseEnrollments.FirstOrDefault(c => c.Id == request.EnrollmentId);
                var enrollmentClassOut = unitOfWork.Repository<EnrollmentOutput>().Linq().FirstOrDefault(c => c.Enrollment.Id == enrollment.Id);
                var contactAddress = unitOfWork.Repository<ContactAddress>().Linq().Where(c => c.Case.Id == request.CaseId);

                var enrollmentParticipents = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => c.Enrollment.Id == enrollment.Id && c.Participant.IsActive == true &&
                        (c.Participant.IsEligible == true || (c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.NoLongerInGroup && 
                        c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.ActivePolicyNoLongerInGroup && c.Participant.InEligibleReason_Id == null)));
                if (request.ParticipantIds != null && request.ParticipantIds.Count > 0)
                {
                    enrollmentParticipents = enrollmentParticipents.Where(c => request.ParticipantIds.Contains(c.Id));
                }

                var pdrClasses = enrollmentParticipents.Select(c => c.Participant.PlanDesignRequestClass).Distinct();
                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(p => pdrClasses.Contains(p.PlanDesignRequestClass));
                var enrollmentPDRClasses = enrollment.Classes.Where(c => c.Enrollment.Id == enrollment.Id);

                request.IsCompactState = caseUnderwritingRequests.IsCompactState != null ? caseUnderwritingRequests.IsCompactState.Value : false;

                mldiCase.cmsCode = cmsCase.CaseNumber;
                mldiCase.casePassword = enrollment.Passcode != null ? enrollment.Passcode  : string.Empty;

                mldiCase.useCompactApp = request.IsCompactState;

                PricingTypeEnum pricingType = caseUnderwritingRequests.PricingType != null ? caseUnderwritingRequests.PricingType.Value : PricingTypeEnum.PC2016;

                mldiCase.productType = pricingType.ToString();

                mldiCase.enrollmentName = CompanyName(enrollmentClassOut, cmsCase);
                mldiCase.enrollmentStartDate = enrollment.EnrollmentStartDate;
                mldiCase.enrollmentEndDate = enrollment.EnrollmentEndDate;
                mldiCase.BaseAMBBillingType = enrollment.AMBType != null ? Convert.ToString(enrollment.AMBType) : string.Empty;
                mldiCase.BuyUpAMBBillingType = enrollment.BuyUpAMBType != null ? Convert.ToString(enrollment.BuyUpAMBType) : string.Empty;

                var annualReviewsForCase = unitOfWork.Repository<AnnualReview>()
                                                     .Linq().Where(c => c.Case.Id == request.CaseId && (c.AnnualReviewStatusType == AnnualReviewStatusTypeEnum.Annual_Review_Approved || c.AnnualReviewStatusType == AnnualReviewStatusTypeEnum.Annual_Review_Pending))
                                                     .OrderByDescending(a => a.CaseYear);

                var mostRecentAnnualReview = annualReviewsForCase.FirstOrDefault();
                var isNewCase = !annualReviewsForCase.Any(a => a.CaseYear != null);

                if (isNewCase)
                {
                    mldiCase.caseType = CaseTypeRestriction.New;
                    mldiCase.renewalYears = 1;
                }
                else
                {
                    mldiCase.caseType = CaseTypeRestriction.Renewal;
                    var renewalYear = mostRecentAnnualReview == null || mostRecentAnnualReview.CaseYear == null ? 1 : (uint)mostRecentAnnualReview.CaseYear + 1;
                    mldiCase.renewalYears = renewalYear;
                }

                mldiCase.company = new MLDICompany()
                {
                    name = CompanyName(enrollmentClassOut, cmsCase),
                    sicCode = GetSisCodeAndName(cmsCase),
                    mainAddress = new MLDIAddress()
                    {
                        type = AddressTypeRestriction.CompanyMain,
                        locationName = "CompanyMain",
                        street1 = cmsCase.CompanyAddressLine1 ?? "",
                        street2 = cmsCase.CompanyAddressLine2 ?? "",
                        city = cmsCase.CompanyCity ?? "",
                        state = cmsCase.CompanyStateType != null ? cmsCase.CompanyStateType.Value.ToString() : "",
                        postalCode = cmsCase.CompanyZipCode ?? "",
                        country = "United States of America",
                        phoneNumber = "",
                    },

                    licenseContractType = GetSitusType(caseUnderwritingRequests),

                    multiStateEnabledStates = (((LicenseContractRestriction)caseUnderwritingRequests.SitusType.Value).Equals(LicenseContractRestriction.MultiState))
                                              ? new List<string> { caseUnderwritingRequests.SitusMultiState1Type.Value.ToString(), caseUnderwritingRequests.SitusMultiState2Type.Value.ToString(), caseUnderwritingRequests.SitusMultiState3Type.Value.ToString() }
                                               : null,
                };

                mldiCase.producersAndAgents = GetProducersAndAgents(caseBrokers, contactAddress);
                mldiCase.groups = GetGroups(pdrSoldClass, enrollmentParticipents, cmsCase, caseBrokers, enrollmentPDRClasses);
            }

            Log.TraceFormat("-CreateCase CaseId : {0} EnrollmentId: {1} Time: {2}s", request.CaseId, request.EnrollmentId, (DateTime.Now - startTime).TotalSeconds);
        }

        private string GetSisCodeAndName(Case cmscase)
        {
            string SisCode = string.Empty;
            string Sisname = string.Empty;


            if (cmscase.CompanySicMajorGroupType != null)
            {
                SisCode = cmscase.CompanySicMajorGroupType.Code;

                SisCode = SisCode.Remove(0, 2);

                Sisname = ((CompanySicMajorGroupTypeEnum)cmscase.CompanySicMajorGroupType.Id).GetDescription().ToString();
            }

            return SisCode + "-" + Sisname;

        }
        private string CompanyName(EnrollmentOutput enrollOutput, Case cases)
        {
            string Compname;
            if (enrollOutput != null && !string.IsNullOrEmpty(enrollOutput.CompanyFriendlyName))
            {
                Compname = enrollOutput.CompanyFriendlyName;
            }
            else
            {
                Compname = cases.CompanyName ?? "";
            }

            return Compname;

        }
        private LicenseContractRestriction GetSitusType(CaseUnderwritingRequest caseUnderwritingRequests)
        {
            LicenseContractRestriction licenseCRe = LicenseContractRestriction.CorporateSitus;
            if (caseUnderwritingRequests.SitusType != null)
            {
                if (caseUnderwritingRequests.SitusType == SitusTypeEnum.Corporate)
                {
                    licenseCRe = LicenseContractRestriction.CorporateSitus;
                }
                else if (caseUnderwritingRequests.SitusType == SitusTypeEnum.Multi_State)
                {
                    licenseCRe = LicenseContractRestriction.MultiState;
                }
                else if (caseUnderwritingRequests.SitusType == SitusTypeEnum.Residence)
                {
                    licenseCRe = LicenseContractRestriction.StateSpecific;
                }
            }
            return licenseCRe;

        }
        private List<MLDIProducerAgent> GetProducersAndAgents(IEnumerable<CaseBroker> caseBrokers, IQueryable<ContactAddress> contactAddress)
        {
            List<MLDIProducerAgent> listMldiProducerAgent = new List<MLDIProducerAgent>();
            foreach (var producer in caseBrokers)
            {
                MLDIProducerAgent agent = new MLDIProducerAgent();
                agent.type = ProducerAgentTypeRestriction.Producer;
                // agent.cmsCode = producer.AgencyCode != null ? "000" + producer.AgencyCode : "";
                agent.cmsCode = producer.BrokerWritingCode != null ? producer.BrokerWritingCode : "";
                agent.agencyCode = producer.AgencyCode;
                agent.agencyName = producer.CompanyName != null ? producer.CompanyName : string.Empty;
                CaseBrokerState cbs = producer.CaseBrokerStates.FirstOrDefault();
                if (cbs != null)
                {
                    agent.leadProducer = (bool)producer.CaseBrokerStates.FirstOrDefault().IsPrimaryBrokerIndicator;
                }


                agent.personalInformation.addresses = new List<MLDIAddress>();
                agent.personalInformation = new MLDIPerson();
                agent.personalInformation.type = PersonTypeRestriction.ProducerAgent;
                agent.personalInformation.title = "";
                agent.personalInformation.prefix = "";
                string s = producer.BrokerName != null ? producer.BrokerName : "";
                string[] values = s.Split(',');
                int index = 0;
                for (index = 0; index < values.Length; index++)
                {
                    values[index] = values[index].Trim();

                }
                if (index >= 2)
                {
                    agent.personalInformation.firstName = values[1].Length > 0 ? values[0] : "";
                    agent.personalInformation.lastName = values[0].Length > 0 ? values[1] : "";
                }
                else
                {
                    agent.personalInformation.firstName = producer.BrokerName != null ? producer.BrokerName : "";
                    agent.personalInformation.lastName = string.Empty;
                }

                IQueryable<ContactAddress> producerContact = null;

                if (contactAddress != null)
                {
                    if (!string.IsNullOrEmpty(agent.personalInformation.firstName) && !string.IsNullOrEmpty(agent.personalInformation.lastName))
                    {
                        producerContact = contactAddress.Where(c => c.ContactRoleType == ContactRoleTypeEnum.Producer &&
                                                                    c.ContactName.Contains(
                                                                        agent.personalInformation.firstName) &&
                                                                    c.ContactName.Contains(
                                                                        agent.personalInformation.lastName));
                    }
                    else
                    {
                        //This accounts for logic above that only loads firstname field.
                        producerContact = contactAddress.Where(c => c.ContactRoleType == ContactRoleTypeEnum.Producer &&
                                                                    c.ContactName.Contains(agent.personalInformation.firstName));
                    }
                }

                if (producerContact.Any())
                {
                    agent.personalInformation.email = producerContact.FirstOrDefault().Email != null ? producerContact.FirstOrDefault().Email : "undetermined@undetermined.com";
                }

                foreach (var contactAddres in producerContact)
                {
                    if (contactAddres != null)
                    {
                        MLDIAddress address = new MLDIAddress();

                        address.type = AddressTypeRestriction.Work;
                        address.locationName = "Work";
                        address.street1 = contactAddres.AddressLine1 != null ? contactAddres.AddressLine1 : "";
                        address.street2 = contactAddres.AddressLine2 != null ? contactAddres.AddressLine2 : "";
                        address.city = contactAddres.City != null ? contactAddres.City : "";
                        address.state = contactAddres.StateType != null ? contactAddres.StateType.Value.ToString() : "";
                        address.postalCode = contactAddres.ZipCode != null ? contactAddres.ZipCode : "";
                        address.country = "United States of America";
                        address.phoneNumber = contactAddres.Phone != null ? contactAddres.Phone : "";

                        agent.personalInformation.addresses.Add(address);
                    }
                }

                agent.stateLicenses = new List<string>();
                foreach (var producerState in producer.CaseBrokerStates)
                {
                    if (producerState.IsLicensedIndicator == true)
                        agent.stateLicenses.Add(producerState.StateType.ToString());
                }
                listMldiProducerAgent.Add(agent);
            }
            return listMldiProducerAgent;

        }
        private List<MLDIGroup> GetGroups(IQueryable<PDRSoldClass> pdrSoldClass, IQueryable<EnrollmentParticipant> enrollmentParticipents,
            Case cmsCase, IEnumerable<CaseBroker> caseBrokers, IEnumerable<EnrollmentPDRClass> enrollmentPDRClasss)
        {

            Log.TraceFormat("+GetGroups CaseId: {0}", cmsCase.Id);

            var startTime = DateTime.Now;

            List<MLDIGroup> lstMLDIGroup = new List<MLDIGroup>();
            int emailAddressCount = 0;

            Log.TraceFormat("+GetGroups CaseId: {0} SoldClassCount: {1}", cmsCase.Id, pdrSoldClass.Count());
            foreach (var pdrSoldClas in pdrSoldClass)
            {
                MLDIGroup group = new MLDIGroup();
                {
                    Log.TraceFormat("+GetGroups CaseId: {0} GroupName: {1}", cmsCase.Id, pdrSoldClas.PlanDesignRequestClass.PlanDesignRequestClassName);

                    group.cmsCode = pdrSoldClas.Id.ToString();
                    group.groupName = pdrSoldClas.PlanDesignRequestClass.PlanDesignRequestClassName;
                    group.groupDescription = pdrSoldClas.EligiblePopulationText;
                    group.eligibleParticipants = new List<MLDIParticipant>();
                    MLDIParticipant participant = new MLDIParticipant();
                    participant.currentLTDs = null;
                    var enrollmentParticipentsByClass = enrollmentParticipents.Where(c => c.Participant.PlanDesignRequestClass.Id == pdrSoldClas.PlanDesignRequestClass.Id);
                    //Mockuser=False(they are real user
                    foreach (EnrollmentParticipant enrolledParticipant in enrollmentParticipentsByClass)
                    {
                        participant = new MLDIParticipant();
                        participant.currentLTDs = null;
                        participant.cmsCode = enrolledParticipant.Id.ToString() != null ? enrolledParticipant.Id.ToString() : "";
                        participant.cmsStatus = GetParticipantStatusCode(enrolledParticipant.Participant);
                        participant.isMockEmployee = false;

                        if (enrolledParticipant.Enrollment.EnrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.OneStep)
                        {
                            participant.isOSEIndicator = true;
                        }
                        else {
                            participant.isOSEIndicator = false;
                        }
                        if (enrolledParticipant.Enrollment.EnrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.DirectCoverage)
                        {
                            participant.isDirectCoverageIndicator = true;
                        }
                        else
                        {
                            participant.isDirectCoverageIndicator = false;
                        }

                        if (!string.IsNullOrEmpty(enrolledParticipant.Participant.Gender))
                        {

                            if (enrolledParticipant.Participant.Gender.ToUpper() == "M" || enrolledParticipant.Participant.Gender.ToUpper() == "F")
                            {
                                participant.gender = ((GenderRestriction)(enrolledParticipant.Participant.Gender.ToUpper() == "M" ? 0 : 1));
                            }
                            else if (enrolledParticipant.Participant.Gender.ToUpper().Trim() == "MALE" || enrolledParticipant.Participant.Gender.ToUpper().Trim() == "FEMALE")
                            {
                                participant.gender = ((GenderRestriction)(enrolledParticipant.Participant.Gender.ToUpper().Trim() == "MALE" ? 0 : 1));
                            }

                        }
                        else
                        {
                            participant.gender = GenderRestriction.Unknown;
                        }

                        if (enrolledParticipant.Participant.DateOfBirth.Value != null)
                        {
                            participant.dateOfBirth = enrolledParticipant.Participant.DateOfBirth.Value;
                        }

                        participant.temporaryPassword = enrolledParticipant.OnlineEnrollmentPassword != null ? enrolledParticipant.OnlineEnrollmentPassword : "";
                        participant.existingPolicyNumber = string.Empty;
                        if (enrolledParticipant.Enrollment.EnrollmentMethodType.Id == (int)EnrollmentMethodTypeEnum.Paper && exstreamRequestDocumentType == "EnrollmentKit")
                        {
                            List<string> producerWritingCodes = GetCaseProducersAndTotalDiscount(enrolledParticipant, participant);

                            participant.isCareerAgent = GetCareerAgentIndicator(producerWritingCodes);
                        }
                        if (enrolledParticipant.Policies.Any())
                        {
                            var policy = enrolledParticipant.Policies.FirstOrDefault();
                            participant.existingPolicyNumber = policy != null ? policy.PolicyNumber : string.Empty;
                        }
                        participant.personalInformation = new MLDIPerson();
                        {
                            participant.personalInformation.type = PersonTypeRestriction.Employee;

                            participant.personalInformation.employeeId = enrolledParticipant.Participant.EmployeeId != null
                                                                        ? enrolledParticipant.Participant.EmployeeId.Trim() : "";

                            if (participant.isOSEIndicator)
                            {
                                participant.personalInformation.socialSecurityNumber = enrolledParticipant.Participant.SocialSecurityNumber != null
                                                                                      ? enrolledParticipant.Participant.SocialSecurityNumber.Trim() : "";

                                if (enrolledParticipant.Participant.Citizenship != null && enrolledParticipant.Participant.Citizenship == true)
                                {
                                    participant.personalInformation.usCitizen = "Yes" ;
                                }

                                if (enrolledParticipant.Participant.AAW != null && enrolledParticipant.Participant.AAW == true)
                                {
                                    participant.personalInformation.fullTime = "Yes" ;
                                }
                            }
                            if(participant.isDirectCoverageIndicator)
                            {
                                participant.personalInformation.socialSecurityNumber = enrolledParticipant.Participant.SocialSecurityNumber != null
                                                                                     ? enrolledParticipant.Participant.SocialSecurityNumber.Trim() : "";
                            }

                            participant.personalInformation.title = "";
                            participant.personalInformation.prefix = "";
                            participant.personalInformation.firstName = enrolledParticipant.Participant.FirstName != null
                                                                        ? enrolledParticipant.Participant.FirstName : "";
                            participant.personalInformation.middleName = enrolledParticipant.Participant.MiddleInitial != null
                                                                        ? enrolledParticipant.Participant.MiddleInitial : "";
                            participant.personalInformation.lastName = enrolledParticipant.Participant.LastName != null
                                                                        ? enrolledParticipant.Participant.LastName : "";
                            participant.personalInformation.suffix = enrolledParticipant.Participant.Suffix != null
                                                                        ? enrolledParticipant.Participant.Suffix : "";
                            participant.personalInformation.email = enrolledParticipant.Participant.WorkEmail != null
                                                                        ? enrolledParticipant.Participant.WorkEmail : "";

                            participant.personalInformation.addresses = new List<MLDIAddress>();
                            MLDIAddress mLdiAddress = new MLDIAddress();
                            {
                                mLdiAddress.type = AddressTypeRestriction.Home;
                                mLdiAddress.locationName = "Home";
                                mLdiAddress.street1 = enrolledParticipant.Participant.HomeStreet1 != null ?
                                                          enrolledParticipant.Participant.HomeStreet1 : "";
                                mLdiAddress.street2 = enrolledParticipant.Participant.HomeStreet2 != null ?
                                                          enrolledParticipant.Participant.HomeStreet2 : "";
                                mLdiAddress.city = enrolledParticipant.Participant.HomeCity != null ?
                                                          enrolledParticipant.Participant.HomeCity : "";
                                mLdiAddress.state = enrolledParticipant.Participant.HomeState != null ? ((StateTypeEnum)((int)enrolledParticipant.Participant.HomeState)).ToString() :
                                    !string.IsNullOrWhiteSpace(enrolledParticipant.Participant.HomeStateDescription) ? enrolledParticipant.Participant.HomeStateDescription : "";
                                mLdiAddress.postalCode = enrolledParticipant.Participant.HomeZipCode != null ?
                                                          enrolledParticipant.Participant.HomeZipCode : "";
                                mLdiAddress.country = "United States of America";
                                mLdiAddress.phoneNumber = enrolledParticipant.Participant.HomePhone != null ?
                                                          enrolledParticipant.Participant.HomePhone : "";
                            }

                            participant.personalInformation.addresses.Add(mLdiAddress);
                            mLdiAddress = new MLDIAddress();
                            {
                                mLdiAddress.type = AddressTypeRestriction.Work;
                                mLdiAddress.locationName = "Work";
                                mLdiAddress.street1 = enrolledParticipant.Participant.WorkStreet1 != null ? enrolledParticipant.Participant.WorkStreet1 : "";
                                mLdiAddress.street2 = enrolledParticipant.Participant.WorkStreet2 != null ? enrolledParticipant.Participant.WorkStreet2 : "";
                                mLdiAddress.city = enrolledParticipant.Participant.WorkCity != null ? enrolledParticipant.Participant.WorkCity : "";
                                mLdiAddress.state = enrolledParticipant.Participant.WorkState != null ? ((StateTypeEnum)((int)enrolledParticipant.Participant.WorkState)).ToString() :
                                    !string.IsNullOrWhiteSpace(enrolledParticipant.Participant.WorkStateDescription) ? enrolledParticipant.Participant.WorkStateDescription : "";
                                mLdiAddress.postalCode = enrolledParticipant.Participant.WorkZipCode != null ? enrolledParticipant.Participant.WorkZipCode : "";
                                mLdiAddress.country = "United States of America";
                                mLdiAddress.phoneNumber = enrolledParticipant.Participant.WorkLocationPhone != null ? enrolledParticipant.Participant.WorkLocationPhone : "";
                            }
                            participant.personalInformation.addresses.Add(mLdiAddress);
                        }
                        participant.occupationDetails = new MLDIParticipantOccupation();
                        {

                            participant.occupationDetails.occupationClass = enrolledParticipant.Participant.OccupationClass_Id != null ? ((OccupationClassTypeEnum)enrolledParticipant.Participant.OccupationClass_Id).GetDescription() : "";
                            participant.occupationDetails.occupationDescription = enrolledParticipant.Participant.JobTitle != null ? enrolledParticipant.Participant.JobTitle : "";
                            if (enrolledParticipant.Participant.DateOfHire.HasValue)
                            {
                                participant.occupationDetails.dateOfHire = (DateTime)enrolledParticipant.Participant.DateOfHire;
                            }

                            //participant.occupationDetails.weeklyHoursWorked = enrolledParticipant.Participant.WeeklyHoursWorked != null ? enrolledParticipant.Participant.WeeklyHoursWorked.ToString() : "";
                            participant.occupationDetails.weeklyHoursWorked = "9999";
                        }
                        participant.incomeDetails = new MLDIParticipantIncome();
                        {
                            participant.incomeDetails.currentYearInsurableIncome = enrolledParticipant.Participant.IDIInsurableIncomeCalculatedAmount ?? 0;
                            participant.incomeDetails.currentYearInsurableSalary = enrolledParticipant.Participant.MostRecentSalaryAmount ?? 0;
                            participant.incomeDetails.currentYearInsurableIncentive = ((enrolledParticipant.Participant.IDIInsurableIncomeCalculatedAmount != null ? enrolledParticipant.Participant.IDIInsurableIncomeCalculatedAmount : 0) - (enrolledParticipant.Participant.MostRecentSalaryAmount != null ? enrolledParticipant.Participant.MostRecentSalaryAmount : 0));
                            participant.incomeDetails.retirementContribution = enrolledParticipant.Participant.TotalEmployerOrEmployeeRetirementContributionAmount ?? 0;

                            var pdrSoldClassPlan = pdrSoldClas.PDRSoldClassPlan != null ? pdrSoldClas.PDRSoldClassPlan.FirstOrDefault() : null;

                            if (pdrSoldClassPlan != null && (pdrSoldClassPlan.CoveredEarningsType != CoveredEarningsTypeEnum.W_2Income && pdrSoldClassPlan.CoveredEarningsType != CoveredEarningsTypeEnum.K_1Earnings))
                            {
                                participant.incomeDetails.baseSalary = enrolledParticipant.Participant.MostRecentSalaryAmount ?? 0;
                                participant.incomeDetails.bonusIncome = enrolledParticipant.Participant.MostRecentPaidBonusAmount ?? 0;
                                participant.incomeDetails.commissionIncome = enrolledParticipant.Participant.MostRecentPaidCommissionAmount ?? 0;
                            }
                            else if (pdrSoldClassPlan != null && pdrSoldClassPlan.CoveredEarningsType == CoveredEarningsTypeEnum.W_2Income)
                            {
                                if (exstreamRequestDocumentType != "BridgelineXml")
                                {
                                    participant.incomeDetails.w2Income = enrolledParticipant.Participant.MostRecentYearPaidW2Income ?? 0;
                                }

                                if (enrolledParticipant.Participant.MostRecentSalaryAmount == 0 || enrolledParticipant.Participant.MostRecentSalaryAmount == null)
                                {
                                    participant.incomeDetails.baseSalary = enrolledParticipant.Participant.MostRecentYearPaidW2Income ?? 0;
                                }
                                else {
                                    participant.incomeDetails.baseSalary = (decimal)enrolledParticipant.Participant.MostRecentYearPaidW2Income  + (decimal)enrolledParticipant.Participant.MostRecentSalaryAmount ;
                                }
                            }
                            else if (pdrSoldClassPlan != null && pdrSoldClassPlan.CoveredEarningsType == CoveredEarningsTypeEnum.K_1Earnings)
                            {
                                if (exstreamRequestDocumentType != "BridgelineXml")
                                {
                                    participant.incomeDetails.k1Income = enrolledParticipant.Participant.MostRecentPaidK1IncomeAmount ?? 0;
                                }

                                if (enrolledParticipant.Participant.MostRecentSalaryAmount == 0 || enrolledParticipant.Participant.MostRecentSalaryAmount == null)
                                {
                                    participant.incomeDetails.baseSalary = enrolledParticipant.Participant.MostRecentPaidK1IncomeAmount ?? 0;
                                }
                                else {
                                    participant.incomeDetails.baseSalary = (decimal)enrolledParticipant.Participant.MostRecentSalaryAmount  + (decimal)enrolledParticipant.Participant.MostRecentPaidK1IncomeAmount ;
                                }
                            }
                        }
                        foreach (CaseBroker caseBroker in caseBrokers)
                        {
                            participant.servicingProducerCmsCode = caseBroker.BrokerWritingCode != null ? caseBroker.BrokerWritingCode : "";
                            participant.signingProducerCmsCode = caseBroker.BrokerWritingCode != null ? caseBroker.BrokerWritingCode : "";
                            participant.ContactProducerCmsCode = caseBroker.BrokerWritingCode != null ? caseBroker.BrokerWritingCode : "";
                        }

                        if (enrolledParticipant.Participant.IDIBenefitAmount1 > 0 || enrolledParticipant.Participant.IDIBenefitAmount2 > 0
                            || enrolledParticipant.Participant.IDIBenefitAmount3 > 0 || enrolledParticipant.Participant.IDIBenefitAmount4 > 0
                            || enrolledParticipant.Participant.LTDCalculatedAmount > 0)
                        {
                            participant.currentLTDs = new List<MLDIAdditionalLtd>();
                            participant.currentLTDs = AdditionalLtdDatabuilder(enrolledParticipant, pdrSoldClas, cmsCase);
                        }

                        // qualifiedOffer Non - Smoker
                        participant.offers = GetQualifiedOffers(enrolledParticipant, pdrSoldClas, cmsCase, participant.currentLTDs);
                        //qualifiedOffer  Smoker
                        //participant.offers = GetQualifiedOfferSmoker(enrolledParticipant, pdrSoldClas);

                        participant.effectiveDate = (DateTime)enrolledParticipant.Enrollment.EffectiveDate;
                        group.eligibleParticipants.Add(participant);
                    }

                    //Mockuser=True(they are not real user)
                    var enrollmentParticipentPlans = enrollmentParticipentsByClass.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();

                    var option1EnrolledParticipants = enrollmentParticipentsByClass.SelectMany(c => c.EnrollmentParticipantOptionPlans).
                        Where(c => c.StandardOptionCodeNonSmoker != null && c.StandardOptionCodeNonSmoker.Contains("Option 1") || (c.StandardOptionCodeSmoker != null && c.StandardOptionCodeSmoker.Contains("Option 1"))).Select(c => c.EnrollmentParticipant).ToList();

                    var option2EnrolledParticipants = enrollmentParticipentsByClass.SelectMany(c => c.EnrollmentParticipantOptionPlans).
                        Where(c => c.StandardOptionCodeNonSmoker != null && c.StandardOptionCodeNonSmoker.Contains("Option 2") || (c.StandardOptionCodeSmoker != null && c.StandardOptionCodeSmoker.Contains("Option 2"))).Select(c => c.EnrollmentParticipant).ToList();

                    var option3EnrolledParticipants = enrollmentParticipentsByClass.SelectMany(c => c.EnrollmentParticipantOptionPlans).
                        Where(c => c.StandardOptionCodeNonSmoker != null && c.StandardOptionCodeNonSmoker.Contains("Option 3") || (c.StandardOptionCodeSmoker != null && c.StandardOptionCodeSmoker.Contains("Option 3"))).Select(c => c.EnrollmentParticipant).ToList();

                    var option1EnrolledParticipantPlans = option1EnrolledParticipants.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                    var maxOption1GSIAmount = option1EnrolledParticipantPlans.Max(c => c.TotalMonthlyBenefitAmount);
                    var option1EnrolOption = option1EnrolledParticipantPlans.Where(c => c.TotalMonthlyBenefitAmount == maxOption1GSIAmount).ToList();
                    var option1MockEnrolledParticiapnt = option1EnrolOption.Select(c => c.EnrollmentParticipant).FirstOrDefault();
                    int count = 0;
                    if (option1MockEnrolledParticiapnt != null)
                    {
                        count++;
                        emailAddressCount++;
                        BuildMockParticipant(option1MockEnrolledParticiapnt, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                    }

                    var option2EnrolledParticipantPlans = option2EnrolledParticipants.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                    var maxOption2GSIAmount = option2EnrolledParticipantPlans.Max(c => c.TotalMonthlyBenefitAmount);
                    var option2EnrolOption = option2EnrolledParticipantPlans.Where(c => c.TotalMonthlyBenefitAmount == maxOption1GSIAmount).ToList();
                    var option2MockEnrolledParticiapnt = option2EnrolOption.Select(c => c.EnrollmentParticipant).FirstOrDefault();

                    if (option2MockEnrolledParticiapnt != null)
                    {
                        count++;
                        emailAddressCount++;
                        BuildMockParticipant(option2MockEnrolledParticiapnt, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                    }

                    var option3EnrolledParticipantPlans = option3EnrolledParticipants.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                    var maxOption3GSIAmount = option3EnrolledParticipantPlans.Max(c => c.TotalMonthlyBenefitAmount);
                    var option3EnrolOption = option3EnrolledParticipantPlans.Where(c => c.TotalMonthlyBenefitAmount == maxOption1GSIAmount).ToList();
                    var option3MockEnrolledParticiapnt = option3EnrolOption.Select(c => c.EnrollmentParticipant).FirstOrDefault();

                    if (option3MockEnrolledParticiapnt != null)
                    {
                        count++;
                        emailAddressCount++;
                        BuildMockParticipant(option3MockEnrolledParticiapnt, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                    }

                    var participantAgeLimit35To40 = enrollmentParticipentsByClass.Where(c => c.Participant.Age != null && c.Participant.Age >= 35 && c.Participant.Age <= 40).ToList();

                    if (participantAgeLimit35To40 != null)
                    {
                        if (participantAgeLimit35To40.Count() > 0)
                        {
                            var participantAgeLimit35To40Plans = participantAgeLimit35To40.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                            var participantAgeLimit35To40MaxGSIAmount = participantAgeLimit35To40Plans.Max(c => c.TotalMonthlyBenefitAmount);
                            var participantAgeLimit35To40EnrolOption = participantAgeLimit35To40Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit35To40MaxGSIAmount).ToList();

                            GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit35To40EnrolOption);
                            var mockParticipantAgeLimit35To40 = participantAgeLimit35To40EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                            if (mockParticipantAgeLimit35To40 != null)
                            {
                                count++;
                                emailAddressCount++;
                                BuildMockParticipant(mockParticipantAgeLimit35To40, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                            }
                        }
                    }

                    var participantAgeLimit41To45 = enrollmentParticipentsByClass.Where(c => c.Participant.Age != null && c.Participant.Age >= 41 && c.Participant.Age <= 45).ToList();
                    if (participantAgeLimit41To45 != null)
                    {
                        if (participantAgeLimit41To45.Count() > 0)
                        {
                            var participantAgeLimit41To45Plans = participantAgeLimit41To45.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                            var participantAgeLimit41To45MaxGSIAmount = participantAgeLimit41To45Plans.Max(c => c.TotalMonthlyBenefitAmount);
                            var participantAgeLimit41To45EnrolOption = participantAgeLimit41To45Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit41To45MaxGSIAmount).ToList();

                            GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit41To45EnrolOption);
                            var mockparticipantAgeLimit41To45 = participantAgeLimit41To45EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                            if (mockparticipantAgeLimit41To45 != null)
                            {
                                count++;
                                emailAddressCount++;
                                BuildMockParticipant(mockparticipantAgeLimit41To45, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                            }
                        }
                    }
                    var participantAgeLimit46To55 = enrollmentParticipentsByClass.Where(c => c.Participant.Age != null && c.Participant.Age >= 46 && c.Participant.Age <= 55).ToList();
                    if (participantAgeLimit46To55 != null)
                    {
                        if (participantAgeLimit46To55.Count() > 0)
                        {
                            var participantAgeLimit46To55Plans = participantAgeLimit46To55.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                            var participantAgeLimit46To55MaxGSIAmount = participantAgeLimit46To55Plans.Max(c => c.TotalMonthlyBenefitAmount);
                            var participantAgeLimit46To55EnrolOption = participantAgeLimit46To55Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit46To55MaxGSIAmount).ToList();

                            GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit46To55EnrolOption);
                            var mockparticipantAgeLimit46To55 = participantAgeLimit46To55Plans.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                            if (mockparticipantAgeLimit46To55 != null)
                            {
                                count++;
                                emailAddressCount++;
                                BuildMockParticipant(mockparticipantAgeLimit46To55, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                            }
                        }
                    }

                    var participantAgeLimit56To60 = enrollmentParticipentsByClass.Where(c => c.Participant.Age != null && c.Participant.Age >= 56 && c.Participant.Age <= 60).ToList();
                    if (participantAgeLimit56To60 != null)
                    {
                        if (participantAgeLimit56To60.Count() > 0)
                        {
                            var participantAgeLimit56To60Plans = participantAgeLimit56To60.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                            var participantAgeLimit56To60MaxGSIAmount = participantAgeLimit56To60Plans.Max(c => c.TotalMonthlyBenefitAmount);
                            var participantAgeLimit56To60EnrolOption = participantAgeLimit56To60Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit56To60MaxGSIAmount).ToList();

                            GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit56To60EnrolOption);
                            var mockparticipantAgeLimit56To60 = participantAgeLimit56To60EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                            if (mockparticipantAgeLimit56To60 != null)
                            {
                                count++;
                                emailAddressCount++;
                                BuildMockParticipant(mockparticipantAgeLimit56To60, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                            }
                        }
                    }
                    var participantAgeLimit61To62 = enrollmentParticipentsByClass.Where(c => c.Participant.Age != null && c.Participant.Age >= 61 && c.Participant.Age <= 62).ToList();
                    if (participantAgeLimit61To62 != null)
                    {
                        if (participantAgeLimit61To62.Count() > 0)
                        {
                            var participantAgeLimit61To62Plans = participantAgeLimit61To62.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                            var participantAgeLimit61To62MaxGSIAmount = participantAgeLimit61To62Plans.Max(c => c.TotalMonthlyBenefitAmount);
                            var participantAgeLimit61To62EnrolOption = participantAgeLimit61To62Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit61To62MaxGSIAmount).ToList();

                            GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit61To62EnrolOption);
                            var mockparticipantAgeLimit61To62 = participantAgeLimit61To62EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                            if (mockparticipantAgeLimit61To62 != null)
                            {
                                count++;
                                emailAddressCount++;
                                BuildMockParticipant(mockparticipantAgeLimit61To62, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                            }
                        }
                    }

                    var participantAgeLimit63To64 = enrollmentParticipentsByClass.Where(c => c.Participant.Age != null && c.Participant.Age >= 63 && c.Participant.Age <= 64).ToList();
                    if (participantAgeLimit63To64 != null)
                    {
                        if (participantAgeLimit63To64.Count() > 0)
                        {
                            var participantAgeLimit63To64Plans = participantAgeLimit63To64.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                            var participantAgeLimit63To64MaxGSIAmount = participantAgeLimit63To64Plans.Max(c => c.TotalMonthlyBenefitAmount);
                            var participantAgeLimit63To64EnrolOption = participantAgeLimit63To64Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit63To64MaxGSIAmount).ToList();

                            GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit63To64EnrolOption);
                            var mockparticipantAgeLimit63To64 = participantAgeLimit63To64EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                            if (mockparticipantAgeLimit63To64 != null)
                            {
                                count++;
                                emailAddressCount++;
                                BuildMockParticipant(mockparticipantAgeLimit63To64, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                            }
                        }
                    }

                    var participantAgeLimit65To66 = enrollmentParticipentsByClass.Where(c => c.Participant.Age != null && c.Participant.Age >= 65 && c.Participant.Age <= 66).ToList();
                    if (participantAgeLimit65To66 != null)
                    {
                        if (participantAgeLimit65To66.Count() > 0)
                        {
                            var participantAgeLimit65To66Plans = participantAgeLimit65To66.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                            var participantAgeLimit65To66MaxGSIAmount = participantAgeLimit65To66Plans.Max(c => c.TotalMonthlyBenefitAmount);
                            var participantAgeLimit65To66EnrolOption = participantAgeLimit65To66Plans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit65To66MaxGSIAmount).ToList();

                            GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit65To66EnrolOption);
                            var mockparticipantAgeLimit65To66 = participantAgeLimit65To66EnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                            if (mockparticipantAgeLimit65To66 != null)
                            {
                                count++;
                                emailAddressCount++;
                                BuildMockParticipant(mockparticipantAgeLimit65To66, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                            }
                        }
                    }

                    var participantAgeLimit67Over = enrollmentParticipentsByClass.Where(c => c.Participant.Age != null && c.Participant.Age >= 67).ToList();
                    if (participantAgeLimit67Over != null)
                    {
                        if (participantAgeLimit67Over.Count() > 0)
                        {
                            var participantAgeLimit67OverPlans = participantAgeLimit67Over.SelectMany(c => c.EnrollmentParticipantOptionPlans).ToList();
                            var participantAgeLimit67OverMaxGSIAmount = participantAgeLimit67OverPlans.Max(c => c.TotalMonthlyBenefitAmount);
                            var participantAgeLimit67OverEnrolOption = participantAgeLimit67OverPlans.Where(c => c.TotalMonthlyBenefitAmount == participantAgeLimit67OverMaxGSIAmount).ToList();

                            GetOption1EnrollmentParticipantOptionPlan(participantAgeLimit67OverEnrolOption);
                            var mockparticipantAgeLimit67Over = participantAgeLimit67OverEnrolOption.Select(c => c.EnrollmentParticipant).OrderBy(d => d.Participant.LastName).FirstOrDefault();
                            if (mockparticipantAgeLimit67Over != null)
                            {
                                count++;
                                emailAddressCount++;
                                BuildMockParticipant(mockparticipantAgeLimit67Over, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                            }
                        }
                    }

                    if (group != null && group.eligibleParticipants != null)
                    {
                        var existingCoverage = group.eligibleParticipants.Where(c => c.currentLTDs != null).SelectMany(c => c.currentLTDs).ToList();
                        if (existingCoverage != null)
                        {
                            if (existingCoverage.Count > 0)
                            {
                                var internalCoverage = existingCoverage.Where(c => c.coverageCategory == CoverageCategoryRestriction.Individual
                                && ((c.isExternalReplacement == null || c.isExternalReplacement == false) && (c.isInternalReplacement == null || c.isInternalReplacement == false)));
                                if (internalCoverage != null)
                                {
                                    if (option1MockEnrolledParticiapnt != null)
                                    {
                                        count++;
                                        emailAddressCount++;
                                        BuildMockParticipant(option1MockEnrolledParticiapnt, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                                    }
                                }

                                var externalCoverage = existingCoverage.Where(c => c.coverageCategory == CoverageCategoryRestriction.Individual
                                && (c.isExternalReplacement == true || c.isInternalReplacement == true));
                                if (externalCoverage != null)
                                {
                                    if (option1MockEnrolledParticiapnt != null)
                                    {
                                        count++;
                                        emailAddressCount++;
                                        BuildMockParticipant(option1MockEnrolledParticiapnt, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                                    }
                                }
                            }
                        }
                    }
                    if (count < 5)
                    {
                        for (int mockCount = count; mockCount < 5; mockCount++)
                        {
                            count++;
                            emailAddressCount++;
                            BuildMockParticipant(option1MockEnrolledParticiapnt, cmsCase, pdrSoldClas, group, caseBrokers, count, emailAddressCount);
                        }
                    }
                }
                lstMLDIGroup.Add(group);
            }
            Log.TraceFormat("-GetGroups CaseId : {0} MLDIJson: {1} Time: {2}s", cmsCase.Id, JsonConvert.SerializeObject(lstMLDIGroup), (DateTime.Now - startTime).TotalSeconds);

            return lstMLDIGroup;
        }


        public bool GetCareerAgentIndicator(List<string> producerWritingCode)
        {
            Log.TraceFormat("+CaseCommonXmlBuilder.GetCareerAgentIndicator");

            bool IsCareerAgentIndicator = false;
            string WritingCode = String.Join(",", producerWritingCode);

            using (var sqlConnection = new SqlConnection(ProductLibraryDatabaseConnection))
            {
                SqlCommand command = sqlConnection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "[Extract].[USP_Get_Producer_CareerAgentIndicator]";
                command.Parameters.Add(new SqlParameter("ODSAgentContractIdentifier", WritingCode));

                sqlConnection.Open();

                SqlDataAdapter sda = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                sda.Fill(ds);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    IsCareerAgentIndicator = Convert.ToBoolean(ds.Tables[0].Rows[0][0]);
                }
            }
            Log.TraceFormat("-CaseCommonXmlBuilder.GetCareerAgentIndicator");
            return IsCareerAgentIndicator;
        }


        public List<string> GetCaseProducersAndTotalDiscount(EnrollmentParticipant enrolledParticipant, MLDIParticipant participant)
        {
            Log.TraceFormat("+CaseCommonXmlBuilder.GetCaseProducers casenumber={0}", enrolledParticipant?.Enrollment?.Case?.CaseNumber);
            List<string> producerWritingCodes = new List<string>();
            string StateApplicationSignedIn = null;
            var totalDiscount = 0;
            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                if (enrolledParticipant?.Enrollment?.Case?.CaseNumber == null)
                {
                    throw new Exception("Invalid case number");
                }

                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq()
                   .FirstOrDefault(c => c.PlanDesignRequestClass.Id == enrolledParticipant.Participant.PlanDesignRequestClass.Id && c.IsActive);

                if (pdrSoldClass != null)
                {
                    var soldPDRClassPlan = unitOfWork.Repository<PDRSoldClassPlan>().Linq().FirstOrDefault(c => c.PDRSoldClass.Id == pdrSoldClass.Id && c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);

                    if (soldPDRClassPlan != null)
                    {
                        var baseDiscount = soldPDRClassPlan.BaseDiscountType != null ? int.Parse(soldPDRClassPlan.BaseDiscountType.Code) : 0;
                        var demographicDiscount = soldPDRClassPlan.DemographicDiscountType != null ? int.Parse(soldPDRClassPlan.DemographicDiscountType.Code) : 0;
                        var employerPaidDiscountCode = (soldPDRClassPlan.EmployerPaidDiscountType != null) ? soldPDRClassPlan.EmployerPaidDiscountType.Code : string.Empty;
                        int employerPaidDiscount = 0;
                        int.TryParse(employerPaidDiscountCode, out employerPaidDiscount);                        
                        totalDiscount = baseDiscount + demographicDiscount + employerPaidDiscount;
                    }
                    else
                    {
                        totalDiscount = 0;
                    }
                }
                else
                {
                    totalDiscount = 0;
                }

                participant.totalDiscount = totalDiscount;  

                var caseUnderwritingRequest = unitOfWork.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id == enrolledParticipant.Enrollment.Case.Id);
                    if (caseUnderwritingRequest != null)
                    {
                        switch (caseUnderwritingRequest.SitusType)
                        {
                            case SitusTypeEnum.Corporate:
                            StateApplicationSignedIn = caseUnderwritingRequest.StateType != null ? caseUnderwritingRequest.StateType.ToString() : null;
                                break;
                            case SitusTypeEnum.Residence:
                            StateApplicationSignedIn = enrolledParticipant.Participant.HomeState != null ? enrolledParticipant.Participant.HomeState.ToString() : null;
                                break;
                            case SitusTypeEnum.Multi_State:
                                if (caseUnderwritingRequest.SitusMultiState1Type == enrolledParticipant.Participant.HomeState || caseUnderwritingRequest.SitusMultiState2Type == enrolledParticipant.Participant.HomeState || caseUnderwritingRequest.SitusMultiState3Type == enrolledParticipant.Participant.HomeState)
                                {
                                StateApplicationSignedIn = enrolledParticipant.Participant.HomeState != null ? enrolledParticipant.Participant.HomeState.ToString() : null;
                                }
                                else
                                {
                                StateApplicationSignedIn = caseUnderwritingRequest.StateType != null ? caseUnderwritingRequest.StateType.ToString() : null;
                                }
                                break;
                        }
                    }
                
                var state = unitOfWork.Repository<StateType>().Linq().FirstOrDefault(i => i.StateCode == StateApplicationSignedIn);
                              

                if (state == null)
                {
                    throw new Exception("Invalid state code");
                }

                producerWritingCodes = state.Id != (int)StateTypeEnum.UN ?
                    unitOfWork.Repository<CaseBrokerState>().Linq().Where(c => c.CaseBroker.Case.Id == enrolledParticipant.Enrollment.Case.Id && c.StateType == (StateTypeEnum)state.Id).Select(x => x.CaseBroker.BrokerWritingCode).Distinct().ToList() : null;
                    

                if (!producerWritingCodes.Any())
                {
                    throw new Exception("There are no producers for this case number and state code!");
                }
            }
            Log.TraceFormat("-CaseCommonXmlBuilder.GetCaseProducers casenumber={0}, stateCode={1}", enrolledParticipant?.Enrollment?.Case?.CaseNumber, StateApplicationSignedIn);
            return producerWritingCodes;
            
        }

        public T DeepClone<T>(T a)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, a);
                stream.Position = 0;
                return (T)formatter.Deserialize(stream);
            }
        }

        private decimal? CheckNullable(decimal? input)
        {
            if (input != null && input > 0)
            {
                return input;
            }
            else
            {
                return 0m;
            }

        }

        private decimal CheckNull(decimal? input)
        {
            if (input != null && input > 0)
            {

                decimal val = input ?? 0;
                return val;
            }
            else
            {
                return 0m;
            }

        }
        private List<MLDIAdditionalLtd> AdditionalLtdDatabuilder(EnrollmentParticipant enrollmentParticipant, PDRSoldClass pdrSoldClass, Case cmscase)
        {
            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var existingCoverage = unitOfWork.Repository<ExistingCoverage>().Linq().FirstOrDefault(c => c.Case.Id == cmscase.Id);

                ParticipantExistingPolicy participantExistingPolicy = new ParticipantExistingPolicy();
                decimal BenifitTotal = 0;
                int BerkshireIDICount = 0;
                bool ReplaceTest = false;
                int BIDCount = 0;
                var bridgelineAdditionalLTDCoverages = enrollmentParticipant.BridgelineAdditionalLTDCoverage.FirstOrDefault();
                var EnrollParty = enrollmentParticipant.Participant;
                List<MLDIAdditionalLtd> additionalLTDs = new List<MLDIAdditionalLtd>();
                MLDIAdditionalLtd additionalLTD = new MLDIAdditionalLtd();
                additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                additionalLTD.policySummary.riders = null;
                var existingPolicyCaseNumber = string.Empty;
                bool isBerhskireGSIPresent = false;
                bool isGroupLTDCoveragePresent = false;

                //  Allare Gurdian/ Berki and not checked 
                if (EnrollParty.IDIToBeReplaced1 == false && EnrollParty.IDIToBeReplaced2 == false && EnrollParty.IDIToBeReplaced3 == false
                    && EnrollParty.IDIToBeReplaced4 == false
                    && (EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
                    && (EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
                    && (EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
                    && (EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
                    )
                {
                    additionalLTD.carrierName = "Berkshire IDI";
                    additionalLTD.salaryMonthlyBenefit = (decimal)(EnrollParty.IDIBenefitAmount1 + EnrollParty.IDIBenefitAmount2 + EnrollParty.IDIBenefitAmount3 + EnrollParty.IDIBenefitAmount4);
                    additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;
                    additionalLTDs.Add(additionalLTD);

                    additionalLTD = new MLDIAdditionalLtd();
                    additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                    additionalLTD.policySummary.riders = null;
                    additionalLTD.carrierName = "Berkshire Combined";
                    additionalLTD.salaryMonthlyBenefit = (decimal)(EnrollParty.IDIBenefitAmount1 + EnrollParty.IDIBenefitAmount2 + EnrollParty.IDIBenefitAmount3 + EnrollParty.IDIBenefitAmount4);
                    additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;

                    additionalLTDs.Add(additionalLTD);
                }
                else
                {
                    if ((EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian) && (EnrollParty.IDIToBeReplaced1 == true))
                    {
                        ReplaceTest = true;
                    }
                    else if ((EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian) && (EnrollParty.IDIToBeReplaced2 == true))
                    {
                        ReplaceTest = true;
                    }
                    else if ((EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian) && (EnrollParty.IDIToBeReplaced3 == true))
                    {
                        ReplaceTest = true;
                    }
                    else if ((EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian) && (EnrollParty.IDIToBeReplaced4 == true))
                    {
                        ReplaceTest = true;
                    }

                    var participantExistingPolicies = EnrollParty.ParticipantExistingPolicies;
                    if (participantExistingPolicies.Any())
                    {
                        participantExistingPolicy = EnrollParty.ParticipantExistingPolicies.FirstOrDefault();
                    }


                    //IDIBenefitAmount1>0

                    var isBerkshireIDITagToBeShown = CheckForValueInFullyUnderwrittenIDI(participantExistingPolicy);
                    if (EnrollParty.IDIBenefitAmount1 != null && EnrollParty.IDIBenefitAmount1 > 0)
                    {
                        additionalLTD = new MLDIAdditionalLtd();
                        additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                        additionalLTD.policySummary.riders = null;
                        if (EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier1 == IDICoverageCarrierTypeEnum.Guardian)
                        {
                            if (isBerkshireIDITagToBeShown)
                            {
                                additionalLTD.carrierName = "Berkshire IDI";
                                additionalLTD.salaryMonthlyBenefit = participantExistingPolicy.FullyUnderwrittenIDI.Value;
                                BenifitTotal += additionalLTD.salaryMonthlyBenefit;

                                if (EnrollParty.IDIToBeReplaced1 != false)
                                {
                                    additionalLTD.isInternalReplacement = true;
                                    additionalLTD.amountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount1);
                                    additionalLTD.userSelectedReplacement = true;
                                }
                            }
                        }
                        else
                        {
                            isBerkshireIDITagToBeShown = true;
                            additionalLTD.carrierName = EnrollParty.IDICarrier1 != null ? EnrollParty.IDICarrier1.GetDescription() : "";
                            additionalLTD.salaryMonthlyBenefit = CheckNull(EnrollParty.IDIBenefitAmount1);

                            if (EnrollParty.IDIToBeReplaced1 != false)
                            {
                                additionalLTD.isExternalReplacement = true;
                                additionalLTD.amountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount1);
                                additionalLTD.userSelectedReplacement = true;
                                if (existingCoverage != null)
                                {
                                    additionalLTD.hexclForm = existingCoverage.EmployerOwned == false ? true : false;
                                }
                            }
                        }
                        if (isBerkshireIDITagToBeShown)
                        {
                            additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;
                            additionalLTD.coverageStatus = CoverageStatusRestriction.InForce;
                            additionalLTD.isTaxableIncome = false;
                            additionalLTD.salaryOnlyCoverage = false;

                            if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.FL)
                            {
                                if (EnrollParty.IDIToBeReplaced1 != null && EnrollParty.IDIToBeReplaced1 == true)
                                {
                                    additionalLTD.flReplacePolicyNumber = EnrollParty.IDIPolicyNumber1 != null ? EnrollParty.IDIPolicyNumber1 : "";

                                    if (existingCoverage != null)
                                    {
                                        var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 : "";
                                        var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 : "";
                                        var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity : "";
                                        var statusType = "";
                                        if (existingCoverage.FloridaReplacementCompanyStateType != null)
                                        {
                                            statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription();
                                        }

                                        var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
                                        additionalLTD.flReplaceCarrierAddress = Address1.ToString() + "," + Address2.ToString() + "," + city.ToString() + "," + statusType.ToString() + "," + Zipcode.ToString();
                                    }
                                }
                            }

                            if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
                            {
                                if (existingCoverage.ColoradoReplacementType != null)
                                {
                                    additionalLTD.coReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
                                    if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
                                    {
                                        additionalLTD.coReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
                                    }
                                }
                            }


                            if (EnrollParty.PremiumPayerId1 != null)
                            {
                                if (EnrollParty.PremiumPayerId1 == (int)PremiumPayerTypeEnum.Employer)
                                {

                                    additionalLTD.employerPaysPremiums = true;
                                    additionalLTD.policySummary.payorType = PayorTypeRestriction.Employer;
                                }
                                else
                                {
                                    additionalLTD.employerPaysPremiums = false;
                                    additionalLTD.policySummary.payorType = PayorTypeRestriction.Employee;
                                }
                            }
                            if (enrollmentParticipant.Participant.IDIToBeIgnore1 == true)
                            {
                                additionalLTD.IgnoreInCalculation = true;
                            }
                            if (additionalLTD.carrierName != "Berkshire IDI")
                            {
                                additionalLTDs.Add(additionalLTD);
                            }
                            else if (ReplaceTest)
                            {
                                additionalLTDs.Add(additionalLTD);
                            }
                            if (additionalLTD.carrierName == "Berkshire IDI" && ReplaceTest == false)
                            {
                                BIDCount = 1;
                            }
                        }
                    }
                    //End IDIBenefitAmount1

                    //IDIBenefitAmount2>0
                    isBerkshireIDITagToBeShown = CheckForValueInFullyUnderwrittenIDI(participantExistingPolicy);
                    if (EnrollParty.IDIBenefitAmount2 != null && EnrollParty.IDIBenefitAmount2 > 0)
                    {
                        additionalLTD = new MLDIAdditionalLtd();
                        additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                        additionalLTD.policySummary.riders = null;
                        if (EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier2 == IDICoverageCarrierTypeEnum.Guardian)
                        {
                            if (isBerkshireIDITagToBeShown)
                            {
                                additionalLTD.carrierName = "Berkshire IDI";
                                additionalLTD.salaryMonthlyBenefit = participantExistingPolicy.FullyUnderwrittenIDI.Value;
                                BenifitTotal += additionalLTD.salaryMonthlyBenefit;
                                if (EnrollParty.IDIToBeReplaced2 != false)
                                {
                                    additionalLTD.isInternalReplacement = true;
                                    additionalLTD.amountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount2);
                                    additionalLTD.userSelectedReplacement = true;
                                }
                                BerkshireIDICount += BerkshireIDICount++;
                            }
                        }
                        else
                        {
                            isBerkshireIDITagToBeShown = true;
                            additionalLTD.carrierName = EnrollParty.IDICarrier2 != null ? EnrollParty.IDICarrier2.GetDescription() : "";
                            additionalLTD.salaryMonthlyBenefit = CheckNull(EnrollParty.IDIBenefitAmount2);
                            if (EnrollParty.IDIToBeReplaced2 != false)
                            {
                                additionalLTD.isExternalReplacement = true;
                                additionalLTD.amountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount2);
                                additionalLTD.userSelectedReplacement = true;
                                if (existingCoverage != null)
                                {
                                    additionalLTD.hexclForm = existingCoverage.EmployerOwned == false ? true : false;
                                }
                            }
                        }

                        if (isBerkshireIDITagToBeShown)
                        {
                            additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;
                            additionalLTD.coverageStatus = CoverageStatusRestriction.InForce;
                            additionalLTD.isTaxableIncome = false;
                            additionalLTD.salaryOnlyCoverage = false;

                            if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.FL)
                            {
                                if (EnrollParty.IDIToBeReplaced2 != null && EnrollParty.IDIToBeReplaced2 == true)
                                {
                                    additionalLTD.flReplacePolicyNumber = EnrollParty.IDIPolicyNumber2 != null ? EnrollParty.IDIPolicyNumber2 : "";

                                    if (existingCoverage != null)
                                    {
                                        var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 : "";
                                        var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 : "";
                                        var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity : "";
                                        var statusType = "";
                                        if (existingCoverage.FloridaReplacementCompanyStateType != null)
                                        {
                                            statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription();
                                        }

                                        var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
                                        additionalLTD.flReplaceCarrierAddress = Address1.ToString() + "," + Address2.ToString() + "," + city.ToString() + "," + statusType.ToString() + "," + Zipcode.ToString();
                                    }
                                }
                            }

                            if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
                            {
                                if (existingCoverage.ColoradoReplacementType != null)
                                {
                                    additionalLTD.coReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
                                    if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
                                    {
                                        additionalLTD.coReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
                                    }
                                }
                            }

                            if (EnrollParty.PremiumPayerId2 != null)
                            {
                                if (EnrollParty.PremiumPayerId2 == (int)PremiumPayerTypeEnum.Employer)
                                {

                                    additionalLTD.employerPaysPremiums = true;
                                    additionalLTD.policySummary.payorType = PayorTypeRestriction.Employer;
                                }
                                else
                                {
                                    additionalLTD.employerPaysPremiums = false;
                                    additionalLTD.policySummary.payorType = PayorTypeRestriction.Employee;
                                }
                            }
                            if (enrollmentParticipant.Participant.IDIToBeIgnore2 == true)
                            {
                                additionalLTD.IgnoreInCalculation = true;
                            }

                            if (additionalLTD.carrierName != "Berkshire IDI")
                            {
                                additionalLTDs.Add(additionalLTD);
                            }
                            else if (ReplaceTest)
                            {
                                additionalLTDs.Add(additionalLTD);
                            }
                            if (additionalLTD.carrierName == "Berkshire IDI" && ReplaceTest == false)
                            {
                                BIDCount = 2;
                            }
                        }

                    }
                    //End IDIBenefitAmount2

                    //IDIBenefitAmount3
                    isBerkshireIDITagToBeShown = CheckForValueInFullyUnderwrittenIDI(participantExistingPolicy);
                    if (EnrollParty.IDIBenefitAmount3 != null && EnrollParty.IDIBenefitAmount3 > 0)
                    {

                        additionalLTD = new MLDIAdditionalLtd();
                        additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                        additionalLTD.policySummary.riders = null;
                        if (EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier3 == IDICoverageCarrierTypeEnum.Guardian)
                        {
                            if (isBerkshireIDITagToBeShown)
                            {
                                additionalLTD.carrierName = "Berkshire IDI";
                                additionalLTD.salaryMonthlyBenefit = participantExistingPolicy.FullyUnderwrittenIDI != null ? participantExistingPolicy.FullyUnderwrittenIDI.Value : 0;
                                BenifitTotal += additionalLTD.salaryMonthlyBenefit;
                                if (EnrollParty.IDIToBeReplaced3 != false)
                                {
                                    additionalLTD.isInternalReplacement = true;
                                    additionalLTD.amountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount3);
                                    additionalLTD.userSelectedReplacement = true;
                                }
                                BerkshireIDICount += BerkshireIDICount++;
                            }
                        }
                        else
                        {
                            isBerkshireIDITagToBeShown = true;
                            additionalLTD.carrierName = EnrollParty.IDICarrier3 != null ? EnrollParty.IDICarrier3.GetDescription() : "";
                            additionalLTD.salaryMonthlyBenefit = CheckNull(EnrollParty.IDIBenefitAmount3);
                            if (EnrollParty.IDIToBeReplaced3 != false)
                            {
                                additionalLTD.isExternalReplacement = true;
                                additionalLTD.amountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount3);
                                additionalLTD.userSelectedReplacement = true;
                                if (existingCoverage != null)
                                {
                                    additionalLTD.hexclForm = existingCoverage.EmployerOwned == false ? true : false;
                                }
                            }
                        }

                        if (isBerkshireIDITagToBeShown)
                        {
                            additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;
                            additionalLTD.coverageStatus = CoverageStatusRestriction.InForce;
                            additionalLTD.isTaxableIncome = false;
                            additionalLTD.salaryOnlyCoverage = false;

                            if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.FL)
                            {
                                if (EnrollParty.IDIToBeReplaced3 != null && EnrollParty.IDIToBeReplaced3 == true)
                                {
                                    additionalLTD.flReplacePolicyNumber = EnrollParty.IDIPolicyNumber3 != null ? EnrollParty.IDIPolicyNumber3 : "";

                                    if (existingCoverage != null)
                                    {
                                        var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 : "";
                                        var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 : "";
                                        var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity : "";
                                        var statusType = "";
                                        if (existingCoverage.FloridaReplacementCompanyStateType != null)
                                        {
                                            statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription();
                                        }

                                        var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
                                        additionalLTD.flReplaceCarrierAddress = Address1.ToString() + "," + Address2.ToString() + "," + city.ToString() + "," + statusType.ToString() + "," + Zipcode.ToString();
                                    }
                                }
                            }

                            if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
                            {
                                if (existingCoverage.ColoradoReplacementType != null)
                                {
                                    additionalLTD.coReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
                                    if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
                                    {
                                        additionalLTD.coReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
                                    }
                                }
                            }

                            if (EnrollParty.PremiumPayerId3 != null)
                            {
                                if (EnrollParty.PremiumPayerId3 == (int)PremiumPayerTypeEnum.Employer)
                                {

                                    additionalLTD.employerPaysPremiums = true;
                                    additionalLTD.policySummary.payorType = PayorTypeRestriction.Employer;
                                }
                                else
                                {
                                    additionalLTD.employerPaysPremiums = false;
                                    additionalLTD.policySummary.payorType = PayorTypeRestriction.Employee;
                                }
                            }
                            if (enrollmentParticipant.Participant.IDIToBeIgnore3 == true)
                            {
                                additionalLTD.IgnoreInCalculation = true;
                            }

                            if (additionalLTD.carrierName != "Berkshire IDI")
                            {
                                additionalLTDs.Add(additionalLTD);
                            }
                            else if (ReplaceTest)
                            {
                                additionalLTDs.Add(additionalLTD);
                            }
                            if (additionalLTD.carrierName == "Berkshire IDI" && ReplaceTest == false)
                            {
                                BIDCount = 3;
                            }
                        }
                    }
                    //End IDIBenefitAmount3

                    //IDIBenefitAmount4
                    isBerkshireIDITagToBeShown = CheckForValueInFullyUnderwrittenIDI(participantExistingPolicy);
                    if (EnrollParty.IDIBenefitAmount4 != null && EnrollParty.IDIBenefitAmount4 > 0)
                    {

                        additionalLTD = new MLDIAdditionalLtd();
                        additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                        additionalLTD.policySummary.riders = null;
                        if (EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Berkshire || EnrollParty.IDICarrier4 == IDICoverageCarrierTypeEnum.Guardian)
                        {
                            if (isBerkshireIDITagToBeShown)
                            {
                                additionalLTD.carrierName = "Berkshire IDI";
                                additionalLTD.salaryMonthlyBenefit = participantExistingPolicy.FullyUnderwrittenIDI != null ? participantExistingPolicy.FullyUnderwrittenIDI.Value : 0;
                                BenifitTotal += additionalLTD.salaryMonthlyBenefit;
                                if (EnrollParty.IDIToBeReplaced4 != false)
                                {
                                    additionalLTD.isInternalReplacement = true;
                                    additionalLTD.amountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount4);
                                    additionalLTD.userSelectedReplacement = true;
                                }
                                BerkshireIDICount += BerkshireIDICount++;
                            }
                        }
                        else
                        {
                            isBerkshireIDITagToBeShown = true;
                            additionalLTD.carrierName = EnrollParty.IDICarrier4 != null ? EnrollParty.IDICarrier4.GetDescription() : "";
                            additionalLTD.salaryMonthlyBenefit = CheckNull(EnrollParty.IDIBenefitAmount4);
                            if (EnrollParty.IDIToBeReplaced4 != false)
                            {
                                additionalLTD.isExternalReplacement = true;
                                additionalLTD.amountOfReplacement = CheckNullable(EnrollParty.IDIToBeReplacedAmount4);
                                additionalLTD.userSelectedReplacement = true;
                                if (existingCoverage != null)
                                {
                                    additionalLTD.hexclForm = existingCoverage.EmployerOwned == false ? true : false;
                                }
                            }
                        }
                        if (isBerkshireIDITagToBeShown)
                        {
                            additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;
                            additionalLTD.coverageStatus = CoverageStatusRestriction.InForce;
                            additionalLTD.isTaxableIncome = false;
                            additionalLTD.salaryOnlyCoverage = false;


                            if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.FL)
                            {
                                if (EnrollParty.IDIToBeReplaced4 != null && EnrollParty.IDIToBeReplaced4 == true)
                                {
                                    additionalLTD.flReplacePolicyNumber = EnrollParty.IDIPolicyNumber4 != null ? EnrollParty.IDIPolicyNumber4 : "";

                                    if (existingCoverage != null)
                                    {
                                        var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 : "";
                                        var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 : "";
                                        var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity : "";
                                        var statusType = "";
                                        if (existingCoverage.FloridaReplacementCompanyStateType != null)
                                        {
                                            statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription();
                                        }

                                        var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
                                        additionalLTD.flReplaceCarrierAddress = Address1.ToString() + "," + Address2.ToString() + "," + city.ToString() + "," + statusType.ToString() + "," + Zipcode.ToString();
                                    }
                                }
                            }

                            if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
                            {
                                if (existingCoverage.ColoradoReplacementType != null)
                                {
                                    additionalLTD.coReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
                                    if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
                                    {
                                        additionalLTD.coReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
                                    }
                                }
                            }

                            if (EnrollParty.PremiumPayerId4 != null)
                            {
                                if (EnrollParty.PremiumPayerId4 == (int)PremiumPayerTypeEnum.Employer)
                                {

                                    additionalLTD.employerPaysPremiums = true;
                                    additionalLTD.policySummary.payorType = PayorTypeRestriction.Employer;
                                }
                                else
                                {
                                    additionalLTD.employerPaysPremiums = false;
                                    additionalLTD.policySummary.payorType = PayorTypeRestriction.Employee;
                                }
                            }
                            if (enrollmentParticipant.Participant.IDIToBeIgnore4 == true)
                            {
                                additionalLTD.IgnoreInCalculation = true;
                            }

                            if (additionalLTD.carrierName != "Berkshire IDI")
                            {
                                additionalLTDs.Add(additionalLTD);
                            }
                            else if (ReplaceTest)
                            {
                                additionalLTDs.Add(additionalLTD);
                            }
                            if (additionalLTD.carrierName == "Berkshire IDI" && ReplaceTest == false)
                            {
                                BIDCount = 4;
                            }
                        }
                    }
                    //End IDIBenefitAmount4

                    if (BIDCount > 0)
                    {
                        additionalLTD = new MLDIAdditionalLtd();
                        additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                        additionalLTD.policySummary.riders = null;
                        additionalLTD.carrierName = "Berkshire IDI";
                        additionalLTD.salaryMonthlyBenefit = BenifitTotal;
                        additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;

                        additionalLTDs.Add(additionalLTD);
                    }

                    if (participantExistingPolicies.Any())
                    {
                        var ParticipantExistingoliciesdetail = unitOfWork.Repository<ParticipantExistingPolicyDetail>().Linq()
                            .FirstOrDefault(c => c.ParticipantExistingPolicy.Id == participantExistingPolicy.Id
                            && (c.CLOASPolicyStatus != null && c.CLOASPolicyStatus.ToLower() == "inforce")); //Later to see which policies we need to take - Anu

                        var terminatedPoliciesList = participantExistingPolicies.SelectMany(p => p.ParticipantExistingPolicyDetails).ToList().Where(c => c.IsTerminateAndReplace).ToList();

                        if (terminatedPoliciesList.Any())
                        {
                            foreach (ParticipantExistingPolicyDetail terminatedPolicyDetail in terminatedPoliciesList)
                            {
                                var GSIIDIBaseAMBamount = participantExistingPolicy.GSIIDIBaseAMB ?? 0 ;

                                additionalLTD = new MLDIAdditionalLtd();
                                existingPolicyCaseNumber = ParticipantExistingoliciesdetail.CaseNumber != null ? ParticipantExistingoliciesdetail.CaseNumber.Trim() ?? string.Empty : string.Empty;
                                isBerhskireGSIPresent = true;
                                additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                                additionalLTD.policySummary.riders = null;

                                if (terminatedPolicyDetail.Product.ToUpper() == "HAS PROVIDER PLUS")
                                {
                                    additionalLTD.carrierName = "Berkshire IDI";
                                }
                                else
                                {
                                    additionalLTD.carrierName = "Berkshire GSI";
                                }
                                additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;
                                additionalLTD.coverageStatus = CoverageStatusRestriction.InForce;

                                //additionalLTD.salaryMonthlyBenefit = GSIIDIBaseAMBamount;
                                //BenifitTotal += additionalLTD.salaryMonthlyBenefit;

                                if (ParticipantExistingoliciesdetail.PremiumPayer != null)
                                {
                                    if (ParticipantExistingoliciesdetail.PremiumPayer == PayorTypeRestriction.Employee.ToString())
                                    {
                                        //additionalLTD.employerPaysPremiums = false;
                                        additionalLTD.policySummary.payorType = PayorTypeRestriction.Employee;
                                    }
                                    else if (ParticipantExistingoliciesdetail.PremiumPayer == PayorTypeRestriction.Employer.ToString())
                                    {
                                        //    additionalLTD.employerPaysPremiums = true;
                                        additionalLTD.policySummary.payorType = PayorTypeRestriction.Employer;
                                    }
                                    if (EnrollParty.ListBillNumber != null)
                                    {
                                        if (EnrollParty.ListBillNumber.BillingMethodType != null)
                                        {
                                            if (EnrollParty.ListBillNumber.BillingMethodType == BillingMethodTypeEnum.DirectBill)
                                            {
                                                additionalLTD.policySummary.paymentMethod = PaymentMethodRestriction.DirectBill;
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.paymentMethod = PaymentMethodRestriction.PayrollDeducted;
                                            }

                                        }
                                    }
                                    additionalLTD.policySummary.premiumPaymentPeriod = !string.IsNullOrWhiteSpace(ParticipantExistingoliciesdetail.BillingModeTypeDescription) ? GetPolicySummaryPayPeriod(ParticipantExistingoliciesdetail.BillingModeTypeDescription) : null;

                                    additionalLTD.policySummary.premiumPerPaycheck = additionalLTD.policySummary.paymentMethod == PaymentMethodRestriction.PayrollDeducted ? CheckNull(ParticipantExistingoliciesdetail.ModalPremium) : 0.0M;

                                    if (additionalLTD.policySummary.premiumPaymentPeriod != null)
                                    {
                                        if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly)
                                        {
                                            additionalLTD.policySummary.premiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                        }
                                        else
                                        {
                                            additionalLTD.policySummary.premiumPerMonth = 0.0M;
                                        }

                                        if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly)
                                        {
                                            additionalLTD.policySummary.premiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                        }
                                        else
                                        {
                                            additionalLTD.policySummary.premiumPerQuarter = 0.0M;
                                        }

                                        if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual)
                                        {
                                            additionalLTD.policySummary.premiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                        }
                                        else
                                        {
                                            additionalLTD.policySummary.premiumPerSemiannual = 0.0M;
                                        }
                                    }

                                    additionalLTD.policySummary.premiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);

                                    if (additionalLTD.policySummary.payorType == PayorTypeRestriction.Employee)
                                    {
                                        if (additionalLTD.policySummary.paymentMethod == PaymentMethodRestriction.PayrollDeducted)
                                        {
                                            additionalLTD.policySummary.employeePremiumPerPaycheck = CheckNullable(ParticipantExistingoliciesdetail.ModalPremium);
                                        }
                                        else
                                        {
                                            additionalLTD.policySummary.employeePremiumPerPaycheck = 0.0M;
                                        }

                                        if (additionalLTD.policySummary.premiumPaymentPeriod != null)
                                        {
                                            if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly)
                                            {
                                                additionalLTD.policySummary.employeePremiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.employeePremiumPerMonth = 0.0M;
                                            }

                                            if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly)
                                            {
                                                additionalLTD.policySummary.employeePremiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.employeePremiumPerQuarter = 0.0M;
                                            }

                                            if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual)
                                            {
                                                additionalLTD.policySummary.employeePremiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.employeePremiumPerSemiannual = 0.0M;
                                            }
                                        }
                                        additionalLTD.policySummary.employeePremiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);
                                    }
                                }

                                if (ParticipantExistingoliciesdetail != null && ParticipantExistingoliciesdetail.ParticipantExistingPolicyRiders != null)
                                {
                                    var participantExistingPolicyRiders = ParticipantExistingoliciesdetail.ParticipantExistingPolicyRiders.
                                        Where(c => c.RiderValueDescription != "Not Include" && c.RiderValueDescription != "Not Included").ToList();

                                    if (participantExistingPolicyRiders != null)
                                    {
                                        additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                                        foreach (var raid in participantExistingPolicyRiders)
                                        {
                                            MLDIQualifiedRider rider = new MLDIQualifiedRider();
                                            rider.riderIdentifier = raid != null ? raid.RiderName : string.Empty;
                                            rider.monthlyBenefit = CheckNullable(raid.Amount);

                                            additionalLTD.policySummary.riders.Add(rider);
                                        }
                                    }
                                }
                                additionalLTD.isInternalReplacement = true;
                                additionalLTD.isExternalReplacement = false;

                                var monthlyIndemnity = terminatedPolicyDetail.MonthlyIndemnity != null ? terminatedPolicyDetail.MonthlyIndemnity.Value : 0.0m;
                                var ambAmount= terminatedPolicyDetail.AMBAmount != null ? terminatedPolicyDetail.AMBAmount.Value : 0.0m;
                                var totalMonthlyAmount = monthlyIndemnity + ambAmount;
                                additionalLTD.amountOfReplacement = totalMonthlyAmount;
                                additionalLTD.salaryMonthlyBenefit = totalMonthlyAmount;
                                BenifitTotal += totalMonthlyAmount;

                                additionalLTD.flReplacePolicyNumber = terminatedPolicyDetail.PolicyNumber;

                                if (existingCoverage != null)
                                {
                                    var Address1 = existingCoverage.FloridaReplacementCompanyAddressLine1 != null ? existingCoverage.FloridaReplacementCompanyAddressLine1 + ", " : "";
                                    var Address2 = existingCoverage.FloridaReplacementCompanyAddressLine2 != null ? existingCoverage.FloridaReplacementCompanyAddressLine2 + ", " : "";
                                    var city = existingCoverage.FloridaReplacementCompanyCity != null ? existingCoverage.FloridaReplacementCompanyCity + ", " : "";
                                    var statusType = "";
                                    if (existingCoverage.FloridaReplacementCompanyStateType != null)
                                    {
                                        statusType = existingCoverage.FloridaReplacementCompanyStateType.GetDescription() + ", ";
                                    }

                                    var Zipcode = existingCoverage.FloridaReplacementCompanyZipCode != null ? existingCoverage.FloridaReplacementCompanyZipCode : "";
                                    additionalLTD.flReplaceCarrierAddress = Address1.ToString() + Address2.ToString() + city.ToString() + statusType.ToString() + Zipcode.ToString();
                                }
                                if (EnrollParty.ContractState != null && EnrollParty.ContractState == StateTypeEnum.CO)
                                {
                                    if (existingCoverage.ColoradoReplacementType != null)
                                    {
                                        additionalLTD.coReplaceReason = existingCoverage.ColoradoReplacementType.GetDescription();
                                        if (existingCoverage.ColoradoReplacementType == ColoradoReplacementTypeEnum.Other)
                                        {
                                            additionalLTD.coReplaceComments = existingCoverage.ColoradoReplacementOther != null ? existingCoverage.ColoradoReplacementOther : "";
                                        }
                                    }
                                }
                                additionalLTD.hexclForm = false;

                                if (additionalLTD != null && !string.IsNullOrWhiteSpace(additionalLTD.carrierName))
                                {
                                    additionalLTDs.Add(additionalLTD);
                                }
                            }
                        }

                        if (ParticipantExistingoliciesdetail != null)
                        {
                            var GSIIDIBaseAMBamount = participantExistingPolicy.GSIIDIBaseAMB ?? 0;
                            if (GSIIDIBaseAMBamount > 0)
                            {
                                additionalLTD = new MLDIAdditionalLtd();
                                existingPolicyCaseNumber = ParticipantExistingoliciesdetail.CaseNumber != null ? ParticipantExistingoliciesdetail.CaseNumber.Trim() ?? string.Empty : string.Empty;
                                isBerhskireGSIPresent = true;
                                additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                                additionalLTD.policySummary.riders = null;

                                bool hasAmbPolicy = EnrollParty.IsAMBIncreaseIndicator == true ? true : false;

                                if (hasAmbPolicy)
                                {
                                    additionalLTD.policySummary.IsCompactState = ParticipantExistingoliciesdetail.IsCompactState != null ? ParticipantExistingoliciesdetail.IsCompactState.Value : false;
                                }

                                if (ParticipantExistingoliciesdetail.Product?.ToUpper() == "HAS PROVIDER PLUS")
                                {
                                    additionalLTD.carrierName = "Berkshire IDI";
                                }
                                else
                                {
                                    additionalLTD.carrierName = "Berkshire GSI";
                                }

                                additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;
                                additionalLTD.coverageStatus = CoverageStatusRestriction.InForce;

                                additionalLTD.salaryMonthlyBenefit = GSIIDIBaseAMBamount;
                                BenifitTotal += additionalLTD.salaryMonthlyBenefit;

                                additionalLTD.flReplacePolicyNumber = ParticipantExistingoliciesdetail.PolicyNumber;

                                if (ParticipantExistingoliciesdetail.PremiumPayer != null)
                                {
                                    if (ParticipantExistingoliciesdetail.PremiumPayer == PayorTypeRestriction.Employee.ToString())
                                    {
                                        //additionalLTD.employerPaysPremiums = false;
                                        additionalLTD.policySummary.payorType = PayorTypeRestriction.Employee;
                                    }
                                    else if (ParticipantExistingoliciesdetail.PremiumPayer == PayorTypeRestriction.Employer.ToString())
                                    {
                                        //    additionalLTD.employerPaysPremiums = true;
                                        additionalLTD.policySummary.payorType = PayorTypeRestriction.Employer;
                                    }
                                    if (EnrollParty.ListBillNumber != null)
                                    {
                                        if (EnrollParty.ListBillNumber.BillingMethodType != null)
                                        {
                                            if (EnrollParty.ListBillNumber.BillingMethodType == BillingMethodTypeEnum.DirectBill)
                                            {
                                                additionalLTD.policySummary.paymentMethod = PaymentMethodRestriction.DirectBill;
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.paymentMethod = PaymentMethodRestriction.PayrollDeducted;
                                            }

                                        }
                                    }
                                    additionalLTD.policySummary.premiumPaymentPeriod = !string.IsNullOrWhiteSpace(ParticipantExistingoliciesdetail.BillingModeTypeDescription) ? GetPolicySummaryPayPeriod(ParticipantExistingoliciesdetail.BillingModeTypeDescription) : null;

                                    additionalLTD.policySummary.premiumPerPaycheck = additionalLTD.policySummary.paymentMethod == PaymentMethodRestriction.PayrollDeducted ? CheckNull(ParticipantExistingoliciesdetail.ModalPremium) : 0.0M;

                                    if (additionalLTD.policySummary.premiumPaymentPeriod != null)
                                    {
                                        if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly)
                                        {
                                            additionalLTD.policySummary.premiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                        }
                                        else
                                        {
                                            additionalLTD.policySummary.premiumPerMonth = 0.0M;
                                        }

                                        if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly)
                                        {
                                            additionalLTD.policySummary.premiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                        }
                                        else
                                        {
                                            additionalLTD.policySummary.premiumPerQuarter = 0.0M;
                                        }

                                        if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual)
                                        {
                                            additionalLTD.policySummary.premiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                        }
                                        else
                                        {
                                            additionalLTD.policySummary.premiumPerSemiannual = 0.0M;
                                        }
                                    }

                                    additionalLTD.policySummary.premiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);

                                    /**/
                                    var Premiumpayertype1 = pdrSoldClass.PDRSoldClassPlan.FirstOrDefault();
                                    MLDIQualifiedOffer MldiQualifiedOffer = new MLDIQualifiedOffer();

                                    foreach (var EPOP in enrollmentParticipant.EnrollmentParticipantOptionPlans)
                                    {
                                        if (EPOP != null)
                                        {
                                            MldiQualifiedOffer.cmsStandardOfferCode = EPOP.StandardOptionCodeNonSmoker != null ? EPOP.StandardOptionCodeNonSmoker : "";
                                        }
                                        MldiQualifiedOffer.type = QualifiedOfferTypeRestriction.IDI;

                                        string s11 = EPOP.StandardOptionCodeNonSmoker != null ? EPOP.StandardOptionCodeNonSmoker : "";
                                        string s12 = "VGSI";
                                        string s13 = "IDI Option 1";
                                        bool b1 = s11.Contains(s12);
                                        bool c1 = s11.Contains(s13);

                                        if (b1 && c1)
                                        {
                                            MldiQualifiedOffer.payorType = PayorTypeRestriction.Employer;
                                        }
                                        else if (b1 == true && c1 != true)
                                        {
                                            MldiQualifiedOffer.payorType = PayorTypeRestriction.Employee;
                                        }
                                        else
                                        {
                                            if (Premiumpayertype1 != null)
                                            {
                                                MldiQualifiedOffer.payorType = GetPayortype(Premiumpayertype1);
                                            }

                                        }

                                    }
                                    if (MldiQualifiedOffer.payorType == PayorTypeRestriction.Employer || MldiQualifiedOffer.payorType == PayorTypeRestriction.Shared)
                                    {
                                        if (additionalLTD.policySummary.paymentMethod == PaymentMethodRestriction.PayrollDeducted)
                                        {
                                            additionalLTD.policySummary.employerPremiumPerPaycheck = CheckNullable(ParticipantExistingoliciesdetail.ModalPremium);
                                        }
                                        else
                                        {
                                            additionalLTD.policySummary.employerPremiumPerPaycheck = 0.0M;
                                        }

                                        if (additionalLTD.policySummary.premiumPaymentPeriod != null)
                                        {
                                            if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly)
                                            {
                                                additionalLTD.policySummary.employerPremiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.employerPremiumPerMonth = 0.0M;
                                            }

                                            if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly)
                                            {
                                                additionalLTD.policySummary.employerPremiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.employerPremiumPerQuarter = 0.0M;
                                            }

                                            if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual)
                                            {
                                                additionalLTD.policySummary.employerPremiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.employerPremiumPerSemiannual = 0.0M;
                                            }
                                        }
                                        additionalLTD.policySummary.employerPremiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);
                                    }

                                    if (MldiQualifiedOffer.payorType == PayorTypeRestriction.Employee || MldiQualifiedOffer.payorType == PayorTypeRestriction.Shared)
                                    {
                                        if (additionalLTD.policySummary.paymentMethod == PaymentMethodRestriction.PayrollDeducted)
                                        {
                                            additionalLTD.policySummary.employeePremiumPerPaycheck = CheckNullable(ParticipantExistingoliciesdetail.ModalPremium);
                                        }
                                        else
                                        {
                                            additionalLTD.policySummary.employeePremiumPerPaycheck = 0.0M;
                                        }

                                        if (additionalLTD.policySummary.premiumPaymentPeriod != null)
                                        {
                                            if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Monthly)
                                            {
                                                additionalLTD.policySummary.employeePremiumPerMonth = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.employeePremiumPerMonth = 0.0M;
                                            }

                                            if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Quarterly)
                                            {
                                                additionalLTD.policySummary.employeePremiumPerQuarter = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.employeePremiumPerQuarter = 0.0M;
                                            }

                                            if (additionalLTD.policySummary.premiumPaymentPeriod == PremiumPaymentPeriodRestriction.Semiannual)
                                            {
                                                additionalLTD.policySummary.employeePremiumPerSemiannual = CheckNull(ParticipantExistingoliciesdetail.ModalPremium);
                                            }
                                            else
                                            {
                                                additionalLTD.policySummary.employeePremiumPerSemiannual = 0.0M;
                                            }
                                        }
                                        additionalLTD.policySummary.employeePremiumPerAnnual = CheckNull(ParticipantExistingoliciesdetail.AnnualizedPremium);
                                    }

                                }

                                if (ParticipantExistingoliciesdetail != null && ParticipantExistingoliciesdetail.ParticipantExistingPolicyRiders != null)
                                {
                                    var participantExistingPolicyRiders = ParticipantExistingoliciesdetail.ParticipantExistingPolicyRiders.
                                        Where(c => c.RiderValueDescription != "Not Include" && c.RiderValueDescription != "Not Included").ToList();

                                    if (participantExistingPolicyRiders != null)
                                    {
                                        additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                                        foreach (var raid in participantExistingPolicyRiders)
                                        {
                                            MLDIQualifiedRider rider = new MLDIQualifiedRider();
                                            rider.riderIdentifier = raid != null ? raid.RiderName : string.Empty;
                                            rider.monthlyBenefit = CheckNullable(raid.Amount);

                                            additionalLTD.policySummary.riders.Add(rider);
                                        }
                                    }
                                }
                                if (additionalLTD != null && !string.IsNullOrWhiteSpace(additionalLTD.carrierName) && additionalLTD.salaryMonthlyBenefit > 0)
                                {
                                    additionalLTDs.Add(additionalLTD);
                                }
                            }
                        }
                    }


                    if (BenifitTotal > 0)
                    {
                        var berkshireIDILTD = additionalLTDs.Any() ? additionalLTDs.Where(c => c.carrierName == "Berkshire IDI") : null;
                        if (berkshireIDILTD.Any())
                        {
                            additionalLTD = new MLDIAdditionalLtd();
                            additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                            additionalLTD.policySummary.riders = null;
                            additionalLTD.carrierName = "Berkshire Combined";
                            additionalLTD.salaryMonthlyBenefit = BenifitTotal;
                            additionalLTD.coverageCategory = CoverageCategoryRestriction.Individual;

                            additionalLTDs.Add(additionalLTD);
                        }
                    }

                }

                //LTD GROUP Node Creation

                if (enrollmentParticipant.Participant.LTDCalculatedAmount > 0)

                {
                    var soldPdrLtdCoverage = pdrSoldClass.PDRSoldClassLTDCoverage.FirstOrDefault();
                    if (soldPdrLtdCoverage != null)
                    {
                        additionalLTD = new MLDIAdditionalLtd();
                        additionalLTD.policySummary.riders = new List<MLDIQualifiedRider>();
                        additionalLTD.policySummary.riders = null;
                        isGroupLTDCoveragePresent = true;
                        additionalLTD.carrierName = soldPdrLtdCoverage.CarrierText != null ? soldPdrLtdCoverage.CarrierText : "";//enrollmentParticipant.Participant.IDICarrier1Description != null ? enrollmentParticipant.Participant.IDICarrier1Description : "";
                        additionalLTD.coverageCategory = CoverageCategoryRestriction.Group;
                        additionalLTD.coverageStatus = CoverageStatusRestriction.InForce;
                        additionalLTD.salaryMonthlyBenefit = CheckNull(enrollmentParticipant.Participant.LTDCalculatedAmount);
                        //(decimal)enrollmentParticipant.Participant.LTDCalculatedAmount : 00.00m;


                        additionalLTD.maxMonthlyBenefit = soldPdrLtdCoverage.GroupLTDCapAmount;
                        if (((ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum)soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id) == (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid))
                        {
                            if (soldPdrLtdCoverage.TypeOfPayType != null && (TaxabilityTypeEnum)soldPdrLtdCoverage.TypeOfPayType == (TaxabilityTypeEnum.Taxable))
                            {
                                additionalLTD.isTaxableIncome = true;
                            }
                        }

                        additionalLTD.salaryOnlyCoverage = soldPdrLtdCoverage.GroupLTDCoveredEarningsType == CoveredEarningsTypeEnum.BaseSalaryOnly ? true : false;
                        additionalLTD.groupLtdPercentage = soldPdrLtdCoverage.GroupLTDReplacementPercentage;
                        additionalLTD.employerPaysPremiums = soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid
                                                             || soldPdrLtdCoverage.PremiumAndTaxpayerLiabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable ?
                            true : false;
                        additionalLTD.isInternalReplacement = null;
                        additionalLTD.isExternalReplacement = null;
                        //additionalLTD
                        additionalLTD.policySummary.sharedPremiumEmployerPercentage = additionalLTD.policySummary.sharedPremiumEmployerPercentage == null ?
                                                                                        0 : additionalLTD.policySummary.sharedPremiumEmployerPercentage;

                        additionalLTDs.Add(additionalLTD);
                    }
                }

                if (additionalLTDs.Any() && additionalLTDs.Count == 2)
                {
                    if (isBerhskireGSIPresent && isGroupLTDCoveragePresent && cmscase.CaseNumber != existingPolicyCaseNumber)
                    {
                        additionalLTDs.Reverse();
                    }
                }
                else if (additionalLTDs.Any() && additionalLTDs.Count > 2)
                {
                    additionalLTDs = additionalLTDs.OrderBy(i => i.carrierName).ToList();
                }
                return additionalLTDs;
            }
        }

        private PayorTypeRestriction GetPayortype(PDRSoldClassPlan pdrSoldClassPlans)
        {

            PayorTypeRestriction Payorenumtype = new PayorTypeRestriction();
            if (pdrSoldClassPlans.PremiumPayerAndTaxabilityType.Id == Convert.ToInt16(ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid))
            {
                Payorenumtype = PayorTypeRestriction.Employer;
            }
            else if (pdrSoldClassPlans.PremiumPayerAndTaxabilityType.Id == Convert.ToInt16(ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare))
            {
                Payorenumtype = PayorTypeRestriction.Shared;
            }
            else if (pdrSoldClassPlans.PremiumPayerAndTaxabilityType.Id == Convert.ToInt16(ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable))
            {
                Payorenumtype = PayorTypeRestriction.Employee;
            }
            else
            {
                Payorenumtype = PayorTypeRestriction.Employee;
            }


            return Payorenumtype;
        }

        private PremiumPaymentPeriodRestriction? GetPayPeriod(ListBillNumber listbilnumbers)
        {
            if (listbilnumbers.BillingModeType == null) return null;


            PremiumPaymentPeriodRestriction PayPeriod = new PremiumPaymentPeriodRestriction();
            if (listbilnumbers.BillingModeType == BillingModeTypeEnum.Annual)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Annually;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.Semi_Annual)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Semiannual;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.Quarterly)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Quarterly;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.Monthly)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Monthly;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.MonthlyGOM)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Monthly;
            }
            else if (listbilnumbers.BillingModeType == BillingModeTypeEnum.DirectBillMonthly)
            {
                PayPeriod = PremiumPaymentPeriodRestriction.Monthly;
            }


            return PayPeriod;

        }

        private PremiumPaymentPeriodRestriction? GetPolicySummaryPayPeriod(string billingModeTypeDescription)
        {
            PremiumPaymentPeriodRestriction policySummaryPayPeriod = new PremiumPaymentPeriodRestriction();
            if (billingModeTypeDescription == "Half Yearly")
            {
                policySummaryPayPeriod = PremiumPaymentPeriodRestriction.Semiannual;
            }
            else if (billingModeTypeDescription == "Monthly")
            {
                policySummaryPayPeriod = PremiumPaymentPeriodRestriction.Monthly;
            }
            else if (billingModeTypeDescription == "Quarterly")
            {
                policySummaryPayPeriod = PremiumPaymentPeriodRestriction.Quarterly;
            }
            else if (billingModeTypeDescription == "Yearly")
            {
                policySummaryPayPeriod = PremiumPaymentPeriodRestriction.Annually;
            }

            return policySummaryPayPeriod;
        }

        private List<MLDIQualifiedOffer> GetQualifiedOffers(EnrollmentParticipant enrolledParticipant, PDRSoldClass pdrSoldClas, Case cmsCase, List<MLDIAdditionalLtd> currentLTDs)
        {
            var isCompactState = cmsCase.CaseUnderwritingRequests.FirstOrDefault().IsCompactState;

            var gsiLTDs = currentLTDs?.Where(i => i.carrierName == "Berkshire GSI");
            bool isVgsiPlan = pdrSoldClas.PDRSoldClassPlan.Any(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

            List<MLDIQualifiedOffer> listMldiQualifiedOffers = new List<MLDIQualifiedOffer>();
            {

                foreach (var EPOP in enrolledParticipant.EnrollmentParticipantOptionPlans)
                {

                    int setcounti1 = 0; int setcountj1 = 0;
                    int setcounti2 = 0; int setcountj2 = 0;
                    int setcounti3 = 0; int setcountj3 = 0;
                    int setcounti4 = 0; int setcountj4 = 0;
                    int setcounti11 = 0; int setcountj11 = 0;
                    int setcounti12 = 0; int setcountj12 = 0;
                    int setcounti13 = 0; int setcountj13 = 0;
                    int setcounti14 = 0; int setcountj14 = 0;
                    int setcountsevrsmk = 0; int setcountsevrnon = 0;
                    int setcounti114 = 0; int setcountj114 = 0;
                    //int setcountcatB12 = 0; int setcountcatB22 = 0;
                    //int setcountcatE12 = 0; int setcountcatE22 = 0;

                    //-NOnSmokers QualifiedOffer

                    bool option1Eligible = EPOP.EnrollmentParticipant.Participant.EnrollmentOption1IsEligible != null ? (bool)EPOP.EnrollmentParticipant.Participant.EnrollmentOption1IsEligible : false;
                    bool option2Eligible = EPOP.EnrollmentParticipant.Participant.EnrollmentOption2IsEligible != null ? (bool)EPOP.EnrollmentParticipant.Participant.EnrollmentOption2IsEligible : false;
                    bool option3Eligible = EPOP.EnrollmentParticipant.Participant.EnrollmentOption3IsEligible != null ? (bool)EPOP.EnrollmentParticipant.Participant.EnrollmentOption3IsEligible : false;

                    if (!option1Eligible)
                    {
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 1"))
                        {
                            continue;
                        }
                    }
                    if (!option2Eligible)
                    {
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 2"))
                        {
                            continue;
                        }
                    }
                    if (!option3Eligible)
                    {
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 3"))
                        {
                            continue;
                        }
                    }

                    var Premiumpayertype1 = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault();

                    bool IsCostShare = Premiumpayertype1.PremiumPayerAndTaxabilityType != null ? (Premiumpayertype1.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare) : false;

                    MLDIQualifiedOffer MldiQualifiedOffer = new MLDIQualifiedOffer();
                    {
                        if (EPOP != null)
                        {
                            MldiQualifiedOffer.cmsStandardOfferCode = EPOP.StandardOptionCodeNonSmoker != null ? EPOP.StandardOptionCodeNonSmoker : "";
                        }
                        MldiQualifiedOffer.type = QualifiedOfferTypeRestriction.IDI;

                        string s11 = EPOP.StandardOptionCodeNonSmoker != null ? EPOP.StandardOptionCodeNonSmoker : "";
                        string s12 = "VGSI";
                        string s13 = "IDI Option 1";
                        bool b1 = s11.Contains(s12);
                        bool c1 = s11.Contains(s13);

                        if (b1 && c1)
                        {
                            MldiQualifiedOffer.payorType = PayorTypeRestriction.Employer;
                        }
                        else if (b1 == true && c1 != true)
                        {
                            MldiQualifiedOffer.payorType = PayorTypeRestriction.Employee;
                        }
                        else
                        {
                            if (Premiumpayertype1 != null)
                            {
                                MldiQualifiedOffer.payorType = GetPayortype(Premiumpayertype1);
                            }

                        }



                        if (Premiumpayertype1 != null)
                        {
                            // MldiQualifiedOffer.payorType = GetPayortype(Premiumpayertype1);

                            if (enrolledParticipant.Participant.ListBillNumber != null && enrolledParticipant.Participant.ListBillNumber.BillingMethodType != null)
                            {
                                if (enrolledParticipant.Participant.ListBillNumber.BillingMethodType == BillingMethodTypeEnum.DirectBill)
                                {
                                    MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.DirectBill;
                                }
                                else
                                {
                                    MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.PayrollDeducted;
                                }
                            }

                            if ((MldiQualifiedOffer.payorType == PayorTypeRestriction.Employer) || (MldiQualifiedOffer.payorType == PayorTypeRestriction.Employee))
                            {
                                //   MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.PayrollDeducted;

                                if (enrolledParticipant.Participant.ListBillNumber != null)
                                {
                                    MldiQualifiedOffer.premiumPaymentPeriod = GetPayPeriod(enrolledParticipant.Participant.ListBillNumber);
                                }
                            }
                            else
                            {
                                // MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.DirectBill;
                                if (enrolledParticipant.Participant.ListBillNumber != null)
                                {
                                    MldiQualifiedOffer.premiumPaymentPeriod = GetPayPeriod(enrolledParticipant.Participant.ListBillNumber);
                                }
                                // cmsCase.ListBillNumbers.FirstOrDefault().BillingMethodType != null ? (PaymentMethodRestriction)cmsCase.ListBillNumbers.FirstOrDefault().BillingMethodType : PaymentMethodRestriction.PayrollDeducted;
                            }
                        }
                        MldiQualifiedOffer.premiumPerPaycheck = CheckNull(EPOP.NonSmokerPremiumAmountPaycheck);

                        MldiQualifiedOffer.premiumPerMonth = CheckNull(EPOP.NonSmokerPremiumAmountMonthly);

                        MldiQualifiedOffer.premiumPerQuarter = CheckNull(EPOP.NonSmokerPremiumAmountQuarterly);

                        MldiQualifiedOffer.premiumPerSemiannual = CheckNull(EPOP.NonSmokerPremiumAmountSemiannually);

                        MldiQualifiedOffer.premiumPerAnnual = CheckNullable(EPOP.NonSmokerPremiumAmountAnnually);

                        MldiQualifiedOffer.totalMonthlyBenefit = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.TotalMonthlyBenefitAmount) : 0;


                        MldiQualifiedOffer.policyFee = (enrolledParticipant.Participant.IsPushtoNewProviderChoicePolicyIndicator == true ||
                                enrolledParticipant.Participant.IsAMBIncreaseIndicator == true) ? "15.00" : "30.00";


                        if (MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.totalMonthlyBenefit = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                    && ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ||
                                                                         enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.TotalMonthlyBenefitAmount) : 0;
                            MldiQualifiedOffer.policyFee = (enrolledParticipant.Participant.IsBuyUpPushtoNewProviderChoicePolicyIndicator == true ||
                                enrolledParticipant.Participant.IsBuyUpAMBIncreaseIndicator == true) ? "15.00" : "30.00";
                        }


                        switch (MldiQualifiedOffer.payorType)
                        {
                            case PayorTypeRestriction.Shared:
                                MldiQualifiedOffer.employeePremiumPerPaycheck = CheckNullable(EPOP.NonSmokerEmployeePremiumAmountPaycheck);
                                MldiQualifiedOffer.employeePremiumPerMonth = CheckNullable(EPOP.NonSmokerEmployeePremiumPerMonth);
                                MldiQualifiedOffer.employeePremiumPerQuarter = CheckNullable(EPOP.NonSmokerEmployeePremiumQuarterly);
                                MldiQualifiedOffer.employeePremiumPerSemiannual = CheckNullable(EPOP.NonSmokerEmployeePremiumSemiannually);
                                MldiQualifiedOffer.employeePremiumPerAnnual = CheckNullable(EPOP.NonSmokerEmployeePremiumAnnually);

                                MldiQualifiedOffer.employerPremiumPerPayCheck = CheckNullable(EPOP.NonSmokerEmployerPremiumAmountPaycheck);
                                MldiQualifiedOffer.employerPremiumPerMonth = CheckNullable(EPOP.NonSmokerEmployerPremiumPerMonth);
                                MldiQualifiedOffer.employerPremiumPerQuarter = CheckNullable(EPOP.NonSmokerEmployerPremiumQuarterly);
                                MldiQualifiedOffer.employerPremiumPerSemiAnnual = CheckNullable(EPOP.NonSmokerEmployerPremiumSemiannually);
                                MldiQualifiedOffer.employerPremiumPerAnnual = CheckNullable(EPOP.NonSmokerEmployerPremiumAnnually);
                                break;
                            case PayorTypeRestriction.Employer:
                                MldiQualifiedOffer.employeePremiumPerPaycheck = 0;
                                MldiQualifiedOffer.employeePremiumPerMonth = 0;
                                MldiQualifiedOffer.employeePremiumPerQuarter = 0;
                                MldiQualifiedOffer.employeePremiumPerSemiannual = 0;
                                MldiQualifiedOffer.employeePremiumPerAnnual = 0;

                                MldiQualifiedOffer.employerPremiumPerPayCheck = 0M;
                                MldiQualifiedOffer.employerPremiumPerMonth = CheckNullable(EPOP.NonSmokerEmployerPremiumPerMonth);
                                MldiQualifiedOffer.employerPremiumPerQuarter = CheckNullable(EPOP.NonSmokerEmployerPremiumQuarterly);
                                MldiQualifiedOffer.employerPremiumPerSemiAnnual = CheckNullable(EPOP.NonSmokerEmployerPremiumSemiannually);
                                MldiQualifiedOffer.employerPremiumPerAnnual = CheckNullable(EPOP.NonSmokerEmployerPremiumAnnually);
                                break;
                            default:
                                MldiQualifiedOffer.employeePremiumPerPaycheck = CheckNullable(EPOP.NonSmokerPremiumAmountPaycheck);
                                MldiQualifiedOffer.employeePremiumPerMonth = CheckNullable(EPOP.NonSmokerPremiumAmountMonthly);
                                MldiQualifiedOffer.employeePremiumPerQuarter = CheckNullable(EPOP.NonSmokerPremiumAmountQuarterly);
                                MldiQualifiedOffer.employeePremiumPerSemiannual = CheckNullable(EPOP.NonSmokerPremiumAmountSemiannually);
                                MldiQualifiedOffer.employeePremiumPerAnnual = CheckNullable(EPOP.NonSmokerPremiumAmountAnnually);

                                MldiQualifiedOffer.employerPremiumPerPayCheck = 0M;
                                MldiQualifiedOffer.employerPremiumPerMonth = 0M;
                                MldiQualifiedOffer.employerPremiumPerQuarter = 0M;
                                MldiQualifiedOffer.employerPremiumPerSemiAnnual = 0M;
                                MldiQualifiedOffer.employerPremiumPerAnnual = 0M;
                                break;
                        }

                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 1") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 1"))
                        {
                            MldiQualifiedOffer.xmlOrderPosition = 1;
                        }
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 2") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 2"))
                        {
                            MldiQualifiedOffer.xmlOrderPosition = 3;
                        }
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 3") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.xmlOrderPosition = 5;
                        }

                        MldiQualifiedOffer.isProViderChoice = true;

                        if (EPOP.BenefitPeriod != null)
                        {
                            if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                            {

                                MldiQualifiedOffer.benefitPeriodAge = 65;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                            {
                                MldiQualifiedOffer.benefitPeriodAge = 67;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                            {
                                MldiQualifiedOffer.benefitPeriodAge = 70;
                            }

                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                            {
                                MldiQualifiedOffer.benefitPeriodYears = 2;

                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                            {
                                MldiQualifiedOffer.benefitPeriodYears = 5;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                            {
                                MldiQualifiedOffer.benefitPeriodYears = 10;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                            {
                                MldiQualifiedOffer.benefitPeriodYears = 1;
                            }

                        }

                        if (EPOP.EliminationPeriod != null)
                        {
                            if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                            {
                                MldiQualifiedOffer.eliminationPeriodDays = 180;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                            {
                                MldiQualifiedOffer.eliminationPeriodDays = 360;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                            {
                                MldiQualifiedOffer.eliminationPeriodDays = 720;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                            {
                                MldiQualifiedOffer.eliminationPeriodDays = 90;
                            }

                        }
                        var EMPPP = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault();
                        if (EMPPP != null)
                        {
                            MldiQualifiedOffer.sharedPremiumEmployerPercentage = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault().EmployerPaidPremium != null ? pdrSoldClas.PDRSoldClassPlan.FirstOrDefault().EmployerPaidPremium : 0M;
                        }
                        MldiQualifiedOffer.isTobaccoRates = false;
                        MldiQualifiedOffer.discountPercentage = EPOP.Discount ?? 0;
                        MldiQualifiedOffer.baseMonthlyBenefit = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.BenefitAmountBaseMonthly) : 0;
                        MldiQualifiedOffer.baseMonthlyPremium = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.NonSmokerPremiumAmountBaseMonthly) : 0;
                        MldiQualifiedOffer.isProViderChoice = true;
                        MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.ParticipantCategoryCodeType) : 0;
                        MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? enrolledParticipant.Participant.ParticipantCategoryCodeType.GetDescription() : string.Empty;
                        // NON-smoker Rider

                        if (MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null ? enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType.GetDescription() : string.Empty;

                            if (MldiQualifiedOffer.OptionClassType == string.Empty)
                            {
                                MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? enrolledParticipant.Participant.ParticipantCategoryCodeType.GetDescription() : string.Empty;
                            }

                            MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType) : 0;

                            if (MldiQualifiedOffer.OptionClassTypeOrder == 0)
                            {
                                MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.ParticipantCategoryCodeType) : 0;
                            }

                            MldiQualifiedOffer.baseMonthlyBenefit = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                   && (enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB || enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.BenefitAmountBaseMonthly) : 0;
                            MldiQualifiedOffer.baseMonthlyPremium = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                   && (enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB || enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.NonSmokerPremiumAmountBaseMonthly) : 0;
                        }

                        MldiQualifiedOffer.riders = new List<MLDIQualifiedRider>();

                        MLDIQualifiedRider MldiQualifiedRider = null;
                        PreExistingConditionLimitTypeEnum peclt;
                        MentalSubstanceLimitationEnum MentalSubstance;


                        MldiQualifiedRider = new MLDIQualifiedRider();

                        peclt = EPOP.PreExistingConditionLimitType;
                        MentalSubstance = EPOP.MentalSubstanceLimitationType;
                        if (peclt == PreExistingConditionLimitTypeEnum.None)
                        {
                            if (setcounti1 < 1)
                            {

                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "NOPREX";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcounti1++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._3_12)
                        {
                            if (setcounti2 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "PREX-3";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcounti2++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._6_12)
                        {
                            if (setcounti3 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "PREX-6";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcounti3++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._12_12)
                        {
                            if (setcounti4 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "PREX-12";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcounti4++;
                            }
                        }

                        if (MentalSubstance == MentalSubstanceLimitationEnum._6Month)
                        {
                            if (setcounti11 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ExtMental-6";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcounti11++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._24Month
                            || MentalSubstance == MentalSubstanceLimitationEnum._24MonthsGSI)
                        {
                            if (setcounti12 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ExtMental-24";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcounti12++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._Nolimitation)
                        {
                            if (setcounti13 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ExtMental";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcounti13++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._12Month)
                        {
                            if (setcounti14 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ExtMental-12";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcounti14++;
                            }

                        }

                        var pexconltDisablity = EPOP.DefinitionOfDisabilityType;
                        if (setcounti114 < 1)
                        {

                            if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "EnhancedMedSpec";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "TOOSR";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TrueOwnOccupation ||
                                     pexconltDisablity == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "TOOR";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation ||
                                pexconltDisablity == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupationME)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "EOOR";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "TOOR-2YRMod";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "MOOR-2YrMod";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            setcounti114++;
                        }

                        foreach (var EPOPR in EPOP.Riders)
                        {
                            if (EPOPR.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)
                            {
                                CreateAMBRiders(EPOPR, enrolledParticipant, pdrSoldClas, MldiQualifiedOffer, false, EPOP, isVgsiPlan);
                            }

                            if (isCompactState == false)
                            {

                                if (EPOPR.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                {


                                    if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")))
                                    {
                                        MldiQualifiedRider = new MLDIQualifiedRider();
                                        MldiQualifiedRider.riderIdentifier = "CAT16b";
                                        MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                        MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                        if (EPOP.BenefitPeriod != null)
                                        {

                                            if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                            {

                                                MldiQualifiedRider.benefitPeriodAge = 65;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                            {
                                                MldiQualifiedRider.benefitPeriodAge = 67;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                            {
                                                MldiQualifiedRider.benefitPeriodAge = 70;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 2;

                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 5;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 10;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                            {
                                                MldiQualifiedOffer.benefitPeriodYears = 1;
                                            }
                                        }

                                        if (EPOP.EliminationPeriod != null)
                                        {

                                            if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 180;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 360;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 720;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 90;
                                            }
                                        }
                                        MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                    }
                                }

                            }
                            else
                            {
                                if (setcountsevrnon < 1)
                                {
                                    if (isCompactState == true)
                                    {
                                        if (EPOPR.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                        {

                                            MldiQualifiedRider = new MLDIQualifiedRider();
                                            MldiQualifiedRider.riderIdentifier = "SevereDisability";
                                            MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                            MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                            MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                            if (EPOP.BenefitPeriod != null)
                                            {

                                                if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                                {

                                                    MldiQualifiedRider.benefitPeriodAge = 65;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                                {
                                                    MldiQualifiedRider.benefitPeriodAge = 67;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                                {
                                                    MldiQualifiedRider.benefitPeriodAge = 70;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                                {
                                                    MldiQualifiedRider.benefitPeriodYears = 2;

                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                                {
                                                    MldiQualifiedRider.benefitPeriodYears = 5;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                                {
                                                    MldiQualifiedRider.benefitPeriodYears = 10;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                                {
                                                    MldiQualifiedOffer.benefitPeriodYears = 1;
                                                }

                                            }

                                            if (EPOP.EliminationPeriod != null)
                                            {

                                                if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                                {
                                                    MldiQualifiedRider.eliminationPeriod = 180;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                                {
                                                    MldiQualifiedRider.eliminationPeriod = 360;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                                {
                                                    MldiQualifiedRider.eliminationPeriod = 720;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                                {
                                                    MldiQualifiedRider.eliminationPeriod = 90;
                                                }
                                            }
                                            MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                            setcountsevrnon++;
                                        }

                                    }
                                }

                            }
                            //Cat16B end

                            if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")) ||
                                    (exstreamRequestDocumentType == "EnrollmentKit" && IsCostShare))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRider();
                                    MldiQualifiedRider.riderIdentifier = "CAT16e";
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);

                                    if (EPOP.BenefitPeriod != null)
                                    {
                                        if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                        {
                                            MldiQualifiedRider.benefitPeriodAge = 65;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                        {
                                            MldiQualifiedRider.benefitPeriodAge = 67;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                        {
                                            MldiQualifiedRider.benefitPeriodAge = 70;
                                        }

                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 2;

                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 5;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 10;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                        {
                                            MldiQualifiedOffer.benefitPeriodYears = 1;
                                        }

                                    }

                                    if (EPOP.EliminationPeriod != null)
                                    {

                                        if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 180;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 360;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 720;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 90;
                                        }

                                    }
                                    MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitAmountMonthly != null && EPOPR.BenefitAmountMonthly > 0)
                            {

                                if (EPOPR.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit)
                                {
                                    if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")))
                                    {
                                        MldiQualifiedRider = new MLDIQualifiedRider();
                                        MldiQualifiedRider.riderIdentifier = "RPP";
                                        MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                        MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                        MldiQualifiedRider.benefitPeriodAge = 65;

                                        if (EPOPR.EliminationPeriodType != null)
                                        {
                                            if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 180;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 360;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 720;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 90;
                                            }
                                        }
                                        MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                    }
                                }
                                else if (EPOPR.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit && exstreamRequestDocumentType == "EnrollmentKit")
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRider();
                                    MldiQualifiedRider.riderIdentifier = "RPP";
                                    if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                    {
                                        MldiQualifiedRider.monthlyPremium = 0;
                                        MldiQualifiedRider.annualPremium = 0;
                                    }
                                    else
                                    {
                                        MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                    }
                                    MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                }
                            }
                            if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedResidualDisability)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "EnhancedRes";
                                MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }

                            else if (EPOPR.BenefitType == BenefitTypeEnum.BasicResidualDisability)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "BasicRes";
                                MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ShortTermRes";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "COLA-6";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving3PercentCompound)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "COLA-3";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving4YearDelayed)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "COLA-4Yr";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }


                            if (EPOPR.BenefitType == BenefitTypeEnum.UnemploymentPremiumWaiver)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "UnempWaiver";
                                MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRider();
                                    MldiQualifiedRider.riderIdentifier = "SIS";
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                    MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                }
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.LumpSumIndemnityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "LSDB";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.BasicPartialDisabilityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "BasicPart";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "EnhancedPart";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }


                            if (EPOPR.BenefitType == BenefitTypeEnum.StudentLoanProtection)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRider();
                                    MldiQualifiedRider.riderIdentifier = "SLP";
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);

                                    if (gsiLTDs.Count() > 0)
                                    {
                                        var slpRiderBenefitAmt = gsiLTDs?.FirstOrDefault()?.policySummary?.riders?.FirstOrDefault(i => i.riderIdentifier.Contains("SLP"))?.monthlyBenefit;
                                        MldiQualifiedRider.monthlyBenefit = CheckNullable(slpRiderBenefitAmt);
                                    }
                                    else
                                    {
                                        MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                    }

                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                    //MldiQualifiedRider.benefitPeriodAge = EPOPR.BenefitPeriodType != null ? (uint)(BenefitPeriodTypeEnum)EPOPR.BenefitPeriodType.Value : 0;
                                    if (EPOPR.BenefitPeriodType != null)
                                    {
                                        if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                                        {

                                            MldiQualifiedRider.benefitPeriodAge = 65;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                                        {
                                            MldiQualifiedRider.benefitPeriodAge = 67;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                                        {
                                            MldiQualifiedRider.benefitPeriodAge = 70;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 2;

                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 5;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 10;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 15;
                                        }
                                        else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                        {
                                            MldiQualifiedOffer.benefitPeriodYears = 1;
                                        }

                                    }
                                    //MldiQualifiedRider.eliminationPeriod = EPOPR.EliminationPeriodType != null ? (uint)(EliminationPeriodTypeEnum)EPOPR.EliminationPeriodType : 00;
                                    if (EPOPR.EliminationPeriodType != null)
                                    {

                                        if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 180;
                                        }
                                        else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 360;
                                        }
                                        else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 720;
                                        }
                                        else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 90;
                                        }

                                    }

                                    MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.SupplementalBenefitTermRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "SBT";
                                MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountMonthly);

                                if (gsiLTDs.Count() > 0)
                                {
                                    var sbtRiderBenefitAmt = gsiLTDs?.FirstOrDefault()?.policySummary?.riders?.FirstOrDefault(i => i.riderIdentifier.Contains("SBT"))?.monthlyBenefit;
                                    MldiQualifiedRider.monthlyBenefit = CheckNullable(sbtRiderBenefitAmt);
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                }

                                MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.NonSmokerPremiumAmountAnnual);
                                // MldiQualifiedRider.benefitPeriodAge = EPOPR.BenefitPeriodType != null ? (uint)(BenefitPeriodTypeEnum)EPOPR.BenefitPeriodType.Value : 0;
                                if (EPOPR.BenefitPeriodType != null)
                                {
                                    if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                                    {

                                        MldiQualifiedRider.benefitPeriodAge = 65;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                                    {
                                        MldiQualifiedRider.benefitPeriodAge = 67;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                                    {
                                        MldiQualifiedRider.benefitPeriodAge = 70;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                    {
                                        MldiQualifiedRider.benefitPeriodYears = 2;

                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                    {
                                        MldiQualifiedRider.benefitPeriodYears = 5;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                                    {
                                        MldiQualifiedRider.benefitPeriodYears = 10;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                                    {
                                        MldiQualifiedRider.benefitPeriodYears = 15;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                    {
                                        MldiQualifiedOffer.benefitPeriodYears = 1;
                                    }

                                }
                                //MldiQualifiedRider.eliminationPeriod = EPOPR.EliminationPeriodType != null ? (uint)(EliminationPeriodTypeEnum)EPOPR.EliminationPeriodType : 00;
                                if (EPOPR.EliminationPeriodType != null)
                                {

                                    if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                    {
                                        MldiQualifiedRider.eliminationPeriod = 180;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                    {
                                        MldiQualifiedRider.eliminationPeriod = 360;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                    {
                                        MldiQualifiedRider.eliminationPeriod = 720;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                    {
                                        MldiQualifiedRider.eliminationPeriod = 90;
                                    }

                                }


                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                        }
                    }


                    //-Smokers QualifiedOffer



                    listMldiQualifiedOffers.Add(MldiQualifiedOffer);

                    MldiQualifiedOffer = new MLDIQualifiedOffer();
                    {

                        MldiQualifiedOffer.cmsStandardOfferCode = EPOP.StandardOptionCodeSmoker != null ? EPOP.StandardOptionCodeSmoker : "";
                        MldiQualifiedOffer.type = QualifiedOfferTypeRestriction.IDI;
                        var Premiumpayertype = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault();

                        string s1 = EPOP.StandardOptionCodeSmoker != null ? EPOP.StandardOptionCodeSmoker : "";
                        string s2 = "VGSI";
                        string s3 = "IDI Option 1";
                        bool b = s1.Contains(s2);
                        bool c = s1.Contains(s3);

                        if (b && c)
                        {
                            MldiQualifiedOffer.payorType = PayorTypeRestriction.Employer;
                        }
                        else if (b == true && c != true)
                        {
                            MldiQualifiedOffer.payorType = PayorTypeRestriction.Employee;
                        }
                        else
                        {
                            if (Premiumpayertype1 != null)
                            {
                                MldiQualifiedOffer.payorType = GetPayortype(Premiumpayertype1);
                            }

                        }

                        if (Premiumpayertype != null)
                        {
                            // MldiQualifiedOffer.payorType = GetPayortype(Premiumpayertype1);

                            if ((MldiQualifiedOffer.payorType == PayorTypeRestriction.Employer) || (MldiQualifiedOffer.payorType == PayorTypeRestriction.Employee))
                            {
                                // MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.PayrollDeducted;
                                if (enrolledParticipant.Participant.ListBillNumber != null)
                                {
                                    MldiQualifiedOffer.premiumPaymentPeriod = GetPayPeriod(enrolledParticipant.Participant.ListBillNumber);

                                }

                            }
                            else
                            {
                                // MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.DirectBill;
                                if (enrolledParticipant.Participant.ListBillNumber != null)
                                {
                                    MldiQualifiedOffer.premiumPaymentPeriod = GetPayPeriod(enrolledParticipant.Participant.ListBillNumber);
                                }
                            }

                            if (enrolledParticipant.Participant.ListBillNumber != null && enrolledParticipant.Participant.ListBillNumber.BillingMethodType != null)
                            {
                                if (enrolledParticipant.Participant.ListBillNumber.BillingMethodType == BillingMethodTypeEnum.DirectBill)
                                {
                                    MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.DirectBill;
                                }
                                else
                                {
                                    MldiQualifiedOffer.paymentMethod = PaymentMethodRestriction.PayrollDeducted;
                                }
                            }
                        }

                        MldiQualifiedOffer.premiumPerPaycheck = CheckNull(EPOP.SmokerPremiumAmountPaycheck);
                        MldiQualifiedOffer.premiumPerMonth = CheckNull(EPOP.SmokerPremiumAmountMonthly);
                        MldiQualifiedOffer.premiumPerQuarter = CheckNullable(EPOP.SmokerPremiumAmountQuarterly);
                        MldiQualifiedOffer.premiumPerSemiannual = CheckNullable(EPOP.SmokerPremiumAmountSemiannually);
                        MldiQualifiedOffer.premiumPerAnnual = CheckNullable(EPOP.SmokerPremiumAmountAnnually);
                        MldiQualifiedOffer.totalMonthlyBenefit = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.TotalMonthlyBenefitAmount) : 0;

                        MldiQualifiedOffer.policyFee = (enrolledParticipant.Participant.IsPushtoNewProviderChoicePolicyIndicator == true ||
                            enrolledParticipant.Participant.IsAMBIncreaseIndicator == true) ? "15.00" : "30.00";


                        if (MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.totalMonthlyBenefit = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                    && ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ||
                                                                         enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.TotalMonthlyBenefitAmount) : 0;


                            MldiQualifiedOffer.policyFee = (enrolledParticipant.Participant.IsBuyUpPushtoNewProviderChoicePolicyIndicator == true ||
                                enrolledParticipant.Participant.IsBuyUpAMBIncreaseIndicator == true) ? "15.00" : "30.00";
                        }

                        switch (MldiQualifiedOffer.payorType)
                        {
                            case PayorTypeRestriction.Shared:
                                MldiQualifiedOffer.employeePremiumPerPaycheck = CheckNullable(EPOP.SmokerEmployeePremiumAmountPaycheck);
                                MldiQualifiedOffer.employeePremiumPerMonth = CheckNull(EPOP.SmokerEmployeePremiumPerMonth);
                                MldiQualifiedOffer.employeePremiumPerQuarter = CheckNull(EPOP.SmokerEmployeePremiumQuarterly);
                                MldiQualifiedOffer.employeePremiumPerSemiannual = CheckNull(EPOP.SmokerEmployeePremiumSemiannually);
                                MldiQualifiedOffer.employeePremiumPerAnnual = CheckNull(EPOP.SmokerEmployeePremiumAnnually);

                                MldiQualifiedOffer.employerPremiumPerPayCheck = CheckNullable(EPOP.SmokerEmployerPremiumAmountPaycheck);
                                MldiQualifiedOffer.employerPremiumPerMonth = CheckNullable(EPOP.SmokerEmployerPremiumPerMonth);
                                MldiQualifiedOffer.employerPremiumPerQuarter = CheckNullable(EPOP.SmokerEmployerPremiumQuarterly);
                                MldiQualifiedOffer.employerPremiumPerSemiAnnual = CheckNullable(EPOP.SmokerEmployerPremiumSemiannually);
                                MldiQualifiedOffer.employerPremiumPerAnnual = CheckNullable(EPOP.SmokerEmployerPremiumAnnually);
                                break;
                            case PayorTypeRestriction.Employer:
                                MldiQualifiedOffer.employeePremiumPerPaycheck = 0;
                                MldiQualifiedOffer.employeePremiumPerMonth = 0;
                                MldiQualifiedOffer.employeePremiumPerQuarter = 0;
                                MldiQualifiedOffer.employeePremiumPerSemiannual = 0;
                                MldiQualifiedOffer.employeePremiumPerAnnual = 0;

                                MldiQualifiedOffer.employerPremiumPerPayCheck = 0M;
                                MldiQualifiedOffer.employerPremiumPerMonth = CheckNullable(EPOP.SmokerEmployerPremiumPerMonth);
                                MldiQualifiedOffer.employerPremiumPerQuarter = CheckNullable(EPOP.SmokerEmployerPremiumQuarterly);
                                MldiQualifiedOffer.employerPremiumPerSemiAnnual = CheckNullable(EPOP.SmokerEmployerPremiumSemiannually);
                                MldiQualifiedOffer.employerPremiumPerAnnual = CheckNullable(EPOP.SmokerEmployerPremiumAnnually);
                                break;
                            default:
                                MldiQualifiedOffer.employeePremiumPerPaycheck = CheckNull(EPOP.SmokerPremiumAmountPaycheck);
                                MldiQualifiedOffer.employeePremiumPerMonth = CheckNull(EPOP.SmokerPremiumAmountMonthly);
                                MldiQualifiedOffer.employeePremiumPerQuarter = CheckNull(EPOP.SmokerPremiumAmountQuarterly);
                                MldiQualifiedOffer.employeePremiumPerSemiannual = CheckNull(EPOP.SmokerPremiumAmountSemiannually);
                                MldiQualifiedOffer.employeePremiumPerAnnual = CheckNull(EPOP.SmokerPremiumAmountAnnually);

                                MldiQualifiedOffer.employerPremiumPerPayCheck = 0M;
                                MldiQualifiedOffer.employerPremiumPerMonth = 0M;
                                MldiQualifiedOffer.employerPremiumPerQuarter = 0M;
                                MldiQualifiedOffer.employerPremiumPerSemiAnnual = 0M;
                                MldiQualifiedOffer.employerPremiumPerAnnual = 0M;
                                break;
                        }



                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 1") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 1"))
                        {
                            MldiQualifiedOffer.xmlOrderPosition = 2;
                        }
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 2") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 2"))
                        {
                            MldiQualifiedOffer.xmlOrderPosition = 4;
                        }
                        if (EPOP.StandardOptionCodeNonSmoker.Contains("Option 3") ||
                            EPOP.StandardOptionCodeSmoker.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.xmlOrderPosition = 6;
                        }


                        MldiQualifiedOffer.isProViderChoice = true;


                        if (EPOP.BenefitPeriod != null)
                        {
                            if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                            {

                                MldiQualifiedOffer.benefitPeriodAge = 65;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                            {
                                MldiQualifiedOffer.benefitPeriodAge = 67;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                            {
                                MldiQualifiedOffer.benefitPeriodAge = 70;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                            {
                                MldiQualifiedOffer.benefitPeriodYears = 2;

                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                            {
                                MldiQualifiedOffer.benefitPeriodYears = 5;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                            {
                                MldiQualifiedOffer.benefitPeriodYears = 10;
                            }
                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                            {
                                MldiQualifiedOffer.benefitPeriodYears = 1;
                            }

                        }

                        if (EPOP.EliminationPeriod != null)
                        {

                            if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                            {
                                MldiQualifiedOffer.eliminationPeriodDays = 180;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                            {
                                MldiQualifiedOffer.eliminationPeriodDays = 360;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                            {
                                MldiQualifiedOffer.eliminationPeriodDays = 720;
                            }
                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                            {
                                MldiQualifiedOffer.eliminationPeriodDays = 90;
                            }

                        }
                        MldiQualifiedOffer.sharedPremiumEmployerPercentage = pdrSoldClas.PDRSoldClassPlan.FirstOrDefault().EmployerPaidPremium != null ? pdrSoldClas.PDRSoldClassPlan.FirstOrDefault().EmployerPaidPremium : 0M;

                        MldiQualifiedOffer.isTobaccoRates = true;
                        MldiQualifiedOffer.discountPercentage = CheckNullable(EPOP.Discount);
                        MldiQualifiedOffer.baseMonthlyBenefit = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.BenefitAmountBaseMonthly) : 0;
                        MldiQualifiedOffer.baseMonthlyPremium = (enrolledParticipant.Participant.ParticipantCategoryCodeType != null && enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB) ? CheckNull(EPOP.SmokerPremiumAmountBaseMonthly) : 0;
                        MldiQualifiedOffer.isProViderChoice = true;
                        MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? enrolledParticipant.Participant.ParticipantCategoryCodeType.GetDescription() : string.Empty;
                        MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.ParticipantCategoryCodeType) : 0;

                        if (MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 3"))
                        {
                            MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null ? enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType.GetDescription() : string.Empty;

                            if (MldiQualifiedOffer.OptionClassType == string.Empty)
                            {
                                MldiQualifiedOffer.OptionClassType = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? enrolledParticipant.Participant.ParticipantCategoryCodeType.GetDescription() : string.Empty;
                            }

                            MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType) : 0;

                            if (MldiQualifiedOffer.OptionClassTypeOrder == 0)
                            {
                                MldiQualifiedOffer.OptionClassTypeOrder = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? GetOptionClassTypeOrder(enrolledParticipant.Participant.ParticipantCategoryCodeType) : 0;
                            }

                            MldiQualifiedOffer.baseMonthlyBenefit = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                   && (enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB || enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.BenefitAmountBaseMonthly) : 0;


                            MldiQualifiedOffer.baseMonthlyPremium = ((enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != null || enrolledParticipant.Participant.ParticipantCategoryCodeType != null)
                                                                   && (enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB || enrolledParticipant.Participant.ParticipantCategoryCodeType != ParticipantCategoryCodeTypeEnum.AMB)) ? CheckNull(EPOP.SmokerPremiumAmountBaseMonthly) : 0;
                        }
                        MldiQualifiedOffer.riders = new List<MLDIQualifiedRider>();
                        MLDIQualifiedRider MldiQualifiedRider = null;
                        PreExistingConditionLimitTypeEnum peclt;
                        MentalSubstanceLimitationEnum MentalSubstance;
                        MldiQualifiedRider = new MLDIQualifiedRider();

                        peclt = EPOP.PreExistingConditionLimitType;
                        MentalSubstance = EPOP.MentalSubstanceLimitationType;

                        if (peclt == PreExistingConditionLimitTypeEnum.None)
                        {
                            if (setcountj1 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "NOPREX";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcountj1++;
                            }
                        }

                        else if (peclt == PreExistingConditionLimitTypeEnum._3_12)
                        {
                            if (setcountj2 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "PREX-3";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcountj2++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._6_12)
                        {
                            if (setcountj3 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "PREX-6";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcountj3++;
                            }
                        }
                        else if (peclt == PreExistingConditionLimitTypeEnum._12_12)
                        {
                            if (setcountj4 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "PREX-12";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcountj4++;
                            }
                        }



                        if (MentalSubstance == MentalSubstanceLimitationEnum._6Month)
                        {
                            if (setcountj11 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ExtMental-6";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcountj11++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._24Month
                             || MentalSubstance == MentalSubstanceLimitationEnum._24MonthsGSI)
                        {
                            if (setcountj12 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ExtMental-24";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcountj12++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._Nolimitation)
                        {
                            if (setcountj13 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ExtMental";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcountj13++;
                            }
                        }
                        else if (MentalSubstance == MentalSubstanceLimitationEnum._12Month)
                        {
                            if (setcountj14 < 1)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ExtMental-12";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                setcountj14++;
                            }
                        }

                        var pexconltDisablity = EPOP.DefinitionOfDisabilityType;

                        if (setcountj114 < 1)
                        {

                            if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "EnhancedMedSpec";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "TOOSR";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TrueOwnOccupation ||
                                     pexconltDisablity == DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "TOOR";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation ||
                                pexconltDisablity == DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupationME)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "EOOR";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "TOOR-2YRMod";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (pexconltDisablity == DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "MOOR-2YrMod";
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            setcountj114++;
                        }

                        foreach (var EPOPR in EPOP.Riders)
                        {
                            if (EPOPR.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit)
                            {
                                if (MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 2") || MldiQualifiedOffer.cmsStandardOfferCode.Contains("Option 3"))
                                {
                                    CreateAMBRiders(EPOPR, enrolledParticipant, pdrSoldClas, MldiQualifiedOffer, true, EPOP, isVgsiPlan);
                                }

                            }

                            if (isCompactState == false)
                            {

                                if (EPOPR.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                {
                                    if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")))
                                    {
                                        MldiQualifiedRider = new MLDIQualifiedRider();
                                        MldiQualifiedRider.riderIdentifier = "CAT16b";
                                        MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);// != null ? EPOPR.SmokerPremiumAmountMonthly : 00.00m;
                                        MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);// != null ? EPOPR.BenefitAmountMonthly : 00.00m;
                                        MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual); // != null ? EPOPR.SmokerPremiumAmountAnnual : 00.00m;
                                        if (EPOP.BenefitPeriod != null)
                                        {
                                            if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                            {
                                                MldiQualifiedRider.benefitPeriodAge = 65;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                            {
                                                MldiQualifiedRider.benefitPeriodAge = 67;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                            {
                                                MldiQualifiedRider.benefitPeriodAge = 70;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 2;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 5;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 10;
                                            }
                                            else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                            {
                                                MldiQualifiedOffer.benefitPeriodYears = 1;
                                            }
                                        }

                                        if (EPOP.EliminationPeriod != null)
                                        {
                                            if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 180;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 360;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 720;
                                            }
                                            else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 90;
                                            }
                                        }
                                        MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                    }
                                }

                            }
                            else
                            {

                                if (setcountsevrsmk < 1)
                                {
                                    if (isCompactState == true)
                                    {
                                        if (EPOPR.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                        {
                                            MldiQualifiedRider = new MLDIQualifiedRider();
                                            MldiQualifiedRider.riderIdentifier = "SevereDisability";
                                            MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                            MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                            MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                            MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                            if (EPOP.BenefitPeriod != null)
                                            {

                                                if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                                {

                                                    MldiQualifiedRider.benefitPeriodAge = 65;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                                {
                                                    MldiQualifiedRider.benefitPeriodAge = 67;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                                {
                                                    MldiQualifiedRider.benefitPeriodAge = 70;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                                {
                                                    MldiQualifiedRider.benefitPeriodYears = 2;

                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                                {
                                                    MldiQualifiedRider.benefitPeriodYears = 5;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                                {
                                                    MldiQualifiedRider.benefitPeriodYears = 10;
                                                }
                                                else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                                {
                                                    MldiQualifiedOffer.benefitPeriodYears = 1;
                                                }
                                            }

                                            if (EPOP.EliminationPeriod != null)
                                            {

                                                if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                                {
                                                    MldiQualifiedRider.eliminationPeriod = 180;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                                {
                                                    MldiQualifiedRider.eliminationPeriod = 360;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                                {
                                                    MldiQualifiedRider.eliminationPeriod = 720;
                                                }
                                                else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                                {
                                                    MldiQualifiedRider.eliminationPeriod = 90;
                                                }
                                            }
                                            MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                            setcountsevrsmk++;
                                        }

                                    }
                                }
                            }//Cat16B end



                            if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")) ||
                                    (exstreamRequestDocumentType == "EnrollmentKit" && IsCostShare))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRider();
                                    MldiQualifiedRider.riderIdentifier = "CAT16e";
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                    if (EPOP.BenefitPeriod != null)
                                    {
                                        if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                                        {
                                            MldiQualifiedRider.benefitPeriodAge = 65;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                                        {
                                            MldiQualifiedRider.benefitPeriodAge = 67;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                                        {
                                            MldiQualifiedRider.benefitPeriodAge = 70;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 2;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 5;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                                        {
                                            MldiQualifiedRider.benefitPeriodYears = 10;
                                        }
                                        else if (EPOP.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                        {
                                            MldiQualifiedOffer.benefitPeriodYears = 1;
                                        }
                                    }

                                    if (EPOP.EliminationPeriod != null)
                                    {
                                        if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._180)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 180;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._360)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 360;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._720)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 720;
                                        }
                                        else if (EPOP.EliminationPeriod == EliminationPeriodTypeEnum._090)
                                        {
                                            MldiQualifiedRider.eliminationPeriod = 90;
                                        }
                                    }
                                    MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitAmountMonthly != null && EPOPR.BenefitAmountMonthly > 0)
                            {

                                if (EPOPR.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit)
                                {
                                    if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")))
                                    {
                                        MldiQualifiedRider = new MLDIQualifiedRider();
                                        MldiQualifiedRider.riderIdentifier = "RPP";
                                        MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                        MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                        MldiQualifiedRider.benefitPeriodAge = 65;

                                        if (EPOPR.EliminationPeriodType != null)
                                        {
                                            if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 180;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 360;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 720;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 90;
                                            }
                                        }
                                        MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                    }
                                }
                                else if (EPOPR.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit && exstreamRequestDocumentType == "EnrollmentKit")
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRider();
                                    MldiQualifiedRider.riderIdentifier = "RPP";
                                    if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                    {
                                        MldiQualifiedRider.monthlyPremium = 0;
                                        MldiQualifiedRider.annualPremium = 0;
                                    }
                                    else
                                    {
                                        MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                    }
                                    MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedResidualDisability)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "EnhancedRes";
                                MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }

                            else if (EPOPR.BenefitType == BenefitTypeEnum.BasicResidualDisability)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "BasicRes";
                                MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "ShortTermRes";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }



                            if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "COLA-6";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving3PercentCompound)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "COLA-3";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.CostOfLiving4YearDelayed)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "COLA-4Yr";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.UnemploymentPremiumWaiver)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "UnempWaiver";
                                MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRider();
                                    MldiQualifiedRider.riderIdentifier = "SIS";
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                    MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                }
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.LumpSumIndemnityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "LSDB";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.BasicPartialDisabilityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "BasicPart";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }
                            else if (EPOPR.BenefitType == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "EnhancedPart";
                                if (EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit))
                                {
                                    MldiQualifiedRider.monthlyPremium = 0;
                                    MldiQualifiedRider.annualPremium = 0;
                                }
                                else
                                {
                                    MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                    MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                }
                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }



                            if (EPOPR.BenefitType == BenefitTypeEnum.StudentLoanProtection)
                            {
                                if (!(EPOP.Riders.Any(r => r.BenefitType == BenefitTypeEnum.AdditionalMonthlyBenefit) && (exstreamRequestDocumentType == "BridgelineXml" || exstreamRequestDocumentType == "BenefitPremium")))
                                {
                                    MldiQualifiedRider = new MLDIQualifiedRider();
                                    {
                                        MldiQualifiedRider.riderIdentifier = "SLP";
                                        MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                        MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                        MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                        // MldiQualifiedRider.benefitPeriodAge = EPOPR.BenefitPeriodType != null ? (uint)(BenefitPeriodTypeEnum)EPOPR.BenefitPeriodType.Value : 0;
                                        if (EPOPR.BenefitPeriodType != null)
                                        {
                                            if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                                            {

                                                MldiQualifiedRider.benefitPeriodAge = 65;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                                            {
                                                MldiQualifiedRider.benefitPeriodAge = 67;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                                            {
                                                MldiQualifiedRider.benefitPeriodAge = 70;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 2;

                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 5;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 10;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                                            {
                                                MldiQualifiedRider.benefitPeriodYears = 15;
                                            }
                                            else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                            {
                                                MldiQualifiedOffer.benefitPeriodYears = 1;
                                            }
                                        }
                                        //MldiQualifiedRider.eliminationPeriod = EPOPR.EliminationPeriodType != null ? (uint)(EliminationPeriodTypeEnum)EPOPR.EliminationPeriodType : 00;
                                        if (EPOPR.EliminationPeriodType != null)
                                        {

                                            if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 180;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 360;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 720;
                                            }
                                            else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                            {
                                                MldiQualifiedRider.eliminationPeriod = 90;
                                            }
                                        }
                                    }
                                    MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                                }
                            }

                            if (EPOPR.BenefitType == BenefitTypeEnum.SupplementalBenefitTermRider)
                            {
                                MldiQualifiedRider = new MLDIQualifiedRider();
                                MldiQualifiedRider.riderIdentifier = "SBT";
                                MldiQualifiedRider.monthlyPremium = CheckNullable(EPOPR.SmokerPremiumAmountMonthly);
                                MldiQualifiedRider.monthlyBenefit = CheckNullable(EPOPR.BenefitAmountMonthly);
                                MldiQualifiedRider.annualPremium = CheckNullable(EPOPR.SmokerPremiumAmountAnnual);
                                //MldiQualifiedRider.benefitPeriodAge = EPOPR.BenefitPeriodType != null ? (uint)(BenefitPeriodTypeEnum)EPOPR.BenefitPeriodType.Value : 0;
                                if (EPOPR.BenefitPeriodType != null)
                                {
                                    if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                                    {
                                        MldiQualifiedRider.benefitPeriodAge = 65;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                                    {
                                        MldiQualifiedRider.benefitPeriodAge = 67;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                                    {
                                        MldiQualifiedRider.benefitPeriodAge = 70;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                                    {
                                        MldiQualifiedRider.benefitPeriodYears = 2;

                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                                    {
                                        MldiQualifiedRider.benefitPeriodYears = 5;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                                    {
                                        MldiQualifiedRider.benefitPeriodYears = 10;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                                    {
                                        MldiQualifiedRider.benefitPeriodYears = 15;
                                    }
                                    else if (EPOPR.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || EPOP.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                                    {
                                        MldiQualifiedOffer.benefitPeriodYears = 1;
                                    }

                                }
                                //MldiQualifiedRider.eliminationPeriod = EPOPR.EliminationPeriodType != null ? (uint)(EliminationPeriodTypeEnum)EPOPR.EliminationPeriodType : 00;
                                if (EPOPR.EliminationPeriodType != null)
                                {

                                    if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                                    {
                                        MldiQualifiedRider.eliminationPeriod = 180;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                                    {
                                        MldiQualifiedRider.eliminationPeriod = 360;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                                    {
                                        MldiQualifiedRider.eliminationPeriod = 720;
                                    }
                                    else if (EPOPR.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                                    {
                                        MldiQualifiedRider.eliminationPeriod = 90;
                                    }

                                }

                                MldiQualifiedOffer.riders.Add(MldiQualifiedRider);
                            }

                        }
                    }

                    listMldiQualifiedOffers.Add(MldiQualifiedOffer);
                }//foreach
                if (listMldiQualifiedOffers.Any())
                {
                    listMldiQualifiedOffers = listMldiQualifiedOffers.OrderBy(c => c.xmlOrderPosition).ToList();
                }

            }

            return listMldiQualifiedOffers;
        }

        private void BuildMockParticipant(EnrollmentParticipant enrolledParticipant, Case cmsCase, PDRSoldClass pdrSoldClass, MLDIGroup group, IEnumerable<CaseBroker> caseBrokers, int count, int emailAddressCount)
        {
            MLDIParticipant participant = new MLDIParticipant();
            participant.currentLTDs = null;

            if (enrolledParticipant != null && enrolledParticipant.Participant != null && enrolledParticipant.Participant.Age != null && enrolledParticipant.Participant.Age >= 35)
            {
                participant.isMockEmployee = true;

                participant.cmsCode = enrolledParticipant.Id.ToString() != null ? "Z" + enrolledParticipant.Id.ToString() + "-" + count : "";
                participant.cmsStatus = GetParticipantStatusCode(enrolledParticipant.Participant);

                if (!string.IsNullOrEmpty(enrolledParticipant.Participant.Gender))
                {
                    if (enrolledParticipant.Participant.Gender.ToUpper() == "M" || enrolledParticipant.Participant.Gender.ToUpper() == "F")
                    {
                        participant.gender = ((GenderRestriction)(enrolledParticipant.Participant.Gender.ToUpper() == "M" ? 0 : 1));
                    }
                    else if (enrolledParticipant.Participant.Gender.ToUpper().Trim() == "MALE" || enrolledParticipant.Participant.Gender.ToUpper().Trim() == "FEMALE")
                    {
                        participant.gender = ((GenderRestriction)(enrolledParticipant.Participant.Gender.ToUpper().Trim() == "MALE" ? 0 : 1));
                    }
                }
                else
                {

                    participant.gender = GenderRestriction.Unknown;
                }
                if (enrolledParticipant.Participant.DateOfBirth.Value != null)
                {
                    participant.dateOfBirth = Convert.ToDateTime("1 / 1 / " + enrolledParticipant.Participant.DateOfBirth.Value.Year);
                }

                participant.temporaryPassword = enrolledParticipant.OnlineEnrollmentPassword != null ? enrolledParticipant.OnlineEnrollmentPassword : "";
                participant.existingPolicyNumber = string.Empty;
                if (enrolledParticipant.Policies.Any())
                {
                    var policy = enrolledParticipant.Policies.FirstOrDefault();
                    participant.existingPolicyNumber = policy != null ? policy.PolicyNumber : string.Empty;
                }
                participant.personalInformation = new MLDIPerson();
                {
                    participant.personalInformation.type = PersonTypeRestriction.Employee;
                    participant.personalInformation.title = "";
                    participant.personalInformation.prefix = "";
                    //Added EmployeeId field as per the story NBTC-3237
                    participant.personalInformation.employeeId = participant.isMockEmployee ? participant.cmsCode :
                                                                            (enrolledParticipant.Participant.EmployeeId != null
                                                                            ? enrolledParticipant.Participant.EmployeeId.Trim() : "");
                    if (!string.IsNullOrEmpty(enrolledParticipant.Participant.Gender))
                    {
                        if (enrolledParticipant.Participant.Gender.ToUpper().Trim() == "MALE")
                        {
                            participant.personalInformation.firstName = "John";
                        }
                        else
                        {
                            participant.personalInformation.firstName = "Jane";
                        }
                    }

                    participant.personalInformation.middleName = "A";
                    participant.personalInformation.lastName = "Smith";
                    participant.personalInformation.suffix = enrolledParticipant.Participant.Suffix != null
                                                                ? enrolledParticipant.Participant.Suffix : "";
                    var Domain = enrolledParticipant.Participant.WorkEmail != null ? enrolledParticipant.Participant.WorkEmail : string.Empty;
                    string domain = Domain.Split('@').ElementAtOrDefault(1);
                    participant.personalInformation.email = "user" + emailAddressCount + "@" + domain;
                    count++;
                    emailAddressCount++;
                    participant.personalInformation.addresses = new List<MLDIAddress>();
                    MLDIAddress mLdiAddress = new MLDIAddress();
                    {
                        mLdiAddress.type = AddressTypeRestriction.Home;
                        mLdiAddress.locationName = "Home";
                        mLdiAddress.street1 = "530 Main St";
                        mLdiAddress.street2 = "";
                        mLdiAddress.city = "Parktown";
                        mLdiAddress.state = "MA";
                        mLdiAddress.postalCode = enrolledParticipant.Participant.HomeZipCode;
                        mLdiAddress.country = "United States of America";
                        mLdiAddress.phoneNumber = "555-555-1212";
                    }

                    participant.personalInformation.addresses.Add(mLdiAddress);
                    mLdiAddress = new MLDIAddress();
                    {
                        mLdiAddress.type = AddressTypeRestriction.Work;
                        mLdiAddress.locationName = "Work";
                        mLdiAddress.street1 = "299 Lynn Lane";
                        mLdiAddress.street2 = "";
                        mLdiAddress.city = "Wardsboro";
                        mLdiAddress.state = "MA";
                        mLdiAddress.postalCode = enrolledParticipant.Participant.WorkZipCode;
                        mLdiAddress.country = "United States of America";
                        mLdiAddress.phoneNumber = "555-555-1212";
                    }
                    participant.personalInformation.addresses.Add(mLdiAddress);
                }
                participant.occupationDetails = new MLDIParticipantOccupation();
                {

                    participant.occupationDetails.occupationClass = enrolledParticipant.Participant.OccupationClass_Id != null ? ((OccupationClassTypeEnum)enrolledParticipant.Participant.OccupationClass_Id).GetDescription() : "";
                    participant.occupationDetails.occupationDescription = "Manager";
                    participant.occupationDetails.dateOfHire = Convert.ToDateTime("1 / 1 / 2005");
                    participant.occupationDetails.weeklyHoursWorked = "9999";

                }
                participant.incomeDetails = new MLDIParticipantIncome();
                {
                    participant.incomeDetails.currentYearInsurableIncome = enrolledParticipant.Participant.IDIInsurableIncomeCalculatedAmount ?? 0;
                    participant.incomeDetails.currentYearInsurableSalary = enrolledParticipant.Participant.MostRecentSalaryAmount ?? 0;
                    participant.incomeDetails.currentYearInsurableIncentive = ((enrolledParticipant.Participant.IDIInsurableIncomeCalculatedAmount != null ? enrolledParticipant.Participant.IDIInsurableIncomeCalculatedAmount : 0) - (enrolledParticipant.Participant.MostRecentSalaryAmount != null ? enrolledParticipant.Participant.MostRecentSalaryAmount : 0));
                    var pdrSoldClassPlan = pdrSoldClass.PDRSoldClassPlan != null ? pdrSoldClass.PDRSoldClassPlan.FirstOrDefault() : null;
                    if (pdrSoldClassPlan != null && (pdrSoldClassPlan.CoveredEarningsType != CoveredEarningsTypeEnum.W_2Income && pdrSoldClassPlan.CoveredEarningsType != CoveredEarningsTypeEnum.K_1Earnings))
                    {
                        participant.incomeDetails.baseSalary = enrolledParticipant.Participant.MostRecentSalaryAmount ?? 0;
                        participant.incomeDetails.bonusIncome = enrolledParticipant.Participant.MostRecentPaidBonusAmount ?? 0;
                        participant.incomeDetails.commissionIncome = enrolledParticipant.Participant.MostRecentPaidCommissionAmount ?? 0;
                    }
                    else if(pdrSoldClassPlan != null && pdrSoldClassPlan.CoveredEarningsType == CoveredEarningsTypeEnum.W_2Income)
                    {
                        if (exstreamRequestDocumentType != "BridgelineXml")
                        {
                            participant.incomeDetails.w2Income = enrolledParticipant.Participant.MostRecentYearPaidW2Income ?? 0;
                        }
                        if (enrolledParticipant.Participant.MostRecentSalaryAmount == 0 || enrolledParticipant.Participant.MostRecentSalaryAmount == null)
                        {
                            participant.incomeDetails.baseSalary = enrolledParticipant.Participant.MostRecentYearPaidW2Income ?? 0;
                        }
                        else {
                            participant.incomeDetails.baseSalary = (decimal)enrolledParticipant.Participant.MostRecentSalaryAmount + (decimal)enrolledParticipant.Participant.MostRecentYearPaidW2Income;
                        }
                    }
                    else if (pdrSoldClassPlan != null && pdrSoldClassPlan.CoveredEarningsType == CoveredEarningsTypeEnum.K_1Earnings)
                    {
                        if (exstreamRequestDocumentType != "BridgelineXml")
                        {
                            participant.incomeDetails.k1Income = enrolledParticipant.Participant.MostRecentPaidK1IncomeAmount ?? 0;
                        }
                        if (enrolledParticipant.Participant.MostRecentSalaryAmount == 0 || enrolledParticipant.Participant.MostRecentSalaryAmount == null)
                        {
                            participant.incomeDetails.baseSalary = enrolledParticipant.Participant.MostRecentPaidK1IncomeAmount ?? 0;
                        }
                        else {
                            participant.incomeDetails.baseSalary = (decimal)enrolledParticipant.Participant.MostRecentSalaryAmount  + (decimal)enrolledParticipant.Participant.MostRecentPaidK1IncomeAmount;
                        }
                    }

                    participant.incomeDetails.retirementContribution = enrolledParticipant.Participant.TotalEmployerOrEmployeeRetirementContributionAmount ?? 0;

                }
                foreach (CaseBroker caseBroker in caseBrokers)
                {
                    participant.servicingProducerCmsCode = caseBroker.BrokerWritingCode != null ? caseBroker.BrokerWritingCode : "";
                    participant.signingProducerCmsCode = caseBroker.BrokerWritingCode != null ? caseBroker.BrokerWritingCode : "";
                    participant.ContactProducerCmsCode = caseBroker.BrokerWritingCode != null ? caseBroker.BrokerWritingCode : "";
                }

                if (enrolledParticipant.Participant.IDIBenefitAmount1 > 0 || enrolledParticipant.Participant.IDIBenefitAmount2 > 0
                    || enrolledParticipant.Participant.IDIBenefitAmount3 > 0 || enrolledParticipant.Participant.IDIBenefitAmount4 > 0
                    || enrolledParticipant.Participant.LTDCalculatedAmount > 0)
                {
                    participant.currentLTDs = new List<MLDIAdditionalLtd>();
                    participant.currentLTDs = AdditionalLtdDatabuilder(enrolledParticipant, pdrSoldClass, cmsCase);
                }

                // qualifiedOffer Non - Smoker
                participant.offers = GetQualifiedOffers(enrolledParticipant, pdrSoldClass, cmsCase, participant.currentLTDs);
                //qualifiedOffer  Smoker
                //participant.offers = GetQualifiedOfferSmoker(enrolledParticipant, pdrSoldClas);

                participant.effectiveDate = enrolledParticipant.Enrollment.EffectiveDate;
                group.eligibleParticipants.Add(participant);
            }
        }

        private void GetOption1EnrollmentParticipantOptionPlan(List<EnrollmentParticipantOptionPlan> enrollmentParticiapntOptionPlan)
        {
            if (enrollmentParticiapntOptionPlan != null)
            {
                if (enrollmentParticiapntOptionPlan.Count > 0)
                {
                    enrollmentParticiapntOptionPlan = enrollmentParticiapntOptionPlan.Where(c => c.StandardOptionCodeNonSmoker != null
                    && c.StandardOptionCodeNonSmoker.Contains("Option 1") || (c.StandardOptionCodeSmoker != null && c.StandardOptionCodeSmoker.Contains("Option 1"))).ToList();
                }
            }
        }

        private bool CheckForValueInFullyUnderwrittenIDI(ParticipantExistingPolicy participantExistingPolicy)
        {
            bool isBerkshireIDITagToBeShown = false;

            if (participantExistingPolicy.FullyUnderwrittenIDI != null && participantExistingPolicy.FullyUnderwrittenIDI > 0)
            {
                isBerkshireIDITagToBeShown = true;
            }
            return isBerkshireIDITagToBeShown;
        }

        private CmsStatusRestriction GetParticipantStatusCode(Participant participant)
        {
            var cmsStatus = CmsStatusRestriction.NewlyEligible;

            if (participant.ParticipantCategoryCodeType != null)
            {
                switch (participant.ParticipantCategoryCodeType)
                {
                    case ParticipantCategoryCodeTypeEnum.AMB:
                        cmsStatus = CmsStatusRestriction.AMBREligible;
                        break;
                    case ParticipantCategoryCodeTypeEnum.NE:
                        cmsStatus = CmsStatusRestriction.NewlyEligible;
                        break;
                    case ParticipantCategoryCodeTypeEnum.PS:
                        cmsStatus = CmsStatusRestriction.PreviousDecline;
                        break;
                    case ParticipantCategoryCodeTypeEnum.FO:
                        cmsStatus = CmsStatusRestriction.FinalOffer;
                        break;
                }
            }

            return cmsStatus;
        }

        private void CreateAMBRiders(EnrollmentParticipantOptionPlanRider epopr, EnrollmentParticipant enrolledParticipant,
                                    PDRSoldClass pdrSoldClass, MLDIQualifiedOffer offer, bool isSmoker, EnrollmentParticipantOptionPlan epop, bool isVgsiPlanType)
        {
            ParticipantCategoryCodeTypeEnum? participantCategoryCodeType = new ParticipantCategoryCodeTypeEnum();

            bool isOffer1 = false;

            if (offer.cmsStandardOfferCode.Contains("Option 2") || offer.cmsStandardOfferCode.Contains("Option 3"))
            {
                isOffer1 = false;
                if (isVgsiPlanType)
                {
                    participantCategoryCodeType = enrolledParticipant.Participant.BuyUpParticipantCategoryCodeType;
                }
                else
                {
                    participantCategoryCodeType = enrolledParticipant.Participant.ParticipantCategoryCodeType;
                }
            }
            else
            {
                isOffer1 = true;
                participantCategoryCodeType = enrolledParticipant.Participant.ParticipantCategoryCodeType;
            }

            if (participantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB)
            {
                var ambRider = new MLDIQualifiedRider();
                ambRider.riderIdentifier = "AMBR";

                var basePlan = pdrSoldClass.PDRSoldClassPlan.Where(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).FirstOrDefault();
                var vgsiPlan = pdrSoldClass.PDRSoldClassPlan.Where(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp).FirstOrDefault();

                var enrollmentBaseParticipantOptionPlan = enrolledParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                var enrollmentVgsiParticipantOptionPlan = enrolledParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                if (basePlan != null && basePlan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                {
                    ambRider.monthlyBenefit = enrolledParticipant.Participant.RPPAMBCalculatedAmount ?? 0;
                }
                else
                {
                    if (vgsiPlan != null && !isOffer1)
                    {
                        ambRider.monthlyBenefit = enrollmentVgsiParticipantOptionPlan?.AMBCalculatedAmount ?? 0;
                    }
                    else
                    {
                        ambRider.monthlyBenefit = enrollmentBaseParticipantOptionPlan?.AMBCalculatedAmount ?? 0;
                    }
                }
                ambRider.monthlyPremium = isSmoker ? CheckNullable(epopr.SmokerPremiumAmountMonthly) : CheckNullable(epopr.NonSmokerPremiumAmountMonthly);

                ambRider.annualPremium = isSmoker ? CheckNullable(epopr.SmokerPremiumAmountAnnual) : CheckNullable(epopr.NonSmokerPremiumAmountAnnual);
                if (epopr.BenefitPeriodType != null)
                {
                    if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                    {

                        ambRider.benefitPeriodAge = 65;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                    {
                        ambRider.benefitPeriodAge = 67;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                    {
                        ambRider.benefitPeriodAge = 70;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || epopr.BenefitPeriodType == BenefitPeriodTypeEnum.M24)
                    {
                        ambRider.benefitPeriodYears = 2;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || epopr.BenefitPeriodType == BenefitPeriodTypeEnum.M60)
                    {
                        ambRider.benefitPeriodYears = 5;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                    {
                        ambRider.benefitPeriodYears = 10;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                    {
                        ambRider.benefitPeriodYears = 15;
                    }
                    else if (epopr.BenefitPeriodType == BenefitPeriodTypeEnum.Y01 || epopr.BenefitPeriodType == BenefitPeriodTypeEnum.M12)
                    {
                        ambRider.benefitPeriodYears = 1;
                    }

                }
                if (epopr.EliminationPeriodType != null)
                {

                    if (epopr.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                    {
                        ambRider.eliminationPeriod = 180;
                    }
                    else if (epopr.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                    {
                        ambRider.eliminationPeriod = 360;
                    }
                    else if (epopr.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                    {
                        ambRider.eliminationPeriod = 720;
                    }
                    else if (epopr.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                    {
                        ambRider.eliminationPeriod = 90;
                    }

                }

                if (basePlan.PremiumPayerAndTaxabilityType != null && basePlan.PremiumPayerAndTaxabilityType.Id == (int?)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                {
                    if (!isSmoker)
                    {
                        ambRider.csEEPremiumPaidPerMonth = CheckNullable(epop.NonSmokerEmployeePremiumPerMonth);
                        ambRider.csERPremiumPaidPerMonth = CheckNullable(epop.NonSmokerEmployerPremiumPerMonth);
                        ambRider.csEEPremiumPaidPerPaycheck = CheckNullable(epop.NonSmokerEmployeePremiumAmountPaycheck);
                        ambRider.csERPremiumPaidPerPaycheck = CheckNullable(epop.NonSmokerEmployerPremiumAmountPaycheck);
                    }
                    else
                    {
                        ambRider.csEEPremiumPaidPerMonth = CheckNullable(epop.SmokerEmployeePremiumPerMonth);
                        ambRider.csERPremiumPaidPerMonth = CheckNullable(epop.SmokerEmployerPremiumPerMonth);
                        ambRider.csEEPremiumPaidPerPaycheck = CheckNullable(epop.SmokerEmployeePremiumAmountPaycheck);
                        ambRider.csERPremiumPaidPerPaycheck = CheckNullable(epop.SmokerEmployerPremiumAmountPaycheck);
                    }
                }

                if (ambRider.monthlyPremium > 0 && ambRider.annualPremium > 0)
                {
                    offer.riders.Add(ambRider);
                }
                else {

                    Log.Debug($"CaseCommonXmlBuilder.CreateAMBRiders : Skipping AMBR rider tags as premium is zero for Enrollment ParticipantId '{enrolledParticipant.Id}'");
                }
            }
        }

        public int GetOptionClassTypeOrder(ParticipantCategoryCodeTypeEnum? participantCodeType)
        {
            int optionClassTypeOrder = 0;
            switch (participantCodeType)
            {
                case ParticipantCategoryCodeTypeEnum.NE:
                    optionClassTypeOrder = 1;
                    break;
                case ParticipantCategoryCodeTypeEnum.PS:
                    optionClassTypeOrder = 2;
                    break;
                case ParticipantCategoryCodeTypeEnum.FO:
                    optionClassTypeOrder = 3;
                    break;
                case ParticipantCategoryCodeTypeEnum.AMB:
                    optionClassTypeOrder = 4;
                    break;

            }
            return optionClassTypeOrder;
        }
    }
}