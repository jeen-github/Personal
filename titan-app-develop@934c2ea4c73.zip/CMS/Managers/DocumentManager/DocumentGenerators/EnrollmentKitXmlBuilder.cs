﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class EnrollmentKitXmlBuilder
    {
        public IUnitOfWorkFactory UnitOfWorkFactory { get; private set; }

        public EnrollmentKitXmlBuilder(IUnitOfWorkFactory unitOfWorkFactory)
        {
            UnitOfWorkFactory = unitOfWorkFactory;
        }

        public void CreateEnrollmentKit(EnrollmentKitXmlGenerationRequest request, EnrollmentKitXml bpXml)
        {

            Log.TraceFormat("+CreateBPXml");

            //var commonXmlBuilder = new CaseKitXmlBuilder(UnitOfWorkFactory);
            var commonXmlBuilder = new CaseCommonXmlBuilder(UnitOfWorkFactory);
            commonXmlBuilder.CreateCase(request, bpXml,bpXml.ExstreamRequestType);

            var kitAddOns = new EnrollmentKitAdditionalData(UnitOfWorkFactory);
            kitAddOns.AddEnrollmentData(request, bpXml);

            string sequencecount = "001";
            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {

                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var listBillNumber = unitOfWork.Repository<ListBillNumber>().Linq().Where(c => c.Case.Id == request.CaseId);
                var policyDeliveryMethod = unitOfWork.Repository<PolicyDeliveryMethodType>().Linq().FirstOrDefault(c => c.Code == "E_Delivery");
                var caseBrokers = cmsCase.CaseBrokers.Where(c => c.Case.Id == request.CaseId);
                // var enrollment = cmsCase.CaseEnrollments.OrderByDescending(c => c.Id).FirstOrDefault(c => c.Case.Id == request.CaseId);
                var enrollment = cmsCase.CaseEnrollments.FirstOrDefault(c => c.Id == request.EnrollmentId);
                var enrollmentOutput = unitOfWork.Repository<EnrollmentOutput>().Linq().FirstOrDefault(c => c.Enrollment.Id == enrollment.Id);
                var contactAddress = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId && c.IsPrimary == true);
                var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(ep => ep.Enrollment.Id == enrollment.Id);
                var enrollmentMeetings = unitOfWork.Repository<EnrollmentMeeting>().Linq().Where(em => em.Enrollment.Id == enrollment.Id); var enrollmentParticipents = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => c.Enrollment.Id == enrollment.Id && c.Participant.IsEligible == true && c.Participant.IsActive == true);
                if (request.ParticipantIds != null && request.ParticipantIds.Count > 0)
                {
                    enrollmentParticipents = enrollmentParticipents.Where(c => request.ParticipantIds.Contains(c.Id));
                }
                // var ProducercontactAddres = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId && c.IsPrimary == true && c.ContactRoleType == ContactRoleTypeEnum.Producer);
                var ProducercontactAddres = unitOfWork.Repository<ContactAddress>().Linq().Where(c => c.Case.Id == request.CaseId);
                ContactAddress returnAddre = null;
                if (enrollmentOutput != null && enrollmentOutput.ReturnAddress != null && enrollmentOutput.ReturnAddress.Id > 0)
                {
                    returnAddre = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId && c.Id == enrollmentOutput.ReturnAddress.Id);
                }
                var DISAddres = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId && c.ContactRoleType == ContactRoleTypeEnum.DIS);
                var BandPUser = unitOfWork.Repository<BenefitPremiumDocument>().Linq().FirstOrDefault(c => c.Enrollment.Id == request.EnrollmentId);
                CmsUser userID = null;
                if (DISAddres!=null&& BandPUser!=null)
                { 
                 userID = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(c => c.LdapUserName.Equals(BandPUser.GeneratedBy));
                }

                //bpXml.cmsProcessDate = cmsCase.CreationDate.Date.ToString("MMddyyyy");
                //bpXml.cmsProcessTime = cmsCase.CreationDate.ToString("HHmmss");
                bpXml.cmsProcessDate = DateTime.Now.ToString("MMddyyyy");
                bpXml.cmsProcessTime = DateTime.Now.ToString("HHmmss");
                bpXml.showCompanyNameOrLogo = enrollmentOutput != null ? IscompanyNameOrLogo(enrollmentOutput) : "None";
                bpXml.printFile = request.PrintFile == true ? "Y" : "N";
                if (enrollmentOutput!=null)
                {
                    bpXml.CompanyFriendlyName = enrollmentOutput.CompanyFriendlyName != null ? enrollmentOutput.CompanyFriendlyName : string.Empty;
                }


                //if (enrollmentOutput == null)
                //{
                //    bpXml.responseRequired = "False";

                //}
                //else
                //{
                //    if (!string.IsNullOrEmpty(enrollmentOutput.ResponseRequiredText))
                //    {
                //        bpXml.responseRequired = "True";
                //    }
                //    else
                //    {
                //        bpXml.responseRequired = "False";
                //    }
                //}


                //bpXml.eDeliveryIndicator = enrollment != null ? enrollment.IsEDeliveryIndicator : false;
                bpXml.eDeliveryIndicator = listBillNumber != null ? (listBillNumber.Where(r => r.PolicyDeliveryMethodType == policyDeliveryMethod).Count() > 0) : false;

                //TODO: What is used for Date ?
                bpXml.enrollmentCommunicationDate = DateTime.Now.ToString("yyyy-MM-dd");
                bpXml.enrollmentCommunicationSender = enrollment != null ? enrollment.EnrollmentWebsite : null;

                bpXml.coverLetterDate = null;
                if (enrollmentOutput != null && enrollmentOutput.IsCoverLetterIncluded )
                {
                    bpXml.coverLetterDate = DateTime.Now.ToString("yyyy-MM-dd");
                }
                
                //Enrollment Meeting Stuff
                bpXml.EnrollmentMeetings = new List<EnrollmentKitXml.ExtreamGenerationEnrollmentMeeting>();
                int meetingCount = 0;
                foreach (var e in enrollmentMeetings)
                {
                    var enrollmentVar = new EnrollmentKitXml.ExtreamGenerationEnrollmentMeeting();
                    enrollmentVar.code = Convert.ToString(++meetingCount);
                    enrollmentVar.location = e.Location;
                    enrollmentVar.meetingDateTime = e.MeetingDateTime;
                    enrollmentVar.phoneOrOther = e.PhoneOrOther;
                    bpXml.EnrollmentMeetings.Add(enrollmentVar);

                }
                //END NEW STUFF

                if (userID != null)
                {
                    bpXml.userID = userID.Id.ToString();
                }


                if (enrollmentOutput != null)
                {
                    if (enrollmentOutput.HRContact != null)
                    {
                        bpXml.companyHRContact = enrollmentOutput.HRContact.ContactName != null ? enrollmentOutput.HRContact.ContactName : "";
                        bpXml.companyHRContactEmail = enrollmentOutput.HRContact.Email != null ? enrollmentOutput.HRContact.Email : "";
                        bpXml.companyHRContactPhone = enrollmentOutput.HRContact.Phone != null ? enrollmentOutput.HRContact.Phone : "";
                    }
                }

                if (DISAddres != null)
                {
                    bpXml.disCode = DISAddres.DISCode != null ? DISAddres.DISCode : "";
                }

                if (enrollmentOutput != null)
                {
                    if (enrollmentOutput.ContactOne != null)
                    {
                        bpXml.companyContact = enrollmentOutput.ContactOne.ContactName != null ? enrollmentOutput.ContactOne.ContactName : "";
                        bpXml.companyContactEmail = enrollmentOutput.ContactOne.Email != null ? enrollmentOutput.ContactOne.Email : "";
                        bpXml.companyContactPhone = enrollmentOutput.ContactOne.Phone != null ? enrollmentOutput.ContactOne.Phone : "";
                    }
                }

                if (enrollmentOutput != null)
                {
                    if (enrollmentOutput.ContactTwo != null)
                    {
                        bpXml.companyContact2 = enrollmentOutput.ContactTwo.ContactName != null ? enrollmentOutput.ContactTwo.ContactName : "";
                        bpXml.companyContact2Email = enrollmentOutput.ContactTwo.Email != null ? enrollmentOutput.ContactTwo.Email : "";
                        bpXml.companyContact2Phone = enrollmentOutput.ContactTwo.Phone != null ? enrollmentOutput.ContactTwo.Phone : "";
                    }

                    if (returnAddre != null)
                    {

                        bpXml.ReturnAddressName = returnAddre.ContactName != null ? returnAddre.ContactName : "";
                    }
                    
                    bpXml.CoverLetterIncluded = enrollmentOutput.IsCoverLetterIncluded;
                    var salutat = "";
                    if (enrollmentOutput.EnrollmentOutputSalutationType!=null)
                    {
                        salutat = enrollmentOutput.EnrollmentOutputSalutationType.Description;
                    }
                   var saltxt = enrollmentOutput.SalutationText != null ? enrollmentOutput.SalutationText : "";
                    bpXml.Salutation = salutat + " " + saltxt;
                    bpXml.IncludeReplacementPercentage = enrollmentOutput.IsShowReplacementPercentage;

                    if (enrollmentOutput.EnrollmentOutputIncomeDefinitionType != EnrollmentOutputIncomeDefinitionTypeEnum.Other)
                    {
                        bpXml.IncomeDefinition = "OfferLetterInsurableIncomeDefinition";
                    }
                    else
                    {
                        bpXml.IncomeDefinition = enrollmentOutput.OtherIncomeDefinitionText != null ? enrollmentOutput.OtherIncomeDefinitionText : "";
                    }

                    if (enrollmentOutput.EnrollmentOutputIncomeDefinitionType != null)
                    {
                        bpXml.IncomeType = (EnrollmentOutputShowTypeEnum)enrollmentOutput.EnrollmentOutputIncomeDefinitionType;

                    }
                    if (enrollmentOutput.EnrollmentOutputIncomeDisplayType != null)
                    {
                        bpXml.IncomeDisplayType = enrollmentOutput.EnrollmentOutputIncomeDisplayType.Description;
                    }
                    if (enrollmentOutput.EnrollmentOutputPremiumDisplayType != null)
                    {
                        bpXml.PremiumDisplayType = enrollmentOutput.EnrollmentOutputPremiumDisplayType.Description;
                    }
                    bpXml.DOBOnFile = enrollmentOutput.IsDOB;
                    bpXml.SSNOnFile = enrollmentOutput.IsSSN;
                    bpXml.CompensationOnFile = enrollmentOutput.IsCompensation;
                    bpXml.PrepaidEnvelope = enrollmentOutput.IsPrepaidEnvelope;


                }

                if (caseBrokers != null && ProducercontactAddres != null)
                {
                    bpXml.questionsProducerInfo = GetProducerInfo(caseBrokers, ProducercontactAddres);
                }

                if (enrollmentOutput != null)
                {
                    bpXml.Letterhead = enrollmentOutput.IsCompanyLetterhead == true ? "Yes" : "No";
                    bpXml.enrollmentMethodFaxText = enrollmentOutput.ApplicationReturnInstructions != null ? enrollmentOutput.ApplicationReturnInstructions : "";
                    bpXml.onlineURL = enrollment.EnrollmentWebsite != null ? enrollment.EnrollmentWebsite : "";
                    bpXml.omitPageNumbers = enrollmentOutput.IsOmitPageNumbers;
                    bpXml.responseRequired = enrollmentOutput.ResponseRequiredText != null ? enrollmentOutput.ResponseRequiredText : "";
                    bpXml.responseRequired = enrollmentOutput.ResponseRequiredText != null ? enrollmentOutput.ResponseRequiredText : "";

                    bpXml.omitGLTD = false;
                    if (enrollmentOutput.IsIncludeGLTDDefinition != true)
                    {
                        bpXml.omitGLTD = true;
                    }

                    bpXml.omitGLTDTaxibilityLanguage = false;
                    if (enrollmentOutput.IsIncludeGLTDTaxabilityLanguage != true)
                    {
                        bpXml.omitGLTDTaxibilityLanguage = true;
                    }

                }

                var csno = cmsCase.CaseNumber != null ? cmsCase.CaseNumber : "";

                bpXml.reqNumber = csno + "-" + GetNextValue(sequencecount);

                //var producersAndAgents = new List<MLDIProducerAgent>();
                //var Producersagent = new MLDIProducerAgent();
                //bpXml.producersAndAgents.Add(Producersagent);

            }


            Log.TraceFormat("-CreateBPXml");
        }

        private string IscompanyNameOrLogo(EnrollmentOutput enrollmentOutputs)
        {
            var CompanyNameorLogo = string.Empty;

            if ((enrollmentOutputs.IsCompanyLogo == true) && (enrollmentOutputs.IsCompanyLetterhead == true))
            {
                CompanyNameorLogo = "BOTH";
            }
            else if ((enrollmentOutputs.IsCompanyLogo == true) && (enrollmentOutputs.IsCompanyLetterhead == false))
            {
                CompanyNameorLogo = "LOGO";
            }
            else if ((enrollmentOutputs.IsCompanyLogo == false) && (enrollmentOutputs.IsCompanyLetterhead == true))
            {
                CompanyNameorLogo = "LETTER";
            }
            else
            {
                CompanyNameorLogo = "None";
            }

            return CompanyNameorLogo;

        }

        private string GetProducerInfo(IEnumerable<CaseBroker> casebroker, IQueryable<ContactAddress> contaddress)
        {
            string compName = "", email = "", phoneno = "", brokerdetails;

            //var casebrokers = casebroker.Select();
            if (casebroker.Any())
            {
                compName = casebroker.FirstOrDefault().CompanyName != null ? casebroker.FirstOrDefault().CompanyName : "";
            }

            var producerContact = contaddress.FirstOrDefault(c => c.ContactRoleType == ContactRoleTypeEnum.Producer);


            if (producerContact!=null)
            {
                email = producerContact.Email != null ? producerContact.Email : "";
                phoneno = producerContact.Phone != null ? producerContact.Phone : "";
            }
            brokerdetails = compName + "|" + email + "|" + phoneno;
            return brokerdetails;
        }

        private string GetNextValue(string s)
        {
            return String.Format("{0:D3}", Convert.ToInt32(s.Substring(00)) + 0);
            //return  Convert.ToInt32(s.Substring(0) + 1);
        }

    }
}