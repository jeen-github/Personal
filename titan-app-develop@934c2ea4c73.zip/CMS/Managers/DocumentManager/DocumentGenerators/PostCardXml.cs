﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{

    [System.Xml.Serialization.XmlRoot("ExtreamDocumentXML", IsNullable = false)]
    public class PostCardXml
    {
        [System.Xml.Serialization.XmlElement("exstreamRequestType", IsNullable = false)]
        public string ExstreamRequestType { get; set; }
      
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date")]
        public DateTime enrollmentStartDate { get; set; }

        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date")]
        public DateTime enrollmentEndDate { get; set; }

        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string enrollmentContactName { get; set; }

        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string enrollmentContactEmail { get; set; }

        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string enrollmentContactPhoneNumber { get; set; }

        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string enrollmentWebsiteURL { get; set; }

        private Company _company;

        public PostCardXml()
        {
             ExstreamRequestType = "PostCardKit";           
            _company = new Company();            
        }


        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public Company company
        {
            get
            {
                return _company;
            }
            set
            {
                _company = value;
            }
        }

        [System.SerializableAttribute()]
        public partial class Company
        {
            private string _name;           
            private string _companyLogoBLOB { get; set; }
            public Company()
            {

            }
            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public string name
            {
                get
                {
                    return _name;
                }
                set
                {
                    _name = value;
                }
            }
            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public string companyLogoBLOB
            {
                get
                {
                    return _companyLogoBLOB;
                }
                set
                {
                    _companyLogoBLOB = value;
                }
            }
        }       

        [System.SerializableAttribute()]
        public partial class Address
        {          
            public AddressTypeRestriction type;
            
            public string street1;
            
            public string street2;

            public string city;

            public string state;

            public string zipCode;

            public Address()
            {
                type = AddressTypeRestriction.Home;
            }           
        }

        [System.SerializableAttribute()]
        public enum AddressTypeRestriction
        {
            Undetermined,
            Home,
            Work,
        }
        
        [XmlArray("Participants")]
        [XmlArrayItem(typeof(ExtreamGenerationParticipantXml), ElementName = "Participant")]
        public List<ExtreamGenerationParticipantXml> Participants { get; set; }

        public class ExtreamGenerationParticipantXml
        {           
            public ExtreamGenerationParticipantXml()
            {
                address = new Address();
            }
            public string firstName;

            public string lastName;

            public Address address;

        }

    }   
}
