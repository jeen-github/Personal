﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Managers.PreQuoteCalculationManagers.Calculators;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Utilities;
using CMS.Interfaces.Managers.EligibilityManager;
using System.Xml.Linq;
using System.Xml.XPath;
using System.IO;


namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class IllustrationDocumentGenerator : DocumentGenerator, IIllustrationDocumentGenerator
    {
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IProductLibraryManager _productLibraryManager;
        private readonly IEligibilityConfigurationManager _eligibilityConfigurationManager;

        public IllustrationDocumentGenerator(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager,
            IProductLibraryManager productLibraryManager, IEligibilityConfigurationManager eligibilityConfigurationManager) : base(unitOfWorkFactory, productLibraryManager)
        {
            _workUnitManager = workUnitManager;
            _productLibraryManager = productLibraryManager;
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
        }

        public void CreateIllustrationDocumentRequest(IllustrationRequest request, List<PremiumCalculatorResponse> responses, List<IllustrationParticipantDto> illustrationParticipants, bool isCompactState)
        {
            Log.TraceFormat("+CreateIllustrationDocumentRequest");
            var cmsCase = GetCase(request.CaseId);

            var docRequestXml = CreateXml(request, responses, illustrationParticipants, isCompactState);

            if (!request.LikelyToSellIndicator)
            {
                SaveTotalAnnualPDRPremium(request, docRequestXml);
            }
            var caseDocumentRequest = CreateCaseDocumentRequest(docRequestXml, cmsCase, CaseDocumentTypeEnum.Illustration);

            var illustrationPdfDoc = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.Illustration, ExtreamDocumentType.PDF, null, request.QuoteName);
            var illustrationTxtDoc = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.Illustration, ExtreamDocumentType.CSV, null, request.QuoteName);

            var programSummaryDocument = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.ProgramSummary, ExtreamDocumentType.PDF, null, request.QuoteName);
            var productSummaryDocument = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.ProductSummary, ExtreamDocumentType.PDF, null, request.QuoteName);

            StoreIllustrationDocumentIdsToDatabase(request, illustrationPdfDoc, illustrationTxtDoc, programSummaryDocument, productSummaryDocument);

            _workUnitManager.CreateWorkUnit(WorkUnitType.ExtreamFileUpload, caseDocumentRequest.Id.ToString());

            Log.TraceFormat("-CreateIllustrationDocumentRequest");
        }

        private void SaveTotalAnnualPDRPremium(IllustrationRequest request, string docRequestXml)
        {
            try
            {
                Log.TraceFormat("+SaveTotalAnnualPDRPremium");
                decimal? totalAnnualPDRPremium = CalculateTotalAnnualPDRPremium(docRequestXml);
                if (totalAnnualPDRPremium != null)
                {
                    using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
                    {
                        var illustration = unitOfWork.Repository<Illustration>().Linq().FirstOrDefault(q => q.Id == request.QuoteId);

                        if (illustration != null)
                        {
                            illustration.TotalAnnualPDRPremium = totalAnnualPDRPremium;
                            unitOfWork.Repository<Illustration>().Save(illustration);
                            unitOfWork.Commit();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error in SaveTotalAnnualPDRPremium", ex);
                throw;
            }
            Log.TraceFormat("-SaveTotalAnnualPDRPremium");
        }

        private decimal? CalculateTotalAnnualPDRPremium(string docRequestXml)
        {
            decimal? totalAnnualPDRPremium = null;
            if (docRequestXml != null)
            {
                var xpath = "/IllustrationDocumentRequest/Classes/IllustrationDocumentClassRequest/TotalMonthlyBenefits/TotalMonthlyPremiumAmt";
                var stream = new MemoryStream();
                var writer = new StreamWriter(stream);
                writer.Write(docRequestXml);
                writer.Flush();
                stream.Position = 0;
                var xmlDocument = XDocument.Load(stream);
                var elements = xmlDocument.XPathSelectElements(xpath);
                //var xmlDocument = XDocument.Parse(docRequestXml);
                //IEnumerable<XElement> elements = from el in xmlDocument.Elements(xpath) select el;
                var totalMonthlyPDRPremium = elements.Sum(el => Convert.ToDecimal(el.Value.Replace("$", string.Empty).Trim()));
                if (totalMonthlyPDRPremium > 0.0m)
                {
                    totalAnnualPDRPremium = totalMonthlyPDRPremium * 12.0m;
                }
            }
            return totalAnnualPDRPremium;
        }

        private void StoreIllustrationDocumentIdsToDatabase(IllustrationRequest illustrationRequest,
            CaseDocument illustrationPdfDoc, CaseDocument illustrationTxtDoc, CaseDocument programSummaryDoc, CaseDocument productSummaryDoc)
        {
            try
            {
                Log.TraceFormat("Store illustration document ids to DB.");
                using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
                {
                    var illustration = unitOfWork.Repository<Illustration>().Linq().FirstOrDefault(q => q.Id == illustrationRequest.QuoteId);
                    if (illustration != null)
                    {
                        illustration.RateSheetPdfDocument = illustrationPdfDoc;
                        illustration.RateSheetExcelDocument = illustrationTxtDoc;
                        illustration.ProgramSummaryDocument = programSummaryDoc;
                        illustration.ProductSummaryDocument = productSummaryDoc;

                        unitOfWork.Repository<Illustration>().Save(illustration);
                        unitOfWork.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error saving illustration doc ids in DB", ex);
                throw;
            }
        }

        private string CreateXml(IllustrationRequest request, List<PremiumCalculatorResponse> responses, List<IllustrationParticipantDto> illustrationParticipants, bool isCompactState)
        {
            Log.TraceFormat("+CreateXml");

            string response;

            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var cmsCaseWholesaler = unitOfWork.Repository<CaseWholesaler>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId);
                var caseUnderwritingRequests = cmsCase.CaseUnderwritingRequests;
                var caseBrokers = cmsCase.CaseBrokers.Where(c => c.Case.Id == request.CaseId);
                var caseBrokerState = caseBrokers.SelectMany(c => c.CaseBrokerStates).Where(c => c.IsPrimaryBrokerIndicator == true && c.StateType == caseUnderwritingRequests.FirstOrDefault().StateType).FirstOrDefault();
                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Id == request.PlanDesignRequestId && c.IsActive);
                var contactAddrCategory = unitOfWork.Repository<ContactAddressCategory>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.ContactAddress.Case.Id == cmsCase.Id && c.IsPrimary && c.IsSelect && c.ContactAddressCategoryType.Id == (int)ContactAddressCategoryTypeEnum.UnderwritingOutput);
                var userDetails = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(c => c.LdapUserName == request.RequestedBy);

                var contractState = GetContractState(cmsCase);
                IllustrationRequest Illustartionrequestclasses = new IllustrationRequest();
                string externalWholeSaler = string.Empty;
                if (cmsCaseWholesaler != null && cmsCaseWholesaler.ExternalWholesaler != null)
                {
                    externalWholeSaler = cmsCaseWholesaler.ExternalWholesaler.FirstName != null ? cmsCaseWholesaler.ExternalWholesaler.FirstName : string.Empty;
                    externalWholeSaler = cmsCaseWholesaler.ExternalWholesaler.LastName != null ? externalWholeSaler + " " + cmsCaseWholesaler.ExternalWholesaler.LastName : externalWholeSaler;
                }

                var docRequest = new IllustrationDocumentRequest
                {
                    CaseNumber = request.CaseNumber,
                    CompanyName = cmsCase.CompanyName,
                    EffectiveDate = request.IllustrationEffectiveDate.Value.ToString("MM/dd/yyyy"),
                    ContractState = contractState != null ? contractState.ToString() : StateTypeEnum.UN.ToString(),
                    BrokerName = contactAddrCategory != null ? contactAddrCategory.ContactAddress.ContactName : string.Empty,
                    PresentedBy = contactAddrCategory != null ? contactAddrCategory.ContactAddress.ContactName : null,
                    GuardianRep = externalWholeSaler,
                    UseCompactApp = isCompactState,
                    IncludeIneligibleParticipants = request.IncludeIneligibleParticipants,
                    Classes = new List<IllustrationDocumentClassRequest>(),
                    ProgramSummaries = new List<ProgramSummary>()
                };
                foreach (var item in request.Classes)
                {
                    var Participants = unitOfWork.Repository<Participant>().Linq().Where(c => c.PlanDesignRequestClass.Id == item.TitanClassId && (c.IsError == null || c.IsError == false) && (c.IsEligible == true || c.IsEligible == null) && c.IsActive == true).ToList();
                    if (Participants.Any())
                    {
                        Illustartionrequestclasses.Classes.Add(item);
                    }
                }
                if (pdrSoldClass.Any())
                {
                    docRequest = PopulateXmlFromPDRSoldClass(docRequest, unitOfWork, Illustartionrequestclasses.Classes, cmsCase, responses, illustrationParticipants, isCompactState);
                }
                else
                {
                    docRequest = PopulateXmlFromPDRClass(docRequest, unitOfWork, Illustartionrequestclasses.Classes, cmsCase, responses, illustrationParticipants, isCompactState);
                }

                if (docRequest.IncludeIneligibleParticipants)
                {
                    docRequest.IneligibleParticipants = GetIneligibleEmployees(Illustartionrequestclasses.Classes, unitOfWork);
                }

                response = SerializeObject(docRequest);
            }

            Log.TraceFormat("-CreateXml");

            return response;
        }

        private IllustrationDocumentRequest PopulateXmlFromPDRClass(IllustrationDocumentRequest illustrationDocumentRequest, IUnitOfWork unitOfWork, List<IllustrationRequestClass> illustrationRequestClass, Case cmsCase, List<PremiumCalculatorResponse> responses, List<IllustrationParticipantDto> illustrationParticipants, bool isCompactState)
        {
            Log.TraceFormat("+PopulateXmlFromPDRClass");
            int underInsuredEmployeeCount = 0;
            var contractState = GetContractState(cmsCase);
            int participantCount = 0;
            var illustrationParticipantIds = illustrationParticipants.Select(a => a.Participant.Id).ToList();
            bool isReEnrollmentCase = unitOfWork.Repository<AnnualReview>().Linq().Any(i=>i.Case.Id == cmsCase.Id);


            foreach (var item in illustrationRequestClass)
            {
                InsurableIncomeColumnNames insurableIncomeColumnNames = new InsurableIncomeColumnNames();
                GLTDandIDIBenefitSummaryColumnNames gLTDandIDIBenefitSummaryColumnNames = new GLTDandIDIBenefitSummaryColumnNames();
                ProviderChoiceMonthlyPremiumColumnNames providerChoiceMonthlyPremiumColumnNames = new ProviderChoiceMonthlyPremiumColumnNames();

                var planDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == item.TitanClassId);
                var planDesignRequestClassLTDCoverage = unitOfWork.Repository<PlanDesignRequestClassLTDCoverage>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == planDesignRequestClass.Id);

                var eligibilityConfigurationClassDto = new EligibilityConfigurationDto { PlanDesignRequestClassId = item.TitanClassId };
                eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
                var minimumBenefitAmount = eligibilityConfigurationClassDto.MinimumBenefitAmount;

                var splittedParticipantsIds = illustrationParticipantIds.ChunkBy(1000);

                foreach (var participantIdsSet in splittedParticipantsIds)
                {
                    var participants = unitOfWork.Repository<Participant>().Linq().Where(c => participantIdsSet.Contains(c.Id) && c.PlanDesignRequestClass.Id == item.TitanClassId).ToList();

                    if (participants.Any())
                    {
                        underInsuredEmployeeCount += participants.Where(q => q.LTDCalculatedAmount == planDesignRequestClassLTDCoverage.GroupLTDCapAmount).Count();
                    }
                }

                if (planDesignRequestClass != null && planDesignRequestClass.ApprovedPlanDesignType != null)
                {
                    var classReq = new IllustrationDocumentClassRequest();
                    if (planDesignRequestClass.ApprovedPlanDesignType != PlanDesignTypeEnum.StandAloneIDIPlan && planDesignRequestClass.ApprovedPlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan)
                    {
                        var programSummary = new ProgramSummary();

                        if (planDesignRequestClassLTDCoverage != null) // For StandAlone IDI and RPP plan LTD coverage is not needed, so UnderInsuredEmployeeCount may be empty
                        {
                            programSummary.UnderInsuredEmployeeCount = Convert.ToString(underInsuredEmployeeCount);
                        }
                        else
                        {
                            programSummary.UnderInsuredEmployeeCount = string.Empty;
                        }

                        if (planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable || planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                        {
                            programSummary.TieredOptionsFlag = "Yes";
                        }
                        if (planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid || planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable)
                        {
                            programSummary.TieredOptionsFlag = "No";
                        }
                        illustrationDocumentRequest.ProgramSummaries.Add(programSummary);
                    }

                    classReq.ClassName = item.TitanClassName;
                    classReq.MaxGSIOffer = item.PrimaryPlan.GSIAmount.ToString();
                    if (item.BuyUpPlan != null)
                    {
                        classReq.ERPaidGSIMax = item.PrimaryPlan.GSIAmount.ToString();
                        classReq.VGSIBuyUpMax = item.BuyUpPlan.GSIAmount.ToString();
                        //classReq.TotalCombinedGSI = (item.PrimaryPlan.GSIAmount + item.BuyUpPlan.GSIAmount).ToString();
                        classReq.TotalCombinedGSI = item.BuyUpPlan.TotalMaxGSIAmount != null ? item.BuyUpPlan.TotalMaxGSIAmount.ToString() : item.PrimaryPlan.TotalMaxGSIMaxAmount.ToString();
                    }
                    classReq.DefinitionOfDisability = GetDefinitionOfDisablity((DefinitionOfDisabilityTypeEnum)item.PrimaryPlan.DefinitionOfDisabilityId);//((DefinitionOfDisabilityTypeEnum)item.PrimaryPlan.DefinitionOfDisabilityId).GetDescription();
                    classReq.EliminationPeriod = ((EliminationPeriodTypeEnum)item.PrimaryPlan.EliminationPeriodId).GetDescription();
                    classReq.BenefitPeriod = ((BenefitPeriodTypeEnum)item.PrimaryPlan.BenefitPeriodId).GetDescription();
                    classReq.MentalSubstance = GetMentalSubstanceDescription(item.PrimaryPlan.MentalSubstanceId);
                    classReq.PREX = GetPreExistingConditionDescription((PreExistingConditionLimitTypeEnum)item.PrimaryPlan.PreExistingConditionLimitationId);
                    if (item.BuyUpPlan != null)
                    {
                        classReq.VGSIPREX = GetPreExistingConditionDescription((PreExistingConditionLimitTypeEnum)item.BuyUpPlan.PreExistingConditionLimitationId);
                    }
                    classReq.Riders = GetRiderDetails(item.PrimaryPlan.Benefits, contractState.Value, isCompactState);
                    classReq.RiderCount = classReq.Riders.Count().ToString();

                    classReq.PlanDesignType = GetPlanDesignTypeDescription(planDesignRequestClass.ApprovedPlanDesignType);

                    classReq.PlanDesign = GetPlanDesignDescription(planDesignRequestClass);
                    string premiumPayer = planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType != null ? planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Description : string.Empty;
                    var premiumPayerAndTaxabilityType = planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType;
                    if (IsCostShare(premiumPayerAndTaxabilityType))
                    {
                        classReq.GSIPremiumPayer = premiumPayer;
                        var typeOfShareType = planDesignRequestClass.ApprovedTypeOfShareType;
                        var employerPaidPremium = planDesignRequestClass.ApprovedEmployerPaidPremium;
                        var costShareTaxabilityType = planDesignRequestClass.ApprovedCostShareTaxabilityType;
                        var employerPaysupto = planDesignRequestClass.ApprovedEmployerPaysupto;
                        AddCostShareGSIPlanTags(classReq, typeOfShareType, employerPaidPremium, costShareTaxabilityType, employerPaysupto);
                    }
                    else
                    {
                        //classReq.GSIPremiumPayer = planDesignRequestClass.ApprovedTaxabilityType != null ? premiumPayer + "/" + planDesignRequestClass.ApprovedTaxabilityType.GetDescription() : premiumPayer;

                        if (planDesignRequestClass.ApprovedTaxabilityType != null)
                        {
                            if (planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType != null && planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Id == (int)(ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid))
                            {
                                classReq.GSIPremiumPayer = premiumPayer + "/" + planDesignRequestClass.ApprovedTaxabilityType.GetDescription();
                            }
                            else
                            {
                                classReq.GSIPremiumPayer = premiumPayer;
                            }
                        }
                        else { classReq.GSIPremiumPayer = premiumPayer; }

                    }
                    classReq.MaximumIp = GetMaximumIPDescription(planDesignRequestClass.ApprovedPlanDesignType, planDesignRequestClass, unitOfWork);

                    var primaryPlanProduct = planDesignRequestClass.PlanDesignRequestClassProducts.FirstOrDefault(x => x.IsGSIPlanIndicator == false);
                    classReq.ParticipantionRequired = primaryPlanProduct.ParticipationPercentage + "%";

                    classReq.CaseLevelDiscountPercentage = GetDiscountPercentage(primaryPlanProduct);// item.PrimaryPlan.DiscountPercentage + "%"; // Take from the Illustration Request
                                                                                                     //classReq.CaseLevelDiscountPercentage = GetDiscountPercentage(primaryPlanProduct); // Wrong code
                    classReq.MaxReplacementPercent = (item.PrimaryPlan.ReplacementRatio != 0.0M) ? item.PrimaryPlan.ReplacementRatio.ToString() + "%" : "0 %";

                    var corporateSitusState = cmsCase.CaseUnderwritingRequests.FirstOrDefault(x => x.Case.Id == cmsCase.Id);
                    classReq.CorporateSitus = corporateSitusState != null ? corporateSitusState.StateType.ToString() : string.Empty;

                    if (item.HasBuyUpPlan)
                    {
                        classReq.VGBPDefinitionOfDisability = GetDefinitionOfDisablity((DefinitionOfDisabilityTypeEnum)item.BuyUpPlan.DefinitionOfDisabilityId); //((DefinitionOfDisabilityTypeEnum)item.BuyUpPlan.DefinitionOfDisabilityId).GetDescription();
                        classReq.VGBPEliminationPeriod = ((EliminationPeriodTypeEnum)item.BuyUpPlan.EliminationPeriodId).GetDescription();
                        classReq.VGBPBenefitPeriod = ((BenefitPeriodTypeEnum)item.BuyUpPlan.BenefitPeriodId).GetDescription();
                        classReq.BPMentalSubstance = GetMentalSubstanceDescription(item.BuyUpPlan.MentalSubstanceId);
                        classReq.VGBPRiders = GetRiderDetails(item.BuyUpPlan.Benefits, contractState.Value, isCompactState);
                        classReq.VGBPPlanDesignType = GetPlanDesignTypeDescription((PlanDesignTypeEnum?)planDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType);
                        classReq.VGBPPlanDesign = GetBuyUpPlanDesignDescription(planDesignRequestClass);
                        classReq.VGBPInsurableIncome = planDesignRequestClass.BuyUpInsurableIncomeDefinition;
                        classReq.BPMaximumIp = GetMaximumIPDescription((PlanDesignTypeEnum?)planDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType, planDesignRequestClass, unitOfWork);
                        classReq.BPParticipantionRequired = planDesignRequestClass.PlanDesignRequestClassProducts.FirstOrDefault(x => x.IsGSIPlanIndicator == true).ParticipationPercentage + "%";
                        classReq.VGBPMaxReplacementPercent = planDesignRequestClass.ApprovedGSIBuyUpReplacementPercentage.ToString() + "%";
                    }

                    var ltdCoverage = planDesignRequestClass.PlanDesignRequestClassLTDCoverage.FirstOrDefault(x => x.PlanDesignRequestClass.Id == item.TitanClassId);
                    if (ltdCoverage != null && (planDesignRequestClass.ApprovedPlanDesignType != PlanDesignTypeEnum.StandAloneIDIPlan || planDesignRequestClass.ApprovedPlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan))
                    {
                        classReq.IsGroupLTDDesign = true;
                        classReq.PercentOfBaseSalary = ltdCoverage.GroupLTDReplacementPercentage + "%";
                        classReq.BaseSalary = GetBaseSalaryDescription(planDesignRequestClass);
                        classReq.MaxSalaryK = string.Format("{0:C2}", ltdCoverage.GroupLTDCapAmount);

                        //classReq.MaxSalaryK = GetMaxSalaryK(ltdCoverage.GroupLTDCapAmount, classReq.TotalCombinedGSI, classReq.Riders);
                        string ltdPremiumPayer = ltdCoverage.PremiumAndTaxpayerLiabilityType != null ? ltdCoverage.PremiumAndTaxpayerLiabilityType.Description : string.Empty;
                        classReq.GroupLTDPremiumPayer = ltdCoverage.TypeOfPayType != null ? ltdPremiumPayer + "/" + ltdCoverage.TypeOfPayType.GetDescription() : ltdPremiumPayer;
                    }
                    else
                    {
                        //For StandAlonePlanIDI LTDCoverage not mandatory
                        classReq.IsGroupLTDDesign = false;
                        classReq.PercentOfBaseSalary = string.Empty;
                        classReq.BaseSalary = string.Empty;
                        classReq.MaxSalaryK = string.Empty;
                        classReq.GroupLTDPremiumPayer = string.Empty;
                    }

                    var billingModeType = unitOfWork.Repository<Participant>().Linq()
                        .FirstOrDefault(c => c.PlanDesignRequestClass.Id == item.TitanClassId).ListBillNumber?.BillingModeType;

                    billingModeType = billingModeType ?? BillingModeTypeEnum.Monthly;

                    List<CoveredEarningsTypeEnum?> coveredEarningsTypeEnum = new List<CoveredEarningsTypeEnum?>();
                    List<CoveredEarningsBonusOnlyTypeEnum?> coveredEarningsBonusOnlyTypeEnum = new List<CoveredEarningsBonusOnlyTypeEnum?>();

                    if (planDesignRequestClass.ApprovedCoveredEarningsType == null && planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.Count() > 0 && (planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.IsGSIPlanIndicator == false) == 1))
                    {
                        if (planDesignRequestClass.ApprovedPlanDesignType != PlanDesignTypeEnum.BonusOnlyPlan)
                        {
                            var customizedIDI = planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault();

                            if (customizedIDI.BaseSalaryPercentage.HasValue && !customizedIDI.BonusPercentage.HasValue
                                && !customizedIDI.CommissionPercentage.HasValue)
                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.BaseSalaryOnly);
                            }
                            else if (customizedIDI.BaseSalaryPercentage.HasValue && customizedIDI.BonusPercentage.HasValue
                                && !customizedIDI.CommissionPercentage.HasValue)

                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.BaseSalary_Bonus);
                            }
                            else if (customizedIDI.BaseSalaryPercentage.HasValue && customizedIDI.BonusPercentage.HasValue
                                && customizedIDI.CommissionPercentage.HasValue)

                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission);
                            }
                            else if (customizedIDI.BaseSalaryPercentage.HasValue && !customizedIDI.BonusPercentage.HasValue
                               && customizedIDI.CommissionPercentage.HasValue)

                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.BaseSalary_Commission);
                            }

                            if (customizedIDI.K1EarningsPercentage.HasValue)
                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.K_1Earnings);
                            }
                            if (customizedIDI.OtherIncomePercentage.HasValue)
                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.Other);
                            }
                            classReq.IDIInsurableIncome = planDesignRequestClass.InsurableIncomeDefinition;
                            classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(coveredEarningsTypeEnum, null, item.HasBuyUpPlan, insurableIncomeColumnNames);
                            classReq.Employees = GetEmployees(item.TitanClassId, coveredEarningsTypeEnum, null, item, unitOfWork, responses, illustrationParticipants,
                                ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, false);
                            classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, coveredEarningsTypeEnum, null, item.HasBuyUpPlan);
                        }
                        else
                        {
                            var customizedIDI = planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault();
                            coveredEarningsBonusOnlyTypeEnum = BuildCoveredEarningsBonusOnlyType(customizedIDI);
                            classReq.IDIInsurableIncome = planDesignRequestClass.InsurableIncomeDefinition;
                            classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan, insurableIncomeColumnNames);
                            classReq.Employees = GetEmployees(item.TitanClassId, null, coveredEarningsBonusOnlyTypeEnum, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, false);
                            classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan);
                        }
                    }
                    else if (planDesignRequestClass.ApprovedCoveredEarningsType != null)
                    {
                        classReq.IDIInsurableIncome = planDesignRequestClass.InsurableIncomeDefinition;
                        coveredEarningsTypeEnum.Add(planDesignRequestClass.ApprovedCoveredEarningsType);
                        classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(coveredEarningsTypeEnum, null, item.HasBuyUpPlan, insurableIncomeColumnNames);
                        classReq.Employees = GetEmployees(item.TitanClassId, coveredEarningsTypeEnum, null, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, false);
                        classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, coveredEarningsTypeEnum, null, item.HasBuyUpPlan);
                    }
                    else if (planDesignRequestClass.ApprovedCoveredEarningsBonusOnlyType == null && planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.Count() > 0 && (planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.Count(c => c.IsGSIPlanIndicator == false) == 1))
                    {
                        var customizedIDI = planDesignRequestClass.PDRClassCustomizedIDIInsurableIncomes.FirstOrDefault();
                        coveredEarningsBonusOnlyTypeEnum = BuildCoveredEarningsBonusOnlyType(customizedIDI);
                        classReq.IDIInsurableIncome = planDesignRequestClass.InsurableIncomeDefinition;
                        classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan, insurableIncomeColumnNames);
                        classReq.Employees = GetEmployees(item.TitanClassId, null, coveredEarningsBonusOnlyTypeEnum, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, false);
                        classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan);
                    }
                    else if (planDesignRequestClass.ApprovedCoveredEarningsBonusOnlyType != null)
                    {
                        classReq.IDIInsurableIncome = planDesignRequestClass.InsurableIncomeDefinition;
                        coveredEarningsBonusOnlyTypeEnum.Add(planDesignRequestClass.ApprovedCoveredEarningsBonusOnlyType);
                        classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan, insurableIncomeColumnNames);
                        classReq.Employees = GetEmployees(item.TitanClassId, null, coveredEarningsBonusOnlyTypeEnum, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, false);
                        classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan);
                    }
                    else
                    {   //For Flat Benefit plan type
                        if (ltdCoverage != null)
                        {
                            coveredEarningsTypeEnum.Add(ltdCoverage.GroupLTDCoveredEarningsType);
                            classReq.IDIInsurableIncome = GetInsurableIncomeDefinitionForFlatBenefit(ltdCoverage, null, false);
                        }

                        classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(coveredEarningsTypeEnum, null, item.HasBuyUpPlan, insurableIncomeColumnNames);
                        classReq.Employees = GetEmployees(item.TitanClassId, coveredEarningsTypeEnum, null, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, false);
                        classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, coveredEarningsTypeEnum, null, item.HasBuyUpPlan);
                    }

                    if (item.HasBuyUpPlan)
                    {
                        classReq.GLTDandIDIBenefitSummaryColumnNames = GetGSIBenefitSummaryColumnNames(item.PrimaryPlan.Benefits.Concat(item.BuyUpPlan.Benefits).ToList(), true, contractState.Value, planDesignRequestClass.ApprovedPlanDesignType, gLTDandIDIBenefitSummaryColumnNames, isCompactState, isReEnrollmentCase, planDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType);
                        if (planDesignRequestClass.ApprovedPlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                            illustrationDocumentRequest.AnnualRetirementContributions = "Yes";
                        classReq.ProviderChoiceMonthlyPremiumColumnNames = GetProviderChoiceMonthlyPremiumColumnNames(item.PrimaryPlan.Benefits, item.BuyUpPlan.Benefits, contractState.Value,
                            planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType, providerChoiceMonthlyPremiumColumnNames, isCompactState, isReEnrollmentCase, billingModeType, planDesignRequestClass.ApprovedPlanDesignType);
                        classReq.TotalBenefitSummaries = GetTotalBenefitSummaries(item.PrimaryPlan.Benefits.Concat(item.BuyUpPlan.Benefits).ToList(), classReq, item.HasBuyUpPlan, planDesignRequestClass.ApprovedPlanDesignType, isReEnrollmentCase);
                        classReq.TotalMonthlyBenefits = GetTotalMonthlyBenefits(classReq, item.PrimaryPlan.Benefits.Concat(item.BuyUpPlan.Benefits).ToList(), item.HasBuyUpPlan, isReEnrollmentCase);
                    }
                    else
                    {
                        classReq.GLTDandIDIBenefitSummaryColumnNames = GetGSIBenefitSummaryColumnNames(item.PrimaryPlan.Benefits, false, contractState.Value, planDesignRequestClass.ApprovedPlanDesignType, gLTDandIDIBenefitSummaryColumnNames, isCompactState, isReEnrollmentCase);
                        if (planDesignRequestClass.ApprovedPlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                            illustrationDocumentRequest.AnnualRetirementContributions = "Yes";
                        classReq.ProviderChoiceMonthlyPremiumColumnNames = GetProviderChoiceMonthlyPremiumColumnNames(item.PrimaryPlan.Benefits, null, contractState.Value,
                            planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType, providerChoiceMonthlyPremiumColumnNames, isCompactState, isReEnrollmentCase, billingModeType, planDesignRequestClass.ApprovedPlanDesignType);
                        classReq.TotalBenefitSummaries = GetTotalBenefitSummaries(item.PrimaryPlan.Benefits, classReq, item.HasBuyUpPlan, planDesignRequestClass.ApprovedPlanDesignType, isReEnrollmentCase);
                        classReq.TotalMonthlyBenefits = GetTotalMonthlyBenefits(classReq, item.PrimaryPlan.Benefits, item.HasBuyUpPlan, isReEnrollmentCase);
                    }

                    illustrationDocumentRequest.Classes.Add(classReq);
                }
            }

            Log.TraceFormat("-PopulateXmlFromPDRClass");
            return illustrationDocumentRequest;
        }

        private IllustrationDocumentRequest PopulateXmlFromPDRSoldClass(IllustrationDocumentRequest illustrationDocumentRequest, IUnitOfWork unitOfWork, List<IllustrationRequestClass> illustrationRequestClass, Case cmsCase, List<PremiumCalculatorResponse> responses, List<IllustrationParticipantDto> illustrationParticipants, bool isCompactState)
        {
            Log.TraceFormat("+PopulateXmlFromPDRSoldClass");
            var contractState = GetContractState(cmsCase);
            var illustrationParticipantIds = illustrationParticipants.Select(a => a.Participant.Id).ToList();
            bool isReEnrollmentCase = unitOfWork.Repository<AnnualReview>().Linq().Any(i => i.Case.Id == cmsCase.Id);

            illustrationDocumentRequest.IsReEnrollmentCase = isReEnrollmentCase;
            int underInsuredEmployeeCount = 0;
            int participantCount = 0;

            foreach (var item in illustrationRequestClass)
            {
                InsurableIncomeColumnNames insurableIncomeColumnNames = new InsurableIncomeColumnNames();
                GLTDandIDIBenefitSummaryColumnNames gLTDandIDIBenefitSummaryColumnNames = new GLTDandIDIBenefitSummaryColumnNames();
                ProviderChoiceMonthlyPremiumColumnNames providerChoiceMonthlyPremiumColumnNames = new ProviderChoiceMonthlyPremiumColumnNames();

                var planDesignRequestSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == item.TitanClassId && c.IsActive);
                var planDesignRequestSoldClassLTDCoverage = unitOfWork.Repository<PDRSoldClassLTDCoverage>().Linq().FirstOrDefault(c => c.PDRSoldClass.Id == planDesignRequestSoldClass.Id);

                var eligibilityConfigurationClassDto = new EligibilityConfigurationDto { PlanDesignRequestClassId = item.TitanClassId };
                eligibilityConfigurationClassDto = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationClassDto);
                var minimumBenefitAmount = eligibilityConfigurationClassDto.MinimumBenefitAmount;

                var splittedParticipantsIds = illustrationParticipantIds.ChunkBy(1000);

                foreach (var participantIdsSet in splittedParticipantsIds)
                {
                    var participants = unitOfWork.Repository<Participant>().Linq().Where(c => participantIdsSet.Contains(c.Id) && c.PlanDesignRequestClass.Id == item.TitanClassId).ToList();

                    if (participants.Any())
                    {
                        underInsuredEmployeeCount += participants.Where(q => q.LTDCalculatedAmount == planDesignRequestSoldClassLTDCoverage.GroupLTDCapAmount).Count();
                    }
                }

                if (planDesignRequestSoldClass != null)
                {
                    var primaryplan = planDesignRequestSoldClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                    var buyupPlan = planDesignRequestSoldClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                    var classReq = new IllustrationDocumentClassRequest();

                    if (primaryplan.PlanDesignType != PlanDesignTypeEnum.StandAloneIDIPlan && primaryplan.PlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan)
                    {
                        var programSummary = new ProgramSummary();
                        if (planDesignRequestSoldClassLTDCoverage != null)// For StandAloneIDI and RPP plan LTD coverage is not mandatory, so UnderInsuredEmployeeCount may be empty
                        {
                            programSummary.UnderInsuredEmployeeCount = Convert.ToString(underInsuredEmployeeCount);
                        }
                        else
                        {
                            programSummary.UnderInsuredEmployeeCount = string.Empty;
                        }

                        if (primaryplan.PremiumPayerAndTaxabilityType.Id != (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable || primaryplan.PremiumPayerAndTaxabilityType.Id != (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                        {
                            programSummary.TieredOptionsFlag = "Yes";
                        }
                        if (primaryplan.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid || primaryplan.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.MandatoryPartnerPlan_Non_Taxable)
                        {
                            programSummary.TieredOptionsFlag = "No";
                        }

                        illustrationDocumentRequest.ProgramSummaries.Add(programSummary);
                    }

                    classReq.MaxReplacementPercent = (item.PrimaryPlan.ReplacementRatio != 0.0M) ? item.PrimaryPlan.ReplacementRatio.ToString() + "%" : "0 %";
                    classReq.ClassName = item.TitanClassName;
                    classReq.MaxGSIOffer = item.PrimaryPlan.GSIAmount.ToString();
                    if (buyupPlan != null)
                    {
                        classReq.ERPaidGSIMax = item.PrimaryPlan.GSIAmount.ToString();
                        classReq.VGSIBuyUpMax = item.BuyUpPlan.GSIAmount.ToString();
                        //classReq.TotalCombinedGSI = (item.PrimaryPlan.GSIAmount + item.BuyUpPlan.GSIAmount).ToString();
                        classReq.TotalCombinedGSI = item.BuyUpPlan.TotalMaxGSIAmount != null ? item.BuyUpPlan.TotalMaxGSIAmount.ToString() : item.PrimaryPlan.TotalMaxGSIAmount.ToString();
                    }

                    classReq.DefinitionOfDisability = GetDefinitionOfDisablity((DefinitionOfDisabilityTypeEnum)item.PrimaryPlan.DefinitionOfDisabilityId);// ((DefinitionOfDisabilityTypeEnum)item.PrimaryPlan.DefinitionOfDisabilityId).GetDescription();
                    classReq.EliminationPeriod = ((EliminationPeriodTypeEnum)item.PrimaryPlan.EliminationPeriodId).GetDescription();
                    classReq.BenefitPeriod = ((BenefitPeriodTypeEnum)item.PrimaryPlan.BenefitPeriodId).GetDescription();
                    classReq.MentalSubstance = GetMentalSubstanceDescription(item.PrimaryPlan.MentalSubstanceId);
                    classReq.PREX = GetPreExistingConditionDescription((PreExistingConditionLimitTypeEnum)item.PrimaryPlan.PreExistingConditionLimitationId);
                    if (buyupPlan != null)
                    {
                        classReq.VGSIPREX = GetPreExistingConditionDescription((PreExistingConditionLimitTypeEnum)item.BuyUpPlan.PreExistingConditionLimitationId);
                    }
                    classReq.Riders = GetRiderDetails(item.PrimaryPlan.Benefits, contractState.Value, isCompactState);
                    classReq.RiderCount = classReq.Riders.Count().ToString();

                    classReq.PlanDesignType = GetPlanDesignTypeDescription(primaryplan.PlanDesignType);
                    classReq.PlanDesign = GetSoldPlanDesignDescription(primaryplan);
                    string premiumPayer = primaryplan.PremiumPayerAndTaxabilityType != null ? primaryplan.PremiumPayerAndTaxabilityType.Description : string.Empty;
                    var premiumPayerAndTaxabilityType = primaryplan.PremiumPayerAndTaxabilityType;
                    if (IsCostShare(premiumPayerAndTaxabilityType))
                    {
                        classReq.GSIPremiumPayer = premiumPayer;
                        var typeOfShareType = primaryplan.TypeOfShareType;
                        var employerPaidPremium = primaryplan.EmployerPaidPremium;
                        var costShareTaxabilityType = primaryplan.CostShareTaxabilityType;
                        var employerPaysupto = primaryplan.EmployerPaysupto;
                        AddCostShareGSIPlanTags(classReq, typeOfShareType, employerPaidPremium, costShareTaxabilityType, employerPaysupto);
                    }
                    else
                    {
                        //classReq.GSIPremiumPayer = primaryplan.TaxabilityType != null ? premiumPayer + "/" + primaryplan.TaxabilityType.GetDescription() : premiumPayer;

                        if (primaryplan.TaxabilityType != null)
                        {
                            if (primaryplan.PremiumPayerAndTaxabilityType != null && primaryplan.PremiumPayerAndTaxabilityType.Id == (int)(ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid))
                            {
                                classReq.GSIPremiumPayer = premiumPayer + "/" + primaryplan.TaxabilityType.GetDescription();
                            }
                            else
                            {
                                classReq.GSIPremiumPayer = premiumPayer;
                            }
                        }
                        else
                        {
                            classReq.GSIPremiumPayer = premiumPayer;
                        }
                    }
                    classReq.MaximumIp = GetMaximumIPDescription(primaryplan.PlanDesignType, primaryplan.PDRSoldClass.PlanDesignRequestClass, unitOfWork);
                    classReq.ParticipantionRequired = primaryplan.ParticipationPercentage + "%";

                    //classReq.CaseLevelDiscountPercentage = item.PrimaryPlan.DiscountPercentage + "%"; // Take from the Illustration Request
                    classReq.CaseLevelDiscountPercentage = GetDiscountPercentageForSoldClass(primaryplan);

                    var corporateSitusState = cmsCase.CaseUnderwritingRequests.FirstOrDefault(x => x.Case.Id == cmsCase.Id);
                    classReq.CorporateSitus = corporateSitusState != null ? corporateSitusState.StateType.ToString() : string.Empty;
                    var ltdCoverageSold = planDesignRequestSoldClass.PDRSoldClassLTDCoverage.FirstOrDefault(x => x.PDRSoldClass.PlanDesignRequestClass.Id == item.TitanClassId);
                    if (ltdCoverageSold != null && (primaryplan.PlanDesignType != PlanDesignTypeEnum.StandAloneIDIPlan || primaryplan.PlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan))
                    {
                        classReq.IsGroupLTDDesign = true;
                        classReq.PercentOfBaseSalary = ltdCoverageSold.GroupLTDReplacementPercentage + "%";
                        classReq.BaseSalary = GetSoldBaseSalaryDescription(planDesignRequestSoldClass);
                        classReq.MaxSalaryK = string.Format("{0:C2}", ltdCoverageSold.GroupLTDCapAmount);
                        //classReq.MaxSalaryK = GetMaxSalaryK(ltdCoverageSold.GroupLTDCapAmount, classReq.TotalCombinedGSI, classReq.Riders);

                        string ltdPremiumPayer = ltdCoverageSold.PremiumAndTaxpayerLiabilityType != null ? ltdCoverageSold.PremiumAndTaxpayerLiabilityType.Description : string.Empty;
                        classReq.GroupLTDPremiumPayer = ltdCoverageSold.TypeOfPayType != null ? ltdPremiumPayer + "/" + ltdCoverageSold.TypeOfPayType.GetDescription() : ltdPremiumPayer;
                        //classReq.GroupLTDPremiumPayer = "Employee Paid / Non-Taxable";
                    }
                    else
                    {
                        //For StandAlonePlanIDI LTDCoverage not mandatory
                        classReq.IsGroupLTDDesign = false;
                        classReq.PercentOfBaseSalary = string.Empty;
                        classReq.BaseSalary = string.Empty;
                        classReq.MaxSalaryK = string.Empty;
                        classReq.GroupLTDPremiumPayer = string.Empty;
                    }

                    if (buyupPlan != null)
                    {
                        classReq.VGBPDefinitionOfDisability = GetDefinitionOfDisablity((DefinitionOfDisabilityTypeEnum)item.BuyUpPlan.DefinitionOfDisabilityId); //((DefinitionOfDisabilityTypeEnum)item.BuyUpPlan.DefinitionOfDisabilityId).GetDescription();
                        classReq.VGBPEliminationPeriod = ((EliminationPeriodTypeEnum)item.BuyUpPlan.EliminationPeriodId).GetDescription();
                        classReq.VGBPBenefitPeriod = ((BenefitPeriodTypeEnum)item.BuyUpPlan.BenefitPeriodId).GetDescription();
                        classReq.BPMentalSubstance = GetMentalSubstanceDescription(item.BuyUpPlan.MentalSubstanceId);
                        classReq.VGBPRiders = GetRiderDetails(item.BuyUpPlan.Benefits, contractState.Value, isCompactState);
                        classReq.VGBPPlanDesignType = GetPlanDesignTypeDescription(buyupPlan.PlanDesignType);
                        classReq.VGBPPlanDesign = GetSoldBuyUpPlanDesignDescription(buyupPlan);
                        classReq.VGBPInsurableIncome = buyupPlan.InsurableIncomeDefinition;
                        classReq.BPMaximumIp = GetMaximumIPDescription(buyupPlan.PlanDesignType, primaryplan.PDRSoldClass.PlanDesignRequestClass, unitOfWork);
                        classReq.BPParticipantionRequired = buyupPlan.ParticipationPercentage + "%";
                        classReq.VGBPMaxReplacementPercent = buyupPlan.ReplacementPercentage.ToString() + "%";
                    }

                    var billingModeType = unitOfWork.Repository<Participant>().Linq()
                        .FirstOrDefault(c => c.PlanDesignRequestClass.Id == item.TitanClassId).ListBillNumber?.BillingModeType;

                    billingModeType = billingModeType ?? BillingModeTypeEnum.Monthly;

                    List<CoveredEarningsTypeEnum?> coveredEarningsTypeEnum = new List<CoveredEarningsTypeEnum?>();
                    List<CoveredEarningsBonusOnlyTypeEnum?> coveredEarningsBonusOnlyTypeEnum = new List<CoveredEarningsBonusOnlyTypeEnum?>();

                    if (primaryplan.CoveredEarningsType == null && primaryplan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.Count() > 0)
                    {
                        if (primaryplan.PlanDesignType != PlanDesignTypeEnum.BonusOnlyPlan)
                        {
                            var customizedIDI = primaryplan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.FirstOrDefault();

                            if (customizedIDI.BaseSalaryPercentage.HasValue && !customizedIDI.BonusPercentage.HasValue
                                && !customizedIDI.CommissionPercentage.HasValue)
                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.BaseSalaryOnly);
                            }
                            else if (customizedIDI.BaseSalaryPercentage.HasValue && customizedIDI.BonusPercentage.HasValue
                                && !customizedIDI.CommissionPercentage.HasValue)

                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.BaseSalary_Bonus);
                            }
                            else if (customizedIDI.BaseSalaryPercentage.HasValue && customizedIDI.BonusPercentage.HasValue
                                && customizedIDI.CommissionPercentage.HasValue)

                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission);
                            }
                            else if (customizedIDI.BaseSalaryPercentage.HasValue && !customizedIDI.BonusPercentage.HasValue
                               && customizedIDI.CommissionPercentage.HasValue)
                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.BaseSalary_Commission);
                            }

                            if (customizedIDI.K1EarningsPercentage.HasValue)
                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.K_1Earnings);
                            }
                            if (customizedIDI.OtherIncomePercentage.HasValue)
                            {
                                coveredEarningsTypeEnum.Add(CoveredEarningsTypeEnum.Other);
                            }
                            classReq.IDIInsurableIncome = primaryplan.InsurableIncomeDefinition;
                            classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(coveredEarningsTypeEnum, null, item.HasBuyUpPlan, insurableIncomeColumnNames);
                            classReq.Employees = GetEmployees(item.TitanClassId, coveredEarningsTypeEnum, null, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, isReEnrollmentCase);
                            classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, coveredEarningsTypeEnum, null, item.HasBuyUpPlan);
                        }
                        else
                        {
                            var customizedIDI = primaryplan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.FirstOrDefault();
                            coveredEarningsBonusOnlyTypeEnum = BuildSoldCoveredEarningsBonusOnlyType(customizedIDI);
                            classReq.IDIInsurableIncome = primaryplan.InsurableIncomeDefinition;
                            classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan, insurableIncomeColumnNames);
                            classReq.Employees = GetEmployees(item.TitanClassId, null, coveredEarningsBonusOnlyTypeEnum, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, isReEnrollmentCase);
                            classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan);
                        }
                    }
                    else if (primaryplan.CoveredEarningsType != null)
                    {
                        classReq.IDIInsurableIncome = primaryplan.InsurableIncomeDefinition;
                        coveredEarningsTypeEnum.Add(primaryplan.CoveredEarningsType);
                        classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(coveredEarningsTypeEnum, null, item.HasBuyUpPlan, insurableIncomeColumnNames);
                        classReq.Employees = GetEmployees(item.TitanClassId, coveredEarningsTypeEnum, null, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, isReEnrollmentCase);
                        classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, coveredEarningsTypeEnum, null, item.HasBuyUpPlan);
                    }
                    else if (primaryplan.CoveredEarningsBonusOnlyType == null && primaryplan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.Count() > 0)
                    {
                        var customizedIDI = primaryplan.PDRSoldClassPlanCustomizedIDIInsurableIncomes.FirstOrDefault();
                        coveredEarningsBonusOnlyTypeEnum = BuildSoldCoveredEarningsBonusOnlyType(customizedIDI);
                        classReq.IDIInsurableIncome = primaryplan.InsurableIncomeDefinition;
                        classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan, insurableIncomeColumnNames);
                        classReq.Employees = GetEmployees(item.TitanClassId, null, coveredEarningsBonusOnlyTypeEnum, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, isReEnrollmentCase);
                        classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan);
                    }
                    else if (primaryplan.CoveredEarningsBonusOnlyType != null)
                    {
                        classReq.IDIInsurableIncome = primaryplan.InsurableIncomeDefinition;
                        coveredEarningsBonusOnlyTypeEnum.Add(primaryplan.CoveredEarningsBonusOnlyType);
                        classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan, insurableIncomeColumnNames);
                        classReq.Employees = GetEmployees(item.TitanClassId, null, coveredEarningsBonusOnlyTypeEnum, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, isReEnrollmentCase);
                        classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, null, coveredEarningsBonusOnlyTypeEnum, item.HasBuyUpPlan);
                    }
                    else
                    {
                        //For Flat Benefit plan type
                        if (ltdCoverageSold != null)
                        {
                            coveredEarningsTypeEnum.Add(ltdCoverageSold.GroupLTDCoveredEarningsType);
                            classReq.IDIInsurableIncome = GetInsurableIncomeDefinitionForFlatBenefit(null, ltdCoverageSold, true);
                        }
                        classReq.InsurableIncomeColumnNames = GetInsurableIncomeColumnNames(coveredEarningsTypeEnum, null, item.HasBuyUpPlan, insurableIncomeColumnNames);
                        classReq.Employees = GetEmployees(item.TitanClassId, coveredEarningsTypeEnum, null, item, unitOfWork, responses, illustrationParticipants, ref participantCount, minimumBenefitAmount, classReq.CaseLevelDiscountPercentage, isReEnrollmentCase);
                        classReq.TotalInsurableIncomes = GetTotalInsurableIncomes(classReq, coveredEarningsTypeEnum, null, item.HasBuyUpPlan);
                    }

                    if (item.HasBuyUpPlan)
                    {
                        List<IllustrationRequestBenefit> benefitsList = new List<IllustrationRequestBenefit>();
                        if(item.BuyUpPlan.Benefits != null)
                        {
                            benefitsList = item.PrimaryPlan.Benefits.Concat(item.BuyUpPlan?.Benefits).ToList();
                        }
                        else {
                            benefitsList = item.PrimaryPlan.Benefits.ToList();
                        }

                        classReq.GLTDandIDIBenefitSummaryColumnNames = GetGSIBenefitSummaryColumnNames(benefitsList, true, contractState.Value, primaryplan.PlanDesignType, gLTDandIDIBenefitSummaryColumnNames, isCompactState, isReEnrollmentCase, (PlanDesignGSITypeEnum?)buyupPlan.PlanDesignType);
                        if (primaryplan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                            illustrationDocumentRequest.AnnualRetirementContributions = "Yes";
                        classReq.ProviderChoiceMonthlyPremiumColumnNames = GetProviderChoiceMonthlyPremiumColumnNames(item.PrimaryPlan.Benefits, item.BuyUpPlan.Benefits,
                            contractState.Value, primaryplan.PremiumPayerAndTaxabilityType, providerChoiceMonthlyPremiumColumnNames, isCompactState, isReEnrollmentCase, billingModeType, primaryplan.PlanDesignType);
                        classReq.TotalBenefitSummaries = GetTotalBenefitSummaries(benefitsList, classReq, true, primaryplan.PlanDesignType, isReEnrollmentCase);
                        classReq.TotalMonthlyBenefits = GetTotalMonthlyBenefits(classReq, benefitsList, item.HasBuyUpPlan, isReEnrollmentCase);
                    }
                    else
                    {
                        classReq.GLTDandIDIBenefitSummaryColumnNames = GetGSIBenefitSummaryColumnNames(item.PrimaryPlan.Benefits, false, contractState.Value, primaryplan.PlanDesignType, gLTDandIDIBenefitSummaryColumnNames, isCompactState, isReEnrollmentCase);
                        if (primaryplan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                            illustrationDocumentRequest.AnnualRetirementContributions = "Yes";
                        classReq.ProviderChoiceMonthlyPremiumColumnNames = GetProviderChoiceMonthlyPremiumColumnNames(item.PrimaryPlan.Benefits, null, contractState.Value,
                            primaryplan.PremiumPayerAndTaxabilityType, providerChoiceMonthlyPremiumColumnNames, isCompactState, isReEnrollmentCase, billingModeType, primaryplan.PlanDesignType);
                        classReq.TotalBenefitSummaries = GetTotalBenefitSummaries(item.PrimaryPlan.Benefits, classReq, false, primaryplan.PlanDesignType, isReEnrollmentCase);
                        classReq.TotalMonthlyBenefits = GetTotalMonthlyBenefits(classReq, item.PrimaryPlan.Benefits, item.HasBuyUpPlan, isReEnrollmentCase);
                    }

                    illustrationDocumentRequest.Classes.Add(classReq);

                }
            }

            Log.TraceFormat("-PopulateXmlFromPDRSoldClass");

            return illustrationDocumentRequest;
        }

        public string GetMaxSalaryK(decimal gltdAmount, string totalCombinedGSI, List<Rider> riders)
        {
            decimal totalBenefitAmount = 0.0M;
            decimal totalCombinedGSIAmount = 0.0m;

            if (!string.IsNullOrEmpty(totalCombinedGSI))
            {
                decimal.TryParse(totalCombinedGSI.Replace("$", ""), out totalCombinedGSIAmount);
            }

            decimal totalRiderBenefitAmount = riders.Sum(c =>
            {
                decimal riderBenefitAmount = 0.0m;
                if (string.IsNullOrEmpty(c.RiderBenefitAmt))
                {
                    return riderBenefitAmount;
                }
                decimal.TryParse(c.RiderBenefitAmt.Replace("$", ""), out riderBenefitAmount);
                return riderBenefitAmount;
            });
            totalBenefitAmount = gltdAmount + totalCombinedGSIAmount + totalRiderBenefitAmount;

            return string.Format("{0:C2}", totalBenefitAmount);
        }

        public StateTypeEnum? GetContractState(Case cmsCase)
        {
            StateTypeEnum? state = StateTypeEnum.UN;
            if (cmsCase.CaseUnderwritingRequests != null && cmsCase.CaseUnderwritingRequests.Count > 0)
            {
                state = cmsCase.CaseUnderwritingRequests.FirstOrDefault().StateType;
            }
            return state;
        }

        public List<Rider> GetRiderDetails(List<IllustrationRequestBenefit> benefits, StateTypeEnum contractState, bool isCompactState)
        {
            Log.TraceFormat("+GetRiderDetails");

            List<Rider> riderDetails = new List<Rider>();

            if (benefits != null)
            {
                foreach (var rider in benefits)
                {
                    if (rider.BenefitId != 0)
                    {
                        var riderBenefit = new Rider();
                        switch ((BenefitGroupTypeEnum)rider.BenefitGroupTypeId)
                        {
                            case BenefitGroupTypeEnum.PartialDisability:
                                riderBenefit.RiderFullName = string.Format("{0}", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                                riderBenefit.RiderEP = "";
                                riderBenefit.RiderBT = "";
                                riderBenefit.RiderBenefitAmt = "";
                                break;

                            case BenefitGroupTypeEnum.CatastrophicDisabilityBenefit:

                                riderBenefit.RiderFullName = string.Format("{0} Benefit Rider (CAT)", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                                riderBenefit.RiderEP = "";
                                riderBenefit.RiderBT = "";
                                riderBenefit.RiderBenefitAmt = string.Format("{0:C2}", rider.Amount);

                                if (isCompactState)
                                {
                                    if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                    {
                                        riderBenefit.RiderFullName = "Severe Disability Rider";
                                    }
                                }

                                break;

                            case BenefitGroupTypeEnum.CostOfLivingAdjustment:

                                riderBenefit.RiderFullName = string.Format("{0} (COLA)", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                                riderBenefit.RiderEP = "";
                                riderBenefit.RiderBT = "";
                                riderBenefit.RiderBenefitAmt = "";
                                break;

                            case BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit:

                                riderBenefit.RiderFullName = "Retirement Protection Plus (RPP)";
                                riderBenefit.RiderEP = string.Format("{0} Day EP", ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Contains("Days") ? ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Replace("Days", "") : ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription());
                                riderBenefit.RiderBT = "";
                                riderBenefit.RiderBenefitAmt = string.Format("{0:C2}", rider.Amount);
                                break;

                            case BenefitGroupTypeEnum.StudentLoanProtectionRider:

                                riderBenefit.RiderFullName = "Student Loan Protection Rider (SLP)";
                                riderBenefit.RiderEP = string.Format("{0} Day EP", ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Contains("Days") ? ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Replace("Days", "") : ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription());
                                riderBenefit.RiderBT = string.Format("{0} Year BT", ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription().Contains("Years") ? ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription().Replace("Years", "") : ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription());
                                riderBenefit.RiderBenefitAmt = string.Format("{0:C2}", rider.Amount);
                                break;

                            case BenefitGroupTypeEnum.SupplementalBenefit:

                                riderBenefit.RiderFullName = "Supplemental Benefit Term Rider (SBT)";
                                riderBenefit.RiderEP = string.Format("{0} Day EP", ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Contains("Days") ? ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Replace("Days", "") : ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription());
                                riderBenefit.RiderBT = string.Format("{0} Year BT", ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription().Contains("Years") ? ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription().Replace("Years", "") : ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription());
                                riderBenefit.RiderBenefitAmt = string.Format("{0:C2}", rider.Amount);
                                break;

                            case BenefitGroupTypeEnum.UnemploymentPremiumWaiver:

                                riderBenefit.RiderFullName = string.Format("{0}", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                                riderBenefit.RiderEP = "";
                                riderBenefit.RiderBT = "";
                                riderBenefit.RiderBenefitAmt = "";
                                break;

                            case BenefitGroupTypeEnum.Endorsement:

                                riderBenefit.RiderFullName = string.Format("{0}", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                                riderBenefit.RiderEP = "";
                                riderBenefit.RiderBT = "";
                                riderBenefit.RiderBenefitAmt = "";
                                break;

                            case BenefitGroupTypeEnum.ExtendedBenefits:

                                riderBenefit.RiderFullName = string.Format("{0}", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                                riderBenefit.RiderEP = "";
                                riderBenefit.RiderBT = "";
                                riderBenefit.RiderBenefitAmt = "";
                                break;
                        }
                        riderDetails.Add(riderBenefit);
                    }
                }

            }
            Log.TraceFormat("-GetRiderDetails");
            return riderDetails;
        }

        private void AddCostShareGSIPlanTags(IllustrationDocumentClassRequest classReq, TypeOfShareTypeEnum? typeOfShareType, decimal? employerPaidPremiumPercentage, CostShareTaxabilityType costShareTaxabilityType, decimal? employerPaysupto)
        {
            var taxableNonTaxable = string.Empty;
            if (costShareTaxabilityType != null)
            {
                if (costShareTaxabilityType.Id == (int)CostShareTaxabilityTypeEnum.EmployerPaidPortionTaxable)
                {
                    taxableNonTaxable = "Taxable";
                }
                else if (costShareTaxabilityType.Id == (int)CostShareTaxabilityTypeEnum.EmployerPaidPortionNonTaxable)
                {
                    taxableNonTaxable = "Non-Taxable";
                }
            }

            classReq.CostShareTaxable = taxableNonTaxable;

            if (typeOfShareType != null && typeOfShareType == TypeOfShareTypeEnum.PercentofPremium)
            {
                classReq.CostSharePercentage = string.Format("{0:P2}", employerPaidPremiumPercentage / 100.00m);
            }
            else if (typeOfShareType != null && typeOfShareType == TypeOfShareTypeEnum.PremiumAmount)
            {
                classReq.CostSharePremiumAmount = string.Format("{0:C2}", employerPaysupto);
            }

        }

        public bool IsCostShare(ExistingCoveragePremiumAndTaxpayerLiabilityType premiumPayerAndTaxabilityType)
        {
            return premiumPayerAndTaxabilityType != null && premiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare;
        }

        private List<IllustrationDocumentEmployeeRequest> GetEmployees(int pdrClassId, List<CoveredEarningsTypeEnum?> coveredEarningsTypes, List<CoveredEarningsBonusOnlyTypeEnum?> CoveredEarningsBonusOnlyType, IllustrationRequestClass request,
            IUnitOfWork unitOfWork, List<PremiumCalculatorResponse> responses, List<IllustrationParticipantDto> illustrationParticipants,
            ref int participantCount, decimal? minimumBenefitAmount, string caseLevelDiscountPercentage, bool isReEnrollmentCase)
        {
            Log.TraceFormat("+GetEmployees");

            //isGLTDRiderAssigned = false;

            TypeOfShareTypeEnum? typeOfShareType = null;
            decimal? employerPaidPremium = null;
            decimal? employeePaidPremium = null;
            decimal? employerPaysupto = null;
            var isCostShare = false;
            PlanDesignTypeEnum? planDesignType = null;
            PlanDesignGSITypeEnum? planDesignGSIType = null;
            var planDesignRequestSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == request.TitanClassId && c.IsActive);
            var planDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == request.TitanClassId);

            if (planDesignRequestSoldClass == null)
            {
                if (IsCostShare(planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType))
                {
                    isCostShare = true;
                    typeOfShareType = planDesignRequestClass.ApprovedTypeOfShareType;
                    employerPaidPremium = planDesignRequestClass.ApprovedEmployerPaidPremium;
                    employeePaidPremium = planDesignRequestClass.ApprovedEmployeePaidPremium;
                    employerPaysupto = planDesignRequestClass.ApprovedEmployerPaysupto;
                }
                planDesignType = planDesignRequestClass.ApprovedPlanDesignType;
                planDesignGSIType = planDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType;
            }
            else
            {
                var primaryPlan = planDesignRequestSoldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                if (IsCostShare(primaryPlan.PremiumPayerAndTaxabilityType))
                {
                    isCostShare = true;
                    typeOfShareType = primaryPlan.TypeOfShareType;
                    employerPaidPremium = primaryPlan.EmployerPaidPremium;
                    employeePaidPremium = primaryPlan.EmployeePaidPremium;
                    employerPaysupto = primaryPlan.EmployerPaysupto;
                }
                planDesignType = primaryPlan.PlanDesignType;
            }

            var employees = new List<IllustrationDocumentEmployeeRequest>();

            var participantIds = illustrationParticipants.Select(c => c.Participant.Id).ToList();
            var splittedParticipantsIds = participantIds.ChunkBy(1500);

            foreach (var chunkedIds in splittedParticipantsIds)
            {
                var participants = unitOfWork.Repository<Participant>().Linq().Where(c => c.PlanDesignRequestClass.Id == pdrClassId && c.IsEligible == true && chunkedIds.Contains(c.Id));

                foreach (var participant in participants)
                {
                    var participantPrimaryPremiumResponse = responses.FirstOrDefault(c => c.ParticipantId == participant.Id && c.HasVGSIBuyUp == false);

                    var employeeRequestPremium = new IllustrationDocumentEmployeeRequest();
                    employeeRequestPremium.Employee = participant.FirstName + " " + participant.LastName;
                    employeeRequestPremium.EmployeeId = participant.EmployeeId;
                    employeeRequestPremium.JobTitle = (!string.IsNullOrEmpty(participant.JobTitle)) ? participant.JobTitle : " ";
                    employeeRequestPremium.Age = participant.IssueAge.HasValue ? participant.IssueAge.ToString() : " ";
                    employeeRequestPremium.OccupationClass = (!string.IsNullOrEmpty(participant.OccupationClassDescription)) ? participant.OccupationClassDescription : " ";
                    employeeRequestPremium.State = participant.ContractState.HasValue ? Convert.ToString(participant.ContractState) : " ";
                    employeeRequestPremium.Gender = (!string.IsNullOrEmpty(participant.Gender)) ? participant.Gender : "Unknown";
                    employeeRequestPremium.InsurableIncomes = GetInsurableIncomeValues(coveredEarningsTypes, participant, CoveredEarningsBonusOnlyType, request.HasBuyUpPlan);

                    employeeRequestPremium.CSVClassName = request.TitanClassName;
                    employeeRequestPremium.CSVCaseLevelDiscountPercentage = caseLevelDiscountPercentage;

                    //Populate for Primary Plan
                    var providerChoiceMonthlyPremiums = new ProviderChoiceMonthlyPremiums();
                    var glTDandIDIBenefitBenefitSummaries = new GLTDandIDIBenefitBenefitSummaries();

                    var basePlanBenefits = illustrationParticipants.FirstOrDefault(c => c.Participant.Id == participant.Id)?.ParticipantPlans?.FirstOrDefault(c => !c.IsBuyUpPlan).Benefits;
                    if (participantPrimaryPremiumResponse != null)
                    {
                        employeeRequestPremium.GLTDandIDIBenefitBenefitSummaries = GetGSIBenefitSummaryValues(basePlanBenefits, participant, glTDandIDIBenefitBenefitSummaries, false,
                                                                                   participantPrimaryPremiumResponse, illustrationParticipants, request, planDesignType, minimumBenefitAmount,
                                                                                   isReEnrollmentCase, planDesignGSIType);

                        employeeRequestPremium.ProviderChoiceMonthlyPremiums = GetProviderChoiceMonthlyPremiumValues(basePlanBenefits, participant, participantPrimaryPremiumResponse,
                            false, providerChoiceMonthlyPremiums, request,
                            employeeRequestPremium.GLTDandIDIBenefitBenefitSummaries, isReEnrollmentCase);
                    }
                    //Populate for BuyUp Plan
                    if (request.HasBuyUpPlan)
                    {
                        var participantBuyUpPremiumResponse = responses.FirstOrDefault(c => c.ParticipantId == participant.Id && c.HasVGSIBuyUp == true);
                        if (participantBuyUpPremiumResponse != null)
                        {
                            var buyUpPlanBenefits = illustrationParticipants.FirstOrDefault(c => c.Participant.Id == participant.Id).ParticipantPlans.FirstOrDefault(c => c.IsBuyUpPlan).Benefits;
                            if (planDesignRequestSoldClass != null)
                            {
                                var buyupPlan = planDesignRequestSoldClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp).PlanDesignType;
                                employeeRequestPremium.GLTDandIDIBenefitBenefitSummaries = GetGSIBenefitSummaryValues(basePlanBenefits != null ? basePlanBenefits.Concat(buyUpPlanBenefits).ToList() : buyUpPlanBenefits.ToList(),
                                participant, glTDandIDIBenefitBenefitSummaries, true, participantBuyUpPremiumResponse,
                                illustrationParticipants, request, planDesignType, minimumBenefitAmount, isReEnrollmentCase, (PlanDesignGSITypeEnum?)buyupPlan);
                            }
                            else
                            {
                                var buyupPlan = planDesignGSIType;
                                employeeRequestPremium.GLTDandIDIBenefitBenefitSummaries = GetGSIBenefitSummaryValues(basePlanBenefits != null ? basePlanBenefits.Concat(buyUpPlanBenefits).ToList() : buyUpPlanBenefits.ToList(), participant,
                                    glTDandIDIBenefitBenefitSummaries, true, participantBuyUpPremiumResponse, illustrationParticipants, request, planDesignType, minimumBenefitAmount, isReEnrollmentCase, buyupPlan);
                            }
                            employeeRequestPremium.ProviderChoiceMonthlyPremiums = GetProviderChoiceMonthlyPremiumValues(buyUpPlanBenefits, participant, participantBuyUpPremiumResponse,
                                                                                    true, providerChoiceMonthlyPremiums, request,
                                                                                    employeeRequestPremium.GLTDandIDIBenefitBenefitSummaries, isReEnrollmentCase);
                        }
                    }

                    employeeRequestPremium.AnnualMonthlyBenefit = employeeRequestPremium?.ProviderChoiceMonthlyPremiums?.NonBPTotalAnnualPremiumAmt;// GetAnnualMonthlyPremium(employeeRequestPremium.ProviderChoiceMonthlyPremiums);

                    if (isCostShare)
                    {
                        AddCostSharePremiums(employeeRequestPremium.ProviderChoiceMonthlyPremiums, typeOfShareType, employerPaidPremium, employeePaidPremium, employerPaysupto);
                    }

                    employees.Add(employeeRequestPremium);
                }
            }

            //Calculate the Sum of Insurabel incomes amount
            decimal totalAmtResult = 0.0m;
            var employeeTotalAmtSum = string.Format("{0:C2}", employees.Sum(c =>
            {

                if (string.IsNullOrEmpty(c.InsurableIncomes.TotalAmt))
                {
                    return totalAmtResult;
                }
                decimal.TryParse(c.InsurableIncomes.TotalAmt.Replace("$", ""), out totalAmtResult);
                return totalAmtResult;

            }));
            decimal salaryAmtResult = 0.0m;
            var employeeSalaryAmtSum = string.Format("{0:C2}", employees.Sum(c =>
            {

                if (string.IsNullOrEmpty(c.InsurableIncomes.SalaryAmt))
                {
                    return salaryAmtResult;
                }
                decimal.TryParse(c.InsurableIncomes.SalaryAmt.Replace("$", ""), out salaryAmtResult);
                return salaryAmtResult;

            }));
            decimal k1IncomeAmtResult = 0.0m;
            var k1IncomeAmtSum = string.Format("{0:C2}", employees.Sum(c =>
            {

                if (string.IsNullOrEmpty(c.InsurableIncomes.K1IncomeAmt))
                {
                    return k1IncomeAmtResult;
                }
                decimal.TryParse(c.InsurableIncomes.K1IncomeAmt.Replace("$", ""), out k1IncomeAmtResult);
                return k1IncomeAmtResult;

            }));
            decimal otherIncomeAmtResult = 0.0m;
            var otherIncomeAmtSum = string.Format("{0:C2}", employees.Sum(c =>
            {

                if (string.IsNullOrEmpty(c.InsurableIncomes.OtherIncomeAmt))
                {
                    return otherIncomeAmtResult;
                }
                decimal.TryParse(c.InsurableIncomes.OtherIncomeAmt.Replace("$", ""), out otherIncomeAmtResult);
                return otherIncomeAmtResult;

            }));
            if (planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                decimal GLTDRetirmentAmountResult = 0.0m;
                employees = employees.OrderByDescending(c =>
                {
                    decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.RetirmentContributionsAmt.Replace("$", ""), out GLTDRetirmentAmountResult);
                    return GLTDRetirmentAmountResult;
                }).ToList();
            }
            else
            {
                //Sort the insurable incomes amount
                if (totalAmtResult == 0.0m && salaryAmtResult > 0.0m)
                {
                    decimal salaryAmountResult = 0.0m;
                    employees = employees.OrderByDescending(c =>
                    {
                        decimal.TryParse(c.InsurableIncomes.SalaryAmt.Replace("$", ""), out salaryAmountResult);
                        return salaryAmountResult;
                    }).ToList();
                }
                else if (salaryAmtResult == 0.0m)
                {
                    if (totalAmtResult > 0.0m)
                    {
                        decimal totalAmt = 0.0m;
                        employees = employees.OrderByDescending(c =>
                        {
                            decimal.TryParse(c.InsurableIncomes.TotalAmt.Replace("$", ""), out totalAmt);
                            return totalAmt;
                        }).ToList();
                    }
                    else if (k1IncomeAmtResult > 0.0m)
                    {
                        decimal kIncomeAmtResult = 0.0m;
                        employees = employees.OrderByDescending(c =>
                        {
                            decimal.TryParse(c.InsurableIncomes.K1IncomeAmt.Replace("$", ""), out kIncomeAmtResult);
                            return kIncomeAmtResult;
                        }).ToList();
                    }
                    else if (otherIncomeAmtResult > 0.0m)
                    {
                        decimal otherAmountResult = 0.0m;
                        employees = employees.OrderByDescending(c =>
                        {
                            decimal.TryParse(c.InsurableIncomes.OtherIncomeAmt.Replace("$", ""), out otherAmountResult);
                            return otherAmountResult;
                        }).ToList();
                    }

                }
                else
                {
                    decimal totalAmountResult = 0.0m;
                    employees = employees.OrderByDescending(c =>
                    {
                        decimal.TryParse(c.InsurableIncomes.TotalAmt.Replace("$", ""), out totalAmountResult);
                        return totalAmountResult;
                    }).ToList();
                }
            }
            foreach (var employee in employees)
            {
                employee.ParticipantCount = participantCount + 1;
                participantCount++;
            }
            Log.TraceFormat("-GetEmployees");

            return employees;
        }

        private void AddCostSharePremiums(ProviderChoiceMonthlyPremiums providerChoiceMonthlyPremiums, TypeOfShareTypeEnum? typeOfShareType, decimal? employerPaidPremium, decimal? employeePaidPremium, decimal? employerPaysupto)
        {
            decimal? monthlyERPremium = 0.0m;
            decimal? annualERPremium = 0.0m;
            decimal? monthlyEEPremium = 0.0m;
            decimal? annualEEPremium = 0.0m;
            decimal monthlyPremium = 0.0m;
            decimal annaulPremium = 0.0m;

            decimal.TryParse(providerChoiceMonthlyPremiums.TotalPremiumAmt.Replace("$", ""), out monthlyPremium);
            decimal.TryParse(providerChoiceMonthlyPremiums.NonBPTotalAnnualPremiumAmt.Replace("$", ""), out annaulPremium);

            if (typeOfShareType == TypeOfShareTypeEnum.PremiumAmount)
            {
                if (employerPaysupto < monthlyPremium)
                {
                    monthlyERPremium = employerPaysupto;
                    monthlyEEPremium = monthlyPremium - employerPaysupto;
                }
                else
                {
                    monthlyERPremium = monthlyPremium;
                    monthlyEEPremium = 0.0m;
                }
                annualERPremium = monthlyERPremium * 12;
                annualEEPremium = monthlyEEPremium * 12;
            }
            else if (typeOfShareType == TypeOfShareTypeEnum.PercentofPremium)
            {
                monthlyERPremium = (monthlyPremium * (employerPaidPremium / 100.00m)).Value.Roundoff(2);
                monthlyEEPremium = monthlyERPremium.HasValue ? (monthlyPremium - monthlyERPremium) : 0.0m;

                annualERPremium = (annaulPremium * (employerPaidPremium / 100.00m)).Value.Roundoff(2);
                annualEEPremium = annualERPremium.HasValue ? (annaulPremium - annualERPremium) : 0.0m;
            }

            providerChoiceMonthlyPremiums.ERPaidPremiumAmtMonthly = string.Format("{0:C2}", monthlyERPremium);
            providerChoiceMonthlyPremiums.EEPaidPremiumAmtMonthly = string.Format("{0:C2}", monthlyEEPremium);
            providerChoiceMonthlyPremiums.ERPaidPremiumAmtAnnual = string.Format("{0:C2}", annualERPremium);
            providerChoiceMonthlyPremiums.EEPaidPremiumAmtAnnual = string.Format("{0:C2}", annualEEPremium);
        }

        private List<IllustrationDocumentEmployeeRequest> GetIneligibleEmployees(List<IllustrationRequestClass> illustrationRequestClass, IUnitOfWork unitOfWork)
        {
            Log.TraceFormat("+GetIneligibleEmployees");
            var employees = new List<IllustrationDocumentEmployeeRequest>();
            var listIds = illustrationRequestClass.Select(c => c.TitanClassId).ToList();
            var participants = unitOfWork.Repository<Participant>().Linq().Where(c => listIds.Contains(c.PlanDesignRequestClass.Id)
            && c.IsEligible == false && c.IneligibleReason != (InEligibleReasonTypeEnum.NoLongerInGroup).GetDescription()
            && c.IneligibleReason != (InEligibleReasonTypeEnum.ActivePolicyNoLongerInGroup).GetDescription()
            && c.IneligibleReason != (InEligibleReasonTypeEnum.NotonNewCensus).GetDescription());
            foreach (var participant in participants)
            {
                var employeeRequestPremium = new IllustrationDocumentEmployeeRequest();
                employeeRequestPremium.Employee = participant.FirstName + " " + participant.LastName;
                employeeRequestPremium.JobTitle = participant.JobTitle;
                employeeRequestPremium.IssueAge = participant.IssueAge.HasValue ? participant.IssueAge.ToString() : string.Empty;
                employeeRequestPremium.Gender = (!string.IsNullOrEmpty(participant.Gender)) ? participant.Gender : "Unknown";
                employeeRequestPremium.Reason = participant.IneligibleReason + (participant.OtherReason != null ? participant.OtherReason : string.Empty);
                employees.Add(employeeRequestPremium);
            }
            Log.TraceFormat("-GetIneligibleEmployees");
            return employees;
        }

        private TotalInsurableIncomes GetTotalInsurableIncomes(IllustrationDocumentClassRequest classReq, List<CoveredEarningsTypeEnum?> coveredEarningsTypes, List<CoveredEarningsBonusOnlyTypeEnum?> CoveredEarningsBonusOnlyType, bool hasBuyUpPlan)
        {
            var totalInsurableIncomes = new TotalInsurableIncomes();
            decimal grandTotalAmt = 0;

            if (coveredEarningsTypes == null && CoveredEarningsBonusOnlyType == null)
            {
                decimal totalAmt = classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    decimal.TryParse(c.InsurableIncomes.TotalAmt.Replace("$", ""), out result);
                    return result;
                });
                grandTotalAmt += totalAmt;
                totalInsurableIncomes.GrandTotalAmt = string.Format("{0:C2}", totalAmt);
            }

            if (coveredEarningsTypes != null)
            {
                foreach (var coveredEarningsType in coveredEarningsTypes)
                {
                    if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalaryOnly)
                    {
                        decimal salarySum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.SalaryAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalSalaryAmt = string.Format("{0:C2}", salarySum);
                        grandTotalAmt += salarySum;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalary_Bonus)
                    {
                        decimal salarySum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.SalaryAmt.Replace("$", ""), out result);
                            return result;
                        });
                        decimal bonusSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.BonusAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalSalaryAmt = string.Format("{0:C2}", salarySum);
                        totalInsurableIncomes.TotalBonusAmt = string.Format("{0:C2}", bonusSum);
                        grandTotalAmt += salarySum + bonusSum;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission)
                    {
                        decimal salarySum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.SalaryAmt.Replace("$", ""), out result);
                            return result;
                        });
                        decimal bonusSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.BonusAmt.Replace("$", ""), out result);
                            return result;
                        });
                        decimal commissionSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.CommissionsAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalSalaryAmt = string.Format("{0:C2}", salarySum);
                        totalInsurableIncomes.TotalBonusAmt = string.Format("{0:C2}", bonusSum);
                        totalInsurableIncomes.TotalCommissionsAmt = string.Format("{0:C2}", commissionSum);
                        grandTotalAmt += salarySum + bonusSum + commissionSum;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalary_Commission)
                    {
                        decimal salarySum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.SalaryAmt.Replace("$", ""), out result);
                            return result;
                        });
                        decimal commissionSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.CommissionsAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalSalaryAmt = string.Format("{0:C2}", salarySum);
                        totalInsurableIncomes.TotalCommissionsAmt = string.Format("{0:C2}", commissionSum);
                        grandTotalAmt += salarySum + commissionSum;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.K_1Earnings)
                    {
                        decimal k1Sum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.K1IncomeAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalK1IncomeAmt = string.Format("{0:C2}", k1Sum);
                        grandTotalAmt += k1Sum;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.Other)
                    {
                        decimal otherIncomeSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.OtherIncomeAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalOtherIncomeAmt = string.Format("{0:C2}", otherIncomeSum);
                        grandTotalAmt += otherIncomeSum;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.W_2Income)
                    {
                        decimal w2IncomeSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.W2IncomeAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalW2IncomeAmt = string.Format("{0:C2}", w2IncomeSum);
                        grandTotalAmt += w2IncomeSum;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.TotalCompensation)
                    {
                        decimal totalCompensation = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.TotalCompensationAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalCompensationAmt = string.Format("{0:C2}", totalCompensation);
                        grandTotalAmt += totalCompensation;
                    }
                }
            }

            if (CoveredEarningsBonusOnlyType != null)
            {
                foreach (var coveredEarningsBonusOnlyType in CoveredEarningsBonusOnlyType)
                {
                    if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.Bonus)
                    {
                        decimal bonusSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.BonusAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalBonusAmt = string.Format("{0:C2}", bonusSum);
                        grandTotalAmt += bonusSum;
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission)
                    {
                        decimal bonusSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.BonusAmt.Replace("$", ""), out result);
                            return result;
                        });
                        decimal commissionSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.CommissionsAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalBonusAmt = string.Format("{0:C2}", bonusSum);
                        totalInsurableIncomes.TotalCommissionsAmt = string.Format("{0:C2}", commissionSum);
                        grandTotalAmt += (bonusSum + commissionSum);
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.Commissions)
                    {
                        decimal commissionSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.CommissionsAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalCommissionsAmt = string.Format("{0:C2}", commissionSum);
                        grandTotalAmt += commissionSum;
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.K_1Earnings)
                    {
                        decimal k1Sum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.K1IncomeAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalK1IncomeAmt = string.Format("{0:C2}", k1Sum);
                        grandTotalAmt += k1Sum;
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus)
                    {
                        decimal bonusSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.BonusAmt.Replace("$", ""), out result);
                            return result;
                        });
                        decimal commissionSum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.CommissionsAmt.Replace("$", ""), out result);
                            return result;
                        });
                        decimal k1Sum = classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.InsurableIncomes.K1IncomeAmt.Replace("$", ""), out result);
                            return result;
                        });
                        totalInsurableIncomes.TotalBonusAmt = string.Format("{0:C2}", bonusSum);
                        totalInsurableIncomes.TotalCommissionsAmt = string.Format("{0:C2}", commissionSum);
                        totalInsurableIncomes.TotalK1IncomeAmt = string.Format("{0:C2}", k1Sum);
                        grandTotalAmt += (bonusSum + commissionSum + k1Sum);
                    }
                }
            }

            if (hasBuyUpPlan)
            {
                decimal totalERPaidGSIBaseAmtSum = classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    decimal.TryParse(c.InsurableIncomes.ERPaidGSIBaseAmt.Replace("$", ""), out result);
                    return result;
                });
                decimal totalVGSIBuyUpAmt = classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    decimal.TryParse(c.InsurableIncomes.VGSIBuyUpAmt.Replace("$", ""), out result);
                    return result;
                });
                totalInsurableIncomes.TotalERPaidGSIBaseAmt = string.Format("{0:C2}", totalERPaidGSIBaseAmtSum);
                totalInsurableIncomes.TotalVGSIBuyUpAmt = string.Format("{0:C2}", totalVGSIBuyUpAmt);

                grandTotalAmt += (totalERPaidGSIBaseAmtSum + totalVGSIBuyUpAmt);

                totalInsurableIncomes.GrandTotalAmt = string.Format("{0:C2}", grandTotalAmt);
            }

            if (coveredEarningsTypes != null && grandTotalAmt > 0)
            {
                totalInsurableIncomes.GrandTotalAmt = string.Format("{0:C2}", grandTotalAmt);
            }
            else if (CoveredEarningsBonusOnlyType != null && grandTotalAmt > 0)
            {
                totalInsurableIncomes.GrandTotalAmt = string.Format("{0:C2}", grandTotalAmt);
            }

            return totalInsurableIncomes;
        }

        private TotalBenefitSummaries GetTotalBenefitSummaries(List<IllustrationRequestBenefit> benefits, IllustrationDocumentClassRequest classReq, bool hasBuyUpPlan, PlanDesignTypeEnum? planDesignType, bool isReEnrolledCase)
        {
            Log.TraceFormat("+GetTotalBenefitSummaries");

            var totalBenefitSummaries = new TotalBenefitSummaries();

            if (planDesignType != null && planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                totalBenefitSummaries.TotalAnnualRetirmentContributionsAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.RetirmentContributionsAmt != null
                                    ? c.GLTDandIDIBenefitBenefitSummaries.RetirmentContributionsAmt.Replace("$", "") : "", out result);
                    return result;
                }));

                if (isReEnrolledCase)
                {
                    totalBenefitSummaries.TotalExistingRPPBaseBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                    {
                        decimal result = 0.0m;
                        decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ExistingRPPBaseBenefitAmt != null
                                        ? c.GLTDandIDIBenefitBenefitSummaries.ExistingRPPBaseBenefitAmt.Replace("$", "") : "", out result);
                        return result;
                    }));

                    totalBenefitSummaries.TotalProposedRPPBaseBenefitIncreaseAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                    {
                        decimal result = 0.0m;
                        decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ProposedRPPBaseBenefitIncreaseAmt != null
                                        ? c.GLTDandIDIBenefitBenefitSummaries.ProposedRPPBaseBenefitIncreaseAmt.Replace("$", "") : "", out result);
                        return result;
                    }));


                    totalBenefitSummaries.TotalProposedRPPBaseBenefitNewAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                    {
                        decimal result = 0.0m;
                        decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ProposedRPPBaseBenefitNewAmt != null
                                        ? c.GLTDandIDIBenefitBenefitSummaries.ProposedRPPBaseBenefitNewAmt.Replace("$", "") : "", out result);
                        return result;
                    }));
                }
                else
                {
                    totalBenefitSummaries.TotalRPPBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                    {
                        decimal result = 0.0m;
                        decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.RPPBenefitAmt != null
                                        ? c.GLTDandIDIBenefitBenefitSummaries.RPPBenefitAmt.Replace("$", "") : "", out result);
                        return result;
                    }));
                }

                totalBenefitSummaries.TotalGSIBaseBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.GSIBaseBenefitAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.GSIBaseBenefitAmt.Replace("$", "") : "", out result);
                    return result;
                }));



                decimal totalAnnualRetirmentContributionsAmt = 0.0m;
                decimal.TryParse(totalBenefitSummaries.TotalAnnualRetirmentContributionsAmt.Replace("$", ""), out totalAnnualRetirmentContributionsAmt);

                decimal totalRppReplacePercentAmt = 0.0m;
                if (isReEnrolledCase)
                {
                    decimal.TryParse(totalBenefitSummaries.TotalExistingRPPBaseBenefitAmt != null ? totalBenefitSummaries.TotalExistingRPPBaseBenefitAmt.Replace("$", "") : "", out totalRppReplacePercentAmt);
                }
                else
                {
                    decimal.TryParse(totalBenefitSummaries.TotalRPPBenefitAmt != null ? totalBenefitSummaries.TotalRPPBenefitAmt.Replace("$", "") : "", out totalRppReplacePercentAmt);
                }
                totalBenefitSummaries.TotalRPPReplacePercent = totalRppReplacePercentAmt > 0.0m ? (string.Format("{0:P2}", ((totalRppReplacePercentAmt * 12) / totalAnnualRetirmentContributionsAmt).Roundoff(3))) : "";
            }
            else
            {
                if (isReEnrolledCase)
                {
                    totalBenefitSummaries.TotalExistingGSIBaseBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                    {
                        decimal result = 0.0m;
                        decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ExistingGSIBaseBenefitAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.ExistingGSIBaseBenefitAmt.Replace("$", "") : "", out result);
                        return result;
                    }));

                    totalBenefitSummaries.TotalProposedGSIBaseBenefitIncreaseAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                    {
                        decimal result = 0.0m;
                        decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ProposedGSIBaseBenefitIncreaseAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.ProposedGSIBaseBenefitIncreaseAmt.Replace("$", "") : "", out result);
                        return result;
                    }));

                    totalBenefitSummaries.TotalProposedGSIBaseBenefitNewAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                    {
                        decimal result = 0.0m;
                        decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ProposedGSIBaseBenefitNewAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.ProposedGSIBaseBenefitNewAmt.Replace("$", "") : "", out result);
                        return result;
                    }));
                }
            }


            if (classReq.TotalInsurableIncomes == null || classReq.TotalInsurableIncomes.GrandTotalAmt == null) return totalBenefitSummaries;

            decimal grandTotalAmount = 0.0m;

            if (hasBuyUpPlan)
            { decimal.TryParse(classReq.TotalInsurableIncomes.TotalVGSIBuyUpAmt.Replace("$", ""), out grandTotalAmount); }
            else
            { decimal.TryParse(classReq.TotalInsurableIncomes.GrandTotalAmt.Replace("$", ""), out grandTotalAmount); }


            totalBenefitSummaries.TotalGLTDBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
            {
                decimal result = 0.0m;
                decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.GLTDBenefitAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.GLTDBenefitAmt.Replace("$", "") : "", out result);
                return result;
            }));

            decimal totalGLTDReplacementPercentAmt = 0.0m;
            decimal.TryParse(totalBenefitSummaries.TotalGLTDBenefitAmt != null ? totalBenefitSummaries.TotalGLTDBenefitAmt.Replace("$", "") : "", out totalGLTDReplacementPercentAmt);
            if (grandTotalAmount > 0)
            {
                totalBenefitSummaries.TotalGLTDReplacePercentAmt = string.Format("{0:P2}", (totalGLTDReplacementPercentAmt * 12 / grandTotalAmount));
            }
            else
            {
                totalBenefitSummaries.TotalGLTDReplacePercentAmt = string.Format("{0:P2}", totalGLTDReplacementPercentAmt);
            }

            totalBenefitSummaries.TotalExistingIDICoverageAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
            {
                decimal result = 0.0m;
                decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ExistingIDICoverageAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.ExistingIDICoverageAmt.Replace("$", "") : "", out result);
                return result;
            }));
            totalBenefitSummaries.TotalGSIBaseBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
            {
                decimal result = 0.0m;
                decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.GSIBaseBenefitAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.GSIBaseBenefitAmt.Replace("$", "") : "", out result);
                return result;
            }));


            decimal totalGSIBaseBenefitAmt = 0.0m;
            decimal.TryParse(totalBenefitSummaries.TotalGSIBaseBenefitAmt != null ? totalBenefitSummaries.TotalGSIBaseBenefitAmt.Replace("$", "") : "", out totalGSIBaseBenefitAmt);
            if (totalGSIBaseBenefitAmt > 0 && grandTotalAmount > 0)
            {
                totalBenefitSummaries.TotalIDIBaseReplacePercentAmt = string.Format("{0:P2}", (totalGSIBaseBenefitAmt * 12 / grandTotalAmount));
            }
            else { totalBenefitSummaries.TotalIDIBaseReplacePercentAmt = string.Empty; }


            totalBenefitSummaries.TotalGLTDPlusIDIAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
            {
                decimal result = 0.0m;
                decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.TotalGLTDPlusIDIAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.TotalGLTDPlusIDIAmt.Replace("$", "") : "", out result);
                return result;
            }));



            decimal totalGLTDPlusIDIPercentAmt = 0.0m;
            decimal.TryParse(totalBenefitSummaries.TotalGLTDPlusIDIAmt != null ? totalBenefitSummaries.TotalGLTDPlusIDIAmt.Replace("$", "") : "", out totalGLTDPlusIDIPercentAmt);

            if (grandTotalAmount > 0)
            {
                totalBenefitSummaries.TotalGLTDPlusIDIPercentAmt = string.Format("{0:P2}", (totalGLTDPlusIDIPercentAmt * 12 / grandTotalAmount));
            }
            else { totalBenefitSummaries.TotalGLTDPlusIDIPercentAmt = string.Format("{0:P2}", totalGLTDPlusIDIPercentAmt); }



            if (hasBuyUpPlan)
            {
                totalBenefitSummaries.TotalERPaidGSIBaseBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (c.GLTDandIDIBenefitBenefitSummaries.ERPaidGSIBaseBenefitAmt != null)
                    {
                        decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ERPaidGSIBaseBenefitAmt.Replace("$", ""), out result);
                    }
                    return result;
                }));

                totalBenefitSummaries.TotalBuyUpGSIBaseBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (c.GLTDandIDIBenefitBenefitSummaries.BuyUpGSIBaseBenefitAmt != null)
                    {
                        decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.BuyUpGSIBaseBenefitAmt.Replace("$", ""), out result);
                    }
                    return result;
                }));
            }

            //if (!hasBuyUpPlan)
            //{
            foreach (var rider in benefits)
            {
                switch ((BenefitGroupTypeEnum)rider.BenefitGroupTypeId)
                {
                    case BenefitGroupTypeEnum.PartialDisability:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                        {
                            totalBenefitSummaries.TotalEnhancedPartialDisabilityAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (c.GLTDandIDIBenefitBenefitSummaries.EnhancedPartialDisabilityAmt != null)
                                {
                                    decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.EnhancedPartialDisabilityAmt.Replace("$", ""), out result);
                                }
                                return result;
                            }));
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicPartialDisabilityRider)
                        {
                            totalBenefitSummaries.TotalBasicPartialDisabilityAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (c.GLTDandIDIBenefitBenefitSummaries.BasicPartialDisabilityAmt != null)
                                {
                                    decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.BasicPartialDisabilityAmt.Replace("$", ""), out result);
                                }
                                return result;
                            }));

                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                        {
                            totalBenefitSummaries.TotalShortTermResidualDisabilityAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (c.GLTDandIDIBenefitBenefitSummaries.ShortTermResidualDisabilityAmt != null)
                                {
                                    decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ShortTermResidualDisabilityAmt.Replace("$", ""), out result);
                                }
                                return result;
                            }));
                        }
                        break;

                    case BenefitGroupTypeEnum.CatastrophicDisabilityBenefit:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                            totalBenefitSummaries.TotalEnhancedCATAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.EnhancedCATAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.EnhancedCATAmt.Replace("$", "") : "", out result);
                                return result;
                            }));
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                            totalBenefitSummaries.TotalBasicCATAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.BasicCATAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.BasicCATAmt.Replace("$", "") : "", out result);
                                return result;
                            }));
                        break;

                    case BenefitGroupTypeEnum.CostOfLivingAdjustment:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving3PercentCompound)
                        {
                            totalBenefitSummaries.TotalThreeCOLAAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (c.GLTDandIDIBenefitBenefitSummaries.ThreeCOLAAmt != null)
                                {
                                    decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.ThreeCOLAAmt.Replace("$", ""), out result);
                                }
                                return result;
                            }));
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                        {
                            totalBenefitSummaries.TotalSixCOLAAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (c.GLTDandIDIBenefitBenefitSummaries.SixCOLAAmt != null)
                                {
                                    decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.SixCOLAAmt.Replace("$", ""), out result);
                                }
                                return result;
                            }));
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving4YearDelayed)
                        {
                            totalBenefitSummaries.TotalFourYearDelayCOLAAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (c.GLTDandIDIBenefitBenefitSummaries.FourYearDelayCOLAAmt != null)
                                {
                                    decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.FourYearDelayCOLAAmt.Replace("$", ""), out result);
                                }
                                return result;
                            }));

                        }
                        break;
                    case BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit:

                        totalBenefitSummaries.TotalRPPBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.RPPBenefitAmt != null
                                            ? c.GLTDandIDIBenefitBenefitSummaries.RPPBenefitAmt.Replace("$", "") : "", out result);
                            return result;
                        }));
                        break;

                    case BenefitGroupTypeEnum.StudentLoanProtectionRider:

                        totalBenefitSummaries.TotalSLPBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.SLPBenefitAmt != null
                                ? c.GLTDandIDIBenefitBenefitSummaries.SLPBenefitAmt.Replace("$", "") : "", out result);
                            return result;
                        }));
                        break;

                    case BenefitGroupTypeEnum.SupplementalBenefit:

                        totalBenefitSummaries.TotalSBTBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.SBTBenefitAmt != null ? c.GLTDandIDIBenefitBenefitSummaries.SBTBenefitAmt.Replace("$", "") : "", out result);
                            return result;
                        }));
                        break;
                }

                switch ((BenefitTypeEnum)rider.BenefitId)
                {
                    case BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement:
                        totalBenefitSummaries.TotalSeriousIllnessBenefitAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            if (c.GLTDandIDIBenefitBenefitSummaries.SeriousIllnessBenefitAmt != null)
                            {
                                decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.SeriousIllnessBenefitAmt.Replace("$", ""), out result);
                            }
                            return result;
                        }));
                        break;

                    case BenefitTypeEnum.LumpSumIndemnityRider:
                        totalBenefitSummaries.TotalLumpSumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            if (c.GLTDandIDIBenefitBenefitSummaries.LumpSumAmt != null)
                            {
                                decimal.TryParse(c.GLTDandIDIBenefitBenefitSummaries.LumpSumAmt.Replace("$", ""), out result);
                            }
                            return result;
                        }));
                        break;

                }
            }

            decimal totalGLTDPlusIDIAmt = 0.0m;
            decimal totalBasicCATAmt = 0.0m;
            decimal totalEnhancedCATAmt = 0.0m;

            decimal.TryParse(totalBenefitSummaries.TotalGLTDPlusIDIAmt != null ? totalBenefitSummaries.TotalGLTDPlusIDIAmt.Replace("$", "") : "", out totalGLTDPlusIDIAmt);
            decimal.TryParse(totalBenefitSummaries.TotalBasicCATAmt != null ? totalBenefitSummaries.TotalBasicCATAmt.Replace("$", "") : "", out totalBasicCATAmt);
            decimal.TryParse(totalBenefitSummaries.TotalEnhancedCATAmt != null ? totalBenefitSummaries.TotalEnhancedCATAmt.Replace("$", "") : "", out totalEnhancedCATAmt);

            if (totalGLTDPlusIDIAmt > 0 && grandTotalAmount > 0 && (totalBasicCATAmt > 0 || totalEnhancedCATAmt > 0))
            {
                if (totalBasicCATAmt > 0)
                {
                    totalBenefitSummaries.TotalReplacementPercentAmt = string.Format("{0:P2}", ((totalGLTDPlusIDIAmt + totalBasicCATAmt) * 12 / grandTotalAmount));
                }
                else if (totalEnhancedCATAmt > 0)
                {
                    totalBenefitSummaries.TotalReplacementPercentAmt = string.Format("{0:P2}", ((totalGLTDPlusIDIAmt + totalEnhancedCATAmt) * 12 / grandTotalAmount));
                }
                else
                {
                    totalBenefitSummaries.TotalReplacementPercentAmt = string.Format("{0:P2}", ((totalGLTDPlusIDIAmt) * 12 / grandTotalAmount));
                }
            }
            else if (totalGLTDPlusIDIAmt > 0 && grandTotalAmount > 0 && (totalBasicCATAmt == 0 && totalEnhancedCATAmt == 0))
            {

                totalBenefitSummaries.TotalReplacementPercentAmt = string.Format("{0:P2}", ((totalGLTDPlusIDIAmt) * 12 / grandTotalAmount));

            }
            else
            {
                totalBenefitSummaries.TotalReplacementPercentAmt = "0%";
            }



            Log.TraceFormat("-GetTotalBenefitSummaries");

            return totalBenefitSummaries;
        }

        private TotalMonthlyBenefits GetTotalMonthlyBenefits(IllustrationDocumentClassRequest classReq, List<IllustrationRequestBenefit> benefits, bool hasBuyUpPlan, bool IsReEnrollmentCase)
        {
            Log.TraceFormat("+GetTotalMonthlyBenefits");
            TotalMonthlyBenefits totalMonthlyBenefits = new TotalMonthlyBenefits();

            if (classReq.Employees == null) return totalMonthlyBenefits;

            decimal totalBasePremiumAmt = classReq.Employees.Sum(c => c.ProviderChoiceMonthlyPremiums.BasePremiumAmt  != null ? decimal.Parse(c.ProviderChoiceMonthlyPremiums.BasePremiumAmt.Replace("$", "")) : 0.0m);

            if (totalBasePremiumAmt < 0)
            {
                totalMonthlyBenefits.TotalBasePremiumAmt = "$0.00";
            }
            else
            {
                totalMonthlyBenefits.TotalBasePremiumAmt = string.Format("{0:C2}", totalBasePremiumAmt);
            }
            decimal totalMonthlyPremiumAmt = totalBasePremiumAmt;
            //Defect MCRT-1719 - Fix To calculate the Base Total Monthly Premium Amount

            if (IsReEnrollmentCase)
            {

                totalMonthlyBenefits.TotalInforceModalPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.InforceModalPremiumAmt))
                    {
                        return result;
                    }
                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.InforceModalPremiumAmt.Replace("$", ""), out result);
                    return result;
                }));

                totalMonthlyBenefits.TotalProposedModalIncreaseAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.ProposedModalIncreaseAmt))
                    {
                        return result;
                    }
                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.ProposedModalIncreaseAmt.Replace("$", ""), out result);
                    return result;
                }));

                totalMonthlyBenefits.GrandTotalModalPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.TotalModalPremiumAmt))
                    {
                        return result;
                    }
                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.TotalModalPremiumAmt.Replace("$", ""), out result);
                    return result;
                }));

                totalMonthlyBenefits.GrandTotalAnnualPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.TotalAnnualPremiumAmt))
                    {
                        return result;
                    }
                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.TotalAnnualPremiumAmt.Replace("$", ""), out result);
                    return result;
                }));
            }
            else
            {
                totalMonthlyBenefits.TotalNonBPTotalMonthlyPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.TotalPremiumAmt))
                    {
                        return result;
                    }
                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.TotalPremiumAmt.Replace("$", ""), out result);
                    return result;
                }));
            }

            totalMonthlyBenefits.TotalNonBPTotalAnnualPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
            {
                decimal result = 0.0m;
                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.NonBPTotalAnnualPremiumAmt))
                {
                    return result;
                }
                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.NonBPTotalAnnualPremiumAmt.Replace("$", ""), out result);
                return result;
            }));


            if (hasBuyUpPlan)
            {

                totalMonthlyBenefits.TotalBuyUpBaseBenefitPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.BuyUpBaseBenefitPremiumAmt))
                    {
                        return result;
                    }
                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.BuyUpBaseBenefitPremiumAmt.Replace("$", ""), out result);
                    totalMonthlyPremiumAmt += result;
                    return result;
                }));

                totalMonthlyBenefits.TotalVGBPTotalMonthlyPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPTotalMonthlyPremiumAmt))
                    {
                        return result;
                    }
                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPTotalMonthlyPremiumAmt.Replace("$", ""), out result);
                    return result;
                }));

                totalMonthlyBenefits.TotalVGBPTotalAnnualPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                {
                    decimal result = 0.0m;
                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPTotalAnnualPremiumAmt))
                    {
                        return result;
                    }
                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPTotalAnnualPremiumAmt.Replace("$", ""), out result);
                    return result;
                }));

            }

            decimal grandTotalPremiumAmt = totalBasePremiumAmt;
            foreach (var rider in benefits)
            {
                switch ((BenefitGroupTypeEnum)rider.BenefitGroupTypeId)
                {
                    case BenefitGroupTypeEnum.PartialDisability:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                        {
                            totalMonthlyBenefits.TotalEnhancedPartialDisabilityPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.EnhancedPartialDisabilityPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.EnhancedPartialDisabilityPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));

                            if (hasBuyUpPlan)
                            {
                                totalMonthlyBenefits.TotalVGBPEnhancedPartialDisabilityPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                                {
                                    decimal result = 0.0m;
                                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPEnhancedPartialDisabilityPremiumAmt))
                                    {
                                        return result;
                                    }
                                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPEnhancedPartialDisabilityPremiumAmt.Replace("$", ""), out result);
                                    grandTotalPremiumAmt += result;
                                    totalMonthlyPremiumAmt += result;
                                    return result;
                                }));
                            }

                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicPartialDisabilityRider)
                        {
                            totalMonthlyBenefits.TotalBasicPartialDisabilityPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.BasicPartialDisabilityPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.BasicPartialDisabilityPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));

                            if (hasBuyUpPlan)
                            {
                                totalMonthlyBenefits.TotalVGBPBasicPartialDisabilityPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                                {
                                    decimal result = 0.0m;
                                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPBasicPartialDisabilityPremiumAmt))
                                    {
                                        return result;
                                    }
                                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPBasicPartialDisabilityPremiumAmt.Replace("$", ""), out result);
                                    grandTotalPremiumAmt += result;
                                    totalMonthlyPremiumAmt += result;
                                    return result;
                                }));
                            }

                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                        {
                            totalMonthlyBenefits.TotalShortTermResidualDisabilityPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.ShortTermResidualDisabilityPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.ShortTermResidualDisabilityPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));

                            if (hasBuyUpPlan)
                            {
                                totalMonthlyBenefits.TotalVGBPShortTermResidualDisabilityPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                                {
                                    decimal result = 0.0m;
                                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPShortTermResidualDisabilityPremiumAmt))
                                    {
                                        return result;
                                    }
                                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPShortTermResidualDisabilityPremiumAmt.Replace("$", ""), out result);
                                    grandTotalPremiumAmt += result;
                                    totalMonthlyPremiumAmt += result;
                                    return result;
                                }));
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.CatastrophicDisabilityBenefit:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                        {
                            totalMonthlyBenefits.TotalEnhancedCATPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.EnhancedCATPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.EnhancedCATPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));
                            if (hasBuyUpPlan)
                            {
                                totalMonthlyBenefits.TotalVGBPEnhancedCATPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                                {
                                    decimal result = 0.0m;
                                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPEnhancedCATPremiumAmt))
                                    {
                                        return result;
                                    }
                                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPEnhancedCATPremiumAmt.Replace("$", ""), out result);
                                    grandTotalPremiumAmt += result;
                                    totalMonthlyPremiumAmt += result;
                                    return result;
                                }));

                            }
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                        {
                            totalMonthlyBenefits.TotalBaseCATPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.BaseCATPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.BaseCATPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));
                            if (hasBuyUpPlan)
                            {
                                totalMonthlyBenefits.TotalVGBPBasicCATPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                                {
                                    decimal result = 0.0m;
                                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPBasicCATPremiumAmt))
                                    {
                                        return result;
                                    }
                                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPBasicCATPremiumAmt.Replace("$", ""), out result);
                                    grandTotalPremiumAmt += result;
                                    totalMonthlyPremiumAmt += result;
                                    return result;
                                }));

                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.CostOfLivingAdjustment:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving3PercentCompound)
                        {
                            totalMonthlyBenefits.TotalThreeCOLAPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.ThreeCOLAPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.ThreeCOLAPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));

                            if (hasBuyUpPlan)
                            {
                                totalMonthlyBenefits.TotalVGBPThreeCOLAPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                                {
                                    decimal result = 0.0m;
                                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPThreeCOLAPremiumAmt))
                                    {
                                        return result;
                                    }
                                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPThreeCOLAPremiumAmt.Replace("$", ""), out result);
                                    grandTotalPremiumAmt += result;
                                    totalMonthlyPremiumAmt += result;
                                    return result;
                                }));
                            }
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                        {
                            totalMonthlyBenefits.TotalSixCOLAPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.SixCOLAPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.SixCOLAPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));

                            if (hasBuyUpPlan)
                            {
                                totalMonthlyBenefits.TotalVGBPSixCOLAPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                                {
                                    decimal result = 0.0m;
                                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPSixCOLAPremiumAmt))
                                    {
                                        return result;
                                    }
                                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPSixCOLAPremiumAmt.Replace("$", ""), out result);
                                    grandTotalPremiumAmt += result;
                                    totalMonthlyPremiumAmt += result;
                                    return result;
                                }));
                            }
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving4YearDelayed)
                        {
                            totalMonthlyBenefits.TotalFourYearCOLAPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.FourYearCOLAPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.FourYearCOLAPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));

                            if (hasBuyUpPlan)
                            {
                                totalMonthlyBenefits.TotalVGBPFourYearCOLAPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                                {
                                    decimal result = 0.0m;
                                    if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPFourYearCOLAPremiumAmt))
                                    {
                                        return result;
                                    }
                                    decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPFourYearCOLAPremiumAmt.Replace("$", ""), out result);
                                    grandTotalPremiumAmt += result;
                                    totalMonthlyPremiumAmt += result;
                                    return result;
                                }));
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit:

                        totalMonthlyBenefits.TotalRPPPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.RPPPremiumAmt))
                            {
                                return result;
                            }
                            decimal.TryParse(c.ProviderChoiceMonthlyPremiums.RPPPremiumAmt.Replace("$", ""), out result);
                            grandTotalPremiumAmt += result;
                            totalMonthlyPremiumAmt += result;
                            return result;
                        }));
                        if (hasBuyUpPlan)
                        {
                            totalMonthlyBenefits.TotalVGBPRPPPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPRPPPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPRPPPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));
                        }
                        break;

                    case BenefitGroupTypeEnum.StudentLoanProtectionRider:

                        totalMonthlyBenefits.TotalSLPPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.SLPPremiumAmt))
                            {
                                return result;
                            }
                            decimal.TryParse(c.ProviderChoiceMonthlyPremiums.SLPPremiumAmt.Replace("$", ""), out result);
                            grandTotalPremiumAmt += result;
                            totalMonthlyPremiumAmt += result;
                            return result;
                        }));
                        if (hasBuyUpPlan)
                        {
                            totalMonthlyBenefits.TotalVGBPSLPPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPSLPPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPSLPPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));
                        }
                        break;

                    case BenefitGroupTypeEnum.SupplementalBenefit:

                        totalMonthlyBenefits.TotalSBTPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.SBTPremiumAmt))
                            {
                                return result;
                            }
                            decimal.TryParse(c.ProviderChoiceMonthlyPremiums.SBTPremiumAmt.Replace("$", ""), out result);
                            grandTotalPremiumAmt += result;
                            totalMonthlyPremiumAmt += result;
                            return result;
                        }));
                        if (hasBuyUpPlan)
                        {
                            totalMonthlyBenefits.TotalVGBPSBTPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPSBTPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPSBTPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));
                        }
                        break;

                    case BenefitGroupTypeEnum.UnemploymentPremiumWaiver:

                        totalMonthlyBenefits.TotalUWPPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.UWPPremiumAmt))
                            {
                                return result;
                            }
                            decimal.TryParse(c.ProviderChoiceMonthlyPremiums.UWPPremiumAmt.Replace("$", ""), out result);
                            grandTotalPremiumAmt += result;
                            totalMonthlyPremiumAmt += result;
                            return result;
                        }));

                        if (hasBuyUpPlan)
                        {
                            totalMonthlyBenefits.TotalVGBPUWPPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPUWPPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPUWPPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));
                        }
                        break;

                    case BenefitGroupTypeEnum.ExtendedBenefits:

                        totalMonthlyBenefits.TotalLumpSumPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                        {
                            decimal result = 0.0m;
                            if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.LumpSumPremiumAmt))
                            {
                                return result;
                            }
                            decimal.TryParse(c.ProviderChoiceMonthlyPremiums.LumpSumPremiumAmt.Replace("$", ""), out result);
                            grandTotalPremiumAmt += result;
                            totalMonthlyPremiumAmt += result;
                            return result;
                        }));

                        if (hasBuyUpPlan)
                        {
                            totalMonthlyBenefits.TotalVGBPLumpSumPremiumAmt = string.Format("{0:C2}", classReq.Employees.Sum(c =>
                            {
                                decimal result = 0.0m;
                                if (string.IsNullOrEmpty(c.ProviderChoiceMonthlyPremiums.VGBPLumpSumPremiumAmt))
                                {
                                    return result;
                                }
                                decimal.TryParse(c.ProviderChoiceMonthlyPremiums.VGBPLumpSumPremiumAmt.Replace("$", ""), out result);
                                grandTotalPremiumAmt += result;
                                totalMonthlyPremiumAmt += result;
                                return result;
                            }));
                        }

                        break;
                }

            }

            totalMonthlyBenefits.GrandTotalPremiumAmt = string.Format("{0:C2}", grandTotalPremiumAmt);
            totalMonthlyBenefits.TotalMonthlyPremiumAmt = string.Format("{0:C2}", totalMonthlyPremiumAmt);

            Log.TraceFormat("-GetTotalMonthlyBenefits");
            return totalMonthlyBenefits;
        }

        private string GetAnnualMonthlyPremium(ProviderChoiceMonthlyPremiums providerChoiceMonthlyPremiums)
        {
            decimal annualMonthlyPremium = 0.0m;
            string annualMonthlyPre = providerChoiceMonthlyPremiums.NonBPTotalAnnualPremiumAmt.TrimStart('$');
            if (decimal.TryParse(annualMonthlyPre, out annualMonthlyPremium))
            {
                return string.Format("{0:C2}", annualMonthlyPremium * 12);
            }
            return annualMonthlyPremium.ToString();
        }

        private ProviderChoiceMonthlyPremiumColumnNames GetProviderChoiceMonthlyPremiumColumnNames(List<IllustrationRequestBenefit> primaryBenefits, List<IllustrationRequestBenefit> buyupBenefits,
            StateTypeEnum contractState, ExistingCoveragePremiumAndTaxpayerLiabilityType premiumPayerAndTaxabilityType,
            ProviderChoiceMonthlyPremiumColumnNames providerChoiceMonthlyPremiumColumnNames, bool isCompactState, bool isReEnrollmentCase, BillingModeTypeEnum? billingModeType, PlanDesignTypeEnum? planDesignType)
        {
            Log.TraceFormat("+GetProviderChoiceMonthlyPremiumColumnNames");

            //ProviderChoiceMonthlyPremiumColumnNames providerChoiceMonthlyPremiumColumnNames = new ProviderChoiceMonthlyPremiumColumnNames();

            string[] providerChoiceMonthlyPremiumColumnNamesValues = new string[] { "Base", //0
                                                                                    "Basic CAT", //1
                                                                                    "Enhanced CAT",//2
                                                                                    "3% COLA",//3
                                                                                    "6% COLA",//4
                                                                                    "4-Year Delayed COLA",//5
                                                                                    "Lump Sum",//6
                                                                                    "Enhanced Partial Disability",//7
                                                                                    "Basic Partial Disability",//8
                                                                                    "Short Term Residual Disability",//9
                                                                                    "RPP Benefit",//10
                                                                                    "SLP Benefit",//11
                                                                                    "SBT Benefit",//12
                                                                                    "UWP Benefit",//13
                                                                                    "Total",//14
                                                                                    "Total (Annual)",//15
                                                                                    "Buy Up Premium",//16
                                                                                    "Total (Monthly)",//17
                                                                                    "Severe Disability",//18
                                                                                    "ER Monthly Paid Premium",//19
                                                                                    "EE Monthly Paid Premium",//20
                                                                                    "ER Annual Paid Premium",//21
                                                                                    "EE Annual Paid Premium",//22
                                                                                    "Inforce [Modal] Premium", //23
                                                                                    "Proposed [Modal] Increase", //24
                                                                                    "Total [Modal]"//25
                                                                                    };

            if (IsCostShare(premiumPayerAndTaxabilityType))
            {
                providerChoiceMonthlyPremiumColumnNames.ERPaidPremiumMonthly = providerChoiceMonthlyPremiumColumnNamesValues[19];
                providerChoiceMonthlyPremiumColumnNames.EEPaidPremiumMonthly = providerChoiceMonthlyPremiumColumnNamesValues[20];
                providerChoiceMonthlyPremiumColumnNames.ERPaidPremiumAnnual = providerChoiceMonthlyPremiumColumnNamesValues[21];
                providerChoiceMonthlyPremiumColumnNames.EEPaidPremiumAnnual = providerChoiceMonthlyPremiumColumnNamesValues[22];
            }

            providerChoiceMonthlyPremiumColumnNames.BasePremium = providerChoiceMonthlyPremiumColumnNamesValues[0];

            foreach (var rider in primaryBenefits)
            {
                switch ((BenefitGroupTypeEnum)rider.BenefitGroupTypeId)
                {
                    case BenefitGroupTypeEnum.PartialDisability:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                        {
                            providerChoiceMonthlyPremiumColumnNames.EnhancedPartialDisabilityPremium = providerChoiceMonthlyPremiumColumnNamesValues[7];
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicPartialDisabilityRider)
                        {
                            providerChoiceMonthlyPremiumColumnNames.BasicPartialDisabilityPremium = providerChoiceMonthlyPremiumColumnNamesValues[8];
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                        {
                            providerChoiceMonthlyPremiumColumnNames.ShortTermResidualDisabilityPremium = providerChoiceMonthlyPremiumColumnNamesValues[9];
                        }
                        break;

                    case BenefitGroupTypeEnum.CatastrophicDisabilityBenefit:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                        {
                            providerChoiceMonthlyPremiumColumnNames.EnhancedCATPremium = providerChoiceMonthlyPremiumColumnNamesValues[2];
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                        {
                            if (isCompactState)
                            {
                                providerChoiceMonthlyPremiumColumnNames.BaseCATPremium = providerChoiceMonthlyPremiumColumnNamesValues[18];
                            }
                            else
                            {
                                providerChoiceMonthlyPremiumColumnNames.BaseCATPremium = providerChoiceMonthlyPremiumColumnNamesValues[1];
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.CostOfLivingAdjustment:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving3PercentCompound)
                        {
                            providerChoiceMonthlyPremiumColumnNames.ThreeCOLAPremium = providerChoiceMonthlyPremiumColumnNamesValues[3];
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                        {
                            providerChoiceMonthlyPremiumColumnNames.SixCOLAPremium = providerChoiceMonthlyPremiumColumnNamesValues[4];
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving4YearDelayed)
                        {
                            providerChoiceMonthlyPremiumColumnNames.FourYearCOLAPremium = providerChoiceMonthlyPremiumColumnNamesValues[5];
                        }
                        break;

                    case BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit:
                        providerChoiceMonthlyPremiumColumnNames.RPPPremium = providerChoiceMonthlyPremiumColumnNamesValues[10];
                        break;

                    case BenefitGroupTypeEnum.StudentLoanProtectionRider:
                        providerChoiceMonthlyPremiumColumnNames.SLPPremium = providerChoiceMonthlyPremiumColumnNamesValues[11];
                        break;

                    case BenefitGroupTypeEnum.SupplementalBenefit:
                        providerChoiceMonthlyPremiumColumnNames.SBTPremium = providerChoiceMonthlyPremiumColumnNamesValues[12];
                        break;

                    case BenefitGroupTypeEnum.UnemploymentPremiumWaiver:
                        providerChoiceMonthlyPremiumColumnNames.UWPPremium = providerChoiceMonthlyPremiumColumnNamesValues[13];
                        break;

                    case BenefitGroupTypeEnum.ExtendedBenefits:
                        providerChoiceMonthlyPremiumColumnNames.LumpSumPremium = providerChoiceMonthlyPremiumColumnNamesValues[6];
                        break;
                }

            }

            if (isReEnrollmentCase)
            {
                providerChoiceMonthlyPremiumColumnNames.InforceModalPremium = string.Format("Inforce {0} Premium", billingModeType.GetDescription());
                if (planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                {
                    providerChoiceMonthlyPremiumColumnNames.InforceModalIncrease = string.Format("Proposed {0} Premium", billingModeType.GetDescription());
                }
                else
                {
                    providerChoiceMonthlyPremiumColumnNames.InforceModalIncrease = string.Format("Proposed {0} Increase", billingModeType.GetDescription());
                }

                providerChoiceMonthlyPremiumColumnNames.TotalModal = string.Format("Total {0}", billingModeType.GetDescription());
            }
            providerChoiceMonthlyPremiumColumnNames.NonBPTotalAnnualPremium = providerChoiceMonthlyPremiumColumnNamesValues[15];

            if (buyupBenefits != null)
            {

                providerChoiceMonthlyPremiumColumnNames.BuyUpBaseBenefitPremium = providerChoiceMonthlyPremiumColumnNamesValues[16];
                providerChoiceMonthlyPremiumColumnNames.VGBPTotalMonthlyPremium = providerChoiceMonthlyPremiumColumnNamesValues[17];
                providerChoiceMonthlyPremiumColumnNames.VGBPTotalAnnualPremium = providerChoiceMonthlyPremiumColumnNamesValues[15];

                foreach (var rider in buyupBenefits)
                {
                    switch ((BenefitGroupTypeEnum)rider.BenefitGroupTypeId)
                    {
                        case BenefitGroupTypeEnum.PartialDisability:

                            if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                            {
                                providerChoiceMonthlyPremiumColumnNames.VGBPEnhancedPartialDisabilityPremium = providerChoiceMonthlyPremiumColumnNamesValues[7];
                            }
                            else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicPartialDisabilityRider)
                            {
                                providerChoiceMonthlyPremiumColumnNames.VGBPBasicPartialDisabilityPremium = providerChoiceMonthlyPremiumColumnNamesValues[8];
                            }
                            else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                            {
                                providerChoiceMonthlyPremiumColumnNames.VGBPShortTermResidualDisabilityPremium = providerChoiceMonthlyPremiumColumnNamesValues[9];
                            }
                            break;

                        case BenefitGroupTypeEnum.CatastrophicDisabilityBenefit:

                            if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                            {
                                providerChoiceMonthlyPremiumColumnNames.VGBPEnhancedCATPremium = providerChoiceMonthlyPremiumColumnNamesValues[2];
                            }
                            else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                            {
                                if (isCompactState)
                                {
                                    providerChoiceMonthlyPremiumColumnNames.VGBPBasicCATPremium = providerChoiceMonthlyPremiumColumnNamesValues[18];
                                }
                                else
                                {
                                    providerChoiceMonthlyPremiumColumnNames.VGBPBasicCATPremium = providerChoiceMonthlyPremiumColumnNamesValues[1];
                                }
                            }
                            break;

                        case BenefitGroupTypeEnum.CostOfLivingAdjustment:

                            if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving3PercentCompound)
                            {
                                providerChoiceMonthlyPremiumColumnNames.VGBPThreeCOLAPremium = providerChoiceMonthlyPremiumColumnNamesValues[3];
                            }
                            else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                            {
                                providerChoiceMonthlyPremiumColumnNames.VGBPSixCOLAPremium = providerChoiceMonthlyPremiumColumnNamesValues[4];
                            }
                            else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving4YearDelayed)
                            {
                                providerChoiceMonthlyPremiumColumnNames.VGBPFourYearCOLAPremium = providerChoiceMonthlyPremiumColumnNamesValues[5];
                            }
                            break;

                        case BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit:
                            providerChoiceMonthlyPremiumColumnNames.VGBPRPPPremium = providerChoiceMonthlyPremiumColumnNamesValues[10];
                            break;

                        case BenefitGroupTypeEnum.StudentLoanProtectionRider:
                            providerChoiceMonthlyPremiumColumnNames.VGBPSLPPremium = providerChoiceMonthlyPremiumColumnNamesValues[11];
                            break;

                        case BenefitGroupTypeEnum.SupplementalBenefit:
                            providerChoiceMonthlyPremiumColumnNames.VGBPSBTPremium = providerChoiceMonthlyPremiumColumnNamesValues[12];
                            break;

                        case BenefitGroupTypeEnum.UnemploymentPremiumWaiver:
                            providerChoiceMonthlyPremiumColumnNames.VGBPUWPPremium = providerChoiceMonthlyPremiumColumnNamesValues[13];
                            break;

                        case BenefitGroupTypeEnum.ExtendedBenefits:
                            providerChoiceMonthlyPremiumColumnNames.VGBPLumpSumPremium = providerChoiceMonthlyPremiumColumnNamesValues[6];
                            break;
                    }
                }
            }

            providerChoiceMonthlyPremiumColumnNames.TotalPremium = providerChoiceMonthlyPremiumColumnNamesValues[14];

            Log.TraceFormat("-GetProviderChoiceMonthlyPremiumColumnNames");

            return providerChoiceMonthlyPremiumColumnNames;
        }

        private ProviderChoiceMonthlyPremiums GetProviderChoiceMonthlyPremiumValues(List<IllustrationRequestBenefit> benefits, Participant participant, PremiumCalculatorResponse response, bool hasBuyUpPlan, ProviderChoiceMonthlyPremiums providerChoiceMonthlyPremiums, IllustrationRequestClass request, GLTDandIDIBenefitBenefitSummaries gLTDandIDIBenefitSummaryValues, bool isReEnrollmentCase)
        {
            //Log.TraceFormat("+GetProviderChoiceMonthlyPremiumValues");

            if (!hasBuyUpPlan)
            {
                var basePremiumAmount = response.Rates.FirstOrDefault(c => c.RiderId == -1);
                var baseAnnuaPremiumAmount = response.AnnualAmount;

                if (basePremiumAmount != null)
                {
                    decimal basePremiumAmt = 0.0m;
                    decimal.TryParse(basePremiumAmount.Premium.Replace("$", ""), out basePremiumAmt);
                    if (basePremiumAmt <= 0)
                    {
                        providerChoiceMonthlyPremiums.BasePremiumAmt = "$0.00";
                    }
                    else
                    {
                        providerChoiceMonthlyPremiums.BasePremiumAmt = string.Format("{0:C2}", basePremiumAmount.Premium);
                    }
                }

                var totalMonthlyPremiumAmount = response.Rates.Where(c => c.RiderId != 0 );
                decimal totalPremiumAmt = 0.0m;
                decimal modaltotalPremiumAmt = totalMonthlyPremiumAmount.Sum(c =>
                {

                    if (string.IsNullOrEmpty(c.Premium))
                    {
                        return totalPremiumAmt;
                    }
                    decimal.TryParse(c.Premium.Replace("$", ""), out totalPremiumAmt);
                    return totalPremiumAmt;
                });

                if (modaltotalPremiumAmt <= 0)
                {
                    providerChoiceMonthlyPremiums.TotalPremiumAmt = "$0.00";
                }
                else
                {
                    providerChoiceMonthlyPremiums.TotalPremiumAmt = string.Format("{0:C2}", modaltotalPremiumAmt);
                    if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator != true)
                    {
                        providerChoiceMonthlyPremiums.ProposedModalIncreaseAmt = string.Format("{0:C2}", modaltotalPremiumAmt);
                        providerChoiceMonthlyPremiums.InforceModalPremiumAmt = "$0.00";
                        providerChoiceMonthlyPremiums.TotalModalPremiumAmt = string.Format("{0:C2}", (modaltotalPremiumAmt));
                    }
                }

                if (isReEnrollmentCase)
                {
                    if (participant.IsAMBIncreaseIndicator == true)
                    {
                        providerChoiceMonthlyPremiums.BasePremiumAmt = "$0.00"; //Mark this as zero for AMB participant to hide it in csv file.

                        var ambMonthlyPremiumAmtValue = response.Rates.Where(c => c.RiderId == (int)BenefitTypeEnum.AdditionalMonthlyBenefit);
                        decimal ambPremiumAmt = 0.0m;
                        decimal ambModalPremiumAmt = ambMonthlyPremiumAmtValue.Sum(c =>
                        {
                            if (string.IsNullOrEmpty(c.Premium))
                            {
                                return ambPremiumAmt;
                            }
                            decimal.TryParse(c.Premium.Replace("$", ""), out ambPremiumAmt);
                            return ambPremiumAmt;
                        });

                        decimal ambAnnualPremiumAmt = ambMonthlyPremiumAmtValue.Sum(c =>
                        {
                            if (string.IsNullOrEmpty(c.Premium))
                            {
                                return ambPremiumAmt;
                            }
                            decimal.TryParse(c.AnnualPremium.Replace("$", ""), out ambPremiumAmt);
                            return ambPremiumAmt;
                        });

                        providerChoiceMonthlyPremiums.ProposedModalIncreaseAmt = string.Format("{0:C2}", ambModalPremiumAmt);

                        var existingPolicyModalPremium = participant.ParticipantExistingPolicies.FirstOrDefault()?.ParticipantExistingPolicyDetails.FirstOrDefault()?.ModalPremium;
                        var existingAnnualizedPremium = participant.ParticipantExistingPolicies.FirstOrDefault()?.ParticipantExistingPolicyDetails.FirstOrDefault()?.AnnualizedPremium;
                        providerChoiceMonthlyPremiums.InforceModalPremiumAmt = string.Format("{0:C2}", existingPolicyModalPremium);

                        providerChoiceMonthlyPremiums.TotalModalPremiumAmt = string.Format("{0:C2}", (ambModalPremiumAmt + existingPolicyModalPremium));
                        providerChoiceMonthlyPremiums.TotalAnnualPremiumAmt = string.Format("{0:C2}", (existingAnnualizedPremium + ambAnnualPremiumAmt));
                    }
                    else
                    {
                        if (baseAnnuaPremiumAmount <= 0)
                        {
                            providerChoiceMonthlyPremiums.TotalAnnualPremiumAmt = "$0.00";
                        }
                        else
                        {
                            providerChoiceMonthlyPremiums.TotalAnnualPremiumAmt = string.Format("{0:C2}", (baseAnnuaPremiumAmount).Roundoff(2));
                        }
                    }
                }
                else
                {
                    if (baseAnnuaPremiumAmount <= 0)
                    {
                        providerChoiceMonthlyPremiums.NonBPTotalAnnualPremiumAmt = "$0.00";
                    }
                    else
                    {
                        providerChoiceMonthlyPremiums.NonBPTotalAnnualPremiumAmt = string.Format("{0:C2}", (baseAnnuaPremiumAmount).Roundoff(2));
                    }
                }
            }
            else
            {
                var buyUpBaseBenefitPremiumAmt = response.Rates.FirstOrDefault(c => c.RiderId == -1);
                var buyUpAnnualPremium = response.AnnualAmount;

                if (buyUpBaseBenefitPremiumAmt != null)
                {
                    decimal buyUpBaseBenefitPremiumAmount = 0.0m;
                    decimal.TryParse(buyUpBaseBenefitPremiumAmt.Premium.Replace("$", ""), out buyUpBaseBenefitPremiumAmount);
                    if (buyUpBaseBenefitPremiumAmount <= 0)
                    {
                        providerChoiceMonthlyPremiums.BuyUpBaseBenefitPremiumAmt = "$0.00";
                    }
                    else
                    {
                        providerChoiceMonthlyPremiums.BuyUpBaseBenefitPremiumAmt = string.Format("{0:C2}", buyUpBaseBenefitPremiumAmt.Premium);
                    }
                }

                var buyupTotalMonthlyPremiumAmount = response.Rates.Where(c => c.RiderId != 0);
                decimal totalPremiumAmt = 0.0m;
                decimal buyupMonthlytotalPremiumAmt = buyupTotalMonthlyPremiumAmount.Sum(c =>
                {

                    if (string.IsNullOrEmpty(c.Premium))
                    {
                        return totalPremiumAmt;
                    }
                    decimal.TryParse(c.Premium.Replace("$", ""), out totalPremiumAmt);
                    return totalPremiumAmt;
                });

                if (buyupMonthlytotalPremiumAmt <= 0)
                {
                    providerChoiceMonthlyPremiums.VGBPTotalMonthlyPremiumAmt = "$0.00";
                }
                else
                {
                    providerChoiceMonthlyPremiums.VGBPTotalMonthlyPremiumAmt = string.Format("{0:C2}", buyupMonthlytotalPremiumAmt);
                }

                if (buyUpAnnualPremium <= 0)
                {
                    providerChoiceMonthlyPremiums.VGBPTotalAnnualPremiumAmt = "$0.00";
                }
                else
                {
                    providerChoiceMonthlyPremiums.VGBPTotalAnnualPremiumAmt = string.Format("{0:C2}", (buyUpAnnualPremium).Roundoff(2));
                }
            }

            var benefitRiders = new List<IllustrationRequestBenefit>();

            if (hasBuyUpPlan)
            {
                benefitRiders = request.BuyUpPlan.Benefits;
            }
            else
            {
                benefitRiders = request.PrimaryPlan.Benefits;
            }

            foreach (var rider in benefitRiders)
            {
                var premiumAmountString = string.Empty;
                rider.BenefitId = (int)_productLibraryManager.FixBenefitTypeEnum((BenefitTypeEnum)rider.BenefitId);
                var premiumAmount = response.Rates.FirstOrDefault(c => c.RiderId == rider.BenefitId);
                if (premiumAmount == null)
                {
                    premiumAmountString = "$0.00";
                }
                else
                {
                    decimal premiumAmt = 0.0m;
                    decimal.TryParse(premiumAmount.Premium.Replace("$", ""), out premiumAmt);
                    if (premiumAmt < 0)
                    {
                        premiumAmountString = "$0.00";
                    }
                    else
                    {
                        premiumAmountString = string.Format("{0:C2}", premiumAmount.Premium);
                    }
                }

                switch ((BenefitGroupTypeEnum)rider.BenefitGroupTypeId)
                {
                    case BenefitGroupTypeEnum.PartialDisability:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                        {
                            if (hasBuyUpPlan)
                            {
                                providerChoiceMonthlyPremiums.VGBPEnhancedPartialDisabilityPremiumAmt = premiumAmountString;
                            }
                            else
                            {
                                if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                                {
                                    providerChoiceMonthlyPremiums.EnhancedPartialDisabilityPremiumAmt = "$0.00";
                                }
                                else
                                {
                                    providerChoiceMonthlyPremiums.EnhancedPartialDisabilityPremiumAmt = premiumAmountString;
                                }
                            }
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicPartialDisabilityRider)
                        {
                            if (hasBuyUpPlan)
                            {
                                providerChoiceMonthlyPremiums.VGBPBasicPartialDisabilityPremiumAmt = premiumAmountString;
                            }
                            else
                            {
                                if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                                {
                                    providerChoiceMonthlyPremiums.BasicPartialDisabilityPremiumAmt = "$0.00";
                                }
                                else
                                {
                                    providerChoiceMonthlyPremiums.BasicPartialDisabilityPremiumAmt = premiumAmountString;
                                }
                            }
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                        {
                            if (hasBuyUpPlan)
                            {
                                providerChoiceMonthlyPremiums.VGBPShortTermResidualDisabilityPremiumAmt = premiumAmountString;
                            }
                            else
                            {
                                if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                                {
                                    providerChoiceMonthlyPremiums.ShortTermResidualDisabilityPremiumAmt = "$0.00";
                                }
                                else
                                {
                                    providerChoiceMonthlyPremiums.ShortTermResidualDisabilityPremiumAmt = premiumAmountString;
                                }
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.CatastrophicDisabilityBenefit:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                        {
                            if (hasBuyUpPlan)
                            {
                                if (premiumAmountString == "$0.00")
                                {
                                    gLTDandIDIBenefitSummaryValues.EnhancedCATAmt = "$0.00";
                                }
                                providerChoiceMonthlyPremiums.VGBPEnhancedCATPremiumAmt = premiumAmountString;
                            }
                            else
                            {
                                if (premiumAmountString == "$0.00")
                                {
                                    gLTDandIDIBenefitSummaryValues.EnhancedCATAmt = "$0.00";
                                }
                                if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                                {
                                    providerChoiceMonthlyPremiums.EnhancedCATPremiumAmt = "$0.00";
                                }
                                else
                                {
                                    providerChoiceMonthlyPremiums.EnhancedCATPremiumAmt = premiumAmountString;
                                }
                            }
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                        {
                            if (hasBuyUpPlan)
                            {
                                if (premiumAmountString == "$0.00")
                                {
                                    gLTDandIDIBenefitSummaryValues.BasicCATAmt = "$0.00";
                                }
                                providerChoiceMonthlyPremiums.VGBPBasicCATPremiumAmt = premiumAmountString;
                            }
                            else
                            {
                                if (premiumAmountString == "$0.00")
                                {
                                    gLTDandIDIBenefitSummaryValues.BasicCATAmt = "$0.00";
                                }

                                if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                                {
                                    providerChoiceMonthlyPremiums.BaseCATPremiumAmt = "$0.00";
                                }
                                else
                                {
                                    providerChoiceMonthlyPremiums.BaseCATPremiumAmt = premiumAmountString;
                                }
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.CostOfLivingAdjustment:
                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving3PercentCompound)
                        {
                            if (hasBuyUpPlan)
                            {
                                providerChoiceMonthlyPremiums.VGBPThreeCOLAPremiumAmt = premiumAmountString;
                            }
                            else
                            {
                                if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                                {
                                    providerChoiceMonthlyPremiums.ThreeCOLAPremiumAmt = "$0.00";
                                }
                                else
                                {
                                    providerChoiceMonthlyPremiums.ThreeCOLAPremiumAmt = premiumAmountString;
                                }
                            }
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                        {
                            if (hasBuyUpPlan)
                            {
                                providerChoiceMonthlyPremiums.VGBPSixCOLAPremiumAmt = premiumAmountString;
                            }
                            else
                            {
                                if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                                {
                                    providerChoiceMonthlyPremiums.SixCOLAPremiumAmt = "$0.00";
                                }
                                else
                                {
                                    providerChoiceMonthlyPremiums.SixCOLAPremiumAmt = premiumAmountString;
                                }
                            }
                        }
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving4YearDelayed)
                        {
                            if (hasBuyUpPlan)
                            {
                                providerChoiceMonthlyPremiums.VGBPFourYearCOLAPremiumAmt = premiumAmountString;
                            }
                            else
                            {
                                if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                                {
                                    providerChoiceMonthlyPremiums.FourYearCOLAPremiumAmt = "$0.00";
                                }
                                else
                                {
                                    providerChoiceMonthlyPremiums.FourYearCOLAPremiumAmt = premiumAmountString;
                                }
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit:
                        if (hasBuyUpPlan)
                        {
                            if (premiumAmountString == "$0.00")
                            {
                                gLTDandIDIBenefitSummaryValues.RPPBenefitAmt = "$0.00";
                            }
                            providerChoiceMonthlyPremiums.VGBPRPPPremiumAmt = premiumAmountString;
                        }
                        else
                        {
                            if (premiumAmountString == "$0.00")
                            {
                                gLTDandIDIBenefitSummaryValues.RPPBenefitAmt = "$0.00";
                            }

                            if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                            {
                                providerChoiceMonthlyPremiums.RPPPremiumAmt = "$0.00";
                            }
                            else
                            {
                                providerChoiceMonthlyPremiums.RPPPremiumAmt = premiumAmountString;
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.StudentLoanProtectionRider:
                        if (hasBuyUpPlan)
                        {
                            if (premiumAmountString == "$0.00")
                            {
                                gLTDandIDIBenefitSummaryValues.SLPBenefitAmt = "$0.00";
                            }
                            providerChoiceMonthlyPremiums.VGBPSLPPremiumAmt = premiumAmountString;
                        }
                        else
                        {
                            if (premiumAmountString == "$0.00")
                            {
                                gLTDandIDIBenefitSummaryValues.SLPBenefitAmt = "$0.00";
                            }
                            if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                            {
                                providerChoiceMonthlyPremiums.SLPPremiumAmt = "$0.00";
                            }
                            else
                            {
                                providerChoiceMonthlyPremiums.SLPPremiumAmt = premiumAmountString;
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.SupplementalBenefit:
                        if (hasBuyUpPlan)
                        {
                            if (premiumAmountString == "$0.00")
                            {
                                gLTDandIDIBenefitSummaryValues.SBTBenefitAmt = "$0.00";
                            }
                            providerChoiceMonthlyPremiums.VGBPSBTPremiumAmt = premiumAmountString;
                        }
                        else
                        {
                            if (premiumAmountString == "$0.00")
                            {
                                gLTDandIDIBenefitSummaryValues.SBTBenefitAmt = "$0.00";
                            }
                            if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                            {
                                providerChoiceMonthlyPremiums.SBTPremiumAmt = "$0.00";
                            }
                            else
                            {
                                providerChoiceMonthlyPremiums.SBTPremiumAmt = premiumAmountString;
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.UnemploymentPremiumWaiver:
                        if (hasBuyUpPlan)
                        {
                            providerChoiceMonthlyPremiums.VGBPUWPPremiumAmt = premiumAmountString;
                        }
                        else {
                            if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                            {
                                providerChoiceMonthlyPremiums.UWPPremiumAmt = "$0.00";
                            }
                            else
                            {
                                providerChoiceMonthlyPremiums.UWPPremiumAmt = premiumAmountString;
                            }
                        }
                        break;

                    case BenefitGroupTypeEnum.ExtendedBenefits:
                        if (hasBuyUpPlan)
                        {
                            providerChoiceMonthlyPremiums.VGBPLumpSumPremiumAmt = premiumAmountString;
                        }
                        else {

                            if (isReEnrollmentCase && participant.IsAMBIncreaseIndicator == true)
                            {
                                providerChoiceMonthlyPremiums.LumpSumPremiumAmt = "$0.00";
                            }
                            else
                            {
                                providerChoiceMonthlyPremiums.LumpSumPremiumAmt = premiumAmountString;
                            }
                        }
                        break;
                }
            }

            //Log.TraceFormat("-GetProviderChoiceMonthlyPremiumValues");
            return providerChoiceMonthlyPremiums;
        }

        private InsurableIncomeColumnNames GetInsurableIncomeColumnNames(List<CoveredEarningsTypeEnum?> coveredEarningsTypes,
            List<CoveredEarningsBonusOnlyTypeEnum?> CoveredEarningsBonusOnlyType, bool hasBuyUpPlan, InsurableIncomeColumnNames insurableIncomeColumnNames)
        {
            Log.TraceFormat("+GetInsurableIncomeColumnNames");

            //InsurableIncomeColumnNames insurableIncomeColumnNames = new InsurableIncomeColumnNames();

            string[] insurableColumnValues = new string[] { "Salary" ,//0
                                                            "Bonus",//1
                                                            "Total",//2
                                                            "Commissions",//3
                                                            "W2 Income",//4
                                                            "K-1 Earnings",//5
                                                            "Other Income",//6
                                                            "Total Compensation",//7
                                                            "ER Paid GSI Base",//8
                                                            "VGSI Buy Up",//9
                                                            "IDI Insurable Income"//10
            };

            if (coveredEarningsTypes == null && CoveredEarningsBonusOnlyType == null)
            {
                insurableIncomeColumnNames.Total = insurableColumnValues[2];
            }

            if (coveredEarningsTypes != null)
            {
                insurableIncomeColumnNames.Total = insurableColumnValues[2];
                insurableIncomeColumnNames.IDIInsurableIncome = insurableColumnValues[10];

                foreach (var coveredEarningsType in coveredEarningsTypes)
                {
                    if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalaryOnly)
                    {
                        insurableIncomeColumnNames.Salary = insurableColumnValues[0];
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalary_Bonus)
                    {
                        insurableIncomeColumnNames.Salary = insurableColumnValues[0];
                        insurableIncomeColumnNames.Bonus = insurableColumnValues[1];
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission)
                    {
                        insurableIncomeColumnNames.Salary = insurableColumnValues[0];
                        insurableIncomeColumnNames.Bonus = insurableColumnValues[1];
                        insurableIncomeColumnNames.Commissions = insurableColumnValues[3];
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalary_Commission)
                    {
                        insurableIncomeColumnNames.Salary = insurableColumnValues[0];
                        insurableIncomeColumnNames.Commissions = insurableColumnValues[3];
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.W_2Income)
                    {
                        insurableIncomeColumnNames.W2Income = insurableColumnValues[4];
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.K_1Earnings)
                    {
                        insurableIncomeColumnNames.K1Income = insurableColumnValues[5];
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.Other)
                    {
                        insurableIncomeColumnNames.OtherIncome = insurableColumnValues[6];
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.TotalCompensation)
                    {
                        insurableIncomeColumnNames.TotalCompensation = insurableColumnValues[7];
                    }
                }
            }

            if (hasBuyUpPlan)
            {
                insurableIncomeColumnNames.ERPaidGSIBase = insurableColumnValues[8];
                insurableIncomeColumnNames.VGSIBuyUp = insurableColumnValues[9];
                insurableIncomeColumnNames.Total = insurableColumnValues[2];
            }


            if (CoveredEarningsBonusOnlyType != null)
            {
                insurableIncomeColumnNames.Total = insurableColumnValues[7];
                insurableIncomeColumnNames.IDIInsurableIncome = insurableColumnValues[10];

                foreach (var coveredEarningsBonusOnlyType in CoveredEarningsBonusOnlyType)
                {
                    if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.Bonus)
                    {
                        insurableIncomeColumnNames.Bonus = insurableColumnValues[1];
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission)
                    {
                        insurableIncomeColumnNames.Bonus = insurableColumnValues[1];
                        insurableIncomeColumnNames.Commissions = insurableColumnValues[3];
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.Commissions)
                    {
                        insurableIncomeColumnNames.Commissions = insurableColumnValues[3];
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.K_1Earnings)
                    {
                        insurableIncomeColumnNames.K1Income = insurableColumnValues[5];
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus)
                    {
                        insurableIncomeColumnNames.Bonus = insurableColumnValues[1];
                        insurableIncomeColumnNames.Commissions = insurableColumnValues[3];
                        insurableIncomeColumnNames.K1Income = insurableColumnValues[5];
                    }
                }
            }

            Log.TraceFormat("-GetInsurableIncomeColumnNames");

            return insurableIncomeColumnNames;
        }

        private InsurableIncomes GetInsurableIncomeValues(List<CoveredEarningsTypeEnum?> coveredEarningsTypes, Participant participant, List<CoveredEarningsBonusOnlyTypeEnum?> CoveredEarningsBonusOnlyType, bool hasBuyUpPlan)
        {
            //Log.TraceFormat("+GetInsurableIncomeValues");

            InsurableIncomes insurableIncomeValues = new InsurableIncomes();
            decimal totalAmt = 0;
            bool showTotal = false;


            if (coveredEarningsTypes != null)
            {
                foreach (var coveredEarningsType in coveredEarningsTypes)
                {
                    if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalaryOnly)
                    {
                        insurableIncomeValues.SalaryAmt = string.Format("{0:C2}", participant.IDIBaseSalaryCalculatedAmount);
                        totalAmt += participant.IDIBaseSalaryCalculatedAmount != null ? participant.IDIBaseSalaryCalculatedAmount.Value : 0;

                        if (!showTotal)
                        {
                            showTotal = true;
                        }
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalary_Bonus)
                    {
                        insurableIncomeValues.SalaryAmt = string.Format("{0:C2}", participant.IDIBaseSalaryCalculatedAmount);
                        insurableIncomeValues.BonusAmt = string.Format("{0:C2}", participant.IDIBonusIncomeCalculatedAmount);
                        totalAmt += (participant.IDIBaseSalaryCalculatedAmount != null ? participant.IDIBaseSalaryCalculatedAmount.Value : 0) +
                                    (participant.IDIBonusIncomeCalculatedAmount != null ? participant.IDIBonusIncomeCalculatedAmount.Value : 0);
                        showTotal = true;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission)
                    {
                        insurableIncomeValues.SalaryAmt = string.Format("{0:C2}", participant.IDIBaseSalaryCalculatedAmount);
                        insurableIncomeValues.BonusAmt = string.Format("{0:C2}", participant.IDIBonusIncomeCalculatedAmount);
                        insurableIncomeValues.CommissionsAmt = string.Format("{0:C2}", participant.IDICommissionsIncomeCalculatedAmount);
                        totalAmt += (participant.IDIBaseSalaryCalculatedAmount != null ? participant.IDIBaseSalaryCalculatedAmount.Value : 0) +
                                    (participant.IDIBonusIncomeCalculatedAmount != null ? participant.IDIBonusIncomeCalculatedAmount.Value : 0) +
                                    (participant.IDICommissionsIncomeCalculatedAmount != null ? participant.IDICommissionsIncomeCalculatedAmount.Value : 0);
                        showTotal = true;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.BaseSalary_Commission)
                    {
                        insurableIncomeValues.SalaryAmt = string.Format("{0:C2}", participant.IDIBaseSalaryCalculatedAmount);
                        insurableIncomeValues.CommissionsAmt = string.Format("{0:C2}", participant.IDICommissionsIncomeCalculatedAmount);
                        totalAmt += (participant.IDIBaseSalaryCalculatedAmount != null ? participant.IDIBaseSalaryCalculatedAmount.Value : 0) +
                                    (participant.IDICommissionsIncomeCalculatedAmount != null ? participant.IDICommissionsIncomeCalculatedAmount.Value : 0);
                        showTotal = true;
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.K_1Earnings)
                    {
                        insurableIncomeValues.K1IncomeAmt = string.Format("{0:C2}", participant.IDIK1IncomeCalculatedAmount);
                        totalAmt += participant.IDIK1IncomeCalculatedAmount != null ? participant.IDIK1IncomeCalculatedAmount.Value : 0;
                        if (!showTotal)
                        {
                            showTotal = true;
                        }
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.Other)
                    {
                        insurableIncomeValues.OtherIncomeAmt = string.Format("{0:C2}", participant.IDIOtherIncomeCalculatedAmount);
                        totalAmt += participant.IDIOtherIncomeCalculatedAmount != null ? participant.IDIOtherIncomeCalculatedAmount.Value : 0;
                        if (!showTotal)
                        {
                            showTotal = true;
                        }
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.W_2Income)
                    {
                        insurableIncomeValues.W2IncomeAmt = string.Format("{0:C2}", participant.IDIInsurableIncomeCalculatedAmount);
                        totalAmt += participant.IDIInsurableIncomeCalculatedAmount != null ? participant.IDIInsurableIncomeCalculatedAmount.Value : 0;
                        if (!showTotal)
                        {
                            showTotal = true;
                        }
                    }
                    else if (coveredEarningsType == CoveredEarningsTypeEnum.TotalCompensation)
                    {

                        //decimal totalCompensationAmount = (participant.IDIBaseSalaryCalculatedAmount != null ? participant.IDIBaseSalaryCalculatedAmount.Value : 0)
                        //                                + (participant.IDIBonusIncomeCalculatedAmount != null ? participant.IDIBonusIncomeCalculatedAmount.Value : 0)                                                       
                        //                                + (participant.IDICommissionsIncomeCalculatedAmount != null ? participant.IDICommissionsIncomeCalculatedAmount.Value : 0)
                        //                                + (participant.IDIK1IncomeCalculatedAmount != null ? participant.IDIK1IncomeCalculatedAmount.Value : 0)
                        //                                + (participant.IDIOtherIncomeCalculatedAmount != null ? participant.IDIOtherIncomeCalculatedAmount.Value : 0);

                        if (participant.IDIInsurableIncomeCalculatedAmount.HasValue)
                        {
                            insurableIncomeValues.TotalCompensationAmt = string.Format("{0:C2}", participant.IDIInsurableIncomeCalculatedAmount);
                        }

                        totalAmt += participant.IDIInsurableIncomeCalculatedAmount != null ? (decimal)participant.IDIInsurableIncomeCalculatedAmount : 0.0m;
                        if (!showTotal)
                        {
                            showTotal = true;
                        }
                    }
                }
                if (participant.IDIInsurableIncomeCalculatedAmount.HasValue)
                {
                    insurableIncomeValues.IDIInsurableIncome = string.Format("{0:C2}", participant.IDIInsurableIncomeCalculatedAmount);
                }
            }

            if (CoveredEarningsBonusOnlyType != null)
            {
                foreach (var coveredEarningsBonusOnlyType in CoveredEarningsBonusOnlyType)
                {
                    if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.Bonus)
                    {
                        insurableIncomeValues.BonusAmt = string.Format("{0:C2}", participant.IDIBonusIncomeCalculatedAmount);
                        totalAmt += participant.IDIBonusIncomeCalculatedAmount != null ? participant.IDIBonusIncomeCalculatedAmount.Value : 0;
                        if (!showTotal)
                        {
                            showTotal = true;
                        }
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission)
                    {
                        insurableIncomeValues.BonusAmt = string.Format("{0:C2}", participant.IDIBonusIncomeCalculatedAmount);
                        insurableIncomeValues.CommissionsAmt = string.Format("{0:C2}", participant.IDICommissionsIncomeCalculatedAmount);
                        totalAmt += (participant.IDIBonusIncomeCalculatedAmount != null ? participant.IDIBonusIncomeCalculatedAmount.Value : 0) +
                                    (participant.IDICommissionsIncomeCalculatedAmount != null ? participant.IDICommissionsIncomeCalculatedAmount.Value : 0);
                        showTotal = true;
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.Commissions)
                    {
                        insurableIncomeValues.CommissionsAmt = string.Format("{0:C2}", participant.IDICommissionsIncomeCalculatedAmount);
                        totalAmt += participant.IDICommissionsIncomeCalculatedAmount != null ? participant.IDICommissionsIncomeCalculatedAmount.Value : 0;
                        if (!showTotal)
                        {
                            showTotal = true;
                        }
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.K_1Earnings)
                    {
                        insurableIncomeValues.K1IncomeAmt = string.Format("{0:C2}", participant.IDIK1IncomeCalculatedAmount);
                        totalAmt += participant.IDIK1IncomeCalculatedAmount != null ? participant.IDIK1IncomeCalculatedAmount.Value : 0;
                        if (!showTotal)
                        {
                            showTotal = true;
                        }
                    }
                    else if (coveredEarningsBonusOnlyType == CoveredEarningsBonusOnlyTypeEnum.AllVariableCompensationonCensus)
                    {
                        insurableIncomeValues.BonusAmt = string.Format("{0:C2}", participant.IDIBonusIncomeCalculatedAmount);
                        insurableIncomeValues.CommissionsAmt = string.Format("{0:C2}", participant.IDICommissionsIncomeCalculatedAmount);
                        insurableIncomeValues.K1IncomeAmt = string.Format("{0:C2}", participant.IDIK1IncomeCalculatedAmount);
                        totalAmt += (participant.IDIBonusIncomeCalculatedAmount != null ? participant.IDIBonusIncomeCalculatedAmount.Value : 0) +
                                    (participant.IDICommissionsIncomeCalculatedAmount != null ? participant.IDICommissionsIncomeCalculatedAmount.Value : 0) +
                                    (participant.IDIK1IncomeCalculatedAmount != null ? participant.IDIK1IncomeCalculatedAmount.Value : 0);
                        showTotal = true;
                    }
                }
                if (participant.IDIInsurableIncomeCalculatedAmount.HasValue)
                {
                    insurableIncomeValues.IDIInsurableIncome = string.Format("{0:C2}", participant.IDIInsurableIncomeCalculatedAmount);
                }
            }

            if (hasBuyUpPlan)
            {
                if (participant.VGSIBuyUpIDIInsurableIncomeCalculatedAmount.HasValue && participant.IDIInsurableIncomeCalculatedAmount.HasValue)
                {
                    insurableIncomeValues.ERPaidGSIBaseAmt = string.Format("{0:C2}", participant.IDIInsurableIncomeCalculatedAmount);
                    insurableIncomeValues.VGSIBuyUpAmt = string.Format("{0:C2}", participant.VGSIBuyUpIDIInsurableIncomeCalculatedAmount);

                    totalAmt += (participant.IDIInsurableIncomeCalculatedAmount != null ? participant.IDIInsurableIncomeCalculatedAmount.Value : 0) +
                                (participant.VGSIBuyUpIDIInsurableIncomeCalculatedAmount != null ? participant.VGSIBuyUpIDIInsurableIncomeCalculatedAmount.Value : 0);

                    insurableIncomeValues.TotalAmt = string.Format("{0:C2}", totalAmt);
                    showTotal = true;
                }
            }

            if (coveredEarningsTypes != null && showTotal)
            {
                insurableIncomeValues.TotalAmt = string.Format("{0:C2}", totalAmt);
            }
            else if (CoveredEarningsBonusOnlyType != null && showTotal)
            {
                insurableIncomeValues.TotalAmt = string.Format("{0:C2}", totalAmt);
            }

            if (coveredEarningsTypes == null && CoveredEarningsBonusOnlyType == null)
            {
                insurableIncomeValues.TotalAmt = string.Format("{0:C2}", participant.LTDInsurableIncomeCalculatedAmount);
            }

            //Log.TraceFormat("-GetInsurableIncomeValues");

            return insurableIncomeValues;
        }

        private GLTDandIDIBenefitSummaryColumnNames GetGSIBenefitSummaryColumnNames(List<IllustrationRequestBenefit> benefits, bool hasBuyUpPlan, StateTypeEnum contractState, PlanDesignTypeEnum? planDesignType, GLTDandIDIBenefitSummaryColumnNames gLTDandIDIBenefitSummaryColumnNames, bool isCompactState, bool isReEnrollmentCase, PlanDesignGSITypeEnum? planDesignGSIType = null)
        {
            Log.TraceFormat("+GetGSIBenefitSummaryColumnNames");

            //GLTDandIDIBenefitSummaryColumnNames gLTDandIDIBenefitSummaryColumnNames = new GLTDandIDIBenefitSummaryColumnNames();

            string[] gLTDandIDIBenefitSummaryColumnValues = new string[] {
                                                                            "GLTD Benefit",//0
                                                                            "GLTD Replace %",//1
                                                                            "Existing IDI Coverage",//2
                                                                            "GSI Base Benefit",//3
                                                                            "IDI Base Replace %",//4
                                                                            "Total GLTD Plus IDI",//5
                                                                            "Total GLTD Plus IDI %",//6
                                                                            "Basic CAT",//7
                                                                            "Enhanced CAT",//8
                                                                            "RPP Benefit",//9
                                                                            "SLP Benefit",//10
                                                                            "SBT Benefit",//11
                                                                            "ER Paid GSI Base Benefit",//12
                                                                            "Buy Up GSI Benefit",//13
                                                                            "Enhanced Partial Disability",//14
                                                                            "Basic Partial Disability",//15
                                                                            "Short Term Residual Disability",//16
                                                                            "3% COLA",//17
                                                                            "6% COLA",//18
                                                                            "4-Year Delayed COLA",//19
                                                                            "Serious Illness Benefit",//20
                                                                            "Unemployment Waiver Premium",//21
                                                                            "Lump Sum",//22
                                                                            "Severe Disability",//23
                                                                            "Total Replacement %", //24
                                                                            "Existing GSI Base Benefit", //25
                                                                            "Proposed GSI Base Benefit (Increase)", //26
                                                                            "Proposed GSI Base Benefit (New)", //27
                                                                            "[Type] CAT Benefit", //28
                                                                            "Existing RPP Base Benefit", //29
                                                                            "Proposed RPP Base Benefit (Increase)", //30
                                                                            "Proposed RPP Base Benefit (New)" //31
                                                                            };

            gLTDandIDIBenefitSummaryColumnNames.GLTDBenefit = gLTDandIDIBenefitSummaryColumnValues[0];

            if (planDesignType != null && planDesignType != PlanDesignTypeEnum.BonusOnlyPlan)
            {
                gLTDandIDIBenefitSummaryColumnNames.GLTDReplacePercent = gLTDandIDIBenefitSummaryColumnValues[1];
                gLTDandIDIBenefitSummaryColumnNames.TotalGLTDPlusIDIPercent = gLTDandIDIBenefitSummaryColumnValues[6];
            }
            gLTDandIDIBenefitSummaryColumnNames.ExistingIDICoverage = gLTDandIDIBenefitSummaryColumnValues[2];

            if (isReEnrollmentCase)
            {
                if (planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                {
                    gLTDandIDIBenefitSummaryColumnNames.ExistingRPPBaseBenefit = gLTDandIDIBenefitSummaryColumnValues[29];
                    gLTDandIDIBenefitSummaryColumnNames.ProposedRPPBaseBenefitIncrease = gLTDandIDIBenefitSummaryColumnValues[30];
                    gLTDandIDIBenefitSummaryColumnNames.ProposedRPPBaseBenefitNew = gLTDandIDIBenefitSummaryColumnValues[31];
                }
                else
                {
                    gLTDandIDIBenefitSummaryColumnNames.ExistingGSIBaseBenefit = gLTDandIDIBenefitSummaryColumnValues[25];
                    gLTDandIDIBenefitSummaryColumnNames.ProposedGSIBaseBenefitIncrease = gLTDandIDIBenefitSummaryColumnValues[26];
                    gLTDandIDIBenefitSummaryColumnNames.ProposedGSIBaseBenefitNew = gLTDandIDIBenefitSummaryColumnValues[27];
                }
            }
            else
            {
                gLTDandIDIBenefitSummaryColumnNames.GSIBaseBenefit = gLTDandIDIBenefitSummaryColumnValues[3];
            }

            if (planDesignType != PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                if (hasBuyUpPlan)
                {
                    if (planDesignGSIType != PlanDesignGSITypeEnum.SupplementalPlan)
                    {
                        gLTDandIDIBenefitSummaryColumnNames.IDIBaseReplacePercent = gLTDandIDIBenefitSummaryColumnValues[4];
                    }
                }
                else
                {
                    gLTDandIDIBenefitSummaryColumnNames.IDIBaseReplacePercent = gLTDandIDIBenefitSummaryColumnValues[4];
                }
            }

            gLTDandIDIBenefitSummaryColumnNames.TotalGLTDPlusIDI = gLTDandIDIBenefitSummaryColumnValues[5];


            if (hasBuyUpPlan)
            {
                gLTDandIDIBenefitSummaryColumnNames.ERPaidGSIBaseBenefit = gLTDandIDIBenefitSummaryColumnValues[12];
                gLTDandIDIBenefitSummaryColumnNames.BuyUpGSIBaseBenefit = gLTDandIDIBenefitSummaryColumnValues[13];
            }

            foreach (var rider in benefits)
            {
                switch ((BenefitGroupTypeEnum)rider.BenefitGroupTypeId)
                {
                    case BenefitGroupTypeEnum.PartialDisability:
                        break;

                    case BenefitGroupTypeEnum.CatastrophicDisabilityBenefit:

                        if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)
                            gLTDandIDIBenefitSummaryColumnNames.EnhancedCAT = gLTDandIDIBenefitSummaryColumnValues[8];
                        else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                        {

                            if (isCompactState)
                            {
                                gLTDandIDIBenefitSummaryColumnNames.BasicCAT = gLTDandIDIBenefitSummaryColumnValues[23];
                            }
                            else
                            {
                                gLTDandIDIBenefitSummaryColumnNames.BasicCAT = gLTDandIDIBenefitSummaryColumnValues[7];
                            }

                        }
                        gLTDandIDIBenefitSummaryColumnNames.TotalReplacementPercent = gLTDandIDIBenefitSummaryColumnValues[24];
                        break;

                    case BenefitGroupTypeEnum.CostOfLivingAdjustment:
                        break;

                    case BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit:

                        gLTDandIDIBenefitSummaryColumnNames.RPPBenefit = gLTDandIDIBenefitSummaryColumnValues[9];
                        break;

                    case BenefitGroupTypeEnum.StudentLoanProtectionRider:

                        gLTDandIDIBenefitSummaryColumnNames.SLPBenefit = gLTDandIDIBenefitSummaryColumnValues[10];
                        break;

                    case BenefitGroupTypeEnum.SupplementalBenefit:

                        gLTDandIDIBenefitSummaryColumnNames.SBTBenefit = gLTDandIDIBenefitSummaryColumnValues[11];
                        break;

                    case BenefitGroupTypeEnum.UnemploymentPremiumWaiver:
                        break;
                }

                switch ((BenefitTypeEnum)rider.BenefitId)
                {
                    case BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement:
                        break;

                    case BenefitTypeEnum.LumpSumIndemnityRider:
                        break;

                }
            }

            Log.TraceFormat("-GetGSIBenefitSummaryColumnNames");

            return gLTDandIDIBenefitSummaryColumnNames;
        }


        private GLTDandIDIBenefitBenefitSummaries GetGSIBenefitSummaryValues(List<IllustrationRequestBenefit> benefits, Participant participant, GLTDandIDIBenefitBenefitSummaries gLTDandIDIBenefitSummaryValues, bool hasBuyUpPlan,
            PremiumCalculatorResponse response, List<IllustrationParticipantDto> illustrationParticipants, IllustrationRequestClass request,
            PlanDesignTypeEnum? planDesignType, decimal? minimumBenefitAmount, bool isReEnrollmentCase, PlanDesignGSITypeEnum? planDesignGSIType = null)
        {
            //Log.TraceFormat("+GetGSIBenefitSummaryValues");

            var baseIllustrationParticipantPlan = illustrationParticipants.FirstOrDefault(c => c.Participant.Id == participant.Id).ParticipantPlans.FirstOrDefault(c => !c.IsBuyUpPlan);
            var buyUpIllustrationParticipantPlan = illustrationParticipants.FirstOrDefault(c => c.Participant.Id == participant.Id).ParticipantPlans.FirstOrDefault(c => c.IsBuyUpPlan);

            var receivedBaseBenefits = baseIllustrationParticipantPlan != null ? baseIllustrationParticipantPlan.Benefits : null;
            var receivedBuyUpBenefits = buyUpIllustrationParticipantPlan != null ? buyUpIllustrationParticipantPlan.Benefits : null;

            if (participant.LTDCalculatedAmount == null)
            {
                gLTDandIDIBenefitSummaryValues.GLTDBenefitAmt = "";
            }
            else if (participant.LTDCalculatedAmount < 0)
            {
                gLTDandIDIBenefitSummaryValues.GLTDBenefitAmt = "$0.00";
            }
            else
            {
                gLTDandIDIBenefitSummaryValues.GLTDBenefitAmt = string.Format("{0:C2}", participant.LTDCalculatedAmount);
            }

            if (participant.ExistingIDICalculatedAmount == null)
            {
                gLTDandIDIBenefitSummaryValues.ExistingIDICoverageAmt = "";
            }
            else if (participant.ExistingIDICalculatedAmount < 0)
            {
                gLTDandIDIBenefitSummaryValues.ExistingIDICoverageAmt = "$0.00";
            }
            else
            {
                gLTDandIDIBenefitSummaryValues.ExistingIDICoverageAmt = string.Format("{0:C2}", participant.ExistingIDICalculatedAmount);
            }

            if (isReEnrollmentCase)
            {
                if (participant.IsAMBIncreaseIndicator == true)
                {
                    if (planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                    {
                        gLTDandIDIBenefitSummaryValues.ProposedRPPBaseBenefitIncreaseAmt = GetBaseBenefitCalculatedAmount(planDesignType, baseIllustrationParticipantPlan?.AMBCalculatedAmount, participant.RPPAMBCalculatedAmount, minimumBenefitAmount, true);
                        gLTDandIDIBenefitSummaryValues.ProposedRPPBaseBenefitNewAmt = "$0.00";
                        var existingRPPBaseAMB = participant.ParticipantExistingPolicies.FirstOrDefault()?.GSIRPPBaseAMB;
                        gLTDandIDIBenefitSummaryValues.ExistingRPPBaseBenefitAmt = string.Format("{0:C2}", existingRPPBaseAMB);
                    }
                    else
                    {
                        gLTDandIDIBenefitSummaryValues.ProposedGSIBaseBenefitIncreaseAmt = GetBaseBenefitCalculatedAmount(planDesignType, baseIllustrationParticipantPlan?.AMBCalculatedAmount, participant.RPPBenefitCalculatedAmount, minimumBenefitAmount, true);
                        gLTDandIDIBenefitSummaryValues.ProposedGSIBaseBenefitNewAmt = "$0.00";
                        var existingGSIIDIBaseAMB = participant.ParticipantExistingPolicies?.FirstOrDefault()?.GSIIDIBaseAMB;
                        gLTDandIDIBenefitSummaryValues.ExistingGSIBaseBenefitAmt = string.Format("{0:C2}", existingGSIIDIBaseAMB);

                        decimal? fullyUnderwrittenIDI = Convert.ToDecimal(participant.ParticipantExistingPolicies?.FirstOrDefault()?.FullyUnderwrittenIDI);
                        decimal? otherExistingIDICoverageTotal = Convert.ToDecimal(participant.OtherExistingIDICoverageTotalCalculatedAmount);
                        gLTDandIDIBenefitSummaryValues.ExistingIDICoverageAmt = string.Format("{0:C2}", (otherExistingIDICoverageTotal));

                    }
                }
                else
                {
                    if (planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                    {
                        gLTDandIDIBenefitSummaryValues.ProposedRPPBaseBenefitIncreaseAmt = "$0.00";
                        gLTDandIDIBenefitSummaryValues.ExistingRPPBaseBenefitAmt = "$0.00";
                        gLTDandIDIBenefitSummaryValues.ProposedRPPBaseBenefitNewAmt = GetBaseBenefitCalculatedAmount(planDesignType, baseIllustrationParticipantPlan?.GSIAmount, participant.RPPBenefitCalculatedAmount, minimumBenefitAmount, false);
                    }
                    else
                    {
                        gLTDandIDIBenefitSummaryValues.ProposedGSIBaseBenefitIncreaseAmt = "$0.00";
                        gLTDandIDIBenefitSummaryValues.ExistingGSIBaseBenefitAmt = "$0.00";
                        gLTDandIDIBenefitSummaryValues.ProposedGSIBaseBenefitNewAmt = GetBaseBenefitCalculatedAmount(planDesignType, baseIllustrationParticipantPlan?.GSIAmount, participant.RPPBenefitCalculatedAmount, minimumBenefitAmount, false);
                    }
                }
            }
            else
            {
                gLTDandIDIBenefitSummaryValues.GSIBaseBenefitAmt = GetBaseBenefitCalculatedAmount(planDesignType, baseIllustrationParticipantPlan?.GSIAmount, participant.RPPBenefitCalculatedAmount, minimumBenefitAmount, false);
            }

            if (planDesignType != PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                if (hasBuyUpPlan)
                {
                    if (planDesignGSIType != PlanDesignGSITypeEnum.SupplementalPlan)
                    {
                        gLTDandIDIBenefitSummaryValues.IDIBaseReplacePercentAmt = string.Format("{0:P2}", baseIllustrationParticipantPlan.IDIBaseReplacementCalculatedPercentage);
                    }
                }
                else
                {
                    gLTDandIDIBenefitSummaryValues.IDIBaseReplacePercentAmt = string.Format("{0:P2}", baseIllustrationParticipantPlan.IDIBaseReplacementCalculatedPercentage);
                }
            }

            if (planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                gLTDandIDIBenefitSummaryValues.RetirmentContributionsAmt = string.Format("{0:C2}", participant.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount);

                if (!isReEnrollmentCase)
                {
                    if (participant.RPPBenefitCalculatedAmount > baseIllustrationParticipantPlan.GSIAmount)
                    {
                        gLTDandIDIBenefitSummaryValues.RPPBenefitAmt = string.Format("{0:C2}", baseIllustrationParticipantPlan.GSIAmount); //Defect D-02710 - Max GSI not limiting RPP Cap
                    }
                    else
                    {
                        gLTDandIDIBenefitSummaryValues.RPPBenefitAmt = string.Format("{0:C2}", participant.RPPBenefitCalculatedAmount);
                    }
                }

                decimal? rppBasePremiumPercent = 0.0M;
                if (participant.RPPBenefitCalculatedAmount != null && participant.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount != null)
                    rppBasePremiumPercent = (participant.RPPBenefitCalculatedAmount * 12 / participant.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount).Value.Roundoff(4);

                gLTDandIDIBenefitSummaryValues.RPPBasePremiumPercentAmt = string.Format("{0:P2}", rppBasePremiumPercent);

            }

            if (baseIllustrationParticipantPlan?.TotalGLTDPlusIDICalculatedAmount == null)
            {
                gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt = "";
            }
            else if (baseIllustrationParticipantPlan?.TotalGLTDPlusIDICalculatedAmount < 0)
            {
                gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt = "$0.00";
            }
            else
            {
                gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt = string.Format("{0:C2}", baseIllustrationParticipantPlan?.TotalGLTDPlusIDICalculatedAmount);
            }

            if (planDesignType != PlanDesignTypeEnum.BonusOnlyPlan)
            {
                gLTDandIDIBenefitSummaryValues.GLTDReplacePercentAmt = string.Format("{0:P2}", baseIllustrationParticipantPlan?.GLTDReplacementCalculatedPercentage);
                gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIPercentAmt = string.Format("{0:P2}", baseIllustrationParticipantPlan?.TotalGLTDPlusIDICalculatedPercentage);
            }
            gLTDandIDIBenefitSummaryValues.IDIInsurableIncomeAmt = string.Format("{0:C2}", baseIllustrationParticipantPlan?.IDIInsurableIncomeAmount);

            if (hasBuyUpPlan)
            {

                gLTDandIDIBenefitSummaryValues.ERPaidGSIBaseBenefitAmt = GetBaseBenefitCalculatedAmount(planDesignType, baseIllustrationParticipantPlan?.BaseGSIGLTDCaculatedAmount, participant.RPPBenefitCalculatedAmount, minimumBenefitAmount, false);

                if (baseIllustrationParticipantPlan?.BuyUpGSIGLTDCaculatedAmount < 0)
                {
                    gLTDandIDIBenefitSummaryValues.BuyUpGSIBaseBenefitAmt = "$0.00";
                }
                else
                {
                    gLTDandIDIBenefitSummaryValues.BuyUpGSIBaseBenefitAmt = string.Format("{0:C2}", (buyUpIllustrationParticipantPlan?.BuyUpGSIGLTDCaculatedAmount).Value.NearestRoundoff(10));
                }

                if (buyUpIllustrationParticipantPlan?.TotalGLTDPlusIDICalculatedAmount == null)
                {
                    gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt = "";
                }
                else if (buyUpIllustrationParticipantPlan?.TotalGLTDPlusIDICalculatedAmount < 0)
                {
                    gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt = "$0.00";
                }
                else
                {
                    gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt = string.Format("{0:C2}", buyUpIllustrationParticipantPlan?.TotalGLTDPlusIDICalculatedAmount);
                }

                if (planDesignType != PlanDesignTypeEnum.BonusOnlyPlan)
                {
                    gLTDandIDIBenefitSummaryValues.GLTDReplacePercentAmt = string.Format("{0:P2}", buyUpIllustrationParticipantPlan?.GLTDReplacementCalculatedPercentage);
                    gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIPercentAmt = string.Format("{0:P2}", buyUpIllustrationParticipantPlan?.TotalGLTDPlusIDICalculatedPercentage);
                }
                gLTDandIDIBenefitSummaryValues.IDIInsurableIncomeAmt = string.Format("{0:C2}", buyUpIllustrationParticipantPlan?.VGSIBuyupIDIInsurableIncomeAmount);
            }




            if (!hasBuyUpPlan)
            {
                if (receivedBaseBenefits != null && receivedBaseBenefits.Count > 0)
                {
                    foreach (var rider in request.PrimaryPlan.Benefits)
                    {
                        var baseActualBenefit = receivedBaseBenefits.FirstOrDefault(i => i.BenefitId == rider.BenefitId);
                        if (baseActualBenefit == null)
                        {
                            baseActualBenefit = receivedBaseBenefits.FirstOrDefault(i => (int)_productLibraryManager.FixBenefitTypeEnum((BenefitTypeEnum)i.BenefitId) == rider.BenefitId);
                        }
                        AssignGLTDRiderSummary(gLTDandIDIBenefitSummaryValues, response, rider, baseActualBenefit, isReEnrollmentCase);
                    }

                }
            }
            else
            {
                if (receivedBuyUpBenefits != null && receivedBuyUpBenefits.Count > 0)
                {
                    foreach (var rider in request.BuyUpPlan.Benefits)
                    {
                        if (receivedBaseBenefits != null && receivedBaseBenefits.Where(i => (int)_productLibraryManager.FixBenefitTypeEnum((BenefitTypeEnum)i.BenefitId) == rider.BenefitId).Count() == 0)
                        {
                            var buyUpActualBenefit = receivedBuyUpBenefits.FirstOrDefault(i => i.BenefitId == rider.BenefitId);
                            if (buyUpActualBenefit == null)
                            {
                                buyUpActualBenefit = receivedBuyUpBenefits.FirstOrDefault(i => (int)_productLibraryManager.FixBenefitTypeEnum((BenefitTypeEnum)i.BenefitId) == rider.BenefitId);
                            }
                            AssignGLTDRiderSummary(gLTDandIDIBenefitSummaryValues, response, rider, buyUpActualBenefit, isReEnrollmentCase);
                        }
                    }
                }
            }

            decimal basicCATAmt = 0.0m;
            decimal enhancedCATAmt = 0.0m;
            decimal.TryParse(gLTDandIDIBenefitSummaryValues.BasicCATAmt != null ? gLTDandIDIBenefitSummaryValues.BasicCATAmt.Replace("$", "") : "", out basicCATAmt);
            decimal.TryParse(gLTDandIDIBenefitSummaryValues.EnhancedCATAmt != null ? gLTDandIDIBenefitSummaryValues.EnhancedCATAmt.Replace("$", "") : "", out enhancedCATAmt);
            if (basicCATAmt == 0 && enhancedCATAmt == 0)
            {
                gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt = AssignTotalReplacementPercentAmount(gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt, string.Empty, gLTDandIDIBenefitSummaryValues.IDIInsurableIncomeAmt);
            }

            //Log.TraceFormat("-GetGSIBenefitSummaryValues");
            return gLTDandIDIBenefitSummaryValues;
        }

        private string GetBaseBenefitCalculatedAmount(PlanDesignTypeEnum? planDesignType, decimal? gsiCalculatedAmount, decimal? rppBenefitCalculatedAmount, decimal? minimumBenefitAmount, bool isAMBPolicy)
        {
            decimal? gsiBaseBenefitAmt;
            string formattedGSIAmount = string.Empty;
            decimal ambMinimumBenefitAmount = 50.0m;

            if (planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                gsiBaseBenefitAmt = rppBenefitCalculatedAmount;
            }
            else
            {
                gsiBaseBenefitAmt = gsiCalculatedAmount != null ? gsiCalculatedAmount.Value.NearestRoundoff(10) : 0.0m;
            }

            if (gsiBaseBenefitAmt == null)
            {
                formattedGSIAmount = "";
            }
            else if ((gsiBaseBenefitAmt < minimumBenefitAmount) && !isAMBPolicy)
            {
                formattedGSIAmount = "$0.00";
            }
            else if ((gsiBaseBenefitAmt < ambMinimumBenefitAmount) && isAMBPolicy)
            {
                formattedGSIAmount = "$0.00";
            }
            else
            {
                formattedGSIAmount = string.Format("{0:C2}", gsiBaseBenefitAmt);
            }

            return formattedGSIAmount;
        }

        private void AssignGLTDRiderSummary(GLTDandIDIBenefitBenefitSummaries gLTDandIDIBenefitSummaryValues, PremiumCalculatorResponse response,
            IllustrationRequestBenefit rider, IllustrationRequestBenefit actualBenefit, bool isReEnrollmentCase)
        {

            rider.BenefitId = (int)_productLibraryManager.FixBenefitTypeEnum((BenefitTypeEnum)rider.BenefitId);
            var premiumAmount = response.Rates.FirstOrDefault(c => c.RiderId == rider.BenefitId);

            decimal riderPremiumAmt = 0.0m;
            if (premiumAmount != null)
            {
                decimal.TryParse(premiumAmount.Premium.Replace("$", ""), out riderPremiumAmt);
            }



            switch ((BenefitGroupTypeEnum)rider.BenefitGroupTypeId)
            {
                case BenefitGroupTypeEnum.PartialDisability:

                    if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedPartialDisabilityRider)
                        gLTDandIDIBenefitSummaryValues.EnhancedPartialDisabilityAmt = null;
                    else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicPartialDisabilityRider)
                        gLTDandIDIBenefitSummaryValues.BasicPartialDisabilityAmt = null;
                    else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider)
                        gLTDandIDIBenefitSummaryValues.ShortTermResidualDisabilityAmt = null;
                    break;

                case BenefitGroupTypeEnum.CatastrophicDisabilityBenefit:

                    if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider)

                        if (actualBenefit == null)
                        {
                            gLTDandIDIBenefitSummaryValues.EnhancedCATAmt = "$0.00";
                        }
                        else if (actualBenefit.Amount < 0 || riderPremiumAmt == 0)
                        {
                            string totlReplaceAmt = string.Empty;
                            totlReplaceAmt = gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt != null ? gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt : string.Empty;

                            gLTDandIDIBenefitSummaryValues.EnhancedCATAmt = "$0.00";
                            //gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt = totlReplaceAmt != "" ? totlReplaceAmt  : "0 %";
                        }
                        else
                        {
                            gLTDandIDIBenefitSummaryValues.EnhancedCATAmt = string.Format("{0:C2}", actualBenefit.Amount);
                            //gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt = AssignTotalReplacementPercentAmount(gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt, gLTDandIDIBenefitSummaryValues.EnhancedCATAmt, gLTDandIDIBenefitSummaryValues.IDIInsurableIncomeAmt);
                        }

                    else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)


                        if (actualBenefit == null)
                        {
                            //string totlReplaceAmt = string.Empty;
                            //totlReplaceAmt = gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt != null ? gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt : string.Empty;

                            gLTDandIDIBenefitSummaryValues.BasicCATAmt = "$0.00";
                            //gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt = totlReplaceAmt != "" ? totlReplaceAmt : "0 %";
                        }
                        else if (actualBenefit.Amount < 0 || riderPremiumAmt == 0)
                        {
                            //string totlReplaceAmt = string.Empty;
                            //totlReplaceAmt = gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt != null ? gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt : string.Empty;

                            gLTDandIDIBenefitSummaryValues.BasicCATAmt = "$0.00";
                            //gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt = totlReplaceAmt != "" ? totlReplaceAmt : "0 %";
                        }
                        else
                        {
                            gLTDandIDIBenefitSummaryValues.BasicCATAmt = string.Format("{0:C2}", actualBenefit.Amount);

                        }
                    break;

                case BenefitGroupTypeEnum.CostOfLivingAdjustment:

                    if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving6PercentMaximum)
                        gLTDandIDIBenefitSummaryValues.SixCOLAAmt = null;
                    else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving3PercentCompound)
                        gLTDandIDIBenefitSummaryValues.ThreeCOLAAmt = null;
                    else if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.CostOfLiving4YearDelayed)
                        gLTDandIDIBenefitSummaryValues.FourYearDelayCOLAAmt = null;
                    break;

                case BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit:
                    if (actualBenefit == null)
                    {
                        gLTDandIDIBenefitSummaryValues.RPPBenefitAmt = "$0.00";
                    }

                    else if (actualBenefit.Amount < 0 || riderPremiumAmt == 0)
                    {
                        gLTDandIDIBenefitSummaryValues.RPPBenefitAmt = "$0.00";
                    }
                    else
                    {
                        gLTDandIDIBenefitSummaryValues.RPPBenefitAmt = string.Format("{0:C2}", actualBenefit.Amount);
                    }
                    break;

                case BenefitGroupTypeEnum.StudentLoanProtectionRider:
                    if (rider.Amount == null)
                    {
                        gLTDandIDIBenefitSummaryValues.SLPBenefitAmt = "";
                    }
                    else if (rider.Amount < 0 || riderPremiumAmt == 0)
                    {
                        gLTDandIDIBenefitSummaryValues.SLPBenefitAmt = "$0.00";
                    }
                    else
                    {
                        gLTDandIDIBenefitSummaryValues.SLPBenefitAmt = string.Format("{0:C2}", rider.Amount);
                    }
                    break;

                case BenefitGroupTypeEnum.SupplementalBenefit:
                    if (rider.Amount == null)
                    {
                        gLTDandIDIBenefitSummaryValues.SBTBenefitAmt = "";
                    }
                    else if (rider.Amount < 0 || riderPremiumAmt == 0)
                    {
                        gLTDandIDIBenefitSummaryValues.SBTBenefitAmt = "$0.00";
                    }
                    else
                    {
                        gLTDandIDIBenefitSummaryValues.SBTBenefitAmt = string.Format("{0:C2}", rider.Amount);
                    }
                    break;
            }


            switch ((BenefitTypeEnum)rider.BenefitId)
            {
                case BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement:
                    gLTDandIDIBenefitSummaryValues.SeriousIllnessBenefitAmt = null;
                    break;
                case BenefitTypeEnum.LumpSumIndemnityRider:
                    gLTDandIDIBenefitSummaryValues.LumpSumAmt = null;
                    break;
            }




            decimal basicCATAmt = 0.0m;
            decimal.TryParse(gLTDandIDIBenefitSummaryValues.BasicCATAmt != null ? gLTDandIDIBenefitSummaryValues.BasicCATAmt.Replace("$", "") : "", out basicCATAmt);
            if (basicCATAmt > 0)
            {
                gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt = AssignTotalReplacementPercentAmount(gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt, gLTDandIDIBenefitSummaryValues.BasicCATAmt, gLTDandIDIBenefitSummaryValues.IDIInsurableIncomeAmt);
            }

            decimal enhancedCATAmt = 0.0m;
            decimal.TryParse(gLTDandIDIBenefitSummaryValues.EnhancedCATAmt != null ? gLTDandIDIBenefitSummaryValues.EnhancedCATAmt.Replace("$", "") : "", out enhancedCATAmt);
            if (enhancedCATAmt > 0)
            {
                gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt = AssignTotalReplacementPercentAmount(gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt, gLTDandIDIBenefitSummaryValues.EnhancedCATAmt, gLTDandIDIBenefitSummaryValues.IDIInsurableIncomeAmt);
            }

            if (basicCATAmt == 0 && enhancedCATAmt == 0)
            {
                gLTDandIDIBenefitSummaryValues.TotalReplacementPercentAmt = AssignTotalReplacementPercentAmount(gLTDandIDIBenefitSummaryValues.TotalGLTDPlusIDIAmt, string.Empty, gLTDandIDIBenefitSummaryValues.IDIInsurableIncomeAmt);
            }

        }
        private string AssignTotalReplacementPercentAmount(string totalGLTDPlusIDIAmount, string catAmount, string idiIInsurableIncomeAmount)
        {
            string result = string.Empty;
            decimal totlGLTDPlusIDIAmt = 0.0m;
            decimal catBenefitAmt = 0.0m;
            decimal idiIInsurableIncomeAmt = 0.0m;

            decimal.TryParse(totalGLTDPlusIDIAmount.Replace("$", ""), out totlGLTDPlusIDIAmt);
            decimal.TryParse(catAmount.Replace("$", ""), out catBenefitAmt);
            decimal.TryParse(idiIInsurableIncomeAmount.Replace("$", ""), out idiIInsurableIncomeAmt);

            result = idiIInsurableIncomeAmt != 0 ? string.Format("{0:P2}", (totlGLTDPlusIDIAmt + catBenefitAmt) * 12 / idiIInsurableIncomeAmt) : "0 %";
            return result;

        }
        public string GetPlanDesignDescription(PlanDesignRequestClass pdrClass)
        {
            Log.TraceFormat("+GetPlanDesignDescription");

            string planDesign = string.Empty;

            if (pdrClass.ApprovedPlanDesignType == PlanDesignTypeEnum.SupplementalPlan)
            {
                planDesign = pdrClass.ApprovedMaximumReplacementRatio.Value + "% less LTD";
            }
            else if (pdrClass.ApprovedPlanDesignType == PlanDesignTypeEnum.BonusOnlyPlan)
            {
                planDesign = pdrClass.ApprovedMaximumReplacementRatio.Value + "% of Variable Compensation";
            }
            else if (pdrClass.ApprovedPlanDesignType == PlanDesignTypeEnum.CombinationPlan)
            {
                planDesign = pdrClass.ApprovedLTDPercentage.Value + "% LTD/" + pdrClass.ApprovedIDIPercentage.Value + "% IDI";
            }
            else if (pdrClass.ApprovedPlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan)
            {
                planDesign = "$" + (pdrClass.ApprovedFlatRateType != null && pdrClass.ApprovedFlatRateType.Id == 99 ? pdrClass.ApprovedFlatRate_Other.Value.ToString("#,##0") : Convert.ToInt32(pdrClass.ApprovedFlatRateType.Description).ToString("#,##0")) + " per month";
            }

            Log.TraceFormat("-GetPlanDesignDescription");
            return planDesign;
        }

        public string GetBuyUpPlanDesignDescription(PlanDesignRequestClass pdrClass)
        {
            Log.TraceFormat("+GetBuyUpPlanDesignDescription");

            string planDesign = string.Empty;

            if (pdrClass.ApprovedVoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.SupplementalPlan)
            {
                planDesign = pdrClass.ApprovedGSIBuyUpReplacementPercentage.Value + "% less LTD & Employer Paid GSI Base";
            }
            else if (pdrClass.ApprovedVoluntaryGSIBuyUpPlanDesignType == PlanDesignGSITypeEnum.BonusOnlyPlan)
            {
                planDesign = pdrClass.ApprovedGSIBuyUpReplacementPercentage.Value + "% of " + pdrClass.BuyUpInsurableIncomeDefinition;
            }

            Log.TraceFormat("-GetBuyUpPlanDesignDescription");
            return planDesign;
        }

        public string GetSoldBuyUpPlanDesignDescription(PDRSoldClassPlan pdrSoldClass)
        {
            Log.TraceFormat("+GetSoldBuyUpPlanDesignDescription");
            string planDesign = string.Empty;

            if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.SupplementalPlan)
            {
                planDesign = pdrSoldClass.ReplacementPercentage.Value + "% less LTD & Employer Paid GSI Base";
            }
            else if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.BonusOnlyPlan)
            {
                planDesign = pdrSoldClass.ReplacementPercentage.Value + "% of " + pdrSoldClass.InsurableIncomeDefinition;
            }

            Log.TraceFormat("-GetSoldBuyUpPlanDesignDescription");
            return planDesign;
        }

        public string GetPlanDesignTypeDescription(PlanDesignTypeEnum? planDesignType)
        {
            Log.TraceFormat("+GetPlanDesignTypeDescription");

            string planDesignTypeDesc = string.Empty;

            if (planDesignType == PlanDesignTypeEnum.CombinationPlan)
                planDesignTypeDesc = "Combination Plan";
            else
                planDesignTypeDesc = planDesignType.GetDescription();


            Log.TraceFormat("-GetPlanDesignTypeDescription");
            return planDesignTypeDesc;
        }

        public string GetSoldPlanDesignDescription(PDRSoldClassPlan pdrSoldClass)
        {
            Log.TraceFormat("+GetSoldPlanDesignDescription");
            string planDesign = string.Empty;

            if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.SupplementalPlan)
            {
                planDesign = pdrSoldClass.MaximumReplacementRatio.Value + "% less LTD";
            }
            else if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.BonusOnlyPlan)
            {
                planDesign = pdrSoldClass.MaximumReplacementRatio.Value + "% of Variable Compensation";
            }
            else if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.CombinationPlan)
            {
                planDesign = pdrSoldClass.LTDPercentage.Value + "% LTD/" + pdrSoldClass.IDIPercentage.Value + "% IDI";
            }
            else if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan)
            {
                planDesign = "$" + (pdrSoldClass.FlatRateType != null && pdrSoldClass.FlatRateType.Id == 99 ? pdrSoldClass.FlatRate_Other.Value.ToString("#,##0") : Convert.ToInt32(pdrSoldClass.FlatRateType.Description).ToString("#,##0")) + " per month";
            }
            Log.TraceFormat("-GetSoldPlanDesignDescription");
            return planDesign;
        }

        public string GetMaximumIPDescription(PlanDesignTypeEnum? planDesignType, PlanDesignRequestClass planDesignRequestClass, IUnitOfWork unitOfWork)
        {
            Log.TraceFormat("+GetMaximumIPDescription");

            string maximumIPDescription = string.Empty;

            ParticipationLimitMaximumCalculator participationLimitMaximumCalculator = new ParticipationLimitMaximumCalculator();
            IssueLimitMaximumCalculator issueLimitMaximumCalculator = new IssueLimitMaximumCalculator();
            BenefitAmountsCalculationRequest request = new BenefitAmountsCalculationRequest();

            decimal? issueLimitMaximum = null;
            decimal? participationLimitMaximum = null;



            request.ExistingIDIAmount = 0.0m;
            request.ClassCalculationRequest.PlanDesignType = planDesignType;

            request.ClassCalculationRequest.ContractState = planDesignRequestClass.PlanDesignRequest?.Case?.CaseUnderwritingRequests.FirstOrDefault()?.StateType;
            bool isCAState = request.ClassCalculationRequest.ContractState == StateTypeEnum.CA ? true : false;

            var eligibilityConfigurationDto = GetClassOverideMaximumValues(planDesignRequestClass, unitOfWork);

            if (planDesignType == PlanDesignTypeEnum.StandAloneIDIPlan)
            {
                if (eligibilityConfigurationDto.IssueLimitMaximum != null && !isCAState)
                {
                    maximumIPDescription = string.Format("{0:C2}", eligibilityConfigurationDto.IssueLimitMaximum) + " IDI";
                }
                else if (eligibilityConfigurationDto.IssueLimitMaximum != null && isCAState)
                {
                    maximumIPDescription = string.Format("{0:C2}", eligibilityConfigurationDto.CAIssueLimitMaximum) + " IDI";
                }
                else
                {
                    maximumIPDescription = "$20,000.00 IDI";
                }
            }
            else
            {

                if (eligibilityConfigurationDto.IssueLimitMaximum != null && !isCAState)
                {
                    issueLimitMaximum = eligibilityConfigurationDto.IssueLimitMaximum;
                }
                else if (eligibilityConfigurationDto.IssueLimitMaximum != null && isCAState)
                {
                    issueLimitMaximum = eligibilityConfigurationDto.CAIssueLimitMaximum;
                }
                else
                {
                    issueLimitMaximum = issueLimitMaximumCalculator.Calculate(request);
                }

                if (eligibilityConfigurationDto.ParticipationLimit != null &&  !isCAState)
                {
                    participationLimitMaximum = eligibilityConfigurationDto.ParticipationLimit;
                }
                else if (eligibilityConfigurationDto.ParticipationLimit != null && isCAState)
                {
                    participationLimitMaximum = eligibilityConfigurationDto.CAParticipationLimit;
                }
                else
                {
                    participationLimitMaximum = participationLimitMaximumCalculator.Calculate(request);
                }

                maximumIPDescription = string.Format("{0:C2}", issueLimitMaximum) + " / " + string.Format("{0:C2}", participationLimitMaximum);
            }

            Log.TraceFormat("-GetMaximumIPDescription");

            return maximumIPDescription;
        }

        private EligibilityConfigurationDto GetClassOverideMaximumValues(PlanDesignRequestClass planDesignRequestClass, IUnitOfWork unitOfWork)
        {
            var eligibilityConfigurationDto = new EligibilityConfigurationDto();

            if (planDesignRequestClass != null)
            {
                StateTypeEnum? contractState = planDesignRequestClass.PlanDesignRequest?.Case?.CaseUnderwritingRequests.FirstOrDefault()?.StateType;
                bool isCAStateType = contractState == StateTypeEnum.CA ? true : false;
                var eligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().Where(c => c.PlanDesignRequestClass != null).FirstOrDefault(c => c.PlanDesignRequestClass.Id == planDesignRequestClass.Id);
                var cmsDefaultEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(e => e.Case == null && e.PlanDesignRequest == null && e.PlanDesignRequestClass == null);
                if (eligibilityConfiguration != null)
                {
                    if(eligibilityConfiguration.IssueLimitMaximum!=null && eligibilityConfiguration.IssueLimitMaximum>0)
                    {
                        eligibilityConfigurationDto.IssueLimitMaximum = eligibilityConfiguration.IssueLimitMaximum;
                        eligibilityConfigurationDto.CAIssueLimitMaximum = eligibilityConfiguration.IssueLimitMaximum;
                    }
                    else if(eligibilityConfiguration.IssueLimitMaximum == null && !isCAStateType)
                    {
                        eligibilityConfigurationDto.IssueLimitMaximum = cmsDefaultEligibilityConfiguration.IssueLimitMaximum;
                    }
                    else if(eligibilityConfiguration.IssueLimitMaximum == null && isCAStateType)
                    {
                        eligibilityConfigurationDto.CAIssueLimitMaximum = cmsDefaultEligibilityConfiguration.CAIssueLimitMaximum;
                    }

                    if(eligibilityConfiguration.ParticipationLimit!=null && eligibilityConfiguration.ParticipationLimit>0)
                    {
                        eligibilityConfigurationDto.ParticipationLimit = eligibilityConfiguration.ParticipationLimit;
                        eligibilityConfigurationDto.CAParticipationLimit= eligibilityConfiguration.ParticipationLimit;
                    }
                    else if(eligibilityConfiguration.ParticipationLimit == null && !isCAStateType)
                    {
                        eligibilityConfigurationDto.ParticipationLimit = cmsDefaultEligibilityConfiguration.ParticipationLimit;
                    }
                    else if(eligibilityConfiguration.ParticipationLimit == null && isCAStateType)
                    {
                        eligibilityConfigurationDto.CAParticipationLimit = cmsDefaultEligibilityConfiguration.CAParticipationLimit;
                    }
                }
            }
            return eligibilityConfigurationDto;
        }

        public string GetMentalSubstanceDescription(int mentalSubstanceId)
        {
            Log.TraceFormat("+GetMentalSubstanceDescription");
            string mentalSubstanceDescription;

            if ((MentalSubstanceLimitationEnum)mentalSubstanceId == MentalSubstanceLimitationEnum._Nolimitation)
            {
                mentalSubstanceDescription = "There is no limitation for Mental and/or Substance Related Disorders";
            }
            else
            {
                mentalSubstanceDescription = ((MentalSubstanceLimitationEnum)mentalSubstanceId).GetDescription().Contains("Months") ? ((MentalSubstanceLimitationEnum)mentalSubstanceId).GetDescription().Replace("Months", "") : ((MentalSubstanceLimitationEnum)mentalSubstanceId).GetDescription();
            }

            Log.TraceFormat("-GetMentalSubstanceDescription");

            return mentalSubstanceDescription;
        }

        public string GetPreExistingConditionDescription(PreExistingConditionLimitTypeEnum preExistingCondition)
        {
            Log.TraceFormat("+GetPreExistingConditionDescription");
            string preExConditonDescription = "";
            switch ((PreExistingConditionLimitTypeEnum)preExistingCondition)
            {

                case PreExistingConditionLimitTypeEnum.None:
                    preExConditonDescription = "No Pre-Existing Condition Limitation";
                    break;

                case PreExistingConditionLimitTypeEnum._3_12:
                    preExConditonDescription = "3/12 Pre-Existing Condition Limitation";
                    break;

                case PreExistingConditionLimitTypeEnum._6_12:
                    preExConditonDescription = "6/12 Pre-Existing Condition Limitation";
                    break;

                case PreExistingConditionLimitTypeEnum._12_12:
                    preExConditonDescription = "12/12 Pre-Existing Condition Limitation";
                    break;

            }
            Log.TraceFormat("+GetPreExistingConditionDescription");
            return preExConditonDescription;
        }
        public string GetBaseSalaryDescription(PlanDesignRequestClass pdrClass)
        {
            Log.TraceFormat("+GetBaseSalaryDescription");

            StringBuilder baseSalarydescription = new StringBuilder();

            var pdrClassLTDCoverage = pdrClass.PlanDesignRequestClassLTDCoverage.FirstOrDefault(i => i.PlanDesignRequestClass.Id == pdrClass.Id);
            if (pdrClassLTDCoverage != null)
            {
                if (pdrClassLTDCoverage.BaseSalaryPercentage != null || pdrClassLTDCoverage.BonusPercentage != null ||
                    pdrClassLTDCoverage.CommissionPercentage != null || pdrClassLTDCoverage.K1EarningsPercentage != null ||
                    pdrClassLTDCoverage.BonusNumberofYears != null || pdrClassLTDCoverage.CommissionNumberofYears != null || pdrClassLTDCoverage.K1EarningsNumberofYears != null)
                {
                    if (pdrClassLTDCoverage.BaseSalaryPercentage > 0)
                    {
                        baseSalarydescription.AppendLine(string.Format("Base Salary at {0:P2} ", pdrClassLTDCoverage.BaseSalaryPercentage));
                    }

                    if (pdrClassLTDCoverage.BonusPercentage > 0 && pdrClassLTDCoverage.BonusNumberofYears > 0)
                    {
                        baseSalarydescription.AppendLine(string.Format("+ most recent {0} years of Bonus at {1:P2} ", pdrClassLTDCoverage.BonusNumberofYears, pdrClassLTDCoverage.BonusPercentage));
                    }

                    if (pdrClassLTDCoverage.CommissionPercentage > 0 && pdrClassLTDCoverage.CommissionNumberofYears > 0)
                    {
                        baseSalarydescription.AppendLine(string.Format("+ most recent {0} years of Commission at {1:P2} ", pdrClassLTDCoverage.CommissionNumberofYears, pdrClassLTDCoverage.CommissionPercentage));
                    }

                    if (pdrClassLTDCoverage.K1EarningsPercentage > 0 && pdrClassLTDCoverage.K1EarningsNumberofYears > 0)
                    {
                        baseSalarydescription.AppendLine(string.Format("+ most recent {0} years of K1Earnings at {1:P2} ", pdrClassLTDCoverage.K1EarningsNumberofYears, pdrClassLTDCoverage.K1EarningsPercentage));
                    }
                }
                else
                {
                    if (pdrClassLTDCoverage.GroupLTDCoveredEarningsType != null)
                    {
                        baseSalarydescription.AppendLine(pdrClassLTDCoverage.GroupLTDCoveredEarningsType.GetDescription());
                    }

                }
            }

            Log.TraceFormat("-GetBaseSalaryDescription");

            return baseSalarydescription.ToString();
        }

        public string GetSoldBaseSalaryDescription(PDRSoldClass pdrClass)
        {
            Log.TraceFormat("+GetBaseSalaryDescription");

            StringBuilder baseSalarydescription = new StringBuilder();

            var pdrClassLTDCoverage = pdrClass.PDRSoldClassLTDCoverage.FirstOrDefault(x => x.PDRSoldClass.PlanDesignRequestClass.Id == pdrClass.PlanDesignRequestClass.Id);
            if (pdrClassLTDCoverage != null)
            {

                if (pdrClassLTDCoverage.BaseSalaryPercentage != null || pdrClassLTDCoverage.BonusPercentage != null ||
                    pdrClassLTDCoverage.CommissionPercentage != null || pdrClassLTDCoverage.K1EarningsPercentage != null ||
                    pdrClassLTDCoverage.BonusNumberofYears != null || pdrClassLTDCoverage.CommissionNumberofYears != null || pdrClassLTDCoverage.K1EarningsNumberofYears != null)
                {
                    if (pdrClassLTDCoverage.BaseSalaryPercentage > 0)
                    {
                        baseSalarydescription.AppendLine(string.Format("Base Salary at {0:P2} ", pdrClassLTDCoverage.BaseSalaryPercentage));
                    }

                    if (pdrClassLTDCoverage.BonusPercentage > 0 && pdrClassLTDCoverage.BonusNumberofYears > 0)
                    {
                        baseSalarydescription.AppendLine(string.Format("+ most recent {0} years of Bonus at {1:P2} ", pdrClassLTDCoverage.BonusNumberofYears, pdrClassLTDCoverage.BonusPercentage));
                    }

                    if (pdrClassLTDCoverage.CommissionPercentage > 0 && pdrClassLTDCoverage.CommissionNumberofYears > 0)
                    {
                        baseSalarydescription.AppendLine(string.Format("+ most recent {0} years of Commission at {1:P2} ", pdrClassLTDCoverage.CommissionNumberofYears, pdrClassLTDCoverage.CommissionPercentage));
                    }

                    if (pdrClassLTDCoverage.K1EarningsPercentage > 0 && pdrClassLTDCoverage.K1EarningsNumberofYears > 0)
                    {
                        baseSalarydescription.AppendLine(string.Format("+ most recent {0} years of K1Earnings at {1:P2} ", pdrClassLTDCoverage.K1EarningsNumberofYears, pdrClassLTDCoverage.K1EarningsPercentage));
                    }
                }
                else
                {
                    if (pdrClassLTDCoverage.GroupLTDCoveredEarningsType != null)
                    {
                        baseSalarydescription.AppendLine(pdrClassLTDCoverage.GroupLTDCoveredEarningsType.GetDescription());
                    }
                }

            }
            Log.TraceFormat("-GetBaseSalaryDescription");

            return baseSalarydescription.ToString();
        }

        public string GetDiscountPercentageForSoldClass(PDRSoldClassPlan primaryPlan)
        {
            string caseLevelDiscountPercentage = string.Empty;
            int baseDiscountName = 0;
            int demographicDiscountName = 0;
            int employerPaidDiscountName = 0;

            if (primaryPlan.BaseDiscountType != null)
            {
                int baseDiscount = 0;
                if (int.TryParse(primaryPlan.BaseDiscountType.Code, out baseDiscount))
                {
                    baseDiscountName = baseDiscount;
                }
            }

            if (primaryPlan.DemographicDiscountType != null)
            {
                int demographicDiscount = 0;
                if (int.TryParse(primaryPlan.DemographicDiscountType.Code, out demographicDiscount))
                {
                    demographicDiscountName = demographicDiscount;
                }
            }


            if (primaryPlan.EmployerPaidDiscountType != null)
            {
                int employerPaidDiscount = 0;
                if (int.TryParse(primaryPlan.EmployerPaidDiscountType.Code, out employerPaidDiscount))
                {
                    employerPaidDiscountName = employerPaidDiscount;
                }
            }




            var discountName = (baseDiscountName + demographicDiscountName + employerPaidDiscountName).ToString() + "%";
            caseLevelDiscountPercentage = discountName;

            return caseLevelDiscountPercentage;
        }

        public string GetDiscountPercentage(PlanDesignRequestClassProduct primaryPlan)
        {
            string caseLevelDiscountPercentage = string.Empty;
            int baseDiscountName = 0;
            int demographicDiscountName = 0;
            int employerPaidDiscountName = 0;
            if (primaryPlan.BaseDiscountType != null)
            {
                int baseDiscount = 0;
                if (int.TryParse(primaryPlan.BaseDiscountType.Code, out baseDiscount))
                {
                    baseDiscountName = baseDiscount;
                }
            }

            if (primaryPlan.DemographicDiscountType != null)
            {
                int demographicDiscount = 0;
                if (int.TryParse(primaryPlan.DemographicDiscountType.Code, out demographicDiscount))
                {
                    demographicDiscountName = demographicDiscount;
                }
            }


            if (primaryPlan.EmployerPaidDiscountType != null)
            {
                int employerPaidDiscount = 0;
                if (int.TryParse(primaryPlan.EmployerPaidDiscountType.Code, out employerPaidDiscount))
                {
                    employerPaidDiscountName = employerPaidDiscount;
                }
            }




            var discountName = (baseDiscountName + demographicDiscountName + employerPaidDiscountName).ToString() + "%";
            caseLevelDiscountPercentage = discountName;

            return caseLevelDiscountPercentage;
        }

        private string GetInsurableIncomeDefinitionForFlatBenefit(PlanDesignRequestClassLTDCoverage ltdCoverage, PDRSoldClassLTDCoverage soldLTDCoverage, bool isSold)
        {
            StringBuilder insurableIncomeDefinition = new StringBuilder();

            if (!isSold)
            {
                if (ltdCoverage.BaseSalaryPercentage != null || ltdCoverage.BonusPercentage != null
                                    || ltdCoverage.CommissionPercentage != null || ltdCoverage.K1EarningsPercentage != null
                                    || ltdCoverage.BonusNumberofYears != null || ltdCoverage.CommissionNumberofYears != null
                                    || ltdCoverage.K1EarningsNumberofYears != null || ltdCoverage.OtherIncomePercentage != null)
                {
                    if (ltdCoverage.BaseSalaryPercentage > 0)
                    {
                        if (ltdCoverage.BaseSalaryPercentage < 1)
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of Salary ", ltdCoverage.BaseSalaryPercentage));
                        }
                        else
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("Salary "));
                        }
                    }

                    if (ltdCoverage.BonusPercentage > 0 && ltdCoverage.BonusNumberofYears > 0)
                    {
                        if (ltdCoverage.BonusNumberofYears > 1)
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} years average Bonus ", ltdCoverage.BonusPercentage, ltdCoverage.BonusNumberofYears));
                        }
                        else
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} year Bonus ", ltdCoverage.BonusPercentage, ltdCoverage.BonusNumberofYears));
                        }

                    }

                    if (ltdCoverage.CommissionPercentage > 0 && ltdCoverage.CommissionNumberofYears > 0)
                    {
                        if (ltdCoverage.CommissionNumberofYears > 1)
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} years average Commission ", ltdCoverage.CommissionPercentage, ltdCoverage.CommissionNumberofYears));
                        }
                        else
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} year Commission ", ltdCoverage.CommissionPercentage, ltdCoverage.CommissionNumberofYears));
                        }
                    }

                    if (ltdCoverage.K1EarningsPercentage > 0 && ltdCoverage.K1EarningsNumberofYears > 0)
                    {
                        if (ltdCoverage.K1EarningsNumberofYears > 1)
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} years average K-1 Earnings ", ltdCoverage.K1EarningsPercentage, ltdCoverage.K1EarningsNumberofYears));
                        }
                        else
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} year K-1 Earnings ", ltdCoverage.K1EarningsPercentage, ltdCoverage.K1EarningsNumberofYears));
                        }

                    }
                    if (ltdCoverage.OtherIncomePercentage > 0)
                    {
                        insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of 1 year Other Income ", ltdCoverage.OtherIncomePercentage));
                    }
                }
                else
                {
                    insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForCoveredEarnings((CoveredEarningsTypeEnum)ltdCoverage.GroupLTDCoveredEarningsType));
                }
            }
            else
            {
                if (soldLTDCoverage.BaseSalaryPercentage != null || soldLTDCoverage.BonusPercentage != null
                                                    || soldLTDCoverage.CommissionPercentage != null || soldLTDCoverage.K1EarningsPercentage != null
                                                    || soldLTDCoverage.BonusNumberofYears != null || soldLTDCoverage.CommissionNumberofYears != null
                                                    || soldLTDCoverage.K1EarningsNumberofYears != null || soldLTDCoverage.OtherIncomePercentage != null)
                {
                    if (soldLTDCoverage.BaseSalaryPercentage > 0)
                    {
                        if (soldLTDCoverage.BaseSalaryPercentage < 1)
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("{0:0%} of Salary ", soldLTDCoverage.BaseSalaryPercentage));
                        }
                        else
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("Salary "));
                        }
                    }

                    if (soldLTDCoverage.BonusPercentage > 0 && soldLTDCoverage.BonusNumberofYears > 0)
                    {
                        if (soldLTDCoverage.BonusNumberofYears > 1)
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} years average Bonus ", soldLTDCoverage.BonusPercentage, soldLTDCoverage.BonusNumberofYears));
                        }
                        else
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} year Bonus ", soldLTDCoverage.BonusPercentage, soldLTDCoverage.BonusNumberofYears));
                        }

                    }

                    if (soldLTDCoverage.CommissionPercentage > 0 && soldLTDCoverage.CommissionNumberofYears > 0)
                    {
                        if (soldLTDCoverage.CommissionNumberofYears > 1)
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} years average Commission ", soldLTDCoverage.CommissionPercentage, soldLTDCoverage.CommissionNumberofYears));
                        }
                        else
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} year Commission ", soldLTDCoverage.CommissionPercentage, soldLTDCoverage.CommissionNumberofYears));
                        }
                    }

                    if (soldLTDCoverage.K1EarningsPercentage > 0 && soldLTDCoverage.K1EarningsNumberofYears > 0)
                    {
                        if (soldLTDCoverage.K1EarningsNumberofYears > 1)
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} years average K-1 Earnings ", soldLTDCoverage.K1EarningsPercentage, soldLTDCoverage.K1EarningsNumberofYears));
                        }
                        else
                        {
                            insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of {1} year K-1 Earnings ", soldLTDCoverage.K1EarningsPercentage, soldLTDCoverage.K1EarningsNumberofYears));
                        }

                    }
                    if (soldLTDCoverage.OtherIncomePercentage > 0)
                    {
                        insurableIncomeDefinition.AppendLine(string.Format("plus {0:0%} of 1 year Other Income ", soldLTDCoverage.OtherIncomePercentage));
                    }
                }
                else
                {
                    insurableIncomeDefinition.AppendLine(GetInsurableIncomeDefinitionForCoveredEarnings((CoveredEarningsTypeEnum)soldLTDCoverage.GroupLTDCoveredEarningsType));
                }
            }

            return insurableIncomeDefinition.ToString();
        }

        private string GetInsurableIncomeDefinitionForCoveredEarnings(CoveredEarningsTypeEnum selectedCoveredEarningsType)
        {
            StringBuilder resultDefinition = new StringBuilder();

            switch (selectedCoveredEarningsType)
            {
                case CoveredEarningsTypeEnum.BaseSalaryOnly:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.BaseSalaryOnly.GetDescription());
                    break;

                case CoveredEarningsTypeEnum.BaseSalary_Bonus:
                    resultDefinition.AppendLine("Salary plus:");
                    resultDefinition.AppendLine("	• Two years submitted Bonus, averaged, or");
                    resultDefinition.AppendLine("	• 75% of submitted One year bonus income");
                    break;

                case CoveredEarningsTypeEnum.BaseSalary_Bonus_Commission:
                    resultDefinition.AppendLine("Salary plus:");
                    resultDefinition.AppendLine("	• Two years submitted Bonus and Commission income, averaged, or");
                    resultDefinition.AppendLine("	• 75% of submitted One year bonus and commission income");
                    break;

                case CoveredEarningsTypeEnum.BaseSalary_Commission:
                    resultDefinition.AppendLine("Salary plus:");
                    resultDefinition.AppendLine("	• Two years submitted Commission income, averaged, or");
                    resultDefinition.AppendLine("	• 75% of submitted One year commission income");
                    break;

                case CoveredEarningsTypeEnum.IDIInsurableIncome:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.IDIInsurableIncome.GetDescription());
                    break;

                case CoveredEarningsTypeEnum.K_1Earnings:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.K_1Earnings.GetDescription());
                    break;

                case CoveredEarningsTypeEnum.Other:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.Other.GetDescription());
                    break;

                case CoveredEarningsTypeEnum.TotalCompensation:
                    resultDefinition.AppendLine(CoveredEarningsTypeEnum.TotalCompensation.GetDescription());
                    break;
            }
            return resultDefinition.ToString();
        }

        private List<CoveredEarningsBonusOnlyTypeEnum?> BuildCoveredEarningsBonusOnlyType(PDRClassCustomizedIDIInsurableIncome customizedIDI)
        {
            List<CoveredEarningsBonusOnlyTypeEnum?> coveredEarningsBonusOnlyTypeEnum = new List<CoveredEarningsBonusOnlyTypeEnum?>();

            if (customizedIDI.BonusPercentage.HasValue
                            && !customizedIDI.CommissionPercentage.HasValue)
            {
                coveredEarningsBonusOnlyTypeEnum.Add(CoveredEarningsBonusOnlyTypeEnum.Bonus);
            }
            else if (customizedIDI.BonusPercentage.HasValue
                && customizedIDI.CommissionPercentage.HasValue)
            {
                coveredEarningsBonusOnlyTypeEnum.Add(CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission);
            }
            else if (!customizedIDI.BonusPercentage.HasValue
                && customizedIDI.CommissionPercentage.HasValue)
            {
                coveredEarningsBonusOnlyTypeEnum.Add(CoveredEarningsBonusOnlyTypeEnum.Commissions);
            }
            if (customizedIDI.K1EarningsPercentage.HasValue)
            {
                coveredEarningsBonusOnlyTypeEnum.Add(CoveredEarningsBonusOnlyTypeEnum.K_1Earnings);
            }

            return coveredEarningsBonusOnlyTypeEnum;
        }

        private List<CoveredEarningsBonusOnlyTypeEnum?> BuildSoldCoveredEarningsBonusOnlyType(PDRSoldClassPlanCustomizedIDIInsurableIncome customizedIDI)
        {
            List<CoveredEarningsBonusOnlyTypeEnum?> coveredEarningsBonusOnlyTypeEnum = new List<CoveredEarningsBonusOnlyTypeEnum?>();

            if (customizedIDI.BonusPercentage.HasValue
                            && !customizedIDI.CommissionPercentage.HasValue)
            {
                coveredEarningsBonusOnlyTypeEnum.Add(CoveredEarningsBonusOnlyTypeEnum.Bonus);
            }
            else if (customizedIDI.BonusPercentage.HasValue
                && customizedIDI.CommissionPercentage.HasValue)
            {
                coveredEarningsBonusOnlyTypeEnum.Add(CoveredEarningsBonusOnlyTypeEnum.Bonus_Commission);
            }
            else if (!customizedIDI.BonusPercentage.HasValue
                && customizedIDI.CommissionPercentage.HasValue)
            {
                coveredEarningsBonusOnlyTypeEnum.Add(CoveredEarningsBonusOnlyTypeEnum.Commissions);
            }
            if (customizedIDI.K1EarningsPercentage.HasValue)
            {
                coveredEarningsBonusOnlyTypeEnum.Add(CoveredEarningsBonusOnlyTypeEnum.K_1Earnings);
            }

            return coveredEarningsBonusOnlyTypeEnum;
        }
        public string GetDefinitionOfDisablity(DefinitionOfDisabilityTypeEnum definitionOfDisabilityTypeEnum)
        {
            Log.TraceFormat("+GetDefinitionOfDisablity");
            string definitionOfDisabilityTypeDescription = "";
            switch ((DefinitionOfDisabilityTypeEnum)definitionOfDisabilityTypeEnum)
            {

                case DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc:
                    definitionOfDisabilityTypeDescription = "True Own Occupation with Enhanced Medical Specialty";
                    break;

                case DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc:
                    definitionOfDisabilityTypeDescription = "True Own Occupation with Medical/Dental Specialty";
                    break;

                case DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty:
                    definitionOfDisabilityTypeDescription = "True Own Occupation";
                    break;

                case DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc:
                    definitionOfDisabilityTypeDescription = "Two Year True Own Occupation (Modified Thereafter)";
                    break;
                case DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation:
                    definitionOfDisabilityTypeDescription = "Modified Own Occupation";
                    break;
                case DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc:
                    definitionOfDisabilityTypeDescription = "Two Year Modified Own Occupation (Any Occupation Thereafter)";
                    break;

            }
            Log.TraceFormat("-GetDefinitionOfDisablity");
            return definitionOfDisabilityTypeDescription;
        }
    }
}