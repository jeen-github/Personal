﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Logger.Static;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class PostCardXmlBuilder
    {
        public IUnitOfWorkFactory UnitOfWorkFactory { get; private set; }
        public PostCardXmlBuilder(IUnitOfWorkFactory unitOfWorkFactory)
        {
            UnitOfWorkFactory = unitOfWorkFactory;
        }

        public void CreatePostCardXml(PostCardXmlGenerationRequest request, PostCardXml postcardXml)
        {

            Log.TraceFormat("+CreatePostCardXml");
            try
            {
                using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
                {

                    var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                    var enrollment = cmsCase.CaseEnrollments.FirstOrDefault(c => c.Id == request.EnrollmentId);
                    var contactAddress = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId && c.ContactRoleType == ContactRoleTypeEnum.EnrollmentContact);
                    var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => c.Enrollment.Id == enrollment.Id && c.Participant.IsEligible == true && c.Participant.IsActive == true);
                    var caseDocument = unitOfWork.Repository<CaseDocument>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.Case_Id == request.CaseId && c.CaseDocumentType == CaseDocumentTypeEnum.CompanyLogo && !c.IsDeleted);
                    if (request.ParticipantIds != null && request.ParticipantIds.Count > 0)
                    {
                        enrollmentParticipants = enrollmentParticipants.Where(c => request.ParticipantIds.Contains(c.Id));
                    }

                    postcardXml.Participants = new List<PostCardXml.ExtreamGenerationParticipantXml>();
                    foreach (var enrollmentparticipant in enrollmentParticipants)
                    {
                        var participantDetails = unitOfWork.Repository<Participant>().Linq().FirstOrDefault(c => c.Id == enrollmentparticipant.Participant.Id);
                        var participantInfo = new PostCardXml.ExtreamGenerationParticipantXml();
                        participantInfo.firstName = participantDetails.FirstName ?? string.Empty;
                        participantInfo.lastName = participantDetails.LastName ?? string.Empty;
                        participantInfo.address.street1 = participantDetails.HomeStreet1 ?? string.Empty;
                        participantInfo.address.street2 = participantDetails.HomeStreet2 ?? string.Empty;
                        participantInfo.address.city = participantDetails.HomeCity ?? string.Empty;
                        participantInfo.address.state = participantDetails.HomeState?.ToString() ?? string.Empty;
                        participantInfo.address.zipCode = participantDetails.HomeZipCode ?? string.Empty;
                        postcardXml.Participants.Add(participantInfo);
                    }

                    postcardXml.enrollmentStartDate = enrollment.EnrollmentStartDate;
                    postcardXml.enrollmentEndDate = enrollment.EnrollmentEndDate;
                    if (contactAddress != null)
                    {
                        postcardXml.enrollmentContactName = contactAddress.ContactName ?? string.Empty;
                        postcardXml.enrollmentContactEmail = contactAddress.Email ?? string.Empty;
                        postcardXml.enrollmentContactPhoneNumber = contactAddress.Phone ?? string.Empty;
                    }
                    else
                    {
                        postcardXml.enrollmentContactName = string.Empty;
                        postcardXml.enrollmentContactEmail = string.Empty;
                        postcardXml.enrollmentContactPhoneNumber = string.Empty;
                    }
                    postcardXml.enrollmentWebsiteURL = enrollment.EnrollmentWebsite ?? string.Empty;
                    postcardXml.company.name = cmsCase.CompanyName ?? string.Empty;

                    if (caseDocument != null)
                    {
                        postcardXml.company.companyLogoBLOB = caseDocument.FileBytes == null ? string.Empty : Convert.ToBase64String(caseDocument.FileBytes);
                    }
                    else
                    {
                        postcardXml.company.companyLogoBLOB = string.Empty;
                    }

                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error in CreatePostCardXml method for EnrollmentId-" + request.EnrollmentId, ex);
            }

            Log.TraceFormat("-CreatepostCardXml");
        }
    }
}
