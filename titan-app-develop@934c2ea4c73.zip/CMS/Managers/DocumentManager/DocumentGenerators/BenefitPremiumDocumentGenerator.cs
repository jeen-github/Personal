﻿using CMS.DataAccess.Repositories;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Managers.WorkUnitManagers;
using Newtonsoft.Json;
using System.Threading;
using System.Web.Security;
using CMS.Interfaces.Managers.SecurityManagers;
using System.Web;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using System.IO;
using System.Diagnostics;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class BenefitPremiumDocumentGenerator : DocumentGenerator, IBenefitPremiumDocumentGenerator
    {
        private readonly IWorkUnitManager _workUnitManager;
        private readonly ISecurityManager _securityManager;
        public new IUnitOfWorkFactory UnitOfWorkFactory { get; private set; }
        public BenefitPremiumDocumentGenerator(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager, 
            ISecurityManager securityManager, IProductLibraryManager productLibraryManager) : base(unitOfWorkFactory, productLibraryManager)
        {
            _workUnitManager = workUnitManager;
            UnitOfWorkFactory = unitOfWorkFactory;
            _securityManager = securityManager;
        }

        public void CreateDocumentRequest(BenefitPremiumDocumentRequest request)
        {
            Log.TraceFormat("+CreateDocument CaseId: {0} B&P Name: {1}", request.CaseId, request.BenefitPremiumName);                      

            var cmsCase = GetCase(request.CaseId);
            var docRequestXml = CreateXml(request); 
            
            var caseDocumentRequest = CreateCaseDocumentRequest(docRequestXml, cmsCase, CaseDocumentTypeEnum.BenefitAndPremium);    

            var caseDocument = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.BenefitAndPremium, ExtreamDocumentType.PDF, null, request.BenefitPremiumName);

            StoreDocumentIdsToDatabase(request, caseDocument);

            _workUnitManager.CreateWorkUnit(WorkUnitType.ExtreamFileUpload, caseDocumentRequest.Id.ToString());

            Log.TraceFormat("-CreateDocument CaseId: {0} B&P Name: {1}", request.CaseId, request.BenefitPremiumName);
        }


        private void StoreDocumentIdsToDatabase(BenefitPremiumDocumentRequest request, CaseDocument caseDocument)
        {
            Log.TraceFormat("+StoreDocumentIdsToDatabase");

            try
            {
                Log.TraceFormat("Store document ids to DB.");
                using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
                {
                    var document = unitOfWork.Repository<BenefitPremiumDocument>().Linq().FirstOrDefault(q => q.Id == request.BenefitPremiumDocumentId);
                    if (document != null)
                    {
                        document.PdfDocument = caseDocument;

                        unitOfWork.Repository<BenefitPremiumDocument>().Save(document);
                        unitOfWork.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error saving doc ids in DB", ex);
                throw;
            }

            Log.TraceFormat("-StoreDocumentIdsToDatabase");
        }

        private string CreateXml(BenefitPremiumDocumentRequest request)
        {
            var startTime = DateTime.Now;
            Log.TraceFormat("+CreateBPXml CaseId : {0} B&P Name: {1}", request.CaseId, request.BenefitPremiumName);

            var commonXmlBuilder = new CaseCommonXmlBuilder(UnitOfWorkFactory);

            var bpXml = new BenefitPremiumXml();
            commonXmlBuilder.CreateCase(request, bpXml, bpXml.ExstreamRequestType);

            //Use Enrollment Kit generator for most of the re-usable data.
            var requestEnrl = new EnrollmentKitXmlGenerationRequest();
            var agentSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace, };
            var serPart = JsonConvert.SerializeObject(request, agentSettings);
            requestEnrl = JsonConvert.DeserializeObject<EnrollmentKitXmlGenerationRequest>(serPart);

            var enrlXml = new EnrollmentKitXml();
            var enrlSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace, };
            var enrlPart = JsonConvert.SerializeObject(bpXml, enrlSettings);
            enrlXml = JsonConvert.DeserializeObject<EnrollmentKitXml>(enrlPart);
            requestEnrl.SelectedForms = new List<EnrollmentKitTypeEnum>();

            var kitAddOns = new EnrollmentKitAdditionalData(UnitOfWorkFactory);
            kitAddOns.AddEnrollmentData(requestEnrl, enrlXml);


            UserInfoDto userInfo = null;

            if (HttpContext.Current != null)
            {
                userInfo = HttpContext.Current.User != null ? _securityManager.GetUserInfo(HttpContext.Current.User) : null;
            }


            string sequencecount = "001";

            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var caseBrokers = cmsCase.CaseBrokers.Where(c => c.Case.Id == request.CaseId);               
                var enrollment = cmsCase.CaseEnrollments.FirstOrDefault(c => c.Id == request.EnrollmentId);
                var enrollmentOutput = unitOfWork.Repository<EnrollmentOutput>().Linq().FirstOrDefault(c => c.Enrollment.Id == enrollment.Id);
               
                var enrollmentParticipents = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => c.Enrollment.Id == enrollment.Id &&
                        (c.Participant.IsEligible==true ||( c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.NoLongerInGroup &&
                        c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.ActivePolicyNoLongerInGroup && c.Participant.InEligibleReason_Id == null)));
                if (request.ParticipantIds != null && request.ParticipantIds.Count > 0)
                {
                    enrollmentParticipents = enrollmentParticipents.Where(c => request.ParticipantIds.Contains(c.Id));
                }
                
                var ProducercontactAddres = unitOfWork.Repository<ContactAddress>().Linq().Where(c => c.Case.Id == request.CaseId);
                ContactAddress returnAddre = null;
                if (enrollmentOutput != null && enrollmentOutput.ReturnAddress != null && enrollmentOutput.ReturnAddress.Id > 0)
                {
                    returnAddre = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId && c.Id == enrollmentOutput.ReturnAddress.Id);
                }

                var DISAddres = unitOfWork.Repository<ContactAddress>().Linq().FirstOrDefault(c => c.Case.Id == request.CaseId && c.ContactRoleType == ContactRoleTypeEnum.DIS);
                var BandPUser = unitOfWork.Repository<BenefitPremiumDocument>().Linq().FirstOrDefault(c => c.Enrollment.Id == request.EnrollmentId);
                var userID = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(c => c.LdapUserName.Equals(BandPUser.GeneratedBy));
             
                enrlXml.cmsProcessDate = DateTime.Now.ToString("MMddyyyy");
                enrlXml.cmsProcessTime = DateTime.Now.ToString("HHmmss");

                enrlXml.showCompanyNameOrLogo = enrollmentOutput != null ? IscompanyNameOrLogo(enrollmentOutput) : "None";

                if (userID != null)
                {
                    enrlXml.userID = userID.Id.ToString();
                }

                if (enrollmentOutput != null)
                {
                    if (enrollmentOutput.HRContact != null)
                    {
                        enrlXml.companyHRContact = enrollmentOutput.HRContact.ContactName != null ? enrollmentOutput.HRContact.ContactName : "";
                        enrlXml.companyHRContactEmail = enrollmentOutput.HRContact.Email != null ? enrollmentOutput.HRContact.Email : "";
                        enrlXml.companyHRContactPhone = enrollmentOutput.HRContact.Phone != null ? enrollmentOutput.HRContact.Phone : "";
                    }
                }

                if (DISAddres != null)
                {
                    enrlXml.disCode = DISAddres.DISCode != null ? DISAddres.DISCode : "";
                }

                if (enrollmentOutput != null)
                {
                    if (enrollmentOutput.ContactOne != null)
                    {
                        enrlXml.companyContact = enrollmentOutput.ContactOne.ContactName != null ? enrollmentOutput.ContactOne.ContactName : "";
                        enrlXml.companyContactEmail = enrollmentOutput.ContactOne.Email != null ? enrollmentOutput.ContactOne.Email : "";
                        enrlXml.companyContactPhone = enrollmentOutput.ContactOne.Phone != null ? enrollmentOutput.ContactOne.Phone : "";
                    }
                }

                if (enrollmentOutput != null)
                {
                    if (enrollmentOutput.ContactTwo != null)
                    {
                        enrlXml.companyContact2 = enrollmentOutput.ContactTwo.ContactName != null ? enrollmentOutput.ContactTwo.ContactName : "";
                        enrlXml.companyContact2Email = enrollmentOutput.ContactTwo.Email != null ? enrollmentOutput.ContactTwo.Email : "";
                        enrlXml.companyContact2Phone = enrollmentOutput.ContactTwo.Phone != null ? enrollmentOutput.ContactTwo.Phone : "";
                    }
                    if (returnAddre != null)
                    {

                        enrlXml.ReturnAddressName = returnAddre.ContactName != null ? returnAddre.ContactName : "";
                    }

                    enrlXml.CoverLetterIncluded = enrollmentOutput.IsCoverLetterIncluded;
                    var salutat = "";
                    if (enrollmentOutput.EnrollmentOutputSalutationType != null)
                    {
                        salutat = enrollmentOutput.EnrollmentOutputSalutationType.Description; ;
                    }
                    var saltxt = enrollmentOutput.SalutationText != null ? enrollmentOutput.SalutationText : "";
                    enrlXml.Salutation = salutat + " " + saltxt;                    
                    enrlXml.IncludeReplacementPercentage = enrollmentOutput.IsShowReplacementPercentage;

                    if (enrollmentOutput.EnrollmentOutputIncomeDefinitionType != EnrollmentOutputIncomeDefinitionTypeEnum.Other)
                    {
                        enrlXml.IncomeDefinition = "OfferLetterInsurableIncomeDefinition";
                    }
                    else
                    {
                        enrlXml.IncomeDefinition = enrollmentOutput.OtherIncomeDefinitionText != null ? enrollmentOutput.OtherIncomeDefinitionText : "";
                    }

                    if (enrollmentOutput.EnrollmentOutputIncomeDefinitionType != null)
                    {
                        enrlXml.IncomeType = (EnrollmentOutputShowTypeEnum)enrollmentOutput.EnrollmentOutputIncomeDefinitionType;

                    }
                    if (enrollmentOutput.EnrollmentOutputIncomeDisplayType != null)
                    {
                        enrlXml.IncomeDisplayType = enrollmentOutput.EnrollmentOutputIncomeDisplayType.Description;
                    }
                    if (enrollmentOutput.EnrollmentOutputPremiumDisplayType != null)
                    {
                        enrlXml.PremiumDisplayType = enrollmentOutput.EnrollmentOutputPremiumDisplayType.Description;
                    }
                    enrlXml.DOBOnFile = enrollmentOutput.IsDOB;
                    enrlXml.SSNOnFile = enrollmentOutput.IsSSN;
                    enrlXml.CompensationOnFile = enrollmentOutput.IsCompensation;
                    enrlXml.PrepaidEnvelope = enrollmentOutput.IsPrepaidEnvelope;

                }

                if (caseBrokers != null && ProducercontactAddres != null)
                {
                    enrlXml.questionsProducerInfo = GetProducerInfo(caseBrokers, ProducercontactAddres);
                }

                if (enrollmentOutput != null)
                {
                    enrlXml.Letterhead = enrollmentOutput.IsCompanyLetterhead == true ? "Yes" : "No";
                    enrlXml.enrollmentMethodFaxText = enrollmentOutput.ApplicationReturnInstructions != null ? enrollmentOutput.ApplicationReturnInstructions : "";
                    enrlXml.onlineURL = enrollment.EnrollmentWebsite != null ? enrollment.EnrollmentWebsite : "";
                    enrlXml.omitPageNumbers = enrollmentOutput.IsOmitPageNumbers;
                    enrlXml.responseRequired = enrollmentOutput.ResponseRequiredText != null ? enrollmentOutput.ResponseRequiredText : "";

                    if (enrollmentOutput.IsIncludeGLTDDefinition != true)
                    {
                        enrlXml.omitGLTD = true;
                    }

                    if (enrollmentOutput.IsIncludeGLTDTaxabilityLanguage != true)
                    {
                        enrlXml.omitGLTDTaxibilityLanguage = true;
                    }

                }
                var csno = cmsCase.CaseNumber != null ? cmsCase.CaseNumber : "";

                enrlXml.reqNumber = csno + "-" + GetNextValue(sequencecount);
           
            }

            //Clear and Null any Unused sections
            enrlXml.groups = null;
            enrlXml.producersAndAgents = null;
            enrlXml.company = null;
            enrlXml.eDeliveryIndicator = null;
            enrlXml.participationPercentage = null;
            enrlXml.userID = null;
            enrlXml.showCompanyNameOrLogo = null;
            enrlXml.CoverLetterIncluded = null;
            enrlXml.PrepaidEnvelope = null;
            enrlXml.Salutation = null;
            enrlXml.IncludeReplacementPercentage = null;
            enrlXml.comeDefinition = null;
            enrlXml.IncomeType = null;
            enrlXml.CompensationOnFile = null;
            enrlXml.DOBOnFile = null;
            enrlXml.SSNOnFile = null;
            enrlXml.IncomeDefinition = null;
            enrlXml.Letterhead = null;
            enrlXml.questionsProducerInfo = null;
            enrlXml.enrollmentMethodFaxText = null;
            enrlXml.onlineURL = null;
            enrlXml.omitPageNumbers = null;
            enrlXml.omitGLTD = null;
            enrlXml.omitGLTDTaxibilityLanguage = null;

            enrlXml = GenerateParticipantCounter(enrlXml);
            var serializedXml =  SerializeObject(enrlXml);
            var updatedBenefitPremiumXml = RemoveAMBRRiderTagsFromXML(serializedXml);
           
            Log.TraceFormat("-CreateBPXml CaseId : {0} B&P Name: {1} Time: {2}s", request.CaseId, request.BenefitPremiumName, (DateTime.Now - startTime).TotalSeconds);
            return updatedBenefitPremiumXml;
        }

        private EnrollmentKitXml GenerateParticipantCounter(EnrollmentKitXml xml)
        {
            EnrollmentKitXml finalXml = xml;
            int participantCounter = 0;        

            var objBPRequest = xml.BPRequest;
            foreach (var obj in objBPRequest)
            {
                Dictionary<string, int> participantsDict = new Dictionary<string, int>();
                //participantCounter = 0;
                if (obj.ParticipantOffers != null)
                {
                    var objParticipansOptions1 = obj.ParticipantOffers.Where(i => i.cmsStandardOfferCode.Contains("\\Non Tobacco\\IDI Option 1"));
                    foreach (var objOffer in objParticipansOptions1)
                    {
                        var objParticipantsInOffers = objOffer.ParticipantsInOffer;
                        foreach (var objParticipantsInOffer in objParticipantsInOffers)
                        {
                            participantCounter++;
                            objParticipantsInOffer.participantCount = participantCounter;
                            if (!participantsDict.ContainsKey(objParticipantsInOffer.EmployeeId))
                            {
                                participantsDict.Add(objParticipantsInOffer.EmployeeId, participantCounter);
                            }
                        }
                    }

                    var objParticipansOptions2 = obj.ParticipantOffers.Where(i => i.cmsStandardOfferCode.Contains("\\Non Tobacco\\IDI Option 2"));
                    foreach (var objOffer in objParticipansOptions2)
                    {
                        var objParticipantsInOffers = objOffer.ParticipantsInOffer;
                        foreach (var objParticipantsInOffer in objParticipantsInOffers)
                        {
                            int oldParticipantCounter = participantCounter;
                            if (participantsDict.TryGetValue(objParticipantsInOffer.EmployeeId, out oldParticipantCounter))
                            {
                                objParticipantsInOffer.participantCount = oldParticipantCounter;
                            }
                            else
                            {
                                objParticipantsInOffer.participantCount = participantCounter++;
                            }
                        }
                    }

                    var objParticipansOptions3 = obj.ParticipantOffers.Where(i => i.cmsStandardOfferCode.Contains("\\Non Tobacco\\IDI Option 3"));
                    foreach (var objOffer in objParticipansOptions3)
                    {
                        var objParticipantsInOffers = objOffer.ParticipantsInOffer;
                        foreach (var objParticipantsInOffer in objParticipantsInOffers)
                        {
                            int oldParticipantCounter = participantCounter;
                            if (participantsDict.TryGetValue(objParticipantsInOffer.EmployeeId, out oldParticipantCounter))
                            {
                                objParticipantsInOffer.participantCount = oldParticipantCounter;
                            }
                            else
                            {
                                objParticipantsInOffer.participantCount = participantCounter++;
                            }
                        }
                    }
                }
            }
            return finalXml;
            
        }

        private string IscompanyNameOrLogo(EnrollmentOutput enrollmentOutputs)
        {
            var CompanyNameorLogo = string.Empty;

            if ((enrollmentOutputs.IsCompanyLogo == true) && (enrollmentOutputs.IsCompanyLetterhead == true))
            {
                CompanyNameorLogo = "BOTH";
            }
            else if ((enrollmentOutputs.IsCompanyLogo == true) && (enrollmentOutputs.IsCompanyLetterhead == false))
            {
                CompanyNameorLogo = "LOGO";
            }
            else if ((enrollmentOutputs.IsCompanyLogo == false) && (enrollmentOutputs.IsCompanyLetterhead == true))
            {
                CompanyNameorLogo = "LETTER";
            }
            else
            {
                CompanyNameorLogo = "None";
            }

            return CompanyNameorLogo;

        }

        private string GetProducerInfo(IEnumerable<CaseBroker> casebroker, IQueryable<ContactAddress> contaddress)
        {
            string compName = "", email = "", phoneno = "", brokerdetails;

            //var casebrokers = casebroker.Select();
            if (casebroker.Any())
            {
                compName = casebroker.FirstOrDefault().CompanyName != null ? casebroker.FirstOrDefault().CompanyName : "";
            }

            var producerContact = contaddress.FirstOrDefault(c => c.ContactRoleType == ContactRoleTypeEnum.Producer);


            if (producerContact != null)
            {
                email = producerContact.Email != null ? producerContact.Email : "";
                phoneno = producerContact.Phone != null ? producerContact.Phone : "";
            }
            brokerdetails = compName + "|" + email + "|" + phoneno;
            return brokerdetails;
        }

        private string GetNextValue(string s)
        {
            return String.Format("{0:D3}", Convert.ToInt32(s.Substring(00)) + 0);
            //return  Convert.ToInt32(s.Substring(0) + 1);
        }
    }
}