﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using Logger.Static;
using System.Linq;
using CMS.Model.Entities;
using CMS.Interfaces.Managers.WorkUnitManagers;
using Newtonsoft.Json;
using System.Xml.Linq;
using System.Threading.Tasks;
using Common.Utilities;
using CMS.Interfaces.Integrations.BrokerDataServices;
using System.Collections.Generic;
using CMS.Model.Enums;
using CMS.Interfaces.Managers.ProductLibraryManagers;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class BridgelineXmlGenerator : DocumentGenerator, IBridgelineXmlGenerator, IWorkUnitHandler
    {
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IBrokerDataClient _brokerDataClient;
        private readonly IProductLibraryManager _productLibraryManager;

        public BridgelineXmlGenerator(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager, IBrokerDataClient brokerDataClient,
            IProductLibraryManager productLibraryManager) : base(unitOfWorkFactory, productLibraryManager)
        {
            _workUnitManager = workUnitManager;
            _brokerDataClient = brokerDataClient;            
        }

        public void EnqueueRequest(CaseCommonXmlGenerationRequest request)
        {
            Log.TraceFormat("+EnqueueRequest");

            _workUnitManager.CreateWorkUnit(WorkUnitType.BridgelineXml, JsonConvert.SerializeObject(request));

            Log.TraceFormat("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.TraceFormat("+Run");

            var request = JsonConvert.DeserializeObject<CaseCommonXmlGenerationRequest>(workUnit.InputData);

            var commonXmlBuilder = new CaseCommonXmlBuilder(UnitOfWorkFactory);

            var mldiCase = new MLDICase();
            commonXmlBuilder.CreateCase(request, mldiCase,"BridgelineXml");

            var servicingAgents = GetProducersForAMBIncrease(request);

            if (servicingAgents.Any())
            {
                mldiCase.producersAndAgents.AddRange(servicingAgents);
            }
            UpdateStandardOfferCodeForAMBParticipants(mldiCase);

            var serializedXml = SerializeObject(mldiCase);

            var updatedXML = RemoveUserSelectedTagsForBridgeLine(serializedXml);

            var updatedAMBRRiderXML = RemoveAMBRRiderTagsFromXML(updatedXML);

            SaveXmlToDb(request, updatedAMBRRiderXML);

            Log.TraceFormat("-Run");
        }

        private void UpdateStandardOfferCodeForAMBParticipants(MLDICase mldiCase)
        {
            var qualifiedOffers = mldiCase.groups.SelectMany(c => c.eligibleParticipants).SelectMany(c => c.offers).ToList();
            if(qualifiedOffers.Any())
            {
                var ambQualifiedOffers = qualifiedOffers.Where(c => c.riders.Any(r => r.riderIdentifier == "AMBR")).ToList();
                if(ambQualifiedOffers.Any())
                {
                    foreach(var offer in ambQualifiedOffers)
                    {
                        var offerCode = offer.cmsStandardOfferCode;
                        var index = offerCode.IndexOf("IDI");
                        if(index != -1)
                        {
                            var code = offerCode.Substring(0, index);
                            offer.cmsStandardOfferCode = string.Concat(code, "Max IDI");
                        }
                    }
                }
            }
        }

        private IList<MLDIProducerAgent> GetProducersForAMBIncrease(CaseCommonXmlGenerationRequest request)
        {
            var servicingAgents = new List<MLDIProducerAgent>();
            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var contactAddress = unitOfWork.Repository<ContactAddress>().Linq().Where(c => c.Case.Id == request.CaseId);

                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);

                var companyName = cmsCase != null ? cmsCase.CompanyName : string.Empty;

                var servicingProducers = new List<ServicingAgentDto>();

                var splittedParticipantsIds = request.ParticipantIds.ChunkBy(1000);
                Parallel.ForEach(splittedParticipantsIds, obj =>
                {

                    var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq()
                                                                      .Where(c => (c.Enrollment.Id == request.EnrollmentId) && obj.Contains(c.Id)).ToList();

                    var participants = enrollmentParticipants.Select(c => c.Participant);

                    var participantExistingPolicies = participants.Where(p => p.ParticipantExistingPolicies.Count > 0 && p.IsAMBIncreaseIndicator == true).Select(p => p.ParticipantExistingPolicies.FirstOrDefault());
                    if (participantExistingPolicies.Any())
                    {
                        var policyNumbers = participantExistingPolicies.SelectMany(pe => pe.ParticipantExistingPolicyDetails).Where(pd => pd.CLOASPolicyStatus == "Inforce" && pd.Product == "Provider Choice").Select(pd => pd.PolicyNumber).ToList();

                        servicingProducers.AddRange(_brokerDataClient.GetServicingProducers(policyNumbers));

                    }

                });

                if (servicingProducers.Any())
                {
                    servicingAgents = GetServicingProducers(servicingProducers, contactAddress, companyName);
                }
            }
            return servicingAgents;
        }

        private List<MLDIProducerAgent> GetServicingProducers(IList<ServicingAgentDto> servicingProducers, IQueryable<ContactAddress> contactAddress, string companyName)
        {
            List<MLDIProducerAgent> listMldiProducerAgent = new List<MLDIProducerAgent>();
            foreach (var producer in servicingProducers)
            {
                MLDIProducerAgent agent = new MLDIProducerAgent();
                agent.type = ProducerAgentTypeRestriction.Producer;
                agent.cmsCode = producer.ProducerWritingCode != null ? producer.ProducerWritingCode : "";
                agent.agencyCode = producer.AgencyCode;
                agent.agencyName = companyName;

                agent.personalInformation.addresses = new List<MLDIAddress>();
                agent.personalInformation = new MLDIPerson();
                agent.personalInformation.type = PersonTypeRestriction.ProducerAgent;
                agent.personalInformation.title = "";
                agent.personalInformation.prefix = "";
                string s = producer.ProducerName != null ? producer.ProducerName : "";
                string[] values = s.Split(',');
                int index = 0;
                for (index = 0; index < values.Length; index++)
                {
                    values[index] = values[index].Trim();

                }
                if (index >= 2)
                {
                    agent.personalInformation.firstName = values[1].Length > 0 ? values[0] : "";
                    agent.personalInformation.lastName = values[0].Length > 0 ? values[1] : "";
                }
                else
                {
                    agent.personalInformation.firstName = producer.ProducerName != null ? producer.ProducerName : "";
                    agent.personalInformation.lastName = string.Empty;
                }

                IQueryable<ContactAddress> producerContact = null;

                if (contactAddress != null)
                {
                    if (!string.IsNullOrEmpty(agent.personalInformation.firstName) && !string.IsNullOrEmpty(agent.personalInformation.lastName))
                    {
                        producerContact = contactAddress.Where(c => c.ContactRoleType == ContactRoleTypeEnum.Producer &&
                                                                    c.ContactName.Contains(
                                                                        agent.personalInformation.firstName) &&
                                                                    c.ContactName.Contains(
                                                                        agent.personalInformation.lastName));
                    }
                    else
                    {
                        producerContact = contactAddress.Where(c => c.ContactRoleType == ContactRoleTypeEnum.Producer &&
                                                                    c.ContactName.Contains(agent.personalInformation.firstName));
                    }
                }

                if (producerContact.Any())
                {
                    agent.personalInformation.email = producerContact.FirstOrDefault().Email != null ? producerContact.FirstOrDefault().Email : "undetermined@undetermined.com";
                }

                foreach (var contactAddres in producerContact)
                {
                    if (contactAddres != null)
                    {
                        MLDIAddress address = new MLDIAddress();

                        address.type = AddressTypeRestriction.Work;
                        address.locationName = "Work";
                        address.street1 = contactAddres.AddressLine1 != null ? contactAddres.AddressLine1 : "";
                        address.street2 = contactAddres.AddressLine2 != null ? contactAddres.AddressLine2 : "";
                        address.city = contactAddres.City != null ? contactAddres.City : "";
                        address.state = contactAddres.StateType != null ? contactAddres.StateType.Value.ToString() : "";
                        address.postalCode = contactAddres.ZipCode != null ? contactAddres.ZipCode : "";
                        address.country = "United States of America";
                        address.phoneNumber = contactAddres.Phone != null ? contactAddres.Phone : "";

                        agent.personalInformation.addresses.Add(address);
                    }
                }

                listMldiProducerAgent.Add(agent);
            }
            return listMldiProducerAgent;
        }

        private string RemoveUserSelectedTagsForBridgeLine(string serializedXml)
        {
            string updatedXML = serializedXml;

            if (serializedXml != null)
            {
                var xmlDocument = XDocument.Parse(serializedXml);

                var userSelectedReplacementNode = xmlDocument.Descendants().Where(o => o.Name.LocalName == "userSelectedReplacement");
                userSelectedReplacementNode.Remove();

                var userSelectedAmountOfReplacementNode = xmlDocument.Descendants().Where(o => o.Name.LocalName == "userSelectedAmountOfReplacement");
                userSelectedAmountOfReplacementNode.Remove();

                var optionClassTypeNode = xmlDocument.Descendants().Where(o => o.Name.LocalName == "OptionClassType");
                optionClassTypeNode.Remove();

                serializedXml = xmlDocument.ToString();
                updatedXML = serializedXml;
            }

            return updatedXML;
        }

        private void SaveXmlToDb(CaseCommonXmlGenerationRequest request, string serializedXml)
        {
            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var bridgeLineXml = unitOfWork.Repository<BridgelineXml>().Linq().FirstOrDefault(x => x.Id == request.RequestId);
                if (bridgeLineXml != null)
                {
                    bridgeLineXml.FileContent = serializedXml;
                    unitOfWork.Repository<BridgelineXml>().Save(bridgeLineXml);
                    unitOfWork.Commit();
                }
            }
        }
    }
}