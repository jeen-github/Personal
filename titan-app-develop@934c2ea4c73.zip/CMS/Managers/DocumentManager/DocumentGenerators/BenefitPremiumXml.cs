﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Xml.Serialization;
using System.Collections;
using System.Xml.Schema;
using System.ComponentModel;
using System.Xml;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{

    [System.Xml.Serialization.XmlRoot("ExtreamDocumentXML", IsNullable = false)]
    public class BenefitPremiumXml : EnrollmentKitXml
    {
        
        public BenefitPremiumXml()
        {
            ExstreamRequestType = "BenefitPremium";
        }

    }
}



