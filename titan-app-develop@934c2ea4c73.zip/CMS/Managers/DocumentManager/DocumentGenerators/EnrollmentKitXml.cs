﻿using System;
using System.Collections.Generic;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Model.Enums;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    using System;
    using System.Diagnostics;
    using System.Xml.Serialization;
    using System.Collections;
    using System.Xml.Schema;
    using System.ComponentModel;
    using System.Xml;
    using System.Collections.Generic;
    using CMS.Model.Enums;
    using CMS.Model.Entities;

    [System.Xml.Serialization.XmlRoot("ExtreamDocumentXML", IsNullable = false)]
    public class EnrollmentKitXml : MLDICase
    {
        [System.Xml.Serialization.XmlElement("exstreamRequestType", IsNullable = false)]
        public string CompanyFriendlyName { get; set; }
        public string ExstreamRequestType { get; set; }
        public string cmsProcessDate { get; set; }
        public string cmsProcessTime { get; set; }
        public string responseRequired { get; set; }

        public bool? eDeliveryIndicator { get; set; }
        public string enrollmentCommunicationDate { get; set; }

        public string enrollmentCommunicationSender { get; set; }
        public string participationPercentage { get; set; }

        public string userID { get; set; }
        public string showCompanyNameOrLogo { get; set; }
        public string showCompanyOnCoverPage { get; set; }
        public string companyHRContact { get; set; }
        public string companyHRContactEmail { get; set; }
        public string companyHRContactPhone { get; set; }
        public string companyContact { get; set; }
        public string companyContactEmail { get; set; }
        public string companyContactPhone { get; set; }

        public string companyContact2 { get; set; }
        public string companyContact2Email { get; set; }
        public string companyContact2Phone { get; set; }
        public string coverLetterDate { get; set; }
        public bool? CoverLetterIncluded { get; set; }
        public string Salutation { get; set; }
        public bool? IncludeReplacementPercentage { get; set; }
        public int? comeDefinition { get; set; }
        public EnrollmentOutputShowTypeEnum? IncomeType { get; set; }
        public string IncomeDisplayType { get; set; }
        public string ReturnAddressName { get; set; }
        public string PremiumDisplayType { get; set; }
        public bool? DOBOnFile { get; set; }
        public bool? SSNOnFile { get; set; }
        public bool? CompensationOnFile { get; set; }
        public bool? PrepaidEnvelope { get; set; }
        public string IncomeDefinition { get; set; }

        [System.Xml.Serialization.XmlElement("letterHead", IsNullable = false)]
        public string Letterhead { get; set; }
        public string questionsProducerInfo { get; set; }
        public string enrollmentMethodFaxText { get; set; }
        public string enrollmentMethodLetter { get; set; }
        public string onlineURL { get; set; }
        public bool? omitPageNumbers { get; set; }
        public bool? omitGLTD { get; set; }
        public bool? omitGLTDTaxibilityLanguage { get; set; }
        public string disCode { get; set; }
        public string reqNumber { get; set; }
        public string versionNumberGEARapprovalNumber { get; set; }
        public string rateAdjustmentFlag { get; set; }
        public string presentedBy { get; set; }
        public string printFile { get; set; }

        [XmlArray("enrollmentMeetings")]
        [XmlArrayItem(typeof(ExtreamGenerationEnrollmentMeeting), ElementName = "enrollmentMeeting")]
        public List<ExtreamGenerationEnrollmentMeeting> EnrollmentMeetings { get; set; }
        [System.Xml.Serialization.XmlElement("company", IsNullable = false)]
        public ExtreamGenerationCompanyXml Company { get; set; }

        [XmlArray("producersAndAgents")]
        [XmlArrayItem(typeof(ExtreamGenerationProducerAgentXml), ElementName = "producerAgent")]
        public List<ExtreamGenerationProducerAgentXml> ProducersAndAgents { get; set; }


        [XmlArray("groups")]
        [XmlArrayItem(typeof(ExtreamGenerationGroup), ElementName = "group")]
        public List<ExtreamGenerationGroup> Groups { get; set; }

        //[XmlArray("BPRGroups")]
        //[XmlArrayItem(typeof(ExtreamGenerationBPOptionXml), ElementName = "BPRequest")]
        [System.Xml.Serialization.XmlElement("BPRequest")]
        public List<ExtreamGenerationBPOptionXml> BPRequest { get; set; }

        [XmlArray("IneligibleParticipants")]
        [XmlArrayItem(typeof(ExtreamGenerationInEligibleParticipantXml), ElementName = "IneligibleParticipant")]
        public List<ExtreamGenerationInEligibleParticipantXml> IneligibleParticipant { get; set; }


        public EnrollmentKitXml()
        {
            ExstreamRequestType = "EnrollmentKit";
        }

        public class ExtreamGenerationEnrollmentMeeting
        {
            public string code { get; set; }
            public DateTime meetingDateTime { get; set; }
            public string location { get; set; }
            public string phoneOrOther { get; set; }
        }

        public class ExtreamGenerationCompanyXml : MLDICompany
        {
            public string companyLogoBLOB { get; set; }

            public ExtreamGenerationCompanyXml()
            {
                companyLogoBLOB = string.Empty;
            }

            public ExtreamGenerationCompanyXml(MLDICompany inCompany)
            {
                mainAddress = inCompany.mainAddress;
                name = inCompany.name;
                licenseContractType = inCompany.licenseContractType;
                sicCode = inCompany.sicCode;
                multiStateEnabledStates = inCompany.multiStateEnabledStates;
                companyLogoBLOB = string.Empty;
            }
        }

        public class ExtreamGenerationGroup : MLDIGroup
        {
            [System.Xml.Serialization.XmlElement("insurableIncomeColumnNames", IsNullable = false)]
            public InsurableIncomeColumnNames InsurableIncomeColumnNames { get; set; }

            [System.Xml.Serialization.XmlElement("gltdAndIDIBenefitSummaryColumnNames", IsNullable = false)]
            public ExstreamGenerationGLTDandIDIBenefitSummaryColumnNames GLTDandIDIBenefitSummaryColumnNames { get; set; }

            [System.Xml.Serialization.XmlElement("providerChoicePremiumsColumnNames", IsNullable = false)]
            public ExstreamGenerationProviderChoicePremiumColumnNames ProviderChoicePremiumsColumnNames { get; set; }

            [XmlArray("eligibleParticipants")]
            [XmlArrayItem(typeof(ExtreamGenerationParticipantXml), ElementName = "participant")]

            public List<ExtreamGenerationParticipantXml> EligibleParticipants { get; set; }
        }

        public class ExtreamGenerationParticipantXml : MLDIParticipant
        {
            [System.Xml.Serialization.XmlElement("incomeDetails", IsNullable = false)]
            public ExtreamGenerationParticipantIncomeXml IncomeDetails { get; set; }

            [System.Xml.Serialization.XmlElement("previousDeclineNumber")]
            public string PreviousDeclineNumber { get; set; }

            [System.Xml.Serialization.XmlElement("basePlanPreviousSolicitations")]
            public bool? BasePlanPreviousSolicitations { get; set; }

            [System.Xml.Serialization.XmlElement("employeeId", IsNullable = false)]
            public string EmployeeId { get; set; }

            [System.Xml.Serialization.XmlElement("existingTobaccoStatus", IsNullable = false)]
            public string ExistingTobaccoStatus { get; set; }

            [System.Xml.Serialization.XmlElement("totalGLTDPlusIDICalculatedAmount", IsNullable = false)]
            public string TotalGLTDPlusIDICalculatedAmount { get; set; }

            [System.Xml.Serialization.XmlElement("totalGLTDPlusIDICalculatedPercentage", IsNullable = false)]
            public string TotalGLTDPlusIDICalculatedPercentage { get; set; }

            [System.Xml.Serialization.XmlElement("voluntaryGSIBuyUpCalculatedAmount", IsNullable = false)]
            public string VoluntaryGSIBuyUpCalculatedAmount { get; set; }

            [System.Xml.Serialization.XmlElement("overrideIPLimit", IsNullable = false)]
            public string OverrideIPLimit { get; set; }

            [System.Xml.Serialization.XmlElement("age", IsNullable = false)]
            public string Age { get; set; }

            [System.Xml.Serialization.XmlElement("ltdPercentage", IsNullable = false)]
            public string LtdPercentage { get; set; }

            [System.Xml.Serialization.XmlElement("ltdMaximum", IsNullable = false)]
            public string LtdMaximum { get; set; }

            [System.Xml.Serialization.XmlElement("employeeType", IsNullable = false)]
            public string EmployeeType { get; set; }

            [System.Xml.Serialization.XmlElement("GltdCode", IsNullable = false)]
            public string GltdCode { get; set; }

            [System.Xml.Serialization.XmlElement("GltdTaxable", IsNullable = false)]
            public string GltdTaxable { get; set; }

            [System.Xml.Serialization.XmlElement("GltdErPaid", IsNullable = false)]
            public string GltdErPaid { get; set; }

            [System.Xml.Serialization.XmlElement("anyCostSharing", IsNullable = false)]
            public string AnyCostSharing { get; set; }

            [System.Xml.Serialization.XmlElement("contractState", IsNullable = false)]
            public string ContractState { get; set; }
            [System.Xml.Serialization.XmlElement("phoneNumber", IsNullable = false)]
            public string PhoneNumber { get; set; }

            [System.Xml.Serialization.XmlElement("emailAddress", IsNullable = false)]
            public string EmailAddress { get; set; }

            [System.Xml.Serialization.XmlElement("premiumPaymentPeriod", IsNullable = false)]
            public string PremiumPaymentPeriod { get; set; }
            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
            public System.Nullable<uint> BenefitPeriodYears { get; set; }
            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
            public System.Nullable<uint> BenefitPeriodAge { get; set; }
            [System.Xml.Serialization.XmlElement("payrollDeductionPeriod", IsNullable = false)]
            public string PayrollDeductionPeriod { get; set; }
            [System.Xml.Serialization.XmlElement("baseMonthlyBenefit", IsNullable = false)]
            public string BaseMonthlyBenefit { get; set; }

            [XmlArray("currentLTDs")]
            [XmlArrayItem(typeof(ExtreamGenerationAdditionalLtdXml), ElementName = "additionalLTDs")]
            public List<ExtreamGenerationAdditionalLtdXml> CurrentLTDs { get; set; }

            [XmlArray("offers")]
            [XmlArrayItem(typeof(ExtreamGenerationQualifiedOfferXml), ElementName = "offer")]
            public List<ExtreamGenerationQualifiedOfferXml> Offers { get; set; }

            [XmlArray("forms")]
            [XmlArrayItem(typeof(ExtreamGenerationForm), ElementName = "prefilledForms")]
            public List<ExtreamGenerationForm> Forms { get; set; }

            public string EndofParticipant { get; set; }


            public ExtreamGenerationParticipantXml()
            {
            }

        }

        public class ExtreamGenerationAdditionalLtdXml : MLDIAdditionalLtd
        {
            [System.Xml.Serialization.XmlElement("isReplacement", IsNullable = false)]
            public bool IsReplacement { get; set; }

            [System.Xml.Serialization.XmlElement("dateToBeReplaced", IsNullable = false)]
            public string DateToBeReplaced { get; set; }

            public ExtreamGenerationAdditionalLtdXml()
            {
            }

        }

        public class ExtreamGenerationProducerAgentXml : MLDIProducerAgent
        {
            [XmlArray("addressSlipProducerAgent")]
            [XmlArrayItem(typeof(ExtreamGenerationAddressSlip), ElementName = "addressSlipProducerAgent")]
            public List<ExtreamGenerationAddressSlip> AddressSlipProducerAgent;
            public ExtreamGenerationProducerAgentXml()
            {
                AddressSlipProducerAgent = new List<ExtreamGenerationAddressSlip>();
            }

            public ExtreamGenerationProducerAgentXml(MLDIProducerAgent inAgent)
            {
                //foreach (var a in inAgent)
                //{
                personalInformation = inAgent.personalInformation;
                agencyCode = inAgent.agencyCode;
                cmsCode = inAgent.cmsCode;
                leadProducer = inAgent.leadProducer;
                stateLicenses = inAgent.stateLicenses;
                type = inAgent.type;

                //}

                AddressSlipProducerAgent = new List<ExtreamGenerationAddressSlip>();
            }
        }

        public class ExtreamGenerationQualifiedOfferXml : MLDIQualifiedOffer
        {

            [System.Xml.Serialization.XmlElement("costSharing", IsNullable = false)]
            public bool CostSharing { get; set; }

            [System.Xml.Serialization.XmlElement("costSharePercentage", IsNullable = false)]
            public string CostSharePercentage { get; set; }

            [System.Xml.Serialization.XmlElement("costSharePremiumAmount", IsNullable = false)]
            public string CostSharePremiumAmount { get; set; }           

            [XmlElement("yourPremiumPayCheck")]
            public System.Nullable<decimal> yourPremiumPayCheck { get; set; }

            [XmlElement("yourPremiumPerMonth")]
            public System.Nullable<decimal> YourPremiumPerMonth { get; set; }

            public string maxGSI { get; set; }

            [System.Xml.Serialization.XmlElement("totalIncomeReplacementPercentage", IsNullable = false)]
            public string TotalIncomeReplacementPercentage { get; set; }

            [System.Xml.Serialization.XmlElement("alternateText", IsNullable = false)]
            public string AlternateText { get; set; }

            [System.Xml.Serialization.XmlElement("isBenefitTaxable", IsNullable = false)]
            public bool IsBenefitTaxable { get; set; }

            [System.Xml.Serialization.XmlElement("isParticipationRequired", IsNullable = false)]
            public bool IsParticipationRequired { get; set; }

            [System.Xml.Serialization.XmlElement("insurableIncomes", IsNullable = false)]
            public TotalInsurableIncomes InsurableIncomes { get; set; }

            [System.Xml.Serialization.XmlElement("gLTDandIDIBenefitSummary", IsNullable = false)]
            public ExtreamGenerationGLTDandIDIBenefitBenefitSummaries GLTDandIDIBenefitSummary { get; set; }

            [System.Xml.Serialization.XmlElement("providerChoicePremiumSummary", IsNullable = false)]
            public ExstreamGenerationProviderChoicePremiumSummaries ProviderChoicePremiumSummary { get; set; }

            [System.Xml.Serialization.XmlElement("taxType", IsNullable = false)]
            public string TaxType { get; set; }
            public ExtreamGenerationQualifiedOfferXml()
            {

            }

        }

        public class ExtreamGenerationGLTDandIDIBenefitBenefitSummaries
        {

            [System.Xml.Serialization.XmlElement("annualRetirementContributionsAmt", IsNullable = false)]
            public string AnnualRetirementContributionsAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingRppProgramCoverageAmt", IsNullable = false)]
            public string ExistingRppProgramCoverageAmt { get; set; }

            [System.Xml.Serialization.XmlElement("rppBaseBenefitAmt", IsNullable = false)]
            public string RppBaseBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedRppAmbBenefitAmt", IsNullable = false)]
            public string ProposedRppAmbBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("rppReplacePercentAmt", IsNullable = false)]
            public string RppReplacePercentAmt { get; set; }

            [System.Xml.Serialization.XmlElement("gLTDBenefitAmt", IsNullable = false)]
            public string GLTDBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("gLTDReplacePercentAmt", IsNullable = false)]
            public string GLTDReplacePercentAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingGSIBaseBenefitAmt", IsNullable = false)]
            public string ExistingGSIBaseBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingERPaidGSIBaseBenefitAmt", IsNullable = false)]
            public string ExistingERPaidGSIBaseBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingIDICoverageAmt", IsNullable = false)]
            public string ExistingIDICoverageAmt { get; set; }

            [System.Xml.Serialization.XmlElement("eRPaidGSIBaseBenefitAmt", IsNullable = false)]
            public string ERPaidGSIBaseBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("volGSIBaseBenefitAmt", IsNullable = false)]
            public string VolGSIBaseBenefitAmt { get; set; }
            [System.Xml.Serialization.XmlElement("gSIBaseBenefitAmt", IsNullable = false)]
            public string GSIBaseBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedAMBRiderAmt", IsNullable = false)]
            public string ProposedAMBRiderAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedERPaidAMBRiderAmt", IsNullable = false)]
            public string ProposedERPaidAMBRiderAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedVGSIBuyUpAMBRiderAmt", IsNullable = false)]
            public string ProposedVGSIBuyUpAMBRiderAmt { get; set; }

            [System.Xml.Serialization.XmlElement("iDIBaseReplacePercentAmt", IsNullable = false)]
            public string IDIBaseReplacePercentAmt { get; set; }

            [System.Xml.Serialization.XmlElement("totalIDIAmt", IsNullable = false)]
            public string TotalIDIAmt { get; set; }

            [System.Xml.Serialization.XmlElement("totalIDIPercentAmt", IsNullable = false)]
            public string TotalIDIPercentAmt { get; set; }

            [System.Xml.Serialization.XmlElement("totalGLTDPlusIDIAmt", IsNullable = false)]
            public string TotalGLTDPlusIDIAmt { get; set; }

            [System.Xml.Serialization.XmlElement("totalGLTDPlusIDIPercentAmt", IsNullable = false)]
            public string TotalGLTDPlusIDIPercentAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingBasicCATAmt", IsNullable = false)]
            public string ExistingBasicCATAmt { get; set; }

            [System.Xml.Serialization.XmlElement("basicCATAmt", IsNullable = false)]
            public string BasicCATAmt { get; set; }

            [System.Xml.Serialization.XmlElement("vgsibasicCATAmt", IsNullable = false)]
            public string VGSIBasicCATAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingEnhancedCATAmt", IsNullable = false)]
            public string ExistingEnhancedCATAmt { get; set; }

            [System.Xml.Serialization.XmlElement("enhancedCATAmt", IsNullable = false)]
            public string EnhancedCATAmt { get; set; }
            [System.Xml.Serialization.XmlElement("vgsienhancedCATAmt", IsNullable = false)]
            public string VGSIEnhancedCATAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingRPPMonthlyBenefitAmt", IsNullable = false)]
            public string ExistingRPPMonthlyBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("rPPBenefitAmt", IsNullable = false)]
            public string RPPBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("vgsirPPBenefitAmt", IsNullable = false)]
            public string VGSIRPPBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingSLRBenefitAmt", IsNullable = false)]
            public string ExistingSLRBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("sLRBenefitAmt", IsNullable = false)]
            public string SLRBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("vgsisLRBenefitAmt", IsNullable = false)]
            public string VGSISLRBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingSBTBenefitAmt", IsNullable = false)]
            public string ExistingSBTBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("sBTBenefitAmt", IsNullable = false)]
            public string SBTBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("vgsisBTBenefitAmt", IsNullable = false)]
            public string VGSISBTBenefitAmt { get; set; }

            //[System.Xml.Serialization.XmlElement("proposedVGSIBuyUpAMBRiderAmt", IsNullable = false)]
            //public string ProposedVGSIBuyUpAMBRiderAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingVGSIBuyUpProgramCoverageAmt", IsNullable = false)]
            public string ExistingVGSIBuyUpProgramCoverageAmt { get; set; }


        }

        public class ExstreamGenerationGLTDandIDIBenefitSummaryColumnNames
        {

            [System.Xml.Serialization.XmlElement("annualRetirementContributions", IsNullable = false)]
            public string AnnualRetirementContributions { get; set; }

            [System.Xml.Serialization.XmlElement("existingRppProgramCoverage", IsNullable = false)]
            public string ExistingRppProgramCoverage { get; set; }

            [System.Xml.Serialization.XmlElement("rppBaseBenefit", IsNullable = false)]
            public string RppBaseBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("proposedRppAmbBenefit", IsNullable = false)]
            public string ProposedRppAmbBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("rppReplacePercent", IsNullable = false)]
            public string RppReplacePercent { get; set; }

            [System.Xml.Serialization.XmlElement("gltdBenefit", IsNullable = false)]
            public string GLTDBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("gltdReplacePercent", IsNullable = false)]
            public string GLTDReplacePercent { get; set; }

            [System.Xml.Serialization.XmlElement("existingGSIBaseBenefit", IsNullable = false)]
            public string ExistingGSIBaseBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("existingERPaidGSIBaseBenefit", IsNullable = false)]
            public string ExistingERPaidGSIBaseBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("existingIDICoverage", IsNullable = false)]
            public string ExistingIDICoverage { get; set; }

            [System.Xml.Serialization.XmlElement("erPaidGSIBaseBenefit", IsNullable = false)]
            public string ERPaidGSIBaseBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("volGSIBaseBenefit", IsNullable = false)]
            public string VolGSIBaseBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("gsiBaseBenefit", IsNullable = false)]
            public string GSIBaseBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("proposedAMBRider", IsNullable = false)]
            public string ProposedAMBRider { get; set; }

            [System.Xml.Serialization.XmlElement("proposedERPaidAMBRider", IsNullable = false)]
            public string ProposedERPaidAMBRider { get; set; }

            [System.Xml.Serialization.XmlElement("proposedVGSIBuyUpAMBRider", IsNullable = false)]
            public string ProposedVGSIBuyUpAMBRider { get; set; }

            [System.Xml.Serialization.XmlElement("idiBaseReplacePercent", IsNullable = false)]
            public string IDIBaseReplacePercent { get; set; }

            [System.Xml.Serialization.XmlElement("totalIDI", IsNullable = false)]
            public string TotalIDI { get; set; }

            [System.Xml.Serialization.XmlElement("totalIDIPercent", IsNullable = false)]
            public string TotalIDIPercent { get; set; }

            [System.Xml.Serialization.XmlElement("totalGLTDPlusIDI", IsNullable = false)]
            public string TotalGLTDPlusIDI { get; set; }

            [System.Xml.Serialization.XmlElement("totalGLTDPlusIDIPercent", IsNullable = false)]
            public string TotalGLTDPlusIDIPercent { get; set; }

            [System.Xml.Serialization.XmlElement("existingBasicCAT", IsNullable = false)]
            public string ExistingBasicCAT { get; set; }

            [System.Xml.Serialization.XmlElement("basicCAT", IsNullable = false)]
            public string BasicCAT { get; set; }

            [System.Xml.Serialization.XmlElement("vgsibasicCAT", IsNullable = false)]
            public string VGSIBasicCAT { get; set; }

            [System.Xml.Serialization.XmlElement("existingEnhancedCAT", IsNullable = false)]
            public string ExistingEnhancedCAT { get; set; }

            [System.Xml.Serialization.XmlElement("enhancedCAT", IsNullable = false)]
            public string EnhancedCAT { get; set; }

            
            [System.Xml.Serialization.XmlElement("vgsienhancedCAT", IsNullable = false)]
            public string VGSIEnhancedCAT { get; set; }

            [System.Xml.Serialization.XmlElement("existingRPPMonthlyBenefit", IsNullable = false)]
            public string ExistingRPPMonthlyBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("rppBenefit", IsNullable = false)]
            public string RPPBenefit { get; set; }
            
            [System.Xml.Serialization.XmlElement("vgsirppBenefit", IsNullable = false)]
            public string VGSIRPPBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("existingSLRBenefit", IsNullable = false)]
            public string ExistingSLRBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("slrBenefit", IsNullable = false)]
            public string SLRBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("vgsislrBenefit", IsNullable = false)]
            public string VGSISLRBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("existingSBTBenefit", IsNullable = false)]
            public string ExistingSBTBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("sbtBenefit", IsNullable = false)]
            public string SBTBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("vgsisbtBenefit", IsNullable = false)]
            public string VGSISBTBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("existingVGSIBuyUpProgramCoverage", IsNullable = false)]
            public string ExistingVGSIBuyUpProgramCoverage { get; set; }
            
        }
        public class ExstreamGenerationProviderChoicePremiumColumnNames
        {

            [System.Xml.Serialization.XmlElement("existingCoveragePremium", IsNullable = false)]
            public string ExistingCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoveragePremium", IsNullable = false)]
            public string ProposedCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("existingAnnualCoveragePremium", IsNullable = false)]
            public string ExistingAnnualCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedAnnualCoveragePremium", IsNullable = false)]
            public string ProposedAnnualCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoverageEmployeePremium", IsNullable = false)]
            public string ProposedCoverageEmployeePremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoverageEmployerPremium", IsNullable = false)]
            public string ProposedCoverageEmployerPremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoverageAnnualEmployeePremium", IsNullable = false)]
            public string ProposedCoverageAnnualEmployeePremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoverageAnnualEmployerPremium", IsNullable = false)]
            public string ProposedCoverageAnnualEmployerPremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedERPaidCoveragePremium", IsNullable = false)]
            public string ProposedERPaidCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedERPaidAnnualCoveragePremium", IsNullable = false)]
            public string ProposedERPaidAnnualCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedVGSIBuyUpCoveragePremium", IsNullable = false)]
            public string ProposedVGSIBuyUpCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("proposedVGSIBuyUpAnnualCoveragePremium", IsNullable = false)]
            public string ProposedVGSIBuyUpAnnualCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoveragePremiumSummary", IsNullable = false)]
            public string ExistingCoveragePremiumSummary { get; set; }

            [System.Xml.Serialization.XmlElement("existingVGSIBuyUpCoveragePremium", IsNullable = false)]
            public string ExistingVGSIBuyUpCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("existingVGSIBuyUpAnnualCoveragePremium", IsNullable = false)]
            public string ExistingVGSIBuyUpAnnualCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("existingERPaidCoveragePremium", IsNullable = false)]
            public string ExistingERPaidUpCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("existingERPaidUpAnnualCoveragePremium", IsNullable = false)]
            public string ExistingERPaidUpAnnualCoveragePremium { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoverageEmployeePremium", IsNullable = false)]
            public string ExistingCoverageEmployeePremium { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoverageEmployerPremium", IsNullable = false)]
            public string ExistingCoverageEmployerPremium { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoverageAnnualEmployeePremium", IsNullable = false)]
            public string ExistingCoverageAnnualEmployeePremium { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoverageAnnualEmployerPremium", IsNullable = false)]
            public string ExistingCoverageAnnualEmployerPremium { get; set; }

            [System.Xml.Serialization.XmlElement("GSIPlusAMBTotalBenefit", IsNullable = false)]
            public string GSIPlusAMBTotalBenefit { get; set; }

            [System.Xml.Serialization.XmlElement("TotalPlusAMBModalPremium", IsNullable = false)]
            public string TotalPlusAMBModalPremium { get; set; }
            [System.Xml.Serialization.XmlElement("TotalPlusAMBModalEmployeePremium", IsNullable = false)]
            public string TotalPlusAMBModalEmployeePremium { get; set; }
            [System.Xml.Serialization.XmlElement("TotalPlusAMBERPaidModalPremium", IsNullable = false)]
            public string TotalPlusAMBERPaidModalPremium { get; set; }
            [System.Xml.Serialization.XmlElement("TotalPlusAMBVGSIBuyUpModalPremium", IsNullable = false)]
            public string TotalPlusAMBVGSIBuyUpModalPremium { get; set; }
            [System.Xml.Serialization.XmlElement("TotalPlusAMBModalEmployerPremium", IsNullable = false)]
            public string TotalPlusAMBModalEmployerPremium { get; set; }
            [System.Xml.Serialization.XmlElement("TotalPlusAMBPremiumPerPaycheck", IsNullable = false)]
            public string TotalPlusAMBPremiumPerPaycheck { get; set; }
        }

        public class ExstreamGenerationProviderChoicePremiumSummaries
        {

            [System.Xml.Serialization.XmlElement("existingCoveragePremiumAmt", IsNullable = false)]
            public string ExistingCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoverageVGSIPremiumAmt", IsNullable = false)]
            public string ExistingCoverageVGSIPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoveragePremiumAmt", IsNullable = false)]
            public string ProposedCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingAnnualCoveragePremiumAmt", IsNullable = false)]
            public string ExistingAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedAnnualCoveragePremiumAmt", IsNullable = false)]
            public string ProposedAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoverageEmployeePremiumAmt", IsNullable = false)]
            public string ProposedCoverageEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoverageEmployerPremiumAmt", IsNullable = false)]
            public string ProposedCoverageEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoverageAnnualEmployeePremiumAmt", IsNullable = false)]
            public string ProposedCoverageAnnualEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedCoverageAnnualEmployerPremiumAmt", IsNullable = false)]
            public string ProposedCoverageAnnualEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedERPaidCoveragePremiumAmt", IsNullable = false)]
            public string ProposedERPaidCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedERPaidAnnualCoveragePremiumAmt", IsNullable = false)]
            public string ProposedERPaidAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedVGSIBuyUpCoveragePremiumAmt", IsNullable = false)]
            public string ProposedVGSIBuyUpCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("proposedVGSIBuyUpAnnualCoveragePremiumAmt", IsNullable = false)]
            public string ProposedVGSIBuyUpAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingVGSIBuyUpCoveragePremiumAmt", IsNullable = false)]
            public string ExistingVGSIBuyUpCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingVGSIBuyUpAnnualCoveragePremiumAmt", IsNullable = false)]
            public string ExistingVGSIBuyUpAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingERPaidCoveragePremiumAmt", IsNullable = false)]
            public string ExistingERPaidCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingERPaidUpAnnualCoveragePremiumAmt", IsNullable = false)]
            public string ExistingERPaidAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoverageEmployeePremiumAmt", IsNullable = false)]
            public string ExistingCoverageEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoverageEmployerPremiumAmt", IsNullable = false)]
            public string ExistingCoverageEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoverageAnnualEmployeePremiumAmt", IsNullable = false)]
            public string ExistingCoverageAnnualEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoverageAnnualEmployerPremiumAmt", IsNullable = false)]
            public string ExistingCoverageAnnualEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("existingCoveragePremiumSummaryAmt", IsNullable = false)]
            public string ExistingCoveragePremiumSummaryAmt { get; set; }

            [System.Xml.Serialization.XmlElement("GSIPlusAMBTotalBenefitAmt", IsNullable = false)]
            public string GSIPlusAMBTotalBenefitAmt { get; set; }           

            [System.Xml.Serialization.XmlElement("TotalPlusAMBModalPremiumAmt", IsNullable = false)]
            public string TotalPlusAMBModalPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalPlusAMBModalEmployeePremiumAmt", IsNullable = false)]
            public string TotalPlusAMBModalEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalPlusAMBERPaidModalPremiumAmt", IsNullable = false)]
            public string TotalPlusAMBERPaidModalPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalPlusAMBVGSIBuyUpModalPremiumAmt", IsNullable = false)]
            public string TotalPlusAMBVGSIBuyUpModalPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalPlusAMBModalEmployerPremiumAmt", IsNullable = false)]
            public string TotalPlusAMBModalEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalPlusAMBPremiumPerPaycheckAmt", IsNullable = false)]
            public string TotalPlusAMBPremiumPerPaycheckAmt { get; set; }

        }

        public class ExstreamGenerationTotalInsurableIncomes
        {
            public string InsurableIncomeTotalSalaryAmt { get; set; }
            public string InsurableIncomeTotalERPaidGSIBaseAmt { get; set; }
            public string InsurableIncomeTotalVGSIBuyUpAmt { get; set; }
            public string InsurableIncomeTotalOtherIncomeAmt { get; set; }
            public string InsurableIncomeGrandTotalAmt { get; set; }
        }

        public class ExstreamGenerationTotalGLTDandIDITotalBenefitSummaries
        {
            public string TotalGLTDBenefitAmt { get; set; }
            public string TotalGLTDReplacePercentAmt { get; set; }
            public string TotalExistingIDICoverageAmt { get; set; }
            public string TotalERPaidGSIBaseBenefitAmt { get; set; }
            public string TotalBuyUpGSIBaseBenefitAmt { get; set; }
            public string TotalGSIBaseBenefitAmt { get; set; }
            public string TotalIDIBaseReplacePercentAmt { get; set; }
            public string TotalGLTDPlusIDIAmt { get; set; }
            public string TotalGLTDPlusIDIPercentAmt { get; set; }
            public string TotalBasicCATAmt { get; set; }
            public string TotalVGSIBasicCATAmt { get; set; }
            public string TotalEnhancedCATAmt { get; set; }
            public string TotalVGSIEnhancedCATAmt { get; set; }
            public string TotalReplacementPercentAmt { get; set; }
            public string TotalRPPBenefitAmt { get; set; }
            public string TotalVGSIRPPBenefitAmt { get; set; }
            public string TotalRPPReplacePercent { get; set; }
            public string TotalSLRBenefitAmt { get; set; }
            public string TotalVGSISLRBenefitAmt { get; set; }
            public string TotalSBTBenefitAmt { get; set; }
            public string TotalVGSISBTBenefitAmt { get; set; }
            public string TotalAnnualRetirementContributionsAmt { get; set; }
            public string TotalExistingRppProgramCoverageAmt { get; set; }
            public string TotalRppBaseBenefitAmt { get; set; }
            public string TotalProposedRppAmbBenefitAmt { get; set; }
            public string TotalRppReplacePercentAmt { get; set; }
            public string TotalExistingGSIBaseBenefitAmt { get; set; }
            public string TotalExistingERPaidGSIBaseBenefitAmt { get; set; }
            public string TotalVolGSIBaseBenefitAmt { get; set; }
            public string TotalProposedERPaidAMBRiderAmt { get; set; }
            public string TotalProposedBuyUpAMBRiderAmt { get; set; }
            public string TotalProposedAMBRiderAmt { get; set; }
            public string TotalIDIAmt { get; set; }
            public string TotalIDIPercentAmt { get; set; }
            public string TotalExistingBasicCATAmt { get; set; }
            public string TotalExistingEnhancedCATAmt { get; set; }
            public string TotalExistingRPPMonthlyBenefitAmt { get; set; }
            public string TotalExistingSLRBenefitAmt { get; set; }
            public string TotalExistingSBTBenefitAmt { get; set; }
            public string TotalProposedVGSIBuyUpAMBRiderAmt { get; set; }
            public string TotalExistingVGSIBuyUpProgramCoverageAmt { get; set; }
        }

        public class ExstreamGenerationTotalProviderChoicePremiumSummaries
        {

            [System.Xml.Serialization.XmlElement("TotalexistingCoveragePremiumAmt", IsNullable = false)]
            public string TotalExistingCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingCoverageVGSIPremiumAmt", IsNullable = false)]
            public string TotalexistingCoverageVGSIPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedCoveragePremiumAmt", IsNullable = false)]
            public string TotalProposedCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingAnnualCoveragePremiumAmt", IsNullable = false)]
            public string TotalExistingAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedAnnualCoveragePremiumAmt", IsNullable = false)]
            public string TotalProposedAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedCoverageEmployeePremiumAmt", IsNullable = false)]
            public string TotalProposedCoverageEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedCoverageEmployerPremiumAmt", IsNullable = false)]
            public string TotalProposedCoverageEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedCoverageAnnualEmployeePremiumAmt", IsNullable = false)]
            public string TotalProposedCoverageAnnualEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedCoverageAnnualEmployerPremiumAmt", IsNullable = false)]
            public string TotalProposedCoverageAnnualEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedERPaidCoveragePremiumAmt", IsNullable = false)]
            public string TotalProposedERPaidCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedERPaidAnnualCoveragePremiumAmt", IsNullable = false)]
            public string TotalProposedERPaidAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedVGSIBuyUpCoveragePremiumAmt", IsNullable = false)]
            public string TotalProposedVGSIBuyUpCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproposedVGSIBuyUpAnnualCoveragePremiumAmt", IsNullable = false)]
            public string TotalProposedVGSIBuyUpAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingVGSIBuyUpCoveragePremiumAmt", IsNullable = false)]
            public string TotalExistingVGSIBuyUpCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingVGSIBuyUpAnnualCoveragePremiumAmt", IsNullable = false)]
            public string TotalExistingVGSIBuyUpAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingERPaidCoveragePremiumAmt", IsNullable = false)]
            public string TotalExistingERPaidCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingERPaidUpAnnualCoveragePremiumAmt", IsNullable = false)]
            public string TotalExistingERPaidAnnualCoveragePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingCoverageEmployeePremiumAmt", IsNullable = false)]
            public string TotalExistingCoverageEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingCoverageEmployerPremiumAmt", IsNullable = false)]
            public string TotalExistingCoverageEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingCoverageAnnualEmployeePremiumAmt", IsNullable = false)]
            public string TotalExistingCoverageAnnualEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalexistingCoverageAnnualEmployerPremiumAmt", IsNullable = false)]
            public string TotalExistingCoverageAnnualEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalExistingCoveragePremiumSummaryAmt", IsNullable = false)]
            public string TotalExistingCoveragePremiumSummaryAmt { get; set; }

            [System.Xml.Serialization.XmlElement("TotalGSIPlusAMBTotalBenefitAmt", IsNullable = false)]
            public string TotalGSIPlusAMBTotalBenefitAmt { get; set; }

            [System.Xml.Serialization.XmlElement("GrandTotalPlusAMBModalPremiumAmt", IsNullable = false)]
            public string GrandTotalPlusAMBModalPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("GrandTotalPlusAMBModalEmployeePremiumAmt", IsNullable = false)]
            public string GrandTotalPlusAMBModalEmployeePremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("GrandTotalPlusAMBERPaidModalPremiumAmt", IsNullable = false)]
            public string GrandTotalPlusAMBERPaidModalPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("GrandTotalPlusAMBVGSIBuyUpModalPremiumAmt", IsNullable = false)]
            public string GrandTotalPlusAMBVGSIBuyUpModalPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("GrandTotalPlusAMBModalEmployerPremiumAmt", IsNullable = false)]
            public string GrandTotalPlusAMBModalEmployerPremiumAmt { get; set; }

            [System.Xml.Serialization.XmlElement("GrandTotalPlusAMBPremiumPerPaycheckAmt", IsNullable = false)]
            public string GrandTotalPlusAMBPremiumPerPaycheckAmt { get; set; }
        }

        public class ExtreamGenerationParticipantIncomeXml : MLDIParticipantIncome
        {

            [System.Xml.Serialization.XmlElement("baseMonthlySalary", IsNullable = false)]
            public string BaseMonthlySalary { get; set; }

            [System.Xml.Serialization.XmlElement("totalAnnualIncome", IsNullable = false)]
            public string TotalAnnualIncome { get; set; }

            [System.Xml.Serialization.XmlElement("insIncCode", IsNullable = false)]
            public string InsIncCode { get; set; }

            [System.Xml.Serialization.XmlElement("taxBracket", IsNullable = false)]
            public string TaxBracket { get; set; }

            [System.Xml.Serialization.XmlElement("gltdTaxBracket", IsNullable = false)]
            public string GLTDTaxBracket { get; set; }

            [System.Xml.Serialization.XmlElement("incomeReplaced", IsNullable = false)]
            public string IncomeReplaced { get; set; }

            [System.Xml.Serialization.XmlElement("gLTDNetMonthlyIncome", IsNullable = false)]
            public string GLTDNetMonthlyIncome { get; set; }

            [System.Xml.Serialization.XmlElement("gltdReplacementPercentage", IsNullable = false)]
            public string GLTDReplacementPercentage { get; set; }

            [System.Xml.Serialization.XmlElement("feesIncome", IsNullable = false)]
            public string FeesIncome { get; set; }

            public ExtreamGenerationParticipantIncomeXml()
            {
            }

        }

        public class ExtreamGenerationForm
        {

            //[System.Xml.Serialization.XmlElement("prefilledForms", IsNullable = false)]
            //public string PrefilledForms { get; set; }

            [System.Xml.Serialization.XmlElement("formState", IsNullable = false)]
            public string FormState { get; set; }

            [System.Xml.Serialization.XmlElement("formName", IsNullable = false)]
            public string FormName { get; set; }

            [System.Xml.Serialization.XmlElement("printFile", IsNullable = false)]
            public string PrintFile { get; set; }

            public ExtreamGenerationForm()
            {
            }

        }

        public class ExtreamGenerationAddressSlip : MLDIProducerAgent
        {
            [System.Xml.Serialization.XmlElement("cmsCode", IsNullable = false)]
            public string CmsCode { get; set; }

            [System.Xml.Serialization.XmlElement("agencyCode", IsNullable = false)]
            public string AgencyCode { get; set; }

            [System.Xml.Serialization.XmlElement("agencyName", IsNullable = false)]
            public string AgencyName { get; set; }

            public ExtreamGenerationAddressSlip()
            {
                personalInformation = new MLDIPerson();
            }


        }

        //public class ExtreamGenerationBPGroupXml
        //{
        //    public List<ExtreamGenerationBPOptionXml> BPRequest { get; set; }

        //    [XmlArray("IneligibleParticipants")]
        //    [XmlArrayItem(typeof(ExtreamGenerationInEligibleParticipantXml), ElementName = "IneligibleParticipant")]
        //    public List<ExtreamGenerationInEligibleParticipantXml> IneligibleParticipant { get; set; }

        //}

        public class ExtreamGenerationBPOptionXml
        {
            [System.Xml.Serialization.XmlElement("insurableIncomeColumnNames", IsNullable = false)]
            public InsurableIncomeColumnNames InsurableIncomeColumnNames { get; set; }

            [System.Xml.Serialization.XmlElement("gltdAndIDIBenefitSummaryColumnNames", IsNullable = false)]
            public ExstreamGenerationGLTDandIDIBenefitSummaryColumnNames GLTDandIDIBenefitSummaryColumnNames { get; set; }

            [System.Xml.Serialization.XmlElement("providerChoicePremiumsColumnNames", IsNullable = false)]
            public ExstreamGenerationProviderChoicePremiumColumnNames ProviderChoicePremiumsColumnNames { get; set; }

            [XmlArray("Options")]
            [XmlArrayItem(typeof(ExtreamGenerationParticipantOfferXml), ElementName = "Option")]
            public List<ExtreamGenerationParticipantOfferXml> ParticipantOffers { get; set; }

            //[XmlArray("IneligibleParticipants")]
            //[XmlArrayItem(typeof(ExtreamGenerationInEligibleParticipantXml), ElementName = "IneligibleParticipant")]
            //public List<ExtreamGenerationInEligibleParticipantXml> IneligibleParticipant { get; set; }
        }

        public class ExtreamGenerationInEligibleParticipantXml
        {
            public string Employee { get; set; }
            public string JobTitle { get; set; }
            public string IssueAge { get; set; }
            public string Gender { get; set; }
            public string Reason { get; set; }

        }
        public class ExtreamGenerationParticipantOfferXml
        {
            [System.Xml.Serialization.XmlElement("ClassName", IsNullable = false)]
            public string ClassName { get; set; }

            [System.Xml.Serialization.XmlElement("OptionClassType", IsNullable = false)]
            public string OptionClassType { get; set; }

            [System.Xml.Serialization.XmlElement("PlanDesignType", IsNullable = false)]
            public string PlanDesignType { get; set; }

            [System.Xml.Serialization.XmlElement("PlanDesign", IsNullable = false)]
            public string PlanDesign { get; set; }

            [System.Xml.Serialization.XmlElement("MaximumIP", IsNullable = false)]
            public string MaximumIp { get; set; }

            [System.Xml.Serialization.XmlElement("ParticipationPercentageRequired", IsNullable = false)]
            public string ParticipationPercentageRequired { get; set; }

            [System.Xml.Serialization.XmlElement("CorporateSitus", IsNullable = false)]
            public string CorporateSitus { get; set; }

            [System.Xml.Serialization.XmlElement("costSharing", IsNullable = false)]
            public bool CostSharing { get; set; }

            [System.Xml.Serialization.XmlElement("costSharePercentage", IsNullable = false)]
            public string CostSharePercentage { get; set; }

            [System.Xml.Serialization.XmlElement("costSharePremiumAmount", IsNullable = false)]
            public string CostSharePremiumAmount { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public string cmsStandardOfferCode { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public QualifiedOfferTypeRestriction type { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public PayorTypeRestriction payorType { get; set; }

            [System.Xml.Serialization.XmlElement("taxType", IsNullable = false)]
            public string TaxType { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public string gltdPayorType { get; set; }

            [System.Xml.Serialization.XmlElement("gltdTaxType", IsNullable = false)]
            public string gltdTaxType { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
            public System.Nullable<PaymentMethodRestriction> paymentMethod { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public decimal totalMonthlyBenefit { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public string maxGSI { get; set; }
            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
            public System.Nullable<uint> benefitPeriodYears { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
            public System.Nullable<uint> benefitPeriodAge { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public uint eliminationPeriodDays { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
            public System.Nullable<decimal> sharedPremiumEmployerPercentage { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
            public System.Nullable<decimal> premiumBonusPercentage { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public bool isTobaccoRates { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
            public System.Nullable<decimal> discountPercentage { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public decimal baseMonthlyBenefit { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public decimal baseMonthlyPremium { get; set; }

            [System.Xml.Serialization.XmlElement("totalIncomeReplacementPercentage", IsNullable = false)]
            public string TotalIncomeReplacementPercentage { get; set; }

            [System.Xml.Serialization.XmlElement("alternateText", IsNullable = false)]
            public string AlternateText { get; set; }

            [System.Xml.Serialization.XmlElement("isBenefitTaxable", IsNullable = false)]
            public bool IsBenefitTaxable { get; set; }

            [System.Xml.Serialization.XmlElement("isParticipationRequired", IsNullable = false)]
            public bool IsParticipationRequired { get; set; }

            [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
            public bool isProViderChoice { get; set; }

            [System.Xml.Serialization.XmlElement("insIncCode", IsNullable = false)]
            public string insIncCode { get; set; }

            [System.Xml.Serialization.XmlElement("ltdMaximum", IsNullable = false)]
            public string ltdMaximum { get; set; }

            [System.Xml.Serialization.XmlElement("gltdCode", IsNullable = false)]
            public string gltdCode { get; set; }

            [System.Xml.Serialization.XmlElement("gltdReplacementPercentage", IsNullable = false)]
            public string gltdReplacementPercentage { get; set; }

            [System.Xml.Serialization.XmlElement("providerChoicePremiumSummary", IsNullable = false)]
            public ExstreamGenerationProviderChoicePremiumSummaries ProviderChoicePremiumSummary { get; set; }

            [System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
            [System.Xml.Serialization.XmlArrayItemAttribute("qualifiedRider", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = false)]
            public List<MLDIQualifiedRider> riders { get; set; }

            [XmlArray("BPParticipants")]
            [XmlArrayItem(typeof(ExtreamGenerationParticipantInOfferXml), ElementName = "BPParticipant")]
            public List<ExtreamGenerationParticipantInOfferXml> ParticipantsInOffer { get; set; }

            [System.Xml.Serialization.XmlElement("totalInsurableIncomes", IsNullable = false)]
            public ExstreamGenerationTotalInsurableIncomes TotalInsurableIncomes { get; set; }

            [System.Xml.Serialization.XmlElement("TotalgltdandIDIBenefitSummary", IsNullable = false)]
            public ExstreamGenerationTotalGLTDandIDITotalBenefitSummaries TotalGLTDAndIDIBenefitSummaries { get; set; }

            [System.Xml.Serialization.XmlElement("TotalproviderChoicePremiumSummary", IsNullable = false)]
            public ExstreamGenerationTotalProviderChoicePremiumSummaries TotalProviderChoicePremiumSummaries { get; set; }

            public ExtreamGenerationParticipantOfferXml()
            {

            }
        }

        public class ExtreamGenerationParticipantInOfferXml : ExtreamGenerationParticipantXml
        {

            public ExtreamGenerationParticipantInOfferXml()
            {

            }

        }
    }
}
