﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Managers.PreQuoteCalculationManagers.Calculators;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class EnrollmentKitAdditionalData
    {
        public IUnitOfWorkFactory UnitOfWorkFactory { get; private set; }
        public IWorkUnitManager WorkUnitManager { get; private set; }

        public EnrollmentKitAdditionalData(IUnitOfWorkFactory unitOfWorkFactory)
        {
            UnitOfWorkFactory = unitOfWorkFactory;
        }

        public void AddEnrollmentData(EnrollmentKitXmlGenerationRequest request, EnrollmentKitXml mldiCase)
        {

            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var caseBrokers = cmsCase.CaseBrokers.Where(c => c.Case.Id == request.CaseId);
                var caseUnderwritingRequests =
                    cmsCase.CaseUnderwritingRequests.FirstOrDefault(c => c.Case.Id == request.CaseId);

                var enrollment = cmsCase.CaseEnrollments.FirstOrDefault(c => c.Id == request.EnrollmentId);
                var enrollmentClassOut =
                    unitOfWork.Repository<EnrollmentOutput>()
                        .Linq()
                        .FirstOrDefault(c => c.Enrollment.Id == enrollment.Id);
                var contactAddress =
                    unitOfWork.Repository<ContactAddress>().Linq().Where(c => c.Case.Id == request.CaseId);
                var eligibilityConfiguration =
                    unitOfWork.Repository<EligibilityConfiguration>().Linq().Where(c => c.Case.Id == request.CaseId);

                var annualReviewsForCase = unitOfWork.Repository<AnnualReview>()
                                     .Linq().Where(c => c.Case.Id == request.CaseId && (c.AnnualReviewStatusType == AnnualReviewStatusTypeEnum.Annual_Review_Approved || c.AnnualReviewStatusType == AnnualReviewStatusTypeEnum.Annual_Review_Pending))
                                     .OrderByDescending(a => a.CaseYear);


                var isNewCase = !annualReviewsForCase.Any(a => a.CaseYear != null);

                var enrollmentParticipents =
                    unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c => c.Enrollment.Id == enrollment.Id && c.Participant.IsActive == true &&
                                                                                     (c.Participant.IsEligible == true ||
                                                                                      (c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.NoLongerInGroup &&
                                                                                       c.Participant.InEligibleReason_Id != (int)InEligibleReasonTypeEnum.ActivePolicyNoLongerInGroup &&
                                                                                       c.Participant.InEligibleReason_Id ==  null)));
                if (request.ParticipantIds != null && request.ParticipantIds.Count > 0)
                {
                    enrollmentParticipents = enrollmentParticipents.Where(c => request.ParticipantIds.Contains(c.Id));
                }


                var pdrClasses = enrollmentParticipents.Select(c => c.Participant.PlanDesignRequestClass).Distinct();
                var pdrSoldClass =
                    unitOfWork.Repository<PDRSoldClass>()
                        .Linq()
                        .Where(p => pdrClasses.Contains(p.PlanDesignRequestClass));

                var enrollmentPDRClasses = enrollment.Classes.Where(c => c.Enrollment.Id == enrollment.Id);

                mldiCase.Company = new EnrollmentKitXml.ExtreamGenerationCompanyXml(mldiCase.company);

                mldiCase.Company.companyLogoBLOB = string.Empty;

                var underWritingContact =
                    contactAddress.FirstOrDefault(
                        a => a.ContactAddressCategories.Any(b => b.ContactAddressCategoryType.Id == 10));

                mldiCase.presentedBy = underWritingContact == null ? null : underWritingContact.ContactName;

                var baseAgentlist = mldiCase.producersAndAgents;
                var enrollmentOutput =
                    unitOfWork.Repository<EnrollmentOutput>()
                        .Linq()
                        .FirstOrDefault(c => c.Enrollment.Id == enrollment.Id);

                mldiCase.ProducersAndAgents = new List<EnrollmentKitXml.ExtreamGenerationProducerAgentXml>();
                mldiCase.ProducersAndAgents = GetProducersAndAgents(mldiCase.producersAndAgents, caseBrokers,
                    contactAddress, enrollmentOutput);

                mldiCase.Groups = new List<EnrollmentKitXml.ExtreamGenerationGroup>();
                mldiCase.Groups = GetGroups(mldiCase, pdrSoldClass, enrollmentParticipents, cmsCase, caseBrokers,
                    enrollmentPDRClasses, request.SelectedForms, enrollmentClassOut, request, eligibilityConfiguration,
                    isNewCase, unitOfWork, request.IsCompactState);

                if (mldiCase.ExstreamRequestType == "BenefitPremium" || mldiCase.ExstreamRequestType == "EnrollmentTool")
                {
                    mldiCase.Groups.Clear();
                    mldiCase.Groups = null;

                    if (mldiCase.BPRequest != null)
                    {
                        var listOfClasses = pdrClasses.ToList();
                        var listIds = listOfClasses.Select(x => x.Id).ToList();

                        var participants = unitOfWork.Repository<Participant>().Linq().Where(c => listIds.Contains(c.PlanDesignRequestClass.Id));

                        var inEligibleParticipants = unitOfWork.Repository<EnrollmentParticipant>()
                            .Linq()
                            .Where(
                                ep => ep.Enrollment.Id == request.EnrollmentId && ep.Participant.IsEligible != true &&
                                      (ep.Participant.InEligibleReason_Id !=
                                       (int)InEligibleReasonTypeEnum.NoLongerInGroup &&
                                       ep.Participant.InEligibleReason_Id !=
                                       (int)InEligibleReasonTypeEnum.ActivePolicyNoLongerInGroup ||
                                       ep.Participant.InEligibleReason_Id == null));

                        CreateIneligibleParticipantsXml(mldiCase, inEligibleParticipants);

                        foreach (var group in mldiCase.BPRequest)
                        {
                            if (group.ParticipantOffers != null)
                            {
                                foreach (var offer in group.ParticipantOffers)
                                {
                                    offer.ProviderChoicePremiumSummary = null;
                                }
                            }
                        }
                    }
                }

                if (mldiCase.ExstreamRequestType != "BenefitPremium" && mldiCase.ExstreamRequestType != "EnrollmentTool")
                {
                    mldiCase.BPRequest = new List<EnrollmentKitXml.ExtreamGenerationBPOptionXml>();
                    mldiCase.IneligibleParticipant =
                        new List<EnrollmentKitXml.ExtreamGenerationInEligibleParticipantXml>();
                }

            }
        }

        private List<EnrollmentKitXml.ExtreamGenerationProducerAgentXml> GetProducersAndAgents(List<MLDIProducerAgent> inAgents, IEnumerable<CaseBroker> caseBrokers, IQueryable<ContactAddress> contactAddress, EnrollmentOutput enrlOutput)
        {
            List<EnrollmentKitXml.ExtreamGenerationProducerAgentXml> listMldiProducerAgent = new List<EnrollmentKitXml.ExtreamGenerationProducerAgentXml>();
            bool contactAdded = false;
            foreach (var a in inAgents)
            {
                var agent = new EnrollmentKitXml.ExtreamGenerationProducerAgentXml();
                var agentSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace, };
                var serPart = JsonConvert.SerializeObject(a, agentSettings);
                agent = JsonConvert.DeserializeObject<EnrollmentKitXml.ExtreamGenerationProducerAgentXml>(serPart);

                agent.AddressSlipProducerAgent = new List<EnrollmentKitXml.ExtreamGenerationAddressSlip>();

                bool contactNameFound = enrlOutput != null && enrlOutput.ReturnAddress != null && !contactAdded;

                if (contactNameFound)
                {
                    var agentSlip = new EnrollmentKitXml.ExtreamGenerationAddressSlip();
                    agentSlip.personalInformation.type = PersonTypeRestriction.ProducerAgent;
                    agentSlip.AgencyCode = agent.agencyCode != null ? agent.agencyCode : string.Empty;
                    agentSlip.AgencyName = agent.agencyName != null ? agent.agencyName : string.Empty;
                    agentSlip.CmsCode = agent.cmsCode != null ? agent.cmsCode : string.Empty;

                    agentSlip.personalInformation.email = enrlOutput.ReturnAddress.Email;
                    agentSlip.personalInformation.firstName = enrlOutput.ReturnAddress.ContactName;

                    agentSlip.personalInformation.title = enrlOutput.ReturnAddress.JobTitle;
                    agentSlip.personalInformation.addresses = new List<MLDIAddress>();
                    if (enrlOutput.ReturnAddress != null)
                    {
                        var slipAddress = new MLDIAddress()
                        {
                            type = AddressTypeRestriction.Work,
                            locationName = enrlOutput.ReturnAddress.CompanyName ?? String.Empty,
                            street1 = enrlOutput.ReturnAddress.AddressLine1 ?? String.Empty,
                            street2 = enrlOutput.ReturnAddress.AddressLine2 ?? String.Empty,
                            city = enrlOutput.ReturnAddress.City ?? String.Empty,
                            state = enrlOutput.ReturnAddress.StateType.ToString() ?? String.Empty,
                            postalCode = enrlOutput.ReturnAddress.ZipCode ?? String.Empty,
                            country = String.Empty,
                            phoneNumber = enrlOutput.ReturnAddress.Phone ?? String.Empty
                        };
                        agentSlip.personalInformation.addresses.Add(slipAddress);
                    }

                    agent.AddressSlipProducerAgent = new List<EnrollmentKitXml.ExtreamGenerationAddressSlip>();
                    agent.AddressSlipProducerAgent.Add(agentSlip);
                    contactAdded = true;
                }
                listMldiProducerAgent.Add(agent);
            }

            return listMldiProducerAgent;
        }
        private List<EnrollmentKitXml.ExtreamGenerationGroup> GetGroups(EnrollmentKitXml mldiCase, IQueryable<PDRSoldClass> pdrSoldClass, IQueryable<EnrollmentParticipant> enrollmentParticipents, Case cmsCase, IEnumerable<CaseBroker> caseBrokers, IEnumerable<EnrollmentPDRClass> enrollmentPDRClasss, List<EnrollmentKitTypeEnum> selectedForms, EnrollmentOutput enrollmentClassIn, EnrollmentKitXmlGenerationRequest inRequest, IQueryable<EligibilityConfiguration> eligibilityConfiguration, bool isNewCase, IUnitOfWork unitOfWork, bool isCompactState)
        {

            List<EnrollmentKitXml.ExtreamGenerationGroup> lstMLDIGroup = new List<EnrollmentKitXml.ExtreamGenerationGroup>();

            bool isCAState = false;
            bool hasRpp = false;
            bool? isERVGSITemplate = false;           
            bool? isVGSIPlan = false;
            bool isIncreaseKitNeeded = false;
            string printFile = inRequest.PrintFile == true ? "Y" : "N";

            foreach (var g in mldiCase.groups)
            {
               
                isVGSIPlan = pdrSoldClass.FirstOrDefault().PlanDesignRequestClass.PlanDesignRequestClassProducts?.Any(x => x.IsGSIPlanIndicator == true);
                var group = new EnrollmentKitXml.ExtreamGenerationGroup();
                var bprequest = new EnrollmentKitXml.ExtreamGenerationBPOptionXml();
                group.isVgsiPlanDesignType = isVGSIPlan.Value;
                group.cmsCode = g.cmsCode;
                group.groupDescription = g.groupDescription;
                group.groupName = g.groupName;
                group.EligibleParticipants = new List<EnrollmentKitXml.ExtreamGenerationParticipantXml>();

                var sortedParticipants = g.eligibleParticipants;
                if (mldiCase.ExstreamRequestType == "BenefitPremium" || mldiCase.ExstreamRequestType == "EnrollmentTool")
                {
                    var classParticipants =
                        enrollmentParticipents.Where(
                            a => a.Participant.PlanDesignRequestClass.PlanDesignRequestClassName == g.groupName)
                            .ToList();

                    var eligClassParticipants = from sp in g.eligibleParticipants
                                                join p in classParticipants on sp.cmsCode equals p.Id.ToString()
                                                select sp;

                    sortedParticipants = new List<MLDIParticipant>(eligClassParticipants.OrderByDescending(a => a.incomeDetails.currentYearInsurableIncome)
                        .Where(c => c.offers != null && c.offers.FirstOrDefault() != null)
                        .OrderBy(c => c.offers.FirstOrDefault().OptionClassTypeOrder));

                }

                foreach (var p in sortedParticipants)
                {
                    if (p.isMockEmployee == false)
                    {                        
                        Log.TraceFormat("EnrollmentKitAdditionalData - Processing Participant {0}", p.cmsCode);

                        isERVGSITemplate = false;                       
                        isIncreaseKitNeeded = false;

                        var participant = new EnrollmentKitXml.ExtreamGenerationParticipantXml();
                        var partSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace, };
                        var serPart = JsonConvert.SerializeObject(p, partSettings);
                        participant = JsonConvert.DeserializeObject<EnrollmentKitXml.ExtreamGenerationParticipantXml>(serPart);

                        participant.incomeDetails = null;
                        participant.currentLTDs = new List<MLDIAdditionalLtd>();
                        participant.currentLTDs = null;

                        participant.offers = new List<MLDIQualifiedOffer>();
                        participant.offers = null;

                        var enrollmentId = Convert.ToInt32(p.cmsCode);
                        var enrollmentParticipant = enrollmentParticipents.FirstOrDefault(x => x.Id == enrollmentId);
                        var firstEligblePart = enrollmentParticipents.FirstOrDefault(a => a.Participant.IsEligible.Value);
                        if (firstEligblePart == null || firstEligblePart.Participant == null || firstEligblePart.Participant.ListBillNumber == null)
                        {
                            Log.TraceFormat("EnrollmentKitAdditionalData - Participant ListBillNumber is Null, Defaulting to Monthly");
                        }

                        var enrollmentBillingMode = firstEligblePart != null && firstEligblePart.Participant != null && firstEligblePart.Participant.ListBillNumber != null ? firstEligblePart.Participant.ListBillNumber.BillingModeType : BillingModeTypeEnum.Monthly;


                        if (enrollmentParticipant == null)
                        {
                            Log.TraceFormat("EnrollmentKitAdditionalData - partValues is Null");
                        }

                        if (enrollmentParticipant != null)
                        {
                            Log.TraceFormat("EnrollmentKitAdditionalData - EnrollmentParticipantsID = [{0}]", enrollmentParticipant.Id.ToString());
                        }

                        Log.TraceFormat("EnrollmentKitAdditionalData - MLDIParticipant enrollment CMSCODE = [{0}]", p.cmsCode);

                        if (enrollmentParticipant != null && enrollmentParticipant.Participant == null)
                        {
                            Log.TraceFormat("EnrollmentKitAdditionalData - partValues.Participant is null");
                        }

                        if (enrollmentParticipant != null && enrollmentParticipant.Participant != null)
                        {
                            if ((enrollmentParticipant.Participant.ParticipantCategoryCodeType != null && 
                                (enrollmentParticipant.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.NE ||
                                 enrollmentParticipant.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.PS ||
                                 enrollmentParticipant.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.FO ||
                                 enrollmentParticipant.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB)) && 
                                (enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType != null && 
                                 enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB))
                            {
                                isERVGSITemplate = true;
                            }

                            if ((enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType != null &&
                               (enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.NE ||
                                enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.PS ||
                                enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.FO ||
                                enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB)) &&
                               (enrollmentParticipant.Participant.ParticipantCategoryCodeType != null &&
                                enrollmentParticipant.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB))
                            {
                                isERVGSITemplate = true;
                            }
                           
                            if (
                                 (enrollmentParticipant.Participant.ParticipantCategoryCodeType != null &&
                                  enrollmentParticipant.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB) &&
                                 (enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType != null &&  
                                  enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB)
                               )
                            {

                                if (enrollmentParticipant.Participant.BaseAMBCalculatedAmount > 0 && enrollmentParticipant.Participant.VGSIBuyUpAMBCalculatedAmount > 0)
                                {
                                    isERVGSITemplate = true;
                                }
                                else
                                {
                                    isERVGSITemplate = false;
                                    isIncreaseKitNeeded = true;
                                }
                                
                            }                            

                            participant.EmployeeId = string.IsNullOrEmpty(enrollmentParticipant.Participant.EmployeeId) ? "" : enrollmentParticipant.Participant.EmployeeId;
                            participant.ExistingTobaccoStatus = enrollmentParticipant.IsSmoker.ToString();
                            if (enrollmentParticipant.Participant.IsAMBIncreaseIndicator != null && enrollmentParticipant.Participant.IsAMBIncreaseIndicator == true
                                && enrollmentParticipant.EnrollmentParticipantOptionPlans != null)
                            {
                                var isSmoker = enrollmentParticipant.EnrollmentParticipantOptionPlans.Any(op => op.IsSmoker == true);
                                participant.ExistingTobaccoStatus = isSmoker ? "Smoker" : "Non Smoker";
                            }
                            participant.PhoneNumber = enrollmentParticipant.Participant.WorkLocationPhone ?? enrollmentParticipant.Participant.HomePhone;
                            participant.ClassName = enrollmentParticipant.Participant.PlanDesignRequestClass.ApprovedEligiblePopulationText.ToString();
                            participant.PayrollDeductionPeriod = enrollmentParticipant.Participant.BenefitDeductionFrequency.ToString();
                            participant.EmailAddress = enrollmentParticipant.Participant.WorkEmail ?? enrollmentParticipant.Participant.PersonalEmail;
                            participant.PremiumPaymentPeriod = enrollmentParticipant.Participant.BenefitDeductionFrequencyDescription;
                            participant.TotalGLTDPlusIDICalculatedAmount = enrollmentParticipant.Participant.TotalGLTDPlusIDICalculatedAmount.ToString();
                            if (enrollmentParticipant.Policies.Any())
                            {
                                var policyNo = enrollmentParticipant.Policies.FirstOrDefault(c => c.EnrollmentParticipant.Id == enrollmentParticipant.Id);
                                participant.existingPolicyNumber = policyNo.PolicyNumber;
                            }
                            if (enrollmentParticipant.EnrollmentParticipantOptionPlans != null && enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault() != null)
                            {

                                var formattedGltdPlusIdiCalculatedPercentage = enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault();

                                if (formattedGltdPlusIdiCalculatedPercentage != null)
                                {
                                    if (formattedGltdPlusIdiCalculatedPercentage.TotalGLTDPlusIDICalculatedPercentage != null && formattedGltdPlusIdiCalculatedPercentage.TotalGLTDPlusIDICalculatedPercentage > 0)
                                    {
                                        participant.TotalGLTDPlusIDICalculatedPercentage = DecimaltoPercentage(formattedGltdPlusIdiCalculatedPercentage.TotalGLTDPlusIDICalculatedPercentage.ToString());

                                    }
                                }
                            }


                            participant.VoluntaryGSIBuyUpCalculatedAmount = enrollmentParticipant.Participant.VoluntaryGSIBuyUpCalculatedAmount.ToString();
                            Log.TraceFormat("Participant: FirstName is {0},LastName is {1}, IssueAge is {2}. Participant DOB is {3} and Effective date is {4}:EnrollmentKitAdditionalData createXML", enrollmentParticipant.Participant.FirstName, enrollmentParticipant.Participant.LastName, enrollmentParticipant.Participant.IssueAge, enrollmentParticipant.Participant.DateOfBirth?.ToString(), enrollmentParticipant.Enrollment.EffectiveDate.ToString());                          
                            participant.Age = enrollmentParticipant.Participant.DateOfBirth.GetAge(enrollmentParticipant.Enrollment.EffectiveDate).ToString();
                            Log.TraceFormat("Participant: FirstName is {0},LastName is {1}, calculated Age is {2}. Participant DOB is {3} and Effective date is {4}:EnrollmentKitAdditionalData createXML", enrollmentParticipant.Participant.FirstName, enrollmentParticipant.Participant.LastName, participant.Age, enrollmentParticipant.Participant.DateOfBirth?.ToString(), enrollmentParticipant.Enrollment.EffectiveDate.ToString());

                            List<string> overideValues = new List<string>();

                            var eligConfig = eligibilityConfiguration.FirstOrDefault();

                            if (eligConfig?.IssueLimitMaximum != null && eligConfig?.IssueLimitMaximum > 0)
                            {
                                overideValues.Add(eligConfig.IssueLimitMaximum.ToString());
                            }

                            if (eligConfig?.ParticipationLimit != null && eligConfig?.ParticipationLimit > 0)
                            {
                                overideValues.Add(eligConfig.ParticipationLimit.ToString());
                            }

                            participant.OverrideIPLimit = overideValues != null && overideValues.Count > 1 ? string.Join("/", overideValues) : string.Empty;
                        }

                        participant.PreviousDeclineNumber = string.Empty;
                        participant.BasePlanPreviousSolicitations = false;
                        if (enrollmentParticipant != null && enrollmentParticipant.Participant != null && enrollmentParticipant.Participant.BasePlanPreviousSolicitations != null)
                        {
                            participant.BasePlanPreviousSolicitations = enrollmentParticipant.Participant.BasePlanPreviousSolicitations > 0;
                        }


                        var pdrS = pdrSoldClass.FirstOrDefault();
                        if (enrollmentParticipant != null && enrollmentParticipant.Participant != null && enrollmentParticipant.Participant.PlanDesignRequestClass != null)
                        {
                            pdrS =
                                pdrSoldClass.FirstOrDefault(
                                    a =>
                                        a.PlanDesignRequestClass ==
                                        enrollmentParticipant.Participant.PlanDesignRequestClass);
                        }

                        if (pdrS != null)
                        {
                            participant.GltdCode =
                                pdrS.PDRSoldClassLTDCoverage.Any()
                              ? pdrS.PDRSoldClassLTDCoverage.FirstOrDefault().GroupLTDCoveredEarningsType.ToString()
                              : string.Empty;

                            var ptlType = (pdrS.PlanDesignRequestClass.PlanDesignRequestClassLTDCoverage.Any()) ? pdrS.PlanDesignRequestClass.PlanDesignRequestClassLTDCoverage.FirstOrDefault().PremiumAndTaxpayerLiabilityType.ToString() : null;
                            if (ptlType != null)
                            {
                                participant.GltdTaxable = ptlType.ToLower() == "taxable" ? "True" : "False";

                                participant.GltdErPaid = ptlType.ToLower() == "employer paid" ? "True" : "False";
                            }
                            else
                            {
                                participant.GltdTaxable = string.Empty;
                                participant.GltdErPaid = string.Empty;
                            }
                        }

                        var pdrSoldClassPlan = pdrS != null && pdrS.PDRSoldClassPlan != null ? pdrS.PDRSoldClassPlan.FirstOrDefault() : null;
                        if (pdrSoldClassPlan != null)
                        {
                            participant.AnyCostSharing = pdrSoldClassPlan.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare ? "True" : "False";
                            mldiCase.participationPercentage = pdrSoldClassPlan.ParticipationPercentage.ToString();
                            participant.LtdPercentage = DecimaltoPercentage(pdrSoldClassPlan.LTDPercentage.ToString());
                            hasRpp = pdrSoldClassPlan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan ? true : false;
                        }

                        var pdrCov = (pdrS != null && pdrS.PDRSoldClassLTDCoverage != null) ? pdrS.PDRSoldClassLTDCoverage.FirstOrDefault() : null;

                        if (pdrCov != null)
                            participant.LtdMaximum = pdrCov.GroupLTDCapAmount.ToString();

                        var employeeType = enrollmentClassIn != null &&
                                           enrollmentClassIn.EnrollmentOutputEmployeeType != null
                            ? enrollmentClassIn.EnrollmentOutputEmployeeType.Description
                            : null;

                        var customEmployeeType = enrollmentClassIn != null && enrollmentClassIn.CustomEmployeeTypeText != null ? enrollmentClassIn.CustomEmployeeTypeText : null;

                        if (!string.IsNullOrEmpty(customEmployeeType))
                        {
                            employeeType = customEmployeeType;
                        }

                        participant.EmployeeType = employeeType;

                        participant.IncomeDetails = new EnrollmentKitXml.ExtreamGenerationParticipantIncomeXml();
                        {
                            var pIncSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace, };
                            var serInc = JsonConvert.SerializeObject(p.incomeDetails, pIncSettings);
                            participant.IncomeDetails = JsonConvert.DeserializeObject<EnrollmentKitXml.ExtreamGenerationParticipantIncomeXml>(serInc);

                            var monthlysal = enrollmentParticipant != null && enrollmentParticipant.Participant != null ? enrollmentParticipant.Participant.CurrentYearSalaryAmount : 0;
                            participant.IncomeDetails.BaseMonthlySalary = string.Empty;
                            if (monthlysal != null && monthlysal > 0)
                            {
                                decimal sal = 0;
                                sal = Convert.ToDecimal(monthlysal);

                                if (sal > 0)
                                {
                                    decimal basmonthval = Math.Round(((sal) / 12), 2);

                                    participant.IncomeDetails.BaseMonthlySalary = basmonthval.ToString(CultureInfo.InvariantCulture);
                                }
                            }


                            participant.IncomeDetails.GLTDNetMonthlyIncome = enrollmentParticipant != null && enrollmentParticipant.Participant != null ? enrollmentParticipant.Participant.GLTDBenefitCalculatedAmount.ToString() : string.Empty;
                            participant.IncomeDetails.IncomeReplaced = enrollmentParticipant != null && enrollmentParticipant.Participant != null ? enrollmentParticipant.Participant.GLTDBenefitCalculatedAmount.ToString() : string.Empty;

                            if (enrollmentParticipant.EnrollmentParticipantOptionPlans != null && enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault() != null)
                            {

                                var totGltd = enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault();
                                if (totGltd.GLTDReplacementCalculatedPercentage != null && totGltd.GLTDReplacementCalculatedPercentage > 0)
                                {
                                    participant.IncomeDetails.GLTDReplacementPercentage = DecimaltoPercentage(totGltd.GLTDReplacementCalculatedPercentage.ToString());

                                }
                            }

                            if (enrollmentClassIn != null)
                            {

                                participant.IncomeDetails.GLTDTaxBracket = DecimaltoPercentage(enrollmentClassIn.TaxRatePercentage.ToString());
                                participant.IncomeDetails.TaxBracket = DecimaltoPercentage(enrollmentClassIn.TaxRatePercentage.ToString());

                            }
                            //Defect MCRT-1800 - Enrollment Kit - Application - Total Income  Fix
                            if (pdrSoldClassPlan != null && pdrSoldClassPlan.CoveredEarningsType != CoveredEarningsTypeEnum.W_2Income)
                            {
                                decimal? totalIncome = participant.IncomeDetails.baseSalary + (participant.IncomeDetails.bonusIncome ?? 0) + (participant.IncomeDetails.commissionIncome ?? 0);
                                participant.IncomeDetails.TotalAnnualIncome = totalIncome != null ? totalIncome.ToString() : string.Empty;
                            }
                            else
                            {
                                participant.IncomeDetails.TotalAnnualIncome = participant.IncomeDetails.w2Income.ToString() ?? "0.0";
                            }
                            participant.IncomeDetails.FeesIncome = enrollmentParticipant != null && enrollmentParticipant.Participant != null ? enrollmentParticipant.Participant.OtherIncomeAmount.ToString() : string.Empty;

                            if (enrollmentParticipant != null && enrollmentParticipant.EnrollmentParticipantOptionPlans != null && enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault() != null)
                            {
                                if (enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault().EnrollmentPDRClassOptionPlan != null && enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault().EnrollmentPDRClassOptionPlan.CoveredEarningsType != null)
                                {
                                    var IncCode = enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault().EnrollmentPDRClassOptionPlan.CoveredEarningsType.GetDescription();
                                    participant.IncomeDetails.InsIncCode = IncCode != null ? IncCode : string.Empty;
                                }

                            }
                        }

                        participant.CurrentLTDs = new List<EnrollmentKitXml.ExtreamGenerationAdditionalLtdXml>();
                        if (p.currentLTDs != null)
                        {
                            foreach (var c in p.currentLTDs)
                            {
                                var ltd = new EnrollmentKitXml.ExtreamGenerationAdditionalLtdXml();
                                var deserializeSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace, };
                                var serObj = JsonConvert.SerializeObject(c, deserializeSettings);
                                ltd = JsonConvert.DeserializeObject<EnrollmentKitXml.ExtreamGenerationAdditionalLtdXml>(serObj);

                                if (enrollmentParticipant != null && enrollmentParticipant.Enrollment != null)
                                {
                                    ltd.DateToBeReplaced = enrollmentParticipant.Enrollment.EffectiveDate.ToString("yyyy-MM-dd");
                                    var brLtd = enrollmentParticipant.BridgelineAdditionalLTDCoverage.FirstOrDefault(x => x.EnrollmentParticipant.Id == enrollmentParticipant.Enrollment.Id);
                                    ltd.IsReplacement = brLtd != null && brLtd.IsReplacementCoverage != null ? (bool)brLtd.IsReplacementCoverage : false;
                                }
                                if (c.carrierName == "Berkshire Combined" && mldiCase.ExstreamRequestType == "EnrollmentKit")
                                {
                                    //No need to show Berkshire Combined For Enrollment Kit
                                }
                                else
                                {
                                    participant.CurrentLTDs.Add(ltd);
                                }
                            }

                        }

                        participant.Offers = new List<EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml>();
                        //Options were coming out of order.  Re-ordering them.                      
                        var orderedOffers = p.offers.OrderBy(c => c.xmlOrderPosition).ToList();

                        if (mldiCase.ExstreamRequestType == "EnrollmentTool")
                        {
                            var nonTobaccoOffers = orderedOffers.Where(c => c.cmsStandardOfferCode != null && c.cmsStandardOfferCode.Contains("Non Tobacco")).ToList();
                            orderedOffers = nonTobaccoOffers;
                        }

                        participant.Forms = new List<EnrollmentKitXml.ExtreamGenerationForm>();
                        var situsType = enrollmentParticipant != null && enrollmentParticipant.Enrollment != null && enrollmentParticipant.Enrollment.Case != null && enrollmentParticipant.Enrollment.Case.CaseUnderwritingRequests != null ? enrollmentParticipant.Enrollment.Case.CaseUnderwritingRequests.FirstOrDefault() : new CaseUnderwritingRequest();

                        isCAState = situsType != null ? situsType.StateType == StateTypeEnum.CA ? true : false : false;

                        if (mldiCase.ExstreamRequestType == "EnrollmentKit")
                        {
                            if (!hasRpp)
                            {
                                hasRpp = orderedOffers.SelectMany(o => o.riders).Any(r => r.riderIdentifier == "RPP");
                            }

                            if (((enrollmentParticipant.Participant.ParticipantCategoryCodeType != null &&
                                   enrollmentParticipant.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB) ||
                                   (enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType != null &&
                                   enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB)) &&
                                   ((enrollmentParticipant.Enrollment.AMBType != null && enrollmentParticipant.Enrollment.AMBType == AMBTypeEnum.Negative) ||
                                   (enrollmentParticipant.Enrollment.BuyUpAMBType != null && enrollmentParticipant.Enrollment.BuyUpAMBType == AMBTypeEnum.Negative)))
                            {
                                participant.Forms.Add(new EnrollmentKitXml.ExtreamGenerationForm
                                {
                                    FormName = "Increase Letter",
                                    FormState = GetContractState(enrollmentParticipant, situsType),
                                    PrintFile = printFile
                                });

                                participant.Forms.Add(new EnrollmentKitXml.ExtreamGenerationForm
                                {
                                    FormName = EnrollmentKitTypeEnum.Declination_of_Coverage.GetDescription(),
                                    FormState = GetContractState(enrollmentParticipant, situsType),
                                    PrintFile = printFile
                                });
                            }
                            else if (((enrollmentParticipant.Participant.ParticipantCategoryCodeType != null && 
                                      enrollmentParticipant.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB ) ||
                                      (enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType != null &&
                                      enrollmentParticipant.Participant.BuyUpParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB)) &&
                                      ((enrollmentParticipant.Enrollment.AMBType != null && 
                                      (enrollmentParticipant.Enrollment.AMBType == AMBTypeEnum.Paper || enrollmentParticipant.Enrollment.AMBType == AMBTypeEnum.OnlinePaper)) ||
                                      (enrollmentParticipant.Enrollment.BuyUpAMBType != null &&
                                      (enrollmentParticipant.Enrollment.BuyUpAMBType == AMBTypeEnum.Paper || enrollmentParticipant.Enrollment.BuyUpAMBType == AMBTypeEnum.OnlinePaper))))
                            {
                                if (mldiCase.ExstreamRequestType == "EnrollmentKit")
                                {
                                    if (isIncreaseKitNeeded == true  || isVGSIPlan == false)
                                    {
                                        if (!participant.Forms.Any(i => i.FormName == "Increase Kit"))
                                        {
                                            participant.Forms.Add(new EnrollmentKitXml.ExtreamGenerationForm
                                            {
                                                FormName = "Increase Kit",
                                                FormState = GetContractState(enrollmentParticipant, situsType),
                                                PrintFile = printFile
                                            });
                                        }
                                    }
                                }

                                participant.Forms.Add(new EnrollmentKitXml.ExtreamGenerationForm
                                {
                                    FormName = EnrollmentKitTypeEnum.Applications.GetDescription(),
                                    FormState = GetContractState(enrollmentParticipant, situsType),
                                    PrintFile = printFile
                                });

                                // NBTC-2870 check for amb paper and if it's an increase exclude the OOC.
                                if (enrollmentParticipant.Enrollment.AMBType != null &&
                                    (enrollmentParticipant.Enrollment.AMBType == AMBTypeEnum.Paper || enrollmentParticipant.Enrollment.AMBType == AMBTypeEnum.OnlinePaper) &&
                                    (enrollmentParticipant.Participant.IsAMBIncreaseIndicator != null && enrollmentParticipant.Participant.IsAMBIncreaseIndicator == true ||
                                    enrollmentParticipant.Participant.IsBuyUpAMBIncreaseIndicator != null && enrollmentParticipant.Participant.IsBuyUpAMBIncreaseIndicator == true))
                                {
                                    if (selectedForms.Contains(EnrollmentKitTypeEnum.Outline_of_Coverage))
                                    {
                                        selectedForms.Remove(EnrollmentKitTypeEnum.Outline_of_Coverage);
                                    }
                                }


                                if (isCAState)
                                {
                                    if (selectedForms.Contains(EnrollmentKitTypeEnum.Outline_of_Coverage))
                                    {
                                        selectedForms.Remove(EnrollmentKitTypeEnum.Outline_of_Coverage);
                                    }

                                    if (hasRpp)
                                    {
                                        if (selectedForms.Contains(EnrollmentKitTypeEnum.RPP_Authorization_and_Irrevocable_Assignment))
                                        {
                                            selectedForms.Remove(EnrollmentKitTypeEnum.RPP_Authorization_and_Irrevocable_Assignment);
                                        }

                                        if (selectedForms.Contains(EnrollmentKitTypeEnum.RPP_Disclosure_Statement))
                                        {
                                            selectedForms.Remove(EnrollmentKitTypeEnum.RPP_Disclosure_Statement);
                                        }

                                        if (selectedForms.Contains(EnrollmentKitTypeEnum.RPP_Rider_Authorization_and_Irrevocable_Assignment))
                                        {
                                            selectedForms.Remove(EnrollmentKitTypeEnum.RPP_Rider_Authorization_and_Irrevocable_Assignment);
                                        }

                                        if (selectedForms.Contains(EnrollmentKitTypeEnum.RPP_Rider_Disclosure_Statement))
                                        {
                                            selectedForms.Remove(EnrollmentKitTypeEnum.RPP_Rider_Disclosure_Statement);
                                        }

                                    }
                                }
                            }

                            if (!participant.Forms.Any(i => i.FormName == "Increase Letter"))
                            {
                                if (isERVGSITemplate.Value == true)
                                {
                                    participant.Forms.Add(new EnrollmentKitXml.ExtreamGenerationForm
                                    {
                                        FormName = "ERVGSI Annual Review kit",
                                        FormState = GetContractState(enrollmentParticipant, situsType),
                                        PrintFile = printFile
                                    });
                                }

                                if (isIncreaseKitNeeded == true)
                                {
                                    participant.Forms.Add(new EnrollmentKitXml.ExtreamGenerationForm
                                    {
                                        FormName = "Increase Kit",
                                        FormState = GetContractState(enrollmentParticipant, situsType),
                                        PrintFile = printFile
                                    });

                                }
                            }                           

                            

                            foreach (var selFrm in selectedForms)
                            {
                                Log.TraceFormat("EnrollmentKitAdditionalData - Processing Form {0}", selFrm.ToString());

                                if (selFrm == EnrollmentKitTypeEnum.RPP_Authorization_and_Irrevocable_Assignment
                                    || selFrm == EnrollmentKitTypeEnum.RPP_Disclosure_Statement
                                    || selFrm == EnrollmentKitTypeEnum.RPP_Rider_Authorization_and_Irrevocable_Assignment
                                    || selFrm == EnrollmentKitTypeEnum.RPP_Rider_Disclosure_Statement)
                                {
                                    if (!hasRpp)
                                    {
                                        continue;
                                    }
                                }

                                if (participant.Forms.Any())
                                {
                                    bool formAlreadyExists = participant.Forms.Any(i => i.FormName == selFrm.GetDescription());
                                    if (!formAlreadyExists)
                                    {
                                        var form = new EnrollmentKitXml.ExtreamGenerationForm();
                                        form.FormName = selFrm.GetDescription();
                                        form.FormState = GetContractState(enrollmentParticipant, situsType);
                                        form.PrintFile = printFile;

                                        participant.ContractState = form.FormState;

                                        bool isIncreaseKitFormPresent = participant.Forms.Any(i => i.FormName == "Increase Kit");
                                        if (form.FormName == "Enrollment Kit" && isIncreaseKitFormPresent)
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            participant.Forms.Add(form);
                                        }
                                    }
                                }
                                else
                                {
                                    var form = new EnrollmentKitXml.ExtreamGenerationForm();
                                    form.FormName = selFrm.GetDescription();
                                    form.FormState = GetContractState(enrollmentParticipant, situsType);
                                    form.PrintFile = printFile;
                                    participant.ContractState = form.FormState;
                                    participant.Forms.Add(form);
                                }
                            }



                        }
                        else
                        {
                            participant.ContractState = GetContractState(enrollmentParticipant, situsType);
                        }

                        foreach (var o in orderedOffers)
                        {
                            var offer = new EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml();
                            var deserializeSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace, };
                            var serTest = JsonConvert.SerializeObject(o, deserializeSettings);
                            offer = JsonConvert.DeserializeObject<EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml>(serTest);
                            offer.AlternateText = enrollmentClassIn != null ? enrollmentClassIn.AlternateReplacementPercentText : null;

                            offer.IsBenefitTaxable = false;
                            offer.CostSharing = false;
                            offer.IsParticipationRequired = enrollmentClassIn != null && !string.IsNullOrEmpty(enrollmentClassIn.ResponseRequiredText);

                            if (pdrSoldClassPlan != null)
                            {
                                offer.CostSharing = pdrSoldClassPlan.PremiumPayerAndTaxabilityType.Id == (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare;
                                offer.IsBenefitTaxable = pdrSoldClassPlan.TaxabilityType == TaxabilityTypeEnum.Taxable;
                                offer.maxGSI = pdrSoldClassPlan.GSIAmount.ToString();
                                if (pdrSoldClassPlan.TaxabilityType != null)
                                {
                                    offer.TaxType = ((TaxabilityTypeEnum)pdrSoldClassPlan.TaxabilityType).GetDescription().ToString();
                                }

                                if (pdrSoldClassPlan.TypeOfShareType == TypeOfShareTypeEnum.PercentofPremium)
                                {
                                    offer.CostSharePercentage = pdrSoldClassPlan.EmployerPaidPremium.ToString();
                                }

                                if (pdrSoldClassPlan.TypeOfShareType == TypeOfShareTypeEnum.PremiumAmount)
                                {
                                    offer.CostSharePremiumAmount = pdrSoldClassPlan.EmployerPaysupto.ToString();
                                }

                            }

                            if (enrollmentParticipant.EnrollmentParticipantOptionPlans != null && enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault() != null)
                            {

                                var totGltd = enrollmentParticipant.EnrollmentParticipantOptionPlans.FirstOrDefault();
                                if (totGltd.IDIBaseReplacementCalculatedPercentage != null && totGltd.IDIBaseReplacementCalculatedPercentage > 0)
                                {
                                    offer.TotalIncomeReplacementPercentage = DecimaltoPercentage(totGltd.IDIBaseReplacementCalculatedPercentage.ToString());

                                }
                            }

                            foreach (var Offercheck in enrollmentParticipant.EnrollmentParticipantOptionPlans)
                            {
                                if (Offercheck != null &&
                                   (o.cmsStandardOfferCode == Offercheck.StandardOptionCodeSmoker ||
                                    o.cmsStandardOfferCode == Offercheck.StandardOptionCodeNonSmoker))
                                {

                                    if (o.isTobaccoRates == true)
                                    {
                                        switch (o.payorType)
                                        {
                                            case PayorTypeRestriction.Shared:
                                                if (enrollmentClassIn != null && enrollmentClassIn.EnrollmentOutputPremiumDisplayType != null && enrollmentClassIn.EnrollmentOutputPremiumDisplayType.Description == "Per Month")
                                                {
                                                    offer.yourPremiumPayCheck = 0;
                                                    offer.YourPremiumPerMonth = Offercheck.SmokerEmployeePremiumPerMonth ?? 0;
                                                }
                                                else
                                                {
                                                    offer.yourPremiumPayCheck = Offercheck.SmokerEmployeePremiumAmountPaycheck ?? 0;
                                                    offer.YourPremiumPerMonth = Offercheck.SmokerEmployeePremiumPerMonth ?? 0;
                                                }
                                                offer.employerPremiumPerPayCheck = Offercheck.SmokerEmployerPremiumAmountPaycheck ?? 0;
                                                offer.employerPremiumPerMonth = Offercheck.SmokerEmployerPremiumPerMonth ?? 0;
                                                break;
                                            case PayorTypeRestriction.Employer:
                                                offer.yourPremiumPayCheck = 0M;
                                                offer.YourPremiumPerMonth = 0M;
                                                offer.employerPremiumPerPayCheck = 0M;
                                                offer.employerPremiumPerMonth = Offercheck.SmokerPremiumAmountMonthly ?? 0;
                                                break;
                                            default:
                                                if (enrollmentClassIn != null && enrollmentClassIn.EnrollmentOutputPremiumDisplayType != null && enrollmentClassIn.EnrollmentOutputPremiumDisplayType.Description == "Per Month")
                                                {
                                                    offer.yourPremiumPayCheck = 0;
                                                    offer.YourPremiumPerMonth = Offercheck.SmokerPremiumAmountMonthly ?? 0;
                                                }
                                                else
                                                {
                                                    offer.yourPremiumPayCheck = Offercheck.SmokerPremiumAmountPaycheck ?? 0;
                                                    offer.YourPremiumPerMonth = Offercheck.SmokerPremiumAmountMonthly ?? 0;
                                                }
                                                offer.employerPremiumPerPayCheck = 0M;
                                                offer.employerPremiumPerMonth = 0M;
                                                break;
                                        }
                                    }
                                    else
                                    {
                                        switch (o.payorType)
                                        {
                                            case PayorTypeRestriction.Shared:
                                                if (enrollmentClassIn != null && enrollmentClassIn.EnrollmentOutputPremiumDisplayType != null && enrollmentClassIn.EnrollmentOutputPremiumDisplayType.Description == "Per Month")
                                                {
                                                    offer.yourPremiumPayCheck = 0;
                                                    offer.YourPremiumPerMonth = Offercheck.NonSmokerEmployeePremiumPerMonth ?? 0;
                                                }
                                                else
                                                {
                                                    offer.yourPremiumPayCheck = Offercheck.NonSmokerEmployeePremiumAmountPaycheck ?? 0;
                                                    offer.YourPremiumPerMonth = Offercheck.NonSmokerEmployeePremiumPerMonth ?? 0;
                                                }

                                                offer.employerPremiumPerPayCheck = Offercheck.NonSmokerEmployerPremiumAmountPaycheck ?? 0;
                                                offer.employerPremiumPerMonth = Offercheck.NonSmokerEmployerPremiumPerMonth ?? 0;
                                                break;
                                            case PayorTypeRestriction.Employer:
                                                offer.yourPremiumPayCheck = 0M;
                                                offer.YourPremiumPerMonth = 0M;
                                                offer.employerPremiumPerPayCheck = 0M;
                                                offer.employerPremiumPerMonth = Offercheck.NonSmokerPremiumAmountMonthly ?? 0;
                                                break;
                                            default:
                                                if (enrollmentClassIn != null && enrollmentClassIn.EnrollmentOutputPremiumDisplayType != null && enrollmentClassIn.EnrollmentOutputPremiumDisplayType.Description == "Per Month")
                                                {
                                                    offer.yourPremiumPayCheck = 0;
                                                    offer.YourPremiumPerMonth = Offercheck.NonSmokerPremiumAmountMonthly ?? 0;
                                                }
                                                else
                                                {
                                                    offer.yourPremiumPayCheck = Offercheck.NonSmokerPremiumAmountPaycheck ?? 0;
                                                    offer.YourPremiumPerMonth = Offercheck.NonSmokerPremiumAmountMonthly ?? 0;
                                                }
                                                offer.employerPremiumPerPayCheck = 0M;
                                                offer.employerPremiumPerMonth = 0M;
                                                break;
                                        }
                                    }
                                }
                            }

                            var participantExistingPoliciy = enrollmentParticipant.Participant.ParticipantExistingPolicies.FirstOrDefault();
                            var participantExistingoliciesdetail = new ParticipantExistingPolicyDetail();
                            if (participantExistingPoliciy != null)
                            {
                                participantExistingoliciesdetail =
                                    unitOfWork.Repository<ParticipantExistingPolicyDetail>()
                                        .Linq()
                                        .FirstOrDefault(c => c.ParticipantExistingPolicy.Id == participantExistingPoliciy.Id
                                         && (c.CLOASPolicyStatus != null && c.CLOASPolicyStatus.ToLower() == "inforce"));
                            }

                            if (mldiCase.ExstreamRequestType == "EnrollmentKit")
                            {
                                CreateBenefitSummaryXML(offer, group, enrollmentParticipant, isNewCase, pdrSoldClassPlan, participantExistingoliciesdetail, mldiCase, enrollmentPDRClasss, isCompactState);
                            }

                            if (mldiCase.ExstreamRequestType == "BenefitPremium" || mldiCase.ExstreamRequestType == "EnrollmentTool")
                            {
                                CreateInsurableIncomeXML(offer, group, enrollmentParticipant, pdrSoldClassPlan);
                                CreateBenefitSummaryXML(offer, group, enrollmentParticipant, isNewCase, pdrSoldClassPlan, participantExistingoliciesdetail, mldiCase, enrollmentPDRClasss, isCompactState);
                            }

                            CreateProviderChoicePremiumSummaryXML(offer, group, enrollmentParticipant, enrollmentBillingMode, isNewCase, participant, participantExistingoliciesdetail, cmsCase, mldiCase);
                            if (enrollmentParticipant.Participant.IsAMBIncreaseIndicator != null && enrollmentParticipant.Participant.IsAMBIncreaseIndicator == true)
                            {
                                CreateProviderChoicePremiumSummaryTotalPlusAMB(offer, group, enrollmentParticipant, isNewCase, participant, participantExistingoliciesdetail);
                            }

                            //var ambParticipantsAvailable = sortedParticipants.Where(c => c.offers != null).SelectMany(c => c.offers)
                            //    .Where(c => c.OptionClassType == "AMB").ToList();
                            //if(ambParticipantsAvailable != null)
                            //{
                            //    //offer.ProviderChoicePremiumSummary.TotalPlusAMBModalPremiumAmt = "0.00";
                            //    //offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployeePremiumAmt = "0.00";
                            //    //offer.ProviderChoicePremiumSummary.TotalPlusAMBERPaidModalPremiumAmt = "0.00";
                            //    //offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployerPremiumAmt = "0.00";
                            //}

                            if (mldiCase.ExstreamRequestType == "BenefitPremium" || mldiCase.ExstreamRequestType == "EnrollmentTool")
                            {
                                bool hasAMBPolicy = enrollmentParticipant.Participant.IsAMBIncreaseIndicator == true ? true : false;
                                bool isVGSI = (enrollmentParticipant.Participant.VGSIBuyUpBenefit != null && enrollmentParticipant.Participant.VGSIBuyUpBenefit > 0) || offer.cmsStandardOfferCode.Contains("VGSI");

                                if (hasAMBPolicy && !isVGSI)
                                {
                                    offer.cmsStandardOfferCode = offer.cmsStandardOfferCode.Replace("Option 2", "Option 1");
                                    offer.cmsStandardOfferCode = offer.cmsStandardOfferCode.Replace("Option 3", "Option 1");
                                }

                                CreateParticipantOfferXML(offer, mldiCase, participant, group, pdrS, pdrSoldClassPlan, situsType, enrollmentPDRClasss, participantExistingoliciesdetail, bprequest, enrollmentParticipant);
                            }

                            offer.OptionClassType = null;

                            participant.Offers.Add(offer);
                        }

                        participant.EndofParticipant = "End Of Participant";
                        group.EligibleParticipants.Add(participant);
                    }
                }
                //remove case participants for new.             
                group.eligibleParticipants = null;
                if (mldiCase.BPRequest == null)
                {
                    mldiCase.BPRequest = new List<EnrollmentKitXml.ExtreamGenerationBPOptionXml>();
                }
                bprequest.InsurableIncomeColumnNames = group.InsurableIncomeColumnNames;
                bprequest.GLTDandIDIBenefitSummaryColumnNames = group.GLTDandIDIBenefitSummaryColumnNames;
                bprequest.ProviderChoicePremiumsColumnNames = group.ProviderChoicePremiumsColumnNames;
                mldiCase.BPRequest.Add(bprequest);
                lstMLDIGroup.Add(group);
            }
            mldiCase.groups.Clear();
            mldiCase.groups = null;

            return lstMLDIGroup;
        }

        private static void CreateParticipantOfferXML(EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml offer, EnrollmentKitXml inCase, EnrollmentKitXml.ExtreamGenerationParticipantXml inPart, EnrollmentKitXml.ExtreamGenerationGroup inGroup, PDRSoldClass pdrSoldClass, PDRSoldClassPlan pdrSoldClassPlan, CaseUnderwritingRequest situsType, IEnumerable<EnrollmentPDRClass> enrollmentPDRClasss, ParticipantExistingPolicyDetail existingPolDetails, EnrollmentKitXml.ExtreamGenerationBPOptionXml inBpr, EnrollmentParticipant enrolledParticipant)
        {
            if (inBpr == null)
            {
                inBpr = new EnrollmentKitXml.ExtreamGenerationBPOptionXml();
                inBpr.GLTDandIDIBenefitSummaryColumnNames = inGroup.GLTDandIDIBenefitSummaryColumnNames;
                inBpr.InsurableIncomeColumnNames = inGroup.InsurableIncomeColumnNames;
                inBpr.ProviderChoicePremiumsColumnNames = inGroup.ProviderChoicePremiumsColumnNames;
            }

            if (inBpr.ParticipantOffers == null)
            {
                inBpr.ParticipantOffers = new List<EnrollmentKitXml.ExtreamGenerationParticipantOfferXml>();
            }

            var currentLoadedOffer = inBpr.ParticipantOffers.FirstOrDefault(a => a.cmsStandardOfferCode == offer.cmsStandardOfferCode && a.OptionClassType == offer.OptionClassType);

            var workingParticipant = new EnrollmentKitXml.ExtreamGenerationParticipantInOfferXml();
            var partSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace, };
            var serPart = JsonConvert.SerializeObject(inPart, partSettings);
            workingParticipant = JsonConvert.DeserializeObject<EnrollmentKitXml.ExtreamGenerationParticipantInOfferXml>(serPart);

            //Information Not Required for BNP at Participant Level
            workingParticipant.CurrentLTDs = null;
            workingParticipant.currentLTDs = null;
            workingParticipant.personalInformation.email = null;
            workingParticipant.temporaryPassword = null;
            workingParticipant.occupationDetails.weeklyHoursWorked = null;
            workingParticipant.servicingProducerCmsCode = null;
            workingParticipant.signingProducerCmsCode = null;
            workingParticipant.ContactProducerCmsCode = null;
            workingParticipant.IncomeDetails.TaxBracket = null;
            workingParticipant.IncomeDetails.GLTDTaxBracket = null;
            workingParticipant.PreviousDeclineNumber = null;
            workingParticipant.BasePlanPreviousSolicitations = null;
            bool isVGSI = false;
            if (currentLoadedOffer == null)
            {
                currentLoadedOffer = new EnrollmentKitXml.ExtreamGenerationParticipantOfferXml();
                var offerPart = JsonConvert.SerializeObject(offer, partSettings);
                currentLoadedOffer = JsonConvert.DeserializeObject<EnrollmentKitXml.ExtreamGenerationParticipantOfferXml>(offerPart);

                currentLoadedOffer.gltdCode = workingParticipant.GltdCode;
                currentLoadedOffer.gltdReplacementPercentage = workingParticipant.IncomeDetails.GLTDReplacementPercentage;
                currentLoadedOffer.insIncCode = workingParticipant.IncomeDetails.InsIncCode;
                currentLoadedOffer.ltdMaximum = workingParticipant.LtdMaximum;
                var participantCategoryCode = enrolledParticipant.Participant.ParticipantCategoryCodeType != null ? enrolledParticipant.Participant.ParticipantCategoryCodeType.GetDescription() : string.Empty;
                currentLoadedOffer.ClassName = string.Concat(pdrSoldClass.EligiblePopulationText, " ", participantCategoryCode);
                currentLoadedOffer.TaxType = pdrSoldClassPlan.TaxabilityType != null ? pdrSoldClassPlan.TaxabilityType.GetDescription() : string.Empty;
                if (pdrSoldClass.PDRSoldClassLTDCoverage.Any())
                {
                    var pdrSoldClassLTDCoverage = pdrSoldClass.PDRSoldClassLTDCoverage.FirstOrDefault();
                    if (pdrSoldClassLTDCoverage != null)
                    {
                        currentLoadedOffer.gltdPayorType = pdrSoldClassLTDCoverage.PremiumAndTaxpayerLiabilityType != null ? pdrSoldClass.PDRSoldClassLTDCoverage[0].PremiumAndTaxpayerLiabilityType.Description : string.Empty;
                        currentLoadedOffer.gltdTaxType = pdrSoldClassLTDCoverage.TypeOfPayType != null ? pdrSoldClass.PDRSoldClassLTDCoverage[0].TypeOfPayType.GetDescription() : string.Empty;
                        currentLoadedOffer.gltdReplacementPercentage = pdrSoldClassLTDCoverage.GroupLTDReplacementPercentage.ToString();
                    }
                }

                currentLoadedOffer.PlanDesign = GetSoldPlanDesignDescription(pdrSoldClassPlan);
                currentLoadedOffer.PlanDesignType = pdrSoldClassPlan.PlanDesignType.ToString();
                //currentLoadedOffer.maxGSI = pdrSoldClassPlan.GSIAmount.ToString();


                isVGSI = (enrolledParticipant.Participant.VGSIBuyUpBenefit != null && enrolledParticipant.Participant.VGSIBuyUpBenefit > 0) || offer.cmsStandardOfferCode.Contains("VGSI");

                if (isVGSI)
                {
                    if (offer.cmsStandardOfferCode.Contains("Option 1"))
                    {
                        currentLoadedOffer.maxGSI = pdrSoldClassPlan.GSIAmount.ToString();
                        currentLoadedOffer.ParticipationPercentageRequired = pdrSoldClassPlan.ParticipationPercentage.ToString();
                    }
                    else
                    {
                        if (pdrSoldClassPlan.PDRSoldClass.PDRSoldClassPlan.Count > 1)
                        {
                            currentLoadedOffer.maxGSI = pdrSoldClassPlan.PDRSoldClass.PDRSoldClassPlan[1].GSIAmount.ToString();
                            currentLoadedOffer.ParticipationPercentageRequired = pdrSoldClassPlan.PDRSoldClass.PDRSoldClassPlan[1].ParticipationPercentage.ToString();
                        }
                    }
                }
                else
                {
                    currentLoadedOffer.maxGSI = pdrSoldClassPlan.GSIAmount.ToString();
                    currentLoadedOffer.ParticipationPercentageRequired = pdrSoldClassPlan.ParticipationPercentage.ToString();
                }

                //currentLoadedOffer.benefitPeriodYears = null;
                //if (pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                //{
                //    currentLoadedOffer.benefitPeriodAge = 65;
                //    workingParticipant.BenefitPeriodAge = 65;
                //}
                //else if (pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                //{
                //    currentLoadedOffer.benefitPeriodAge = 67;
                //    workingParticipant.BenefitPeriodAge = 67;
                //}
                //else if (pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                //{
                //    currentLoadedOffer.benefitPeriodAge = 70;
                //    workingParticipant.BenefitPeriodAge = 70;
                //}
                //if (pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.M24)
                //{
                //    currentLoadedOffer.benefitPeriodYears = 2;
                //    workingParticipant.BenefitPeriodYears = 2;
                //}
                //else if (pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.M60)
                //{
                //    currentLoadedOffer.benefitPeriodYears = 5;
                //    workingParticipant.BenefitPeriodYears = 5;
                //}
                //else if (pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                //{
                //    currentLoadedOffer.benefitPeriodYears = 10;
                //    workingParticipant.BenefitPeriodYears = 10;
                //}
                //else if (pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.Y01 || pdrSoldClassPlan.BenefitPeriod == BenefitPeriodTypeEnum.M12)
                //{
                //    currentLoadedOffer.benefitPeriodYears = 1;
                //    workingParticipant.BenefitPeriodYears = 1;
                //}

                workingParticipant.PremiumPaymentPeriod = currentLoadedOffer.paymentMethod != null ? currentLoadedOffer.paymentMethod.GetDescription() : " ";

                if (!string.IsNullOrWhiteSpace(workingParticipant.OverrideIPLimit))
                {
                    List<string> overrideSplit = workingParticipant.OverrideIPLimit.Split('/').ToList();
                    for (var i = 0; i < overrideSplit.Count; i++)
                    {
                        if (!String.IsNullOrEmpty(overrideSplit[i]))
                        {
                            var decimalValue = Convert.ToDecimal(overrideSplit[i]);
                            overrideSplit[i] = decimalValue.ToString("C");
                        }
                    }
                    currentLoadedOffer.MaximumIp = overrideSplit != null && overrideSplit.Count > 1
                        ? string.Join("/", overrideSplit)
                        : string.Empty;
                }
                else
                {
                    currentLoadedOffer.MaximumIp = GetMaximumIPDescription(pdrSoldClassPlan);
                }

                //currentLoadedOffer.ParticipationPercentageRequired = pdrSoldClassPlan.ParticipationPercentage.ToString();

                currentLoadedOffer.CorporateSitus = situsType.SitusType.ToString();
                workingParticipant.OverrideIPLimit = null;

                if (currentLoadedOffer.ParticipantsInOffer == null)
                {
                    currentLoadedOffer.ParticipantsInOffer = new List<EnrollmentKitXml.ExtreamGenerationParticipantInOfferXml>();
                }

                workingParticipant.Offers = new List<EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml>();
                workingParticipant.Offers.Add(offer);
                currentLoadedOffer.ParticipantsInOffer.Add(workingParticipant);

                var currentRiders = currentLoadedOffer.riders.ToList();
                var enrollmentPdrClass = enrollmentPDRClasss.FirstOrDefault();
                if (enrollmentPdrClass != null)
                {
                    var enrollmentOptions = enrollmentPdrClass.EnrollmentPDRClassOptions.FirstOrDefault(a => a.StandardOptionCodeNonSmoker == currentLoadedOffer.cmsStandardOfferCode || a.StandardOptionCodeSmoker == currentLoadedOffer.cmsStandardOfferCode);
                    if (enrollmentOptions != null)
                    {
                        var enrollmentPdrClassOptionPlan = enrollmentOptions.EnrollmentPDRClassOptionPlans.FirstOrDefault();
                        if (enrollmentPdrClassOptionPlan != null)
                        {
                            var enrollmentRiders = enrollmentPdrClassOptionPlan.EnrollmentPDRClassOptionPlanRiders.ToList();

                            foreach (var x in currentRiders)
                            {
                                RiderSettings(x, enrollmentRiders);
                            }
                        }
                    }
                }

                currentLoadedOffer.riders = currentRiders;

                inBpr.ParticipantOffers.Add(currentLoadedOffer);

                //To order the Options - MCRT-1791
                if (inBpr.ParticipantOffers.Any())
                {
                    inBpr.ParticipantOffers = inBpr.ParticipantOffers.Where(c => !string.IsNullOrWhiteSpace(c.cmsStandardOfferCode))
                        .OrderBy(c => c.cmsStandardOfferCode.Substring(c.cmsStandardOfferCode.Length - 1)).ToList();
                }
            }
            else
            {
                workingParticipant.OverrideIPLimit = null;
                workingParticipant.Offers = new List<EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml>();
                workingParticipant.Offers.Add(offer);
                //Check to ensure riders in main option.
                foreach (var r in offer.riders)
                {
                    var riderFound = currentLoadedOffer.riders.Any(a => a.riderIdentifier == r.riderIdentifier);
                    if (!riderFound)
                    {
                        var enrollmentPdrClass = enrollmentPDRClasss.FirstOrDefault();
                        if (enrollmentPdrClass != null)
                        {
                            var enrollmentOptions = enrollmentPdrClass.EnrollmentPDRClassOptions.FirstOrDefault(a => a.StandardOptionCodeNonSmoker == currentLoadedOffer.cmsStandardOfferCode || a.StandardOptionCodeSmoker == currentLoadedOffer.cmsStandardOfferCode);
                            if (enrollmentOptions != null)
                            {
                                var enrollmentPdrClassOptionPlan = enrollmentOptions.EnrollmentPDRClassOptionPlans.FirstOrDefault();
                                if (enrollmentPdrClassOptionPlan != null)
                                {
                                    var enrollmentRiders =
                                        enrollmentPdrClassOptionPlan
                                            .EnrollmentPDRClassOptionPlanRiders.ToList();

                                    var additionalRider = r;
                                    RiderSettings(additionalRider, enrollmentRiders);
                                    currentLoadedOffer.riders.Add(additionalRider);
                                }
                            }
                        }
                    }
                }

                var extreamGenerationParticipantOfferXml = inBpr.ParticipantOffers.FirstOrDefault(a => a.cmsStandardOfferCode == offer.cmsStandardOfferCode && a.OptionClassType == offer.OptionClassType);
                if (extreamGenerationParticipantOfferXml != null)
                    extreamGenerationParticipantOfferXml.ParticipantsInOffer.Add(workingParticipant);
            }

            CreateTotalProviderChoicePremiumSummaryXML(currentLoadedOffer, workingParticipant, offer);
            CreateTotalBenefitSummaryXML(currentLoadedOffer, offer, inCase);
            CreateTotalInsurableIncomeXML(currentLoadedOffer, offer);
        }

        private static bool CheckTermRiderAvailable(IEnumerable<EnrollmentPDRClass> enrollmentPDRClasss, string standardofferCode, string riderIdentifier)
        {
            bool isExist = false;

            var enrollmentPdrClass = enrollmentPDRClasss.FirstOrDefault();
            if (enrollmentPdrClass != null)
            {
                var enrollmentOptions = enrollmentPdrClass.EnrollmentPDRClassOptions.FirstOrDefault(a => a.StandardOptionCodeNonSmoker == standardofferCode || a.StandardOptionCodeSmoker == standardofferCode);
                if (enrollmentOptions != null)
                {
                    var enrollmentPdrClassOptionPlan = enrollmentOptions.EnrollmentPDRClassOptionPlans.FirstOrDefault();
                    if (enrollmentPdrClassOptionPlan != null)
                    {
                        var enrollmentRiders = enrollmentPdrClassOptionPlan.EnrollmentPDRClassOptionPlanRiders.ToList();

                        BenefitTypeEnum? benefitType = null;
                        if (riderIdentifier == "SLP")
                        {
                            benefitType = BenefitTypeEnum.StudentLoanProtection;
                        }
                        else if (riderIdentifier == "SBT")
                        {
                            benefitType = BenefitTypeEnum.SupplementalBenefitTermRider;
                        }
                        else if (riderIdentifier == "RPP")
                        {
                            benefitType = BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit;
                        }
                        else if (riderIdentifier == "CAT16e")
                        {
                            benefitType = BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider;
                        }
                        else if (riderIdentifier == "CAT16b" || riderIdentifier == "SevereDisability")
                        {
                            benefitType = BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider;
                        }
                        var isAvaialable = enrollmentRiders.Any(c => c.BenefitType == benefitType);
                        if (isAvaialable)
                        {
                            isExist = true;
                        }
                    }
                }
            }
            return isExist;
        }
        private static void RiderSettings(MLDIQualifiedRider x, IList<EnrollmentPDRClassOptionPlanRider> optionRider)
        {
            var benefit = new EnrollmentPDRClassOptionPlanRider();
            switch (x.riderIdentifier)
            {
                case "SevereDisability":
                case "CAT16b":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider);
                    SetRiderValues(x, benefit);
                    break;
                case "CAT16e":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.EnhancedCatastrophicDisabilityBenefitRider);
                    SetRiderValues(x, benefit);
                    break;
                case "RPP":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.RetirementProtectionPlusDisabilityBenefit);
                    SetRiderValues(x, benefit);
                    break;
                case "EnhancedRes":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.EnhancedResidualDisability);
                    SetRiderValues(x, benefit);
                    break;
                case "BasicRes":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.BasicResidualDisability);
                    SetRiderValues(x, benefit);
                    break;
                case "ShortTermRes":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.ShortTermResidualDisabilityBenefitRider);
                    SetRiderValues(x, benefit);
                    break;
                case "COLA-6":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.CostOfLiving6PercentMaximum);
                    SetRiderValues(x, benefit);
                    break;
                case "COLA-3":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.CostOfLiving3PercentMaximum);
                    SetRiderValues(x, benefit);
                    break;
                case "COLA-4Yr":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.CostOfLiving4YearDelayed);
                    SetRiderValues(x, benefit);
                    break;
                case "UnempWaiver":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.UnemploymentPremiumWaiver);
                    SetRiderValues(x, benefit);
                    break;
                case "SIS":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.SeriousIllnessSupplementalBenefitEndorsement);
                    SetRiderValues(x, benefit);
                    break;
                case "LSDB":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.LumpSumIndemnityRider);
                    SetRiderValues(x, benefit);
                    break;
                case "BasicPart":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.BasicPartialDisabilityRider);
                    SetRiderValues(x, benefit);
                    break;
                case "EnhancedPart":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.EnhancedPartialDisabilityRider);
                    SetRiderValues(x, benefit);
                    break;
                case "SLP":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.StudentLoanProtection);
                    SetRiderValues(x, benefit);
                    break;
                case "SBT":
                    benefit =
                        optionRider.FirstOrDefault(
                            a => a.BenefitType == BenefitTypeEnum.SupplementalBenefitTermRider);
                    SetRiderValues(x, benefit);
                    break;
            }
        }

        private static void SetRiderValues(MLDIQualifiedRider x, EnrollmentPDRClassOptionPlanRider benefit)
        {
            x.annualPremium = null;
            x.monthlyPremium = null;
            if (benefit != null && benefit.Amount != null)
            {
                x.monthlyBenefit = benefit.Amount;
            }

            if (benefit != null && benefit.BenefitPeriodType != null)
            {
                if (benefit.BenefitPeriodType == BenefitPeriodTypeEnum.A65)
                {

                    x.benefitPeriodAge = 65;
                }
                else if (benefit.BenefitPeriodType == BenefitPeriodTypeEnum.A67)
                {
                    x.benefitPeriodAge = 67;
                }
                else if (benefit.BenefitPeriodType == BenefitPeriodTypeEnum.V70)
                {
                    x.benefitPeriodAge = 70;
                }
                else if (benefit.BenefitPeriodType == BenefitPeriodTypeEnum.Y02 || benefit.BenefitPeriodType == BenefitPeriodTypeEnum.M24)
                {
                    x.benefitPeriodYears = 2;

                }
                else if (benefit.BenefitPeriodType == BenefitPeriodTypeEnum.Y05 || benefit.BenefitPeriodType == BenefitPeriodTypeEnum.M60)
                {
                    x.benefitPeriodYears = 5;
                }
                else if (benefit.BenefitPeriodType == BenefitPeriodTypeEnum.Y10)
                {
                    x.benefitPeriodYears = 10;
                }
                else if (benefit.BenefitPeriodType == BenefitPeriodTypeEnum.Y15)
                {
                    x.benefitPeriodYears = 15;
                }
            }

            if (benefit != null && benefit.EliminationPeriodType != null)
            {
                if (benefit.EliminationPeriodType == EliminationPeriodTypeEnum._180)
                {
                    x.eliminationPeriod = 180;
                }
                else if (benefit.EliminationPeriodType == EliminationPeriodTypeEnum._360)
                {
                    x.eliminationPeriod = 360;
                }
                else if (benefit.EliminationPeriodType == EliminationPeriodTypeEnum._720)
                {
                    x.eliminationPeriod = 720;
                }
                else if (benefit.EliminationPeriodType == EliminationPeriodTypeEnum._090)
                {
                    x.eliminationPeriod = 90;
                }
            }
        }

        private static void CreateInsurableIncomeXML(EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml offer, EnrollmentKitXml.ExtreamGenerationGroup inGroup, EnrollmentParticipant inPart, PDRSoldClassPlan pdrSoldClassPlan)
        {
            offer.InsurableIncomes = new TotalInsurableIncomes();
            if (inGroup.InsurableIncomeColumnNames == null)
            {
                inGroup.InsurableIncomeColumnNames = new InsurableIncomeColumnNames();
            }

            if (inPart != null && inPart.Participant != null)
            {
                if ((inPart.Participant.VGSIBuyUpBenefit != null && inPart.Participant.VGSIBuyUpBenefit > 0) ||
                    (inPart.Participant.VGSIBuyUpIDIInsurableIncomeCalculatedAmount != null && inPart.Participant.VGSIBuyUpIDIInsurableIncomeCalculatedAmount > 0))
                {
                    offer.InsurableIncomes.TotalERPaidGSIBaseAmt =
                        inPart.Participant.IDIInsurableIncomeCalculatedAmount.ToString();
                    if (!string.IsNullOrEmpty(offer.InsurableIncomes.TotalERPaidGSIBaseAmt))
                    {
                        inGroup.InsurableIncomeColumnNames.ERPaidGSIBase = "ER Paid GSI Base";
                    }

                    offer.InsurableIncomes.TotalVGSIBuyUpAmt =
                        inPart.Participant.VGSIBuyUpIDIInsurableIncomeCalculatedAmount.ToString();
                    if (!string.IsNullOrEmpty(offer.InsurableIncomes.TotalVGSIBuyUpAmt))
                    {
                        inGroup.InsurableIncomeColumnNames.VGSIBuyUp = "VGSI Buy Up";
                    }
                }
                else
                {
                    var enrollmentOptionPlan = inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode || c.StandardOptionCodeSmoker == offer.cmsStandardOfferCode);
                    if (enrollmentOptionPlan != null)
                    {
                        if (enrollmentOptionPlan.PlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan)
                        {
                            if (pdrSoldClassPlan.CoveredEarningsType == CoveredEarningsTypeEnum.W_2Income)
                            {
                                offer.InsurableIncomes.TotalW2IncomeAmt = inPart.Participant.MostRecentYearPaidW2Income != null ? inPart.Participant.MostRecentYearPaidW2Income.ToString() : "0.0";
                                if (!string.IsNullOrEmpty(offer.InsurableIncomes.TotalW2IncomeAmt))
                                {
                                    inGroup.InsurableIncomeColumnNames.W2Income = "W2 Income";
                                }
                            }
                            else
                            {
                                offer.InsurableIncomes.TotalSalaryAmt = inPart.Participant.MostRecentSalaryAmount.ToString();
                                if (!string.IsNullOrEmpty(offer.InsurableIncomes.TotalSalaryAmt))
                                {
                                    inGroup.InsurableIncomeColumnNames.Salary = "Salary";
                                }


                                if (enrollmentOptionPlan != null)
                                {
                                    var selectedCoveredEarning = enrollmentOptionPlan.CoveredEarningsType;
                                    var selectedCoveredEarningBonusOnly = enrollmentOptionPlan.CoveredEarningsBonusOnlyType;

                                    if ((selectedCoveredEarning != null && selectedCoveredEarning != CoveredEarningsTypeEnum.BaseSalaryOnly) || selectedCoveredEarningBonusOnly != null)
                                    {
                                        var toatalAmount = inPart.Participant.IDIInsurableIncomeCalculatedAmount ?? 0;
                                        var currentsalary = inPart.Participant.MostRecentSalaryAmount ?? 0;
                                        decimal? otherIncome = toatalAmount - currentsalary;
                                        offer.InsurableIncomes.TotalOtherIncomeAmt = otherIncome.ToString();
                                        if (!string.IsNullOrEmpty(offer.InsurableIncomes.TotalOtherIncomeAmt))
                                        {
                                            inGroup.InsurableIncomeColumnNames.OtherIncome = "Other";
                                        }
                                    }

                                }

                                offer.InsurableIncomes.GrandTotalAmt =
                                    inPart.Participant.IDIInsurableIncomeCalculatedAmount.ToString();
                                if (!string.IsNullOrEmpty(offer.InsurableIncomes.GrandTotalAmt))
                                {
                                    inGroup.InsurableIncomeColumnNames.Total = "Total";
                                }
                            }
                        }
                    }

                }
            }
        }

        private static void CreateBenefitSummaryXML(EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml offer, EnrollmentKitXml.ExtreamGenerationGroup inGroup, EnrollmentParticipant inPart, bool isNewCase, PDRSoldClassPlan pdrSoldClassPlan, ParticipantExistingPolicyDetail participantExistingoliciesdetail, EnrollmentKitXml mldiCase, IEnumerable<EnrollmentPDRClass> enrollmentPDRClasss, bool isCompactState)
        {
            //bool isAMBPolicy = participantExistingoliciesdetail.ParticipantExistingPolicy != null ? participantExistingoliciesdetail.ParticipantExistingPolicy.Participant.ParticipantCategoryCodeType == ParticipantCategoryCodeTypeEnum.AMB ? true : false : false;

            offer.GLTDandIDIBenefitSummary = new EnrollmentKitXml.ExtreamGenerationGLTDandIDIBenefitBenefitSummaries();

            if (inGroup.GLTDandIDIBenefitSummaryColumnNames == null)
            {
                inGroup.GLTDandIDIBenefitSummaryColumnNames = new EnrollmentKitXml.ExstreamGenerationGLTDandIDIBenefitSummaryColumnNames();
            }

            if (inGroup.ProviderChoicePremiumsColumnNames == null)
            {
                inGroup.ProviderChoicePremiumsColumnNames = new EnrollmentKitXml.ExstreamGenerationProviderChoicePremiumColumnNames();
            }

            bool isVGSI = false;
            bool isStandAlone = false;
            bool isReverseCombo = false;
            bool isRPPBnP = false;
            bool isSuppBnp = false;
            bool hasEnhancedCat = false;
            bool hasBasicCat = false;
            bool hasAmbPolicy = false;
            bool hasBuyUpAmbPolicy = false;

            if (inPart != null && inPart.Participant != null)
            {

                isVGSI = (inPart.Participant.VGSIBuyUpBenefit != null && inPart.Participant.VGSIBuyUpBenefit > 0) || offer.cmsStandardOfferCode.Contains("VGSI");
                isStandAlone = pdrSoldClassPlan.PlanDesignType == PlanDesignTypeEnum.StandAloneIDIPlan || inPart.Participant.PlanDesignRequestClass.ApprovedPlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan;
                isReverseCombo = pdrSoldClassPlan.PlanDesignType == PlanDesignTypeEnum.ReverseCombinationPlan;
                isRPPBnP = pdrSoldClassPlan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan;
                isSuppBnp = pdrSoldClassPlan.PlanDesignType == PlanDesignTypeEnum.SupplementalPlan;
                hasEnhancedCat = offer.riders.Any(a => a.riderIdentifier == "CAT16e");
                hasBasicCat = offer.riders.Any(a => a.riderIdentifier == "CAT16b" || a.riderIdentifier == "SevereDisability");
                hasAmbPolicy = inPart.Participant.IsAMBIncreaseIndicator == true ? true : false;
                hasBuyUpAmbPolicy = inPart.Participant.IsBuyUpAMBIncreaseIndicator == true ? true : false;

                if (hasAmbPolicy)
                {
                    if (participantExistingoliciesdetail != null)
                    {
                        isCompactState = participantExistingoliciesdetail.IsCompactState != null ? participantExistingoliciesdetail.IsCompactState.Value : false;
                    }
                    else
                    {
                        isCompactState = false;
                    }
                }

                if (isRPPBnP)
                {
                    var totEmp = inPart.Participant.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount;

                    if (totEmp != null && totEmp != 0)
                    {
                        offer.GLTDandIDIBenefitSummary.AnnualRetirementContributionsAmt = totEmp.ToString();
                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.AnnualRetirementContributionsAmt))
                        {
                            inGroup.GLTDandIDIBenefitSummaryColumnNames.AnnualRetirementContributions =
                                "Annual Retirement Contributions";
                        }
                    }
                }

                if (isRPPBnP && !isNewCase)
                {
                    var existingRPPCoverage = participantExistingoliciesdetail != null ? participantExistingoliciesdetail.MonthlyIndemnity : 0;
                    if (existingRPPCoverage != null)
                    {
                        offer.GLTDandIDIBenefitSummary.ExistingRppProgramCoverageAmt = existingRPPCoverage.ToString();
                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingRppProgramCoverageAmt))
                        {
                            inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingRppProgramCoverage = "Existing RPP Program Coverage";
                        }
                    }
                }

                if (isRPPBnP)
                {
                    offer.GLTDandIDIBenefitSummary.RppBaseBenefitAmt = inPart.Participant.RPPBenefitCalculatedAmount != null ? inPart.Participant.RPPBenefitCalculatedAmount.ToString() : null;
                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.RppBaseBenefitAmt))
                    {
                        inGroup.GLTDandIDIBenefitSummaryColumnNames.RppBaseBenefit = "RPP Monthly Benefit";
                    }
                }

                if (isRPPBnP && hasAmbPolicy)
                {
                    offer.GLTDandIDIBenefitSummary.ProposedRppAmbBenefitAmt = inPart.Participant.RPPAMBCalculatedAmount != null ? inPart.Participant.RPPAMBCalculatedAmount.ToString() : null;
                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ProposedRppAmbBenefitAmt))
                    {
                        inGroup.GLTDandIDIBenefitSummaryColumnNames.ProposedRppAmbBenefit =
                            "Proposed RPP AMB Benefit";
                    }

                }



                if (isRPPBnP)
                {
                    decimal? rppReplacementPercent = CalculateRPPReplacementPercentage(inPart);
                    offer.GLTDandIDIBenefitSummary.RppReplacePercentAmt = DecimaltoPercentage(rppReplacementPercent.ToString());
                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.RppReplacePercentAmt))
                    {
                        inGroup.GLTDandIDIBenefitSummaryColumnNames.RppReplacePercent = "RPP Replacement %";
                    }
                }


                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp)
                {
                    var totGltd = inPart.Participant.GLTDBenefitCalculatedAmount;

                    if (totGltd != null && totGltd != 0)
                    {

                        offer.GLTDandIDIBenefitSummary.GLTDBenefitAmt = totGltd.ToString();
                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.GLTDBenefitAmt))
                        {
                            inGroup.GLTDandIDIBenefitSummaryColumnNames.GLTDBenefit = "GLTD Benefit";
                        }
                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp)
                {

                    if (inPart.EnrollmentParticipantOptionPlans != null && inPart.EnrollmentParticipantOptionPlans.FirstOrDefault() != null)
                    {
                        var totGltd = inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.StandardOptionCodeSmoker == offer.cmsStandardOfferCode || c.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode);

                        if (totGltd.GLTDReplacementCalculatedPercentage != null && totGltd.GLTDReplacementCalculatedPercentage > 0)
                        {
                            offer.GLTDandIDIBenefitSummary.GLTDReplacePercentAmt = DecimaltoPercentage(totGltd.GLTDReplacementCalculatedPercentage.ToString());
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.GLTDBenefitAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.GLTDReplacePercent = "GLTD Replace %";
                            }

                        }
                    }

                }

                if (offer.CostSharing || isReverseCombo || isSuppBnp)
                {                    
                    bool? IsVGSIClass = inPart?.Participant?.PlanDesignRequestClass?.PlanDesignRequestClassProducts?.Any(x => x.IsGSIPlanIndicator == true);
                    if (IsVGSIClass == false)
                    {
                        if (!isNewCase && hasAmbPolicy)
                        {                           
                            offer.GLTDandIDIBenefitSummary.ExistingGSIBaseBenefitAmt = inPart.Participant.ParticipantExistingPolicies.Select(a => a.GSIIDIBaseAMB).FirstOrDefault()?.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingGSIBaseBenefitAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingGSIBaseBenefit =
                                    "Existing GSI Program Coverage";
                            }
                        }
                    }
                }

                if (isVGSI && !isNewCase && hasAmbPolicy)
                {                   
                    offer.GLTDandIDIBenefitSummary.ExistingERPaidGSIBaseBenefitAmt = inPart.Participant.ParticipantExistingPolicies.Select(a => a.GSIIDIBaseAMB).FirstOrDefault()?.ToString();
                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingERPaidGSIBaseBenefitAmt))
                        {
                            inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingERPaidGSIBaseBenefit =
                                "Existing ER Paid GSI Program Coverage";
                        }                  
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp)
                {
                    if (inPart.Participant.ExistingIDICalculatedAmount != null)
                    {
                        offer.GLTDandIDIBenefitSummary.ExistingIDICoverageAmt =
                            inPart.Participant.ExistingIDICalculatedAmount.ToString();
                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingIDICoverageAmt))
                        {
                            inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingIDICoverage = "Existing IDI Coverage"; // need to shown from the beginning
                        }
                    }
                }

                if (offer.CostSharing || isReverseCombo || isSuppBnp || isStandAlone)
                {
                    if (!isRPPBnP)
                    {
                        if (inPart.Participant.GSIBaseCalculatedAmount != 0 &&
                            inPart.Participant.GSIBaseCalculatedAmount != null &&
                            !isVGSI)
                        {
                            offer.GLTDandIDIBenefitSummary.GSIBaseBenefitAmt = offer.baseMonthlyBenefit.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.GSIBaseBenefitAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.GSIBaseBenefit = "GSI Base Benefit";
                            }
                        }
                    }
                }

                if (isVGSI)
                {
                    if (offer.baseMonthlyBenefit != 0)
                    {
                        var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                        if (isOption1)
                        {
                            offer.GLTDandIDIBenefitSummary.ERPaidGSIBaseBenefitAmt = offer.baseMonthlyBenefit.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ERPaidGSIBaseBenefitAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.ERPaidGSIBaseBenefit =
                                    "ER Paid GSI Base Benefit";
                            }
                        }
                        if (!isOption1 && mldiCase.ExstreamRequestType == "BenefitPremium" || mldiCase.ExstreamRequestType == "EnrollmentTool")
                        {
                            offer.GLTDandIDIBenefitSummary.VolGSIBaseBenefitAmt = offer.baseMonthlyBenefit.ToString();

                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.VolGSIBaseBenefitAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.VolGSIBaseBenefit = "VOL GSI Base Benefit";
                            }
                        }
                    }
                }


                if (isVGSI && !isNewCase)
                {
                    var participantExistingPolicyDetails = inPart.Participant.ParticipantExistingPolicies.Where(p => p.Participant.Id == inPart.Participant.Id).Select(q => q.ParticipantExistingPolicyDetails);
                    if (participantExistingPolicyDetails.Any())
                    {
                        decimal? existingVGSIBuyUpProgramCoverage = participantExistingPolicyDetails.FirstOrDefault().FirstOrDefault(i => i.PremiumPayer == "Employee")?.MonthlyIndemnity;

                        if (existingVGSIBuyUpProgramCoverage != null)
                        {
                            offer.GLTDandIDIBenefitSummary.ExistingVGSIBuyUpProgramCoverageAmt = existingVGSIBuyUpProgramCoverage.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingVGSIBuyUpProgramCoverageAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingVGSIBuyUpProgramCoverage = "Existing VGSI Buy Up Program Coverage";
                            }
                        }
                    }
                }

                if (isVGSI && (hasBuyUpAmbPolicy || hasAmbPolicy))
                {
                    var enrollmentBaseParticipantOptionPlan = inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);

                    if (offer.cmsStandardOfferCode.Contains("Option 1"))
                    {
                        if (hasAmbPolicy)
                        {
                            
                            offer.GLTDandIDIBenefitSummary.ProposedERPaidAMBRiderAmt = enrollmentBaseParticipantOptionPlan?.AMBCalculatedAmount?.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ERPaidGSIBaseBenefitAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.ERPaidGSIBaseBenefit =
                                    "ER Paid GSI Base Benefit";
                            }
                        }
                    }

                    if (offer.cmsStandardOfferCode.Contains("Option 2") || offer.cmsStandardOfferCode.Contains("Option 3"))
                    {
                        if (hasBuyUpAmbPolicy)
                        {
                            var enrollmentVgsiParticipantOptionPlan = inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                            if (enrollmentVgsiParticipantOptionPlan != null)
                            {
                                offer.GLTDandIDIBenefitSummary.ProposedVGSIBuyUpAMBRiderAmt = enrollmentVgsiParticipantOptionPlan?.AMBCalculatedAmount?.ToString();
                            }

                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ProposedVGSIBuyUpAMBRiderAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.ProposedVGSIBuyUpAMBRider =
                                    "Proposed VGSI Buy Up AMB Rider";
                            }

                            
                            offer.GLTDandIDIBenefitSummary.ERPaidGSIBaseBenefitAmt = enrollmentBaseParticipantOptionPlan?.BenefitAmountBaseMonthly?.ToString();
                            offer.GLTDandIDIBenefitSummary.ProposedERPaidAMBRiderAmt = enrollmentBaseParticipantOptionPlan?.AMBCalculatedAmount?.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ERPaidGSIBaseBenefitAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.ERPaidGSIBaseBenefit =
                                    "ER Paid GSI Base Benefit";
                            }
                        }
                    }                   

                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ProposedERPaidAMBRiderAmt))
                    {
                        inGroup.GLTDandIDIBenefitSummaryColumnNames.ProposedERPaidAMBRider =
                            "Proposed ER Paid AMB Rider";
                    }                    

                    if (!offer.cmsStandardOfferCode.Contains("Option 1"))
                    {
                        if (String.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ProposedERPaidAMBRiderAmt))
                        {
                            offer.GLTDandIDIBenefitSummary.ProposedERPaidAMBRiderAmt = "0.00";
                        }

                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ProposedERPaidAMBRiderAmt))
                        {
                            inGroup.GLTDandIDIBenefitSummaryColumnNames.ProposedERPaidAMBRider =
                                "Proposed ER Paid AMB Rider";
                        }
                                               
                    }
                    else
                    {
                        offer.GLTDandIDIBenefitSummary.ProposedVGSIBuyUpAMBRiderAmt = null;
                    }
                }

                if (hasAmbPolicy)
                {
                    if (isRPPBnP)
                    {
                        if (inPart.Participant.RPPAMBCalculatedAmount != null &&
                                inPart.Participant.RPPAMBCalculatedAmount != 0.0m)
                        {
                            offer.GLTDandIDIBenefitSummary.ProposedAMBRiderAmt = inPart.Participant.RPPAMBCalculatedAmount.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ProposedAMBRiderAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.ProposedAMBRider = "Proposed AMB Rider";
                            }
                        }
                    }
                    else if (!isVGSI)
                    {
                        if (inPart.Participant.BaseAMBCalculatedAmount != null &&
                            inPart.Participant.BaseAMBCalculatedAmount != 0.0m)
                        {
                            offer.GLTDandIDIBenefitSummary.ProposedAMBRiderAmt = inPart.Participant.BaseAMBCalculatedAmount.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ProposedAMBRiderAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.ProposedAMBRider = "Proposed AMB Rider";
                            }
                        }
                    }
                }

                if (offer.CostSharing || isReverseCombo || isSuppBnp)
                {
                    bool? IsVGSIClass = inPart?.Participant?.PlanDesignRequestClass?.PlanDesignRequestClassProducts?.Any(x => x.IsGSIPlanIndicator == true);
                    if (IsVGSIClass == false)
                    {
                        if (inPart.EnrollmentParticipantOptionPlans != null && inPart.EnrollmentParticipantOptionPlans.FirstOrDefault() != null)
                        {
                            var totGltd = inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.StandardOptionCodeSmoker == offer.cmsStandardOfferCode || c.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode);

                            if (totGltd.IDIBaseReplacementCalculatedPercentage != null && totGltd.IDIBaseReplacementCalculatedPercentage > 0)
                            {
                                offer.GLTDandIDIBenefitSummary.IDIBaseReplacePercentAmt = DecimaltoPercentage(totGltd.IDIBaseReplacementCalculatedPercentage.ToString());
                                if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.IDIBaseReplacePercentAmt))
                                {
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.IDIBaseReplacePercent = "IDI Base Replace %";
                                }

                            }
                        }
                    }

                }

                if (isStandAlone)
                {
                    if (!isRPPBnP)
                    {
                        if (inPart.Participant.TotalGLTDPlusIDICalculatedAmount != 0 &&
                            inPart.Participant.TotalGLTDPlusIDICalculatedAmount != null)
                        {
                            offer.GLTDandIDIBenefitSummary.TotalIDIAmt = inPart.Participant.TotalGLTDPlusIDICalculatedAmount.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.TotalIDIAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.TotalIDI = "Total IDI";
                            }

                        }
                    }

                }

                if (isStandAlone)
                {
                    if (!isRPPBnP)
                    {
                        if (inPart.EnrollmentParticipantOptionPlans != null &&
                            inPart.EnrollmentParticipantOptionPlans.FirstOrDefault() != null)
                        {
                            var totGltd =
                                inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(
                                    c =>
                                        c.StandardOptionCodeSmoker == offer.cmsStandardOfferCode ||
                                        c.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode);

                            if (totGltd.TotalGLTDPlusIDICalculatedPercentage != null &&
                                totGltd.TotalGLTDPlusIDICalculatedPercentage > 0)
                            {
                                offer.GLTDandIDIBenefitSummary.TotalIDIPercentAmt =
                                    DecimaltoPercentage(totGltd.TotalGLTDPlusIDICalculatedPercentage.ToString());
                                if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.TotalIDIPercentAmt))
                                {
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.TotalIDIPercent = "Total IDI %";
                                }

                            }
                        }
                    }
                }
                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp)
                {
                    if (inPart.EnrollmentParticipantOptionPlans != null &&
                        inPart.EnrollmentParticipantOptionPlans.FirstOrDefault() != null)
                    {
                        var totlPlusIDI = inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.StandardOptionCodeSmoker == offer.cmsStandardOfferCode || c.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode);

                        if (totlPlusIDI.TotalGLTDPlusIDICalculatedAmount != null && totlPlusIDI.TotalGLTDPlusIDICalculatedAmount > 0)
                        {
                            offer.GLTDandIDIBenefitSummary.TotalGLTDPlusIDIAmt = totlPlusIDI.TotalGLTDPlusIDICalculatedAmount.ToString();
                            inPart.Participant.TotalGLTDPlusIDICalculatedAmount.ToString();
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.TotalGLTDPlusIDIAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.TotalGLTDPlusIDI = "Total GLTD plus IDI";
                            }
                        }
                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp)
                {
                    if (inPart.EnrollmentParticipantOptionPlans != null && inPart.EnrollmentParticipantOptionPlans.FirstOrDefault() != null)
                    {
                        var totGltd = inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(c => c.StandardOptionCodeSmoker == offer.cmsStandardOfferCode || c.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode);
                        if (totGltd.TotalGLTDPlusIDICalculatedPercentage != null && totGltd.TotalGLTDPlusIDICalculatedPercentage > 0)
                        {
                            offer.GLTDandIDIBenefitSummary.TotalGLTDPlusIDIPercentAmt = DecimaltoPercentage(totGltd.TotalGLTDPlusIDICalculatedPercentage.ToString());
                            if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.TotalGLTDPlusIDIPercentAmt))
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.TotalGLTDPlusIDIPercent = "Total GLTD plus IDI %";
                            }

                        }
                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp)
                {
                    if (hasBasicCat && !isNewCase)
                    {
                        var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                        var participantExistingPolicyDetails = inPart?.Participant?.ParticipantExistingPolicies?.Where(p => p.Participant?.Id == inPart?.Participant?.Id).Select(q => q.ParticipantExistingPolicyDetails)?.FirstOrDefault();
                        var existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employer") : null;
                        if (!isOption1)
                        {
                            existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employee") : null;
                        }
                        if (existingPolicyDetails != null)
                        {
                            var existingCATCoverage = existingPolicyDetails.ParticipantExistingPolicyRiders?.FirstOrDefault(
                                a => a.RiderName.Contains("CAT") && a.RiderValueDescription != "Not Included");

                            if (existingCATCoverage != null)
                            {
                                if (existingCATCoverage.Amount != null)
                                {
                                    offer.GLTDandIDIBenefitSummary.ExistingBasicCATAmt = existingCATCoverage.Amount.ToString();
                                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingBasicCATAmt))
                                    {
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingBasicCAT =
                                            "Existing Basic CAT Coverage";
                                    }
                                }
                            }
                        }



                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp || isStandAlone)
                {
                    var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                    if (hasBasicCat)
                    {
                        var basicCatRider = offer.riders.FirstOrDefault(a => a.riderIdentifier == "CAT16b" || a.riderIdentifier == "SevereDisability");
                        var erCatAmt = 0M;
                        if (basicCatRider != null)
                        {
                            erCatAmt = (decimal)basicCatRider.monthlyBenefit;
                        }

                        offer.GLTDandIDIBenefitSummary.BasicCATAmt = erCatAmt != 0 ? erCatAmt.ToString() : null;
                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.BasicCATAmt))
                        {
                            if (isCompactState)
                            {
                                if (isOption1)
                                {
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.BasicCAT = "Severe Disability";
                                }
                                else
                                {
                                    if (!isVGSI)
                                    {
                                        offer.GLTDandIDIBenefitSummary.BasicCATAmt = erCatAmt != 0 ? erCatAmt.ToString() : null;
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.BasicCAT = "Severe Disability";
                                    }
                                    else
                                    {
                                        offer.GLTDandIDIBenefitSummary.VGSIBasicCATAmt = erCatAmt != 0 ? erCatAmt.ToString() : null;
                                        offer.GLTDandIDIBenefitSummary.BasicCATAmt = "0.0";
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSIBasicCAT = "VGSI Buy Up Severe Disability";
                                    }
                                }
                            }
                            else
                            {
                                if (isOption1)
                                {
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.BasicCAT = "Basic CAT Benefit";
                                }
                                else
                                {
                                    if (!isVGSI)
                                    {
                                        offer.GLTDandIDIBenefitSummary.BasicCATAmt = erCatAmt != 0 ? erCatAmt.ToString() : null;
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.BasicCAT = "Basic CAT Benefit";
                                    }
                                    else
                                    {
                                        offer.GLTDandIDIBenefitSummary.VGSIBasicCATAmt = erCatAmt != 0 ? erCatAmt.ToString() : null;
                                        offer.GLTDandIDIBenefitSummary.BasicCATAmt = "0.0";
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSIBasicCAT = "VGSI Buy Up Basic CAT Benefit";
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (mldiCase.ExstreamRequestType == "BenefitPremium")
                        {
                            var isExist = CheckTermRiderAvailable(enrollmentPDRClasss, offer.cmsStandardOfferCode, "CAT16b");
                            if (isExist)
                            {
                                offer.GLTDandIDIBenefitSummary.BasicCATAmt = "0.0";
                                if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.BasicCATAmt))
                                {
                                    if (isCompactState)
                                    {
                                        if (isOption1)
                                        {
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.BasicCAT = "Severe Disability";
                                        }
                                        else
                                        {
                                            if (!isVGSI)
                                            {   offer.GLTDandIDIBenefitSummary.BasicCATAmt = "0.0";
                                                inGroup.GLTDandIDIBenefitSummaryColumnNames.BasicCAT = "Severe Disability";
                                            }
                                            else
                                            {
                                                offer.GLTDandIDIBenefitSummary.VGSIBasicCATAmt = "0.0";
                                                offer.GLTDandIDIBenefitSummary.BasicCATAmt = "0.0";
                                                inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSIBasicCAT = "VGSI Buy Up Severe Disability";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (isOption1)
                                        {
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.BasicCAT = "Basic CAT Benefit";
                                        }
                                        else
                                        {
                                            if (!isVGSI)
                                            {
                                                offer.GLTDandIDIBenefitSummary.BasicCATAmt = "0.0";
                                                inGroup.GLTDandIDIBenefitSummaryColumnNames.BasicCAT = "Basic CAT Benefit";
                                            }
                                            else
                                            {
                                                offer.GLTDandIDIBenefitSummary.VGSIBasicCATAmt = "0.0";
                                                offer.GLTDandIDIBenefitSummary.BasicCATAmt = "0.0";
                                                inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSIBasicCAT = "VGSI Buy Up Basic CAT Benefit";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (offer.CostSharing || isVGSI)
                {
                    if (hasEnhancedCat && !isNewCase)
                    {
                        var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                        var participantExistingPolicyDetails = inPart?.Participant?.ParticipantExistingPolicies?.Where(p => p.Participant?.Id == inPart?.Participant?.Id).Select(q => q.ParticipantExistingPolicyDetails)?.FirstOrDefault();
                        var existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employer") : null;
                        if (!isOption1)
                        {
                            existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employee") : null;
                        }
                        if (existingPolicyDetails != null)
                        {
                            var existingCATCoverage = existingPolicyDetails.ParticipantExistingPolicyRiders?.FirstOrDefault(
                                a => a.RiderName.Contains("CAT") && a.RiderValueDescription != "Not Included");

                            if (existingCATCoverage != null)
                            {
                                if (existingCATCoverage.Amount != null)
                                {
                                    offer.GLTDandIDIBenefitSummary.ExistingEnhancedCATAmt = existingCATCoverage.Amount.ToString();
                                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingEnhancedCATAmt))
                                    {
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingEnhancedCAT =
                                            "Existing Enhanced CAT Coverage";
                                    }
                                }
                            }
                        }
                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp || isStandAlone)
                {
                    var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                    if (hasEnhancedCat)
                    {
                        var enhanceCatRider = offer.riders.FirstOrDefault(a => a.riderIdentifier == "CAT16e");
                        var erCatAmt = 0M;
                        if (enhanceCatRider != null)
                        {
                            erCatAmt = (decimal)enhanceCatRider.monthlyBenefit;
                        }

                        offer.GLTDandIDIBenefitSummary.EnhancedCATAmt = erCatAmt != 0 ? erCatAmt.ToString() : null;
                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.EnhancedCATAmt))
                        {
                            if (isOption1)
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.EnhancedCAT = "Enhanced CAT Benefit";
                            }
                            else
                            {
                                if (!isVGSI)
                                {
                                    offer.GLTDandIDIBenefitSummary.EnhancedCATAmt = erCatAmt != 0 ? erCatAmt.ToString() : null;
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.EnhancedCAT = "Enhanced CAT Benefit";
                                }
                                else
                                {
                                    offer.GLTDandIDIBenefitSummary.VGSIEnhancedCATAmt = erCatAmt != 0 ? erCatAmt.ToString() : null;
                                    offer.GLTDandIDIBenefitSummary.EnhancedCATAmt = "0.0";
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSIEnhancedCAT = "VGSI Buy Up Enhanced CAT Benefit";
                                }
                            }
                        }
                    }
                    else
                    {
                        if (mldiCase.ExstreamRequestType == "BenefitPremium")
                        {
                            var isExist = CheckTermRiderAvailable(enrollmentPDRClasss, offer.cmsStandardOfferCode, "CAT16e");
                            if (isExist)
                            {
                                offer.GLTDandIDIBenefitSummary.EnhancedCATAmt = "0.0";
                                if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.EnhancedCATAmt))
                                {
                                    if (isOption1)
                                    {
                                        offer.GLTDandIDIBenefitSummary.EnhancedCATAmt = "0.0";
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.EnhancedCAT = "Enhanced CAT Benefit";
                                    }
                                    else
                                    {
                                        if (!isVGSI)
                                        {
                                            offer.GLTDandIDIBenefitSummary.EnhancedCATAmt = "0.0";
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.EnhancedCAT = "Enhanced CAT Benefit";
                                        }
                                        else
                                        {
                                            offer.GLTDandIDIBenefitSummary.VGSIEnhancedCATAmt = "0.0";
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSIEnhancedCAT = "VGSI Buy Up Enhanced CAT Benefit";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp || isStandAlone)
                {
                    if (!isNewCase)
                    {
                        var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                        var participantExistingPolicyDetails = inPart?.Participant?.ParticipantExistingPolicies?.Where(p => p.Participant?.Id == inPart?.Participant?.Id).Select(q => q.ParticipantExistingPolicyDetails)?.FirstOrDefault();
                        var existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employer") : null;
                        if (!isOption1)
                        {
                            existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employee") : null;
                        }
                        if (existingPolicyDetails != null)
                        {
                            var existingRPPCoverage = existingPolicyDetails.ParticipantExistingPolicyRiders?.FirstOrDefault(
                                a => a.RiderName.Contains("RPP") && a.RiderValueDescription != "Not Included");
                            if (existingRPPCoverage != null)
                            {
                                if (existingRPPCoverage.Amount != null)
                                {
                                    offer.GLTDandIDIBenefitSummary.ExistingRPPMonthlyBenefitAmt =
                                        existingRPPCoverage.Amount.ToString();
                                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingRPPMonthlyBenefitAmt))
                                    {
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingRPPMonthlyBenefit =
                                            "Existing RPP Monthly Benefit";
                                    }
                                }
                            }
                        }
                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp || isStandAlone)
                {
                    var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                    var rppBenefit = offer.riders.FirstOrDefault(a => a.riderIdentifier == "RPP");
                    var erRppAmt = 0M;
                    if (rppBenefit != null)
                    {
                        if (rppBenefit.monthlyBenefit != null)
                            erRppAmt = (decimal)rppBenefit.monthlyBenefit;
                        offer.GLTDandIDIBenefitSummary.RPPBenefitAmt = erRppAmt != 0 ? erRppAmt.ToString() : null;
                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.RPPBenefitAmt))
                        {
                            if (isOption1)
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.RPPBenefit = "RPP Benefit";
                            }
                            else
                            {
                                if (!isVGSI)
                                {
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.RPPBenefit = "RPP Benefit";
                                    offer.GLTDandIDIBenefitSummary.RPPBenefitAmt = erRppAmt != 0 ? erRppAmt.ToString() : null;
                                }
                                else
                                {
                                    offer.GLTDandIDIBenefitSummary.VGSIRPPBenefitAmt = erRppAmt != 0 ? erRppAmt.ToString() : null;
                                    offer.GLTDandIDIBenefitSummary.RPPBenefitAmt = "0.0";
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSIRPPBenefit = "VGSI Buy Up RPP Benefit";
                                }
                            }
                        }
                    }
                    else
                    {
                        if (mldiCase.ExstreamRequestType == "BenefitPremium")
                        {
                            var isExist = CheckTermRiderAvailable(enrollmentPDRClasss, offer.cmsStandardOfferCode, "RPP");
                            if (isExist)
                            {
                                offer.GLTDandIDIBenefitSummary.RPPBenefitAmt = "0.0";
                                if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.RPPBenefitAmt))
                                {
                                    if (isOption1)
                                    {
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.RPPBenefit = "RPP Benefit";
                                    }
                                    else
                                    {
                                        if (!isVGSI)
                                        {
                                            offer.GLTDandIDIBenefitSummary.RPPBenefitAmt = "0.0";
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.RPPBenefit = "RPP Benefit";
                                        }
                                        else
                                        {
                                            offer.GLTDandIDIBenefitSummary.VGSIRPPBenefitAmt = "0.0";
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSIRPPBenefit = "VGSI Buy Up RPP Benefit";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp || isStandAlone)
                {
                    if (!isNewCase)
                    {
                        var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                        var participantExistingPolicyDetails = inPart?.Participant?.ParticipantExistingPolicies?.Where(p => p.Participant?.Id == inPart?.Participant?.Id).Select(q => q.ParticipantExistingPolicyDetails)?.FirstOrDefault();
                        var existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employer") : null;
                        if (!isOption1)
                        {
                            existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employee") : null;
                        }
                        if (existingPolicyDetails != null)
                        {
                            var existingSLRCoverage = existingPolicyDetails.ParticipantExistingPolicyRiders?.FirstOrDefault(
                                a => a.RiderName.Contains("SLP") && a.RiderValueDescription != "Not Included");

                            if (existingSLRCoverage != null)
                            {
                                if (existingSLRCoverage.Amount != null)
                                {
                                    offer.GLTDandIDIBenefitSummary.ExistingSLRBenefitAmt = existingSLRCoverage.Amount.ToString();
                                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingSLRBenefitAmt))
                                    {
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingSLRBenefit = "Existing SLR Benefit";
                                    }
                                }
                            }
                        }
                    }
                }

                if (offer.CostSharing || isVGSI)
                {
                    if (!isNewCase)
                    {
                        var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                        var participantExistingPolicyDetails = inPart?.Participant?.ParticipantExistingPolicies?.Where(p => p.Participant?.Id == inPart?.Participant?.Id).Select(q => q.ParticipantExistingPolicyDetails)?.FirstOrDefault();
                        var existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employer") : null;
                        if (!isOption1)
                        {
                            existingPolicyDetails = participantExistingPolicyDetails != null ? participantExistingPolicyDetails.FirstOrDefault(x => x.PremiumPayer == "Employee") : null;
                        }
                        if (existingPolicyDetails != null)
                        {
                            var existingSBTCoverage = existingPolicyDetails.ParticipantExistingPolicyRiders?.FirstOrDefault(
                                a => a.RiderName.Contains("SBT") && a.RiderValueDescription != "Not Included");

                            if (existingSBTCoverage != null)
                            {
                                if (existingSBTCoverage.Amount != null)
                                {
                                    offer.GLTDandIDIBenefitSummary.ExistingSBTBenefitAmt = existingSBTCoverage.Amount.ToString();
                                    if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.ExistingSBTBenefitAmt))
                                    {
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.ExistingSBTBenefit = "Existing Supp Benefit";
                                    }
                                }
                            }
                        }
                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp || isStandAlone)
                {
                    var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                    var hasSlpRider = offer.riders.Any(a => a.riderIdentifier == "SLP");

                    var slrBenefit =
                        inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(a => a.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode || a.StandardOptionCodeSmoker == offer.cmsStandardOfferCode)
                            .EnrollmentPDRClassOptionPlan.EnrollmentPDRClassOptionPlanRiders.FirstOrDefault(
                                a => a.BenefitType == BenefitTypeEnum.StudentLoanProtection);

                    if (hasSlpRider && slrBenefit != null && slrBenefit.Amount != null && slrBenefit.Amount != 0)
                    {
                        offer.GLTDandIDIBenefitSummary.SLRBenefitAmt = slrBenefit.Amount.ToString();
                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.SLRBenefitAmt))
                        {
                            if (isOption1)
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.SLRBenefit = "SLR Benefit";
                            }
                            else
                            {
                                if (!isVGSI)
                                {
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.SLRBenefit = "SLR Benefit";
                                    offer.GLTDandIDIBenefitSummary.SLRBenefitAmt = slrBenefit.Amount.ToString();
                                }
                                else
                                {
                                    offer.GLTDandIDIBenefitSummary.VGSISLRBenefitAmt = slrBenefit.Amount.ToString();
                                    offer.GLTDandIDIBenefitSummary.SLRBenefitAmt = "0.0";
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSISLRBenefit = "VGSI Buy Up SLR Benefit";
                                }
                            }
                        }
                    }
                    else
                    {
                        if (mldiCase.ExstreamRequestType == "BenefitPremium")
                        {
                            var isExist = CheckTermRiderAvailable(enrollmentPDRClasss, offer.cmsStandardOfferCode, "SLP");
                            if (isExist)
                            {
                                offer.GLTDandIDIBenefitSummary.SLRBenefitAmt = "0.0";
                                if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.SLRBenefitAmt))
                                {
                                    if (isOption1)
                                    {
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.SLRBenefit = "SLR Benefit";
                                    }
                                    else
                                    {
                                        if (!isVGSI)
                                        {
                                            offer.GLTDandIDIBenefitSummary.SLRBenefitAmt = "0.0";
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.SLRBenefit = "SLR Benefit";
                                        }
                                        else
                                        {
                                            offer.GLTDandIDIBenefitSummary.VGSISLRBenefitAmt = "0.0";
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSISLRBenefit = "VGSI Buy Up SLR Benefit";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (offer.CostSharing || isVGSI || isReverseCombo || isSuppBnp || isStandAlone)
                {
                    var hasSbtRider = offer.riders.Any(a => a.riderIdentifier == "SBT");
                    var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
                    var supBenefit =
                        inPart.EnrollmentParticipantOptionPlans.FirstOrDefault(a => a.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode || a.StandardOptionCodeSmoker == offer.cmsStandardOfferCode)
                            .EnrollmentPDRClassOptionPlan.EnrollmentPDRClassOptionPlanRiders.FirstOrDefault(
                                a => a.BenefitType == BenefitTypeEnum.SupplementalBenefitTermRider);

                    if (hasSbtRider && supBenefit != null && supBenefit.Amount != null && supBenefit.Amount != 0)
                    {
                        offer.GLTDandIDIBenefitSummary.SBTBenefitAmt = supBenefit.Amount.ToString();
                        if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.SBTBenefitAmt))
                        {
                            if (isOption1)
                            {
                                inGroup.GLTDandIDIBenefitSummaryColumnNames.SBTBenefit = "Supp Benefit";
                            }
                            else
                            {
                                if (!isVGSI)
                                {
                                    offer.GLTDandIDIBenefitSummary.SBTBenefitAmt = supBenefit.Amount.ToString();
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.SBTBenefit = "Supp Benefit";
                                }
                                else
                                {
                                    offer.GLTDandIDIBenefitSummary.VGSISBTBenefitAmt = supBenefit.Amount.ToString();
                                    offer.GLTDandIDIBenefitSummary.SBTBenefitAmt = "0.0";
                                    inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSISBTBenefit = "VGSI Buy Up Supp Benefit";
                                }
                            }
                        }
                    }
                    else
                    {
                        if (mldiCase.ExstreamRequestType == "BenefitPremium")
                        {
                            var isExist = CheckTermRiderAvailable(enrollmentPDRClasss, offer.cmsStandardOfferCode, "SBT");
                            if (isExist)
                            {
                                offer.GLTDandIDIBenefitSummary.SBTBenefitAmt = "0.0";
                                if (!string.IsNullOrEmpty(offer.GLTDandIDIBenefitSummary.SBTBenefitAmt))
                                {
                                    if (isOption1)
                                    {
                                        inGroup.GLTDandIDIBenefitSummaryColumnNames.SBTBenefit = "Supp Benefit";
                                    }
                                    else
                                    {
                                        if (!isVGSI)
                                        {
                                            offer.GLTDandIDIBenefitSummary.SBTBenefitAmt = "0.0";
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.SBTBenefit = "Supp Benefit";
                                        }
                                        else
                                        {
                                            offer.GLTDandIDIBenefitSummary.VGSISBTBenefitAmt = "0.0";
                                            inGroup.GLTDandIDIBenefitSummaryColumnNames.VGSISBTBenefit = "VGSI Buy Up Supp Benefit";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private static decimal? CalculateRPPReplacementPercentage(EnrollmentParticipant inPart)
        {
            decimal? rppReplacementPercent = 0.0m;
            decimal? rppBenefitAmount = inPart.Participant.RPPBenefitCalculatedAmount ?? 0;
            decimal? totalEmployerEmployeeCalculatedAmount = inPart.Participant.TotalEmployerOrEmployeeRetirementContributionCalculatedAmount ?? 0;
            rppReplacementPercent = totalEmployerEmployeeCalculatedAmount != 0 ? (rppBenefitAmount * 12 / totalEmployerEmployeeCalculatedAmount).Value.Roundoff(4) : 0;
            return rppReplacementPercent;
        }

        private static void CreateProviderChoicePremiumSummaryTotalPlusAMB(EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml offer, EnrollmentKitXml.ExtreamGenerationGroup inGroup, EnrollmentParticipant inPart, bool isNewCase, EnrollmentKitXml.ExtreamGenerationParticipantXml fullParticipantRecord, ParticipantExistingPolicyDetail existingPolicydetail)
        {
            if (offer.ProviderChoicePremiumSummary == null)
            {
                offer.ProviderChoicePremiumSummary = new EnrollmentKitXml.ExstreamGenerationProviderChoicePremiumSummaries();
            }

            if (inGroup.ProviderChoicePremiumsColumnNames == null)
            {
                inGroup.ProviderChoicePremiumsColumnNames = new EnrollmentKitXml.ExstreamGenerationProviderChoicePremiumColumnNames();
            }

            bool isVGSI = false;
            bool hasAmbPolicy = false;

            if (inPart != null && inPart.Participant != null)
            {
                isVGSI = (inPart.Participant.VGSIBuyUpBenefit != null && inPart.Participant.VGSIBuyUpBenefit > 0) || offer.cmsStandardOfferCode.Contains("VGSI");
                hasAmbPolicy = inPart.Participant.IsAMBIncreaseIndicator == true ? true : false;

                var participantOptionPlan = inPart.EnrollmentParticipantOptionPlans
                                                  .FirstOrDefault(a => a.StandardOptionCodeSmoker == offer.cmsStandardOfferCode ||
                                                                       a.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode);
                var participantBuyUpOptionPlan = inPart.EnrollmentParticipantOptionPlans
                                                 .FirstOrDefault(a => (a.StandardOptionCodeSmoker == offer.cmsStandardOfferCode ||
                                                                      a.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode) && a.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                if (participantOptionPlan != null && !isVGSI && !hasAmbPolicy)
                {
                    if (offer.CostSharing)
                    {
                        offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployeePremiumAmt = participantOptionPlan.NewTotalPremiumEmployeePortionModalPremium != null ? participantOptionPlan.NewTotalPremiumEmployeePortionModalPremium.ToString() : null;
                        offer.ProviderChoicePremiumSummary.TotalPlusAMBERPaidModalPremiumAmt = participantOptionPlan.NewTotalPremiumEmployerPortionModalPremium != null ? participantOptionPlan.NewTotalPremiumEmployerPortionModalPremium.ToString() : null;
                        offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployerPremiumAmt = participantOptionPlan.NewTotalPremiumEmployerPortionModalPremium != null ? participantOptionPlan.NewTotalPremiumEmployerPortionModalPremium.ToString() : null;
                    }
                    else
                    {
                        offer.ProviderChoicePremiumSummary.TotalPlusAMBERPaidModalPremiumAmt = participantOptionPlan.NewTotalPremiumModalPremium != null ? participantOptionPlan.NewTotalPremiumModalPremium.ToString() : null;
                        offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployerPremiumAmt = participantOptionPlan.NewTotalPremiumModalPremium != null ? participantOptionPlan.NewTotalPremiumModalPremium.ToString() : null;
                        if (participantBuyUpOptionPlan != null)
                        {
                            offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployeePremiumAmt = participantBuyUpOptionPlan.NewTotalPremiumModalPremium != null ? participantBuyUpOptionPlan.NewTotalPremiumModalPremium.ToString() : null;
                            offer.ProviderChoicePremiumSummary.TotalPlusAMBERPaidModalPremiumAmt = "0.0";
                        }
                        else
                        {
                            offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployeePremiumAmt = "0.0";
                        }
                    }

                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployeePremiumAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.TotalPlusAMBModalEmployeePremium = string.Format("Total Plus AMB Modal Employee Premium");
                    }
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.TotalPlusAMBERPaidModalPremiumAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.TotalPlusAMBERPaidModalPremium = string.Format("Total Plus AMB ER Paid Modal Premium");
                    }

                    offer.ProviderChoicePremiumSummary.TotalPlusAMBVGSIBuyUpModalPremiumAmt = participantOptionPlan.NewTotalBuyUpPremiumModalPremium != null ? participantOptionPlan.NewTotalBuyUpPremiumModalPremium.ToString() : null;
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.TotalPlusAMBVGSIBuyUpModalPremiumAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.TotalPlusAMBVGSIBuyUpModalPremium = string.Format("Total Plus AMB VGSIBuyUp Modal Premium");
                    }

                    offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployerPremiumAmt = participantOptionPlan.NewTotalPremiumEmployerPortionModalPremium != null ? participantOptionPlan.NewTotalPremiumEmployerPortionModalPremium.ToString() : (participantOptionPlan.NewTotalPremiumModalPremium != null && participantOptionPlan.PDRClassPlanType == PDRClassPlanTypeEnum.Primary) ? participantOptionPlan.NewTotalPremiumModalPremium.ToString() : null;
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.TotalPlusAMBModalEmployerPremiumAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.TotalPlusAMBModalEmployerPremium = string.Format("Total Plus AMB Modal Employer Premium");
                    }
                }
            }

        }

        private static void CreateProviderChoicePremiumSummaryXML(EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml offer, EnrollmentKitXml.ExtreamGenerationGroup inGroup, EnrollmentParticipant inPart, BillingModeTypeEnum? modalValue, bool isNewCase, EnrollmentKitXml.ExtreamGenerationParticipantXml fullParticipantRecord, ParticipantExistingPolicyDetail existingPolicydetail, Case cmsCase, EnrollmentKitXml mldiCase)
        {
            offer.ProviderChoicePremiumSummary = new EnrollmentKitXml.ExstreamGenerationProviderChoicePremiumSummaries();
            string modalValueDescription = null;
            if (inGroup.ProviderChoicePremiumsColumnNames == null)
            {
                inGroup.ProviderChoicePremiumsColumnNames = new EnrollmentKitXml.ExstreamGenerationProviderChoicePremiumColumnNames();
            }

            if (modalValue != null)
            {
                modalValueDescription = modalValue.GetDescription();
            }
            else
            {
                modalValueDescription = BillingModeTypeEnum.Monthly.GetDescription();
            }

            if (inPart != null && inPart.Participant != null)
            {

                var participantOptionPlan = inPart.EnrollmentParticipantOptionPlans
                                                  .FirstOrDefault(a => a.StandardOptionCodeSmoker == offer.cmsStandardOfferCode ||
                                                                       a.StandardOptionCodeNonSmoker == offer.cmsStandardOfferCode);
                decimal proposedCoveragePremiumAmt = 0M;
                decimal proposedAnnualCoveragePremiumAmt = 0M;
                decimal proposedCoverageEmployeePremiumAmt = 0M;
                decimal proposedCoverageEmployerPremiumAmt = 0M;
                decimal proposedCoverageAnnualEmployerPremiumAmt = 0M;
                decimal proposedCoverageAnnualEmployeePremiumAmt = 0M;
                var hasAmbPolicy = inPart.Participant.IsAMBIncreaseIndicator == true ? true : false;
                var hasBuyUpAmbPolicy = inPart.Participant.IsBuyUpAMBIncreaseIndicator == true ? true : false;
                var isVGSI = (inPart.Participant.VGSIBuyUpBenefit != null && inPart.Participant.VGSIBuyUpBenefit > 0) || offer.cmsStandardOfferCode.Contains("VGSI");
                var pdrSoldClassPlan = new PDRSoldClassPlan();
                var isRPPBnP = pdrSoldClassPlan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan;

                if (inPart.IsSmoker != null && (bool)inPart.IsSmoker)
                {
                    proposedAnnualCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerPremiumAmountAnnually != null ? (decimal)participantOptionPlan.SmokerPremiumAmountAnnually : 0M;
                    proposedCoverageAnnualEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployerPremiumAnnually != null ? (decimal)participantOptionPlan.SmokerEmployerPremiumAnnually : 0M;
                    proposedCoverageAnnualEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployeePremiumAnnually != null ? (decimal)participantOptionPlan.SmokerEmployeePremiumAnnually : 0M;
                }
                else
                {
                    proposedAnnualCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerPremiumAmountAnnually != null ? (decimal)participantOptionPlan.NonSmokerPremiumAmountAnnually : 0M;
                    proposedCoverageAnnualEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployerPremiumAnnually != null ? (decimal)participantOptionPlan.NonSmokerEmployerPremiumAnnually : 0M;
                    proposedCoverageAnnualEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployeePremiumAnnually != null ? (decimal)participantOptionPlan.NonSmokerEmployeePremiumAnnually : 0M;
                }

                var policyDetails = inPart.Participant.ParticipantExistingPolicies.SelectMany(c => c.ParticipantExistingPolicyDetails).ToList();

                if (hasAmbPolicy)
                {
                    var policyInfo = policyDetails.Where(c => c.CaseNumber != null
                                                                && c.CaseNumber.Trim() == cmsCase.CaseNumber.Trim()
                                                                && c.CLOASPolicyStatus == "Inforce").ToList();
                    var modalPremiums = policyInfo.Sum(c => c.ModalPremium);
                    offer.ProviderChoicePremiumSummary.ExistingCoveragePremiumSummaryAmt = modalPremiums != null ? modalPremiums.ToString() : null;
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingCoveragePremiumSummaryAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.ExistingCoveragePremiumSummary = string.Format("Existing Coverage Premium Summary");
                    }
                }
                switch (modalValue)
                {
                    case BillingModeTypeEnum.Annual:
                        if (inPart.IsSmoker != null && (bool)inPart.IsSmoker)
                        {
                            proposedCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerPremiumAmountAnnually != null ? (decimal)participantOptionPlan.SmokerPremiumAmountAnnually : 0M;
                            proposedCoverageEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployeePremiumAnnually != null ? (decimal)participantOptionPlan.SmokerEmployeePremiumAnnually : 0M;
                            proposedCoverageEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployeePremiumAnnually != null ? (decimal)participantOptionPlan.SmokerEmployerPremiumAnnually : 0M;
                        }
                        else
                        {
                            proposedCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerPremiumAmountAnnually != null ? (decimal)participantOptionPlan.NonSmokerPremiumAmountAnnually : 0M;
                            proposedCoverageEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployeePremiumAnnually != null ? (decimal)participantOptionPlan.NonSmokerEmployeePremiumAnnually : 0M;
                            proposedCoverageEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployerPremiumAnnually != null ? (decimal)participantOptionPlan.NonSmokerEmployerPremiumAnnually : 0M;
                        }
                        break;
                    case BillingModeTypeEnum.Semi_Annual:
                        if (inPart.IsSmoker != null && (bool)inPart.IsSmoker)
                        {
                            proposedCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerPremiumAmountSemiannually != null ? (decimal)participantOptionPlan.SmokerPremiumAmountSemiannually : 0M;
                            proposedCoverageEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployeePremiumSemiannually != null ? (decimal)participantOptionPlan.SmokerEmployeePremiumSemiannually : 0M;
                            proposedCoverageEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployerPremiumSemiannually != null ? (decimal)participantOptionPlan.SmokerEmployerPremiumSemiannually : 0M;
                        }
                        else
                        {
                            proposedCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerPremiumAmountSemiannually != null ? (decimal)participantOptionPlan.NonSmokerPremiumAmountSemiannually : 0M;
                            proposedCoverageEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployeePremiumSemiannually != null ? (decimal)participantOptionPlan.NonSmokerEmployeePremiumSemiannually : 0M;
                            proposedCoverageEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployerPremiumSemiannually != null ? (decimal)participantOptionPlan.NonSmokerEmployerPremiumSemiannually : 0M;
                        }
                        break;
                    case BillingModeTypeEnum.Quarterly:
                        if (inPart.IsSmoker != null && (bool)inPart.IsSmoker)
                        {
                            proposedCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerPremiumAmountQuarterly != null ? (decimal)participantOptionPlan.SmokerPremiumAmountQuarterly : 0M;
                            proposedCoverageEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployeePremiumQuarterly != null ? (decimal)participantOptionPlan.SmokerEmployeePremiumQuarterly : 0M;
                            proposedCoverageEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployerPremiumQuarterly != null ? (decimal)participantOptionPlan.SmokerEmployerPremiumQuarterly : 0M;
                        }
                        else
                        {
                            proposedCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerPremiumAmountQuarterly != null ? (decimal)participantOptionPlan.NonSmokerPremiumAmountQuarterly : 0M;
                            proposedCoverageEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployeePremiumQuarterly != null ? (decimal)participantOptionPlan.NonSmokerEmployeePremiumQuarterly : 0M;
                            proposedCoverageEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployerPremiumQuarterly != null ? (decimal)participantOptionPlan.NonSmokerEmployerPremiumQuarterly : 0M;
                        }
                        break;
                    default:
                        if (inPart.IsSmoker != null && (bool)inPart.IsSmoker)
                        {
                            proposedCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerPremiumAmountMonthly != null ? (decimal)participantOptionPlan.SmokerPremiumAmountMonthly : 0M;
                            proposedCoverageEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployeePremiumPerMonth != null ? (decimal)participantOptionPlan.SmokerEmployeePremiumPerMonth : 0M;
                            proposedCoverageEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.SmokerEmployerPremiumPerMonth != null ? (decimal)participantOptionPlan.SmokerEmployerPremiumPerMonth : 0M;
                        }
                        else
                        {
                            proposedCoveragePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerPremiumAmountMonthly != null ? (decimal)participantOptionPlan.NonSmokerPremiumAmountMonthly : 0M;
                            proposedCoverageEmployeePremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployeePremiumPerMonth != null ? (decimal)participantOptionPlan.NonSmokerEmployeePremiumPerMonth : 0M;
                            proposedCoverageEmployerPremiumAmt = participantOptionPlan != null && participantOptionPlan.NonSmokerEmployerPremiumPerMonth != null ? (decimal)participantOptionPlan.NonSmokerEmployerPremiumPerMonth : 0M;
                        }
                        break;

                }

                if (offer.CostSharing)
                {
                    offer.ProviderChoicePremiumSummary.ProposedCoverageEmployeePremiumAmt =
                        proposedCoverageEmployeePremiumAmt != 0 ? proposedCoverageEmployeePremiumAmt.ToString(CultureInfo.InvariantCulture) : "0.00";
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedCoverageEmployeePremiumAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.ProposedCoverageEmployeePremium = string.Format("Proposed Coverage {0} Employee Premium", modalValueDescription);
                    }

                    offer.ProviderChoicePremiumSummary.ProposedCoverageEmployerPremiumAmt =
                        proposedCoverageEmployerPremiumAmt != 0 ? proposedCoverageEmployerPremiumAmt.ToString(CultureInfo.InvariantCulture) : "0.00";
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedCoverageEmployerPremiumAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.ProposedCoverageEmployerPremium = string.Format("Proposed Coverage {0} Employer Premium", modalValueDescription);
                    }

                    offer.ProviderChoicePremiumSummary.ProposedCoverageAnnualEmployeePremiumAmt =
                        proposedCoverageAnnualEmployeePremiumAmt != 0 ? proposedCoverageAnnualEmployeePremiumAmt.ToString(CultureInfo.InvariantCulture) : "0.00";
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedCoverageAnnualEmployeePremiumAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.ProposedCoverageAnnualEmployeePremium = string.Format("Proposed Coverage Annual Employee Premium");
                    }

                    offer.ProviderChoicePremiumSummary.ProposedCoverageAnnualEmployerPremiumAmt =
                        proposedCoverageAnnualEmployerPremiumAmt != 0 ? proposedCoverageAnnualEmployerPremiumAmt.ToString(CultureInfo.InvariantCulture) : "0.00";
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedCoverageAnnualEmployerPremiumAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.ProposedCoverageAnnualEmployerPremium = string.Format("Proposed Coverage Annual Employer Premium");
                    }

                    if (hasAmbPolicy)
                    {
                        if (isRPPBnP)
                        {
                            offer.ProviderChoicePremiumSummary.ExistingCoverageEmployeePremiumAmt = inPart.Participant.EEPaidRPPGSIBasePlusAMBInForceModalAmount != null ? inPart.Participant.EEPaidRPPGSIBasePlusAMBInForceModalAmount.ToString() : null;
                            if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingCoverageEmployeePremiumAmt))
                            {
                                inGroup.ProviderChoicePremiumsColumnNames.ExistingCoverageEmployeePremium =
                                    string.Format("Existing Coverage {0} Employee Premium", modalValueDescription);
                            }
                            offer.ProviderChoicePremiumSummary.ExistingCoverageAnnualEmployeePremiumAmt = inPart.Participant.EEPaidRPPGSIBasePlusAMBInForceAnnualAmount != null ? inPart.Participant.EEPaidRPPGSIBasePlusAMBInForceAnnualAmount.ToString() : null;
                        }
                        else
                        {
                            offer.ProviderChoicePremiumSummary.ExistingCoverageEmployeePremiumAmt = inPart.Participant.EEPaidIDIGSIBasePlusAMBInForceModalAmount != null ? inPart.Participant.EEPaidIDIGSIBasePlusAMBInForceModalAmount.ToString() : null;
                            if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingCoverageEmployeePremiumAmt))
                            {
                                inGroup.ProviderChoicePremiumsColumnNames.ExistingCoverageEmployeePremium =
                                    string.Format("Existing Coverage {0} Employee Premium", modalValueDescription);
                            }
                            offer.ProviderChoicePremiumSummary.ExistingCoverageAnnualEmployeePremiumAmt = inPart.Participant.EEPaidIDIGSIBasePlusAMBInForceAnnualAmount != null ? inPart.Participant.EEPaidIDIGSIBasePlusAMBInForceAnnualAmount.ToString() : null;
                        }
                        if (isRPPBnP)
                        {
                            offer.ProviderChoicePremiumSummary.ExistingCoverageEmployerPremiumAmt = inPart.Participant.ERPaidRPPGSIBasePlusAMBInForceModalAmount != null ? inPart.Participant.ERPaidRPPGSIBasePlusAMBInForceModalAmount.ToString() : null;
                            if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingCoverageEmployerPremiumAmt))
                            {
                                inGroup.ProviderChoicePremiumsColumnNames.ExistingCoverageEmployerPremium =
                                    string.Format("Existing Coverage {0} Employer Premium", modalValueDescription);
                            }
                            offer.ProviderChoicePremiumSummary.ExistingCoverageAnnualEmployerPremiumAmt = inPart.Participant.ERPaidRPPGSIBasePlusAMBInForceAnnualAmount != null ? inPart.Participant.ERPaidRPPGSIBasePlusAMBInForceAnnualAmount.ToString() : null;
                        }
                        else
                        {
                            offer.ProviderChoicePremiumSummary.ExistingCoverageEmployerPremiumAmt = inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceModalAmount != null ? inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceModalAmount.ToString() : null;
                            if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingCoverageEmployerPremiumAmt))
                            {
                                inGroup.ProviderChoicePremiumsColumnNames.ExistingCoverageEmployerPremium =
                                    string.Format("Existing Coverage {0} Employer Premium", modalValueDescription);
                            }
                            offer.ProviderChoicePremiumSummary.ExistingCoverageAnnualEmployerPremiumAmt = inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceAnnualAmount != null ? inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceAnnualAmount.ToString() : null;
                        }

                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingCoverageAnnualEmployeePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingCoverageAnnualEmployeePremium =
                                string.Format("Existing Coverage Annual Employee Premium");
                        }
                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingCoverageAnnualEmployerPremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingCoverageAnnualEmployerPremium =
                                string.Format("Existing Coverage Annual Employer Premium");
                        }
                    }
                }
                else if (isVGSI)
                {

                    var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");

                    var firstOffer = new EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml();

                    if (!offer.isTobaccoRates)
                    {
                        firstOffer =
                            fullParticipantRecord.Offers.FirstOrDefault(
                                a => a.cmsStandardOfferCode.Contains("Option 1") &&
                                     a.cmsStandardOfferCode.Contains("Non Tobacco"));

                    }
                    else
                    {
                        firstOffer =
                            fullParticipantRecord.Offers.FirstOrDefault(
                                a => a.cmsStandardOfferCode.Contains("Option 1") &&
                                     !a.cmsStandardOfferCode.Contains("Non Tobacco"));

                    }

                    if (isOption1)
                    {
                        offer.ProviderChoicePremiumSummary.ProposedERPaidCoveragePremiumAmt =
                            proposedCoveragePremiumAmt != 0
                                ? proposedCoveragePremiumAmt.ToString(CultureInfo.InvariantCulture)
                                : null;

                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedERPaidCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ProposedERPaidCoveragePremium =
                                string.Format("Proposed ER Paid Coverage {0} Premium", modalValueDescription);
                        }

                        offer.ProviderChoicePremiumSummary.ProposedERPaidAnnualCoveragePremiumAmt =
                            proposedAnnualCoveragePremiumAmt != 0
                                ? proposedAnnualCoveragePremiumAmt.ToString(CultureInfo.InvariantCulture)
                                : null;
                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedERPaidAnnualCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ProposedERPaidAnnualCoveragePremium =
                                string.Format("Proposed ER Paid Coverage Annual Premium");
                        }
                    }

                    //EE
                    if (!isOption1)
                    {
                        offer.ProviderChoicePremiumSummary.ProposedERPaidCoveragePremiumAmt = firstOffer != null ?
                                        firstOffer.ProviderChoicePremiumSummary.ProposedERPaidCoveragePremiumAmt : string.Empty;

                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedERPaidCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ProposedERPaidCoveragePremium =
                                string.Format("Proposed ER Paid Coverage {0} Premium", modalValueDescription);
                        }

                        offer.ProviderChoicePremiumSummary.ProposedERPaidAnnualCoveragePremiumAmt = firstOffer != null ?
                                        firstOffer.ProviderChoicePremiumSummary.ProposedERPaidAnnualCoveragePremiumAmt : string.Empty;

                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedERPaidAnnualCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ProposedERPaidAnnualCoveragePremium =
                                string.Format("Proposed ER Paid Coverage Annual Premium");
                        }

                        offer.ProviderChoicePremiumSummary.ProposedVGSIBuyUpCoveragePremiumAmt =
                            proposedCoveragePremiumAmt != 0
                                ? proposedCoveragePremiumAmt.ToString(CultureInfo.InvariantCulture)
                                : null;

                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedVGSIBuyUpCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ProposedVGSIBuyUpCoveragePremium =
                                string.Format("Proposed VGSI Buy Up Coverage {0} Premium", modalValueDescription);
                        }

                        offer.ProviderChoicePremiumSummary.ProposedVGSIBuyUpAnnualCoveragePremiumAmt =
                            proposedAnnualCoveragePremiumAmt != 0
                                ? proposedAnnualCoveragePremiumAmt.ToString(CultureInfo.InvariantCulture)
                                : null;

                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedVGSIBuyUpAnnualCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ProposedVGSIBuyUpAnnualCoveragePremium =
                                string.Format("Proposed VGSI Buy Up Coverage Annual Premium");
                        }

                        if (mldiCase.ExstreamRequestType == "EnrollmentTool")
                        {
                            offer.ProviderChoicePremiumSummary.ProposedERPaidCoveragePremiumAmt = proposedCoveragePremiumAmt != 0
                                    ? proposedCoveragePremiumAmt.ToString(CultureInfo.InvariantCulture)
                                    : null;

                            offer.ProviderChoicePremiumSummary.ProposedERPaidAnnualCoveragePremiumAmt = proposedAnnualCoveragePremiumAmt != 0
                                    ? proposedAnnualCoveragePremiumAmt.ToString(CultureInfo.InvariantCulture)
                                    : null;
                        }
                    }

                    if (hasAmbPolicy && isOption1)
                    {

                        offer.ProviderChoicePremiumSummary.ExistingERPaidCoveragePremiumAmt = inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceModalAmount != null ? inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceModalAmount.ToString() : null;
                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingERPaidCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingERPaidUpCoveragePremium =
                                string.Format("Existing ER Paid Coverage {0} Premium", modalValueDescription);
                        }

                        offer.ProviderChoicePremiumSummary.ExistingERPaidAnnualCoveragePremiumAmt = inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceAnnualAmount != null ? inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceAnnualAmount.ToString() : null; ;
                        if (
                            !string.IsNullOrEmpty(
                                offer.ProviderChoicePremiumSummary.ExistingERPaidAnnualCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingERPaidUpAnnualCoveragePremium =
                                string.Format("Existing ER Paid Coverage Annual Premium");
                        }


                        offer.ProviderChoicePremiumSummary.ExistingVGSIBuyUpCoveragePremiumAmt = null;  //todo
                        if (
                            !string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingVGSIBuyUpCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingVGSIBuyUpCoveragePremium =
                                string.Format("Existing VGSI Buy Up Coverage {0} Premium", modalValueDescription);
                        }


                        offer.ProviderChoicePremiumSummary.ExistingVGSIBuyUpAnnualCoveragePremiumAmt = null; //todo
                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingVGSIBuyUpAnnualCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingVGSIBuyUpAnnualCoveragePremium =
                                string.Format("Existing VGSI Buy Up Coverage Annual Premium");
                        }

                    }
                    if (hasBuyUpAmbPolicy && !isOption1)
                    {
                        offer.ProviderChoicePremiumSummary.ExistingERPaidCoveragePremiumAmt = inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceModalAmount != null ? inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceModalAmount.ToString() : null;
                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingERPaidCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingERPaidUpCoveragePremium =
                                string.Format("Existing ER Paid Coverage {0} Premium", modalValueDescription);
                        }

                        offer.ProviderChoicePremiumSummary.ExistingERPaidAnnualCoveragePremiumAmt = inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceAnnualAmount != null ? inPart.Participant.ERPaidIDIGSIBasePlusAMBInForceAnnualAmount.ToString() : null;
                        if (
                            !string.IsNullOrEmpty(
                                offer.ProviderChoicePremiumSummary.ExistingERPaidAnnualCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingERPaidUpAnnualCoveragePremium =
                                string.Format("Existing ER Paid Coverage Annual Premium");
                        }


                        offer.ProviderChoicePremiumSummary.ExistingVGSIBuyUpCoveragePremiumAmt = inPart.Participant.EEPaidIDIGSIBasePlusAMBInForceModalAmount != null ? inPart.Participant.EEPaidIDIGSIBasePlusAMBInForceModalAmount.ToString() : null; ;
                        if (
                            !string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingVGSIBuyUpCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingVGSIBuyUpCoveragePremium =
                                string.Format("Existing VGSI Buy Up Coverage {0} Premium", modalValueDescription);
                        }


                        offer.ProviderChoicePremiumSummary.ExistingVGSIBuyUpAnnualCoveragePremiumAmt = inPart.Participant.EEPaidIDIGSIBasePlusAMBInForceAnnualAmount != null ? inPart.Participant.EEPaidIDIGSIBasePlusAMBInForceAnnualAmount.ToString() : null; ;
                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingVGSIBuyUpAnnualCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ExistingVGSIBuyUpAnnualCoveragePremium =
                                string.Format("Existing VGSI Buy Up Coverage Annual Premium");
                        }

                    }

                }
                else
                {
                    bool? IsVGSICase = inPart?.Participant?.PlanDesignRequestClass?.PlanDesignRequestClassProducts?.Any(x => x.IsGSIPlanIndicator == true);
                    if (IsVGSICase == false)
                    {
                        offer.ProviderChoicePremiumSummary.ProposedCoveragePremiumAmt =
                    proposedCoveragePremiumAmt != 0
                        ? proposedCoveragePremiumAmt.ToString(CultureInfo.InvariantCulture)
                        : null;
                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ProposedCoveragePremium =
                                string.Format("Proposed Coverage {0} Premium", modalValueDescription);
                        }

                        offer.ProviderChoicePremiumSummary.ProposedAnnualCoveragePremiumAmt =
                            proposedAnnualCoveragePremiumAmt != 0
                                ? proposedAnnualCoveragePremiumAmt.ToString(CultureInfo.InvariantCulture)
                                : null;
                        if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ProposedAnnualCoveragePremiumAmt))
                        {
                            inGroup.ProviderChoicePremiumsColumnNames.ProposedAnnualCoveragePremium =
                                string.Format("Proposed Coverage Annual Premium");
                        }

                        if (!isNewCase)
                        {
                            var employerPolicy = policyDetails.Where(c => c.CaseNumber != null
                                                                  && c.CaseNumber.Trim() == cmsCase.CaseNumber.Trim()
                                                                  && c.CLOASPolicyStatus == "Inforce" && c.PremiumPayer != null && c.PremiumPayer == "Employer").ToList();
                            var modalPremiums = employerPolicy.Sum(c => c.ModalPremium);
                            offer.ProviderChoicePremiumSummary.ExistingCoveragePremiumAmt = modalPremiums != null ? modalPremiums.ToString() : null;
                            if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingCoveragePremiumAmt))
                            {
                                inGroup.ProviderChoicePremiumsColumnNames.ExistingCoveragePremium =
                                    string.Format("Existing Coverage {0} Premium", modalValueDescription);
                            }

                            var employeePolicy = policyDetails.Where(c => c.CaseNumber != null
                                                                 && c.CaseNumber.Trim() == cmsCase.CaseNumber.Trim()
                                                                 && c.CLOASPolicyStatus == "Inforce" && c.PremiumPayer != null && c.PremiumPayer == "Employee").ToList();
                            var employeePolicyModalPremiums = employeePolicy.Sum(c => c.ModalPremium);
                            offer.ProviderChoicePremiumSummary.ExistingCoverageVGSIPremiumAmt = employeePolicyModalPremiums != null ? employeePolicyModalPremiums.ToString() : null;

                            if (modalPremiums == 0 && employeePolicyModalPremiums != 0)
                            {
                                offer.ProviderChoicePremiumSummary.ExistingCoveragePremiumAmt = offer.ProviderChoicePremiumSummary.ExistingCoverageVGSIPremiumAmt;
                            }

                            if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingCoverageVGSIPremiumAmt))
                            {
                                inGroup.ProviderChoicePremiumsColumnNames.ExistingCoveragePremium =
                                    string.Format("Existing Coverage {0} Premium", modalValueDescription);
                            }

                            offer.ProviderChoicePremiumSummary.ExistingAnnualCoveragePremiumAmt = existingPolicydetail != null ? (existingPolicydetail.AnnualizedPremium != null ? existingPolicydetail.AnnualizedPremium.ToString() : "0.0") : "0.0";
                            if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.ExistingAnnualCoveragePremiumAmt))
                            {
                                inGroup.ProviderChoicePremiumsColumnNames.ExistingAnnualCoveragePremium =
                                    string.Format("Existing Coverage Annual Premium");
                            }

                        }
                    }
                }

                if (isRPPBnP)
                {
                    offer.ProviderChoicePremiumSummary.GSIPlusAMBTotalBenefitAmt = ((inPart.Participant.RPPPlusAMBTotalBaseBenefitAmount != null ? inPart.Participant.RPPPlusAMBTotalBaseBenefitAmount : 0) +
                                                                                    (inPart.Participant.ExistingIDICalculatedAmount != null ? inPart.Participant.ExistingIDICalculatedAmount : 0)).ToString();
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.GSIPlusAMBTotalBenefitAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.GSIPlusAMBTotalBenefit =
                            string.Format("GSI Plus AMB Total Benefit");
                    }
                }
                else
                {
                    if (isVGSI)
                    {
                        offer.ProviderChoicePremiumSummary.GSIPlusAMBTotalBenefitAmt = ((inPart.Participant.VGSIBuyUpAMBCalculatedAmount != null ? inPart.Participant.VGSIBuyUpAMBCalculatedAmount : 0) +
                                                                                        (inPart.Participant.BaseAMBCalculatedAmount != null ? inPart.Participant.BaseAMBCalculatedAmount : 0) +
                                                                                        (inPart.Participant.ExistingIDICalculatedAmount != null ? inPart.Participant.ExistingIDICalculatedAmount : 0)).ToString();
                    }
                    else
                    {
                        offer.ProviderChoicePremiumSummary.GSIPlusAMBTotalBenefitAmt = ((inPart.Participant.BaseAMBCalculatedAmount != null ? inPart.Participant.BaseAMBCalculatedAmount : 0) +
                                                                                        (inPart.Participant.ExistingIDICalculatedAmount != null ? inPart.Participant.ExistingIDICalculatedAmount : 0)).ToString();
                    }
                    if (!string.IsNullOrEmpty(offer.ProviderChoicePremiumSummary.GSIPlusAMBTotalBenefitAmt))
                    {
                        inGroup.ProviderChoicePremiumsColumnNames.GSIPlusAMBTotalBenefit =
                            string.Format("GSI Plus AMB Total Benefit");
                    }
                }
            }

        }
        private static void CreateTotalProviderChoicePremiumSummaryXML(EnrollmentKitXml.ExtreamGenerationParticipantOfferXml offer, EnrollmentKitXml.ExtreamGenerationParticipantInOfferXml workingParticipant, EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml workingOffer)
        {
            if (offer.TotalProviderChoicePremiumSummaries == null)
            {
                offer.TotalProviderChoicePremiumSummaries = new EnrollmentKitXml.ExstreamGenerationTotalProviderChoicePremiumSummaries();
            }

            offer.TotalProviderChoicePremiumSummaries.TotalExistingCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalexistingCoverageVGSIPremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingCoverageVGSIPremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalexistingCoverageVGSIPremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalExistingAnnualCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingAnnualCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingAnnualCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedAnnualCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedAnnualCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedAnnualCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedCoverageEmployeePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedCoverageEmployeePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedCoverageEmployeePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedCoverageEmployerPremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedCoverageEmployerPremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedCoverageEmployerPremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedCoverageAnnualEmployeePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedCoverageAnnualEmployeePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedCoverageAnnualEmployeePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedCoverageAnnualEmployerPremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedCoverageAnnualEmployerPremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedCoverageAnnualEmployerPremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedERPaidCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedERPaidCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedERPaidCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedERPaidAnnualCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedERPaidAnnualCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedERPaidAnnualCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedVGSIBuyUpCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedVGSIBuyUpCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedVGSIBuyUpCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalProposedVGSIBuyUpAnnualCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ProposedVGSIBuyUpAnnualCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalProposedVGSIBuyUpAnnualCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalExistingCoverageEmployeePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingCoverageEmployeePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingCoverageEmployeePremiumAmt) ?? "$0.00";
            offer.TotalProviderChoicePremiumSummaries.TotalExistingCoverageEmployerPremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingCoverageEmployerPremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingCoverageEmployerPremiumAmt) ?? "$0.00";
            offer.TotalProviderChoicePremiumSummaries.TotalExistingCoverageAnnualEmployeePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingCoverageAnnualEmployeePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingCoverageAnnualEmployeePremiumAmt) ?? "$0.00";
            offer.TotalProviderChoicePremiumSummaries.TotalExistingCoverageAnnualEmployerPremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingCoverageAnnualEmployerPremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingCoverageAnnualEmployerPremiumAmt) ?? "$0.00";
            offer.TotalProviderChoicePremiumSummaries.TotalExistingERPaidCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingERPaidCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingERPaidCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalExistingERPaidAnnualCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingERPaidAnnualCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingERPaidAnnualCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalExistingVGSIBuyUpCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingVGSIBuyUpCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingVGSIBuyUpCoveragePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalExistingVGSIBuyUpAnnualCoveragePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingVGSIBuyUpAnnualCoveragePremiumAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingVGSIBuyUpAnnualCoveragePremiumAmt);

            //added as per MCRT-2330
            offer.TotalProviderChoicePremiumSummaries.TotalExistingCoveragePremiumSummaryAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.ExistingCoveragePremiumSummaryAmt, offer.TotalProviderChoicePremiumSummaries.TotalExistingCoveragePremiumSummaryAmt);
            offer.TotalProviderChoicePremiumSummaries.TotalGSIPlusAMBTotalBenefitAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.GSIPlusAMBTotalBenefitAmt, offer.TotalProviderChoicePremiumSummaries.TotalGSIPlusAMBTotalBenefitAmt);
            //offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBModalPremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.TotalPlusAMBModalPremiumAmt, offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBModalPremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBModalEmployeePremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.TotalPlusAMBModalEmployeePremiumAmt, offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBModalEmployeePremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBERPaidModalPremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.TotalPlusAMBERPaidModalPremiumAmt, offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBERPaidModalPremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBVGSIBuyUpModalPremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.TotalPlusAMBVGSIBuyUpModalPremiumAmt, offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBVGSIBuyUpModalPremiumAmt);
            offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBModalEmployerPremiumAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.TotalPlusAMBModalEmployerPremiumAmt, offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBModalEmployerPremiumAmt);
            // offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBPremiumPerPaycheckAmt = SummarizeTotals(workingOffer?.ProviderChoicePremiumSummary?.TotalPlusAMBPremiumPerPaycheckAmt, offer.TotalProviderChoicePremiumSummaries.GrandTotalPlusAMBPremiumPerPaycheckAmt);
        }

        private static void CreateTotalInsurableIncomeXML(EnrollmentKitXml.ExtreamGenerationParticipantOfferXml participantOffer, EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml offer)
        {
            if (participantOffer.TotalInsurableIncomes == null)
            {
                participantOffer.TotalInsurableIncomes = new EnrollmentKitXml.ExstreamGenerationTotalInsurableIncomes();
            }

            participantOffer.TotalInsurableIncomes.InsurableIncomeTotalSalaryAmt = SummarizeTotals(offer?.InsurableIncomes.TotalSalaryAmt, participantOffer.TotalInsurableIncomes.InsurableIncomeTotalSalaryAmt);
            participantOffer.TotalInsurableIncomes.InsurableIncomeTotalERPaidGSIBaseAmt = SummarizeTotals(offer?.InsurableIncomes.TotalERPaidGSIBaseAmt, participantOffer.TotalInsurableIncomes.InsurableIncomeTotalERPaidGSIBaseAmt);
            participantOffer.TotalInsurableIncomes.InsurableIncomeTotalVGSIBuyUpAmt = SummarizeTotals(offer?.InsurableIncomes.TotalVGSIBuyUpAmt, participantOffer.TotalInsurableIncomes.InsurableIncomeTotalVGSIBuyUpAmt);
            participantOffer.TotalInsurableIncomes.InsurableIncomeTotalOtherIncomeAmt = SummarizeTotals(offer?.InsurableIncomes.TotalOtherIncomeAmt, participantOffer.TotalInsurableIncomes.InsurableIncomeTotalOtherIncomeAmt);
            participantOffer.TotalInsurableIncomes.InsurableIncomeGrandTotalAmt = SummarizeTotals(offer?.InsurableIncomes.GrandTotalAmt, participantOffer.TotalInsurableIncomes.InsurableIncomeGrandTotalAmt);
        }
        private static void CreateTotalBenefitSummaryXML(EnrollmentKitXml.ExtreamGenerationParticipantOfferXml offer, EnrollmentKitXml.ExtreamGenerationQualifiedOfferXml workingOffer, EnrollmentKitXml mldiCase)
        {
            if (offer.TotalGLTDAndIDIBenefitSummaries == null)
            {
                offer.TotalGLTDAndIDIBenefitSummaries = new EnrollmentKitXml.ExstreamGenerationTotalGLTDandIDITotalBenefitSummaries();
            }

            offer.TotalGLTDAndIDIBenefitSummaries.TotalGLTDBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.GLTDBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalGLTDBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalGLTDPlusIDIAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.TotalGLTDPlusIDIAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalGLTDPlusIDIAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalGSIBaseBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.GSIBaseBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalGSIBaseBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingIDICoverageAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingIDICoverageAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingIDICoverageAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalERPaidGSIBaseBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ERPaidGSIBaseBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalERPaidGSIBaseBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalBuyUpGSIBaseBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.VolGSIBaseBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalBuyUpGSIBaseBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalBasicCATAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.BasicCATAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalBasicCATAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSIBasicCATAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.VGSIBasicCATAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSIBasicCATAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalEnhancedCATAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.EnhancedCATAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalEnhancedCATAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSIEnhancedCATAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.VGSIEnhancedCATAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSIEnhancedCATAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalRPPBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.RPPBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalRPPBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSIRPPBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.VGSIRPPBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSIRPPBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalSBTBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.SBTBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalSBTBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSISBTBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.VGSISBTBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSISBTBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalSLRBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.SLRBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalSLRBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSISLRBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.VGSISLRBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalVGSISLRBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalAnnualRetirementContributionsAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.AnnualRetirementContributionsAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalAnnualRetirementContributionsAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingRppProgramCoverageAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingRppProgramCoverageAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingRppProgramCoverageAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalRppBaseBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.RppBaseBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalRppBaseBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedRppAmbBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ProposedRppAmbBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedRppAmbBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalRppReplacePercentAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.RppReplacePercentAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalRppReplacePercentAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingGSIBaseBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingGSIBaseBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingGSIBaseBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingERPaidGSIBaseBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingERPaidGSIBaseBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingERPaidGSIBaseBenefitAmt);

            var isOption1 = offer.cmsStandardOfferCode.Contains("Option 1");
            if (!isOption1 && mldiCase.ExstreamRequestType == "BenefitPremium")
            {
                offer.TotalGLTDAndIDIBenefitSummaries.TotalVolGSIBaseBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.VolGSIBaseBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalVolGSIBaseBenefitAmt);
            }
            offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedERPaidAMBRiderAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ProposedERPaidAMBRiderAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedERPaidAMBRiderAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedBuyUpAMBRiderAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ProposedVGSIBuyUpAMBRiderAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedBuyUpAMBRiderAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedAMBRiderAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ProposedAMBRiderAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedAMBRiderAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalIDIAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.TotalIDIAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalIDIAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalIDIPercentAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.TotalIDIPercentAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalIDIPercentAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingBasicCATAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingBasicCATAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingBasicCATAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingEnhancedCATAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingEnhancedCATAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingEnhancedCATAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingRPPMonthlyBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingRPPMonthlyBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingRPPMonthlyBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingSLRBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingSLRBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingSLRBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingSBTBenefitAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingSBTBenefitAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingSBTBenefitAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedVGSIBuyUpAMBRiderAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ProposedVGSIBuyUpAMBRiderAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalProposedVGSIBuyUpAMBRiderAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingVGSIBuyUpProgramCoverageAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.ExistingVGSIBuyUpProgramCoverageAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalExistingVGSIBuyUpProgramCoverageAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalGLTDReplacePercentAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.GLTDReplacePercentAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalGLTDReplacePercentAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalIDIBaseReplacePercentAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.IDIBaseReplacePercentAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalIDIBaseReplacePercentAmt);
            offer.TotalGLTDAndIDIBenefitSummaries.TotalGLTDPlusIDIPercentAmt = SummarizeTotals(workingOffer?.GLTDandIDIBenefitSummary?.TotalGLTDPlusIDIPercentAmt, offer.TotalGLTDAndIDIBenefitSummaries.TotalGLTDPlusIDIPercentAmt);
        }

        private static string SummarizeTotals(string inOffer, string inTotal)
        {
            double workingOffer = Double.MinValue;
            double workingTotal = Double.MinValue;

            if (string.IsNullOrEmpty(inOffer))
            {
                return inTotal;
            }

            double.TryParse(inOffer, out workingOffer);

            double.TryParse(inTotal, out workingTotal);

            workingTotal = workingTotal + workingOffer;
            return workingTotal.ToString("N", new CultureInfo("en-US"));

        }

        private static void CreateIneligibleParticipantsXml(EnrollmentKitXml inCase, IQueryable<EnrollmentParticipant> inEligibleParticipants)
        {
            if (inCase.IneligibleParticipant == null)
            {
                inCase.IneligibleParticipant = new List<EnrollmentKitXml.ExtreamGenerationInEligibleParticipantXml>();
            }

            foreach (var ie in inEligibleParticipants)
            {
                var inEligibleParticipant = new EnrollmentKitXml.ExtreamGenerationInEligibleParticipantXml();
                inEligibleParticipant.Employee = string.Format("{0} {1}", ie.Participant.FirstName, ie.Participant.LastName);
                inEligibleParticipant.Gender = ie.Participant.Gender;
                inEligibleParticipant.IssueAge = ie.Participant.Age.ToString();
                inEligibleParticipant.JobTitle = ie.Participant.JobTitle;
                inEligibleParticipant.Reason = ie.Participant.IneligibleReason;
                inCase.IneligibleParticipant.Add(inEligibleParticipant);
            }

        }
        private static string DecimaltoPercentage(string value)
        {
            decimal percentage = 0;
            decimal inputvalu = value != null && value != string.Empty ? Convert.ToDecimal(value) : 0m;
            if (inputvalu > 0)
            {

                percentage = inputvalu * 100;
                percentage = Math.Round(percentage, 2);
            }

            return percentage.ToString();

        }

        private static string GetSoldPlanDesignDescription(PDRSoldClassPlan pdrSoldClass)
        {
            Log.TraceFormat("+GetSoldPlanDesignDescription");
            string planDesign = string.Empty;

            if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.SupplementalPlan)
            {
                var percentage = CreatePercentage(pdrSoldClass.MaximumReplacementRatio);
                planDesign = percentage + "% less LTD";
            }
            else if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.BonusOnlyPlan)
            {
                var percentage = CreatePercentage(pdrSoldClass.MaximumReplacementRatio);
                planDesign = percentage + "% of Variable Compensation";
            }
            else if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.CombinationPlan)
            {
                var ltdPercentage = CreatePercentage(pdrSoldClass.LTDPercentage);
                var idiPercentage = CreatePercentage(pdrSoldClass.IDIPercentage);
                planDesign = ltdPercentage + "% LTD/" + idiPercentage + "% IDI";
            }
            else if (pdrSoldClass.PlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan)
            {
                planDesign = pdrSoldClass.FlatRateType.Id == 99 ? pdrSoldClass.FlatRate_Other.ToString() : pdrSoldClass.FlatRateType.Name;
            }
            Log.TraceFormat("-GetSoldPlanDesignDescription");
            return planDesign;
        }

        public string GetContractState(EnrollmentParticipant enrollmentParticipant, CaseUnderwritingRequest underWritingRequest)
        {
            string state = string.Empty;
            if (enrollmentParticipant != null && enrollmentParticipant.Participant == null)
            {
                Log.TraceFormat("EnrollmentKitAdditionalData - partValues.Participant is null");
            }

            if (underWritingRequest == null)
            {
                Log.TraceFormat("EnrollmentKitAdditionalData - situsType is Null");
            }


            Log.TraceFormat("EnrollmentKitAdditionalData - Situs Type [{0}]", underWritingRequest.SitusType);

            switch (underWritingRequest.SitusType)
            {
                case SitusTypeEnum.Corporate:
                    state = underWritingRequest.StateType != null ? underWritingRequest.StateType.ToString() : "";
                    Log.TraceFormat("EnrollmentKitAdditionalData - Corporate State [{0}]", state);
                    break;
                case SitusTypeEnum.Residence:
                    state = enrollmentParticipant != null && enrollmentParticipant.Participant != null ? enrollmentParticipant.Participant.HomeState.ToString() : "";
                    Log.TraceFormat("EnrollmentKitAdditionalData - Residence State [{0}]", state);
                    break;
                case SitusTypeEnum.Multi_State:
                    if (underWritingRequest.StateType != null)
                    {
                        if ((underWritingRequest.SitusMultiState1Type != null && underWritingRequest.SitusMultiState1Type == enrollmentParticipant.Participant.HomeState) ||
                             (underWritingRequest.SitusMultiState2Type != null && underWritingRequest.SitusMultiState2Type == enrollmentParticipant.Participant.HomeState) ||
                              (underWritingRequest.SitusMultiState3Type != null && underWritingRequest.SitusMultiState3Type == enrollmentParticipant.Participant.HomeState))
                        {
                            state = enrollmentParticipant.Participant.HomeState != null ? ((StateTypeEnum)((int)enrollmentParticipant.Participant.HomeState)).ToString() :
                                        !string.IsNullOrWhiteSpace(enrollmentParticipant.Participant.HomeStateDescription) ? enrollmentParticipant.Participant.HomeStateDescription : "";
                            Log.TraceFormat("EnrollmentKitAdditionalData - MultiState NOT Use Corp State [{0}]", state);
                        }
                        else
                        {
                            state = underWritingRequest.StateType.ToString();
                            Log.TraceFormat("EnrollmentKitAdditionalData - MultiState Use Corp State [{0}]", state);
                        }
                    }
                    else
                    {
                        state = underWritingRequest.StateType.ToString();
                        Log.TraceFormat("EnrollmentKitAdditionalData - MultiState Use Corp State [{0}]", state);
                    }
                    break;
                default:
                    state = enrollmentParticipant != null && enrollmentParticipant.Participant != null ? enrollmentParticipant.Participant.HomeState.ToString() : "";
                    Log.TraceFormat("EnrollmentKitAdditionalData - Default State [{0}]", state);
                    break;
            }

            return state;
        }

        private static int CreatePercentage(decimal? inDecimal)
        {
            int percentage = 0;
            if (inDecimal != null)
            {
                percentage = (int)inDecimal;

            }

            return percentage;
        }

        private static string GetMaximumIPDescription(PDRSoldClassPlan pdrSoldClassPlan)
        {
            string maximumIPDescription = string.Empty;

            ParticipationLimitMaximumCalculator participationLimitMaximumCalculator = new ParticipationLimitMaximumCalculator();
            IssueLimitMaximumCalculator issueLimitMaximumCalculator = new IssueLimitMaximumCalculator();
            BenefitAmountsCalculationRequest request = new BenefitAmountsCalculationRequest();

            decimal? issueLimitMaximum = null;
            decimal? participationLimitMaximum = null;

            request.ExistingIDIAmount = 0.0m;
            request.ClassCalculationRequest.PlanDesignType = pdrSoldClassPlan.PlanDesignType;

            issueLimitMaximum = issueLimitMaximumCalculator.Calculate(request);
            participationLimitMaximum = participationLimitMaximumCalculator.Calculate(request);

            maximumIPDescription = string.Format("{0:C2}", issueLimitMaximum) + " / " + string.Format("{0:C2}", participationLimitMaximum);

            if (pdrSoldClassPlan.PlanDesignType != null && pdrSoldClassPlan.PlanDesignType == PlanDesignTypeEnum.StandAloneIDIPlan)
            {
                maximumIPDescription = "$20,000 IDI";
            }

            return maximumIPDescription;
        }
    }
}