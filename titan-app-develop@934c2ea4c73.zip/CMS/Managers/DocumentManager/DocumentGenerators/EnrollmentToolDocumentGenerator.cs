﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using Logger.Static;
using System.Linq;
using CMS.Model.Entities;
using CMS.Interfaces.Managers.WorkUnitManagers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using Common.Utilities;
using CMS.Model.Enums;
using CMS.Managers.DocumentManagers.DocumentGenerators;
using Guardian.Core.Entities.Product.Enums;
using CMS.Interfaces.Managers.ProductLibraryManagers;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class EnrollmentToolDocumentGenerator : DocumentGenerator, IEnrollmentToolDocumentGenerator, IWorkUnitHandler
    {
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public EnrollmentToolDocumentGenerator(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager,
             IProductLibraryManager productLibraryManager) : base(unitOfWorkFactory, productLibraryManager)
        {
            _workUnitManager = workUnitManager;
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public void EnqueueRequest(CaseCommonXmlGenerationRequest request)
        {
            Log.TraceFormat("+EnqueueRequest");

            _workUnitManager.CreateWorkUnit(WorkUnitType.EnrollmentTool, JsonConvert.SerializeObject(request));

            Log.TraceFormat("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.TraceFormat("+Execute");

            var request = JsonConvert.DeserializeObject<CaseCommonXmlGenerationRequest>(workUnit.InputData);

            var commonXmlBuilder = new CaseCommonXmlBuilder(UnitOfWorkFactory);

            var enrollmentToolXml = new EnrollmentToolXml();

            commonXmlBuilder.CreateCase(request, enrollmentToolXml, enrollmentToolXml.ExstreamRequestType);

            //BuildAdditionalFields(request.EnrollmentId, enrollmentToolXml);

            var kitAddOns = new EnrollmentKitAdditionalData(UnitOfWorkFactory);

            var requestEnrl = new EnrollmentKitXmlGenerationRequest();
            requestEnrl.CaseId = request.CaseId;
            requestEnrl.EnrollmentId = request.EnrollmentId;
            var enrlXml = new EnrollmentKitXml();
            var enrlSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace, };
            var enrlPart = JsonConvert.SerializeObject(enrollmentToolXml, enrlSettings);
            enrlXml = JsonConvert.DeserializeObject<EnrollmentKitXml>(enrlPart);
            requestEnrl.SelectedForms = new List<EnrollmentKitTypeEnum>();

            kitAddOns.AddEnrollmentData(requestEnrl, enrlXml);

            var serializedXml = SerializeObject(enrlXml);

            var updatedXMLEnrollmentTool = RemoveAMBRRiderTagsFromXML(serializedXml);

            CreateDocument(request, updatedXMLEnrollmentTool);

            Log.TraceFormat("-Execute");
        }


        private EnrollmentToolDocumentRequest BuildAdditionalFields(int enrollmentId, EnrollmentToolDocumentRequest enrollmentToolXml)
        {
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(ep => ep.Enrollment.Id == enrollmentId).ToList();

                var groups = new List<MLDIGroup>();

                foreach (var grp in enrollmentToolXml.groups)
                {
                    var mldiGroup = new MLDIGroup();
                    mldiGroup.cmsCode = grp.cmsCode;
                    mldiGroup.groupDescription = grp.groupDescription;
                    mldiGroup.groupName = grp.groupName;
                    mldiGroup.eligibleParticipants = new List<MLDIParticipant>();

                    foreach (var eligibleparticipant in grp.eligibleParticipants)
                    {
                        var ep = enrollmentParticipants.FirstOrDefault(c => c.Id.ToString() == eligibleparticipant.cmsCode);
                        if (ep != null)
                        {
                            string riskClassTobaccoStatus = string.Empty;
                            var participantExistingPolicyDetail = unitOfWork.Repository<ParticipantExistingPolicyDetail>().Linq().Where(q => q.ParticipantExistingPolicy.Participant.Id == ep.Participant.Id);
                            var epp = unitOfWork.Repository<EnrollmentParticipantPolicy>().Linq().FirstOrDefault(q => q.EnrollmentParticipant.Id.ToString() == eligibleparticipant.cmsCode);
                            if (participantExistingPolicyDetail.Any())
                            {
                                var participantExistingPolicyInfo = participantExistingPolicyDetail.FirstOrDefault(q => q.CLOASPolicyStatus == "Inforce" && q.CaseNumber == ep.Enrollment.Case.CaseNumber);
                                riskClassTobaccoStatus = participantExistingPolicyInfo != null ? participantExistingPolicyInfo.RiskClassTobaccoStatus : string.Empty;
                            }
                            var p = new EntrollmentToolGroupsParticipant();
                            p.cmsCode = eligibleparticipant.cmsCode;
                            p.cmsStatus = eligibleparticipant.cmsStatus;
                            p.ContactProducerCmsCode = eligibleparticipant.ContactProducerCmsCode;
                            p.effectiveDate = eligibleparticipant.effectiveDate;
                            p.dateOfBirth = eligibleparticipant.dateOfBirth;
                            p.employeeID = ep.Participant.EmployeeId;
                            p.personalInformation = eligibleparticipant.personalInformation;
                            p.occupationDetails = eligibleparticipant.occupationDetails;
                            p.currentLTDs = eligibleparticipant.currentLTDs;
                            p.existingPolicyNumber = epp != null ? epp.PolicyNumber : "";
                            p.ExistingTobaccoStatus = riskClassTobaccoStatus;
                            p.gender = eligibleparticipant.gender;
                            p.incomeDetails = eligibleparticipant.incomeDetails;
                            p.isMockEmployee = eligibleparticipant.isMockEmployee;
                            p.offers = eligibleparticipant.offers;
                            p.servicingProducerCmsCode = eligibleparticipant.servicingProducerCmsCode;
                            p.signingProducerCmsCode = eligibleparticipant.signingProducerCmsCode;
                            p.temporaryPassword = eligibleparticipant.temporaryPassword;
                            p.phoneNumber = ep.Participant.WorkLocationPhone;

                            p.emailAddress = ep.Participant.WorkEmail;

                            //var epop = unitOfWork.Repository<EnrollmentParticipantOptionPlan>().Linq().FirstOrDefault(a => a.EnrollmentParticipant.Id.ToString() == eligibleparticipant.cmsCode);
                            //if (epop.BenefitPeriod != null)
                            //{
                            //    if (epop.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                            //    {
                            //        p.benefitPeriodAge = 65;
                            //    }
                            //    else if (epop.BenefitPeriod == BenefitPeriodTypeEnum.A67)
                            //    {
                            //        p.benefitPeriodAge = 67;
                            //    }
                            //    else if (epop.BenefitPeriod == BenefitPeriodTypeEnum.V70)
                            //    {
                            //        p.benefitPeriodAge = 70;
                            //    }
                            //    else if (epop.BenefitPeriod == BenefitPeriodTypeEnum.Y02)
                            //    {
                            //        p.benefitPeriodYears = 2;
                            //    }
                            //    else if (epop.BenefitPeriod == BenefitPeriodTypeEnum.Y05)
                            //    {
                            //        p.benefitPeriodYears = 5;
                            //    }
                            //    else if (epop.BenefitPeriod == BenefitPeriodTypeEnum.Y10)
                            //    {
                            //        p.benefitPeriodYears = 10;
                            //    }
                            //    else if (epop.BenefitPeriod == BenefitPeriodTypeEnum.Y01)
                            //    {
                            //        p.benefitPeriodYears = 1;
                            //    }
                            //}
                            p.payrollDeductionPeriod = ep.Participant.BenefitDeductionFrequencyDescription;
                            //p.baseMonthlyBenefit = epop.BenefitAmountBaseMonthly;
                            mldiGroup.eligibleParticipants.Add(p);
                        }
                    }
                    groups.Add(mldiGroup);
                }

                enrollmentToolXml.groups = groups;

                return enrollmentToolXml;
            }

        }

        private void CreateDocument(CaseCommonXmlGenerationRequest request, string serializedXml)
        {
            Log.TraceFormat("+CreateDocument");

            var cmsCase = GetCase(request.CaseId);

            var caseDocumentRequest = CreateCaseDocumentRequest(serializedXml, cmsCase, CaseDocumentTypeEnum.EnrollmentTool);
            var casePDFDocument = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.EnrollmentTool, ExtreamDocumentType.PDF, null, request.EnrollmentToolName);
            var caseXLSDocument = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.EnrollmentTool, ExtreamDocumentType.CSV, null, request.EnrollmentToolName);

            StoreDocumentIdsToDatabase(request, casePDFDocument, caseXLSDocument);

            _workUnitManager.CreateWorkUnit(WorkUnitType.ExtreamFileUpload, caseDocumentRequest.Id.ToString());

            Log.TraceFormat("-CreateDocument");
        }

        private void StoreDocumentIdsToDatabase(CaseCommonXmlGenerationRequest request, CaseDocument casePDFDocument, CaseDocument caseXLSDocument)
        {
            Log.TraceFormat("+StoreDocumentIdsToDatabase");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentTool = unitOfWork.Repository<EnrollmentTool>().Linq().FirstOrDefault(et => et.Id == request.RequestId);
                if (enrollmentTool != null)
                {
                    enrollmentTool.PdfDocument = casePDFDocument;
                    enrollmentTool.ExcelDocument = caseXLSDocument;

                    unitOfWork.Repository<EnrollmentTool>().Save(enrollmentTool);
                    unitOfWork.Commit();
                }
            }
            Log.TraceFormat("-StoreDocumentIdsToDatabase");
        }


    }

}
