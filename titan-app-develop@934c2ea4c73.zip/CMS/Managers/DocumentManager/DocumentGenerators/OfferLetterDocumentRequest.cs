﻿using System.Collections.Generic;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class OfferLetterDocumentRequest
    {
        public string CaseNumber { get; set; }
        public string CompanyName { get; set; }
        public string EffectiveDate { get; set; }
        public string BrokerName { get; set; }
        public string PresentedBy { get; set; }
        public string SICCode { get; set; }
        public string CarrierName { get; set; }
        public bool GuaranteedIssueFlag { get; set; }
        public bool EmployerOwnerFlag { get; set; }
        public bool VGSICase { get; set; }
        public bool? ERISAInd { get; set; }
        public bool UseCompactApp { get; set; }
        public string PDRNumber { get; set; }
        public List<OfferletterOptionRequest> OfferletterOptionRequest { get; set; }
    }

    public class OfferletterOptionRequest
    {
        public int OfferLetterOption { get; set; }
        public int IllustrationId { get; set; }
        public string IllustrationName { get; set; }
        public bool Is5to9CaseInd { get; set; } 
        public bool IncludeIneligibleParticipants { get; set; }
        public string TotalPlus90 { get; set; }
        public List<OfferLetterDocumentClassRequest> Classes { get; set; }

        public OfferletterOptionRequest()
        {
            Classes = new List<OfferLetterDocumentClassRequest>();
        }
    }

    public class OfferLetterDocumentClassRequest
    {
        public string ClassName { get; set; }
        public string OSEIndicator { get; set; }
        public decimal MaxGSIOffer { get; set; }
        public decimal VGBPMaxGSIOffer { get; set; }
        public int? TotalCombinedGSI { get; set; }
        public decimal TotalMaxGSI { get; set; }
        public string DefinitionOfDisability { get; set; }
        public string VGBPDefinitionOfDisability { get; set; }
        public string EliminationPeriod { get; set; }
        public string VGBPEliminationPeriod { get; set; }
        public string BenefitPeriod { get; set; }
        public string VGBPBenefitPeriod { get; set; }
        public string MentalSubstance { get; set; }
        public string BPMentalSubstance { get; set; }
        public string RiderCount { get; set; }
        public string VGBPRiderCount { get; set; }
        public List<ClassRider> Riders { get; set; }
        public List<ClassRider> VGBPRiders { get; set; }
        public string CostSharePercentage { get; set; }
        public string CostSharePremiumAmount { get; set; }
        public string CostShareTaxable { get; set; }
        public string PlanDesignType { get; set; }
        public string VGBPPlanDesignType { get; set; }
        public string PlanDesign { get; set; }
        public string VGBPPlanDesign { get; set; }
        public string GSIPremiumPayer { get; set; }
        public string IDIInsurableIncome { get; set; }
        public string VGBPInsurableIncome { get; set; }
        public string MaximumIp { get; set; }
        public string BPMaximumIp { get; set; }
        public string ParticipantionRequired { get; set; }
        public string BPParticipantionRequired { get; set; }
        public string CaseLevelDiscountPercentage { get; set; }
        public string VGSICaseLevelDiscountPercentage { get; set; }
        public string CorporateSitus { get; set; }
        public bool IsGroupLTDDesign { get; set; }
        public string PercentOfBaseSalary { get; set; }
        public string BaseSalary { get; set; }
        public string MaxSalaryK { get; set; }
        public string GroupLTDPremiumPayer { get; set; }
        public string EligibleEmployees { get; set; }
        public string PrexCondition { get; set; }
        public string VGBPPrexCondition { get; set; }
        public string MaxReplacementPercent { get; set; }
        public string VGBPMaxReplacementPercent { get; set; }
        public string RPPBenefitAmt { get; set; }
        public string RetirmentContributionsAmt { get; set; }
        public string RPPBasePremiumPercentAmt { get; set; }
        public string CreationDate { get; set; }
        public string EnrollmentManager { get; set; }
       
    }

    public class ClassRider
    {
        public string RiderFullName { get; set; }
        public string RiderEP { get; set; }
        public string RiderBT { get; set; }
        public string RiderBenefitAmt { get; set; }
    }

    #region TitanLetterRequest
    //public class Titan_Letter_Request
    //{
    //    public string companyNameField { get; set; }
    //    public string companyAddressLine1Field { get; set; }
    //    public string companyAddressLine2Field { get; set; }
    //    public string companyAddressLine3Field { get; set; }
    //    public string companyAddressLine4Field { get; set; }
    //    public string brokerNameField { get; set; }
    //    public string caseNumberField { get; set; }
    //    public string programTypeField { get; set; }
    //    public string issueStateField { get; set; }
    //    public string offerLetterContractFlagField { get; set; }
    //    public string offerLetterContractAddendumFlagField { get; set; }
    //    public Titan_Letter_RequestOfferLetterContractOfferProposal offerLetterContractOfferProposalField { get; set; }
    //    public Titan_Letter_RequestOfferLetterContractAcceptance offerLetterContractAcceptanceField { get; set; }
    //    public string todayPlus90DateField { get; set; }
    //    public string offer1Field { get; set; }
    //    public string offer1DescriptionField { get; set; }
    //    public string offer2Field { get; set; }
    //    public string offer2DescriptionField { get; set; }
    //    public string offer3Field { get; set; }
    //    public string offer3DescriptionField { get; set; }
    //    public Titan_Letter_RequestOfferWithdrawalLetter offerWithdrawalLetterField { get; set; }
    //    public Titan_Letter_RequestRenewalLetter renewalLetterField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferLetterContractOfferProposal
    //{
    //    public string classNameField { get; set; }
    //    public string planDesignField { get; set; }
    //    public string maximumIncomeReplacementPercentageField { get; set; }
    //    public Titan_Letter_RequestOfferLetterContractOfferProposalClassesMaximumIssueandParticipationLimits maximumIssueandParticipationLimitsField { get; set; }
    //    public string eliminatiionPeriodField { get; set; }
    //    public string benefitPeriodField { get; set; }
    //    public Titan_Letter_RequestOfferLetterContractOfferProposalClassesDiscounts discountsField { get; set; }
    //    public Titan_Letter_RequestOfferLetterContractOfferProposalClassesGroupLTDPlan groupLTDPlanField { get; set; }
    //    public Titan_Letter_RequestOfferLetterContractOfferProposalClassesEmployerEmployeePaid employerEmployeePaidField { get; set; }
    //    public string eligibleEmployeesCountField { get; set; }
    //    public string definitionofDisabilityField { get; set; }
    //    public Titan_Letter_RequestOfferLetterContractOfferProposalClassesCostRidersIncluded costRidersIncludedField { get; set; }
    //    public string seriousIllnessRiderFlagField { get; set; }
    //    public Titan_Letter_RequestOfferLetterContractOfferProposalClassesExclusionsLimitations exclusionsLimitationsField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferLetterContractOfferProposalClassesMaximumIssueandParticipationLimits
    //{
    //    public string maxIDIAmtField { get; set; }
    //    public string maxGLTDComboAmtField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferLetterContractOfferProposalClassesDiscounts
    //{
    //    public string nonNicotineDiscountField { get; set; }
    //    public string mentalSubstanceDiscountField { get; set; }
    //    public string caseLevelDiscountField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferLetterContractOfferProposalClassesGroupLTDPlan

    //{
    //    public string groupTaxNonTaxLTDPercentField { get; set; }
    //    public string groupLTDBuyUpPercentField { get; set; }
    //    public string baseSalaryTypeField { get; set; }
    //    public string k1IncomeFlagField { get; set; }
    //    public string w2IncomeFlagField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferLetterContractOfferProposalClassesEmployerEmployeePaid
    //{

    //    public string payTypeField { get; set; }
    //    public string payPercentageField { get; set; }
    //    public string taxabilityFlagField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferLetterContractOfferProposalClassesCostRidersIncluded
    //{

    //    public string disabilityBenefitRiderTypeField { get; set; }
    //    public string cOLATypeField { get; set; }
    //    public string cATTypeField { get; set; }
    //    public ushort cATBenefitAmtField { get; set; }
    //    public string lumpSumFlagField { get; set; }
    //    public string rPPFlagField { get; set; }
    //    public string rPPBenefitAmtField { get; set; }
    //    public string sLPFlagField { get; set; }
    //    public string sLPBenefitAmtField { get; set; }
    //    public string suppBenefitFlagField { get; set; }
    //    public string unemployWaiverPremiumFlagField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferLetterContractOfferProposalClassesExclusionsLimitations
    //{

    //    public string mNLimitationField { get; set; }
    //    public string extendedMNLimitationField { get; set; }
    //    public string pREXMonthPeriodField { get; set; }
    //    public string noPrexFlagField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferLetterContractAcceptance
    //{

    //    public string fiveNineLifeCasesFlagField { get; set; }
    //    public string medicalCasesFlagField { get; set; }
    //    public Titan_Letter_RequestOfferLetterContractAcceptanceReplacementTakeoverFlag replacementTakeoverFlagField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferLetterContractAcceptanceReplacementTakeoverFlag
    //{
    //    public string replacedCarrierNameField { get; set; }
    //    public string additionalOwnerFlagField { get; set; }
    //}
    //public class Titan_Letter_RequestOfferWithdrawalLetter
    //{
    //    public string withdrawalTypeField { get; set; }
    //    public string employeeParticipationFlagField { get; set; }
    //    public string persistancyFlagField { get; set; }
    //    public string claimHistoryFlagField { get; set; }
    //    public string programOfferAcceptanceDateField { get; set; }
    //    public string companyRepresentativeNameField { get; set; }
    //    public string underwriterNameField { get; set; }
    //    public string underwriterTitleField { get; set; }
    //}
    //public class Titan_Letter_RequestRenewalLetter
    //{
    //    public string renewalLetterDateField { get; set; }
    //    public string originalEffectiveDateField { get; set; }
    //    public string considersTextFlagField { get; set; }
    //    public string contactNameField { get; set; }
    //    public string contactPhoneField { get; set; }
    //    public string contactEmailField { get; set; }
    //}

    #endregion
}













