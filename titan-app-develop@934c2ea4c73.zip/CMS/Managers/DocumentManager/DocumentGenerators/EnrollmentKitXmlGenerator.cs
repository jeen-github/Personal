﻿using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Logger.Static;
using Newtonsoft.Json;
using Common.Utilities;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Interfaces.Managers.ImplementationManagers;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class EnrollmentKitXmlGenerator : DocumentGenerator, IEnrollmentKitXmlGenerator, IWorkUnitHandler
    {
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IPolicyNumberGenerationManager _policyNumberGenerationManager;
        

        public EnrollmentKitXmlGenerator(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager,            
            IProductLibraryManager productLibraryManager, IPolicyNumberGenerationManager policyNumberGenerationManager) : base(unitOfWorkFactory, productLibraryManager)
        {
            _workUnitManager = workUnitManager;
            _policyNumberGenerationManager = policyNumberGenerationManager;         
        }

        public void EnqueueRequest(EnrollmentKitXmlGenerationRequest request)
        {
            Log.TraceFormat("+EnqueueRequest");
            var splittedParticipantsIds = request.ParticipantIds.ChunkBy(1000);

            foreach (var item in splittedParticipantsIds)
            {
                if (request.ParticipantIds.Count > 0)
                {
                    request.ParticipantIds.RemoveAll(c => c != -1);
                }
                request.ParticipantIds.AddRange(item);
                if (request.IsDirectCoverageEnrollment)
                {
                    if (request.SitusState == StateTypeEnum.CA || request.SitusState == StateTypeEnum.FL)
                    {
                        _workUnitManager.CreateWorkUnit(WorkUnitType.EnrollmentKit, JsonConvert.SerializeObject(request));
                    }
                }
                else
                {
                    _workUnitManager.CreateWorkUnit(WorkUnitType.EnrollmentKit, JsonConvert.SerializeObject(request));
                }
               
                if (request.IsDirectCoverageEnrollment || request.IsOneStepEnrollment)
                { 
                    var policyGenerationRequest = new PolicyGenerationRequestDto()
                        {
                            CaseId = request.CaseId,                           
                            EnrollmentId = request.EnrollmentId,                            
                            SelectedEnrollmentParticipantIds = request.ParticipantIds,
                            GeneratedBy = request.GeneratedBy,
                            SitusState= request.SitusState,
                            IsDirectCoverageEnrollment = request.IsDirectCoverageEnrollment,
                            IsOneStepEnrollment= request.IsOneStepEnrollment
                    };
                        Log.Debug($"-Policynumber generation triggered from EnrollmentKit process for participants {JsonConvert.SerializeObject(policyGenerationRequest)}");
                        _policyNumberGenerationManager.EnqueueRequest(policyGenerationRequest);
                }                

            }
            Log.TraceFormat("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.TraceFormat("+Execute");

            var request = JsonConvert.DeserializeObject<EnrollmentKitXmlGenerationRequest>(workUnit.InputData);
            var splittedParticipantsIds = request.ParticipantIds.ChunkBy(1000);

            foreach (var item in splittedParticipantsIds)
            {
                if (request.ParticipantIds.Count > 0)
                {
                    request.ParticipantIds.RemoveAll(c => c != -1);
                }
                request.ParticipantIds.AddRange(item);

                var cmsCase = GetCase(request.CaseId);
                                
                var docRequestXml = CreateXml(request);

                var caseDocumentRequest = new CaseDocumentRequest();

                if (request.SelectedForms.Contains(EnrollmentKitTypeEnum.Enrollment_Kit))
                {
                    caseDocumentRequest = CreateCaseDocumentRequest(docRequestXml, cmsCase, CaseDocumentTypeEnum.EnrollmentKit);
                }               
                else if (request.SelectedForms.Contains(EnrollmentKitTypeEnum.Sweep))
                {
                    caseDocumentRequest = CreateCaseDocumentRequest(docRequestXml, cmsCase, CaseDocumentTypeEnum.Sweep);
                }
                else if (request.SelectedForms.Contains(EnrollmentKitTypeEnum.Applications) && request.IsDirectCoverageEnrollment)
                {
                    caseDocumentRequest = CreateCaseDocumentRequest(docRequestXml, cmsCase, CaseDocumentTypeEnum.EnrollmentKit);
                }
                else if ((!request.SelectedForms.Contains(EnrollmentKitTypeEnum.Enrollment_Kit)) && (!request.SelectedForms.Contains(EnrollmentKitTypeEnum.Sweep)))
                {
                    caseDocumentRequest = CreateCaseDocumentRequest(docRequestXml, cmsCase, CaseDocumentTypeEnum.Other);
                }

                using (var ow = UnitOfWorkFactory.CreateUnitOfWork())
                {
                    var enrollmentParticipants = ow.Repository<EnrollmentParticipant>().Linq().Where(e => request.ParticipantIds.Contains(e.Id)).ToList();

                    foreach (var enrollmentParticipant in enrollmentParticipants)
                    {
                        var documentName = string.Empty;                                      

                        if (enrollmentParticipant.Participant != null)
                        {
                            documentName = enrollmentParticipant.Participant.LastName + ", " + enrollmentParticipant.Participant.FirstName;
                        }

                        if (request.SelectedForms.Contains(EnrollmentKitTypeEnum.Enrollment_Kit))
                        {  
                            enrollmentParticipant.Kit = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.EnrollmentKit, ExtreamDocumentType.PDF, enrollmentParticipant.Id, documentName);                           
                        }

                        if (request.SelectedForms.Contains(EnrollmentKitTypeEnum.Sweep))
                        {
                            enrollmentParticipant.Sweep = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.Sweep, ExtreamDocumentType.PDF, enrollmentParticipant.Id, documentName);
                        }

                        if (request.SelectedForms.Contains(EnrollmentKitTypeEnum.Applications) && request.IsDirectCoverageEnrollment)
                        {
                            enrollmentParticipant.Kit = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.EnrollmentKit, ExtreamDocumentType.PDF, enrollmentParticipant.Id, documentName);
                        }
                        else if ((!request.SelectedForms.Contains(EnrollmentKitTypeEnum.Enrollment_Kit)) && (!request.SelectedForms.Contains(EnrollmentKitTypeEnum.Sweep)))
                        {
                            enrollmentParticipant.Other = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.Other, ExtreamDocumentType.PDF, enrollmentParticipant.Id, documentName);
                        }
                       
                        ow.Repository<EnrollmentParticipant>().Save(enrollmentParticipant);
                    }
                    ow.Commit();
                }
                _workUnitManager.CreateWorkUnit(WorkUnitType.ExtreamFileUpload, caseDocumentRequest.Id.ToString());
            }
            Log.TraceFormat("-Execute");
        }


        private string CreateXml(EnrollmentKitXmlGenerationRequest request)
        {
            Log.TraceFormat("+CreateEnrollmentKitXml");

            var enrollmentKitXmlBuilder = new EnrollmentKitXmlBuilder(UnitOfWorkFactory);

            var enrollmentKitXml = new EnrollmentKitXml();

            enrollmentKitXmlBuilder.CreateEnrollmentKit(request, enrollmentKitXml);

            UpdateStandardOfferCodeForAMBParticipants(enrollmentKitXml);

            //Clear and Null to remove old layout to use new.
            //enrollmentKitXml.groups.Clear();
            enrollmentKitXml.groups = null;
            enrollmentKitXml.producersAndAgents.Clear();
            enrollmentKitXml.producersAndAgents = null;
            enrollmentKitXml.company = null;

            var serializedEnrollmentKit = SerializeObject(enrollmentKitXml);

            var updatedXMLEnrollmentKit = RemoveAMBRRiderTagsFromXML(serializedEnrollmentKit);

            Log.TraceFormat("-CreateEnrollmentKitXml");

            return updatedXMLEnrollmentKit;
        }

        private void UpdateStandardOfferCodeForAMBParticipants(EnrollmentKitXml enrollmentKitXml)
        {
            Log.TraceFormat("+UpdateStandardOfferCodeForAMBParticipants");
            var qualifiedOffers = enrollmentKitXml.Groups.SelectMany(c => c.EligibleParticipants).SelectMany(c => c.Offers).ToList();

            bool isVgsiPlan = enrollmentKitXml.Groups.Any(i => i.isVgsiPlanDesignType == true);

            if (qualifiedOffers.Any())
            {
                bool isVGSIPlanTemplate = qualifiedOffers.Any(c => c.riders.Any(r => r.riderIdentifier == "AMBR") && isVgsiPlan);

                if (!isVGSIPlanTemplate)
                {
                    Log.TraceFormat("+UpdateStandardOfferCodeForAMBParticipants : Updated for Non ER/VGSI plan");
                    var ambQualifiedOffers = qualifiedOffers.Where(c => c.riders.Any(r => r.riderIdentifier == "AMBR")).ToList();
                    if (ambQualifiedOffers.Any())
                    {
                        foreach (var offer in ambQualifiedOffers)
                        {
                            var offerCode = offer.cmsStandardOfferCode;
                            var index = offerCode.IndexOf("IDI");
                            if (index != -1)
                            {
                                var code = offerCode.Substring(0, index);
                                offer.cmsStandardOfferCode = string.Concat(code, "Max IDI");
                            }
                        }
                    }
                }
            }

            Log.TraceFormat("+UpdateStandardOfferCodeForAMBParticipants");
        }
    }
}