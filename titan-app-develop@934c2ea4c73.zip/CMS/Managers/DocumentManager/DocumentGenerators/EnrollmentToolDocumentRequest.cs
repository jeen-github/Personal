﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class EnrollmentToolDocumentRequest : MLDICase
    {
        public EnrollmentToolDocumentGroupRequest EntrollmentToolGroups { get; set; }
    }
    
    public class EnrollmentToolDocumentGroupRequest
    {
        public List<EntrollmentToolGroups> group { get; set; }
    }
    
    public class EntrollmentToolGroups : MLDIGroup
    {
          public EnrollmentToolGroupsEligibleParticipants Participants { get; set; }
    }

    public class EnrollmentToolGroupsEligibleParticipants
    {
        public List<EntrollmentToolGroupsParticipant> participant { get; set; }
    }

    public class EntrollmentToolGroupsParticipant : MLDIParticipant
    {
        public string employeeID { get; set; }
        public string ExistingTobaccoStatus { get; set; }
        public string phoneNumber { get; set; }
        public string emailAddress { get; set; }
        public string premiumPaymentPeriod { get; set; }
        public uint? benefitPeriodYears { get; set; }
        public uint? benefitPeriodAge { get; set; }
        public string payrollDeductionPeriod { get; set; }
        public decimal? baseMonthlyBenefit { get; set; }
    }
    
}
