﻿using System;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Model.Entities;
using Logger.Static;
using Newtonsoft.Json;
using System.Linq;
using System.Collections.Generic;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Guardian.Core.Entities.Product.Enums;
using CMS.Interfaces.Managers.ProductLibraryManagers;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class ProducerCertificationDocumentGenerator : DocumentGenerator, IWorkUnitHandler, IProducerCertificationDocumentGenerator
    {
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IPlanDesignRequestManager _planDesignRequestManager;
        
        public ProducerCertificationDocumentGenerator(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager,
            IPlanDesignRequestManager planDesignRequestManager, IProductLibraryManager productLibraryManager) : base(unitOfWorkFactory, productLibraryManager)
        {
            _workUnitManager = workUnitManager;
            _planDesignRequestManager = planDesignRequestManager;
        }

        public void EnqueueRequest(ProducerCertificationDto request)
        {
            Log.TraceFormat("+EnqueueRequest");

            _workUnitManager.CreateWorkUnit(WorkUnitType.ProducerCertification, JsonConvert.SerializeObject(request));

            Log.TraceFormat("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.TraceFormat("+Run");

            var request = JsonConvert.DeserializeObject<ProducerCertificationDto>(workUnit.InputData);

            CreateProductCertificationRequest(request);

            Log.TraceFormat("-Run");
        }

        public void CreateProductCertificationRequest(ProducerCertificationDto request)
        {
            Log.TraceFormat("+CreateProductCertificationRequest");

            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var caseBrokers = cmsCase.CaseBrokers.Where(c => request.CaseBrokerIds.Contains(c.Id)).ToList();
                var caseBrokerStates = caseBrokers.SelectMany(c => c.CaseBrokerStates).Where(c => request.CaseBrokerStateIds.Contains((int)c.StateType)).ToList();
                var docRequestXml = CreateXml(cmsCase, caseBrokers, caseBrokerStates);
                var agentCertificationDocumentNames = CreateAgentCertificationDocumentNames(caseBrokers);
                CreateDocument(docRequestXml, cmsCase, agentCertificationDocumentNames);
            }

            Log.TraceFormat("-CreateProductCertificationRequest");
        }

        private string CreateXml(Case cmsCase, List<CaseBroker> caseBrokers, List<CaseBrokerState> caseBrokerStates)
        {
            Log.TraceFormat("+CreateXml");
            string response = string.Empty;

            int StateId = _planDesignRequestManager.GetCorporateSitusStateByCaseId(cmsCase.Id);

            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var docRequest = new ProducerCertificationDocumentRequest
                {
                    CaseName = cmsCase.CompanyName,                    
                    CaseState = ((StateTypeEnum)StateId).ToString(),
                    CaseBrokerRequest = GetCaseBrokers(caseBrokers, caseBrokerStates)
                };

                response = SerializeObject(docRequest);
            }
            Log.TraceFormat("-CreateXml");

            return response;
        }

        private List<CaseBrokerRequest> GetCaseBrokers(List<CaseBroker> caseBrokers, List<CaseBrokerState> caseBrokerStates)
        {
            Log.TraceFormat("+GetCaseBrokers");
            var distinctCaseBrokerStates = caseBrokerStates.Select(p => p.StateType).Distinct().ToList();
            var agencies = caseBrokers.Select(p => p.AgencyCode).Distinct().ToList();

            var caseBrokerRequests = new List<CaseBrokerRequest>();

            foreach (string agency in agencies)
            {
                var caseBrokerRequest = new CaseBrokerRequest();
                var caseBrokerStateRequests = new List<CaseBrokerStateRequest>();

                foreach (StateTypeEnum stateType in distinctCaseBrokerStates)
                {
                    var caseBrokerStateRequest = new CaseBrokerStateRequest();
                    var caseBrokerByStateList = caseBrokerStates.Where(p => p.StateType == stateType && p.CaseBroker.AgencyCode==agency).ToList();

                    var producer = caseBrokerByStateList.Where(p => p.CaseBroker.BrokerType == "0").FirstOrDefault();
                    var corporateProducer = caseBrokerByStateList.Where(p => p.CaseBroker.BrokerType == "1").FirstOrDefault();
                    var subProducer = caseBrokerByStateList.Where(p => p.CaseBroker.BrokerType == "2").FirstOrDefault();

                    caseBrokerStateRequest.CaseBrokerState = stateType.GetDescription();
                    if (producer != null)
                    {
                        caseBrokerStateRequest.ProducerName = producer.CaseBroker.BrokerName.Trim().Replace(",", " ");
                        caseBrokerStateRequest.ProducerSplit = producer.CommisionPercentage;
                        caseBrokerStateRequest.ProducerCode = producer.CaseBroker.BrokerWritingCode;
                        caseBrokerStateRequest.IsServicingProducer = producer.IsPrimaryBrokerIndicator;
                    }
                    if (corporateProducer != null)
                    {
                        caseBrokerStateRequest.ProducerCorporateName = corporateProducer.CaseBroker.BrokerName.Trim().Replace(",", " ");
                        caseBrokerStateRequest.CorporateProducerSplit = corporateProducer.CommisionPercentage;
                        caseBrokerStateRequest.CorporateProducerCode = corporateProducer.CaseBroker.BrokerWritingCode;
                        caseBrokerStateRequest.IsCorporateServicingProducer = corporateProducer.IsPrimaryBrokerIndicator;
                    }
                    if (subProducer != null)
                    {
                        if (subProducer.CaseBroker.BrokerName != null)
                        {
                            if (subProducer.CaseBroker.BrokerName.Contains(" - "))
                            {
                                string[] splitCorporate = subProducer.CaseBroker.BrokerName.Split(new string[] { " - " }, StringSplitOptions.None);
                                if (splitCorporate.Count() == 2)
                                {
                                    caseBrokerStateRequest.ProducerCorporateName = splitCorporate[1];
                                    caseBrokerStateRequest.ProducerName = splitCorporate[0].Trim().Replace(",", " ");
                                }
                            }
                        }
                        caseBrokerStateRequest.ProducerSplit = subProducer.CommisionPercentage;
                        caseBrokerStateRequest.ProducerCode = subProducer.CaseBroker.BrokerWritingCode;
                        caseBrokerStateRequest.IsServicingProducer = subProducer.IsPrimaryBrokerIndicator;
                    }
                    caseBrokerStateRequests.Add(caseBrokerStateRequest);
                }
                caseBrokerRequest.CaseBrokerStateRequest = caseBrokerStateRequests;
                caseBrokerRequests.Add(caseBrokerRequest);
            }
            Log.TraceFormat("-GetCaseBrokers");
            return caseBrokerRequests;
        }

        private void CreateDocument(string docRequestXml, Case cmsCase, string agentCertificationDocumentNames)
        {
            Log.TraceFormat("+CreateDocument");

            var caseDocumentRequest = CreateCaseDocumentRequest(docRequestXml, cmsCase, CaseDocumentTypeEnum.ProducerCertification);

            var caseDocument = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.ProducerCertification, ExtreamDocumentType.PDF,null, agentCertificationDocumentNames);
            
            _workUnitManager.CreateWorkUnit(WorkUnitType.ExtreamFileUpload, caseDocumentRequest.Id.ToString());

            Log.TraceFormat("-CreateDocument");
        }

        private string CreateAgentCertificationDocumentNames(List<CaseBroker> caseBrokers)
        {
            string agentCertificationDocumentName = string.Empty;

            string brokerNames = string.Join(", ", caseBrokers.Where(c => c.CaseBrokerStates.Any(s => s.IsPrimaryBrokerIndicator == true)).Select(b => b.BrokerName.Replace(",", "")).ToArray());

            agentCertificationDocumentName = !string.IsNullOrWhiteSpace(brokerNames) ? brokerNames : string.Empty;

            return agentCertificationDocumentName;
        }
        
    }
}
