﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.OfferLetterManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using Guardian.Core.Entities.Product.Enums;
using CMS.Interfaces.Managers.BusinessManagers;
using CMS.Model.Extensions;
using Common.Exceptions;
using CMS.Interfaces.Managers.ProductLibraryManagers;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class OfferLetterDocumentGenerator : DocumentGenerator, IOfferLetterDocumentGenerator, IWorkUnitHandler
    {
        private readonly IWorkUnitManager _workUnitManager;
        private readonly IllustrationDocumentGenerator _illustrationDocumentGenerator;
        private readonly IProductLibraryManager _productLibraryManager;
        private bool isCompactState = false;

        public OfferLetterDocumentGenerator(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager, 
            IllustrationDocumentGenerator illustrationDocumentGenerator, IProductLibraryManager productLibraryManager) : base(unitOfWorkFactory, productLibraryManager)
        {
            _workUnitManager = workUnitManager;
            _illustrationDocumentGenerator = illustrationDocumentGenerator;
            _productLibraryManager = productLibraryManager;
        }

        public void EnqueueRequest(OfferLetterRequestDto request)
        {
            Log.TraceFormat("+EnqueueRequest");           

            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);

                var isCompactState = cmsCase.CaseUnderwritingRequests.FirstOrDefault().IsCompactState;
                if (isCompactState == null)
                {
                    throw new ValidationException("Please select Compact State as Yes or No in Plan Design Request..");
                }
            }

            isCompactState = _productLibraryManager.IsCompactStateCase(request.CaseId);

            _workUnitManager.CreateWorkUnit(WorkUnitType.OfferLetterDocument, JsonConvert.SerializeObject(request));

            Log.TraceFormat("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.TraceFormat("+Run");

            var request = JsonConvert.DeserializeObject<OfferLetterRequestDto>(workUnit.InputData);

            ProcessRequest(request);

            Log.TraceFormat("-Run");
        }

        private void ProcessRequest(OfferLetterRequestDto request)
        {
            Log.TraceFormat("+ProcessOfferLetterRequest");

            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var illustrations = unitOfWork.Repository<Illustration>().Linq().Where(c => request.IllustrationIds.Contains(c.Id)).ToList();
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var docRequestXml = CreateXml(request.CaseId, illustrations);

                var documentRequest = CreateCaseDocumentRequest(docRequestXml, cmsCase, CaseDocumentTypeEnum.OfferLetter);
                var caseDocument = CreateCaseDocument(documentRequest, cmsCase, CaseDocumentTypeEnum.OfferLetter, ExtreamDocumentType.PDF);

                StoreOfferLetterDocumentIdsToDatabase(request.OfferLetterId, caseDocument);

                _workUnitManager.CreateWorkUnit(WorkUnitType.ExtreamFileUpload, documentRequest.Id.ToString());
            }

            Log.TraceFormat("-ProcessOfferLetterRequest");
        }

        private string CreateXml(int caseId, List<Illustration> selectedIllustrations)
        {
            Log.TraceFormat("+CreateXml");

            string response;

            using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                var existingCoverage = unitOfWork.Repository<ExistingCoverage>().Linq().FirstOrDefault(c => c.Case.Id == caseId);
                //var planDesignRequest = cmsCase.PlanDesignRequests.FirstOrDefault();

                var pdrId = selectedIllustrations.FirstOrDefault()?.PlanDesignRequest.Id;
                var planDesignRequest = cmsCase.PlanDesignRequests.FirstOrDefault(i => i.Id == pdrId);
                var caseBrokers = cmsCase.CaseBrokers.Where(c => c.Case.Id == caseId);
                var caseBrokerState = caseBrokers.SelectMany(c => c.CaseBrokerStates).FirstOrDefault(c => c.IsPrimaryBrokerIndicator == true && c.StateType == cmsCase.CaseUnderwritingRequests.FirstOrDefault().StateType);
                var contactAddrCategory = unitOfWork.Repository<ContactAddressCategory>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.ContactAddress.Case.Id == cmsCase.Id && c.IsPrimary && c.IsSelect && c.ContactAddressCategoryType.Id == (int)ContactAddressCategoryTypeEnum.UnderwritingOutput);

                isCompactState = _productLibraryManager.IsCompactStateCase(cmsCase.Id);

                var docRequest = new OfferLetterDocumentRequest
                {
                    CaseNumber = cmsCase.CaseNumber,
                    CompanyName = cmsCase.CompanyName,
                    EffectiveDate = planDesignRequest.IllustrationEffectiveDate.Value.ToString("MM/dd/yyyy"),
                    BrokerName = contactAddrCategory != null ? contactAddrCategory.ContactAddress.ContactName : string.Empty,
                    PresentedBy = contactAddrCategory != null ? contactAddrCategory.ContactAddress.ContactName : null,
                    SICCode = cmsCase.CompanySicMajorGroupType != null ? cmsCase.CompanySicMajorGroupType.Description : string.Empty,
                    CarrierName = (existingCoverage != null && existingCoverage.ExistingIndividualDisabilityCoverageType != null) ? existingCoverage.ExistingIndividualDisabilityCoverageType.Description : string.Empty,
                    GuaranteedIssueFlag = existingCoverage != null ? (existingCoverage.IsExistingGuranteedIssueCoverageIndicator != null ? (bool)existingCoverage.IsExistingGuranteedIssueCoverageIndicator : false) : false,
                    EmployerOwnerFlag = (existingCoverage != null && existingCoverage.EmployerOwned != null) ? (bool)existingCoverage.EmployerOwned : false,
                    VGSICase = GetIsVGSICase(selectedIllustrations, unitOfWork, cmsCase),
                    ERISAInd = (cmsCase.IsCompanyErisaIndicator != null) ? cmsCase.IsCompanyErisaIndicator : false,
                    OfferletterOptionRequest = GetOfferLetterOptionRequest(selectedIllustrations, unitOfWork, cmsCase),
                    UseCompactApp = isCompactState,
                    //PDRNumber = GetPDRNumberText(cmsCase.PlanDesignRequests)
                    PDRNumber = GetPDRNumberText(planDesignRequest)
                };

                response = SerializeObject(docRequest);
            }

            Log.TraceFormat("-CreateXml");

            return response;
        }

        public string GetPDRNumberText(IList<PlanDesignRequest> pdrs)
        {
            Log.TraceFormat("+GetPDRNumberText");
            string pdrName = string.Empty;

            for (int i = 1; i <= pdrs.Count(); i++)
            {
                pdrName += $"{i:D3}, ";
            }

            pdrName = "PDR" + pdrName;
            pdrName = pdrName.Remove(pdrName.LastIndexOf(','), 1).Trim();

            Log.TraceFormat("-GetPDRNumberText");

            return pdrName;

        }

        public string GetPDRNumberText(PlanDesignRequest pdr)
        {
            Log.TraceFormat("+GetPDRNumberText");
            string pdrName = string.Empty;

            try
            {
                string[] splitpdrName = pdr.RequestHeaderName.Split('-');

                if (splitpdrName.Count() > 0)
                {
                    pdrName = "PDR " + splitpdrName[1];
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error in GetPDRNumberText", ex);
            }

            Log.TraceFormat("-GetPDRNumberText");

            return pdrName;   
        }


        public bool GetIsVGSICase(List<Illustration> selectedIllustrations, IUnitOfWork unitOfWork, Case cmsCase)
        {
            Log.TraceFormat("+GetIsVGSICase");
            bool vgsiCase = false;
            foreach (var illustration in selectedIllustrations)
            {
                var illustrationRequest = JsonConvert.DeserializeObject<IllustrationRequest>(illustration.RequestJsonText);
                var isSold = illustration.PlanDesignRequest.PDRSoldClass.Any(c => c.IsActive);

                if (illustrationRequest != null)
                {
                    if (isSold)
                    {
                        vgsiCase = illustrationRequest.Classes.Any() ? illustrationRequest.Classes.Where(c => c.HasBuyUpPlan).Count() > 0 : false;
                        return vgsiCase;
                    }
                    else
                    {
                        vgsiCase = illustrationRequest.Classes.Any() ? illustrationRequest.Classes.Where(c => c.HasBuyUpPlan).Count() > 0 : false;
                        return vgsiCase;
                    }
                }
            }
            Log.TraceFormat("-GetIsVGSICase");
            return vgsiCase;
        }
        public List<OfferletterOptionRequest> GetOfferLetterOptionRequest(List<Illustration> selectedIllustrations, IUnitOfWork unitOfWork, Case cmsCase)
        {
            Log.TraceFormat("+GetOfferLetterOptionRequest");

            var offerLetterOptionRequestList = new List<OfferletterOptionRequest>();
            int offerLetterOption = 1;

            foreach (var illustration in selectedIllustrations)
            {
                var offerLetterOptionRequest = new OfferletterOptionRequest();
                offerLetterOptionRequest.IllustrationId = illustration.Id;
                offerLetterOptionRequest.IllustrationName = illustration.QuoteName;
                offerLetterOptionRequest.OfferLetterOption = offerLetterOption++;
                offerLetterOptionRequest.IncludeIneligibleParticipants = illustration.IncludeIneligibleParticipants;
                var eligibleParticipants = illustration.PlanDesignRequest.PlanDesignRequestClass.SelectMany(c => c.CensusParticipants).Where(p => (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null));
                offerLetterOptionRequest.Is5to9CaseInd = eligibleParticipants.Count() <= 9 ? true : false;
                offerLetterOptionRequest.TotalPlus90 = "";//This will be populated by extream adding 90days to OfferLetter Requested Date.

                var illustrationRequest = JsonConvert.DeserializeObject<IllustrationRequest>(illustration.RequestJsonText);
                var isSold = illustration.PlanDesignRequest.PDRSoldClass.Any(c => c.IsActive);
                if (illustrationRequest != null)
                {
                    offerLetterOptionRequest = BuildXmlFromIllustration(offerLetterOptionRequest, unitOfWork, illustrationRequest.Classes, cmsCase, isSold);
                }
                offerLetterOptionRequestList.Add(offerLetterOptionRequest);
            }

            Log.TraceFormat("-GetOfferLetterOptionRequest");

            return offerLetterOptionRequestList;
        }

        private OfferletterOptionRequest BuildXmlFromIllustration(OfferletterOptionRequest illustrationDocumentRequest, IUnitOfWork unitOfWork, List<IllustrationRequestClass> illustrationRequestClass, Case cmsCase, bool isSold)
        {
            Log.TraceFormat("+BuildXmlFromIllustration");
            var contractState = _illustrationDocumentGenerator.GetContractState(cmsCase);
            foreach (var item in illustrationRequestClass)
            {
                var classReq = new OfferLetterDocumentClassRequest();
                if (isSold)
                {
                    CreateOfferLetterDocumentRequestFromPDRSoldClass(unitOfWork, cmsCase, contractState, item, classReq);
                }
                else
                {
                    CreateOfferLetterDocumentRequestFromPDRClass(unitOfWork, cmsCase, contractState, item, classReq);
                }
                illustrationDocumentRequest.Classes.Add(classReq);
            }
            Log.TraceFormat("-BuildXmlFromIllustration");
            return illustrationDocumentRequest;
        }

        private void CreateOfferLetterDocumentRequestFromPDRClass(IUnitOfWork unitOfWork, Case cmsCase, StateTypeEnum? contractState, IllustrationRequestClass item, OfferLetterDocumentClassRequest classReq)
        {
            var planDesignRequestClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(c => c.Id == item.TitanClassId);

            classReq.ClassName = item.TitanClassName;
            classReq.OSEIndicator = planDesignRequestClass.PlanDesignRequestClassProducts.Where(i => i.IsGSIPlanIndicator == false)
                                                           .FirstOrDefault().IsOneStepEnrollmentIndicator.ToString();
            classReq.MaxGSIOffer = item.PrimaryPlan.GSIMaxAmount;
            if (item.BuyUpPlan != null)
            {
                classReq.TotalMaxGSI = item.PrimaryPlan.GSIAmount + item.BuyUpPlan.GSIAmount;
                classReq.TotalCombinedGSI = item.BuyUpPlan.TotalMaxGSIAmount != 0 ? item.BuyUpPlan.TotalMaxGSIAmount : item.PrimaryPlan.TotalMaxGSIAmount;
            }
            else
            {
                classReq.TotalMaxGSI = item.PrimaryPlan.GSIAmount;
            }
            classReq.DefinitionOfDisability = GetDefinitionOfDisablity((DefinitionOfDisabilityTypeEnum)item.PrimaryPlan.DefinitionOfDisabilityId); //((DefinitionOfDisabilityTypeEnum)item.PrimaryPlan.DefinitionOfDisabilityId).GetDescription();
            classReq.MentalSubstance = _illustrationDocumentGenerator.GetMentalSubstanceDescription(item.PrimaryPlan.MentalSubstanceId);
            classReq.PrexCondition = ((PreExistingConditionLimitTypeEnum)item.PrimaryPlan.PreExistingConditionLimitationId).GetDescription();
            classReq.EliminationPeriod = ((EliminationPeriodTypeEnum)item.PrimaryPlan.EliminationPeriodId).GetDescription();
            classReq.BenefitPeriod = ((BenefitPeriodTypeEnum)item.PrimaryPlan.BenefitPeriodId).GetDescription();
            classReq.Riders = GetRiderDetails(item.PrimaryPlan.Benefits, contractState.Value);
            classReq.RiderCount = classReq.Riders.Count().ToString();
            classReq.MaxReplacementPercent = (item.PrimaryPlan.ReplacementRatio != 0.0M) ? item.PrimaryPlan.ReplacementRatio.ToString() : string.Empty;

            classReq.PlanDesignType = _illustrationDocumentGenerator.GetPlanDesignTypeDescription(planDesignRequestClass.ApprovedPlanDesignType);

            classReq.PlanDesign = _illustrationDocumentGenerator.GetPlanDesignDescription(planDesignRequestClass);
            string premiumPayer = planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType != null ? planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType.Description : string.Empty;
            var premiumPayerAndTaxabilityType = planDesignRequestClass.ApprovedPremiumPayerAndTaxabilityType;
            if (_illustrationDocumentGenerator.IsCostShare(premiumPayerAndTaxabilityType))
            {
                classReq.GSIPremiumPayer = premiumPayer;
                var typeOfShareType = planDesignRequestClass.ApprovedTypeOfShareType;
                var employerPaidPremium = planDesignRequestClass.ApprovedEmployerPaidPremium;
                var costShareTaxabilityType = planDesignRequestClass.ApprovedCostShareTaxabilityType;
                var employerPaysupto = planDesignRequestClass.ApprovedEmployerPaysupto;
                AddCostShareGSIPlanTags(classReq, typeOfShareType, employerPaidPremium, costShareTaxabilityType, employerPaysupto);
            }
            else
            {
                classReq.GSIPremiumPayer = planDesignRequestClass.ApprovedTaxabilityType != null ? premiumPayer + " / " + planDesignRequestClass.ApprovedTaxabilityType.GetDescription() : premiumPayer;
            }
            classReq.MaximumIp = _illustrationDocumentGenerator.GetMaximumIPDescription(planDesignRequestClass.ApprovedPlanDesignType, planDesignRequestClass, unitOfWork);

            var primaryPlanProduct = planDesignRequestClass.PlanDesignRequestClassProducts.FirstOrDefault(x => x.IsGSIPlanIndicator == false);
            classReq.ParticipantionRequired = primaryPlanProduct.ParticipationPercentage + "%";
            classReq.CaseLevelDiscountPercentage = _illustrationDocumentGenerator.GetDiscountPercentage(primaryPlanProduct);
            classReq.IDIInsurableIncome = planDesignRequestClass.InsurableIncomeDefinition;

            var corporateSitusState = cmsCase.CaseUnderwritingRequests.FirstOrDefault(x => x.Case.Id == cmsCase.Id);
            classReq.CorporateSitus = corporateSitusState != null ? corporateSitusState.StateType.ToString() : string.Empty;

            if (planDesignRequestClass.ApprovedPlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                var primaryPlan = planDesignRequestClass.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == false);
                classReq.RPPBenefitAmt = string.Format("{0:C2}", primaryPlan.GSIAmount);
                if (planDesignRequestClass.ApprovedRetirementContributionsType == RetirementContributionsTypeEnum.ActualContributiononCensus)
                {
                    classReq.RetirmentContributionsAmt = "True";
                }
                else
                {
                    classReq.RetirmentContributionsAmt = planDesignRequestClass.ApprovedAnnualContributions != null ? string.Format("{0:C2}", planDesignRequestClass.ApprovedAnnualContributions) : string.Empty;
                }
                classReq.RPPBasePremiumPercentAmt = (planDesignRequestClass.ApprovedCoveredEarningsPercentage != null) ? planDesignRequestClass.ApprovedCoveredEarningsPercentage + "%" : string.Empty;
            }

            if (item.HasBuyUpPlan)
            {
                var buyUpPlanProduct = planDesignRequestClass.PlanDesignRequestClassProducts.FirstOrDefault(x => x.IsGSIPlanIndicator == true);
                classReq.VGSICaseLevelDiscountPercentage = _illustrationDocumentGenerator.GetDiscountPercentage(buyUpPlanProduct);
                classReq.VGBPDefinitionOfDisability = GetDefinitionOfDisablity((DefinitionOfDisabilityTypeEnum)item.BuyUpPlan.DefinitionOfDisabilityId); // ((DefinitionOfDisabilityTypeEnum)item.BuyUpPlan.DefinitionOfDisabilityId).GetDescription();
                classReq.BPMentalSubstance = _illustrationDocumentGenerator.GetMentalSubstanceDescription(item.BuyUpPlan.MentalSubstanceId);
                classReq.VGBPPrexCondition = ((PreExistingConditionLimitTypeEnum)item.BuyUpPlan.PreExistingConditionLimitationId).GetDescription();
                classReq.VGBPEliminationPeriod = ((EliminationPeriodTypeEnum)item.BuyUpPlan.EliminationPeriodId).GetDescription();
                classReq.VGBPBenefitPeriod = ((BenefitPeriodTypeEnum)item.BuyUpPlan.BenefitPeriodId).GetDescription();
                //classReq.VGBPMaxReplacementPercent = item.BuyUpPlan.ReplacementRatio.ToString();
                classReq.VGBPMaxReplacementPercent = planDesignRequestClass.ApprovedGSIBuyUpReplacementPercentage.ToString();
                classReq.VGBPRiders = GetRiderDetails(item.BuyUpPlan.Benefits, contractState.Value);
                classReq.VGBPRiderCount = classReq.VGBPRiders.Count().ToString();
                classReq.VGBPPlanDesignType = _illustrationDocumentGenerator.GetPlanDesignTypeDescription((PlanDesignTypeEnum?)planDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType);
                classReq.VGBPPlanDesign = _illustrationDocumentGenerator.GetBuyUpPlanDesignDescription(planDesignRequestClass);
                classReq.VGBPInsurableIncome = planDesignRequestClass.BuyUpInsurableIncomeDefinition;
                classReq.BPMaximumIp = _illustrationDocumentGenerator.GetMaximumIPDescription((PlanDesignTypeEnum?)planDesignRequestClass.ApprovedVoluntaryGSIBuyUpPlanDesignType, planDesignRequestClass, unitOfWork);
                classReq.BPParticipantionRequired = planDesignRequestClass.PlanDesignRequestClassProducts.FirstOrDefault(x => x.IsGSIPlanIndicator == true).ParticipationPercentage + "%";
                classReq.VGBPMaxGSIOffer = item.BuyUpPlan.GSIMaxAmount;
            }

            var ltdCoverage = planDesignRequestClass.PlanDesignRequestClassLTDCoverage.FirstOrDefault(x => x.PlanDesignRequestClass.Id == item.TitanClassId);
            if (ltdCoverage != null && (planDesignRequestClass.ApprovedPlanDesignType != PlanDesignTypeEnum.StandAloneIDIPlan || planDesignRequestClass.ApprovedPlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan))
            {
                classReq.IsGroupLTDDesign = ltdCoverage != null ? true : false;
                classReq.PercentOfBaseSalary = ltdCoverage != null ? ltdCoverage.GroupLTDReplacementPercentage + "%" : string.Empty;
                classReq.BaseSalary = _illustrationDocumentGenerator.GetBaseSalaryDescription(planDesignRequestClass);
                classReq.MaxSalaryK = string.Format("{0:C2}", ltdCoverage.GroupLTDCapAmount);
                string ltdPremiumPayer = ltdCoverage.PremiumAndTaxpayerLiabilityType != null ? ltdCoverage.PremiumAndTaxpayerLiabilityType.Description : string.Empty;
                classReq.GroupLTDPremiumPayer = ltdCoverage.TypeOfPayType != null ? ltdPremiumPayer + " / " + ltdCoverage.TypeOfPayType.GetDescription() : ltdPremiumPayer;
            }
            else
            {
                //For StandAlonePlanIDI LTDCoverage not mandatory
                classReq.IsGroupLTDDesign = false;
                classReq.PercentOfBaseSalary = string.Empty;
                classReq.BaseSalary = string.Empty;
                classReq.MaxSalaryK = string.Empty;
                classReq.GroupLTDPremiumPayer = string.Empty;
            }
            classReq.EligibleEmployees = planDesignRequestClass.CensusParticipants.Where(p => (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null)).Count().ToString();
            classReq.CreationDate = DateTime.Now.ToString("MMMM dd, yyyy");

            var enrollmentMgr = unitOfWork.Repository<CmsUser>().Linq().Where(t => t.Id == cmsCase.EnrollmentManagerId).FirstOrDefault();
            if (enrollmentMgr != null)
            {
                classReq.EnrollmentManager = enrollmentMgr.FirstName + " " + enrollmentMgr.LastName;
            }
            else
            {
                classReq.EnrollmentManager = string.Empty;
            }
        }

        private void CreateOfferLetterDocumentRequestFromPDRSoldClass(IUnitOfWork unitOfWork, Case cmsCase, StateTypeEnum? contractState, IllustrationRequestClass item, OfferLetterDocumentClassRequest classReq)
        {
            var planDesignRequestSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().FirstOrDefault(c => c.PlanDesignRequestClass.Id == item.TitanClassId && c.IsActive);
            if (planDesignRequestSoldClass != null)
            {
                var primaryplan = planDesignRequestSoldClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                var buyupPlan = planDesignRequestSoldClass.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);

                classReq.ClassName = item.TitanClassName;
                classReq.OSEIndicator = planDesignRequestSoldClass.PDRSoldClassPlan.FirstOrDefault(i=>i.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).IsOneStepEnrollmentIndicator.ToString();
                classReq.MaxGSIOffer = item.PrimaryPlan.GSIMaxAmount;
                if (item.BuyUpPlan != null)
                {
                    classReq.TotalMaxGSI = item.PrimaryPlan.GSIAmount + item.BuyUpPlan.GSIAmount;
                    classReq.TotalCombinedGSI = item.BuyUpPlan.TotalMaxGSIAmount != 0 ? item.BuyUpPlan.TotalMaxGSIAmount : item.PrimaryPlan.TotalMaxGSIAmount;
                }
                else
                {
                    classReq.TotalMaxGSI = item.PrimaryPlan.GSIAmount;
                }
                classReq.DefinitionOfDisability = GetDefinitionOfDisablity((DefinitionOfDisabilityTypeEnum)item.PrimaryPlan.DefinitionOfDisabilityId); //((DefinitionOfDisabilityTypeEnum)item.PrimaryPlan.DefinitionOfDisabilityId).GetDescription();
                classReq.MentalSubstance = _illustrationDocumentGenerator.GetMentalSubstanceDescription(item.PrimaryPlan.MentalSubstanceId);
                classReq.PrexCondition = ((PreExistingConditionLimitTypeEnum)item.PrimaryPlan.PreExistingConditionLimitationId).GetDescription();
                classReq.EliminationPeriod = ((EliminationPeriodTypeEnum)item.PrimaryPlan.EliminationPeriodId).GetDescription();
                classReq.BenefitPeriod = ((BenefitPeriodTypeEnum)item.PrimaryPlan.BenefitPeriodId).GetDescription();
                classReq.Riders = GetRiderDetails(item.PrimaryPlan.Benefits, contractState.Value);
                classReq.RiderCount = classReq.Riders.Count().ToString();
                classReq.MaxReplacementPercent = (item.PrimaryPlan.ReplacementRatio != 0.0M) ? item.PrimaryPlan.ReplacementRatio.ToString() : string.Empty;

                classReq.PlanDesignType = _illustrationDocumentGenerator.GetPlanDesignTypeDescription(primaryplan.PlanDesignType);
                classReq.PlanDesign = _illustrationDocumentGenerator.GetSoldPlanDesignDescription(primaryplan);
                string premiumPayer = primaryplan.PremiumPayerAndTaxabilityType != null ? primaryplan.PremiumPayerAndTaxabilityType.Description : string.Empty;
                var premiumPayerAndTaxabilityType = primaryplan.PremiumPayerAndTaxabilityType;
                if (_illustrationDocumentGenerator.IsCostShare(premiumPayerAndTaxabilityType))
                {
                    classReq.GSIPremiumPayer = premiumPayer;
                    var typeOfShareType = primaryplan.TypeOfShareType;
                    var employerPaidPremium = primaryplan.EmployerPaidPremium;
                    var costShareTaxabilityType = primaryplan.CostShareTaxabilityType;
                    var employerPaysupto = primaryplan.EmployerPaysupto;
                    AddCostShareGSIPlanTags(classReq, typeOfShareType, employerPaidPremium, costShareTaxabilityType, employerPaysupto);
                }
                else
                {
                    classReq.GSIPremiumPayer = primaryplan.TaxabilityType != null ? premiumPayer + " / " + primaryplan.TaxabilityType.GetDescription() : premiumPayer;
                }
                classReq.MaximumIp = _illustrationDocumentGenerator.GetMaximumIPDescription(primaryplan.PlanDesignType, primaryplan.PDRSoldClass.PlanDesignRequestClass, unitOfWork);


                classReq.ParticipantionRequired = primaryplan.ParticipationPercentage + "%";
                classReq.CaseLevelDiscountPercentage = _illustrationDocumentGenerator.GetDiscountPercentageForSoldClass(primaryplan);
                classReq.IDIInsurableIncome = primaryplan.InsurableIncomeDefinition;

                var corporateSitusState = cmsCase.CaseUnderwritingRequests.FirstOrDefault(x => x.Case.Id == cmsCase.Id);
                classReq.CorporateSitus = corporateSitusState != null ? corporateSitusState.StateType.ToString() : string.Empty;

                if (primaryplan.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
                {
                    classReq.RPPBenefitAmt = string.Format("{0:C2}", primaryplan.GSIAmount);
                    if (primaryplan.RetirementContributionsType == RetirementContributionsTypeEnum.ActualContributiononCensus)
                    {
                        classReq.RetirmentContributionsAmt = "True";
                    }
                    else
                    {
                        classReq.RetirmentContributionsAmt = primaryplan.AnnualContributions != null ? string.Format("{0:C2}", primaryplan.AnnualContributions) : string.Empty;
                    }
                    classReq.RPPBasePremiumPercentAmt = primaryplan.CoveredEarningsPercentage != null ? primaryplan.CoveredEarningsPercentage + "%" : string.Empty;
                }

                if (item.HasBuyUpPlan)
                {
                    classReq.VGSICaseLevelDiscountPercentage = _illustrationDocumentGenerator.GetDiscountPercentageForSoldClass(buyupPlan);
                    classReq.VGBPDefinitionOfDisability = GetDefinitionOfDisablity((DefinitionOfDisabilityTypeEnum)item.BuyUpPlan.DefinitionOfDisabilityId);// ((DefinitionOfDisabilityTypeEnum)item.BuyUpPlan.DefinitionOfDisabilityId).GetDescription();
                    classReq.BPMentalSubstance = _illustrationDocumentGenerator.GetMentalSubstanceDescription(item.BuyUpPlan.MentalSubstanceId);
                    classReq.VGBPPrexCondition = ((PreExistingConditionLimitTypeEnum)item.BuyUpPlan.PreExistingConditionLimitationId).GetDescription();
                    classReq.VGBPEliminationPeriod = ((EliminationPeriodTypeEnum)item.BuyUpPlan.EliminationPeriodId).GetDescription();
                    classReq.VGBPBenefitPeriod = ((BenefitPeriodTypeEnum)item.BuyUpPlan.BenefitPeriodId).GetDescription();
                    //classReq.VGBPMaxReplacementPercent = item.BuyUpPlan.ReplacementRatio.ToString();
                    classReq.VGBPMaxReplacementPercent = buyupPlan.ReplacementPercentage.ToString();
                    classReq.VGBPRiders = GetRiderDetails(item.BuyUpPlan.Benefits, contractState.Value);
                    classReq.VGBPRiderCount = classReq.VGBPRiders.Count().ToString();
                    classReq.VGBPPlanDesignType = _illustrationDocumentGenerator.GetPlanDesignTypeDescription(buyupPlan.PlanDesignType);
                    classReq.VGBPPlanDesign = _illustrationDocumentGenerator.GetSoldBuyUpPlanDesignDescription(buyupPlan);
                    classReq.VGBPInsurableIncome = buyupPlan.InsurableIncomeDefinition;
                    classReq.BPMaximumIp = _illustrationDocumentGenerator.GetMaximumIPDescription(buyupPlan.PlanDesignType, primaryplan.PDRSoldClass.PlanDesignRequestClass, unitOfWork);
                    classReq.BPParticipantionRequired = buyupPlan.ParticipationPercentage + "%";
                    classReq.VGBPMaxGSIOffer = item.BuyUpPlan.GSIMaxAmount;
                }

                var ltdCoverageSold = planDesignRequestSoldClass.PDRSoldClassLTDCoverage.FirstOrDefault(x => x.PDRSoldClass.PlanDesignRequestClass.Id == item.TitanClassId);
                if (ltdCoverageSold != null && (primaryplan.PlanDesignType != PlanDesignTypeEnum.StandAloneIDIPlan || primaryplan.PlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan))
                {
                    classReq.IsGroupLTDDesign = ltdCoverageSold != null ? true : false;
                    classReq.PercentOfBaseSalary = ltdCoverageSold != null ? ltdCoverageSold.GroupLTDReplacementPercentage + "%" : string.Empty;

                    classReq.BaseSalary = _illustrationDocumentGenerator.GetSoldBaseSalaryDescription(planDesignRequestSoldClass);

                    classReq.MaxSalaryK = string.Format("{0:C2}", ltdCoverageSold.GroupLTDCapAmount);
                    string ltdPremiumPayer = ltdCoverageSold.PremiumAndTaxpayerLiabilityType != null ? ltdCoverageSold.PremiumAndTaxpayerLiabilityType.Description : string.Empty;
                    classReq.GroupLTDPremiumPayer = ltdCoverageSold.TypeOfPayType != null ? ltdPremiumPayer + " / " + ltdCoverageSold.TypeOfPayType.GetDescription() : ltdPremiumPayer;
                }
                else
                {
                    // For StandAlonePlanIDI LTDCoverage not mandatory
                    classReq.IsGroupLTDDesign = false;
                    classReq.PercentOfBaseSalary = string.Empty;
                    classReq.BaseSalary = string.Empty;
                    classReq.MaxSalaryK = string.Empty;
                    classReq.GroupLTDPremiumPayer = string.Empty;
                }

                classReq.EligibleEmployees = planDesignRequestSoldClass.PlanDesignRequestClass.CensusParticipants.Where(p => (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null)).Count().ToString();
                classReq.CreationDate = DateTime.Now.ToString("MMMM dd, yyyy");

                var enrollmentMgr = unitOfWork.Repository<CmsUser>().Linq().Where(t=>t.Id== cmsCase.EnrollmentManagerId).FirstOrDefault();
                if (enrollmentMgr != null)
                {
                    classReq.EnrollmentManager = enrollmentMgr.LastName + " " + enrollmentMgr.FirstName;
                }
                else
                {
                    classReq.EnrollmentManager = string.Empty;
                }
            }

        }

        private void AddCostShareGSIPlanTags(OfferLetterDocumentClassRequest classReq, TypeOfShareTypeEnum? typeOfShareType, decimal? employerPaidPremiumPercentage, CostShareTaxabilityType costShareTaxabilityType, decimal? employerPaysupto)
        {
            var taxableNonTaxable = string.Empty;
            if (costShareTaxabilityType != null)
            {
                if (costShareTaxabilityType.Id == (int)CostShareTaxabilityTypeEnum.EmployerPaidPortionTaxable)
                {
                    taxableNonTaxable = "Taxable";
                }
                else if (costShareTaxabilityType.Id == (int)CostShareTaxabilityTypeEnum.EmployerPaidPortionNonTaxable)
                {
                    taxableNonTaxable = "Non-Taxable";
                }
            }

            classReq.CostShareTaxable = taxableNonTaxable;

            if (typeOfShareType != null && typeOfShareType == TypeOfShareTypeEnum.PercentofPremium)
            {
                classReq.CostSharePercentage = string.Format("{0:P2}", employerPaidPremiumPercentage / 100.00m);
            }
            else if (typeOfShareType != null && typeOfShareType == TypeOfShareTypeEnum.PremiumAmount)
            {
                classReq.CostSharePremiumAmount = string.Format("{0:C2}", employerPaysupto);
            }

        }

        private void StoreOfferLetterDocumentIdsToDatabase(int offerLetterId, CaseDocument pdfDocumentId)
        {
            try
            {
                Log.TraceFormat("Store offer letter document ids to DB.");
                using (var unitOfWork = UnitOfWorkFactory.CreateUnitOfWork())
                {
                    var offerLetter = unitOfWork.Repository<OfferLetter>().Linq().FirstOrDefault(q => q.Id == offerLetterId);
                    if (offerLetter != null)
                    {
                        offerLetter.OfferLetterPdfDocument = pdfDocumentId;

                        unitOfWork.Repository<OfferLetter>().Save(offerLetter);
                        unitOfWork.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error saving offer letter doc id in DB", ex);
                throw;
            }
        }

        public List<ClassRider> GetRiderDetails(List<IllustrationRequestBenefit> benefits, StateTypeEnum contractState)
        {
            Log.TraceFormat("+GetRiderDetails");

            List<ClassRider> riderDetails = new List<ClassRider>();

            foreach (var rider in benefits)
            {
                if (rider.BenefitId != 0)
                {
                    var riderBenefit = new ClassRider();
                    switch ((BenefitGroupTypeEnum)rider.BenefitGroupTypeId)
                    {
                        case BenefitGroupTypeEnum.PartialDisability:
                            if (rider.BenefitId != 0)
                            {
                                riderBenefit.RiderFullName = string.Format("{0}", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                                riderBenefit.RiderEP = "";
                                riderBenefit.RiderBT = "";
                                riderBenefit.RiderBenefitAmt = "";
                            }
                            break;

                        case BenefitGroupTypeEnum.CatastrophicDisabilityBenefit:
                            riderBenefit.RiderFullName = string.Format("{0} Benefit Rider (CAT)", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                            riderBenefit.RiderEP = "";
                            riderBenefit.RiderBT = "";
                            riderBenefit.RiderBenefitAmt = string.Format("{0:C2}", rider.Amount);

                            if (isCompactState)
                            {
                                if ((BenefitTypeEnum)rider.BenefitId == BenefitTypeEnum.BasicCatastrophicDisabilityBenefitRider)
                                {
                                    riderBenefit.RiderFullName = "Severe Disability Rider";
                                }
                            }

                            break;

                        case BenefitGroupTypeEnum.CostOfLivingAdjustment:

                            riderBenefit.RiderFullName = string.Format("{0} (COLA)", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                            riderBenefit.RiderEP = "";
                            riderBenefit.RiderBT = "";
                            riderBenefit.RiderBenefitAmt = "";
                            break;

                        case BenefitGroupTypeEnum.RetirementProtectionPlusDisabilityBenefit:

                            riderBenefit.RiderFullName = "Retirement Protection Plus (RPP)";
                            riderBenefit.RiderEP = string.Format("{0} Day EP", ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Contains("Days") ? ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Replace("Days", "") : ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription());
                            riderBenefit.RiderBT = "";
                            riderBenefit.RiderBenefitAmt = string.Format("{0:C2}", rider.Amount);
                            break;

                        case BenefitGroupTypeEnum.StudentLoanProtectionRider:

                            riderBenefit.RiderFullName = "Student Loan Protection Rider (SLP)";
                            riderBenefit.RiderEP = string.Format("{0} Day EP", ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Contains("Days") ? ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Replace("Days", "") : ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription());
                            riderBenefit.RiderBT = string.Format("{0} Year BT", ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription().Contains("Years") ? ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription().Replace("Years", "") : ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription());
                            riderBenefit.RiderBenefitAmt = string.Format("{0:C2}", rider.Amount);
                            break;

                        case BenefitGroupTypeEnum.SupplementalBenefit:

                            riderBenefit.RiderFullName = "Supplemental Benefit Term Rider (SBT)";
                            riderBenefit.RiderEP = string.Format("{0} Day EP", ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Contains("Days") ? ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription().Replace("Days", "") : ((EliminationPeriodTypeEnum)rider.EliminationPeriodId).GetDescription());
                            riderBenefit.RiderBT = string.Format("{0} Year BT", ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription().Contains("Years") ? ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription().Replace("Years", "") : ((BenefitPeriodTypeEnum?)rider.BenefitPeriodId).GetDescription());
                            riderBenefit.RiderBenefitAmt = string.Format("{0:C2}", rider.Amount);
                            break;

                        case BenefitGroupTypeEnum.UnemploymentPremiumWaiver:

                            riderBenefit.RiderFullName = string.Format("{0}", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                            riderBenefit.RiderEP = "";
                            riderBenefit.RiderBT = "";
                            riderBenefit.RiderBenefitAmt = "";
                            break;

                        case BenefitGroupTypeEnum.Endorsement:

                            riderBenefit.RiderFullName = string.Format("{0}", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                            riderBenefit.RiderEP = "";
                            riderBenefit.RiderBT = "";
                            riderBenefit.RiderBenefitAmt = "";
                            break;

                        case BenefitGroupTypeEnum.ExtendedBenefits:

                            riderBenefit.RiderFullName = string.Format("{0}", ((BenefitTypeEnum)rider.BenefitId).GetDescription());
                            riderBenefit.RiderEP = "";
                            riderBenefit.RiderBT = "";
                            riderBenefit.RiderBenefitAmt = "";
                            break;
                    }                    
                        riderDetails.Add(riderBenefit);                   
                }
            }

            Log.TraceFormat("-GetRiderDetails");
            return riderDetails;
        }
        public string GetDefinitionOfDisablity(DefinitionOfDisabilityTypeEnum definitionOfDisabilityTypeEnum)
        {
            Log.TraceFormat("+GetDefinitionOfDisablity");
            string definitionOfDisabilityTypeDescription = "";
            switch ((DefinitionOfDisabilityTypeEnum)definitionOfDisabilityTypeEnum)
            {

                case DefinitionOfDisabilityTypeEnum.EnhancedMedicalSpecialtyOwnOcc:
                    definitionOfDisabilityTypeDescription = "True Own Occupation with Enhanced Medical Specialty";
                    break;

                case DefinitionOfDisabilityTypeEnum.SpecialtyOwnOcc:
                    definitionOfDisabilityTypeDescription = "True Own Occupation with Medical/Dental Specialty";
                    break;

                case DefinitionOfDisabilityTypeEnum.TruewithNoSpecialty:
                    definitionOfDisabilityTypeDescription = "True Own Occupation";
                    break;

                case DefinitionOfDisabilityTypeEnum.TwoYearTrueOwnOcc:
                    definitionOfDisabilityTypeDescription = "Two Year True Own Occupation (Modified Thereafter)";
                    break;
                case DefinitionOfDisabilityTypeEnum.ModifiedOwnOccupation:
                    definitionOfDisabilityTypeDescription = "Modified Own Occupation";
                    break;
                case DefinitionOfDisabilityTypeEnum.TwoYearModifiedOwnOcc:
                    definitionOfDisabilityTypeDescription = "Two Year Modified Own Occupation (Any Occupation Thereafter)";
                    break;

            }
            Log.TraceFormat("-GetDefinitionOfDisablity");
            return definitionOfDisabilityTypeDescription;
        }
    }
}
