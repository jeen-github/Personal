﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.ProductLibraryManagers;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Utilities;
using Logger.Static;
using Newtonsoft.Json;
using System;

namespace CMS.Managers.DocumentManagers.DocumentGenerators
{
    public class PostCardXmlGenerator : DocumentGenerator, IPostCardXmlGenerator, IWorkUnitHandler
    {
        private readonly IWorkUnitManager _workUnitManager;
        public PostCardXmlGenerator(IUnitOfWorkFactory unitOfWorkFactory, IWorkUnitManager workUnitManager,
            IProductLibraryManager productLibraryManager) : base(unitOfWorkFactory, productLibraryManager)
        {
            _workUnitManager = workUnitManager;
        }


        public void EnqueueRequest(PostCardXmlGenerationRequest request)
        {
            Log.TraceFormat("+EnqueueRequest");
            try
            {
                var splittedParticipantsIds = request.ParticipantIds.ChunkBy(1000);

                foreach (var item in splittedParticipantsIds)
                {
                    if (request.ParticipantIds.Count > 0)
                    {
                        request.ParticipantIds.RemoveAll(c => c != -1);
                    }
                    request.ParticipantIds.AddRange(item);
                    _workUnitManager.CreateWorkUnit(WorkUnitType.PostCard, JsonConvert.SerializeObject(request));
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error in PostCardXmlGenerator class EnqueueRequest method for EnrollmentId-"+request.EnrollmentId, ex);
            }
            Log.TraceFormat("-EnqueueRequest");
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.TraceFormat("+Execute");
            try
            {
                var request = JsonConvert.DeserializeObject<PostCardXmlGenerationRequest>(workUnit.InputData);
                var splittedParticipantsIds = request.ParticipantIds.ChunkBy(1000);

                foreach (var item in splittedParticipantsIds)
                {
                    if (request.ParticipantIds.Count > 0)
                    {
                        request.ParticipantIds.RemoveAll(c => c != -1);
                    }
                    request.ParticipantIds.AddRange(item);

                    var cmsCase = GetCase(request.CaseId);

                    var docRequestXml = CreatePostCardKitXml(request);

                    var caseDocumentRequest = new CaseDocumentRequest();

                    caseDocumentRequest = CreateCaseDocumentRequest(docRequestXml, cmsCase, CaseDocumentTypeEnum.PostCard);
                    var caseDocument = CreateCaseDocument(caseDocumentRequest, cmsCase, CaseDocumentTypeEnum.PostCard, ExtreamDocumentType.PDF, null, null);

                    _workUnitManager.CreateWorkUnit(WorkUnitType.ExtreamFileUpload, caseDocumentRequest.Id.ToString());
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error in PostCardXmlGenerator class Execute method for workunitId-"+workUnit.Id,ex);               
            }
            Log.TraceFormat("-Execute");
        }
        private string CreatePostCardKitXml(PostCardXmlGenerationRequest request)
        {
            Log.TraceFormat("+CreatePostCardKitXml");
            try
            {
                var postCardXmlBuilder = new PostCardXmlBuilder(UnitOfWorkFactory);

                var postCardXml = new PostCardXml();

                postCardXmlBuilder.CreatePostCardXml(request, postCardXml);

                var updatedXMLPostCard = SerializeObject(postCardXml);               

                return updatedXMLPostCard;
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Error in PostCardXmlGenerator class CreatePostCardKitXml method for EnrollmentId-"+request.EnrollmentId, ex);
            }
            Log.TraceFormat("-CreatePostCardKitXml");
            return null;           
        }        
    }
}
