﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.OfferLetterManagers;
using CMS.Model.Entities;
using Common.Exceptions;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMS.Managers.OfferLetterManagers
{
    public class OfferLetterRequestDatabaseManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public OfferLetterRequestDatabaseManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }
    }
}
