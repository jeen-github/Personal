﻿using CMS.Interfaces.Managers.OfferLetterManagers;
using Common.Exceptions;
using Logger.Static;
using System.Collections.Generic;
using System.Linq;

namespace CMS.Managers.OfferLetterManagers
{
    public class OfferLetterRequestManagerValidator
    {
        public void ValidateOfferLetterRequestData(List<SignedOfferLetterDto> signedOfferLetterDtos)
        {
            Log.TraceFormat("+ValidateOfferLetterRequestData");
            var errorMessages = new List<string>();
            ValidateSigendDocument(errorMessages, signedOfferLetterDtos);

            ValidateIllustration(errorMessages, signedOfferLetterDtos);


            if (errorMessages.Any()) throw new ValidationException(errorMessages);
            Log.TraceFormat("-ValidateOfferLetterRequestData");
        }
        public void ValidateSigendDocument(List<string> errorMessages, List<SignedOfferLetterDto> offerLetterDtos)
        {
            Log.TraceFormat("+ValidateSigendDocument");
            var i = 0;
            foreach (var offerLetterDto in offerLetterDtos)
            {
                i++;
                if (offerLetterDto.OfferLetterId == 0)
                {
                    errorMessages.Add("Please select Sigend Document " + i.ToString() + ".");
                }
            }
            Log.TraceFormat("-ValidateSigendDocument.");
        }

        public void ValidateIllustration(List<string> errorMessages, List<SignedOfferLetterDto> offerLetterDtos)
        {
            Log.TraceFormat("+ValidateIllustration");
            var i = 0;
            foreach (var offerLetterDto in offerLetterDtos)
            {

                foreach (var offerLetterIllustration in offerLetterDto.SignedOfferLetterIllustrations)
                {
                    i++;
                    if (offerLetterIllustration.IllustrationId == 0)
                    {
                        errorMessages.Add("Please select Illustration " + i.ToString() + ".");
                    }
                }
                
            }
            Log.TraceFormat("-ValidateIllustration.");
        }
    }
}
