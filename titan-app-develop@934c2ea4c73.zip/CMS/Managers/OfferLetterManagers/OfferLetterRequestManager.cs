﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.DocumentManagers.DocumentGenerators;
using CMS.Interfaces.Managers.OfferLetterManagers;
using CMS.Interfaces.Managers.PlanManagers;
using CMS.Interfaces.Managers.TaskManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Exceptions;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMS.Managers.OfferLetterManagers
{
    public class OfferLetterRequestManager : IOfferLetterRequestManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly OfferLetterRequestManagerValidator _offerLetterRequestManagerValidator;
        private readonly IOfferLetterDocumentGenerator _offerLetterDocumentGenerator;
        private readonly IPlanDesignRequestSaveSoldManager _planDesignRequestSaveSoldManager;
        private readonly ITaskManager _taskManager;
        private readonly ICaseManager _caseManager;

        public OfferLetterRequestManager(IUnitOfWorkFactory unitOfWorkFactory, IOfferLetterDocumentGenerator offerLetterDocumentGenerator,
            IPlanDesignRequestSaveSoldManager planDesignRequestSaveSoldManager,
            ITaskManager taskManager, ICaseManager caseManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _offerLetterRequestManagerValidator = new OfferLetterRequestManagerValidator();
            _offerLetterDocumentGenerator = offerLetterDocumentGenerator;
            _planDesignRequestSaveSoldManager = planDesignRequestSaveSoldManager;
            _taskManager = taskManager;
            _caseManager = caseManager;
        }

        public int? SaveRequest(OfferLetterDto offerLetterRequest)
        {
            Log.TraceFormat("+SaveRequest");
            int? offerLetterId = null;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var passedCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.CaseNumber == offerLetterRequest.CaseNumber);
                if (passedCase == null) throw new ValidationException("Case number not found!");
                if (!offerLetterRequest.OfferLetterIllustrations.Any()) throw new ValidationException("No quotes exist with this offer letter.");

                var offerLetter = new OfferLetter
                {
                    Case = passedCase,
                    IsReleasedToGA = false,
                    IsExternalRequestIndicator = offerLetterRequest.IsExternalRequestIndicator,
                    Version = 1,
                    OfferLetterIllustrations = new List<OfferLetterIllustration>()
                };

                offerLetter.OfferLetterName = GetOfferLetterName(passedCase.CaseNumber, offerLetterRequest.OfferLetterIllustrations.Select(i => i.IllustrationId).ToList());

                foreach (var offerLetterIllustration in offerLetterRequest.OfferLetterIllustrations)
                {
                    var requestedIllustration = unitOfWork.Repository<Illustration>().Linq().FirstOrDefault(c => c.Id == offerLetterIllustration.IllustrationId);
                    if (requestedIllustration == null) throw new ValidationException("Invalid quotes send in the offer letter request.");

                    var newOfferLetterIllustration = new OfferLetterIllustration
                    {
                        Illustration = requestedIllustration,
                        OfferLetter = offerLetter
                    };
                    offerLetter.OfferLetterIllustrations.Add(newOfferLetterIllustration);

                    requestedIllustration.IllustrationGAStatusType = IllustrationGAStatusTypeEnum.OfferLetterRequested;
                    unitOfWork.Repository<Illustration>().Save(requestedIllustration);
                }

                offerLetter.OfferLetterStatusHistories.Add(new OfferLetterStatusHistory
                {
                    OfferLetterStatusType = OfferLetterStatusTypeEnum.New,
                    DateOfChange = DateTime.Now,
                    OfferLetter = offerLetter
                });

                unitOfWork.Repository<OfferLetter>().Save(offerLetter);

                GenerateTaskForOfferLetterRequest(passedCase, unitOfWork);

                unitOfWork.Commit();
                offerLetterId = offerLetter.Id;
            }
            Log.TraceFormat("-SaveRequest");

            return offerLetterId;
        }

        public List<OfferLetterDto> GetReleasedOfferLetters(string titanCaseNumber)
        {
            Log.TraceFormat("+GetReleasedOfferLetters");
            var offerLetterDtos = new List<OfferLetterDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var offerLetters = unitOfWork.Repository<OfferLetter>().Linq().Where(c => c.Case.CaseNumber == titanCaseNumber && (c.IsReleasedToGA || c.IsExternalRequestIndicator)).ToList();

                if (offerLetters.Any())
                {
                    offerLetterDtos = offerLetters.Select(t => new OfferLetterDto
                    {
                        OfferLetterId = t.Id,
                        CaseId = t.Case.Id,
                        CaseNumber = t.Case.CaseNumber,
                        OfferLetterName = GetOfferLetterName(titanCaseNumber, t.OfferLetterIllustrations.Select(c => c.Illustration.Id).ToList()),
                        IsReleasedToGA = t.IsReleasedToGA,
                        OfferLetterPdfDocumentId = t.OfferLetterPdfDocument != null && t.IsReleasedToGA ? t.OfferLetterPdfDocument.Id : (long?)null,
                        ReleasedDateTime = t.ReleasedDateTime,
                        OfferLetterIllustrations = t.OfferLetterIllustrations.Select(p => new OfferLetterIllustrationDto
                        {
                            OfferLetterIllustrationId = p.Id,
                            OfferLetterID = t.Id,
                            IllustrationId = p.Illustration.Id
                        }).ToList()
                    }).ToList();
                }
            }
            Log.TraceFormat("-GetReleasedOfferLetters");
            return offerLetterDtos;
        }

        public List<OfferLetterDto> GetOfferLetters(int caseId)
        {
            Log.TraceFormat("+GetOfferLetters");
            var offerLetterDtos = new List<OfferLetterDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var offerLetters = unitOfWork.Repository<OfferLetter>().Linq()
                    .Where(c => c.Case.Id == caseId && c.OfferLetterIllustrations.Any(i => i.Illustration.PlanDesignRequest.IsActive) && (c.OfferLetterPdfDocument != null ? c.OfferLetterPdfDocument.IsDeleted == false : true))
                    .ToList();
                if (offerLetters.Any())
                {
                    offerLetterDtos = offerLetters.Select(t => new OfferLetterDto
                    {

                        OfferLetterId = t.Id,
                        CaseId = t.Case.Id,
                        CaseNumber = t.Case.CaseNumber,
                        OfferLetterName = t.OfferLetterName,
                        OfferLetterPdfDocumentId = t.OfferLetterPdfDocument != null ? t.OfferLetterPdfDocument.Id : (long?)null,
                        OfferLetterWordDocumentId = t.OfferLetterWordDocument != null ? t.OfferLetterWordDocument.Id : (long?)null,
                        ReleasedDateTime = t.ReleasedDateTime,
                        Version = t.Version,
                        OfferLetterStatusHistories = t.OfferLetterStatusHistories.Select(p => new OfferLetterStatusHistoryDto
                        {
                            OfferLetterStatusType = p.OfferLetterStatusType,
                            TitanUser = p.TitanUser,
                            ApprovedByUser = p.ApprovedByUser,
                            DateOfChange = p.DateOfChange
                        }).OrderByDescending(i => i.DateOfChange).FirstOrDefault(),
                        OfferLetterIllustrations = t.OfferLetterIllustrations.Select(p => new OfferLetterIllustrationDto
                        {
                            OfferLetterIllustrationId = p.Id,
                            OfferLetterID = t.Id,
                            IllustrationId = p.Illustration.Id,
                            QuoteName = p.Illustration.QuoteName
                        }).ToList()
                    }).ToList();
                }
            }
            Log.TraceFormat("-GetOfferLetters");
            return offerLetterDtos;
        }

        public List<SignedOfferLetterDto> GetSignedOfferLetters(int caseId)
        {
            Log.TraceFormat("+GetSignedOfferLetters");

            List<SignedOfferLetterDto> signedOfferLetterDtos;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                signedOfferLetterDtos = unitOfWork.Repository<CaseDocument>().Linq()
                    .Where(c => c.Case_Id == caseId && c.CaseDocumentType == CaseDocumentTypeEnum.OfferLetter && c.IsExternalIndicator)
                    .Select(t => new SignedOfferLetterDto
                    {
                        CaseId = t.Case_Id,
                        Version = t.Version,
                        SignedOfferLetterDocumentId = t.Id,
                        Status = "New"
                    }).ToList();
                if (signedOfferLetterDtos.Any())
                {
                    foreach (var signedOffletterDto in signedOfferLetterDtos)
                    {
                        if (signedOffletterDto != null)
                        {

                            var approvedSignedOfferLetters = unitOfWork.Repository<OfferLetter>().Linq().Where(c => c.SignedOfferLetterDocument.Id == signedOffletterDto.SignedOfferLetterDocumentId).ToList();

                            var offerletterNames = signedOfferLetterDtos.Select(so => so.OfferLetterName).ToList();
                            if (approvedSignedOfferLetters.Any())
                            {
                                signedOffletterDto.Status = "Approved";
                                signedOffletterDto.OfferLetterId = approvedSignedOfferLetters.Any() ? approvedSignedOfferLetters.FirstOrDefault().Id : 0;
                                signedOffletterDto.OfferLetterName = approvedSignedOfferLetters.Any() ? String.Join(" , ", approvedSignedOfferLetters.Select(ao => ao.OfferLetterName).ToArray()) : "";
                                signedOffletterDto.OfferLetterSignedDate = approvedSignedOfferLetters.Any() ? String.Join(",", approvedSignedOfferLetters.Select(x => x.OfferLetterSignedDate != null ? x.OfferLetterSignedDate.Value.ToString(@"MM\/dd\/yyyy") : null)) : null;
                                signedOffletterDto.SignedOfferLetterIllustrations = approvedSignedOfferLetters.SelectMany(ao => ao.OfferLetterIllustrations).Select(p => new OfferLetterIllustrationDto
                                {
                                    OfferLetterIllustrationId = p.Id,
                                    OfferLetterID = p.OfferLetter.Id,
                                    IllustrationId = p.Illustration.Id,
                                    QuoteName = p.Illustration.QuoteName
                                }).ToList();
                                var approvedOfferLetter = approvedSignedOfferLetters.Any() ? approvedSignedOfferLetters.FirstOrDefault() : null;
                                if (approvedOfferLetter != null)
                                {
                                    signedOffletterDto.StatusDateTime = approvedOfferLetter.OfferLetterStatusHistories != null ? approvedOfferLetter.OfferLetterStatusHistories.Where(olst => olst.OfferLetterStatusType == OfferLetterStatusTypeEnum.Sold).OrderByDescending(x => x.Id).Select(p => p.DateOfChange).FirstOrDefault() : signedOffletterDto.StatusDateTime;
                                }
                            }
                        }
                    }
                }
            }

            Log.TraceFormat("-GetSignedOfferLetters");
            return signedOfferLetterDtos;
        }

        public void SaveSoldOfferLetters(List<SignedOfferLetterDto> signedOfferLetters, string titanUser)
        {
            try
            {
                Log.TraceFormat("+OfferLetterRequestManager.SaveSoldOfferLetters");
                _offerLetterRequestManagerValidator.ValidateOfferLetterRequestData(signedOfferLetters);
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    foreach (var signedOfferLetter in signedOfferLetters)
                    {
                        var offerLetter = unitOfWork.Repository<OfferLetter>().Linq().FirstOrDefault(c => c.Id == signedOfferLetter.OfferLetterId);
                        var signedOfferLetterDoc = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == signedOfferLetter.SignedOfferLetterDocumentId);
                        if (offerLetter != null)
                        {
                            offerLetter.SignedOfferLetterDocument = signedOfferLetterDoc;
                            offerLetter.OfferLetterSignedDate = !string.IsNullOrEmpty(signedOfferLetter.OfferLetterSignedDate) ? (DateTime?)Convert.ToDateTime(signedOfferLetter.OfferLetterSignedDate) : null;
                            OfferLetterStatusHistory statusHistory = new OfferLetterStatusHistory();
                            statusHistory.OfferLetter.Id = offerLetter.Id;
                            statusHistory.OfferLetterStatusType = OfferLetterStatusTypeEnum.Sold;
                            statusHistory.TitanUser = titanUser;
                            statusHistory.DateOfChange = DateTime.Now;
                            offerLetter.OfferLetterStatusHistories.Add(statusHistory);
                            unitOfWork.Repository<OfferLetter>().Save(offerLetter);
                        }
                    }
                    unitOfWork.Commit();
                }
                var signedOffletterIllustartions = signedOfferLetters.SelectMany(so => so.SignedOfferLetterIllustrations).ToList();
                if (signedOffletterIllustartions.Any())
                {
                    _planDesignRequestSaveSoldManager.SaveSoldPDRInformation(signedOffletterIllustartions);
                }
                Log.TraceFormat("-OfferLetterRequestManager.SaveSoldOfferLetters");
            }
            catch (Exception ex)
            {
                Log.ErrorFormat($"-OfferLetterRequestManager.SaveSoldOfferLetters", ex);
            }
        }

        public void ReleaseOfferLetter(List<int> selectedOfferLetterIds, string titanUser)
        {
            Log.TraceFormat("+ReleaseOfferLetter");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                if (selectedOfferLetterIds.Any())
                {
                    int caseId = 0;

                    var offerLetters = unitOfWork.Repository<OfferLetter>().Linq().Where(c => selectedOfferLetterIds.Contains(c.Id));
                    foreach (OfferLetter offerLetter in offerLetters)
                    {
                        if (offerLetter != null)
                        {
                            caseId = offerLetter.Case.Id;
                            offerLetter.ReleasedDateTime = DateTime.Now;
                            offerLetter.IsReleasedToGA = true;

                            OfferLetterStatusHistory statusHistory = new OfferLetterStatusHistory();
                            statusHistory.OfferLetter.Id = offerLetter.Id;
                            statusHistory.OfferLetterStatusType = OfferLetterStatusTypeEnum.Released;
                            statusHistory.TitanUser = titanUser;
                            statusHistory.DateOfChange = DateTime.Now;
                            offerLetter.OfferLetterStatusHistories.Add(statusHistory);
                            unitOfWork.Repository<OfferLetter>().Save(offerLetter);

                            var offerLetterIllustrations = unitOfWork.Repository<OfferLetterIllustration>().Linq().Where(c => selectedOfferLetterIds.Contains(c.OfferLetter.Id)).Select(c => c.Illustration.Id).Distinct();
                            if (offerLetterIllustrations.Any())
                            {
                                var illustrations = unitOfWork.Repository<Illustration>().Linq().Where(c => offerLetterIllustrations.Contains(c.Id));
                                foreach (var illustration in illustrations)
                                {
                                    illustration.IllustrationGAStatusType = IllustrationGAStatusTypeEnum.FormalOffer;
                                    unitOfWork.Repository<Illustration>().Save(illustration);

                                    var planDesignRequest = illustration.PlanDesignRequest;
                                    planDesignRequest.PlanDesignRequestStatusType = PlanDesignRequestStatusTypeEnum.FormalOffer;

                                    var pdrStatusHistory = new PlanDesignRequestStatusHistory();
                                    pdrStatusHistory.PlanDesignRequest = planDesignRequest;
                                    pdrStatusHistory.PlanDesignRequestStatusType = PlanDesignRequestStatusTypeEnum.FormalOffer;
                                    pdrStatusHistory.DateOfChange = DateTime.Now;
                                    planDesignRequest.PlanDesignRequestStatusHistories.Add(pdrStatusHistory);
                                    unitOfWork.Repository<PlanDesignRequest>().Save(planDesignRequest);
                                }
                            }
                            
                        }
                    }
                    unitOfWork.Commit();

                    if (caseId > 0)
                    {
                        var request = new CaseStatusDto
                        {
                            CaseId = caseId,
                            CaseStatusType = CaseStatusTypeEnum.FormalOffer,
                        };
                        _caseManager.SaveCaseStatusAndPDRStatus(request);
                    }
                }
            }
            Log.TraceFormat("-ReleaseOfferLetter");
        }

        public List<OfferLetterIllustrationDto> GetIllustrations(int offerLetterId)
        {
            Log.TraceFormat("+GetOfferLetterIllustrations");
            var illustrationDtos = new List<OfferLetterIllustrationDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var illustrations = unitOfWork.Repository<OfferLetterIllustration>().Linq().Where(c => c.OfferLetter.Id == offerLetterId);
                if (illustrations.Any())
                {
                    illustrationDtos = illustrations.Select(t => new OfferLetterIllustrationDto
                    {
                        OfferLetterID = t.OfferLetter.Id,
                        QuoteName = t.Illustration.QuoteName,
                        IllustrationId = t.Illustration.Id,
                    }).ToList();
                }
            }
            Log.TraceFormat("-GetOfferLetterIllustrations");
            return illustrationDtos;
        }

        private string GetOfferLetterName(string titancasenumber, List<int> offerLetterIllustrationIds)
        {
            List<string> offerLetterNameList = new List<string>();
            string quotes = "";
            string offerLetterName = "";
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmscase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.CaseNumber == titancasenumber);
                var planDesignRequests = cmscase.PlanDesignRequests.Where(c => c.Case.CaseNumber == cmscase.CaseNumber).ToList();
                foreach (var pdr in planDesignRequests)
                {
                    var illustrationList = unitOfWork.Repository<Illustration>().Linq().Where(c => c.PlanDesignRequest.Id == pdr.Id && offerLetterIllustrationIds.Contains(c.Id)).ToList();
                    if (illustrationList.Any())
                    {
                        offerLetterName = pdr.PDRName != null ? pdr.PDRName : pdr.GAPlanDesignRequestId;
                        quotes = string.Join(", ", (illustrationList.Select(c => c.QuoteName)));
                        offerLetterName += " (" + quotes + ")";
                        offerLetterNameList.Add(offerLetterName);
                    }
                }
            }
            offerLetterName = string.Join(", ", (offerLetterNameList));
            return offerLetterName;
        }

        private void GenerateTaskForOfferLetterRequest(Case cmsCase, IUnitOfWork unitOfWork)
        {
            Log.TraceFormat("-GenerateTaskForOfferLetterRequest");

            //var dueTimeSpan = TimeSpan.FromDays(10);
            //var taskName = "Offer Letter for case \"" + cmsCase.CaseNumber + "\" Company \"" + cmsCase.CompanyName + "\" is ready for Underwriter review";

            var taskSLA = unitOfWork.Repository<TaskSLAType>().Linq();
            var taskSLAForOfferLetterReady = taskSLA.Where(i => i.ShortDescription == "OfferLetterReady").FirstOrDefault();

            if (taskSLAForOfferLetterReady != null)
            {
                var taskName = string.Format(taskSLAForOfferLetterReady.TaskName, cmsCase.CaseNumber, cmsCase.CompanyName);
                var assignedUserId = _taskManager.GetAssignedUserId(cmsCase.Id);
                _taskManager.CreateTask(cmsCase.Id, taskName, UserGroup.Group_Underwriting, assignedUserId, taskSLAForOfferLetterReady.SLAInHours, taskSLAForOfferLetterReady.isSameDayResponseRequired);
            }

            Log.TraceFormat("-GenerateTaskForOfferLetterRequest");
        }
        public void WithdrawOfferLetters(List<int> selectedOfferLetterIds, string titanUser)
        {
            Log.TraceFormat("+WithdrawOfferLetters");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                if (selectedOfferLetterIds.Any())
                {
                    var offerLetters = unitOfWork.Repository<OfferLetter>().Linq().Where(c => selectedOfferLetterIds.Contains(c.Id));
                    foreach (OfferLetter offerLetter in offerLetters)
                    {
                        if (offerLetter != null)
                        {
                            offerLetter.ReleasedDateTime = DateTime.Now;
                            offerLetter.IsReleasedToGA = false;
                            offerLetter.IsExternalRequestIndicator = false;
                            OfferLetterStatusHistory statusHistory = new OfferLetterStatusHistory();
                            statusHistory.OfferLetter.Id = offerLetter.Id;
                            statusHistory.OfferLetterStatusType = OfferLetterStatusTypeEnum.Withdrawn;
                            statusHistory.TitanUser = null;
                            statusHistory.DateOfChange = DateTime.Now;
                            offerLetter.OfferLetterStatusHistories.Add(statusHistory);
                            unitOfWork.Repository<OfferLetter>().Save(offerLetter);

                            var offerLetterIllustrations = unitOfWork.Repository<OfferLetterIllustration>().Linq().Where(c => selectedOfferLetterIds.Contains(c.OfferLetter.Id)).Select(c => c.Illustration.Id).Distinct();
                            if (offerLetterIllustrations.Any())
                            {
                                var illustrations = unitOfWork.Repository<Illustration>().Linq().Where(c => offerLetterIllustrations.Contains(c.Id));
                                foreach (var illustration in illustrations)
                                {
                                    illustration.IllustrationGAStatusType = IllustrationGAStatusTypeEnum.FormalOffer;
                                    unitOfWork.Repository<Illustration>().Save(illustration);
                                }
                            }
                        }
                    }
                    unitOfWork.Commit();
                }
            }
            Log.TraceFormat("-WithdrawOfferLetters");
        }

        public void DeleteOfferLetters(List<int> selectedOfferLetterIds, string titanUser)
        {
            Log.TraceFormat("+DeleteOfferLetters");
            if (selectedOfferLetterIds.Any())
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    foreach (var selectedOfferLetterId in selectedOfferLetterIds)
                    {
                        var offerLetters = unitOfWork.Repository<OfferLetter>().Linq().Where(c => c.Id == selectedOfferLetterId);
                        if (offerLetters.Any())
                        {
                            foreach (var offerLetter in offerLetters)
                            {
                                var dbDocument = unitOfWork.Repository<CaseDocument>().Linq().FirstOrDefault(c => c.Id == offerLetter.OfferLetterPdfDocument.Id);
                                if (dbDocument == null)
                                    throw new ApplicationException("Case document not found!");

                                dbDocument.IsDeleted = true;
                                unitOfWork.Repository<CaseDocument>().Save(dbDocument);
                            }
                        }
                    }
                    unitOfWork.Commit();
                }
            }
            Log.TraceFormat("-DeleteOfferLetters");
        }

        public void CreateOfferLetterRequest(OfferLetterRequestDto request)
        {
            Log.TraceFormat("+CreateOfferLetterRequest");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);

                var offerLetterDto = new OfferLetterDto
                {
                    CaseNumber = cmsCase.CaseNumber,
                    IsExternalRequestIndicator = false,
                    OfferLetterIllustrations = new List<OfferLetterIllustrationDto>()
                };

                foreach (var titanQuoteId in request.IllustrationIds)
                {
                    var offerLetterIllustrationDto = new OfferLetterIllustrationDto { IllustrationId = titanQuoteId };
                    offerLetterDto.OfferLetterIllustrations.Add(offerLetterIllustrationDto);
                }

                var offerLetterId = SaveRequest(offerLetterDto);

                if (offerLetterId != null && offerLetterId > 0)
                {
                    request.OfferLetterId = offerLetterId.Value;
                    _offerLetterDocumentGenerator.EnqueueRequest(request);
                }
            }

            Log.TraceFormat("-CreateOfferLetterRequest");
        }
    }
}
