﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Model.Entities;
using Common.Exceptions;
using Logger.Static;
using System.Text.RegularExpressions;
using CMS.Interfaces.Configurations;
using System.Collections.Generic;
using System.Linq;
using System;
using Guardian.Core.Entities.Product.Enums;
using CMS.Model.Enums;

namespace CMS.Managers.CaseManagers
{
    public class WholesalerManager : IWholesalerManager
    {
        public IUnitOfWorkFactory _unitOfWorkFactory { get; set; }
        private readonly WholesalerManagerValidator _caseWholesalerManagerValidator;

        public WholesalerManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _caseWholesalerManagerValidator = new WholesalerManagerValidator();
        }

        public IList<CaseWholesalerDto> GetCaseWholeSaler(int caseId)
        {
            Log.TraceFormat("+GetCaseWholeSaler");

            var caseWholesalerDto = new List<CaseWholesalerDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);

                if (cmsCase == null) throw new ValidationException("Case not found!");

                var caseWholesaler = unitOfWork.Repository<CaseWholesaler>().Linq().Where(c => c.Case.Id == cmsCase.Id);
                if (caseWholesaler.Any())
                {
                    caseWholesalerDto = caseWholesaler.Select(c => new CaseWholesalerDto
                    {
                        CaseWholesalerId = c.Id,
                        CaseId = c.Case.Id,
                        WholesalerRegionId = c.WholesalerRegion.Id,
                        ExternalWholesalerId = c.ExternalWholesaler.Id,
                        IsPrimaryIndicator = c.IsPrimaryIndicator,
                        WholesalerPercent = c.WholesalerPercent
                    }).ToList();

                }
            }

            Log.TraceFormat("-GetCaseWholeSaler");

            return caseWholesalerDto;
        }

        public WholesalersDto GetWholesaler()
        {
            Log.TraceFormat("+GetWholesaler");

            var wholesalersDto = new WholesalersDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                IList<Wholesaler> Wholesaler = unitOfWork.Repository<Wholesaler>().Linq().ToList();
                if (Wholesaler == null) throw new ValidationException("Wholesaler not found!");
                wholesalersDto.ExternalWholesaler = GetWholesalers(Wholesaler, WholesalerTypeEnum.External);
            }

            Log.TraceFormat("-GetWholesaler");

            return wholesalersDto;
        }

        private IList<WholesalerDto> GetWholesalers(IList<Wholesaler> Wholesaler, WholesalerTypeEnum WholesalerTypeEnum)
        {
            return Wholesaler.Where(c => c.WholesalerType.Id == (int)WholesalerTypeEnum).Select(c => new WholesalerDto
            {
                WholesalerId = c.Id,
                WholesalerTypeId = c.WholesalerType.Id,
                LdapUserId = c.LdapUserId,
                FirstName = c.FirstName,
                LastName = c.LastName,
                AddressLine1 = c.AddressLine1,
                AddressLine2 = c.AddressLine2,
                City = c.City,
                //StateType = c.StateType, // != null ? c.StateType.ToString() : string.Empty,
                ZipCode = c.ZipCode,
                TelephoneNumber = c.TelephoneNumber,
                EmailAddress = c.EmailAddress

            }).ToList();
        }

        public IList<WholesalerRegionDto> GetWholesalerRegion()
        {
            Log.TraceFormat("+GetWholesalerRegion");

            var wholesalerRegionDto = new List<WholesalerRegionDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var WholesalerRegion = unitOfWork.Repository<WholesalerRegion>().Linq();
                if (WholesalerRegion == null) throw new ValidationException("WholesalerRegion not found!");
                wholesalerRegionDto = WholesalerRegion.Select(c => new WholesalerRegionDto
                {
                    RegionName = c.RegionName,
                    ExternalWholesalerId = c.ExternalWholesaler.Id,
                    WholesalerRegionId = c.Id,

                }).ToList();
            }

            Log.TraceFormat("-GetWholesalerRegion");

            return wholesalerRegionDto;
        }

        public void SaveCaseWholesalerInformation(IList<CaseWholesalerDto> request)
        {
            Log.TraceFormat("+SaveCaseWholesalerInformation");

            _caseWholesalerManagerValidator.ValidatePrimaryWholesalerPresent(request);
           
            if (request != null && request.Count > 0)
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request[0].CaseId);
                    var caseWholesalers = unitOfWork.Repository<CaseWholesaler>().Linq().Where(c => c.Case.Id == request[0].CaseId).ToList();
                    var wholesalerRegion = unitOfWork.Repository<WholesalerRegion>().Linq().ToList();
                    var wholesalers = unitOfWork.Repository<Wholesaler>().Linq().ToList();
                    foreach (var caseWholesaler in request)
                    {
                        var cmsCaseWholesaler = caseWholesalers.FirstOrDefault(c => c.Id == caseWholesaler.CaseWholesalerId);
                        if (cmsCaseWholesaler == null)
                        {
                            cmsCaseWholesaler = new CaseWholesaler();
                            cmsCaseWholesaler.Case = cmsCase;
                            cmsCase.CaseWholesalers.Add(cmsCaseWholesaler);
                        }
                        cmsCaseWholesaler.WholesalerRegion = wholesalerRegion.FirstOrDefault(c => c.Id == caseWholesaler.WholesalerRegionId);
                        cmsCaseWholesaler.ExternalWholesaler = wholesalers.FirstOrDefault(c => c.Id == caseWholesaler.ExternalWholesalerId);
                        cmsCaseWholesaler.IsPrimaryIndicator = caseWholesaler.IsPrimaryIndicator;
                        cmsCaseWholesaler.WholesalerPercent = caseWholesaler.WholesalerPercent;
                    }
                    var newAndExistingCaseWholesalerIds = request.Select(d => d.CaseWholesalerId).ToList();
                    var deletedCaseWholesalerIds = caseWholesalers.Where(l => !newAndExistingCaseWholesalerIds.Contains(l.Id)).ToList();
                    foreach (var deletedCaseWholesaler in deletedCaseWholesalerIds)
                    {
                        cmsCase.CaseWholesalers.Remove(deletedCaseWholesaler);
                    }

                    unitOfWork.Repository<Case>().Save(cmsCase);

                    unitOfWork.Commit();
                }
            }

            Log.TraceFormat("-SaveCaseWholesalerInformation");
        }
        public void SaveCaseWholesalerInformationFromGA(CaseBrokerDto request)
        {
            Log.TraceFormat("+SaveCaseWholesalerInformationFromGA");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                WholesalerRegion wholesalerRegion = null;
                if (request.WholesalerRegionOfficeId.HasValue)
                {
                    var wholesalerRegionOffice = unitOfWork.Repository<WholesalerRegionOffice>().Linq().FirstOrDefault(r => r.Id == request.WholesalerRegionOfficeId.Value);
                    if (wholesalerRegionOffice != null)
                    {
                        wholesalerRegion = wholesalerRegionOffice.WholesalerRegion;
                    }
                }
                if (wholesalerRegion == null && request.AgencyCode != null)
                {
                    var wholesalerRegionOffice = unitOfWork.Repository<WholesalerRegionOffice>().Linq().FirstOrDefault(r => r.OfficeCode == request.AgencyCode);
                    if (wholesalerRegionOffice != null)
                    {
                        wholesalerRegion = wholesalerRegionOffice.WholesalerRegion;
                    }
                }
                if (wholesalerRegion != null)
                {
                    var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                    var cmsCaseWholesaler = cmsCase.CaseWholesalers.FirstOrDefault(cw => cw.IsPrimaryIndicator);
                    if (cmsCaseWholesaler == null)
                    {
                        cmsCaseWholesaler = new CaseWholesaler();
                        cmsCaseWholesaler.Case = cmsCase;
                        cmsCaseWholesaler.WholesalerRegion = wholesalerRegion;
                        cmsCaseWholesaler.ExternalWholesaler = wholesalerRegion.ExternalWholesaler;
                        cmsCaseWholesaler.IsPrimaryIndicator = true;
                        unitOfWork.Repository<CaseWholesaler>().Save(cmsCaseWholesaler);
                        unitOfWork.Commit();
                    }
                }
            }
            Log.TraceFormat("-SaveCaseWholesalerInformationFromGA");
        }
    }
}
