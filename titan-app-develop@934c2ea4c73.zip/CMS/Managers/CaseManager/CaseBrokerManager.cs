﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Exceptions;
using Logger.Static;
using Guardian.Core.Entities.Product.Enums;
using CMS.Interfaces.Integrations.BrokerDataServices;
using CMS.Integrations.BrokerDataServices;
using CMS.Interfaces.Configurations;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Integrations.BrokerLicensingServices;
using CMS.Integrations.BrokerLicensingService;
using System;
using CMS.Interfaces.Managers.LookupManagers;
using Common.Utilities;
using System.Net.NetworkInformation;

namespace CMS.Managers.CaseManagers
{
    public class CaseBrokerManager : ICaseBrokerManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly CaseBrokerManagerValidator _caseBrokerManagerValidator;
        private readonly IConfiguration _configuration;
        private readonly ILookupManager _lookupManager;

        public CaseBrokerManager(IUnitOfWorkFactory unitOfWorkFactory, IConfiguration configuration, ILookupManager lookupManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _caseBrokerManagerValidator = new CaseBrokerManagerValidator();
            _configuration = configuration;
            _lookupManager = lookupManager;
        }

        public IList<BrokerDataDto> GetBrokerData(BrokerSearchRequest request, bool? isFromGA = null)
        {
            Log.TraceFormat("+GetBrokerData");

            var objBrokerDataClient = new BrokerDataClient(_configuration);
            var brokerdata = objBrokerDataClient.Search(request);

            if (isFromGA != true)
            {
                if (brokerdata == null || brokerdata.Count == 0)
                    throw new BusinessException("Producer Data Exception", "Producer data not found.");
            }

            Log.TraceFormat("-GetBrokerData");
            return brokerdata;
        }

        public BrokerLicensingValidationReponse ValidateProducerLicense(string writingCode, string stateAbbreviation, DateTime lastVerifiedDate)
        {
            Log.TraceFormat("+ValidateProducerLicense");

            var objBrokerVerificationDataClient = new BrokerLicensingServiceClient(_configuration);
            var validationResponse = objBrokerVerificationDataClient.ValidateProducerLicense(writingCode, stateAbbreviation, lastVerifiedDate);
            if (validationResponse == null)
                throw new BusinessException("", "Producer verification data not found.");

            Log.TraceFormat("-ValidateProducerLicense");
            return validationResponse;
        }

        public BrokerLicensingValidationReponse ValidateCorporationLicense(string writingCode, string subProducerWritingCode, string stateAbbreviation, DateTime lastVerifiedDate, int caseId)
        {
            Log.TraceFormat("+ValidateCorporationLicense");
            if (subProducerWritingCode.ToLower() == "undefined" || subProducerWritingCode == string.Empty)
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var caseBrokers = unitOfWork.Repository<CaseBroker>().Linq().Where(c => c.Case.Id == caseId && c.BrokerParentWritingCode == writingCode).ToList();
                    if (caseBrokers.Any())
                    {
                        var licensedSubProducers = caseBrokers.Where(c => c.CaseBrokerStates.Any(p => p.IsLicensedIndicator == true)).ToList();
                        if (licensedSubProducers.Any())
                        {
                            subProducerWritingCode = licensedSubProducers.Select(c => c.BrokerWritingCode).FirstOrDefault();
                        }
                        else
                        {
                            var subProducers = caseBrokers.Where(c => c.CaseBrokerStates.Any(p => p.IsLicensedIndicator == false)).ToList();
                            if (subProducers.Any())
                            {
                                subProducerWritingCode = subProducers.Select(c => c.BrokerWritingCode).FirstOrDefault();
                            }
                        }
                    }

                }
            }
            var objBrokerVerificationDataClient = new BrokerLicensingServiceClient(_configuration);
            var validationResponse = objBrokerVerificationDataClient.ValidateCorporationLicense(writingCode, subProducerWritingCode, stateAbbreviation, lastVerifiedDate);
            if (validationResponse == null)
                throw new BusinessException("", "Producer verification data not found.");

            Log.TraceFormat("-ValidateCorporationLicense");
            return validationResponse;
        }

        public BrokerLicensingValidationReponse ValidateSubProducerLicense(string writingCode, string subProducerWritingCode, string stateAbbreviation, DateTime lastVerifiedDate)
        {
            Log.TraceFormat("+ValidateSubProducerLicense");

            var objBrokerVerificationDataClient = new BrokerLicensingServiceClient(_configuration);
            var validationResponse = objBrokerVerificationDataClient.ValidateSubProducerLicense(writingCode, subProducerWritingCode, stateAbbreviation, lastVerifiedDate);
            if (validationResponse == null)
                throw new BusinessException("", "Producer verification data not found.");

            Log.TraceFormat("-ValidateSubProducerLicense");
            return validationResponse;
        }

        public IList<BrokerDataDto> GetBrokerDataForSubProducers(BrokerSearchRequest request)
        {
            Log.TraceFormat("+GetSubProducersData");

            var objBrokerDataClient = new BrokerDataClient(_configuration);
            var brokerdata = objBrokerDataClient.GetBrokerDataForSubProducers(request);

            Log.TraceFormat("-GetSubProducersData");
            return brokerdata;
        }
        public BrokerDto GetBrokerInformationByCaseId(int caseId)
        {
            Log.TraceFormat("+GetBrokerInformationByCaseId caseId={0}", caseId);
            var brokerDto = new BrokerDto();
           
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");
                brokerDto.CaseId = caseId;
                StateTypeEnum? corporateSitusSate = null;
                var caseUnderWritingRequest = cmsCase.CaseUnderwritingRequests.FirstOrDefault();
                if (caseUnderWritingRequest != null)
                {
                    if (caseUnderWritingRequest.SitusType != SitusTypeEnum.Residence)
                    {
                        corporateSitusSate = caseUnderWritingRequest.StateType;
                    }
                    if (corporateSitusSate != null)
                    {
                        brokerDto.SitusStateTypeId = (int?)corporateSitusSate;
                        brokerDto.SitusStateTypeName = corporateSitusSate.ToString();
                    }
                }
                brokerDto.BrokerIllustrationDate = cmsCase.BrokerIllustrationDate;
                var enrollment = cmsCase.CaseEnrollments.OrderByDescending(c => c.EffectiveDate).FirstOrDefault();
                var planDesignRequestIds = cmsCase.PlanDesignRequests.Where(c => c.IsActive).Select(c => c.Id).ToList();
                var pdrSold = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => planDesignRequestIds.Contains(c.PlanDesignRequest.Id) && c.IsActive);
                var planDesignRequest = cmsCase.PlanDesignRequests.OrderByDescending(c => c.Id).FirstOrDefault();

                if (pdrSold.Count() > 0)
                {
                    if (enrollment != null)
                    {
                        brokerDto.BrokerEffectiveDate = enrollment.EffectiveDate;
                        brokerDto.IsAttested = enrollment.IsAttested;
                    }
                    else
                    {
                        brokerDto.BrokerEffectiveDate = pdrSold.OrderByDescending(c => c.Id).FirstOrDefault() != null ? pdrSold.OrderByDescending(c => c.Id).FirstOrDefault().PlanDesignRequest.IllustrationEffectiveDate : null;
                    }
                }
                else
                {
                    brokerDto.BrokerEffectiveDate = planDesignRequest != null ? planDesignRequest.IllustrationEffectiveDate : null;
                }


                brokerDto.BrokerActiveCensusDate = cmsCase.BrokerActiveCensusDate;               
                var brokerAffiliationNoneType = unitOfWork.Repository<BrokerAffiliationType>().Linq().FirstOrDefault(brokerAffiliationType => brokerAffiliationType.Code == "None");
                brokerDto.CaseBrokers = cmsCase.CaseBrokers
                    .Select(t => new CaseBrokerDto
                    {
                        CaseBrokerId = t.Id,
                        CaseId = caseId,
                        BrokerWritingCode = t.BrokerWritingCode,
                        BrokerParentWritingCode = t.BrokerParentWritingCode,
                        BrokerName = t.BrokerName,
                        AgencyCode = t.AgencyCode,
                        BrokerAffiliationTypeId = t.BrokerAffiliationType != null ? t.BrokerAffiliationType.Id : brokerAffiliationNoneType?.Id,
                        BrokerAffiliationTypeName = t.BrokerAffiliationType != null ? t.BrokerAffiliationType.Name : brokerAffiliationNoneType?.Name,

                        BrokerType = t.BrokerType,
                        WholesalerRegionOfficeId = t.WholesalerRegionOfficeId != null ? t.WholesalerRegionOfficeId : -1,
                        OfficeCode =  GetOfficeCode(t.WholesalerRegionOfficeId),

                        CaseBrokerStates = t.CaseBrokerStates.Select(brokerState => new CaseBrokerStateDto
                        {
                            CaseBrokerStateId = brokerState.Id,
                            CaseBrokerId = t.Id,
                            StateTypeId = (int)brokerState.StateType,
                            StateTypeName = brokerState.StateType.ToString(),
                            CommisionPercentage = brokerState.CommisionPercentage,
                            IsAppointedIndicator = brokerState.IsAppointedIndicator,
                            IsLicensedIndicator = brokerState.IsLicensedIndicator,
                            IsPrimaryBrokerIndicator = brokerState.IsPrimaryBrokerIndicator,
                            LicenseVerificationDate = brokerState.LicenseVerificationDate,
                            LicenseVerificationMessage = brokerState.LicenseVerificationMessage
                        }).ToList()
                    }).ToList();

                brokerDto.CensusStates = GetCensusStates(caseId, corporateSitusSate).ToList();
            }

            Log.TraceFormat("-GetBrokerInformationByCaseId");
            return brokerDto;
        }

        public string GetOfficeCode(int? wholesalerRegionOfficeId)
        {
            Log.TraceFormat("+GetOfficeCode");
            string officeCode = "None";
            var regionGroupOfficeName = _lookupManager.GetRGOList();

            if (wholesalerRegionOfficeId != null)
            {
                var objOfficeCode = regionGroupOfficeName.Where(c => c.Id == wholesalerRegionOfficeId).FirstOrDefault();
                if (objOfficeCode != null)
                {
                    officeCode = objOfficeCode.Description;
                }              
            }
            
            Log.TraceFormat("-GetOfficeCode");
            return officeCode;
        }
        public void SaveBrokersInformation(BrokerDto request)
        {
            Log.TraceFormat("+SaveBrokersInformation");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var plnaDesignRequestIds = unitOfWork.Repository<PlanDesignRequest>().Linq().Where(c => c.Case.Id == request.CaseId).Select(c => c.Id).ToList();
                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => plnaDesignRequestIds.Contains(c.PlanDesignRequest.Id));
                if (pdrSoldClass.Any())
                {
                    if (pdrSoldClass.Any(c => c.IsActive))
                    {
                        _caseBrokerManagerValidator.ValidateCaseBrokertData(request);
                    }
                }
            }
            SaveBrokerInfoGA(request);

            Log.TraceFormat("-SaveBrokersInformation");
        }

        public void SaveBrokerInfoGA(BrokerDto request, bool? isRequestFromGA = null)
        {
            Log.TraceFormat("+SaveBrokerInfoGA");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var brokerAffiliationTypes = unitOfWork.Repository<BrokerAffiliationType>()
                    .Linq()
                    .Where(affiliation => affiliation.Status != StatusEnum.Deleted.ToString())
                    .ToList();
                var caseBrokers = unitOfWork.Repository<CaseBroker>().Linq().Where(c => c.Case.Id == request.CaseId).ToList();

                if (request.CaseBrokers != null)
                {
                    foreach (var caseBrokerDto in request.CaseBrokers)
                    {
                        var cmsCaseBroker = caseBrokers.FirstOrDefault(c => c.Id == caseBrokerDto.CaseBrokerId);
                        if (cmsCaseBroker == null)
                        {
                            cmsCaseBroker = new CaseBroker();
                            cmsCaseBroker.Case = cmsCase;
                            cmsCase.CaseBrokers.Add(cmsCaseBroker);
                        }

                        cmsCaseBroker.BrokerName = caseBrokerDto.BrokerName;

                        cmsCaseBroker.AgencyCode = caseBrokerDto.AgencyCode;
                        cmsCaseBroker.BrokerType = caseBrokerDto.BrokerType;
                        var brokerAffiliationType = brokerAffiliationTypes.FirstOrDefault(c => c.Id == caseBrokerDto.BrokerAffiliationTypeId);
                        cmsCaseBroker.BrokerAffiliationType = brokerAffiliationType;
                        cmsCaseBroker.WholesalerRegionOfficeId = caseBrokerDto.WholesalerRegionOfficeId == -1 ? null : caseBrokerDto.WholesalerRegionOfficeId;
                                           
                        cmsCaseBroker.CompanyName = caseBrokerDto.CompanyName;
                        if (caseBrokerDto.IsFromGA == true)
                        {
                            BrokerSearchRequest brokerSearchRequest = new BrokerSearchRequest() { WritingCode = caseBrokerDto.BrokerWritingCode };
                            var brokerDto = GetBrokerData(brokerSearchRequest, true).FirstOrDefault();
                            if (brokerDto != null)
                            {
                                cmsCaseBroker.BrokerWritingCode = caseBrokerDto.BrokerWritingCode;
                                cmsCaseBroker.BrokerParentWritingCode = caseBrokerDto.BrokerParentWritingCode;

                                if (brokerDto.CorporateIndicator == true)
                                {
                                    cmsCaseBroker.BrokerType = "1";
                                }
                                else
                                {
                                    cmsCaseBroker.BrokerType = "0";
                                }

                                if (!string.IsNullOrEmpty(caseBrokerDto.BrokerName))
                                {
                                    cmsCaseBroker.BrokerName = caseBrokerDto.BrokerName;
                                }
                                else
                                {
                                    cmsCaseBroker.BrokerName = caseBrokerDto.CompanyName;
                                }                                
                            }
                            else
                            {

                                cmsCaseBroker.BrokerWritingCode = caseBrokerDto.BrokerWritingCode;
                                cmsCaseBroker.BrokerParentWritingCode = caseBrokerDto.BrokerParentWritingCode;
                            }

                            if (string.IsNullOrEmpty(cmsCaseBroker.BrokerName))
                            {
                                cmsCaseBroker.BrokerName = GetPreviousBrokerName(caseBrokers, caseBrokerDto);
                            }

                            var subProducers = GetBrokerDataForSubProducers(brokerSearchRequest).ToList();
                            if (subProducers.Any())
                            {
                                var cmsCaseSubProducer = new CaseBroker();
                                cmsCaseSubProducer.Case = cmsCase;
                                var subProducer = subProducers.FirstOrDefault();
                                cmsCaseSubProducer.BrokerWritingCode = subProducer.WritingCode;
                                cmsCaseSubProducer.BrokerParentWritingCode = subProducer.ParentContractIdentifier;
                                cmsCaseSubProducer.BrokerName = GetBrokerName.BrokerName(subProducer.FirstName, subProducer.LastName);
                                cmsCaseSubProducer.AgencyCode = subProducer.AgencyCode;
                                cmsCaseSubProducer.BrokerAffiliationType = brokerAffiliationType;
                                cmsCaseSubProducer.BrokerType = "2";
                                cmsCaseSubProducer.WholesalerRegionOfficeId = caseBrokerDto.WholesalerRegionOfficeId;
                                cmsCase.CaseBrokers.Add(cmsCaseSubProducer);
                            }
                        }
                        else
                        {
                            cmsCaseBroker.BrokerWritingCode = caseBrokerDto.BrokerWritingCode;
                            cmsCaseBroker.BrokerParentWritingCode = caseBrokerDto.BrokerParentWritingCode;

                        }

                        if (caseBrokerDto.CaseBrokerStates != null && caseBrokerDto.CaseBrokerStates.Count > 0)
                        {
                            SaveBrokerStateInformation(unitOfWork, caseBrokerDto, cmsCaseBroker);
                        }
                    }
                    var newAndExistingBrokerIds = request.CaseBrokers.Select(d => d.CaseBrokerId).ToList();
                    var deletedbrokers = caseBrokers.Where(l => !newAndExistingBrokerIds.Contains(l.Id)).ToList();
                    foreach (var deletedBroker in deletedbrokers)
                    {
                        cmsCase.CaseBrokers.Remove(deletedBroker);
                    }
                    unitOfWork.Repository<Case>().Save(cmsCase);

                    unitOfWork.Commit();
                }
            }
            Log.TraceFormat("-SaveBrokerInfoGA");
        }

        private string GetPreviousBrokerName(List<CaseBroker> casebroker, CaseBrokerDto request)
        {
            Log.TraceFormat($"+GetPreviousBrokerName");

            string brokername = string.Empty;

            if (string.IsNullOrEmpty(request.BrokerName))
            {
                if (casebroker.Any())
                {
                    var previousBrokerName = casebroker.FirstOrDefault(i => i.AgencyCode == request.AgencyCode.Trim() 
                                                                         || i.BrokerWritingCode == request.BrokerWritingCode.Trim());
                    if (previousBrokerName != null) 
                    {
                        brokername = previousBrokerName.BrokerName;
                        Log.TraceFormat($"+GetPreviousBrokerName : Pulled previous broker name:'{previousBrokerName}'");

                    };                
                }            
            }           

            Log.TraceFormat($"-GetPreviousBrokerName");

            return brokername;

        }
        private void SaveBrokerStateInformation(IUnitOfWork unitOfWork, CaseBrokerDto caseBrokerDto, CaseBroker cmsCaseBroker)
        {
            Log.TraceFormat("+SaveBrokerStateInformation");

            var caseBrokerStates = unitOfWork.Repository<CaseBrokerState>().Linq().Where(c => c.CaseBroker.Id == cmsCaseBroker.Id).ToList();

            foreach (var caseBrokerState in caseBrokerDto.CaseBrokerStates)
            {
                var cmsCaseBrokerState = caseBrokerStates.FirstOrDefault(c => c.Id == caseBrokerState.CaseBrokerStateId);
                if (cmsCaseBrokerState == null)
                {
                    cmsCaseBrokerState = new CaseBrokerState();
                    cmsCaseBrokerState.CaseBroker = cmsCaseBroker;
                    cmsCaseBroker.CaseBrokerStates.Add(cmsCaseBrokerState);
                }
                cmsCaseBrokerState.StateType = (StateTypeEnum)caseBrokerState.StateTypeId;
                cmsCaseBrokerState.CommisionPercentage = caseBrokerState.CommisionPercentage;
                cmsCaseBrokerState.IsLicensedIndicator = caseBrokerState.IsLicensedIndicator;
                cmsCaseBrokerState.IsAppointedIndicator = caseBrokerState.IsAppointedIndicator;
                cmsCaseBrokerState.LicenseVerificationDate = caseBrokerState.LicenseVerificationDate;
                cmsCaseBrokerState.LicenseVerificationMessage = caseBrokerState.LicenseVerificationMessage;
                cmsCaseBrokerState.IsPrimaryBrokerIndicator = caseBrokerState.IsPrimaryBrokerIndicator;
            }
            Log.TraceFormat("-SaveBrokerStateInformation");
        }

        private IList<CensusStateDto> GetCensusStates(int caseId, StateTypeEnum? companySitusState)
        {
            Log.TraceFormat("+GetCensusStates");
            IList<CensusStateDto> censusStates = new List<CensusStateDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var soldPDR = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => c.PlanDesignRequest.Case.Id == caseId && c.IsActive == true).Select(c => c.PlanDesignRequestClass.Id);
                var cmsparticipants = unitOfWork.Repository<Participant>().Linq().Where(c => soldPDR.Contains(c.PlanDesignRequestClass.Id) && (c.IsEligible == true || c.IsEligible == null) && c.IsActive == true).ToList();

                if (cmsparticipants.Any())
                {
                    var workState = cmsparticipants.Where(c => c.WorkState != null).Select(p => new CensusStateDto
                    {
                        BrokerState = p.WorkState
                    }).Distinct().ToList();

                    var homeState = cmsparticipants.Where(c => c.HomeState != null).Select(p => new CensusStateDto
                    {
                        BrokerState = p.HomeState
                    }).Distinct().ToList();

                    var allStates = workState.Union(homeState).GroupBy(c => c.BrokerState).Select(x => x.First()).ToList();

                    censusStates = allStates.Select(s => new CensusStateDto
                    {
                        BrokerState = s.BrokerState,
                        WorksInParticipants = cmsparticipants.Count(p => p.WorkState == s.BrokerState),
                        LivesInParticipants = cmsparticipants.Count(p => p.HomeState == s.BrokerState),
                    }).ToList();
                }

                var companySitusStateDto = censusStates.FirstOrDefault(s => s.BrokerState == companySitusState);

                if (companySitusStateDto == null)
                {
                    companySitusStateDto = new CensusStateDto();
                    companySitusStateDto.BrokerState = companySitusState;
                    companySitusStateDto.WorksInParticipants = cmsparticipants.Count(p => p.WorkState == companySitusStateDto.BrokerState);
                    companySitusStateDto.LivesInParticipants = cmsparticipants.Count(p => p.HomeState == companySitusStateDto.BrokerState);
                }
                else
                {
                    censusStates.Remove(companySitusStateDto);
                }

                censusStates = censusStates.OrderByDescending(s => Convert.ToString(s.BrokerState)).Reverse().ToList();
                if (companySitusState != null)
                {
                    censusStates.Insert(0, companySitusStateDto);
                }
            }

            Log.TraceFormat("-GetCensusStates");
            return censusStates;
        }

        public int? GetUnderwriterByAffiliationOrRegion(int caseId)
        {
            string wholesalerRegionName = string.Empty;

            int? assignedUserId = null;
            var brokerAffiliationTypeIds = new List<int>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseBrokers = unitOfWork.Repository<CaseBroker>().Linq().Where(c => c.Case.Id == caseId).ToList();
                var wholeSalerRegionOffice = unitOfWork.Repository<WholesalerRegionOffice>().Linq().ToList();
                var brokerAffiliationUnderwriterAssociation = unitOfWork.Repository<BrokerAffiliationUnderwriterAssociation>().Linq();
                brokerAffiliationTypeIds = brokerAffiliationUnderwriterAssociation.Select(c => c.BrokerAffiliationType.Id).ToList();

                if (caseBrokers.Any())
                {
                    var brokerWithAffliations = caseBrokers.Where(c => c.BrokerAffiliationType != null && brokerAffiliationTypeIds.Contains(c.BrokerAffiliationType.Id)).FirstOrDefault();
                    var brokerWithRegions = caseBrokers.Where(c => c.WholesalerRegionOfficeId != null).FirstOrDefault();
                    var brokerWithAgency = caseBrokers.Where(c => c.AgencyCode != null).FirstOrDefault();

                    if (brokerWithAffliations != null)
                    {
                        var brokerAffiliationUnderwriter = brokerAffiliationUnderwriterAssociation.FirstOrDefault(c => c.BrokerAffiliationType.Id == brokerWithAffliations.BrokerAffiliationType.Id);
                        assignedUserId = brokerAffiliationUnderwriter.User != null ? (int?)brokerAffiliationUnderwriter.User.Id : null;
                    }

                    else
                    {
                        if (brokerWithRegions != null)
                        {
                            wholesalerRegionName = GetRegionByWholesalerRegionOffice(wholeSalerRegionOffice, brokerWithRegions);
                            if (!string.IsNullOrWhiteSpace(wholesalerRegionName))
                            {
                                var brokerUnderWriter = unitOfWork.Repository<BillingSpecialistRegion>().Linq().FirstOrDefault(r => r.RegionName == wholesalerRegionName);
                                if (brokerUnderWriter != null && brokerUnderWriter.UnderWriterUser != null)
                                {
                                    assignedUserId = brokerUnderWriter.UnderWriterUser.Id;
                                }
                            }
                        }
                        else
                        {
                            wholesalerRegionName = GetRegionByWholesalerAgency(wholeSalerRegionOffice, brokerWithAgency);
                            if (!string.IsNullOrWhiteSpace(wholesalerRegionName))
                            {
                                var brokerUnderWriter = unitOfWork.Repository<BillingSpecialistRegion>().Linq().FirstOrDefault(r => r.RegionName == wholesalerRegionName);
                                if (brokerUnderWriter != null && brokerUnderWriter.UnderWriterUser != null)
                                {
                                    assignedUserId = brokerUnderWriter.UnderWriterUser.Id;
                                }
                            }
                        }
                    }
                }
            }
            return assignedUserId;
        }

        private string GetRegionByWholesalerRegionOffice(List<WholesalerRegionOffice> wholeSalerRegionOffice, CaseBroker caseBroker)
        {
            string wholesalerRegionName = string.Empty;
            var wholeSalerRegionOfficeByRegion = wholeSalerRegionOffice.FirstOrDefault(w => w.Id == caseBroker.WholesalerRegionOfficeId);
            if (wholeSalerRegionOfficeByRegion != null)
            {
                wholesalerRegionName = wholeSalerRegionOfficeByRegion.WholesalerRegion.RegionName;
            }

            return wholesalerRegionName;
        }

        private string GetRegionByWholesalerAgency(List<WholesalerRegionOffice> wholeSalerRegionOffice, CaseBroker caseBroker)
        {
            string wholesalerRegionName = string.Empty;

            var wholeSalerRegionOfficeByAgencyCode = wholeSalerRegionOffice.FirstOrDefault(r => r.OfficeCode == caseBroker.AgencyCode);
            if (wholeSalerRegionOfficeByAgencyCode != null)
            {
                wholesalerRegionName = wholeSalerRegionOfficeByAgencyCode.WholesalerRegion.RegionName;
            }

            return wholesalerRegionName;
        }
    }
}
