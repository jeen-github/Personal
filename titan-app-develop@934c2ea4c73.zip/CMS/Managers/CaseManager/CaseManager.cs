﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CaseManagers;
using Logger.Static;
using Common.Exceptions;
using CMS.Model.Entities;
using Guardian.Core.Entities.Product.Enums;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using CMS.Managers.PlanManagers;
using CMS.Interfaces.Managers.SecurityManagers;
using CMS.Interfaces.Managers;
using CMS.Interfaces.Managers.ITAdminManagers;
using System.Web;

namespace CMS.Managers.CaseManagers
{
    public class CaseManager : ICaseManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly CaseCompanyValidator _caseCompanyValidator;
        private readonly PlanDesignRequestManager _planDesignRequestManager;
        private readonly ISecurityManager _securityManager;

        public CaseManager(IUnitOfWorkFactory unitOfWorkFactory, PlanDesignRequestManager planDesignRequestManager, ISecurityManager securityManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _planDesignRequestManager = planDesignRequestManager;
            _caseCompanyValidator = new CaseCompanyValidator();
            _securityManager = securityManager;
        }

        public CaseDto GetCompanyInformationByCaseId(int caseId, UserInfoDto userDto)
        {
            Log.TraceFormat("+GetCompanyInformationByCaseId caseId={0}", caseId);

            var caseDto = new CaseDto();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");

                caseDto.CaseId = cmsCase.Id;
                caseDto.GACaseId = cmsCase.GACaseId;
                caseDto.CaseNumber = cmsCase.CaseNumber;
                if (cmsCase.Company != null)
                {
                    caseDto.EmployerClientId = cmsCase.Company.EmployerClientId;
                    caseDto.CompanyId = cmsCase.Company.Id;
                }
                caseDto.CompanyName = cmsCase.CompanyName;
                caseDto.CaseStatusTypeId = (int)cmsCase.CaseStatusType;
                caseDto.CaseStatusTypeDescription = cmsCase.CaseStatusType.GetDescription();
                caseDto.CompanyAddressLine1 = cmsCase.CompanyAddressLine1;
                caseDto.CompanyAddressLine2 = cmsCase.CompanyAddressLine2;
                caseDto.CompanyCity = cmsCase.CompanyCity;
                caseDto.CompanyStateTypeId = (int?)cmsCase.CompanyStateType;
                caseDto.CompanyZipCode = String.IsNullOrEmpty(cmsCase.CompanyZipCode) ? "" : cmsCase.CompanyZipCode.Trim();
                caseDto.CompanyNatureOfBusiness = cmsCase.CompanyNatureOfBusiness;
                caseDto.CompanyWebAddress = cmsCase.CompanyWebAddress;
                caseDto.CompanyBusinessEntityTypeId = cmsCase.CompanyBusinessEntityType != null ? (int?)cmsCase.CompanyBusinessEntityType.Id : null;
                caseDto.CompanyBusinessEntityUnknownComments = cmsCase.CompanyBusinessEntityUnknownComments;
                caseDto.CompanySicDivisionTypeId = cmsCase.CompanySicDivisionType != null ? (int?)cmsCase.CompanySicDivisionType.Id : null;
                caseDto.CompanySicMajorGroupTypeId = cmsCase.CompanySicMajorGroupType != null ? (int?)cmsCase.CompanySicMajorGroupType.Id : null;
                caseDto.CompanySicSubGroupTypeId = cmsCase.CompanySicSubGroupType != null ? (int?)cmsCase.CompanySicSubGroupType.Id : null;
                caseDto.CompanyRevisionSicCode = cmsCase.CompanyRevisionSicCode;
                caseDto.IsCompanyNonDisclosureAgreementIndicator = cmsCase.IsCompanyNonDisclosureAgreementIndicator;
                caseDto.IsTheCompanyAlreadyGuardianGroupClientIndicator = cmsCase.IsTheCompanyAlreadyGuardianGroupClientIndicator;
                caseDto.IsCompanyErisaIndicator = cmsCase.IsCompanyErisaIndicator;
                caseDto.AdditionalCommentsText = cmsCase.AdditionalCommentsText;
                caseDto.CaseCompetitiveDescription = cmsCase.CaseCompetitiveDescription;
                caseDto.IsConfidentialCaseIndicator = cmsCase.IsConfidentialCaseIndicator;
                caseDto.CaseCompanyLocations = cmsCase.CaseCompanyLocations
                    .Select(t => new CaseCompanyLocationDto
                    {
                        CaseCompanyLocationId = t.Id,
                        CaseId = t.Case.Id,
                        CompanyLocationTypeId = t.CompanyLocationType != null ? (int?)t.CompanyLocationType.Id : null,
                        CompanyLocationTypeName = t.CompanyLocationType != null ? t.CompanyLocationType.Description : string.Empty,
                        LocationName = t.LocationName,
                        AddressLine1 = t.AddressLine1,
                        AddressLine2 = t.AddressLine2,
                        City = t.City,
                        StateTypeId = (int?)t.StateType,
                        StateTypeName = t.StateType != null ? t.StateType.ToString() : string.Empty,
                        ZipCode = t.ZipCode,
                        Attention = t.Attention,
                    }).ToList();

                caseDto.CaseCompanyGuardianProducts = cmsCase.CaseCompanyGuardianProducts
                    .Select(t => new CaseCompanyGuardianProductDto
                    {
                        CaseCompanyGuardianProductId = t.Id,
                        CaseId = t.Case.Id,
                        CompanyGuardianProductTypeId = t.CompanyGuardianProductType.Id,
                        IsAlreadyAGuardianGroupClientIndicator = t.IsAlreadyAGuardianGroupClientIndicator,
                        IsCurrentlyQuotingGuardianGroupProductIndicator = t.IsCurrentlyQuotingGuardianGroupProductIndicator,
                    }).ToList();

                caseDto.CaseCarriers = cmsCase.CaseCarriers
                    .Select(c => new CaseCarrierDto
                    {
                        CaseCarrierId = c.Id,
                        CaseId = c.Case.Id,
                        ExistingIndividualDisabilityCoverageTypeId = c.ExistingIndividualDisabilityCoverageType.Id,
                        ExistingIndividualDisabilityCoverageTypeName = c.ExistingIndividualDisabilityCoverageType != null ? c.ExistingIndividualDisabilityCoverageType.Name : string.Empty,
                        IsCompetition = c.IsCompetition
                    }).ToList();
                var enrollmentMgr = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == cmsCase.EnrollmentManagerId);
                if (enrollmentMgr != null)
                {
                    caseDto.EnrollmentManager = enrollmentMgr.FirstName + ' ' + enrollmentMgr.LastName;
                }

                var implementationAnalyzt = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == cmsCase.ImplementationAnalystId);
                if (implementationAnalyzt != null)
                {
                    caseDto.ImplementationAnalyst = implementationAnalyzt.FirstName + ' ' + implementationAnalyzt.LastName;
                }
                SaveConfidentialCaseHistory(cmsCase, userDto);

            }

            Log.TraceFormat("-GetCompanyInformationByCaseId");
            return caseDto;
        }

        private void SaveConfidentialCaseHistory(Case cmsCase, UserInfoDto userDto)
        {
            Log.TraceFormat("+SaveConfidentialCaseHistory");

            CmsUser assignedUser = null;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                if (userDto != null)
                {
                    assignedUser = unitOfWork.Repository<CmsUser>().Linq().FirstOrDefault(t => t.Id == userDto.TitanUserId);
                }

                if (cmsCase.IsConfidentialCaseIndicator != null && cmsCase.IsConfidentialCaseIndicator == true)
                {
                    var confidentialCase = new ConfidentialCaseHistory
                    {
                        Case = cmsCase,
                        LdapUser = assignedUser,
                        LastAccessedDateTime = DateTime.Now
                    };

                    unitOfWork.Repository<ConfidentialCaseHistory>().Save(confidentialCase);
                    unitOfWork.Commit();
                }
            }
            Log.TraceFormat("-SaveConfidentialCaseHistory");
        }

        public void SaveCaseCompanyInformation(CaseDto request)
        {
            Log.TraceFormat("+SaveCaseCompanyInformation");

            _caseCompanyValidator.ValidateCaseCompanyData(request);

            SaveCaseCompanyFromGA(request);

            Log.TraceFormat("-SaveCaseCompanyInformation");
        }

        public int SaveCaseCompanyFromGA(CaseDto request)
        {
            Log.TraceFormat("+SaveCaseCompanyFromGA");
            var caseId = 0;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                var company = unitOfWork.Repository<Company>().Linq().FirstOrDefault(c => c.Id == request.CompanyId);

                if (cmsCase == null)
                {
                    cmsCase = new Case { CreationDate = DateTime.Now };
                }

                cmsCase.Company = company;
                cmsCase.CaseNumber = request.CaseNumber;
                cmsCase.GACaseId = request.GACaseId;
                cmsCase.CaseStatusType = (CaseStatusTypeEnum)request.CaseStatusTypeId;
                cmsCase.CompanyName = request.CompanyName;
                cmsCase.CompanyAddressLine1 = request.CompanyAddressLine1;
                cmsCase.CompanyAddressLine2 = request.CompanyAddressLine2;
                cmsCase.CompanyCity = request.CompanyCity;
                cmsCase.CompanyStateType = (StateTypeEnum?)request.CompanyStateTypeId;
                cmsCase.CompanyZipCode = request.CompanyZipCode;
                cmsCase.CompanyNatureOfBusiness = request.CompanyNatureOfBusiness;
                cmsCase.CompanyWebAddress = request.CompanyWebAddress;
                cmsCase.CompanyBusinessEntityType = unitOfWork.Repository<CompanyBusinessEntityType>().Linq().FirstOrDefault(c => c.Id == request.CompanyBusinessEntityTypeId);

                if (cmsCase.CompanyBusinessEntityType != null && cmsCase.CompanyBusinessEntityType.Code.Equals("Unknown", StringComparison.InvariantCultureIgnoreCase))
                {
                    cmsCase.CompanyBusinessEntityUnknownComments = request.CompanyBusinessEntityUnknownComments;
                }
                else
                {
                    cmsCase.CompanyBusinessEntityUnknownComments = null;
                }
                if (!request.IsFromGA)
                {
                    cmsCase.CompanySicDivisionType = unitOfWork.Repository<CompanySicDivisionType>().Linq().FirstOrDefault(c => c.Id == request.CompanySicDivisionTypeId);
                    cmsCase.CompanySicMajorGroupType = unitOfWork.Repository<CompanySicMajorGroupType>().Linq().FirstOrDefault(c => c.Id == request.CompanySicMajorGroupTypeId);
                    cmsCase.CompanySicSubGroupType = unitOfWork.Repository<CompanySicSubGroupType>().Linq().FirstOrDefault(c => c.Id == request.CompanySicSubGroupTypeId);
                    cmsCase.CompanyRevisionSicCode = request.CompanyRevisionSicCode;
                    cmsCase.IsConfidentialCaseIndicator = request.IsConfidentialCaseIndicator;
                }

                cmsCase.IsTheCompanyAlreadyGuardianGroupClientIndicator = request.IsTheCompanyAlreadyGuardianGroupClientIndicator;
                cmsCase.IsCompanyNonDisclosureAgreementIndicator = request.IsCompanyNonDisclosureAgreementIndicator;
                cmsCase.IsCompanyErisaIndicator = request.IsCompanyErisaIndicator;
                cmsCase.AdditionalCommentsText = request.AdditionalCommentsText;
                cmsCase.CaseCompetitiveDescription = request.CaseCompetitiveDescription;

                if (request.CaseCompanyLocations != null)
                {
                    UpdateCaseCompanyLocations(request, unitOfWork, cmsCase);
                }

                if (request.CaseCompanyGuardianProducts != null)
                {
                    UpdateCaseCompanyProducts(request, unitOfWork, cmsCase);
                }

                if (request.CaseCarriers != null)
                {
                    UpdateCaseCarriers(request, unitOfWork, cmsCase);
                }

                unitOfWork.Repository<Case>().Save(cmsCase);

                unitOfWork.Commit();

                caseId = cmsCase.Id;
            }

            Log.TraceFormat("-SaveCaseCompanyFromGA");

            return caseId;
        }

        private void UpdateCaseCarriers(CaseDto request, IUnitOfWork unitOfWork, Case cmsCase)
        {
            var caseCarriers = unitOfWork.Repository<CaseCarrier>().Linq().Where(c => c.Case.Id == request.CaseId).ToList();
            var existingIndividualDisabilityCoverageTypes = unitOfWork.Repository<ExistingIndividualDisabilityCoverageType>().Linq().ToList();

            foreach (var caseCarrierDto in request.CaseCarriers)
            {
                var cmsCaseCarrier = caseCarriers.FirstOrDefault(c => c.Id == caseCarrierDto.CaseCarrierId);
                if (cmsCaseCarrier == null)
                {
                    cmsCaseCarrier = new CaseCarrier();
                    cmsCaseCarrier.Case = cmsCase;
                    cmsCase.CaseCarriers.Add(cmsCaseCarrier);
                }
                cmsCaseCarrier.IsCompetition = caseCarrierDto.IsCompetition;
                var existingIndividualDisabilityCoverageType = existingIndividualDisabilityCoverageTypes.FirstOrDefault(c => c.Id == caseCarrierDto.ExistingIndividualDisabilityCoverageTypeId);
                cmsCaseCarrier.ExistingIndividualDisabilityCoverageType = existingIndividualDisabilityCoverageType;
            }

            var newAndExistingCarrierIds = request.CaseCarriers.Select(d => d.CaseCarrierId).ToList();
            var deletedCarriers = caseCarriers.Where(l => !newAndExistingCarrierIds.Contains(l.Id)).ToList();
            foreach (var deletedCarrier in deletedCarriers)
            {
                cmsCase.CaseCarriers.Remove(deletedCarrier);
            }
        }

        private void UpdateCaseCompanyLocations(CaseDto request, IUnitOfWork unitOfWork, Case cmsCase)
        {
            Log.TraceFormat("+UpdateCaseCompanyLocations");
            var caseCompanyLocationTypes = unitOfWork.Repository<CompanyLocationType>().Linq().ToList();
            var caseCompanyLocations = unitOfWork.Repository<CaseCompanyLocation>().Linq().ToList();

            foreach (var caseCompanyLocationDto in request.CaseCompanyLocations)
            {
                var caseCompanyLocation = caseCompanyLocations.FirstOrDefault(c => c.Id == caseCompanyLocationDto.CaseCompanyLocationId);
                if (caseCompanyLocation == null)
                {
                    caseCompanyLocation = new CaseCompanyLocation();
                    caseCompanyLocation.Case = cmsCase;
                    cmsCase.CaseCompanyLocations.Add(caseCompanyLocation);
                }
                var companyLocationType = caseCompanyLocationTypes.FirstOrDefault(c => c.Id == caseCompanyLocationDto.CompanyLocationTypeId);
                caseCompanyLocation.CompanyLocationType = companyLocationType;
                caseCompanyLocation.LocationName = caseCompanyLocationDto.LocationName;
                caseCompanyLocation.AddressLine1 = caseCompanyLocationDto.AddressLine1;
                caseCompanyLocation.AddressLine2 = caseCompanyLocationDto.AddressLine2;
                caseCompanyLocation.City = caseCompanyLocationDto.City;
                caseCompanyLocation.StateType = (StateTypeEnum?)caseCompanyLocationDto.StateTypeId;
                caseCompanyLocation.ZipCode = caseCompanyLocationDto.ZipCode;
                caseCompanyLocation.Attention = caseCompanyLocationDto.Attention;
            }

            var newAndExistingLocationIds = request.CaseCompanyLocations.Select(d => d.CaseCompanyLocationId).ToList();
            var deletedLocations = caseCompanyLocations.Where(l => !newAndExistingLocationIds.Contains(l.Id)).ToList();
            foreach (var deletedLocation in deletedLocations)
            {
                cmsCase.CaseCompanyLocations.Remove(deletedLocation);
            }

            Log.TraceFormat("-UpdateCaseCompanyLocations");
        }

        private void UpdateCaseCompanyProducts(CaseDto request, IUnitOfWork unitOfWork, Case cmsCase)
        {
            Log.TraceFormat("+UpdateCaseCompanyProducts");
            var companyGuardianProductTypes = unitOfWork.Repository<CompanyGuardianProductType>().Linq().ToList();
            var caseCompanyGuardianProducts = unitOfWork.Repository<CaseCompanyGuardianProduct>().Linq().ToList();

            foreach (var caseCompanyGuardianProductDto in request.CaseCompanyGuardianProducts)
            {
                var caseCompanyGuardianProduct = caseCompanyGuardianProducts.FirstOrDefault(c => c.Id == caseCompanyGuardianProductDto.CaseCompanyGuardianProductId);
                if (caseCompanyGuardianProduct == null)
                {
                    caseCompanyGuardianProduct = new CaseCompanyGuardianProduct();
                    caseCompanyGuardianProduct.Case = cmsCase;
                    cmsCase.CaseCompanyGuardianProducts.Add(caseCompanyGuardianProduct);
                }
                var companyGuardianProductType = companyGuardianProductTypes.FirstOrDefault(c => c.Id == caseCompanyGuardianProductDto.CompanyGuardianProductTypeId);
                caseCompanyGuardianProduct.CompanyGuardianProductType = companyGuardianProductType;
                caseCompanyGuardianProduct.IsAlreadyAGuardianGroupClientIndicator = caseCompanyGuardianProductDto.IsAlreadyAGuardianGroupClientIndicator;
                caseCompanyGuardianProduct.IsCurrentlyQuotingGuardianGroupProductIndicator = caseCompanyGuardianProductDto.IsCurrentlyQuotingGuardianGroupProductIndicator;
            }

            var newAndExistingProductIds = request.CaseCompanyGuardianProducts.Select(p => p.CaseCompanyGuardianProductId).ToList();
            var deletedProducts = caseCompanyGuardianProducts.Where(p => !newAndExistingProductIds.Contains(p.Id)).ToList();
            foreach (var deletedProduct in deletedProducts)
            {
                cmsCase.CaseCompanyGuardianProducts.Remove(deletedProduct);
            }
            Log.TraceFormat("-UpdateCaseCompanyProducts");
        }

        public IList<CompanySicDivisionTypeDto> GetCompanySicDivisionTypes()
        {
            Log.TraceFormat("+GetCompanySicDivisionTypes");
            var companySicDivisionTypes = new List<CompanySicDivisionTypeDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                companySicDivisionTypes = unitOfWork.Repository<CompanySicDivisionType>().Linq().Select(companySicDivisionType =>
                     new CompanySicDivisionTypeDto
                     {
                         Id = companySicDivisionType.Id,
                         Code = companySicDivisionType.Code,
                         Description = companySicDivisionType.Description,
                         Name = companySicDivisionType.Name,
                         SortOrder = companySicDivisionType.SortOrder,
                         CompanySicMajorGroupTypes = companySicDivisionType.CompanySicMajorGroupTypes.Select(t => new CompanySicMajorGroupTypeDto()
                         {
                             Id = t.Id,
                             CompanySicDivisionTypeId = companySicDivisionType.Id,
                             Code = (t.Code.TrimStart(new Char[] { '0' })).Length == 1 ? "0" + t.Code.TrimStart(new Char[] { '0' }) : t.Code.TrimStart(new Char[] { '0' }),
                             Description = t.Description,
                             SortOrder = t.SortOrder,
                             Name = t.Name
                         }).ToList()
                     }).ToList();
            }
            Log.TraceFormat("-GetCompanySicDivisionTypes");
            return companySicDivisionTypes;
        }

        public IList<CompanySicMajorGroupTypeDto> GetCompanySicMajorGroupTypes()
        {
            Log.TraceFormat("+GetCompanySicMajorGroupTypes");
            var companySicMajorGroupTypes = new List<CompanySicMajorGroupTypeDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                companySicMajorGroupTypes = unitOfWork.Repository<CompanySicMajorGroupType>().Linq().Select(CompanySicMajorGroupType =>
                     new CompanySicMajorGroupTypeDto
                     {
                         Id = CompanySicMajorGroupType.Id,
                         Code = (CompanySicMajorGroupType.Code.TrimStart(new Char[] { '0' })).Length == 1 ? "0" + CompanySicMajorGroupType.Code.TrimStart(new Char[] { '0' }) : CompanySicMajorGroupType.Code.TrimStart(new Char[] { '0' }),
                         Description = CompanySicMajorGroupType.Description,
                         Name = CompanySicMajorGroupType.Name,
                         SortOrder = CompanySicMajorGroupType.SortOrder,
                         CompanySicSubGroupTypes = CompanySicMajorGroupType.CompanySicSubGroupTypes.Select(t => new CompanySicSubGroupTypeDto()
                         {
                             Id = t.Id,
                             CompanySicMajorGroupTypeId = CompanySicMajorGroupType.Id,
                             Code = ((t.Code).Substring(2, t.Code.Length - 2)).Length == 1 ? "0" + (t.Code).Substring(2, t.Code.Length - 2) : (t.Code).Substring(2, t.Code.Length - 2),
                             Description = t.Description,
                             SortOrder = t.SortOrder,
                             Name = t.Name
                         }).ToList()
                     }).ToList();
            }
            Log.TraceFormat("-GetCompanySicMajorGroupTypes");
            return companySicMajorGroupTypes;
        }

        public CaseDataReceivedResponseDto CaseDataReceived(CaseDataReceivedRequestDto request)
        {
            Log.Trace("+CaseDataReceived");

            //TODO: Implement business logic here

            Log.Trace("-CaseDataReceived");

            return new CaseDataReceivedResponseDto();
        }

        public string GenerateCaseNumber()
        {
            Log.TraceFormat("+GenerateCaseNumber");

            int? caseNumberId = null;
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    caseNumberId = unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_GetCaseNumber]").FirstOrDefault();
                    unitOfWork.Commit();
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR generating a new case number", ex);
                throw;
            }

            if (caseNumberId == null) throw new BusinessException("Error", "Null case number generated!");

            string caseNumber = string.Format("C{0}", caseNumberId);
            Log.TraceFormat("New case number generate={0}", caseNumber);

            Log.TraceFormat("-GenerateCaseNumber");
            return caseNumber;
        }

        public int GetCaseId(string gaCaseId)
        {
            Log.TraceFormat("+GetCaseId");
            int caseId = 0;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.GACaseId == gaCaseId);
                if (cmsCase != null)
                {
                    caseId = cmsCase.Id;
                }
            }
            Log.TraceFormat("-GetCaseId");
            return caseId;
        }

        public int? GetCaseIdByCaseNumber(string caseNumber)
        {
            Log.TraceFormat("+GetCaseIdByCaseNumber");

            int? caseId = null;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.CaseNumber == caseNumber);
                if (cmsCase != null)
                {
                    caseId = cmsCase.Id;
                }
            }

            Log.TraceFormat("-GetCaseIdByCaseNumber");
            return caseId;
        }

        public void SaveGACaseSubmission(GACaseSubmissionDto request)
        {
            Log.TraceFormat("+SaveGACaseSubmission");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var gaCaseSubmission = unitOfWork.Repository<GACaseSubmission>().Linq().FirstOrDefault(c => c.GACaseSubmissionId == request.GACaseSubmissionId);
                if (gaCaseSubmission == null)
                {
                    gaCaseSubmission = new GACaseSubmission();
                    gaCaseSubmission.ReceivedDateTime = DateTime.Now;
                }

                gaCaseSubmission.TitanCaseNumber = request.TitanCaseNumber;
                gaCaseSubmission.GACaseId = request.GACaseId;
                gaCaseSubmission.GACaseSubmissionId = request.GACaseSubmissionId;
                gaCaseSubmission.MessageType = request.MessageType;
                gaCaseSubmission.MessageId = request.MessageId;
                gaCaseSubmission.CaseSubmissionName = request.CaseSubmissionName;
                gaCaseSubmission.RegionName = request.RegionName;
                gaCaseSubmission.ExternalWholesaler = request.ExternalWholesaler;               
                gaCaseSubmission.Note = request.Note;
                gaCaseSubmission.EnrollmentType = request.EnrollmentType;
                gaCaseSubmission.ProposedEnrollStartDate = request.ProposedEnrollStartDate;
                gaCaseSubmission.ProposedEnrollEndDate = request.ProposedEnrollEndDate;
                gaCaseSubmission.ProposedExtensionEndDate = request.ProposedExtensionEndDate;
                gaCaseSubmission.ProposedEffectiveDate = request.ProposedEffectiveDate;
                gaCaseSubmission.IsLicenseingCaseUtilizeCorpIndicator = request.IsLicenseingCaseUtilizeCorpIndicator;
                gaCaseSubmission.IsLicenseingCaseUtilizeIndProdIndicator = request.IsLicenseingCaseUtilizeIndProdIndicator;
                gaCaseSubmission.IsLicenseingCaseUtilizeIndOtherIndicator = request.IsLicenseingCaseUtilizeIndOtherIndicator;
                gaCaseSubmission.CorporationName = request.CorporationName;
                gaCaseSubmission.CorpWritingCode = request.CorpWritingCode;
                gaCaseSubmission.SubProducerName = request.SubProducerName;
                gaCaseSubmission.SubProdWritingCode = request.SubProdWritingCode;
                gaCaseSubmission.IsWritingCodeInProcessIndicator = request.IsWritingCodeInProcessIndicator;
                gaCaseSubmission.AgencyCode = request.AgencyCode;
                gaCaseSubmission.RgoCode = request.RgoCode;
                gaCaseSubmission.IndividualProducerName = request.IndividualProducerName;
                gaCaseSubmission.IndividualProducerWritingCode = request.IndividualProducerWritingCode;
                gaCaseSubmission.IsIndividualProducerWritingCodeInProcessIndicator = request.IsIndividualProducerWritingCodeInProcessIndicator;
                gaCaseSubmission.IndividualProducerAgencyCode = request.IndividualProducerAgencyCode;
                gaCaseSubmission.IndividualProducerRGOCode = request.IndividualProducerRGOCode;
                gaCaseSubmission.OtherDISpecialistName = request.OtherDISpecialistName;
                gaCaseSubmission.OtherDISpecialiastNumber = request.OtherDISpecialiastNumber;
                gaCaseSubmission.OtherGroupSaleRepName = request.OtherGroupSaleRepName;
                gaCaseSubmission.OtherGroupSaleRepNumber = request.OtherGroupSaleRepNumber;
                gaCaseSubmission.EnrollmentMethodType_Id = request.EnrollmentMethodType_Id;
                gaCaseSubmission.ClientName = request.ClientName;
                gaCaseSubmission.ClientPhone = request.ClientPhone;
                gaCaseSubmission.ClientEmail = request.ClientEmail;
                gaCaseSubmission.EnrollmentName = request.EnrollmentName;
                gaCaseSubmission.EnrollmentPhone = request.EnrollmentPhone;
                gaCaseSubmission.EnrollmentEmail = request.EnrollmentEmail;
                gaCaseSubmission.IsEnrollmentKitDeliveryOptionIndicator = request.IsEnrollmentKitDeliveryOptionIndicator;
                gaCaseSubmission.IsMailDeliveryOptionIndicator = request.IsMailDeliveryOptionIndicator;
                gaCaseSubmission.EmailName = request.EmailName;
                gaCaseSubmission.EmailAddress = request.EmailAddress;
                gaCaseSubmission.MailName = request.MailName;
                gaCaseSubmission.MailAttention = request.MailAttention;
                gaCaseSubmission.MailAddress = request.MailAddress;
                gaCaseSubmission.MailCity = request.MailCity;
                gaCaseSubmission.MailState = request.MailState;
                gaCaseSubmission.MailZipCode = request.MailZipCode;
                gaCaseSubmission.MailDeliveryInstruction = request.MailDeliveryInstruction;
                gaCaseSubmission.IsMaterialsContactInformationIndicator = request.IsMaterialsContactInformationIndicator;

                unitOfWork.Repository<GACaseSubmission>().Save(gaCaseSubmission);

                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveGACaseSubmission");
        }

        public void SaveCaseStatusInformation(int caseId, int caseStausTypeId)
        {
            Log.TraceFormat("+SaveCaseStatusInformation");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");

                cmsCase.CaseStatusType = (CaseStatusTypeEnum)caseStausTypeId;

                unitOfWork.Repository<Case>().Save(cmsCase);

                unitOfWork.Commit();
            }
            Log.TraceFormat("-SaveCaseStatusInformation");
        }

        public string GetCaseNumberbyCaseId(int caseId)
        {
            Log.TraceFormat("+GetCaseNumberbyCaseId");

            var caseNumber = string.Empty;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                if (cmsCase != null)
                {
                    caseNumber = cmsCase.CaseNumber;
                }
            }

            Log.TraceFormat("-GetCaseNumberbyCaseId");

            return caseNumber;
        }

        public void SaveCaseStatusAndPDRStatus(CaseStatusDto request)
        {
            Log.TraceFormat("+SaveCaseStatusAndPDRStatus");

            if (request != null)
            {
                Log.TraceFormat("+SaveCaseStatusAndPDRStatus Case Id {0} and Status Type {1}", request.CaseId, request.CaseStatusType.GetDescription());

                var hasFormalOffer = CheckCaseReachedFormalOfferStatus(request);

                if (hasFormalOffer && request.PlanDesignRequestId > 0)
                {
                    // No need to update case status
                    if (request.PlanDesignRequestStatusType != null)
                    {
                        SavePDRHistoryStatusByCase(request.CaseId, (PlanDesignRequestStatusTypeEnum)request.PlanDesignRequestStatusType, request.PlanDesignRequestId);
                    }
                }
                else
                {
                    SaveCaseStatusInformation(request.CaseId, (int)request.CaseStatusType);

                    if (request.PlanDesignRequestStatusType != null)
                    {
                        SavePDRHistoryStatusByCase(request.CaseId, (PlanDesignRequestStatusTypeEnum)request.PlanDesignRequestStatusType, request.PlanDesignRequestId);
                    }
                }

                Log.TraceFormat("-SaveCaseStatusAndPDRStatus Case Id {0} and Status Type {1}", request.CaseId, request.CaseStatusType.GetDescription());
            }

            Log.TraceFormat("-SaveCaseStatusAndPDRStatus");
        }

        private bool CheckCaseReachedFormalOfferStatus(CaseStatusDto request)
        {
            Log.TraceFormat("+CheckCaseReachedFormalOfferStatus");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignRequests = unitOfWork.Repository<PlanDesignRequest>().Linq().Where(c => c.Case.Id == request.CaseId && c.IsActive);

                Log.TraceFormat("-CheckCaseReachedFormalOfferStatus");

                return planDesignRequests.SelectMany(c => c.PlanDesignRequestStatusHistories)
                    .Any(c => c.PlanDesignRequestStatusType == PlanDesignRequestStatusTypeEnum.FormalOffer);
            }
        }

        private void SavePDRHistoryStatusByCase(int caseId, PlanDesignRequestStatusTypeEnum statusType, int planDesignRequestId)
        {
            Log.TraceFormat("+SavePDRHistoryStatusByCase Id {0} PlanDesignStatus type {1} Plan Design Request Id {2}", caseId, statusType.GetDescription(), planDesignRequestId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");

                if (planDesignRequestId == 0)
                {
                    var planDesignRequests = cmsCase.PlanDesignRequests;

                    DateTime currentDateTime = DateTime.Now;
                    foreach (var pdr in planDesignRequests)
                    {
                        var statusHistory = new PlanDesignRequestStatusHistory();
                        statusHistory.PlanDesignRequest = pdr;
                        statusHistory.PlanDesignRequestStatusType = statusType;
                        statusHistory.DateOfChange = currentDateTime;
                        unitOfWork.Repository<PlanDesignRequestStatusHistory>().Save(statusHistory);
                    }
                }
                else
                {
                    var pdr = cmsCase.PlanDesignRequests.FirstOrDefault(c => c.Id == planDesignRequestId);
                    if (pdr != null)
                    {
                        var statusHistory = new PlanDesignRequestStatusHistory();
                        statusHistory.PlanDesignRequest = pdr;
                        statusHistory.PlanDesignRequestStatusType = statusType;
                        statusHistory.DateOfChange = DateTime.Now;
                        unitOfWork.Repository<PlanDesignRequestStatusHistory>().Save(statusHistory);
                    }
                }
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SavePDRHistoryStatusByCase Id {0}", caseId);
        }

        public StickyBarDto GetStickyBarInformationByCaseId(int caseId)
        {
            Log.TraceFormat("+GetStickyBarInformationByCaseId caseId={0}", caseId);

            var stickyBarDto = new StickyBarDto();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                var cmsUser = unitOfWork.Repository<CmsUser>().Linq().ToList();
                if (cmsCase == null) throw new ValidationException("Case not found!");

                stickyBarDto.CaseId = cmsCase.Id;

                stickyBarDto.CaseNumber = cmsCase.CaseNumber;
                stickyBarDto.CompanyName = cmsCase.CompanyName;
                stickyBarDto.CaseStatusTypeId = (int)cmsCase.CaseStatusType;
                stickyBarDto.CaseStatusTypeDescription = cmsCase.CaseStatusType.GetDescription();
                stickyBarDto.IsCompanyNonDisclosureAgreementIndicator = cmsCase.IsCompanyNonDisclosureAgreementIndicator;
                stickyBarDto.IsCompanyErisaIndicator = cmsCase.IsCompanyErisaIndicator;

                GetWholesalerName(stickyBarDto, cmsCase);
                GetProducerDetailsByCase(stickyBarDto, cmsCase);
                GetUnderWriterInfoByCase(stickyBarDto, cmsCase, unitOfWork);
                GetBillingSpecialistInfoByCase(stickyBarDto, cmsCase, unitOfWork);

                var enrollmentMgr = cmsUser.FirstOrDefault(t => t.Id == cmsCase.EnrollmentManagerId);
                if (enrollmentMgr != null)
                {
                    stickyBarDto.EnrollmentManager = enrollmentMgr.FirstName + " " + enrollmentMgr.LastName;
                }

                var implementationAnalyst = cmsUser.FirstOrDefault(t => t.Id == cmsCase.ImplementationAnalystId);
                if (implementationAnalyst != null)
                {
                    stickyBarDto.ImplementationAnalyst = implementationAnalyst.FirstName + " " + implementationAnalyst.LastName;
                }

            }

            Log.TraceFormat("-GetStickyBarInformationByCaseId");
            return stickyBarDto;
        }

        private void GetUnderWriterInfoByCase(StickyBarDto stickyBarDto, Case cmsCase, IUnitOfWork unitOfWork)
        {
            var cmsTasks = unitOfWork.Repository<CmsTask>().Linq().Where(c => c.Case.Id == cmsCase.Id).ToList();
            var openTasks = cmsTasks.Where(c => !c.IsCompletedIndicator).ToList();
            if (openTasks.Any())
            {
                if (openTasks.Any(c => c.AssignedToUserGroup != null))
                {
                    var taskDetails = openTasks.Where(c => c.AssignedToUserGroup != null && c.AssignedToUserGroup.Id == UserGroup.Group_Underwriting).ToList();
                    if (taskDetails.Any())
                    {
                        var groups = taskDetails.Where(c => c.AssignedToUser != null).FirstOrDefault();
                        if (groups != null)
                        {
                            stickyBarDto.UnderWriterUserId = (groups.AssignedToUser != null) ? (int?)groups.AssignedToUser.Id : null;
                            stickyBarDto.UnderWriterUserDescription = (groups.AssignedToUser != null) ? (groups.AssignedToUser.FirstName + " " + groups.AssignedToUser.LastName) : string.Empty;
                        }
                    }
                    else
                    {
                        var completedTasks = cmsTasks.Where(c => c.IsCompletedIndicator).OrderByDescending(c => c.Id).ToList();
                        if (completedTasks.Any())
                        {
                            var completedTaskDetails = completedTasks.Where(c => c.AssignedToUserGroup != null && c.AssignedToUserGroup.Id == UserGroup.Group_Underwriting).ToList();
                            if (completedTaskDetails.Any())
                            {
                                var groups = completedTaskDetails.Where(c => c.AssignedToUser != null).FirstOrDefault();
                                if (groups != null)
                                {
                                    stickyBarDto.UnderWriterUserId = (groups.AssignedToUser != null) ? (int?)groups.AssignedToUser.Id : null;
                                    stickyBarDto.UnderWriterUserDescription = (groups.AssignedToUser != null) ? (groups.AssignedToUser.FirstName + " " + groups.AssignedToUser.LastName) : string.Empty;
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                var groups = cmsTasks.Where(c => c.AssignedToUser != null).OrderByDescending(c => c.Id).FirstOrDefault();
                stickyBarDto.UnderWriterUserId = (groups.AssignedToUser != null) ? (int?)groups.AssignedToUser.Id : null;
                stickyBarDto.UnderWriterUserDescription = (groups.AssignedToUser != null) ? (groups.AssignedToUser.FirstName + " " + groups.AssignedToUser.LastName) : string.Empty;
            }
        }

        private void GetBillingSpecialistInfoByCase(StickyBarDto stickyBarDto, Case cmsCase, IUnitOfWork unitOfWork)
        {
            var cmsTasks = unitOfWork.Repository<CmsTask>().Linq().Where(c => c.Case.Id == cmsCase.Id).ToList();
            var openTasks = unitOfWork.Repository<CmsTask>().Linq().Where(c => c.Case.Id == cmsCase.Id && !c.IsCompletedIndicator).ToList();
            if (openTasks.Any())
            {
                if (openTasks.Any(c => c.AssignedToUserGroup != null))
                {
                    var taskDetails = openTasks.Where(c => c.AssignedToUserGroup != null
                    && c.AssignedToUserGroup.Id == UserGroup.Group_BillingSpecialist).OrderByDescending(c => c.CreationDate).ToList();
                    if (taskDetails.Any())
                    {
                        var groups = taskDetails.Where(c => c.AssignedToUser != null).FirstOrDefault();
                        if (groups != null)
                        {
                            stickyBarDto.BillingSpecialistUserId = (groups.AssignedToUser != null) ? (int?)groups.AssignedToUser.Id : null;
                            stickyBarDto.BillingSpecialistUserDescription = (groups.AssignedToUser != null) ? (groups.AssignedToUser.FirstName + " " + groups.AssignedToUser.LastName) : string.Empty;
                        }
                    }
                    else
                    {
                        var completedTasks = cmsTasks.Where(c => c.IsCompletedIndicator).OrderByDescending(c => c.Id).ToList();
                        if (completedTasks.Any())
                        {
                            var completedTaskDetails = completedTasks.Where(c => c.AssignedToUserGroup != null
                            && c.AssignedToUserGroup.Id == UserGroup.Group_BillingSpecialist).OrderByDescending(c => c.CreationDate).ToList();
                            if (completedTaskDetails.Any())
                            {
                                var groups = completedTaskDetails.Where(c => c.AssignedToUser != null).FirstOrDefault();
                                if (groups != null)
                                {
                                    stickyBarDto.BillingSpecialistUserId = (groups.AssignedToUser != null) ? (int?)groups.AssignedToUser.Id : null;
                                    stickyBarDto.BillingSpecialistUserDescription = (groups.AssignedToUser != null) ? (groups.AssignedToUser.FirstName + " " + groups.AssignedToUser.LastName) : string.Empty;
                                }
                            }
                        }
                    }
                }
            }
        }

        private void GetWholesalerName(StickyBarDto stickyBarDto, Case cmsCase)
        {
            var caseWholesaler = cmsCase.CaseWholesalers.FirstOrDefault(c => c.IsPrimaryIndicator == true);
            if (caseWholesaler != null)
            {               
                var externalWholesaler = caseWholesaler.ExternalWholesaler;                
                if (externalWholesaler != null)
                {
                    stickyBarDto.ExternalWholesalerName = externalWholesaler.FirstName + " " + externalWholesaler.LastName;
                }
            }
        }

        private void GetProducerDetailsByCase(StickyBarDto stickyBarDto, Case cmsCase)
        {
            var caseBrokers = cmsCase.CaseBrokers;
            int stateId = _planDesignRequestManager.GetCorporateSitusStateByCaseId(cmsCase.Id);
            if (caseBrokers != null)
            {
                var caseBrokerStates = caseBrokers.SelectMany(c => c.CaseBrokerStates).Where(s => (int)s.StateType == stateId).FirstOrDefault();
                if (caseBrokerStates != null)
                {
                    if (caseBrokerStates.IsPrimaryBrokerIndicator == true)
                    {
                        stickyBarDto.PrimaryProducer = caseBrokerStates.CaseBroker.BrokerName;
                        stickyBarDto.AgencyCode = caseBrokerStates.CaseBroker.AgencyCode;
                        stickyBarDto.ProducerAffiliationTypeId = caseBrokerStates.CaseBroker.BrokerAffiliationType != null ? (int?)caseBrokerStates.CaseBroker.BrokerAffiliationType.Id : null;
                        stickyBarDto.ProducerAffiliationTypeName = caseBrokerStates.CaseBroker.BrokerAffiliationType != null ? caseBrokerStates.CaseBroker.BrokerAffiliationType.Name : string.Empty;
                    }
                }
            }
        }

        public void UpdateAssignedUsersForTask(StickyBarDto stickyBarDto)
        {
            Log.TraceFormat("+UpdateAssignedUsersForTask");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsTasks = unitOfWork.Repository<CmsTask>().Linq().Where(c => c.Case.Id == stickyBarDto.CaseId && c.AssignedToUserGroup != null && !c.IsCompletedIndicator);
                var cmsUnderWritingTasks = cmsTasks.Where(c => c.AssignedToUserGroup.Id == UserGroup.Group_Underwriting).ToList();
                var cmsBillingSpecialistTasks = cmsTasks.Where(c => c.AssignedToUserGroup.Id == UserGroup.Group_BillingSpecialist).ToList();
                var cmsUsers = unitOfWork.Repository<CmsUser>().Linq();

                if (cmsUnderWritingTasks.Any())
                {
                    Log.TraceFormat("cmsUnderWritingTasks.Any");
                    foreach (var task in cmsUnderWritingTasks)
                    {
                        if (stickyBarDto.UnderWriterUserId != null)
                        {
                            Log.TraceFormat("stickyBarDto.UnderWriterUserId");
                            var underWriterUser = cmsUsers.FirstOrDefault(t => t.Id == stickyBarDto.UnderWriterUserId);
                            task.AssignedToUser = underWriterUser;
                            Log.TraceFormat("Save CmsTask");
                            unitOfWork.Repository<CmsTask>().Save(task);
                            Log.TraceFormat("Save CmsTaskActivityLog");
                            SaveTaskActivityLog(task, unitOfWork);
                        }
                    }
                }
                if (cmsBillingSpecialistTasks.Any())
                {
                    Log.TraceFormat("cmsUnderWritingTasks.Any-BS");
                    foreach (var task in cmsBillingSpecialistTasks)
                    {
                        if (stickyBarDto.BillingSpecialistUserId != null)
                        {
                            Log.TraceFormat("stickyBarDto.UnderWriterUserId-BS");
                            var billingSpecialistUser = cmsUsers.FirstOrDefault(t => t.Id == stickyBarDto.BillingSpecialistUserId);
                            task.AssignedToUser = billingSpecialistUser;
                            Log.TraceFormat("Save CmsTask");
                            unitOfWork.Repository<CmsTask>().Save(task);
                            Log.TraceFormat("Save CmsTaskActivityLog");
                            SaveTaskActivityLog(task, unitOfWork);
                        }
                    }
                }
                Log.TraceFormat("Commit Start");
                unitOfWork.Commit();
                Log.TraceFormat("Commit End");
            }
            Log.TraceFormat("-UpdateAssignedUsersForTask");
        }

        public void UpdatePDRStatusByCase(int caseId, PlanDesignRequestStatusTypeEnum planDesignRequestStatusType)
        {
            Log.TraceFormat("+UpdatePDRStatus case Id={0}", caseId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var planDesignRequests = unitOfWork.Repository<PlanDesignRequest>().Linq().Where(c => c.Case.Id == caseId && c.IsActive);
                var pdrIds = planDesignRequests.Select(c => c.Id).ToList();

                var pdrSoldClasses = unitOfWork.Repository<PDRSoldClass>().Linq().Where(c => pdrIds.Contains(c.PlanDesignRequest.Id) && c.IsActive);

                if (pdrSoldClasses != null)
                {
                    if (pdrSoldClasses.Any())
                    {
                        foreach (var pdrSoldclass in pdrSoldClasses)
                        {
                            var planDesignRequest = planDesignRequests.FirstOrDefault(c => c.Id == pdrSoldclass.PlanDesignRequest.Id);
                            if (planDesignRequest != null)
                            {
                                Log.TraceFormat("+UpdatePDRStatus PDR Id={0}", planDesignRequest.Id);

                                var pdrStatusHistory = new PlanDesignRequestStatusHistory();
                                pdrStatusHistory.PlanDesignRequest = planDesignRequest;
                                pdrStatusHistory.PlanDesignRequestStatusType = planDesignRequestStatusType;
                                pdrStatusHistory.DateOfChange = DateTime.Now;
                                planDesignRequest.PlanDesignRequestStatusHistories.Add(pdrStatusHistory);

                                if (planDesignRequestStatusType == PlanDesignRequestStatusTypeEnum.Withdrawn)
                                {
                                    planDesignRequest.PlanDesignRequestStatusType = PlanDesignRequestStatusTypeEnum.Withdrawn;
                                }
                                unitOfWork.Repository<PlanDesignRequest>().Save(planDesignRequest);
                            }
                        }
                        unitOfWork.Commit();
                    }
                }
            }

            Log.TraceFormat("+UpdatePDRStatus case Id={0}", caseId);
        }

        private void SaveTaskActivityLog(CmsTask task, IUnitOfWork unitOfWork)
        {
            Log.TraceFormat("+LogTaskActivity");
            var taskActivityLog = new TaskActivityLog
            {
                Task = task,
                TaskGroup = task.TaskGroup,
                Case = task.Case,
                CreationDate = task.CreationDate,
                DueDate = task.DueDate,
                AssignedToUser = task.AssignedToUser,
                AssignedToUserGroup = task.AssignedToUserGroup,
                ClaimedByUser = task.ClaimedByUser,
                CompletedDate = task.CompletedDate != null ? task.CompletedDate : null,
                UpdatedDueDate = task.UpdatedDueDate != null ? task.UpdatedDueDate : null,
                FollowUpDate = task.FollowUpDate != null ? task.FollowUpDate : null,
                Comments = task.Comments,
                TaskStatusType = task.TaskStatusType,
                IsAdHocIndicator = task.IsAdHocIndicator,
                ClaimedDate = task.ClaimedDate,
                SuspendedDate = task.SuspendedDate,
                CompletedByUser = task.CompletedByUser
            };
            Log.TraceFormat("TaskActivityLog Save");
            unitOfWork.Repository<TaskActivityLog>().Save(taskActivityLog);
            Log.TraceFormat("-LogTaskActivity");
        }

        public CaseUpdateDto GetCaseUpdateInfo(string caseNumber)
        {
            Log.TraceFormat("+GetCaseUpdateInfo caseNumber:" + caseNumber);

            var caseUpdate = new CaseUpdateDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.CaseNumber == caseNumber);
                if (cmsCase == null) throw new ValidationException("Case Number not found in titan");

                if (cmsCase.CaseNumber != null && cmsCase.CaseNumber.ToUpper().StartsWith("C"))
                {
                    caseUpdate.IsHideCase = false;
                    caseUpdate.CaseNumber = cmsCase.CaseNumber;
                    caseUpdate.CompanyName = cmsCase.CompanyName;
                }

                else if (cmsCase.CaseNumber != null && cmsCase.CaseNumber.ToUpper().StartsWith("R"))
                {
                    caseUpdate.IsHideCase = true;
                    caseUpdate.CaseNumber = cmsCase.CaseNumber;
                    caseUpdate.CompanyName = cmsCase.CompanyName;
                }
            }

            Log.TraceFormat("-GetCaseUpdateInfo caseNumber:" + caseNumber);
            return caseUpdate;
        }

        public MaskedCaseDto SaveCaseUpdates(CaseUpdateDto request)
        {
            Log.TraceFormat("+SaveCaseUpdates caseNumber : " + request.CaseNumber);
            var maskedCaseDto = new MaskedCaseDto();
            string message = string.Empty;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().OrderByDescending(c => c.Id).FirstOrDefault(c => c.CaseNumber == request.CaseNumber);

                if (cmsCase == null) throw new ValidationException("Case Number not found in titan");

                if (request.CaseNumber.ToUpper().StartsWith("C") && request.IsHideCase)
                {
                    cmsCase.CaseNumber = request.CaseNumber.Replace('C', 'R');
                    message = "The case number " + request.CaseNumber + " has been masked successfully.";
                }

                else if (request.CaseNumber.ToUpper().StartsWith("R") && !request.IsHideCase)
                {
                    cmsCase.CaseNumber = request.CaseNumber.Replace('R', 'C');
                    message = "The case number " + request.CaseNumber + " has been unmasked successfully.";
                }

                unitOfWork.Repository<Case>().Save(cmsCase);
                unitOfWork.Commit();

                maskedCaseDto.CaseNumber = cmsCase.CaseNumber;
                maskedCaseDto.GaCaseId = cmsCase.GACaseId;
                maskedCaseDto.Message = message;
            }
            Log.TraceFormat("-SaveCaseUpdates caseNumber : " + request.CaseNumber);

            return maskedCaseDto;
        }

        public void SaveCompanyEmployerClient(CaseDto caseDto)
        {
            Log.TraceFormat("+SaveCompanyEmployerClient");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseDto.CaseId);
                if (cmsCase != null)
                {
                    cmsCase.Company.EmployerClientId = caseDto.EmployerClientId;
                    unitOfWork.Commit();
                }
            }
            Log.TraceFormat("-SaveCompanyEmployerClient");
        }

        public List<CaseCompanyDto> GetCasesCompanyList(string employerClientId, int caseid)
        {
            Log.TraceFormat("+GetCasesCompanyList");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseCompanyDto = new List<CaseCompanyDto>();

                var company = unitOfWork.Repository<Company>().Linq().Where(c => c.EmployerClientId == employerClientId).Select(co => co.Id).ToList();

                if (company.Any())
                {
                    caseCompanyDto = unitOfWork.Repository<Case>().Linq().Where(c => company.Contains(c.Company.Id) && c.Id != caseid).Select(r => new CaseCompanyDto
                    {
                        CaseNumber = r.CaseNumber,
                        CaseStatusType = r.CaseStatusType,
                        CaseId = r.Id
                    }).ToList();
                }
                Log.TraceFormat("-GetCasesCompanyList");
                return caseCompanyDto;
            }

        }

        public List<CaseParticipantDto> GetParticipantDetails(string caseNumber, string employeeId)
        {
            Log.TraceFormat("+GetParticipantDetails");
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var caseParticipantDtoList = new List<CaseParticipantDto>();

                var enrollments = unitOfWork.Repository<Enrollment>().Linq().Where(c => c.Case.CaseNumber == caseNumber && (c.IsActive == true || c.IsActive == null)).ToList();
                if (enrollments.Any())
                {
                    foreach (var enrollment in enrollments)
                    {
                        var censusParticipants = enrollment.CensusParticipants.Where(c => c.Participant.EmployeeId == employeeId).ToList();

                        if (censusParticipants.Any())
                        {
                            var caseParticipantDto = censusParticipants.Select(c => new CaseParticipantDto
                            {
                                CaseNumber = caseNumber,
                                EmployeeId = c.Participant.EmployeeId,
                                FirstName = c.Participant.FirstName,
                                LastName = c.Participant.LastName,
                                MiddleInitial = c.Participant.MiddleInitial,
                                EnrollmentParticipantId = c.Id,
                            }).ToList().Distinct();

                            caseParticipantDtoList.AddRange(caseParticipantDto);
                        }
                    }
                }
                else
                {
                    throw new ValidationException("Active Enrollment Not Found!");
                }

                caseParticipantDtoList.GroupBy(c => new { c.EmployeeId, c.FirstName, c.LastName }).Select(c => c.First());
                Log.TraceFormat("-GetParticipantDetails");
                return caseParticipantDtoList;
            }
        }

        public string UpdateSSNDetailsForParticipants(CaseParticipantDto caseParticipantDto)
        {
            Log.TraceFormat("-UpdateSSNDetailsForParticipants");
            string message = string.Empty;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var enrollmentParticipants = unitOfWork.Repository<EnrollmentParticipant>().Linq().Where(c =>
                c.Participant != null && c.Participant.EmployeeId == caseParticipantDto.EmployeeId && c.Enrollment.Case.CaseNumber == caseParticipantDto.CaseNumber).ToList();

                if (enrollmentParticipants.Any())
                {
                    foreach (var participant in enrollmentParticipants)
                    {
                        participant.SocialSecurityNumber = caseParticipantDto.SocialSecurityNumber;
                        unitOfWork.Repository<EnrollmentParticipant>().Save(participant);
                    }
                }
                unitOfWork.Commit();
                message = "SSN has been updated for the case# " + caseParticipantDto.CaseNumber + ", Employee ID  " + caseParticipantDto.EmployeeId + " successfully";
            }

            Log.TraceFormat("-UpdateSSNDetailsForParticipants");
            return message;
        }

        public RppLimitsDto UpdateRPPLimits(RppLimitsDto rppLimitsDto)
        {
            Log.TraceFormat("+UpdateRPPLimits");
            string message = string.Empty;

            var rppLimitsMsg = new RppLimitsDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var eligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().Where(i => i.Id == 1).FirstOrDefault(); // First record the default record and should be updated always
                if (eligibilityConfiguration != null)
                {
                    eligibilityConfiguration.RPPMaximumIndemnityAmount = rppLimitsDto.rpplimit50Plus;
                    eligibilityConfiguration.RPPMaximumIndemnityAmountUnderAge49 = rppLimitsDto.rpplimit18To49;
                    unitOfWork.Repository<EligibilityConfiguration>().Save(eligibilityConfiguration);
                    unitOfWork.Commit();
                    message = "RPP Limits has been updated succesfully.";
                }
                else
                {
                    message = "RPP Limits updation failed.";
                }
            }
            rppLimitsMsg.message = message;
            Log.TraceFormat("-UpdateRPPLimits");
            return rppLimitsMsg;
        }

        public RppLimitsDto GetRPPLimits()
        {
            Log.TraceFormat("+GetRPPLimits");

            var rppLimitDto = new RppLimitsDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var eligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().Where(i => i.Id == 1).FirstOrDefault(); // First record the default record and should be updated always
                if (eligibilityConfiguration != null)
                {
                    rppLimitDto.rpplimit50Plus = eligibilityConfiguration.RPPMaximumIndemnityAmount;
                    rppLimitDto.rpplimit18To49 = eligibilityConfiguration.RPPMaximumIndemnityAmountUnderAge49;
                }
            }
            Log.TraceFormat("-GetRPPLimits");

            return rppLimitDto;
        }

        public IandPLimitsDto GetIandPLimits()
        {
            Log.TraceFormat("+GetIandPLimits");

            var ipLimitDto = new IandPLimitsDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var eligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().Where(i => i.Id == 1).FirstOrDefault(); // First record the default record and should be updated always
                if (eligibilityConfiguration != null)
                {
                    ipLimitDto.nonCAIssueLimit = eligibilityConfiguration.IssueLimitMaximum;
                    ipLimitDto.CAIssueLimit = eligibilityConfiguration.CAIssueLimitMaximum;
                    ipLimitDto.nonCAParticipationLimit = eligibilityConfiguration.ParticipationLimit;
                    ipLimitDto.CAParticipationLimit = eligibilityConfiguration.CAParticipationLimit;
                }
            }
            Log.TraceFormat("-GetIandPLimits");

            return ipLimitDto;
        }

        public IandPLimitsDto UpdateIandPLimits(IandPLimitsDto rppLimitsDto)
        {
            Log.TraceFormat("+UpdateIandPLimits");
            string message = string.Empty;

            var IPLimitMessage = new IandPLimitsDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var eligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().Where(i => i.Id == 1).FirstOrDefault(); // First record the default record and should be updated always
                if (eligibilityConfiguration != null)
                {
                    eligibilityConfiguration.CAIssueLimitMaximum = rppLimitsDto.CAIssueLimit;
                    eligibilityConfiguration.IssueLimitMaximum = rppLimitsDto.nonCAIssueLimit;
                    eligibilityConfiguration.CAParticipationLimit = rppLimitsDto.CAParticipationLimit;
                    eligibilityConfiguration.ParticipationLimit = rppLimitsDto.nonCAParticipationLimit;
                    unitOfWork.Repository<EligibilityConfiguration>().Save(eligibilityConfiguration);
                    unitOfWork.Commit();
                    message = "I&P limits have been updated successfully.";
                }
                else
                {
                    message = "I&P Limits updation failed.";
                }
            }
            IPLimitMessage.message = message;
            Log.TraceFormat("-UpdateIandPLimits");
            return IPLimitMessage;
        }

        public List<BrokerAffiliationTypeDto> GetBrokerAffiliations()
        {
            Log.TraceFormat("+GetBrokerAffiliations");

            List<BrokerAffiliationTypeDto> affiliationTypeDtos;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                affiliationTypeDtos = unitOfWork.Repository<BrokerAffiliationType>()
                    .Linq()
                    .Where(brokerAffiliation => brokerAffiliation.Status != StatusEnum.Deleted.ToString())
                    .Select(brokerAffiliation => new BrokerAffiliationTypeDto
                    {
                        Code = brokerAffiliation.Code,
                        Description = brokerAffiliation.Description,
                        Name = brokerAffiliation.Name,
                        BrokerAffiliationType_Id = brokerAffiliation.Id,
                        Status = brokerAffiliation.Status,
                        UpdatedAt = brokerAffiliation.UpdatedAt,
                        UpdatedBy = brokerAffiliation.UpdatedBy
                    })
                    .Distinct()
                    .ToList();
            }

            Log.TraceFormat("-GetBrokerAffiliations");

            return affiliationTypeDtos;
        }

        public BrokerAffiliationTypeDto CreateBrokerAffiliationType(BrokerAffiliationTypeDto newBrokerAffiliationType)
        {
            Log.TraceFormat("+CreateBrokerAffiliationType");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                BrokerAffiliationType brokerAffiliation = new BrokerAffiliationType
                {
                    Code = newBrokerAffiliationType.Name.Replace(" ", "_"),
                    Description = newBrokerAffiliationType.Name,
                    Name = newBrokerAffiliationType.Name,
                    Status = StatusEnum.Active.ToString(),
                    UpdatedAt = DateTime.Now,
                    UpdatedBy = GetUpdatedBy(),
                    SortOrder = unitOfWork.Repository<BrokerAffiliationType>().Linq().Max(c => c.SortOrder).GetValueOrDefault() + 1
                };

                unitOfWork.Repository<BrokerAffiliationType>().Save(brokerAffiliation);
                unitOfWork.Commit();

                newBrokerAffiliationType.BrokerAffiliationType_Id = brokerAffiliation.Id;
                newBrokerAffiliationType.Status = brokerAffiliation.Status;
                newBrokerAffiliationType.UpdatedAt = brokerAffiliation.UpdatedAt;
                newBrokerAffiliationType.UpdatedBy = brokerAffiliation.UpdatedBy;
            }

            Log.TraceFormat("-CreateBrokerAffiliationType");
            return newBrokerAffiliationType;
        }

        public BrokerAffiliationTypeDto UpdateBrokerAffiliationType(BrokerAffiliationTypeDto updatedAffiliationType)
        { 
            Log.TraceFormat("+UpdateBrokerAffiliationType");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var brokerAffiliation = unitOfWork.Repository<BrokerAffiliationType>()
                    .Linq()
                    .FirstOrDefault(affiliation =>
                        affiliation.Status != StatusEnum.Deleted.ToString() &&
                        affiliation.Id == updatedAffiliationType.BrokerAffiliationType_Id);

                if (brokerAffiliation == null)
                {
                    throw new Exception("The broker affiliation with the provided ID does not exist.");
                }

                brokerAffiliation.Code = updatedAffiliationType.Name.Replace(" ", "_");
                brokerAffiliation.Description = updatedAffiliationType.Name;
                brokerAffiliation.Name = updatedAffiliationType.Name;

                brokerAffiliation.UpdatedBy = GetUpdatedBy();
                brokerAffiliation.UpdatedAt = DateTime.Now;
                unitOfWork.Repository<BrokerAffiliationType>().Save(brokerAffiliation);
                unitOfWork.Commit();

                updatedAffiliationType.UpdatedAt = brokerAffiliation.UpdatedAt;
                updatedAffiliationType.UpdatedBy = brokerAffiliation.UpdatedBy;
            }

            Log.TraceFormat("-UpdateBrokerAffiliationType");
            return updatedAffiliationType;
        }

        public BrokerAffiliationTypeDto DeleteBrokerAffiliationType(int brokerAffiliationTypeId)
        {
            Log.TraceFormat("+DeleteBrokerAffiliationType");

            BrokerAffiliationTypeDto responseDto = new BrokerAffiliationTypeDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var brokerAffiliation = unitOfWork.Repository<BrokerAffiliationType>()
                    .Linq()
                    .FirstOrDefault(affiliation =>
                        affiliation.Status != StatusEnum.Deleted.ToString() &&
                        affiliation.Id == brokerAffiliationTypeId);

                if (brokerAffiliation == null)
                {
                    throw new Exception("The broker affiliation with the provided ID does not exist.");
                }

                brokerAffiliation.Status = StatusEnum.Deleted.ToString();
                brokerAffiliation.UpdatedAt = DateTime.Now;
                brokerAffiliation.UpdatedBy = GetUpdatedBy();
                unitOfWork.Repository<BrokerAffiliationType>().Save(brokerAffiliation);
                unitOfWork.Commit();
            }

            Log.TraceFormat("-DeleteBrokerAffiliationType");
            return responseDto;
        }

        private string GetUpdatedBy()
        {
            var user = _securityManager.GetUserInfo(HttpContext.Current.User);
            return user.Name;
        }
    }
}
