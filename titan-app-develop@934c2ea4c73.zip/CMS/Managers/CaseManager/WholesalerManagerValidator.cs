﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Logger.Static;
using Common.Exceptions;
using CMS.Interfaces.Managers.CaseManagers;

namespace CMS.Managers.CaseManagers
{
    public class WholesalerManagerValidator
    {
        public void ValidatePrimaryWholesalerPresent(IList<CaseWholesalerDto> caseWholesalerDto)
        {
            Log.TraceFormat("+ValidatePrimaryWholesalerPresent");
            var errorMessages = new List<string>();

            if (caseWholesalerDto != null && caseWholesalerDto.Count > 0)
            {
                var primaryCaseWholeSaler = caseWholesalerDto.FirstOrDefault(i => i.IsPrimaryIndicator == true);

                if (primaryCaseWholeSaler != null)
                {
                    if (string.IsNullOrEmpty(primaryCaseWholeSaler.WholesalerRegionId.ToString()) || primaryCaseWholeSaler.WholesalerRegionId == 0)
                    {
                        errorMessages.Add("Please define the Wholesaler's Region for this case.");
                    }
                    if (primaryCaseWholeSaler.ExternalWholesalerId == null || primaryCaseWholeSaler.ExternalWholesalerId == 0)
                    {
                        errorMessages.Add("Please select an External Wholesaler.");
                    }                    
                }

                var secondaryCaseWholeSaler = caseWholesalerDto.FirstOrDefault(i => i.IsPrimaryIndicator == false);
                if (secondaryCaseWholeSaler != null)
                {
                    if (secondaryCaseWholeSaler.WholesalerRegionId != 0)
                    {
                        if (secondaryCaseWholeSaler.ExternalWholesalerId == null || secondaryCaseWholeSaler.ExternalWholesalerId == 0)
                        {
                            errorMessages.Add("Secondary Region selected without  External Wholesaler defined.");
                        }
                    }
                }

            }
            else
            {
                errorMessages.Add("Please define the Wholesaler's Region for this case.");
                errorMessages.Add("Please select an External Wholesaler.");
                errorMessages.Add("Please select an Internal Wholesaler.");
            }

            ValidateWholesalerPercent(caseWholesalerDto , errorMessages);

            Log.TraceFormat("-ValidatePrimaryWholesalerPresent");
            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }

        public void ValidateWholesalerPercent(IList<CaseWholesalerDto> caseWholesalerDto , List<string> errorMessages)
        {
            Log.TraceFormat("+ValidatePrimaryWholesalerPresent");

            if (caseWholesalerDto != null && caseWholesalerDto.Count > 0)
            {
                var externalWholesalerPercent = caseWholesalerDto.Sum(c => c.WholesalerPercent);
                if (externalWholesalerPercent > 0 && externalWholesalerPercent != 100)
                {
                    errorMessages.Add("External Wholesaler Percentages must total 100%");
                }
            }
        }
    }
}
