﻿using CMS.Interfaces.Managers.CaseManagers;
using Common.Exceptions;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CMS.Managers.CaseManagers
{
    public class CaseExistingCoverageValidator
    {
        public void ValidateCaseExistingCoverageData(ExistingCoverageDto caseExistingCoverageDto)
        {
            Log.TraceFormat("+ValidateCaseExistingCoverageData");

            var errorMessages = new List<string>();

            ValidateGSIAmount(caseExistingCoverageDto, errorMessages);

            ValidateLastTimeEnrolled(caseExistingCoverageDto, errorMessages);

            ValidateExistingGuranteedIssueCoverageIndicator(caseExistingCoverageDto, errorMessages);

            ValidateCompanyZipCode(caseExistingCoverageDto, errorMessages);

            Log.TraceFormat("-ValidateCaseExistingCoverageData");

            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }

       public bool IsDecimalOrInteger(decimal? percentage)
        {            
            return percentage % 1 == 0;            
        }
        public void ValidateExistingGuranteedIssueCoverageIndicator(ExistingCoverageDto caseExistingCoverageDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateExistingGuranteedIssueCoverageIndicator");

            if (caseExistingCoverageDto.IsExistingGuranteedIssueCoverageIndicator == null)
            {
                errorMessages.Add("Please enter Any existing Guaranteed Issue coverage Indicator.");
            }
            Log.TraceFormat("-ValidateExistingGuranteedIssueCoverageIndicator");
        }

        public void ValidateGSIAmount(ExistingCoverageDto caseExistingCoverageDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateGSIAmount");
            if (caseExistingCoverageDto.GSIAmount != null && caseExistingCoverageDto.GSIAmount <0)
            {
                errorMessages.Add("Please enter a valid GSI Amount greater than zero.");
            }            
            Log.TraceFormat("-ValidateGSIAmount");

        }

       public void ValidateLastTimeEnrolled(ExistingCoverageDto caseExistingCoverageDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateLastTimeEnrolled.");

            if (caseExistingCoverageDto.LastTimeEnrolled > DateTime.Now.Year)
            {
                errorMessages.Add("Please provide a Last Time Enrolled year that is less than or equal to the current year.");
            }
            Log.TraceFormat("-ValidateLastTimeEnrolled.");
        }

        public void ValidateCompanyZipCode(ExistingCoverageDto caseExistingCoverageDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateCompanyZipCode");
            if (!string.IsNullOrEmpty(caseExistingCoverageDto.FloridaReplacementCompanyZipCode))
            {
                bool isUsZipCode = IsUsZipCode(caseExistingCoverageDto.FloridaReplacementCompanyZipCode);
                Log.DebugFormat("IsUsZipCode={0}", isUsZipCode);
                if (!isUsZipCode) errorMessages.Add("Zip Code is invalid.");
            }
            Log.TraceFormat("-ValidateCompanyZipCode");
        }

        private bool IsUsZipCode(string zipCode)
        {
            Log.TraceFormat("+IsUsZipCode");

            bool validZipCode = false;
            string _usZipRegEx = @"^\d{5}(?:[-\s]\d{4})?$";
            if (Regex.Match(zipCode, _usZipRegEx).Success)
            {
                validZipCode = true;
            }
            Log.TraceFormat("-IsUsZipCode");
            return validZipCode;
        }
    }
}
