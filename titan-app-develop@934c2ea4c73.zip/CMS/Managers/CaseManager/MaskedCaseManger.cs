﻿using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.GAMessageManagers;
using CMS.Interfaces.Managers.GAMessageManagers.OutgoingMessages;
using CMS.Interfaces.Managers.WorkUnitManagers;
using CMS.Model.Entities;
using Logger.Static;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.CaseManagers
{
    public class MaskedCaseManger : IGaMaskedCaseManger, IWorkUnitHandler
    {

        private readonly IGaMessageManager _gaMessageManager;
        private readonly IWorkUnitManager _workUnitManager;

        public MaskedCaseManger(IGaMessageManager gaMessageManager, IWorkUnitManager workUnitManager)
        {
            _gaMessageManager = gaMessageManager;
            _workUnitManager = workUnitManager;
        }

        public void Execute(WorkUnit workUnit)
        {
            Log.TraceFormat("+MaskedCaseManger-Execute()");
            var request = JsonConvert.DeserializeObject<MaskedCaseDto>(workUnit.InputData);

            if (request != null )
            {
                Log.TraceFormat("+MaskedCaseManger-Execute()  TitanCaseNumber:" + request.CaseNumber);
                _gaMessageManager.SendMessage(new GaOutgoingMessage
                {
                    MessageType = request.MessageType,
                    GACaseId = request.GaCaseId,
                    TitanCaseNumber = request.CaseNumber,
                    MessageId = request.MessageId
                });
            }

            Log.TraceFormat("-MaskedCaseManger-Execute()");
        }

        public void CreateMaskedCaseGARequest(string gaCaseId, string titanCaseNumber)
        {
            Log.TraceFormat("+MaskedCaseManger-CreateMaskedCaseGARequest() TitanCaseNumber:" + titanCaseNumber);
            var maskedCaseDto = new MaskedCaseDto();
            maskedCaseDto.CaseNumber = titanCaseNumber;
            maskedCaseDto.GaCaseId = gaCaseId;            
            maskedCaseDto.MessageId = Guid.NewGuid().ToString();
            maskedCaseDto.MessageType = "MaskedCase";

            _workUnitManager.CreateWorkUnit(WorkUnitType.TibcoPostToGA, JsonConvert.SerializeObject(maskedCaseDto).ToString(), TimeSpan.FromSeconds(45));

            Log.TraceFormat("+MaskedCaseManger-CreateMaskedCaseGARequest()");

        }
    }
}
