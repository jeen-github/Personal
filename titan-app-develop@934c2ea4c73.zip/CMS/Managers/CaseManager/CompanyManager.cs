﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Interfaces.Common;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Exceptions;
using Guardian.Core.Entities.Product.Enums;
using Guardian.Core.Entities.Product.Enums.EnumExtensions;
using Logger.Static;

namespace CMS.Managers.CaseManagers
{
    public class CompanyManager : ICompanyManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public CompanyManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public int? SaveEmployerClient(CompanyDto request)
        {
            Log.TraceFormat("+SaveCompanyInformation");
            int? companyId = null;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var company = unitOfWork.Repository<Company>().Linq().FirstOrDefault(c => c.Id == request.CompanyId);
                if (company == null)
                {
                    company = new Company();
                }
                company.EmployerClientId = request.EmployerClientId;
                unitOfWork.Repository<Company>().Save(company);
                companyId = company.Id;
                unitOfWork.Commit();
            }            
            Log.TraceFormat("-SaveCompanyInformation");
            return companyId;
        }

        public string GenerateEmployerClientNumber()
        {
            Log.TraceFormat("+GenerateEmployerClientNumber");

            int? employerClientNumberId = null;
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    employerClientNumberId = unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_GetEmployerClientNumber]").FirstOrDefault();
                    unitOfWork.Commit();
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR generating a new employer client number", ex);
                throw;
            }

            if (employerClientNumberId == null) throw new BusinessException("Error", "Null employer client number generated!");

            string employerClientNumber = string.Format("EC{0}", employerClientNumberId);
            Log.TraceFormat("New employer client number generate={0}", employerClientNumber);

            Log.TraceFormat("-GenerateEmployerClientNumber");
            return employerClientNumber;
        }
    }
}
