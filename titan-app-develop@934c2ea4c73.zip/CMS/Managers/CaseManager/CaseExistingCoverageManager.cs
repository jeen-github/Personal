﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using System.Linq;

namespace CMS.Managers.CaseManagers
{
    public class CaseExistingCoverageManager : ICaseExistingCoverageManager
    {
        public IUnitOfWorkFactory _unitOfWorkFactory { get; set; }
        private readonly CaseExistingCoverageValidator _caseExistingCoverageValidator;

        public CaseExistingCoverageManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _caseExistingCoverageValidator = new CaseExistingCoverageValidator();
        }

        public ExistingCoverageDto GetExistingCoverageByCaseId(int caseId)
        {
            Log.TraceFormat("+GetExistingCoverageByCaseId caseId={0}", caseId);
            var existingCoverageDto = new ExistingCoverageDto();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                

                var cmsExistingCoverageCase = unitOfWork.Repository<ExistingCoverage>().Linq().OrderByDescending(x=>x.Id).FirstOrDefault(c => c.Case.Id == caseId);
                if (cmsExistingCoverageCase == null)
                {
                    existingCoverageDto.CaseId = caseId;
                }
                else
                {
                    existingCoverageDto.Id = cmsExistingCoverageCase.Id;
                    existingCoverageDto.CaseId = cmsExistingCoverageCase.Case.Id;
                    existingCoverageDto.IsExistingGuranteedIssueCoverageIndicator = cmsExistingCoverageCase.IsExistingGuranteedIssueCoverageIndicator;
                    existingCoverageDto.ExistingIndividualDisabilityCoverageTypeId = cmsExistingCoverageCase.ExistingIndividualDisabilityCoverageType != null ? (int?)cmsExistingCoverageCase.ExistingIndividualDisabilityCoverageType.Id : null;
                    existingCoverageDto.ExistingIndividualDisabilityEligiblePopulation = cmsExistingCoverageCase.ExistingIndividualDisabilityEligiblePopulation;
                    existingCoverageDto.GSIAmount = cmsExistingCoverageCase.GSIAmount;
                    existingCoverageDto.LastTimeEnrolled = cmsExistingCoverageCase.LastTimeEnrolled;
                    existingCoverageDto.ExistingIndividualDisabilityPremiumPayerTypeId = cmsExistingCoverageCase.ExistingIndividualDisabilityPremiumPayerType != null ? (int?)cmsExistingCoverageCase.ExistingIndividualDisabilityPremiumPayerType.Id : null;
                    existingCoverageDto.ExistingIndividualDisabilityReasonOutMarketTypeId = cmsExistingCoverageCase.ExistingIndividualDisabilityReasonOutMarketType != null ? (int?)cmsExistingCoverageCase.ExistingIndividualDisabilityReasonOutMarketType.Id : null;
                    existingCoverageDto.ReasonOutMarketTypeOther = cmsExistingCoverageCase.ReasonOutMarketTypeOther;
                    existingCoverageDto.ReasonOutMarketTypeDate = cmsExistingCoverageCase.ReasonOutMarketTypeDate;
                    existingCoverageDto.ExistingIndividualDisabilityAdditionalDetailsText = cmsExistingCoverageCase.ExistingIndividualDisabilityAdditionalDetailsText;
                    existingCoverageDto.ColoradoReplacementTypeId = cmsExistingCoverageCase.ColoradoReplacementType != null ? (int?)cmsExistingCoverageCase.ColoradoReplacementType : null;
                    existingCoverageDto.ColoradoReplacementOther = cmsExistingCoverageCase.ColoradoReplacementOther;
                    existingCoverageDto.FloridaReplacementCompanyName = cmsExistingCoverageCase.FloridaReplacementCompanyName;
                    existingCoverageDto.FloridaReplacementCompanyAddressLine1 = cmsExistingCoverageCase.FloridaReplacementCompanyAddressLine1;
                    existingCoverageDto.FloridaReplacementCompanyAddressLine2 = cmsExistingCoverageCase.FloridaReplacementCompanyAddressLine2;
                    existingCoverageDto.FloridaReplacementCompanyCity = cmsExistingCoverageCase.FloridaReplacementCompanyCity;
                    existingCoverageDto.FloridaReplacementCompanyStateTypeId = (int?)cmsExistingCoverageCase.FloridaReplacementCompanyStateType;
                    existingCoverageDto.FloridaReplacementCompanyZipCode = cmsExistingCoverageCase.FloridaReplacementCompanyZipCode;
                    existingCoverageDto.EmployerOwned = cmsExistingCoverageCase.EmployerOwned;
                }
            }
            Log.TraceFormat("-GetExistingCoverageByCaseId");
            return existingCoverageDto;
        }
        public int SaveExistingCoverage(ExistingCoverageDto request, bool isRequestComingFromGA)
        {
            Log.TraceFormat("+SaveExistingCoverage");
            int existingCoverageId = 0;
            if(!isRequestComingFromGA)
                _caseExistingCoverageValidator.ValidateCaseExistingCoverageData(request);
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsExistingCoverage = unitOfWork.Repository<ExistingCoverage>().Linq().FirstOrDefault(c => c.Id == request.Id);
                if (cmsExistingCoverage == null)
                {
                    cmsExistingCoverage = new ExistingCoverage();
                    cmsExistingCoverage.Case = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                }
                cmsExistingCoverage.IsExistingGuranteedIssueCoverageIndicator = request.IsExistingGuranteedIssueCoverageIndicator;
                cmsExistingCoverage.ExistingIndividualDisabilityCoverageType = unitOfWork.Repository<ExistingIndividualDisabilityCoverageType>().Linq().FirstOrDefault(c => c.Id == request.ExistingIndividualDisabilityCoverageTypeId);
                cmsExistingCoverage.ExistingIndividualDisabilityEligiblePopulation = request.ExistingIndividualDisabilityEligiblePopulation;
                cmsExistingCoverage.GSIAmount = request.GSIAmount;
                cmsExistingCoverage.LastTimeEnrolled = request.LastTimeEnrolled;
                cmsExistingCoverage.ExistingIndividualDisabilityPremiumPayerType = unitOfWork.Repository<ExistingIndividualDisabilityPremiumPayerType>().Linq().FirstOrDefault(c => c.Id == request.ExistingIndividualDisabilityPremiumPayerTypeId);
                cmsExistingCoverage.ExistingIndividualDisabilityReasonOutMarketType = unitOfWork.Repository<ExistingIndividualDisabilityReasonOutMarketType>().Linq().FirstOrDefault(c => c.Id == request.ExistingIndividualDisabilityReasonOutMarketTypeId);
                cmsExistingCoverage.ReasonOutMarketTypeOther = request.ReasonOutMarketTypeOther;
                cmsExistingCoverage.ReasonOutMarketTypeDate = request.ReasonOutMarketTypeDate;
                cmsExistingCoverage.ExistingIndividualDisabilityAdditionalDetailsText = request.ExistingIndividualDisabilityAdditionalDetailsText;
                cmsExistingCoverage.ColoradoReplacementType = (ColoradoReplacementTypeEnum?)request.ColoradoReplacementTypeId;
                cmsExistingCoverage.ColoradoReplacementOther = request.ColoradoReplacementOther;
                cmsExistingCoverage.FloridaReplacementCompanyName = request.FloridaReplacementCompanyName;
                cmsExistingCoverage.FloridaReplacementCompanyAddressLine1 = request.FloridaReplacementCompanyAddressLine1;
                cmsExistingCoverage.FloridaReplacementCompanyAddressLine2 = request.FloridaReplacementCompanyAddressLine2;
                cmsExistingCoverage.FloridaReplacementCompanyCity = request.FloridaReplacementCompanyCity;
                cmsExistingCoverage.FloridaReplacementCompanyStateType = (StateTypeEnum?)request.FloridaReplacementCompanyStateTypeId;
                cmsExistingCoverage.FloridaReplacementCompanyZipCode = request.FloridaReplacementCompanyZipCode;
                cmsExistingCoverage.EmployerOwned = request.EmployerOwned;

                unitOfWork.Repository<ExistingCoverage>().Save(cmsExistingCoverage);

                unitOfWork.Commit();
                existingCoverageId = cmsExistingCoverage.Id;
            }
            Log.TraceFormat("-SaveExistingCoverage");
            return existingCoverageId;
        }

    }
}
