﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers;
using CMS.Interfaces.Managers.CaseManagers;
using Logger.Static;
using Common.Exceptions;
using CMS.Model.Entities;
using System.Text.RegularExpressions;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.CaseManagers
{
    public class CaseCompanyValidator
    {

        public void ValidateCaseCompanyData(CaseDto caseDto)
        {
            Log.TraceFormat("+ValidateCaseCompanyData");

            var errorMessages = new List<string>();

            ValidateCompanyName(caseDto, errorMessages);

            ValidateCompanyZipCode(caseDto, errorMessages);

            ValidateCompanyNatureOfBusiness(caseDto, errorMessages);

            ValidateCompanyWebAddress(caseDto, errorMessages);

            ValidateCaseCompanyLocations(caseDto, errorMessages);

            Log.TraceFormat("-ValidateCaseCompanyData");

            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }

        public void ValidateCaseCompanyLocations(CaseDto caseDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateCaseCompanyLocations");

            if (caseDto.CaseCompanyLocations != null && caseDto.CaseCompanyLocations.Count > 0)
            {
                bool result = caseDto.CaseCompanyLocations.Any(t => t.CompanyLocationTypeId != (int?)null);
                if (!result)
                {
                    errorMessages.Add("Atleast one Location Type should be selected");
                }
            }

            Log.TraceFormat("-ValidateCaseCompanyLocations");
        }

        public void ValidateCompanyWebAddress(CaseDto caseDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateCompanyWebAddress");

            if (!string.IsNullOrEmpty(caseDto.CompanyWebAddress))
            {
                bool result = false;
                var url = caseDto.CompanyWebAddress;
                if (url.ToLower().StartsWith("www."))
                {
                    url = "http://" + url;
                }
                Uri uriResult;
                result = Uri.TryCreate(url, UriKind.Absolute, out uriResult)
                    && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);

                if (!result) errorMessages.Add("Please provide a valid Web address");
            }

            Log.TraceFormat("-ValidateCompanyWebAddress");
        }

        public void ValidateCompanyNatureOfBusiness(CaseDto caseDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateCompanyNatureOfBusiness");

            if (!string.IsNullOrEmpty(caseDto.CompanyNatureOfBusiness))
            {
                if (caseDto.CompanyNatureOfBusiness.Length > 50) errorMessages.Add("Company Nature of Business length should be no more than 50");
                bool isValidString = IsAllowedCharacter(caseDto.CompanyNatureOfBusiness);
                Log.DebugFormat("isValidCompanyNatureOfBusiness={0}", isValidString);
                if (!isValidString) errorMessages.Add("Company Nature of Business is invalid");
            }

            Log.TraceFormat("-ValidateCompanyNatureOfBusiness");
        }

        public void ValidateCompanyZipCode(CaseDto caseDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateCompanyZipCode");

            if (!string.IsNullOrEmpty(caseDto.CompanyZipCode))
            {
                bool isUsZipCode = IsUsZipCode(caseDto.CompanyZipCode);
                Log.DebugFormat("IsUsZipCode={0}", isUsZipCode);
                if (!isUsZipCode) errorMessages.Add("Company Zip Code is invalid");
            }

            Log.TraceFormat("-ValidateCompanyZipCode");
        }

        public void ValidateCompanyName(CaseDto caseDto, List<string> errorMessages)
        {
            Log.TraceFormat("+ValidateCompanyName");

            if (string.IsNullOrEmpty(caseDto.CompanyName)) errorMessages.Add("Company name is required");

            else if (caseDto.CompanyName.Length > 55) errorMessages.Add("Company name length should be no more than 55");

            Log.TraceFormat("-ValidateCompanyName");
        }

        private bool IsUsZipCode(string zipCode)
        {
            Log.TraceFormat("+IsUsZipCode");

            bool validZipCode = false;
            string _usZipRegEx = @"^\d{5}(?:[-\s]\d{4})?$";
            if (Regex.Match(zipCode, _usZipRegEx).Success)
            {
                validZipCode = true;
            }

            Log.TraceFormat("-IsUsZipCode");

            return validZipCode;
        }

        private bool IsAllowedCharacter(string strInput)
        {
            Log.TraceFormat("+IsAllowedCharacter");

            bool validString = false;
            string _allowedCharacters = @"^[ A-Za-z0-9‘’“”!#$%&‘()*+,-./:;<=>?@\–—¢£]*$";
            if (Regex.Match(strInput, _allowedCharacters).Success)
            {
                validString = true;
            }
            Log.TraceFormat("-IsAllowedCharacter");
            return validString;
        }
    }
}
