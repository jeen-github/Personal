﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers;
using CMS.Interfaces.Managers.CaseManagers;
using Logger.Static;
using Common.Exceptions;
using CMS.Model.Entities;
using System.Text.RegularExpressions;
using Guardian.Core.Entities.Product.Enums;
namespace CMS.Managers.CaseManagers
{
    public class CaseBrokerManagerValidator
    {
        public void ValidateCaseBrokertData(BrokerDto brokerDto)
        {
            Log.TraceFormat("+ValidateCaseBrokertData");

            var errorMessages = new List<string>();

            ValidatePrimaryProducer(errorMessages, brokerDto);
            ValidateTotalPercentage(errorMessages, brokerDto);
            ValidateSubProducerHavingPrimaryProducer(errorMessages, brokerDto);
            ValidateSubProducerHavingStatePercentage(errorMessages, brokerDto);

            if (errorMessages.Any()) throw new ValidationException(errorMessages);

            Log.TraceFormat("-ValidateCaseBrokertData");
        }
        public void ValidateTotalPercentage(List<string> errorMessages, BrokerDto brokerDto)
        {
            Log.TraceFormat("+ValidateTotalPercentage");

            if (brokerDto.CaseBrokers != null && brokerDto.CaseBrokers.Count > 0)
            {
                var caseBrokerStates = brokerDto.CaseBrokers.SelectMany(c => c.CaseBrokerStates);
                if (caseBrokerStates != null)
                {
                    IList<CaseBrokerStateDto> states = (from st in caseBrokerStates
                                                        group st by new { st.StateTypeId, st.StateTypeName } into grp
                                                        select new CaseBrokerStateDto
                                                        {
                                                            StateTypeId = grp.Key.StateTypeId,
                                                            StateTypeName = grp.Key.StateTypeName,
                                                            CommisionPercentage = grp.Sum(x => x.CommisionPercentage ?? 0)
                                                        }).ToList();

                    string statesError = string.Join(", ", states.Where(t => t.CommisionPercentage != 100).Select(c => c.StateTypeName));
                    if (!string.IsNullOrEmpty(statesError))
                    {
                        errorMessages.Add("Please verify the State Percentages for (" + statesError + ").");
                    }
                }
            }

            Log.TraceFormat("-ValidateTotalPercentage");
        }

        public void ValidatePrimaryProducer(List<string> errorMessages, BrokerDto brokerDto)
        {
            Log.TraceFormat("+ValidatePrimaryProducer");

            if (brokerDto.CaseBrokers != null && brokerDto.CaseBrokers.Count > 0)
            {
                var validBrokers = brokerDto.CaseBrokers.Where(i => i.BrokerWritingCode != null && i.BrokerWritingCode.Length == 8);
                if (validBrokers != null)
                {
                    var caseBrokerStates = validBrokers.SelectMany(c => c.CaseBrokerStates);
                    if (caseBrokerStates != null)
                    {
                        IList<CaseBrokerStateDto> states = (from st in caseBrokerStates
                                                            group st by new { st.StateTypeId, st.StateTypeName } into grp
                                                            select new CaseBrokerStateDto
                                                            {
                                                                StateTypeId = grp.Key.StateTypeId,
                                                                StateTypeName = grp.Key.StateTypeName,
                                                                PrimaryBrokerCount = grp.Count(x => x.IsPrimaryBrokerIndicator ?? false)
                                                            }).ToList();

                        string statesError = string.Join(", ", states.Where(t => t.PrimaryBrokerCount > 1 || t.PrimaryBrokerCount == 0 ).Select(c => c.StateTypeName));
                        if (!string.IsNullOrEmpty(statesError))
                        {
                            errorMessages.Add("Please verify Primary Producer selection for (" + statesError + ").");
                        }
                    }
                }
            }

            Log.TraceFormat("-ValidatePrimaryProducer");
        }

        public void ValidateSubProducerHavingPrimaryProducer(List<string> errorMessages, BrokerDto brokerDto)
        {
            Log.TraceFormat("+ValidateSubProducerHavingPrimaryProducer");

            if (brokerDto.CaseBrokers != null && brokerDto.CaseBrokers.Count > 0)
            {
                var validSubProducers = brokerDto.CaseBrokers.Where(i => i.BrokerWritingCode!= null &&  i.BrokerWritingCode.Length > 8);
                if (validSubProducers != null)
                {
                    var caseBrokerStates = validSubProducers.SelectMany(c => c.CaseBrokerStates);
                    if (caseBrokerStates != null)
                    {

                        IList<CaseBrokerStateDto> states = (from st in caseBrokerStates
                                                            group st by new { st.StateTypeId, st.StateTypeName } into grp
                                                            select new CaseBrokerStateDto
                                                            {
                                                                StateTypeId = grp.Key.StateTypeId,
                                                                StateTypeName = grp.Key.StateTypeName,
                                                                PrimaryBrokerCount = grp.Count(x => x.IsPrimaryBrokerIndicator ?? false)
                                                            }).ToList();

                        string statesError = string.Join(", ", states.Where(t => t.PrimaryBrokerCount != 0).Select(c => c.StateTypeName));
                        string subProducerNameError = string.Join(", ", validSubProducers.Where(t => t.BrokerWritingCode.Length > 8).Select(c => c.BrokerName));
                        if (!string.IsNullOrEmpty(statesError))
                        {
                            errorMessages.Add("Sub Producer (" + subProducerNameError + ") is listed as Primary Producer for (" + statesError + ").");
                        }
                    }
                }
            }

            Log.TraceFormat("-ValidateSubProducerHavingPrimaryProducer");
        }

        public void ValidateSubProducerHavingStatePercentage(List<string> errorMessages, BrokerDto brokerDto)
        {
            Log.TraceFormat("+ValidateSubProducerHavingStatePercentage");

            if (brokerDto.CaseBrokers != null && brokerDto.CaseBrokers.Count > 0)
            {
                var validSubProducers = brokerDto.CaseBrokers.Where(i => i.BrokerWritingCode != null && i.BrokerWritingCode.Length > 8);
                if (validSubProducers != null)
                {
                    var caseBrokerStates = validSubProducers.SelectMany(c => c.CaseBrokerStates);
                    if (caseBrokerStates != null)
                    {
                        IList<CaseBrokerStateDto> states = (from st in caseBrokerStates
                                                            group st by new { st.StateTypeId, st.StateTypeName } into grp
                                                            select new CaseBrokerStateDto
                                                            {
                                                                StateTypeId = grp.Key.StateTypeId,
                                                                StateTypeName = grp.Key.StateTypeName,
                                                                CommisionPercentage = grp.Sum(x => x.CommisionPercentage ?? 0)
                                                            }).ToList();

                        string statesError = string.Join(", ", states.Where(t => t.CommisionPercentage > 0).Select(c => c.StateTypeName));
                        string subProducerNameError = string.Join(", ", validSubProducers.Where(t => t.BrokerWritingCode.Length > 8).Select(c => c.BrokerName));
                        if (!string.IsNullOrEmpty(statesError))
                        {
                            errorMessages.Add("Sub Producer (" + subProducerNameError + ") is listed with a Percentage for (" + statesError + ").");
                        }
                    }
                }
            }

            Log.TraceFormat("+ValidateSubProducerHavingStatePercentage");
        }
    }
}
