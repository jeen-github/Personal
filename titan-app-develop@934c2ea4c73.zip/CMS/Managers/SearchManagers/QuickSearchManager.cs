﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.QuickSearchManagers;
using CMS.Model.Entities;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using CMS.Interfaces.Managers.SecurityManagers;
using System.Text;

namespace CMS.Managers.SearchManagers
{
    public class QuickSearchManager : IQuickSearch
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly ISecurityManager _securityManager;

        public QuickSearchManager(IUnitOfWorkFactory unitOfWorkFactory, ISecurityManager securityManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _securityManager = securityManager;
        }

        public List<QuickSearchDto> QuickSearch(string searchText, string searchfield, string ldapUserId)
        {
            Log.TraceFormat("+QuickSearch");

            List<QuickSearchDto> quickSearchResults = new List<QuickSearchDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                Expression<Func<Case, bool>> quickSearchQuery = null;

                if (searchfield == "Case number")
                {
                    quickSearchQuery = c => c.CaseNumber.Contains(searchText);
                }
                else if (searchfield == "Company")
                {
                    quickSearchQuery = c => c.CompanyName.Contains(searchText);
                }
                else if (searchfield == "Producer")
                {
                    quickSearchQuery = c => c.CaseBrokers.Where(cb => cb.BrokerName.Contains(searchText)).Count() > 0;
                }

                var cmsCases = GetCaseResultsBasedOnConfidentialUserGroups(ldapUserId, quickSearchQuery, unitOfWork);

                if (cmsCases.Any())
                {
                    quickSearchResults = cmsCases.Select(c => new QuickSearchDto
                    {
                        CaseId = c.Id,
                        CaseNumber = c.CaseNumber,
                        CompanyName = c.CompanyName,
                        CompanyNumber = c.Company.EmployerClientId,
                        Producers = GetProducerNames(c.CaseBrokers),
                        Wholesalers = GetWholesalerNames(c.CaseWholesalers),
                    }).ToList();
                }

            }
            Log.TraceFormat("-QuickSearch");
            return quickSearchResults;
        }

        private string GetProducerNames(IList<CaseBroker> caseBrokers)
        {
            string producer = string.Empty;

            StringBuilder strProducer = new StringBuilder();
            if (caseBrokers.Any())
            {
                foreach (var broker in caseBrokers)
                {
                    if (!string.IsNullOrEmpty(broker.BrokerName))
                    {
                        strProducer.Append(" " + broker.BrokerName.Replace(",", "")).Append(",");
                    }
                }
            }

            producer = strProducer != null ? strProducer.ToString().TrimEnd(',') : string.Empty;

            return producer;
        }

        private string GetWholesalerNames(IList<CaseWholesaler> caseWholesalers)
        {
            string wholesaler = string.Empty;

            StringBuilder strWholesalers = new StringBuilder();
            if (caseWholesalers.Any())
            {
                foreach (var cw in caseWholesalers)
                {
                    var wholesalerRegionName = cw.WholesalerRegion != null ? cw.WholesalerRegion.RegionName : string.Empty;                  
                    var externalWholesaler = cw.ExternalWholesaler != null ? cw.ExternalWholesaler.LastName + " " + cw.ExternalWholesaler.FirstName : string.Empty;
                    strWholesalers.Append(" " + externalWholesaler).Append(" - " + wholesalerRegionName).Append(",");
                }
            }

            wholesaler = strWholesalers != null ? strWholesalers.ToString().TrimEnd(',') : string.Empty;

            return wholesaler;
        }

        private IQueryable<Case> GetCaseResultsBasedOnConfidentialUserGroups(string ldapUserId, Expression<Func<Case, bool>> quickSearchQuery, IUnitOfWork unitOfWork)
        {
            List<int> userGroupIds = new List<int>();

            var cmsCases = unitOfWork.Repository<Case>().Linq().Where(quickSearchQuery);

            var userGroups = _securityManager.GetUserGroups(ldapUserId);
            if (userGroups != null)
            {
                userGroupIds = userGroups.Select(c => c.Id).Distinct().ToList();
            }

            var confidentialCaseUserGroups = _securityManager.GetConfidentialCaseUserGroup().Where(c => c.IsActiveIndicator);

            var filteredConfidentialUserGroups = confidentialCaseUserGroups.Where(c => userGroupIds.Contains(c.UserGroupId)).ToList();
            if (filteredConfidentialUserGroups.Any())
            {
                //Continue
            }
            else
            {
                var confidentialCases = cmsCases.Where(c => c.IsConfidentialCaseIndicator != null && c.IsConfidentialCaseIndicator == true).Select(c => c.Id).ToList();

                if (confidentialCases.Any())
                {
                    var cmsTasks = unitOfWork.Repository<CmsTask>().Linq().Where(c => confidentialCases.Contains(c.Case.Id)
                    && c.AssignedToUser != null && c.AssignedToUser.LdapUserName == ldapUserId);

                    if (!cmsTasks.Any())
                    {
                        var otherCases = cmsCases.Where(c => c.IsConfidentialCaseIndicator == null || c.IsConfidentialCaseIndicator == false);
                        cmsCases = otherCases.Where(quickSearchQuery);
                    }

                }
                else
                {
                    var otherCases = cmsCases.Where(c => c.IsConfidentialCaseIndicator == null || c.IsConfidentialCaseIndicator == false);
                    cmsCases = otherCases.Where(quickSearchQuery);
                }
            }
            return cmsCases;
        }
    }
}
