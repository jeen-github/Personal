﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.LookupManagers;
using CMS.Interfaces.Managers.OccupationClassAssignmentManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CMS.Managers.OccupationClassAssignmentManagers
{
    public class OccupationClassAssignmentManager : IOccupationClassAssignmentManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly ILookupManager _lookupManager;
        private static List<OccupationCode> occupationCodes;
        private static List<SICCodeOccupationClass> occupationClasses;
        private static int? _8721;

        public OccupationClassAssignmentManager(IUnitOfWorkFactory unitOfWorkFactory, ILookupManager lookUpManager)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _lookupManager = lookUpManager;
        }

        private void IntializeOccCodes()
        {
            if (occupationCodes == null || occupationClasses == null || _8721 == null)
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    occupationCodes = unitOfWork.Repository<OccupationCode>().Linq().ToList();
                    occupationClasses = unitOfWork.Repository<SICCodeOccupationClass>().Linq().ToList();
                }
                var companySicSubGroupType = _lookupManager.GetValues<CompanySicSubGroupType>().FirstOrDefault(cSicSub => cSicSub.Code == "8721");
                if (companySicSubGroupType != null)
                {
                    _8721 = companySicSubGroupType.Id;
                }
            }
        }

        public OccupationClassAssignmentResponse GetOccupationClass(OccupationClassAssignmentRequest request)
        {
            IntializeOccCodes();
            var occupationClassAssignmentResponse = new OccupationClassAssignmentResponse();
            //Log.TraceFormat("+GetOccupationClass");
            var keyAlwaysOccs = occupationClasses.Where(oc => oc.CompanySicMajorGroupType == null && oc.CompanySicSubGroupType == null && oc.IsEligible);
            var keyOccupation = keyAlwaysOccs.FirstOrDefault(keyOcc => keyOcc?.OccupationCode?.OccCode == request.CLOASOccupationCode && keyOcc?.OccupationCode?.Occupation == request.Occupation);

            if (keyOccupation == null)
            {
                //B-06554
                if (request.CompanySicMajorGroupId != null)
                {
                    IList<SICCodeOccupationClass> occupations = new List<SICCodeOccupationClass>();
                    //8721
                    if (request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0087 && request.CompanySicSubGroupId == _8721)
                    {
                        occupations = occupationClasses.Where(oc => oc.CompanySicMajorGroupType != null && oc.CompanySicMajorGroupType.Id == request.CompanySicMajorGroupId && oc.CompanySicSubGroupType != null && oc.CompanySicSubGroupType.Id == _8721).ToList();
                    }
                    else if (request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0087)
                    {
                        occupations = occupationClasses.Where(oc => oc.CompanySicMajorGroupType != null && oc.CompanySicMajorGroupType.Id == request.CompanySicMajorGroupId && oc.CompanySicSubGroupType == null).ToList();
                    }
                    else
                    {
                        occupations = occupationClasses.Where(oc => oc.CompanySicMajorGroupType != null && oc.CompanySicMajorGroupType.Id == request.CompanySicMajorGroupId).ToList();
                    }

                    var occupation = occupations.FirstOrDefault(keyOcc => keyOcc.OccupationCode.OccCode == request.CLOASOccupationCode);
                    if (occupation == null)
                    {
                        if (request.CLOASOccupationCode != null)
                        {
                            if (request.CLOASOccupationCode.ToUpper() == "PHYS" || request.CLOASOccupationCode.ToUpper() == "MD"
                                || request.CLOASOccupationCode.ToUpper() == "INTST" || request.CLOASOccupationCode.ToUpper() == "ENTMG")
                            {
                                occupation = new SICCodeOccupationClass();
                                occupation.IsEligible = true;
                                occupation.OccupationClassType = OccupationClassTypeEnum._4M;
                            }
                            else if (request.CLOASOccupationCode.ToUpper() == "ERPHYS" || request.CLOASOccupationCode.ToUpper() == "SURGN"
                                || request.CLOASOccupationCode.ToUpper() == "GENSR" || request.CLOASOccupationCode.ToUpper() == "ERPHY")
                            {
                                occupation = new SICCodeOccupationClass();
                                occupation.IsEligible = true;
                                occupation.OccupationClassType = OccupationClassTypeEnum._3M;
                            }
                            else if (request.CLOASOccupationCode.ToUpper() == "MANUF")
                            {
                                occupation = new SICCodeOccupationClass();
                                occupation.IsEligible = true;
                                occupation.OccupationClassType = OccupationClassTypeEnum._3;
                            }
                        }
                    }
                    if (occupation == null)
                    {
                        //B-06556
                        if (request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0064
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0065)
                        {
                            if (request.IDIInsurableIncomeAmount < 100000)
                            {
                                occupation = new SICCodeOccupationClass();
                                occupation.OccupationClassType = OccupationClassTypeEnum._4;
                            }
                            else if (request.IDIInsurableIncomeAmount >= 200000)
                            {
                                occupation = new SICCodeOccupationClass();
                                occupation.OccupationClassType = OccupationClassTypeEnum._6;
                            }
                            else if (100000 <= request.IDIInsurableIncomeAmount && request.IDIInsurableIncomeAmount < 200000)
                            {
                                occupation = new SICCodeOccupationClass();
                                occupation.OccupationClassType = OccupationClassTypeEnum._5;
                            }
                        }
                        else if (request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0081)
                        {
                            occupation = new SICCodeOccupationClass();
                            occupation.OccupationClassType = OccupationClassTypeEnum._4;
                        }
                        //8721 case
                        else if (request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0087 && request.CompanySicSubGroupId == _8721)
                        {
                            occupation = new SICCodeOccupationClass();
                            occupation.OccupationClassType = OccupationClassTypeEnum._4;
                        }
                        else if (request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0080
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0083)
                        {
                            if ((request.PremiumPayerandTaxability == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid || request.PremiumPayerandTaxability == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                                && request.ClassParticipantCount > 30)
                            {
                                if (request.IDIInsurableIncomeAmount < 75000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._4;
                                }
                                else if (request.IDIInsurableIncomeAmount >= 100000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._6;
                                }
                                else if (75000 <= request.IDIInsurableIncomeAmount && request.IDIInsurableIncomeAmount < 100000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._5;
                                }
                            }
                            else
                            {
                                if (request.IDIInsurableIncomeAmount < 100000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._4;
                                }
                                else if (request.IDIInsurableIncomeAmount >= 175000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._6;
                                }
                                else if (100000 <= request.IDIInsurableIncomeAmount && request.IDIInsurableIncomeAmount < 175000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._5;
                                }
                            }
                        }
                        else if (request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0020
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0021
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0022
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0023
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0024
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0025
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0026
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0027
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0028
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0029
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0030
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0031
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0032
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0033
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0034
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0035
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0036
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0037
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0038
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0039
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0050
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0051
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0052
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0053
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0054
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0055
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0056
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0057
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0058
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0059
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0060
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0061
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0062
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0063
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0067
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0070
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0072
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0073
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0082
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0084
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0086
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0087
                            || request.CompanySicMajorGroupId == (int)CompanySicMajorGroupTypeEnum._0089)
                        {
                            if ((request.PremiumPayerandTaxability == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid || request.PremiumPayerandTaxability == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.CostShare)
                                && request.ClassParticipantCount > 30)
                            {
                                if (request.IDIInsurableIncomeAmount < 75000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._4;
                                }
                                else if (request.IDIInsurableIncomeAmount >= 100000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._6;
                                }
                                else if (75000 <= request.IDIInsurableIncomeAmount && request.IDIInsurableIncomeAmount < 100000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._5;
                                }
                            }
                            else
                            {
                                if (request.IDIInsurableIncomeAmount < 100000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._4;
                                }
                                else if (request.IDIInsurableIncomeAmount >= 150000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._6;
                                }
                                else if (100000 <= request.IDIInsurableIncomeAmount && request.IDIInsurableIncomeAmount < 150000)
                                {
                                    occupation = new SICCodeOccupationClass();
                                    occupation.OccupationClassType = OccupationClassTypeEnum._5;
                                }
                            }
                        }
                    }

                    else if (occupation.IsEligible == false)
                    {
                        occupationClassAssignmentResponse.IsEligible = false;
                        occupationClassAssignmentResponse.InEligibleReason = "Job Duties";
                    }


                    if (occupation == null && keyOccupation != null)
                    {
                        occupation = new SICCodeOccupationClass();
                        occupation.OccupationClassType = keyOccupation.OccupationClassType;
                    }

                    if (occupation != null && occupation.OccupationClassType != null)
                    {
                        //B-06557
                        occupationClassAssignmentResponse.OccupationClass = CommissionBasedAdjustment(request, occupation);
                    }
                }
            }
            else
            {
                //B-06557
                occupationClassAssignmentResponse.OccupationClass = CommissionBasedAdjustment(request, keyOccupation);
            }
            //Log.TraceFormat("-GetOccupationClass");
            return occupationClassAssignmentResponse;
        }

        private OccupationClassTypeEnum? CommissionBasedAdjustment(OccupationClassAssignmentRequest request, SICCodeOccupationClass occupation)
        {
            //Log.TraceFormat("+CommissionBasedAdjustment");
            if (occupation.OccupationClassType == OccupationClassTypeEnum._5M
                                        || occupation.OccupationClassType == OccupationClassTypeEnum._6
                                        || occupation.OccupationClassType == OccupationClassTypeEnum._6M)
            {
                if ((request.MostRecentPaidCommissionAmount.HasValue && request.MostRecentPaidCommissionAmount.Value > 0) || (request.PriorPaidCommissionAmount.HasValue && request.PriorPaidCommissionAmount.Value > 0))
                {
                    return OccupationClassTypeEnum._5;
                }
            }

            //Log.TraceFormat("-CommissionBasedAdjustment");

            return occupation.OccupationClassType;
        }

        /*
        The code determines the occupation based on the ParticipantJobTitle in the following order:

        1. Matches specific starting strings ("vascu", "surg", "opht", "evp", "svp", "avp", "vp", "mgr") to corresponding OccCodes ("GENSR", "SURGN", "OPHTH", "VP", "MGR").
        2. Matches specific contained strings ("surg", "orthop", "-peds ") to corresponding OccCodes ("SURGN", "ORTHO", "PDTRN").
        3. Matches the exact ParticipantJobTitle to Occupation.
        4. Matches any word in ParticipantJobTitle to any of the CommonAbbreviations.
        5. Matches the exact ParticipantJobTitle to CommonAbbreviations.
        6. Matches ParticipantJobTitle containing or contained in Occupation.
        7. Matches ParticipantJobTitle contained in CommonAbbreviations.

        If no match is found, an error is set indicating that the occupation was not found. If a match is found, the OccCode and Occupation are set in the response. 
        If Occupation and CLOASOccupationCode were provided in the request, they are directly set in the response without any checks.
        */

        public OccupationClassAssignmentResponse GetCLOASOccupationCode(OccupationClassAssignmentRequest request)
        {
            Log.TraceFormat("+GetOccupationCode");

            bool isOccCodeMatchFound = false;
            OccupationClassAssignmentResponse occupationClassAssignmentResponse = new OccupationClassAssignmentResponse();
            OccupationCode occupation = null;

            if (request == null)
            {
                occupationClassAssignmentResponse.IsError = true;
                occupationClassAssignmentResponse.ErrorReason = "Occupation Not Found.";
                return occupationClassAssignmentResponse;
            }

            if (string.IsNullOrEmpty(request.ParticipantJobTitle) && string.IsNullOrEmpty(request.Occupation))
            {
                occupationClassAssignmentResponse.IsError = true;
                occupationClassAssignmentResponse.ErrorReason = "Occupation Not Found.";
                return occupationClassAssignmentResponse;
            }


            if (string.IsNullOrEmpty(request.Occupation) || string.IsNullOrEmpty(request.CLOASOccupationCode))
            {
                IntializeOccCodes();
                if (Regex.IsMatch(request.ParticipantJobTitle, @"^\d+"))
                {
                    request.ParticipantJobTitle = Regex.Replace(request.ParticipantJobTitle, @"[\d-]", " ").Trim(); // Remove down numericals, Hypen's (eg: 429-PHYSICAL MEDICINE AND REHABILITATION)
                }
                if (request.ParticipantJobTitle.ToLower().Contains("rehabilitation"))
                {
                    occupationClassAssignmentResponse.IsError = true;
                    occupationClassAssignmentResponse.ErrorReason = "Occupation Not Found.";
                    return occupationClassAssignmentResponse;
                }
                if (request.ParticipantJobTitle.ToLower().StartsWith("vascu"))
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.OccCode == "GENSR");
                }
                else if (request.ParticipantJobTitle.ToLower().StartsWith("surg") || request.ParticipantJobTitle.ToLower().Contains("surg"))
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.OccCode == "SURGN");
                }
                else if (request.ParticipantJobTitle.ToLower().StartsWith("opht"))
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.OccCode == "OPHTH");
                }
                else if (request.ParticipantJobTitle.ToLower().Contains("orthop"))
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.OccCode == "ORTHO");
                }
                else if (request.ParticipantJobTitle.ToLower() == "assistant vice president" || request.ParticipantJobTitle.ToLower().StartsWith("evp") || request.ParticipantJobTitle.ToLower().StartsWith("svp") || request.ParticipantJobTitle.ToLower().StartsWith("avp") || request.ParticipantJobTitle.ToLower().StartsWith("vp"))
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.OccCode == "VP");
                }
                else if (request.ParticipantJobTitle.ToLower().Contains("-peds "))
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.OccCode == "PDTRN");
                }
                if (occupation == null)
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.Occupation != null && oc.Occupation.Trim().ToLower() == request.ParticipantJobTitle.Trim().ToLower());
                }

                if (occupation == null)
                {

                    foreach (var occcode in occupationCodes)
                    {
                        if (isOccCodeMatchFound)
                            break;

                        if (!string.IsNullOrEmpty(occcode.CommonAbbreviations))
                        {
                            var CommonAbbreviationsList = occcode.CommonAbbreviations.Split(',');

                            foreach (var cmlist in CommonAbbreviationsList)
                            {
                                if (isOccCodeMatchFound)
                                    break;

                                var ParticipantJobTitleList = request.ParticipantJobTitle.Split(' ');

                                foreach (var title in ParticipantJobTitleList)
                                {
                                    if (title.ToLower().Trim() == cmlist.ToLower().Trim())
                                    {
                                        occupation = occcode;
                                        isOccCodeMatchFound = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }

                if (occupation == null)
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.CommonAbbreviations != null && oc.CommonAbbreviations.Split(',').ToList().Exists(ocAb => ocAb.Trim().ToLower() == request.ParticipantJobTitle.Trim().ToLower()));
                }

                if (occupation == null)
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.Occupation != null && (oc.Occupation.Trim().ToLower().Contains(request.ParticipantJobTitle.Trim().ToLower())
                                                                                                || request.ParticipantJobTitle.Trim().ToLower().Contains(oc.Occupation.Trim().ToLower())));
                }
                if (occupation == null)
                {
                    occupation = occupationCodes.FirstOrDefault(oc => oc.CommonAbbreviations != null && oc.CommonAbbreviations != string.Empty && (oc.CommonAbbreviations.Split(',').ToList().Exists(ocAb => ocAb.Trim().ToLower().Contains(request.ParticipantJobTitle.Trim().ToLower()))));
                }

                //Hardcoding the hardest JobTitle matches
                if (occupation == null)
                {

                    if (request.ParticipantJobTitle.ToLower().StartsWith("mgr"))
                    {
                        occupation = occupationCodes.FirstOrDefault(oc => oc.OccCode == "MGR");
                    }

                }
                if (occupation == null)
                {
                    occupationClassAssignmentResponse.IsError = true;
                    occupationClassAssignmentResponse.ErrorReason = "Occupation Not Found.";
                }
                else
                {
                    occupationClassAssignmentResponse.IsError = false;

                    if (string.IsNullOrEmpty(request.CLOASOccupationCode))
                    {
                        occupationClassAssignmentResponse.OccCode = occupation.OccCode;
                    }

                    if (string.IsNullOrEmpty(request.Occupation))
                    {
                        occupationClassAssignmentResponse.Occupation = occupation.Occupation;
                    }
                }
            }
            else
            {
                occupationClassAssignmentResponse.IsError = false;
                occupationClassAssignmentResponse.OccCode = request.CLOASOccupationCode;
                occupationClassAssignmentResponse.Occupation = request.Occupation;
            }

            Log.TraceFormat("-GetOccupationCode");

            return occupationClassAssignmentResponse;
        }
    }
}
