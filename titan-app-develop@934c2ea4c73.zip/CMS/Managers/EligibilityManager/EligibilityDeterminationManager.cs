﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Interfaces.Managers.BenefitAmountsCalculationManagers;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Managers.EligibilityManager.EligibilityDeterminator;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Logger.Static;
using CMS.Interfaces.Managers.BusinessManagers;
using Guardian.Core.Entities.Product.Enums;
using CMS.Interfaces.DataAccess;
using CMS.Managers.BusinessManagers.BenefitAndPremiums.Calculators;
using CMS.Interfaces.Configurations;

namespace CMS.Managers.EligibilityManager
{
    public class EligibilityDeterminationManager : IEligibilityDeterminationManager
    {
        private readonly IncreaseAgeEligibilityDeterminator _increaseAgeEligibilityDeterminator;
        private readonly AgeEligibilityDeterminator _ageEligibilityDeterminator;
        private readonly MaxGSIEligibilityDeterminator _maxGSIEligibilityDeterminator;
        private readonly EligibilityConfigurationManager _eligibilityConfigurationManager;
        private readonly MinimumInsurableIncomeLevelEligibilityDeterminator _minimumInsurableIncomeLevelEligibilityDeterminator;
        private readonly EmploymentStatusEligibilityDeterminator _employmentStatusEligibilityDeterminator;
        private readonly FullyInsuredEligibilityDeterminator _fullyInsuredEligibilityDeterminator;
        private readonly BelowMinimumGSIEligibilityDeterminator _belowMinimumGSIEligibilityDeterminator;
        private readonly MaximumSolicitationDeterminator _maximumSolicitationDeterminator;
        private readonly MinimumPolicyEligibilityDeterminator _minimumPolicyEligibilityDeterminator;
        private readonly AAWEligibilityDeterminator _AAWEligibilityDeterminator;
        private readonly CitizenshipEligibilityDeterminator _CitizenshipEligibilityDeterminator;
        private readonly SSNEligibilityDeterminator _SSNEligibilityDeterminator;
        private readonly HoursWorkedEligibilityDeterminator _HoursWorkedEligibilityDeterminator;
        

        private readonly IConfiguration _configuration;

        public EligibilityDeterminationManager(EligibilityConfigurationManager eligibilityConfigurationManager, IConfiguration configuration)
        {
            _eligibilityConfigurationManager = eligibilityConfigurationManager;
            _ageEligibilityDeterminator = new AgeEligibilityDeterminator();
            _maxGSIEligibilityDeterminator = new MaxGSIEligibilityDeterminator();
            _minimumInsurableIncomeLevelEligibilityDeterminator = new MinimumInsurableIncomeLevelEligibilityDeterminator();
            _employmentStatusEligibilityDeterminator = new EmploymentStatusEligibilityDeterminator();
            _increaseAgeEligibilityDeterminator = new IncreaseAgeEligibilityDeterminator();
            _fullyInsuredEligibilityDeterminator = new FullyInsuredEligibilityDeterminator();
            _belowMinimumGSIEligibilityDeterminator = new BelowMinimumGSIEligibilityDeterminator();
            _maximumSolicitationDeterminator = new MaximumSolicitationDeterminator();
            _minimumPolicyEligibilityDeterminator = new MinimumPolicyEligibilityDeterminator();
            _AAWEligibilityDeterminator = new AAWEligibilityDeterminator();
            _CitizenshipEligibilityDeterminator = new CitizenshipEligibilityDeterminator();
            _SSNEligibilityDeterminator = new SSNEligibilityDeterminator();
            _HoursWorkedEligibilityDeterminator = new HoursWorkedEligibilityDeterminator();
            _configuration = configuration;
        }

        public EligibilityDeterminationRequest CreateEligibilityDeterminationRequest(Participant participant, PlanDesignRequestClass pdrClass)
        {
            var eligibilityDeterminationRequest = new EligibilityDeterminationRequest();

            if (pdrClass != null)
            {
                eligibilityDeterminationRequest.PlanDesignRequestClassId = pdrClass.Id;
                eligibilityDeterminationRequest.IllustrationEffectiveDate = pdrClass.PlanDesignRequest.IllustrationEffectiveDate;
                eligibilityDeterminationRequest.ReplacementRatio = pdrClass.ApprovedMaximumReplacementRatio;

                if (pdrClass.ApprovedPremiumPayerAndTaxabilityType != null)
                {
                    eligibilityDeterminationRequest.PremiumPayerandTaxability = (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum)pdrClass.ApprovedPremiumPayerAndTaxabilityType.Id;
                    eligibilityDeterminationRequest.PlanDesignType = pdrClass.ApprovedPlanDesignType;
                }
                else
                {
                    eligibilityDeterminationRequest.PremiumPayerandTaxability = (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum)pdrClass.RequestedPremiumPayerAndTaxabilityType.Id;
                    eligibilityDeterminationRequest.PlanDesignType = pdrClass.RequestedPlanDesignType;
                }
                eligibilityDeterminationRequest.BenefitPeriod = pdrClass.ApprovedBenefitPeriod;
                if (pdrClass.IsApprovedVoluntaryGSIBuyUpPlan == true)
                {
                    var buyUpPlan = pdrClass.PlanDesignRequestClassProducts.FirstOrDefault(p => p.IsGSIPlanIndicator == true);
                    if (buyUpPlan != null)
                    {
                        eligibilityDeterminationRequest.TotalMaxGSIAmount = buyUpPlan.TotalMaxGSIAmount > 0 ? (int?)buyUpPlan.TotalMaxGSIAmount : null;
                    }
                   
                }
                else
                {
                    var primaryPlan = pdrClass.PlanDesignRequestClassProducts.FirstOrDefault(p => p.IsGSIPlanIndicator == false);
                    if (primaryPlan != null)
                    {
                        eligibilityDeterminationRequest.TotalMaxGSIAmount = primaryPlan.GSIAmount > 0 ? (int?)primaryPlan.GSIAmount : null;
                        eligibilityDeterminationRequest.IsOneStepEnrollmentIndicator = primaryPlan.IsOneStepEnrollmentIndicator;
                        eligibilityDeterminationRequest.IsDirectCoverageIndicator = primaryPlan.IsDirectCoverageIndicator;
                    }

                }
                eligibilityDeterminationRequest.IsEmployerPremiumPayerType = pdrClass.ApprovedPremiumPayerAndTaxabilityType?.Id != (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable ? true : false;
            }

            AddParticipantDataToRequest(participant, eligibilityDeterminationRequest);

            return eligibilityDeterminationRequest;
        }

        public EligibilityDeterminationRequest CreateEligibilityDeterminationRequest(Participant participant, PDRSoldClass soldClass)
        {
            var eligibilityDeterminationRequest = new EligibilityDeterminationRequest();

            if (soldClass != null)
            {
                eligibilityDeterminationRequest.PlanDesignRequestClassId = soldClass.PlanDesignRequestClass.Id;
                eligibilityDeterminationRequest.IllustrationEffectiveDate = soldClass.PlanDesignRequest.IllustrationEffectiveDate;

                var primaryPlan = soldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.Primary);
                var buyUpPlan = soldClass.PDRSoldClassPlan.FirstOrDefault(c => c.PDRClassPlanType == PDRClassPlanTypeEnum.VoluntaryGSIBuyUp);
                if (primaryPlan != null)
                {
                    eligibilityDeterminationRequest.PremiumPayerandTaxability = (ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum?)primaryPlan.PremiumPayerAndTaxabilityType.Id;
                    eligibilityDeterminationRequest.ReplacementRatio = primaryPlan.MaximumReplacementRatio;
                    eligibilityDeterminationRequest.PlanDesignType = primaryPlan.PlanDesignType;
                    eligibilityDeterminationRequest.BenefitPeriod = primaryPlan.BenefitPeriod;
                    eligibilityDeterminationRequest.TotalMaxGSIAmount = primaryPlan.GSIAmount > 0 ? (int?)primaryPlan.GSIAmount : null;
                    eligibilityDeterminationRequest.IsOneStepEnrollmentIndicator = primaryPlan.IsOneStepEnrollmentIndicator;
                }
                if (buyUpPlan != null)
                {
                    eligibilityDeterminationRequest.BenefitPeriod = buyUpPlan?.BenefitPeriod;                    
                    eligibilityDeterminationRequest.PlanDesignType = buyUpPlan?.PlanDesignType;
                    eligibilityDeterminationRequest.BuyUpReplacementRatio = buyUpPlan.ReplacementPercentage; //should come from BuyUp replacemnt percent section from UI
                    eligibilityDeterminationRequest.TotalMaxGSIAmount = buyUpPlan.TotalMaxGSIAmount > 0 ? (int?)buyUpPlan.TotalMaxGSIAmount : null;
                }

                eligibilityDeterminationRequest.IsEmployerPremiumPayerType = primaryPlan.PremiumPayerAndTaxabilityType.Id != (int)ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.VoluntaryPlan_Non_Taxable ? true : false;
            }

            AddParticipantDataToRequest(participant, eligibilityDeterminationRequest);

            return eligibilityDeterminationRequest;
        }

        private void AddParticipantDataToRequest(Participant participant, EligibilityDeterminationRequest request, BenefitAmountsCalculationResponse response = null)
        {
            var cmsCase = participant.PlanDesignRequestClass.PlanDesignRequest.Case;
            request.IsAMBIncreaseIndicator = (participant.IsAMBIncreaseIndicator != null && participant.IsAMBIncreaseIndicator == true) ? true : false;
            
            //NBTC-3121 ER/VGSI Buy Up Annual Review: UW calculation and validation updates
            request.IsBuyUpAMBPolicyIndicator = participant.IsBuyUpPushtoNewProviderChoicePolicyIndicator;
            request.IsBuyUpAMBIncreaseIndicator = (participant.IsBuyUpAMBIncreaseIndicator != null && participant.IsBuyUpAMBIncreaseIndicator == true) ? true : false;

            var existingPolicy = participant.ParticipantExistingPolicies.FirstOrDefault();
            if (existingPolicy != null)
            {
                BuildParticipantExistingPolicyDetails(existingPolicy, request, cmsCase, request.IsAMBIncreaseIndicator, request.IsBuyUpAMBIncreaseIndicator.Value);
            }
            request.ParticipantDateOfBirth = participant.DateOfBirth;
            request.EmploymentStatus = participant.EmploymentStatusType;
            request.BasePlanPreviousSolicitations = participant.BasePlanPreviousSolicitations;
            request.ParticipantAge = participant.IssueAge;
            request.ParticipantIDIInsurableIncomeAmount = response != null ? response.IDIInsurableIncomeAmount : participant.IDIInsurableIncomeCalculatedAmount;
            request.IDIReplacementCalculatedPercentage = response != null ? response.IDIReplacementPercent : participant.IDIReplacementCalculatedPercent;
            request.IsAMBPolicyIndicator = participant.IsPushtoNewProviderChoicePolicyIndicator ;
            request.ParticipantRPPCalculatedAmount = participant.RPPBenefitCalculatedAmount;
            request.ContractState = participant.ContractState;
            request.AAW = participant.AAW;
            request.Citizenship = participant.Citizenship;
            request.SocialSecurityNumber = participant.SocialSecurityNumber;
            request.HoursWorked = participant.WeeklyHoursWorked;
            request.ManualBenefitAmount = participant.ManualBenefitAmount;

        }

        private List<ExistingCoverageProdLib> GetParticipantExistingPolicy(List<ParticipantExistingPolicyDetail> policyDetails, string caseNumber)
        {
            var request = policyDetails.Select(c => new ExistingCoveragePolicyNumber
            {
                PolicyNumber = c.PolicyNumber
            }).ToList();

            var participantExistingPolicyDataReader = new ParticipantExistingPolicyDataReader(_configuration);
            return participantExistingPolicyDataReader.GetParticipantExistingPolicyByPolicies(request, caseNumber);
        }
        private void BuildParticipantExistingPolicyDetails(ParticipantExistingPolicy existingPolicy, EligibilityDeterminationRequest request, Case cmsCase, bool isBaseAMBIncrease, bool isBuyUpAMBIncrease )
        {
            var policyDetails = existingPolicy.ParticipantExistingPolicyDetails.GroupBy(c => c.PolicyNumber).Select(g => g.First()).ToList();
            if (policyDetails.Any())
            {
                if (policyDetails.Where(c => c.CLOASPolicyStatus != "Rejected" && (c.CLOASPolicyStatus == "Inforce" || c.CLOASPolicyStatus == "Inforce-Claim" || c.CLOASPolicyStatus == "Pending")).Any())
                {
                    request.ParticipantGSIAmount = existingPolicy.GSIIDIBaseAMB != null ? existingPolicy.GSIIDIBaseAMB : null;

                    if (request.IsEmployerPremiumPayerType)
                    {
                        var employerPolicyDetails = policyDetails.Where(c => c.PremiumPayer == PremiumPayerTypeEnum.Employer.ToString()).ToList();

                        var productLibCoverage = GetParticipantExistingPolicy(employerPolicyDetails, cmsCase.CaseNumber).Where(c => c.IsBaseCoverageIndicator).FirstOrDefault();

                        request.BenefitPeriod = productLibCoverage != null ? (BenefitPeriodTypeEnum?)productLibCoverage.BenefitPeriodKey : null;

                    }

                    if(isBaseAMBIncrease != true && isBuyUpAMBIncrease == true)
                    {
                        var employeePolicyDetails = policyDetails.Where(c => c.PremiumPayer == PremiumPayerTypeEnum.Employee.ToString()).ToList();

                        var productLibCoverage = GetParticipantExistingPolicy(employeePolicyDetails, cmsCase.CaseNumber).Where(c => c.IsBaseCoverageIndicator).FirstOrDefault();

                        request.BenefitPeriod = productLibCoverage != null ? (BenefitPeriodTypeEnum ?)productLibCoverage.BenefitPeriodKey : null;
                    }
                }
            }
        }

        public EligibilityDeterminationRequest CreateEligibilityDeterminationRequest(
            Participant participant, PDRSoldClass soldClass,
            EnrollmentParticipantOptionPlan participantOptionPlan, BenefitAmountsCalculationResponse response = null)
        {
            var eligibilityDeterminationRequest = CreateEligibilityDeterminationRequest(participant, soldClass);

            //TODO: fill the request with the participantOptionPlan values

            AddParticipantDataToRequest(participant, eligibilityDeterminationRequest, response);

            return eligibilityDeterminationRequest;
        }

        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request)
        {
            var eligibilityConfigurationRequest = new EligibilityConfigurationDto
            {
                CaseId = request.CaseId,
                PlanDesignRequestId = request.PlanDesignRequestId,
                PlanDesignRequestClassId = request.PlanDesignRequestClassId
            };

            var eligibilityConfiguration = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationRequest);
            var response = Determine(request, eligibilityConfiguration);

            return response;
        }

        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request, EligibilityConfigurationDto eligibilityConfiguration)
        {
            var eligibilityResponses = new List<EligibilityDeterminationResponse>();
            var increaseAgeEligibilityDeterminator = _increaseAgeEligibilityDeterminator.Determine(request, eligibilityConfiguration);
            var ageEligibilityResponse = _ageEligibilityDeterminator.Determine(request, eligibilityConfiguration);
            var maxGSIEligibilityResponse = _maxGSIEligibilityDeterminator.Determine(request);
            var minimumPolicyEligibilityResponse = _minimumPolicyEligibilityDeterminator.Determine(request, eligibilityConfiguration);
            var minimumInsurableIncomeLevelEligibilityResponse = _minimumInsurableIncomeLevelEligibilityDeterminator.Determine(request, eligibilityConfiguration);
            var employmentStatusEligibilityResponse = _employmentStatusEligibilityDeterminator.Determine(request);
            var fullyInsuredEligibilityResponse = _fullyInsuredEligibilityDeterminator.Determine(request);
            var belowMinimumGSIEligibilityResponse = _belowMinimumGSIEligibilityDeterminator.Determine(request, eligibilityConfiguration);
            var maximumSolicitationDeterminator = _maximumSolicitationDeterminator.Determine(request, eligibilityConfiguration);
            var HoursWorkedEligibilityResponse = _HoursWorkedEligibilityDeterminator.Determine(request);

            if (increaseAgeEligibilityDeterminator != null)
            {
                eligibilityResponses.Add(increaseAgeEligibilityDeterminator);
            }
            if (ageEligibilityResponse != null)
            {
                eligibilityResponses.Add(ageEligibilityResponse);
            }
            if (maxGSIEligibilityResponse != null)
            {
                eligibilityResponses.Add(maxGSIEligibilityResponse);
            }
            if (minimumPolicyEligibilityResponse != null)
            {
                eligibilityResponses.Add(minimumPolicyEligibilityResponse);
            }
            if (minimumInsurableIncomeLevelEligibilityResponse != null)
            {
                eligibilityResponses.Add(minimumInsurableIncomeLevelEligibilityResponse);
            }
            if (employmentStatusEligibilityResponse != null)
            {
                eligibilityResponses.Add(employmentStatusEligibilityResponse);
            }
            if (fullyInsuredEligibilityResponse != null)
            {
                eligibilityResponses.Add(fullyInsuredEligibilityResponse);
            }
            if (belowMinimumGSIEligibilityResponse != null)
            {
                eligibilityResponses.Add(belowMinimumGSIEligibilityResponse);
            }
            if (maximumSolicitationDeterminator != null)
            {
                eligibilityResponses.Add(maximumSolicitationDeterminator);
            }
            if(HoursWorkedEligibilityResponse!=null)
            {
                eligibilityResponses.Add(HoursWorkedEligibilityResponse);
            }
            
            var response = CreateEligibilityResponse(eligibilityResponses);

            return response;
        }

        public EligibilityDeterminationResponse DetermineForBandP(EligibilityDeterminationRequest request, EligibilityConfigurationDto eligibilityConfiguration)
        {
            var eligibilityResponses = new List<EligibilityDeterminationResponse>();

            var increaseAgeEligibilityDeterminator = _increaseAgeEligibilityDeterminator.Determine(request, eligibilityConfiguration);
            var ageEligibilityResponse = _ageEligibilityDeterminator.Determine(request, eligibilityConfiguration);

            if (increaseAgeEligibilityDeterminator != null)
            {
                eligibilityResponses.Add(increaseAgeEligibilityDeterminator);
            }
            if (ageEligibilityResponse != null)
            {
                eligibilityResponses.Add(ageEligibilityResponse);
            }
            var response = CreateEligibilityResponse(eligibilityResponses);

            return response;
        }

        public EligibilityDeterminationRequest CreateEligibilityDeterminationRequest(
            Participant participant, PDRSoldClass soldClass,
            IllustrationRequestClassPlan participantOptionPlan, BenefitAmountsCalculationResponse response = null)
        {
            var eligibilityDeterminationRequest = CreateEligibilityDeterminationRequest(participant, soldClass);

            AddParticipantDataToRequest(participant, eligibilityDeterminationRequest, response);

            return eligibilityDeterminationRequest;
        }

        public EligibilityDeterminationRequest CreateEligibilityDeterminationRequest(
            Participant participant, PlanDesignRequestClass pdrClass,
            IllustrationRequestClassPlan participantOptionPlan, BenefitAmountsCalculationResponse response = null)
        {
            var eligibilityDeterminationRequest = CreateEligibilityDeterminationRequest(participant, pdrClass);

            AddParticipantDataToRequest(participant, eligibilityDeterminationRequest, response);

            return eligibilityDeterminationRequest;
        }
        private EligibilityDeterminationResponse CreateEligibilityResponse(List<EligibilityDeterminationResponse> eligibilityResponses)
        {
            if (!eligibilityResponses.Any()) return null;

            var eligibilityDeterminationResponse = new EligibilityDeterminationResponse();
            eligibilityDeterminationResponse.isEligible = eligibilityResponses.All(el => el.isEligible == true);

            if (eligibilityDeterminationResponse.isEligible == false)
            {
                eligibilityDeterminationResponse.InEligibleReason = string.Join(", ", eligibilityResponses.Where(e => e.isEligible == false).Select(el => el.InEligibleReason).ToArray());
            }

            return eligibilityDeterminationResponse;
        }

        public OneStepEligibilityDeterminationResponse DetermineOneStepEligibility(EligibilityDeterminationRequest request)
        {
            var eligibilityConfigurationRequest = new EligibilityConfigurationDto
            {
                CaseId = request.CaseId,
                PlanDesignRequestId = request.PlanDesignRequestId,
                PlanDesignRequestClassId = request.PlanDesignRequestClassId
            };

            var eligibilityConfiguration = _eligibilityConfigurationManager.GetEligibilityConfiguration(eligibilityConfigurationRequest);
            var response = DetermineOneStepEligibility(request, eligibilityConfiguration);

            return response;
        }

        public OneStepEligibilityDeterminationResponse DetermineOneStepEligibility(EligibilityDeterminationRequest request, EligibilityConfigurationDto eligibilityConfiguration)
        {
            var eligibilityResponses = new List<OneStepEligibilityDeterminationResponse>();
            var AAWEligibilityResponse = _AAWEligibilityDeterminator.Determine(request);
            var CitizenshipEligibilityResponse = _CitizenshipEligibilityDeterminator.Determine(request);
            var SSNEligibilityResponse = _SSNEligibilityDeterminator.Determine(request);

            if (SSNEligibilityResponse != null)
            {
                eligibilityResponses.Add(SSNEligibilityResponse);
            }
            if (AAWEligibilityResponse != null)
            {
                eligibilityResponses.Add(AAWEligibilityResponse);
            }
            if (CitizenshipEligibilityResponse != null)
            {
                eligibilityResponses.Add(CitizenshipEligibilityResponse);
            }
            var response = CreateOneStepEligibilityResponse(eligibilityResponses);

            return response;
        }

        private OneStepEligibilityDeterminationResponse CreateOneStepEligibilityResponse(List<OneStepEligibilityDeterminationResponse> eligibilityResponses)
        {
            if (!eligibilityResponses.Any()) return null;

            var oneStepEligibilityDeterminationResponse = new OneStepEligibilityDeterminationResponse();
            oneStepEligibilityDeterminationResponse.IsError = eligibilityResponses.Any(el => el.IsError == true);

            if (oneStepEligibilityDeterminationResponse.IsError == true)
            {
                oneStepEligibilityDeterminationResponse.ErrorReason = string.Join(", ", eligibilityResponses.Where(e => e.IsError == true).Select(el => el.ErrorReason).ToArray());
            }

            return oneStepEligibilityDeterminationResponse;
        }
    }
}
