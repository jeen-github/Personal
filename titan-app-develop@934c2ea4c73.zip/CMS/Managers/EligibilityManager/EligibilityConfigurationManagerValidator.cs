﻿using System;
using System.Collections.Generic;
using System.Linq;
using Logger.Static;
using Common.Exceptions;
using CMS.Interfaces.Managers.EligibilityManager;

namespace CMS.Managers.EligibilityManager
{
    public class EligibilityConfigurationManagerValidator
    {
        public void ValidateClassEligibility(EligibilityConfigurationDto request)
        {
            Log.TraceFormat("+ValidateClassEligibility");

            var errorMessages = new List<string>();

            ValidateMinimumBenefitAmount(errorMessages,request);
            if (errorMessages.Any()) throw new ValidationException(errorMessages);

            Log.TraceFormat("-ValidateClassEligibility");
        }

        public void ValidateMinimumBenefitAmount( List<string> errorMessages, EligibilityConfigurationDto request)
        {
            Log.TraceFormat("+ValidateMinimumBenefitAmount");
            if(request.MinimumBenefitAmount < 0 || request.MinimumBenefitAmount > 20000)
            {
                errorMessages.Add("Please enter a valid  Minimum Benefit Amount.");
            }
            Log.TraceFormat("-ValidateMinimumBenefitAmount");
        }
    }
}
