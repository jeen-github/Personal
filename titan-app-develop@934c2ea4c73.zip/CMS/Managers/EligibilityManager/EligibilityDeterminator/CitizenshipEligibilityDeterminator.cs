﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class CitizenshipEligibilityDeterminator
    {
        public OneStepEligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request)
        {
            OneStepEligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            bool isError = false;

            if (request.Citizenship == null || request.Citizenship != true)
            {
                isError = true;
            }

            response = new OneStepEligibilityDeterminationResponse();
            response.IsError = isError;
            if (isError)
            {
                response.ErrorReason = "Not US citizen/green card holder";
            }

            return response;
        }
    }
}
