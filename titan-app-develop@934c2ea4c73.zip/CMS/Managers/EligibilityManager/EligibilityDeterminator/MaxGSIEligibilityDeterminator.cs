﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class MaxGSIEligibilityDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request)
        {
            EligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            bool isEligible = true;
            response = new EligibilityDeterminationResponse();

            if (request.ManualBenefitAmount > 0)
            {
                response.isEligible = true;
                return response;
            }

            if (request.ParticipantGSIAmount.HasValue && request.TotalMaxGSIAmount.HasValue)
            {
                if (request.ParticipantGSIAmount >= request.TotalMaxGSIAmount)
                {
                    isEligible = false;
                }
            }
           
            response.isEligible = isEligible;
            if (isEligible == false)
            {
                response.InEligibleReason = "At Max GSI";
            }

            return response;
        }
    }
}
