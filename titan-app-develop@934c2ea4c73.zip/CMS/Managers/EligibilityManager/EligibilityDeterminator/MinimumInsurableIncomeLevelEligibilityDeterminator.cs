﻿using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Model.Enums;
using Logger.Static;


namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class MinimumInsurableIncomeLevelEligibilityDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request, EligibilityConfigurationDto eligibiltyConfiguration)
        {
            EligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            if (eligibiltyConfiguration == null)
            {
                //Log.InfoFormat("Eligibilty Configuration is null");
                return response;
            }
            if(request.PlanDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                return response;
            }

            bool isEligible = true;
            if (request.PlanDesignType != PlanDesignTypeEnum.FlatBenefitPlan)
            {
                if (request.PremiumPayerandTaxability == ExistingCoveragePremiumAndTaxpayerLiabilityTypeEnum.EmployerPaid)
                {
                    if (request.ParticipantIDIInsurableIncomeAmount < eligibiltyConfiguration.EmployerPaidMinimumInsurableIncomeAmount)
                    {
                        isEligible = false;
                    }
                }
                else
                {
                    if (request.ParticipantIDIInsurableIncomeAmount < eligibiltyConfiguration.MinimumInsurableIncomeAmount)
                    {
                        isEligible = false;
                    }
                }
            }
            response = new EligibilityDeterminationResponse();
            response.isEligible = isEligible;
            if (isEligible == false)
            {
                response.InEligibleReason = "Minimum Insurable Income";
            }
            return response;
        }
    }
}
