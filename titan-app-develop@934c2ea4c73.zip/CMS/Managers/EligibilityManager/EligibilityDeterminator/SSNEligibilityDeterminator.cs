﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class SSNEligibilityDeterminator
    {
        public OneStepEligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request)
        {
            OneStepEligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            bool isError = false;

            string SSNPattern = "^\\d{3}-\\d{2}-\\d{4}$|^\\d{9}$";
            Regex regex = new Regex(SSNPattern);
            bool IsMatching = request.SocialSecurityNumber != null ? (regex.IsMatch(request.SocialSecurityNumber)) : false;
            if (!IsMatching)
            {
                isError = true;
            }

            response = new OneStepEligibilityDeterminationResponse();
            response.IsError = isError;
            if (isError)
            {
                response.ErrorReason = "Missing or invalid SSN";
            }

            return response;
        }
    }
}
