﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class HoursWorkedEligibilityDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request)
        {
            EligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            bool isEligible = true;
            if (request.IsOneStepEnrollmentIndicator)
            {
                if (request.HoursWorked > 0 && request.HoursWorked < 30)
                {
                    request.AAW = false;
                    isEligible = false;
                }
                else if (request.HoursWorked >= 30)
                {
                    request.AAW = true;
                }
                else
                {
                    isEligible = false;
                }
            }

            response = new EligibilityDeterminationResponse();
            response.isEligible = isEligible;
            if (!isEligible)
            {
                response.InEligibleReason = "Hours Worked";
            }

            return response;
        }
    }
}
