﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;
using Common.Utilities;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class MaximumSolicitationDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request, EligibilityConfigurationDto eligibiltyConfiguration)
        {
            EligibilityDeterminationResponse response = null;

            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            if (eligibiltyConfiguration == null)
            {
                //Log.InfoFormat("Eligibilty Configuration is null");
                return response;
            }

            bool isEligible = true;

            if (request.BasePlanPreviousSolicitations.HasValue)
            {
                isEligible = DetermineByMaximumSolicitation(eligibiltyConfiguration, isEligible, request.BasePlanPreviousSolicitations);
            }

            response = new EligibilityDeterminationResponse();
            response.isEligible = isEligible;
            if (isEligible == false)
            {
                response.InEligibleReason = "Maximum Solicitation";
            }
            return response;
        }

        private bool DetermineByMaximumSolicitation(EligibilityConfigurationDto eligibiltyConfiguration, bool isEligible, int? basePlanPreviousSolicitations)
        {
            if (basePlanPreviousSolicitations >= eligibiltyConfiguration.MaximumSolicitation)
            {
                isEligible = false;
            }
            return isEligible;
        }
    }
}
