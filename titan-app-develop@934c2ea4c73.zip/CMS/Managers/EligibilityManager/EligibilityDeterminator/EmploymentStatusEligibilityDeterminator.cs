﻿using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Model.Enums;
using Logger.Static;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class EmploymentStatusEligibilityDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request)
        {
            EligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }

            response = new EligibilityDeterminationResponse();
            bool isEligible = true;
            if (request.EmploymentStatus.HasValue)
            {
                isEligible = DetermineByEmploymentStatus(request.EmploymentStatus);
            }

            response.isEligible = isEligible;
            if (isEligible == false)
            {
                if (request.EmploymentStatus == EmploymentStatusTypeEnum.Terminated)
                {
                    response.InEligibleReason = "Termination";
                }
                else if(request.EmploymentStatus == EmploymentStatusTypeEnum.Leave)
                {
                    response.InEligibleReason = "Leave of Absence";
                }
            }

            return response;
        }

        private bool DetermineByEmploymentStatus(EmploymentStatusTypeEnum? employmentStatus)
        {
            bool isEligible = true;
            if (employmentStatus == EmploymentStatusTypeEnum.Terminated || employmentStatus == EmploymentStatusTypeEnum.Leave)
            {
                isEligible = false;
            }

            return isEligible;
        }
    }
}
