﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class AAWEligibilityDeterminator
    {
        public OneStepEligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request)
        {
            OneStepEligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            bool isError = false;
            
            if (request.AAW == null || request.AAW != true)
            {
                isError = true;
            }
            
            response = new OneStepEligibilityDeterminationResponse();
            response.IsError = isError;
            if (isError)
            {
                response.ErrorReason = "Not actively at work";
            }

            return response;
        }
    }
}
