﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class FullyInsuredEligibilityDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request)
        {
            EligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }

            if(request.PlanDesignType == Model.Enums.PlanDesignTypeEnum.BonusOnlyPlan)
            {
                return response;
            }
            bool isEligible = true;
            response = new EligibilityDeterminationResponse();           

            if (request.ManualBenefitAmount > 0)
            {
                response.isEligible = true;
                return response;
            }

            if (request.IDIReplacementCalculatedPercentage.HasValue && request.ReplacementRatio.HasValue)
            {
                if (request.IDIReplacementCalculatedPercentage * 100 >= request.ReplacementRatio)
                {
                    isEligible = false;
                }
            }

            if (request.IDIReplacementCalculatedPercentage.HasValue && request.BuyUpReplacementRatio.HasValue && isEligible == false)
            {
                isEligible = true;

                if (request.IDIReplacementCalculatedPercentage * 100 >= request.BuyUpReplacementRatio)
                {
                    isEligible = false;
                }
            }

            response.isEligible = isEligible;
            if (isEligible == false)
            {
                response.InEligibleReason = "Fully Insured";
            }
            
            return response;
        }
    }
}
