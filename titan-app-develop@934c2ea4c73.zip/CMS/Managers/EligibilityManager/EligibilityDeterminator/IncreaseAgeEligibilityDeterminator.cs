﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;
using Common.Utilities;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class IncreaseAgeEligibilityDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request, EligibilityConfigurationDto eligibiltyConfiguration)
        {
            EligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            if (eligibiltyConfiguration == null)
            {
                //Log.InfoFormat("Eligibilty Configuration is null");
                return response;
            }

            bool isEligible = false;
            if (request.IsAMBPolicyIndicator == true || request.IsBuyUpAMBPolicyIndicator == true)
            {
                if (request.ParticipantAge.HasValue)
                {
                    var participantAge = request.ParticipantAge;
                    isEligible = DetermineByAge(eligibiltyConfiguration, isEligible, participantAge);
                }
                else if (request.ParticipantDateOfBirth.HasValue)
                {
                    var participantAge = request.ParticipantDateOfBirth.GetAge(request.IllustrationEffectiveDate);
                    isEligible = DetermineByAge(eligibiltyConfiguration, isEligible, participantAge);
                }
                response = new EligibilityDeterminationResponse();
                response.isEligible = isEligible;
                if (isEligible == false)
                {
                    response.InEligibleReason = "Ineligible for Increase - AGE";
                }
            }
            else if (request.IsAMBIncreaseIndicator == true || request.IsBuyUpAMBIncreaseIndicator == true)
            {
                if (request.ParticipantAge.HasValue)
                {
                    var participantAge = request.ParticipantAge;
                    isEligible = DetermineByIssueAge(request, isEligible, participantAge);
                }
                else if (request.ParticipantDateOfBirth.HasValue)
                {
                    var participantAge = request.ParticipantDateOfBirth.GetAge(request.IllustrationEffectiveDate);
                    isEligible = DetermineByIssueAge(request, isEligible, participantAge);
                }
                response = new EligibilityDeterminationResponse();
                response.isEligible = isEligible;
                if (isEligible == false)
                {
                    response.InEligibleReason = "Over Max Issue Age For Increase";
                }
            }          
            return response;
        }


        private bool DetermineByIssueAge(EligibilityDeterminationRequest request, bool isEligible, int? participantAge)
        {
            isEligible = true;
            if (request.BenefitPeriod != null)
            {
                if ((request.BenefitPeriod == BenefitPeriodTypeEnum.Y02 || request.BenefitPeriod == BenefitPeriodTypeEnum.M24 ||
                     request.BenefitPeriod == BenefitPeriodTypeEnum.Y05 || request.BenefitPeriod == BenefitPeriodTypeEnum.M60 ||
                     request.BenefitPeriod == BenefitPeriodTypeEnum.Y10 || request.BenefitPeriod == BenefitPeriodTypeEnum.A65)
                    && participantAge >= 65)
                {
                    isEligible = false;
                }
                else if ((request.BenefitPeriod == BenefitPeriodTypeEnum.A67 ||
                    request.BenefitPeriod == BenefitPeriodTypeEnum.V70) && participantAge >= 67)
                {
                    isEligible = false;
                }
                else
                {
                    isEligible = true;
                }
            }
            return isEligible;
        }

        private bool DetermineByAge(EligibilityConfigurationDto eligibiltyConfiguration, bool isEligible, int? participantAge)
        {
            if (participantAge < eligibiltyConfiguration.IncreaseAge)
            {
                isEligible = true;
            }
            return isEligible;
        }
    }
}
