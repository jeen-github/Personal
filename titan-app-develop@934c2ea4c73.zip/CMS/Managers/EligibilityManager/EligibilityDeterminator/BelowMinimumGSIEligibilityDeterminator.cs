﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;
using CMS.Model.Enums;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class BelowMinimumGSIEligibilityDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request, EligibilityConfigurationDto eligibiltyConfiguration)
        {
            EligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            if (eligibiltyConfiguration == null)
            {
                //Log.InfoFormat("Eligibilty Configuration is null");
                return response;
            }

            bool isEligible = true;
            response = new EligibilityDeterminationResponse();

            if (request.ManualBenefitAmount > 0)
            {
                response.isEligible = true;
                return response;
            }

            if (request.PlanDesignType == PlanDesignTypeEnum.FlatBenefitPlan)
            {
                response.isEligible = true;
                return response;
            }

            if (request.ParticipantGSIAmount.HasValue)
            {
                isEligible = DetermineByGSI(eligibiltyConfiguration, isEligible, request.ParticipantGSIAmount);
            }
            
            response.isEligible = isEligible;
            if (isEligible == false)
            {
                response.InEligibleReason = "Below Minimum GSI";
            }

            return response;
        }

        private bool DetermineByGSI(EligibilityConfigurationDto eligibiltyConfiguration, bool isEligible, decimal? gsiBaseCalculatedAmount)
        {
            if (gsiBaseCalculatedAmount < eligibiltyConfiguration.MinimumBenefitAmount)
            {
                isEligible = false;
            }
            return isEligible;
        }
    }
}
