﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;
using Common.Utilities;
using System.Linq;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class AgeEligibilityDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request, EligibilityConfigurationDto eligibiltyConfiguration)
        {
            EligibilityDeterminationResponse response = null;
            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            if (eligibiltyConfiguration == null)
            {
                //Log.InfoFormat("Eligibilty Configuration is null");
                return response;
            }
            //if (!(bool)request.IsAMBPolicyIndicator)
            if ((request.IsAMBPolicyIndicator == false || request.IsAMBPolicyIndicator == null) && (request.IsBuyUpAMBPolicyIndicator == false || request.IsBuyUpAMBPolicyIndicator == null))
            {
                bool isEligible = false;
                if (request.ParticipantAge.HasValue)
                {
                    var participantAge = request.ParticipantAge;
                    isEligible = DetermineByAge(eligibiltyConfiguration, isEligible, participantAge, request.PlanDesignType, request.ContractState, request.BenefitPeriod);
                }
                else if (request.ParticipantDateOfBirth.HasValue)
                {
                    var participantAge = request.ParticipantDateOfBirth.GetAge(request.IllustrationEffectiveDate);
                    isEligible = DetermineByAge(eligibiltyConfiguration, isEligible, participantAge, request.PlanDesignType, request.ContractState, request.BenefitPeriod);
                }
                response = new EligibilityDeterminationResponse();
                response.isEligible = isEligible;
                if (isEligible == false)
                {
                    response.InEligibleReason = "Age";
                }
            }
            return response;
        }

        private bool DetermineByAge(EligibilityConfigurationDto eligibiltyConfiguration, bool isEligible, int? participantAge, PlanDesignTypeEnum? planDesignType, StateTypeEnum? contractState, BenefitPeriodTypeEnum? benefitPeriod)
        {
          
            if (planDesignType == PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                if ((participantAge >= eligibiltyConfiguration.MinimumAge) && (participantAge < eligibiltyConfiguration.StandAloneRPPMaximumAge))
                {
                    isEligible = true;
                }
            }
            else
            {
                if ((participantAge >= eligibiltyConfiguration.MinimumAge) && (participantAge <= eligibiltyConfiguration.MaximumAge))
                {
                    isEligible = true;
                }
            }
           

            return isEligible;
        }

    }
}
