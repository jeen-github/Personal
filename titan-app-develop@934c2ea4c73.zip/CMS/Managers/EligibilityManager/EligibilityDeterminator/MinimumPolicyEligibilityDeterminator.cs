﻿using CMS.Interfaces.Managers.EligibilityManager;
using Logger.Static;
using CMS.Model.Enums;

namespace CMS.Managers.EligibilityManager.EligibilityDeterminator
{
    public class MinimumPolicyEligibilityDeterminator
    {
        public EligibilityDeterminationResponse Determine(EligibilityDeterminationRequest request, EligibilityConfigurationDto eligibiltyConfiguration)
        {
            EligibilityDeterminationResponse response = null;

            if (request == null)
            {
                Log.InfoFormat("request is null");
                return response;
            }
            if (eligibiltyConfiguration == null)
            {               
                return response;
            }
            if (request.PlanDesignType != PlanDesignTypeEnum.StandAloneRPPPlan)
            {
                return response;
            }

            bool isEligible = true;
            response = new EligibilityDeterminationResponse();
           
            if (request.ParticipantRPPCalculatedAmount.HasValue)
            {
                isEligible = DetermineByMinimumPolicy(eligibiltyConfiguration, isEligible, request.ParticipantRPPCalculatedAmount);
            }

            response.isEligible = isEligible;
            if (isEligible == false)
            {
                response.InEligibleReason = "Below Minimum Policy";
            }

            return response;
        }

        private bool DetermineByMinimumPolicy(EligibilityConfigurationDto eligibiltyConfiguration, bool isEligible, decimal? rppCalculatedAmount)
        {
            if (rppCalculatedAmount < eligibiltyConfiguration.MinimumBenefitAmount)
            {
                isEligible = false;
            }
            return isEligible;
        }
    }
}
