﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.EligibilityManager;
using CMS.Model.Entities;
using Common.Exceptions;
using Guardian.Core.Entities.Product.Enums;
using Logger.Static;
using System.Linq;

namespace CMS.Managers.EligibilityManager
{
    public class EligibilityConfigurationManager : IEligibilityConfigurationManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        private readonly EligibilityConfigurationManagerValidator _eligibilityConfigurationManagerValidator;

        public EligibilityConfigurationManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
            _eligibilityConfigurationManagerValidator = new EligibilityConfigurationManagerValidator();
        }

        public EligibilityConfigurationDto GetEligibilityConfiguration(EligibilityConfigurationDto request)
        {
            //Log.TraceFormat("+GetEligibilityConfiguration");
            var eligibilityConfigurationDto = new EligibilityConfigurationDto();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsDefaultEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(e => e.Case == null && e.PlanDesignRequest == null && e.PlanDesignRequestClass == null);
                var cmsCaseEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(e => e.Case != null && e.Case.Id == request.CaseId && e.PlanDesignRequest == null && e.PlanDesignRequestClass == null);
                var cmsPDREligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(e => e.PlanDesignRequest != null && e.PlanDesignRequest.Id == request.PlanDesignRequestId && e.PlanDesignRequestClass == null);
                var cmsPDRClassEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(e => e.PlanDesignRequestClass != null && e.PlanDesignRequestClass.Id == request.PlanDesignRequestClassId);
                eligibilityConfigurationDto.CaseId = request.CaseId;
                if (cmsDefaultEligibilityConfiguration != null)
                {
                    CreateEligibilityConfigurationDto(eligibilityConfigurationDto, cmsDefaultEligibilityConfiguration);
                }
                if (cmsCaseEligibilityConfiguration != null)
                {
                    CreateEligibilityConfigurationDto(eligibilityConfigurationDto, cmsCaseEligibilityConfiguration);
                }
                if (cmsPDREligibilityConfiguration != null)
                {
                    CreateEligibilityConfigurationDto(eligibilityConfigurationDto, cmsPDREligibilityConfiguration);
                }
                if (cmsPDRClassEligibilityConfiguration != null)
                {
                    CreateEligibilityConfigurationDto(eligibilityConfigurationDto, cmsPDRClassEligibilityConfiguration);
                }
            }

           // Log.TraceFormat("-GetEligibilityConfiguration");
            return eligibilityConfigurationDto;
        }

        public void SaveEligibilityConfiguration(EligibilityConfigurationDto request)
        {
            Log.TraceFormat("+SaveEligibilityConfiguration");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == request.CaseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");
                bool hasPDRConfig = false, hasPDRClassConfig = false;
                PlanDesignRequest cmsPDR = null;
                PlanDesignRequestClass cmsPDRClass = null;
                if (request.PlanDesignRequestId.HasValue || request.PlanDesignRequestClassId.HasValue)
                {
                    cmsPDR = unitOfWork.Repository<PlanDesignRequest>().Linq().FirstOrDefault(p => p.Id == request.PlanDesignRequestId);
                    if (cmsPDR == null) throw new ValidationException("Plan Design Request not found!");
                    hasPDRConfig = true;
                }

                if (request.PlanDesignRequestClassId.HasValue)
                {
                    cmsPDRClass = unitOfWork.Repository<PlanDesignRequestClass>().Linq().FirstOrDefault(p => p.Id == request.PlanDesignRequestClassId);
                    if (cmsPDRClass == null) throw new ValidationException("Plan Design Request Class not found!");
                    hasPDRClassConfig = true;
                }

                EligibilityConfiguration cmsEligibilityConfiguration = null;

                if (hasPDRClassConfig)
                {
                    cmsEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(e => e.PlanDesignRequestClass != null && e.PlanDesignRequestClass.Id == request.PlanDesignRequestClassId);
                }
                else if (hasPDRConfig)
                {
                    cmsEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(e => e.PlanDesignRequest != null && e.PlanDesignRequest.Id == request.PlanDesignRequestId);
                }
                else
                {
                    cmsEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(e => e.Case != null && e.Case.Id == request.CaseId);
                }

                if (cmsEligibilityConfiguration == null)
                {
                    cmsEligibilityConfiguration = new EligibilityConfiguration();
                }

                CreateEligibilityConfiguration(request, cmsCase, cmsPDR, cmsPDRClass, cmsEligibilityConfiguration);

                unitOfWork.Repository<EligibilityConfiguration>().Save(cmsEligibilityConfiguration);

                unitOfWork.Commit();
            }
            Log.TraceFormat("-SaveEligibilityConfiguration");
        }

        private void CreateEligibilityConfigurationDto(EligibilityConfigurationDto eligibilityConfigurationDto, EligibilityConfiguration cmsDefaultEligibilityConfiguration)
        {
            Log.TraceFormat("+CreateEligibilityConfigurationDto");
            bool isCAStateType = false;
            bool isCACaseEligibilityConfiguration = false;
            StateTypeEnum ? contractState = StateTypeEnum.UN;
            eligibilityConfigurationDto.EligibilityConfigurationId = cmsDefaultEligibilityConfiguration.Id;
            if (cmsDefaultEligibilityConfiguration.Case != null)
            {
                eligibilityConfigurationDto.CaseId = cmsDefaultEligibilityConfiguration.Case.Id;
            }
            
            using (var unitOfWorkCase = _unitOfWorkFactory.CreateUnitOfWork())
            {
                isCACaseEligibilityConfiguration = unitOfWorkCase.Repository<CaseUnderwritingRequest>().Linq().FirstOrDefault(c => c.Case.Id== eligibilityConfigurationDto.CaseId)?.StateType == StateTypeEnum.CA ? true : false;               
            }
            if (cmsDefaultEligibilityConfiguration.PlanDesignRequest != null)
            {
                eligibilityConfigurationDto.PlanDesignRequestId = cmsDefaultEligibilityConfiguration.PlanDesignRequest.Id;
            }
            if (cmsDefaultEligibilityConfiguration.PlanDesignRequestClass != null)
            {
                contractState = cmsDefaultEligibilityConfiguration.PlanDesignRequestClass?.PlanDesignRequest?.Case?.CaseUnderwritingRequests.FirstOrDefault()?.StateType;
                isCAStateType = contractState == StateTypeEnum.CA ? true : false;
                eligibilityConfigurationDto.PlanDesignRequestClassId = cmsDefaultEligibilityConfiguration.PlanDesignRequestClass.Id;
            }
            if (cmsDefaultEligibilityConfiguration.MinimumAge.HasValue)
            {
                eligibilityConfigurationDto.MinimumAge = cmsDefaultEligibilityConfiguration.MinimumAge;
            }
            if (cmsDefaultEligibilityConfiguration.MaximumAge.HasValue)
            {
                eligibilityConfigurationDto.MaximumAge = cmsDefaultEligibilityConfiguration.MaximumAge;
            }
            if (cmsDefaultEligibilityConfiguration.MaximumGSIAmount.HasValue)
            {
                eligibilityConfigurationDto.MaximumGSIAmount = cmsDefaultEligibilityConfiguration.MaximumGSIAmount;
            }
            if (cmsDefaultEligibilityConfiguration.MinimumInsurableIncomeAmount.HasValue)
            {
                eligibilityConfigurationDto.MinimumInsurableIncomeAmount = cmsDefaultEligibilityConfiguration.MinimumInsurableIncomeAmount;
            }
            if (cmsDefaultEligibilityConfiguration.EmployerPaidMinimumInsurableIncomeAmount.HasValue)
            {
                eligibilityConfigurationDto.EmployerPaidMinimumInsurableIncomeAmount = cmsDefaultEligibilityConfiguration.EmployerPaidMinimumInsurableIncomeAmount;
            }
            if (cmsDefaultEligibilityConfiguration.IncreaseDuetoAge.HasValue)
            {
                eligibilityConfigurationDto.IncreaseAge = cmsDefaultEligibilityConfiguration.IncreaseDuetoAge;
            }
            if (cmsDefaultEligibilityConfiguration.RPPMaximumIndemnityAmount.HasValue)
            {
                eligibilityConfigurationDto.RPPMaximumIndemnityAmount = cmsDefaultEligibilityConfiguration.RPPMaximumIndemnityAmount;
            }
            if (cmsDefaultEligibilityConfiguration.RPPMaximumIndemnityAmountUnderAge49.HasValue)
            {
                eligibilityConfigurationDto.RPPMaximumIndemnityAmountUnderAge49 = cmsDefaultEligibilityConfiguration.RPPMaximumIndemnityAmountUnderAge49;
            }
            if (cmsDefaultEligibilityConfiguration.CATLimitAmount.HasValue)
            {
                eligibilityConfigurationDto.CATLimitAmount = cmsDefaultEligibilityConfiguration.CATLimitAmount;
            }
            if (cmsDefaultEligibilityConfiguration.MaximumSolicitation.HasValue)
            {
                eligibilityConfigurationDto.MaximumSolicitation = cmsDefaultEligibilityConfiguration.MaximumSolicitation;
            }
            if (cmsDefaultEligibilityConfiguration.FullTimeDefinitionType_Id.HasValue)
            {
                eligibilityConfigurationDto.FullTimeDefinitionType_Id = cmsDefaultEligibilityConfiguration.FullTimeDefinitionType_Id;
            }
            if (cmsDefaultEligibilityConfiguration.IssueLimitMaximum.HasValue)
            {
                eligibilityConfigurationDto.IssueLimitMaximum = cmsDefaultEligibilityConfiguration.IssueLimitMaximum;
            }
            if (cmsDefaultEligibilityConfiguration.ParticipationLimit.HasValue)
            {
                eligibilityConfigurationDto.ParticipationLimit = cmsDefaultEligibilityConfiguration.ParticipationLimit;
            }
            if (cmsDefaultEligibilityConfiguration.MinimumBenefitAmount.HasValue)
            {
                eligibilityConfigurationDto.MinimumBenefitAmount = cmsDefaultEligibilityConfiguration.MinimumBenefitAmount;
            }
            if (cmsDefaultEligibilityConfiguration.StandAloneRPPMaximumAge.HasValue)
            {
                eligibilityConfigurationDto.StandAloneRPPMaximumAge = cmsDefaultEligibilityConfiguration.StandAloneRPPMaximumAge;
            }
            if (cmsDefaultEligibilityConfiguration.CAIssueLimitMaximum.HasValue && isCACaseEligibilityConfiguration)
            {
                eligibilityConfigurationDto.CAIssueLimitMaximum = cmsDefaultEligibilityConfiguration.CAIssueLimitMaximum;
                eligibilityConfigurationDto.IssueLimitMaximum = cmsDefaultEligibilityConfiguration.CAIssueLimitMaximum;
            }
            if (cmsDefaultEligibilityConfiguration.CAParticipationLimit.HasValue && isCACaseEligibilityConfiguration)
            {
                eligibilityConfigurationDto.CAParticipationLimit = cmsDefaultEligibilityConfiguration.CAParticipationLimit;
                eligibilityConfigurationDto.ParticipationLimit = cmsDefaultEligibilityConfiguration.CAParticipationLimit;
            }
            // value for isCAStateType variable during loading default configuration will be false so that CAIssueLimitMaximum will not be overriden by IssueLimitMaximum
            //when overriding values from "Class Eligibility Settings" isCAStateType variable value will be true so that CAIssueLimitMaximum will be overriden by IssueLimitMaximum
            if (cmsDefaultEligibilityConfiguration.IssueLimitMaximum.HasValue && isCAStateType)
            {
                eligibilityConfigurationDto.CAIssueLimitMaximum = cmsDefaultEligibilityConfiguration.IssueLimitMaximum;
            }
            else if (isCAStateType)
            {
                eligibilityConfigurationDto.IssueLimitMaximum = eligibilityConfigurationDto.CAIssueLimitMaximum;
            }
            if (cmsDefaultEligibilityConfiguration.ParticipationLimit.HasValue && isCAStateType)
            {
                eligibilityConfigurationDto.CAParticipationLimit = cmsDefaultEligibilityConfiguration.ParticipationLimit;
            }
            else if (isCAStateType)
            {
                eligibilityConfigurationDto.ParticipationLimit = eligibilityConfigurationDto.CAParticipationLimit;
            }

            if (cmsDefaultEligibilityConfiguration.EligibilityConfigurationbyStates.Any())
            {
                foreach (var eligibilityConfigurationByState in cmsDefaultEligibilityConfiguration.EligibilityConfigurationbyStates)
                {
                    var eligibilityConfigurationByStateDto = CreateEligibilityConfigurationByStateDto(eligibilityConfigurationByState);
                    eligibilityConfigurationDto.EligibilityConfigurationbyStates.Add(eligibilityConfigurationByStateDto);
                }
            }

            Log.TraceFormat("-CreateEligibilityConfigurationDto");
        }

        private EligibilityConfigurationbyStateDto CreateEligibilityConfigurationByStateDto(EligibilityConfigurationbyState eligibilityConfigurationByState)
        {
            var eligibilityConfigurationbyStateDto = new EligibilityConfigurationbyStateDto();
            eligibilityConfigurationbyStateDto.EligibilityConfigurationbyStateId = eligibilityConfigurationByState.Id;
            eligibilityConfigurationbyStateDto.EligibilityConfigurationId = eligibilityConfigurationByState.EligibilityConfiguration.Id;
            eligibilityConfigurationbyStateDto.StateTypeId = (int)eligibilityConfigurationByState.StateType;
            if (eligibilityConfigurationByState.BenefitPeriodType.HasValue)
            {
                eligibilityConfigurationbyStateDto.BenefitPeriodTypeId = (int)eligibilityConfigurationByState.BenefitPeriodType;
            }
            if (eligibilityConfigurationByState.MaximumAge.HasValue)
            {
                eligibilityConfigurationbyStateDto.MaximumAge = eligibilityConfigurationByState.MaximumAge;
            }
            return eligibilityConfigurationbyStateDto;
        }

        private void CreateEligibilityConfiguration(EligibilityConfigurationDto request, Case cmsCase, PlanDesignRequest cmsPDR, PlanDesignRequestClass cmsPDRClass, EligibilityConfiguration cmsEligibilityConfiguration)
        {
            Log.TraceFormat("+CreateEligibilityConfiguration");
            _eligibilityConfigurationManagerValidator.ValidateClassEligibility(request);
            cmsEligibilityConfiguration.Case = cmsCase;
            cmsEligibilityConfiguration.PlanDesignRequest = cmsPDR;
            cmsEligibilityConfiguration.PlanDesignRequestClass = cmsPDRClass;
            StateTypeEnum? contractState = cmsEligibilityConfiguration.PlanDesignRequestClass?.PlanDesignRequest?.Case?.CaseUnderwritingRequests.FirstOrDefault()?.StateType;
            bool isCAState = contractState == StateTypeEnum.CA ? true : false;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsDefaultEligibilityConfiguration = unitOfWork.Repository<EligibilityConfiguration>().Linq().FirstOrDefault(e => e.Case == null && e.PlanDesignRequest == null && e.PlanDesignRequestClass == null);

                if (request.IssueLimitMaximum==null)
                {
                    request.IssueLimitMaximum = 0;
                }
                if (request.ParticipationLimit == null)
                {
                    request.ParticipationLimit = 0;
                }

                if (request.MinimumAge.HasValue)
                {
                    cmsEligibilityConfiguration.MinimumAge = request.MinimumAge;
                }
                if (request.FullTimeDefinitionType_Id.HasValue)
                {
                    cmsEligibilityConfiguration.FullTimeDefinitionType_Id = request.FullTimeDefinitionType_Id;
                }
                if (request.MaximumAge.HasValue)
                {
                    cmsEligibilityConfiguration.MaximumAge = request.MaximumAge;
                }
                if (request.MaximumGSIAmount.HasValue)
                {
                    cmsEligibilityConfiguration.MaximumGSIAmount = request.MaximumGSIAmount;
                }
                if (request.MinimumInsurableIncomeAmount.HasValue)
                {
                    if (request.MinimumInsurableIncomeAmount.Value == 0)
                    {
                        cmsEligibilityConfiguration.MinimumInsurableIncomeAmount = null;
                    }
                    else
                    {
                        cmsEligibilityConfiguration.MinimumInsurableIncomeAmount = request.MinimumInsurableIncomeAmount;
                    }
                }
                if (request.EmployerPaidMinimumInsurableIncomeAmount.HasValue)
                {
                    if (request.EmployerPaidMinimumInsurableIncomeAmount.Value == 0)
                    {
                        cmsEligibilityConfiguration.EmployerPaidMinimumInsurableIncomeAmount = null;
                    }
                    else
                    {
                        cmsEligibilityConfiguration.EmployerPaidMinimumInsurableIncomeAmount = request.EmployerPaidMinimumInsurableIncomeAmount;
                    }
                }
                if (request.MaximumSolicitation.HasValue)
                {
                    if (request.MaximumSolicitation.Value == 0)
                    {
                        cmsEligibilityConfiguration.MaximumSolicitation = null;
                    }
                    else
                    {
                        cmsEligibilityConfiguration.MaximumSolicitation = request.MaximumSolicitation;
                    }
                }
                if (request.IssueLimitMaximum.HasValue)
                {
                    if (request.IssueLimitMaximum.Value == 0 && !isCAState)
                    {
                        cmsEligibilityConfiguration.IssueLimitMaximum = cmsDefaultEligibilityConfiguration.IssueLimitMaximum;
                    }
                    else if(request.IssueLimitMaximum.Value == 0 && isCAState)
                    {
                        cmsEligibilityConfiguration.IssueLimitMaximum = cmsDefaultEligibilityConfiguration.CAIssueLimitMaximum;
                    }
                    else
                    {
                        cmsEligibilityConfiguration.IssueLimitMaximum = request.IssueLimitMaximum;
                    }
                }
                if (request.ParticipationLimit.HasValue)
                {
                    if(request.ParticipationLimit == 0 && !isCAState)
                    {
                        cmsEligibilityConfiguration.ParticipationLimit = cmsDefaultEligibilityConfiguration.ParticipationLimit;
                    }
                    else if(request.ParticipationLimit == 0 && isCAState)
                    {
                        cmsEligibilityConfiguration.ParticipationLimit = cmsDefaultEligibilityConfiguration.CAParticipationLimit;                       
                    }
                    else
                    {
                        cmsEligibilityConfiguration.ParticipationLimit = request.ParticipationLimit;
                    }
                }
                if (request.MinimumBenefitAmount.HasValue)
                {
                    if (request.MinimumBenefitAmount == 0)
                    {
                        cmsEligibilityConfiguration.MinimumBenefitAmount = null;
                    }
                    else
                    {
                        cmsEligibilityConfiguration.MinimumBenefitAmount = request.MinimumBenefitAmount;
                    }
                }
                if (request.StandAloneRPPMaximumAge.HasValue)
                {
                    cmsEligibilityConfiguration.StandAloneRPPMaximumAge = request.StandAloneRPPMaximumAge;
                }
            }
            Log.TraceFormat("-CreateEligibilityConfiguration");
        }

    }
}
