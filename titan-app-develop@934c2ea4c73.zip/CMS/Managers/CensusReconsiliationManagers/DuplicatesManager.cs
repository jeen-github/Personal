﻿using CMS.Interfaces.DataAccess;
using Logger.Static;
using System.Collections.Generic;
using CMS.Interfaces.Managers.CensusReconciliationManagers;
using System;
using System.Linq;

namespace CMS.Managers.CensusReconsiliationManagers
{
    public class DuplicatesManager : IDuplicatesManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public DuplicatesManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public List<NewCensusDuplicate> GetNewCensusDuplicates(int caseId)
        {
            return null;
        }

        public void Delete(int[] participantIds)
        {
            try
            {
                Log.TraceFormat("+Census Reconciliation Delete Duplicates");
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    string participantReconciliationIds = string.Join(",", participantIds);

                    object[] parameters = new object[1];
                    parameters[0] = participantReconciliationIds;

                    unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_CR_DeleteDuplicates] :@ParticipantReconciliationIds", parameters);
                    unitOfWork.Commit();

                    Log.TraceFormat("-Census Reconciliation Delete Duplicates");
                  
                }

            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while Deleting Duplicates", ex);
                throw;
            }
        }

        public void MarkAsNotDuplicate(int[] participantIds)
        {

            try
            {
                Log.TraceFormat("+Census Reconciliation UnMatch Duplicates");
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    string participantReconciliationIds = string.Join(",", participantIds);

                    object[] parameters = new object[1];
                    parameters[0] = participantReconciliationIds;

                    unitOfWork.RunSqlQueryWithTimeOut<int?>("EXEC [cms].[USP_CR_UnMatchDuplicates] :@ParticipantReconciliationIds", 300, parameters);
                    unitOfWork.Commit();

                    Log.TraceFormat("-Census Reconciliation UnMatch Duplicates");

                }

            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while Unmatching Duplicates", ex);
                throw;
            }
        }

        public bool CheckDuplicatesResolved(int censusId)
        {
               Log.TraceFormat("+Census Reconciliation Check Duplicates Resolved");              

                int? duplicateCount = null;
                try
                {
                    using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                    {
                        duplicateCount = unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_CR_CheckDuplicatesResolved] @NewCensus_Id = " + censusId.ToString(), 300).FirstOrDefault();
                        unitOfWork.Commit();
                    }
                    Log.TraceFormat("-Census Reconciliation Check Duplicates Resolved");
                    if (duplicateCount == 0 ) return true; else return false;
                }
                
            
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while Checking for Duplicates", ex);
                throw;
            }
        }
    }    
}