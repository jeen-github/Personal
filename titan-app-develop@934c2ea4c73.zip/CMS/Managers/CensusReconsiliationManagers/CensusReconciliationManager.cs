﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CensusManagers;
using CMS.Model.Entities;
using Logger.Static;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.Managers.CensusReconciliationManagers;
using Common.Exceptions;
using System;

namespace CMS.Managers.CensusReconsiliationManagers
{

    public class CensusReconciliationManager : ICensusReconciliationManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public CensusReconciliationManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public List<CensusDto> GetCensusReconciliationInformation(int caseId)
        {
            Log.TraceFormat("+GetCensusReconciliationInformation");

            var censusReconsiliationDto = new List<CensusDto>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {                
                var pdrSoldClass = unitOfWork.Repository<PDRSoldClass>().Linq().Where(p => p.PlanDesignRequest.Case.Id == caseId && p.IsActive);

                if (pdrSoldClass != null)
                {
                    var soldPdrIds = pdrSoldClass.Select(i => i.PlanDesignRequest.Id);
                    foreach (var soldPdrId in soldPdrIds)
                    {
                        var availableCensusList = unitOfWork.Repository<Census>().Linq()
                          .Where(t => ((t.PlanDesignRequest.Id == soldPdrId))
                                    && (((t.ReconciliationStatus ?? 0) != 7) && ((t.ReconciliationStatus ?? 0) != 8))); //Including Existing Census & Exclude Made Current & Removed

                        foreach (var availableCensus in availableCensusList)
                        {
                            CensusDto CensusDto = new CensusDto();
                            CensusDto.CaseId = availableCensus.Case.Id;
                            CensusDto.CensusId = availableCensus.Id;
                            CensusDto.ReceivedDateTime = availableCensus.ReceivedDateTime;
                            CensusDto.IsActiveIndicator = availableCensus.IsActiveIndicator;
                            CensusDto.ReconciliationStatus = availableCensus.ReconciliationStatus;
                            censusReconsiliationDto.Add(CensusDto);
                        }                     
                    }
                }
            }

            Log.TraceFormat("-GetCensusReconciliationInformation");
            return censusReconsiliationDto;
        }

        public bool Reconcile(int caseId, int censusId)
        {
            //TODO: copy all the participants from Existing Census and the New Census to the ParticipantReconciliation table            
            //Get Current Census, if no current census, throw errror
            //Copy participant data for New Census and CurrentCensus
                       
            try
            {
                Log.TraceFormat("+Reconcile Census");               
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var currentPdrId = unitOfWork.Repository<Census>().Linq().Where(i => i.Id == censusId).Select(i => i.PlanDesignRequest.Id).FirstOrDefault();
                    var currentCensus = unitOfWork.Repository<Census>().Linq().FirstOrDefault(c => c.Case.Id == caseId && c.IsActiveIndicator && c.PlanDesignRequest.Id == currentPdrId);

                    if (currentCensus == null)
                    {
                        throw new ValidationException("Current Census is not found for this case!");
                    }

                    int currentCensusId = currentCensus.Id;

                    object[] parameters = new object[2];
                    parameters[0] = censusId;
                    parameters[1] = currentCensusId;

                    unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_CR_CopyParticipantDataForReconciliation] :@NewCensus_Id, :@CurrentCensus_Id", parameters);
                    unitOfWork.Commit();

                    Log.TraceFormat("-Reconcile Census");
                    return true;
                }
               
            }
            catch (Exception ex)
            {                
                Log.ErrorFormat(string.Format("ERROR occured while starting Census Reconciliation, CaseId: {0} CensusId: {1}", caseId, censusId), ex);
                throw;
            }
        }
       
        public bool MakeCurrent(int caseId, int censusId, int userId)
        {
            //TODO: delete the NEW CENSUS and ALL its participants from the Participant table
            //TODO: update the EXISTING participants with the data from ParticipantReconciliation table
            //TODO: delete all the data from ParticipantReconciliation table belonging to this caseId

            try
            {
                Log.TraceFormat("+Census - Make Current");
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    var currentPdrId = unitOfWork.Repository<Census>().Linq().Where(i => i.Id == censusId).Select(i => i.PlanDesignRequest.Id).FirstOrDefault();                    
                    var currentCensus = unitOfWork.Repository<Census>().Linq().FirstOrDefault(c => c.Case.Id == caseId && c.IsActiveIndicator && c.PlanDesignRequest.Id == currentPdrId);

                    if (currentCensus == null)
                    {
                        throw new ValidationException("Current Census is not found for this case!");
                    }
                    
                    bool isReconcileCompleted = CheckReconcileCompleted(censusId);
                    
                    if (!isReconcileCompleted)
                    {
                        throw new ValidationException("Please complete census reconciliation.!");
                    }                                       

                    object[] parameters = new object[2];
                    parameters[0] = censusId;
                    parameters[1] = userId;

                    ////TODO : To Confirm with Audit Log & History Data
                    unitOfWork.RunSqlQueryWithTimeOut<int?>("EXEC [cms].[USP_CR_MakeCurrent] :@NewCensus_Id, :@TitanUserId", 900, parameters);
                    unitOfWork.Commit();

                    Log.TraceFormat("-Census - Make Current");

                    return true;
                }

            }
            catch (Exception ex)
            {                
                Log.ErrorFormat(string.Format("ERROR occured while updating Current Census, CaseId: {0} CensusId: {1} UserId: {2}", caseId, censusId, userId), ex);
                throw;
            }
        }

        private bool CheckReconcileCompleted(int censusId)
        {
            Log.TraceFormat("+Census Reconciliation Check Reconcile Completed");

            int? pendingRowsCount = null;
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    pendingRowsCount = unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_CR_CheckReconcileCompleted] @NewCensus_Id = " + censusId.ToString(), 150).LastOrDefault();
                    unitOfWork.Commit();
                }
                Log.TraceFormat("-Census Reconciliation Check Reconcile Completed");
                if (pendingRowsCount == 0) return true; else return false;
            }


            catch (Exception ex)
            {                
                Log.ErrorFormat(string.Format("ERROR occured while Checking for Reconcile Completed, CensusId: {0}", censusId), ex);
                throw;
            }
        }

        public void RemoveSubmission(int censusId)
        {
            //TODO: delete the NEW CENSUS and ALL its participants from the Participant table
            
            //Delete the details from Participant Reconciliation & change the status of the new Census
            try
            {
                Log.TraceFormat("+Remove Census Submission");
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    object[] parameters = new object[1];
                    parameters[0] = censusId; //New Census Id                  

                    unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_CR_RemoveSubmission] :@NewCensus_Id", parameters);
                    unitOfWork.Commit();

                    Log.TraceFormat("-Remove Census Submission");                   
                }

            }
            catch (Exception ex)
            {                
                Log.ErrorFormat(string.Format("ERROR occured while removing Census Submission, CensusId: {0}", censusId), ex);
                throw;
            }

        }
    }
}
