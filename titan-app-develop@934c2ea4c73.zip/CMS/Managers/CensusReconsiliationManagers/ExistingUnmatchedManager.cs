﻿using CMS.Interfaces.DataAccess;
using Logger.Static;
using System.Collections.Generic;
using CMS.Interfaces.Managers.CensusReconciliationManagers;
using System;
using Common.Utilities;
using System.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;

namespace CMS.Managers.CensusReconsiliationManagers
{
    public class ExistingUnmatchedManager : IExistingUnmatchedManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public ExistingUnmatchedManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public void MakeInEligible(List<CensusFieldChangesDTO> participants)
        {

            try
            {
                Log.TraceFormat("+Census Reconciliation - MakeInEligible - Existing Unmatched Participants");
                if (participants.Count > 0)
                {
                    string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");
                    DataTable participantTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(participants));
                    using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
                    {
                        SqlCommand command = sqlConnection.CreateCommand();
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "[cms].[USP_CR_MakeInEligibleExistingUnMatched]";
                        command.CommandTimeout = 300;

                        SqlParameter parameter1 = new SqlParameter();
                        parameter1.ParameterName = "@ParticipantChanges";
                        parameter1.SqlDbType = SqlDbType.Structured;
                        parameter1.Value = participantTable;
                        command.Parameters.Add(parameter1);

                        sqlConnection.Open();
                        int numberOfRowsUpdated = command.ExecuteNonQuery();
                    }
                    Log.TraceFormat("-Census Reconciliation - MakeInEligible - Existing Unmatched Participants");

                }

            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while making Existing Unmatched Participants InEligible", ex);
                throw;
            }
        }

        public void KeepActive(List<CensusFieldChangesDTO> participants)
        {

            try
            {
                Log.TraceFormat("+Census Reconciliation - Keep Active Existing - Unmatched Participants");
                if (participants.Count > 0)
                {
                string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");
                DataTable participantTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(participants));
                using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
                {
                    SqlCommand command = sqlConnection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "[cms].[USP_CR_KeepActiveExistingUnMatched]";

                    SqlParameter parameter1 = new SqlParameter();
                    parameter1.ParameterName = "@ParticipantChanges";
                    parameter1.SqlDbType = SqlDbType.Structured;
                    parameter1.Value = participantTable;
                    command.Parameters.Add(parameter1);

                    sqlConnection.Open();
                    int numberOfRowsUpdated = command.ExecuteNonQuery();
                }
               Log.TraceFormat("-Census Reconciliation - Keep Existing - Unmatched Participants");
               }

            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while making Existing Unmatched Participants Inactive", ex);
                throw;
            }
        }
    }
}

