﻿using CMS.Interfaces.DataAccess;
using Logger.Static;
using System.Collections.Generic;
using CMS.Interfaces.Managers.CensusReconciliationManagers;
using System;
using System.Linq;
using Common.Utilities;
using System.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;

namespace CMS.Managers.CensusReconsiliationManagers
{
    public class PartialMatchesManager : IPartialMatchesManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public PartialMatchesManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public List<PartialMatch> GetPartialMatches(int caseId)
        {
            return null;
        }

        public void ConfirmMatch(List<CensusFieldChangesDTO> participants)
        {

            try

            {
                if (participants.Count > 0)
                {
                  string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");
                   DataTable participantTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(participants));
                   Log.TraceFormat("+Census Reconciliation - Confirm Partial Matches");
                    using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
                    {
                        SqlCommand command = sqlConnection.CreateCommand();
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "[cms].[USP_CR_ConfirmPartialMatch]";
                        command.CommandTimeout = 300;

                        SqlParameter parameter1 = new SqlParameter();
                        parameter1.ParameterName = "@ParticipantPartialChanges";
                        parameter1.SqlDbType = SqlDbType.Structured;
                        parameter1.Value = participantTable;
                        command.Parameters.Add(parameter1);

                        sqlConnection.Open();
                        int numberOfRowsUpdated = command.ExecuteNonQuery();
                    }
                    Log.TraceFormat("-Census Reconciliation - Confirm Partial Matches");

                }              

            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while Confirming Partial Matches", ex);
                throw;
            }
        }

        public void Unmatch(List<CensusFieldChangesDTO> participants)
        {

            try
            {
                if (participants.Count > 0)
                {
                    string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");
                    DataTable participantTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(participants));
                    Log.TraceFormat("+Census Reconciliation UnMatch Partial Matches");
                    using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
                    {
                        SqlCommand command = sqlConnection.CreateCommand();
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "[cms].[USP_CR_UnMatchPartialMatch]";
                        command.CommandTimeout = 300;

                        SqlParameter parameter1 = new SqlParameter();
                        parameter1.ParameterName = "@ParticipantPartialChanges";
                        parameter1.SqlDbType = SqlDbType.Structured;
                        parameter1.Value = participantTable;
                        command.Parameters.Add(parameter1);

                        sqlConnection.Open();
                        int numberOfRowsUpdated = command.ExecuteNonQuery();
                    }
                    Log.TraceFormat("-Census Reconciliation UnMatch Partial Matches");

                }                

            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while UnMatch Partial Matches", ex);
                throw;
            }
        }

        public bool CheckPartialMatchesResolved(int censusId)
        {
            Log.TraceFormat("+Census Reconciliation Check Partial Matches Resolved");

            int? partialMatchesCount = null;
            try
            {
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    partialMatchesCount = unitOfWork.RunSqlQuery<int?>("EXEC [cms].[USP_CR_CheckPartialMatchesResolved] @NewCensus_Id = " + censusId.ToString(), 300).FirstOrDefault();
                    unitOfWork.Commit();
                }
                Log.TraceFormat("-Census Reconciliation Check Partial Matches Resolved");
                if (partialMatchesCount == 0) return true; else return false;
            }


            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while Checking for Partial Matches", ex);
                throw;
            }
        }


    }
}