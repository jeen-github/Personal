﻿using CMS.Interfaces.DataAccess;
using Logger.Static;
using System.Collections.Generic;
using CMS.Interfaces.Managers.CensusReconciliationManagers;
using System;
using System.Data;
using System.Data.SqlClient;
using Common.Utilities;
using Newtonsoft.Json;
using System.Linq;
using System.Collections;

namespace CMS.Managers.CensusReconsiliationManagers
{
    public class MatchWithChangesManager : IMatchWithChangesManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;       

        public MatchWithChangesManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }
                
        public void KeepNewCensus(int[] participantIds, int[] linkParticipantIds)
        {

            try
            {
                Log.TraceFormat("+Census Reconciliation - Keep New Census");
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    string participantReconciliationIds = string.Join(",", participantIds);
                    string LinkParticipantReconciliationIds = string.Join(",", linkParticipantIds);

                    object[] parameters = new object[2];
                    parameters[0] = participantReconciliationIds;
                    parameters[1] = LinkParticipantReconciliationIds;

                    unitOfWork.RunSqlQueryWithTimeOut<int?>("EXEC [cms].[USP_CR_KeepNewCensusRecord] :@CurrentParticipantReconciliationIds, :@NewParticipantReconciliationIds", 300, parameters);
                    unitOfWork.Commit();

                    Log.TraceFormat("-Census Reconciliation - Keep New Census");

                }

            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while Overwriting with New Census", ex);
                throw;
            }
        }

        public void KeepExistingCensus(int[] participantIds, int[] linkParticipantIds)
        {

            try
            {
                Log.TraceFormat("+Census Reconciliation - Keep Existing Census");
                using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
                {
                    string participantReconciliationIds = string.Join(",", participantIds);
                    string LinkParticipantReconciliationIds = string.Join(",", linkParticipantIds);

                    object[] parameters = new object[2];
                    parameters[0] = participantReconciliationIds;
                    parameters[1] = LinkParticipantReconciliationIds;

                    unitOfWork.RunSqlQueryWithTimeOut<int?>("EXEC [cms].[USP_CR_KeepExistingCensusRecord] :@CurrentParticipantReconciliationIds, :@NewParticipantReconciliationIds", 300, parameters);
                    unitOfWork.Commit();

                    Log.TraceFormat("-Census Reconciliation - Keep Existing Census");

                }

            }
            catch (Exception ex)
            {
                Log.ErrorFormat("ERROR occured while Keep Existing Census action", ex);
                throw;
            }
        }        

        public void MatchWithChangesAction(int actionType, int[] participantIds, int[] linkParticipantIds, List<CensusFieldChangesDTO> participants)
        {  
            if (participants.Count > 0)
            {
                Log.TraceFormat("+Census Reconciliation - Keep Census Fields");
                string CMSDatabaseConnection = AppSettingsReader.ReadAppSettingValue("CMSDatabaseConnection");
                DataTable participantTable = DataTableMapper.GetDataTable(JsonConvert.SerializeObject(participants));

                using (var sqlConnection = new SqlConnection(CMSDatabaseConnection))
                {
                    SqlCommand command = sqlConnection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "[cms].[USP_CR_KeepCensusFieldValues]";
                    command.CommandTimeout = 300;

                    SqlParameter parameter1 = new SqlParameter();
                    parameter1.ParameterName = "@KeepMode";
                    parameter1.SqlDbType = SqlDbType.Int;
                    parameter1.Value = actionType;
                    command.Parameters.Add(parameter1);

                    SqlParameter parameter2 = new SqlParameter();
                    parameter2.ParameterName = "@ParticipantChangesTableVariable";
                    parameter2.SqlDbType = SqlDbType.Structured;
                    parameter2.Value = participantTable;
                    command.Parameters.Add(parameter2);

                    sqlConnection.Open();
                    int numberOfRowsUpdated = command.ExecuteNonQuery();
                }

                Log.TraceFormat("-Census Reconciliation - Keep Census Fields");
            }
            
        }

        public Object[] GetMatchWithoutChanges(int? censusId)
        {
            Log.TraceFormat("+GetMatchWithoutChanges");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var matchWithoutChangesStoredProcName = "[cms].[USP_CR_GetMatchWithoutChanges]  @NewCensus_Id = " + censusId.ToString();
                List<Object> allColumnMatches = unitOfWork.RunSqlQuery<Object>("EXEC " + matchWithoutChangesStoredProcName, 300).ToList();
                Object[] matchWithoutChanges = allColumnMatches.ToArray();

                Log.TraceFormat("-GetMatchWithoutChanges");

                return matchWithoutChanges;
            }        
        }
    }
}
