﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.ITAdminManagers;
using CMS.Model.Entities;

namespace ITAdminManagers
{
    public class AdminGaMessageHistoryManager : IAdminGaMessageHistoryManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public AdminGaMessageHistoryManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public List<AdminGaMessageDto> GetMessages(int requestedPage, int pageFactor )
        {
            var gaMsgDto = new List<AdminGaMessageDto>(); 

            int startingRow = ((requestedPage*pageFactor) - (pageFactor));

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                gaMsgDto = unitOfWork.Repository<GaMessageHistory>().Linq()
                    .Select(t => new AdminGaMessageDto
                    {
                        Id = t.Id,
                        ReceivedDateTime = t.ReceivedDateTime,
                        MessageType =t.MessageType,
                        GaCaseId = t.GaCaseId,
                        MessageId = t.MessageId,
                        MessageBody = t.MessageBody,
                        IsSuccessIndicator = t.IsSuccessIndicator,
                        ErrorMessage = t.ErrorMessage
                    })
                    .OrderByDescending(t => t.ReceivedDateTime)
                    .Skip(startingRow)
                    .Take(pageFactor)
                    .ToList();
            }

            return gaMsgDto;
        }
        public int GetCountOfMessages()
        {

            int theCount = 0;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {

                theCount = unitOfWork.Repository<GaMessageHistory>().Linq()
                    .Select(t => t.Id).Count();
            }

            return theCount;
        }

    }
}