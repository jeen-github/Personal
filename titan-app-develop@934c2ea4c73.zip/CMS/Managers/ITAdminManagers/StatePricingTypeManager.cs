﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Logger.Static;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.CaseManagers;
using CMS.Interfaces.Managers.ITAdminManagers;
using CMS.Interfaces.Managers.SecurityManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using Common.Exceptions;

namespace ITAdminManagers
{
    public class StatePricingTypeManager : IStatePricingTypeManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        public StatePricingTypeManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }
        public List<string> GetPricingTypes()
        {
            Log.TraceFormat("+GetPricingTypes");
            var lstPricingTypes = Enum.GetNames(typeof(PricingTypeEnum)).ToList();
            Log.TraceFormat("-GetPricingTypes");
            return lstPricingTypes;
        }
        public List<StateApprovalDto> GetAllStatesforPricingType(int PricingTypeId)
        {
            Log.TraceFormat("+GetAllStatesforPricingType Pricing Type ={0}", PricingTypeId);
            var lstStateApproval = new List<StateApprovalDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var lstStateApprovalMlRepricing = unitOfWork.Repository<PricingApprovedStates>().Linq()
                    .Where(c => c.PricingType == (PricingTypeEnum)PricingTypeId).ToList();
                
                foreach (PricingApprovedStates statesforPricingType in lstStateApprovalMlRepricing)
                {
                    StateApprovalDto StateApprovaldTo = new StateApprovalDto
                    {
                        PricingType_Id = PricingTypeId,
                        IsActive = statesforPricingType.IsActive,
                        IsApproved = statesforPricingType.IsApproved,
                        StateCode = statesforPricingType.StateCode
                    };
                    lstStateApproval.Add(StateApprovaldTo);
                }
            }
            Log.TraceFormat("-GetStatesforPricingTypes");
            return lstStateApproval;
        }
        public bool SaveStatesforPricingType(List<StateApprovalDto> updatedStatePricingTypes, int pricingTypeId, string updatedBy)
        {
            Log.TraceFormat("+SaveStatesforPricingType");
            var lstStateApproval = GetAllStatesforPricingType(pricingTypeId);

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var pricingApprovedStates = unitOfWork.Repository<PricingApprovedStates>().Linq();
                foreach (StateApprovalDto StatePricingType in updatedStatePricingTypes)
                {
                    PricingApprovedStates pricingapprovedstate = pricingApprovedStates.Where(c => c.PricingType == (PricingTypeEnum)pricingTypeId
                                && c.StateCode == StatePricingType.StateCode).FirstOrDefault();

                    if(pricingapprovedstate.IsApproved != StatePricingType.IsApproved)
                    {
                        //If the approval do not match the database content, we need to update the database.
                        pricingapprovedstate.IsApproved = StatePricingType.IsApproved;
                        pricingapprovedstate.ApprovedDate = System.DateTime.Now;
                        pricingapprovedstate.UpdatedBy = updatedBy;
                        unitOfWork.Repository<PricingApprovedStates>().Save(pricingapprovedstate);
                        Log.TraceFormat("ML Repricing changed for state {0} to {1}", pricingapprovedstate.StateCode, StatePricingType.IsApproved);
                    }
                }
                unitOfWork.Commit();
            }
            
            Log.TraceFormat("-SaveStatesforPricingType");
            return true;
        }
        public bool IsStateApprovedforPricingType(int stateTypeId, int pricingTypeId)
        {
           // Log.TraceFormat("+isStateApprovedforPricingType Pricing Type = {0} and State Type Id = {1}", pricingTypeId, stateTypeId);
            bool isStateApprovedforPricingType = false;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var PricingApprovedState = unitOfWork.Repository<PricingApprovedStates>().Linq()
                    .Where(c => c.StateTypeId == stateTypeId 
                    && c.PricingType == (PricingTypeEnum)pricingTypeId
                    && c.IsActive.Equals(true)).FirstOrDefault();

                if (PricingApprovedState != null)
                {
                    isStateApprovedforPricingType =  PricingApprovedState.IsApproved;
                }
            }
          //  Log.TraceFormat("-isStateApprovedforPricingType");
            return isStateApprovedforPricingType;
        }
        public bool IsStateApprovedforPricingType(string stateCode, int pricingTypeId)
        {
            //Log.TraceFormat("+isStateApprovedforPricingType Pricing Type = {0} and State Code = {1}", pricingTypeId, stateCode);
            bool isStateApprovedforPricingType = false;
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var PricingApprovedState = unitOfWork.Repository<PricingApprovedStates>().Linq()
                    .Where(c => c.StateCode == stateCode
                    && c.PricingType == (PricingTypeEnum)pricingTypeId
                    && c.IsActive.Equals(true)).FirstOrDefault();

                if (PricingApprovedState != null)
                {
                    isStateApprovedforPricingType = PricingApprovedState.IsApproved ;
                }
            }

            //Log.TraceFormat("-isStateApprovedforPricingType");
            return isStateApprovedforPricingType;
        }

    }
}