﻿using System;
using System.Collections.Generic;
using System.Linq;
using Logger.Static;
using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.ITAdminManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Guardian.Core.Entities.Product.Enums;

namespace ITAdminManagers
{
    public class CompactStateManager : ICompactStateManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;
        public CompactStateManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }        
        public List<CompactStateDto> GetCompactStatesforPricingType(int pricingTypeId)
        {
            Log.TraceFormat("+GetCompactStatesforPricingType Pricing Type = {0}", (PricingTypeEnum)pricingTypeId);
            var lstCompactState = new List<CompactStateDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var lstCompactApprovedStates = unitOfWork.Repository<CompactApprovedStates>().Linq()
                    .Where(c => c.PricingType == (PricingTypeEnum)pricingTypeId).ToList();

                lstCompactState = lstCompactApprovedStates.Select(c => new CompactStateDto()
                {
                    PricingTypeId = pricingTypeId,
                    IsActive = c.IsActive,
                    IsApproved = c.IsApproved,
                    StateTypeId = c.StateType.Id,
                    StateTypeCode = c.StateType.StateCode
                }).ToList();
            }
            Log.TraceFormat("-GetCompactStatesforPricingType");
            return lstCompactState;
        }

        public bool SaveCompactStatesApproval(List<CompactStateDto> updatedCompactStateTypes, int pricingTypeId, string updatedBy)
        {
            Log.TraceFormat("+SaveCompactStatesApproval Pricing Type = {0}", (PricingTypeEnum)pricingTypeId);

            var lstStateApproval = GetCompactStatesforPricingType(pricingTypeId);
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var compactStates = unitOfWork.Repository<CompactApprovedStates>().Linq();
                foreach (CompactStateDto compactStateType in updatedCompactStateTypes)
                {
                    CompactApprovedStates compactgapprovedstate = compactStates.Where(c => c.PricingType == (PricingTypeEnum)pricingTypeId
                                && c.StateType.StateCode == compactStateType.StateTypeCode).FirstOrDefault();

                    if (compactgapprovedstate.IsApproved != compactStateType.IsApproved)
                    {
                        //If the approval do not match the database content, we need to update the database.
                        compactgapprovedstate.IsApproved = compactStateType.IsApproved;
                        compactgapprovedstate.UpdatedDate = System.DateTime.Now;
                        compactgapprovedstate.UpdatedBy = updatedBy;
                        unitOfWork.Repository<CompactApprovedStates>().Save(compactgapprovedstate);
                        Log.TraceFormat("Compact State Approval changed for state {0} to {1}", compactgapprovedstate.StateType.StateCode, compactStateType.IsApproved);
                    }
                }
                unitOfWork.Commit();
            }

            Log.TraceFormat("-SaveCompactStatesApproval");
            return true;
        }

        public List<int> GetNonCompactStates(int pricingTypeId = 1)
        {
            //Log.TraceFormat("+GetNonCompactStates Pricing Type = {0}", (PricingTypeEnum)pricingTypeId);
            List<int> nonCompactStateIds = new List<int>();  

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                nonCompactStateIds = unitOfWork.Repository<CompactApprovedStates>().Linq()
                .Where(i => i.PricingType == (PricingTypeEnum)pricingTypeId && i.IsActive.Equals(true) && i.IsApproved.Equals(false))
                .Select(a => a.StateType.Id).ToList();
            }

            //Log.TraceFormat("-GetNonCompactStates");

            return nonCompactStateIds;
        }

        public List<int> GetCompactStates(int pricingTypeId = 1)
        {
           // Log.TraceFormat("+GetCompactStates Pricing Type = {0}", (PricingTypeEnum)pricingTypeId);
            List<int> compactStateIds = new List<int>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                compactStateIds = unitOfWork.Repository<CompactApprovedStates>().Linq()
                .Where(i => i.PricingType == (PricingTypeEnum)pricingTypeId && i.IsActive.Equals(true) && i.IsApproved.Equals(true))
                .Select(a => a.StateType.Id).ToList();
            }

           // Log.TraceFormat("-GetCompactStates");
            return compactStateIds.ToList();
        }

    }
}