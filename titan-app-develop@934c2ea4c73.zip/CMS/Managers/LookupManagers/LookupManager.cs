﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.LookupManagers;
using CMS.Model.BaseEntities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using CMS.Model.Entities;
using CMS.Model.Enums;
using CMS.Model.Extensions;
using CMS.Interfaces.Managers.CaseManagers;
namespace CMS.Managers.LookupManagers
{
    public class LookupManager : ILookupManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public LookupManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public List<LookupMetadataDto> GetLookupsMetadata()
        {
            var baseType = typeof(LookupEntity);
            return baseType.Assembly.GetTypes()
                .Where(t => t.IsSubclassOf(baseType) && t.GetCustomAttributes(typeof(DescriptionAttribute), true).Any())
                .Select(b =>
                    {
                        var descriptionAttribute = b.GetCustomAttributes(typeof(DescriptionAttribute), true).FirstOrDefault() as DescriptionAttribute;
                        return new LookupMetadataDto
                        {
                            EntityClassName = b.Name,
                            Description = descriptionAttribute != null ? descriptionAttribute.Description : string.Empty
                        };
                    }
                ).ToList();
        }

        public List<LookupEntityDto> GetValuesForType(string lookupTypeName)
        {
            var lookupType = AppDomain.CurrentDomain.GetAssemblies().SelectMany(a => a.GetTypes()).FirstOrDefault(t => t.Name == lookupTypeName);
            if (lookupType == null) throw new ApplicationException(lookupTypeName + " not found!");

            return GetValuesForType(lookupType);
        }

        public List<LookupEntityDto> GetValuesForType(Type lookupType)
        {
            var getValuesMethod = GetType().GetMethod("GetValues", BindingFlags.Public | BindingFlags.Instance);
            if (getValuesMethod == null) throw new ApplicationException("GetValues method not found in LookupManager");

            var genericGetValuesMethod = getValuesMethod.MakeGenericMethod(lookupType);
            if (genericGetValuesMethod == null) throw new ApplicationException("Generic GetValues method not found in LookupManager");

            var results = genericGetValuesMethod.Invoke(this, null) as IEnumerable;
            if (results == null) throw new ApplicationException("There are no values for lookup: " + lookupType.Name);

            return results.Cast<LookupEntity>().Select(d => new LookupEntityDto(d)).ToList();
        }

        public List<LookupEntityDto> GetValuesForEnum(Enum lookupEnum)
        {
            return
                lookupEnum.GetDescriptions()
                    .Select(e => new LookupEntityDto { Id = e.Id, Code = e.EnumName, Description = e.Description })
                    .ToList();
        }

        public List<T> GetValues<T>() where T : LookupEntity
        {
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                return unitOfWork.Repository<T>().Linq().ToList();
            }
        }

        public List<LookupEntityDto> GetRGOList()
        {
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                return unitOfWork.Repository<WholesalerRegionOffice>().Linq()
                    .Where(r => r.WholesalerRegionOfficeType == WholesalerRegionOfficeTypeEnum.RGO)
                    .OrderBy(r => r.OfficeCode)
                    .Select(r => new LookupEntityDto
                    {
                        Id = r.Id,
                        Code = r.OfficeCode,
                        Description = r.WholesalerRegion.RegionName + ": " + r.OfficeName + " (" + string.Format("RGO-{0}", r.OfficeCode) + ")"
                    }
                    ).ToList();
            }
        }

        public List<LookupEntityDto> GetOccupationCodeList()
        {
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                return unitOfWork.Repository<OccupationCode>().Linq()
                    .Select(r => new LookupEntityDto
                    {
                        Id = r.Id,
                        Code = r.OccCode,
                        Description = r.Occupation
                    }
                    ).OrderBy(i=> i.Description).ToList();
            }
        }

        public List<LookupEntityDto> GetCaseCompanyLocationList(int caseId)
        {
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                return unitOfWork.Repository<CaseCompanyLocation>().Linq().Where(c=>c.Case.Id == caseId)
                    .Select(r => new LookupEntityDto
                    {
                        Id = r.Id,
                        Code = r.Case.Id.ToString(),
                        Description = r.LocationName
                    }
                    ).ToList();
            }
        }

        public List<LookupEntityDto> GetActiveBrokerAffiliationTypes()
        {
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                return unitOfWork.Repository<BrokerAffiliationType>().Linq()
                    .Where(affiliation => affiliation.Status != StatusEnum.Deleted.ToString())
                    .Select(affiliation => new LookupEntityDto
                    {
                        Id = affiliation.Id,
                        Code = affiliation.Code,
                        Description = affiliation.Description
                    })
                    .ToList();
            }
        }

    }
}
