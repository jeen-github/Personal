﻿using CMS.Interfaces.DataAccess;
using CMS.Interfaces.Managers.ReleaseManagers;
using CMS.Interfaces.Managers.SecurityManagers;
using CMS.Model.Entities;
using CMS.Model.Enums;
using Common.Exceptions;
using Logger.Static;
using System.Collections.Generic;
using System.Linq;

namespace CMS.Managers.ReleaseManagers
{
    public class ReleaseManager : IReleaseManager
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public ReleaseManager(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public List<PDRReleaseDto> GetReleaseDetailsByCaseId(int caseId)
        {
            Log.TraceFormat("+GetReleaseDetailsByCaseId caseId={0}", caseId);

            var cmsPlanDesignRequestList = new List<PDRReleaseDto>();
            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                var cmsCase = unitOfWork.Repository<Case>().Linq().FirstOrDefault(c => c.Id == caseId);
                if (cmsCase == null) throw new ValidationException("Case not found!");

                cmsPlanDesignRequestList = cmsCase.PlanDesignRequests
                    .Where(pdr => pdr.IsActive)
                    .Select(pdr => new PDRReleaseDto
                    {
                        PDRId = pdr.Id,
                        PDRHeaderName = pdr.GAPlanDesignRequestId != null ? pdr.GAPlanDesignRequestId : pdr.RequestHeaderName,
                        PlanDesignRequestStatusTypeId = (int)pdr.PlanDesignRequestStatusType,
                        PDRReleaseCount = pdr.PlanDesignRequestStatusHistories.Count(pdrsh => pdrsh.PlanDesignRequest.Id == pdr.Id && pdrsh.PlanDesignRequestStatusType == PlanDesignRequestStatusTypeEnum.Released),
                        Classes = pdr.PDRSoldClass.Any() ? GetPDRClassesForSoldPDRs(pdr.PDRSoldClass) : GetPDRClassesForActivePDRs(pdr.PlanDesignRequestClass)
                    }).ToList();
            }

            Log.TraceFormat("-GetReleaseDetailsByCaseId caseId={0}", caseId);
            return cmsPlanDesignRequestList;
        }

        private List<PDRClassReleaseDto> GetPDRClassesForSoldPDRs(IList<PDRSoldClass> pDRSoldClasses)
        {
            return pDRSoldClasses.Select(pdrc => new PDRClassReleaseDto
            {

                EligiblePopulation = GetApprovedEligibleText(pdrc.EligiblePopulationText,pdrc.PlanDesignRequestClass.ApprovedEligiblePopulationText, pdrc.PlanDesignRequestClass.RequestedEligiblePopulationText),
                EligibleParticipants = (pdrc.PlanDesignRequestClass.CensusParticipants != null) ? pdrc.PlanDesignRequestClass.CensusParticipants.Count(p => (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null)) : 0,
                GSIAmount = pdrc.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).GSIAmount,
                DiscountPercent = pdrc.PlanDesignRequestClass.PlanDesignRequestClassProducts.Any() ? GetDiscountPercent(pdrc.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).BaseDiscountType, pdrc.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).DemographicDiscountType, pdrc.PDRSoldClassPlan.FirstOrDefault(pc => pc.PDRClassPlanType == PDRClassPlanTypeEnum.Primary).EmployerPaidDiscountType) : string.Empty
            }).ToList();
        }
        private string GetApprovedEligibleText(string eligiblePopulationText, string approvedEligiblePopulationText, string requestedEligiblePopulationText)
        {
            Log.TraceFormat("+GetApprovedEligibleText");
            string approvedText = string.Empty;
            approvedText = eligiblePopulationText;
            if (string.IsNullOrEmpty(approvedText))
            {
                approvedText = approvedEligiblePopulationText != null ? approvedEligiblePopulationText : requestedEligiblePopulationText;
            }        
            Log.TraceFormat("-GetApprovedEligibleText");
            return approvedText;
        }
        private List<PDRClassReleaseDto> GetPDRClassesForActivePDRs(IList<PlanDesignRequestClass> planDesignRequestClasses)
        {
            return planDesignRequestClasses.Select(pdrc => new PDRClassReleaseDto
            {
                EligiblePopulation = pdrc.ApprovedEligiblePopulationText != null ? pdrc.ApprovedEligiblePopulationText : pdrc.RequestedEligiblePopulationText,
                EligibleParticipants = (pdrc.CensusParticipants != null) ? pdrc.CensusParticipants.Count(p => (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null)) : 0,
                GSIAmount = pdrc.PlanDesignRequestClassProducts.Any() ? pdrc.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == false).GSIAmount : 0,
                DiscountPercent = pdrc.PlanDesignRequestClassProducts.Any() ? GetDiscountPercent(pdrc.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == false).BaseDiscountType, pdrc.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == false).DemographicDiscountType, pdrc.PlanDesignRequestClassProducts.FirstOrDefault(c => c.IsGSIPlanIndicator == false).EmployerPaidDiscountType) : string.Empty
            }).ToList();
        }

        private string GetDiscountPercent(BaseDiscountType baseDiscountType, DemographicDiscountType demographicDiscountType, EmployerPaidDiscountType employerPaidDiscountType)
        {
            string caseLevelDiscountPercentage = string.Empty;
            int baseDiscountName = 0;
            int demographicDiscountName = 0;
            int employerPaidDiscountName = 0;
            if (baseDiscountType != null)
            {
                int baseDiscount = 0;
                if (int.TryParse(baseDiscountType.Code, out baseDiscount))
                {
                    baseDiscountName = baseDiscount;
                }
            }

            if (demographicDiscountType != null)
            {
                int demographicDiscount = 0;
                if (int.TryParse(demographicDiscountType.Code, out demographicDiscount))
                {
                    demographicDiscountName = demographicDiscount;
                }
            }

            if (employerPaidDiscountType != null)
            {
                int employerPaidDiscount = 0;
                if (int.TryParse(employerPaidDiscountType.Code, out employerPaidDiscount))
                {
                    employerPaidDiscountName = employerPaidDiscount;
                }
            }
            var discountName = (baseDiscountName + demographicDiscountName + employerPaidDiscountName).ToString() + "%";
            caseLevelDiscountPercentage = discountName;

            return caseLevelDiscountPercentage;
        }

        public void ValidateParticipantsForPDRApproval(List<PDRReleaseDto> pdrReleaseDtos)
        {
            Log.TraceFormat("+ValidateParticipantsForPDRApproval");

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                List<int> pdrIds = pdrReleaseDtos.Select(c => c.PDRId).ToList();
                var censusParticipants = unitOfWork.Repository<PlanDesignRequest>().Linq()
                    .Where(c => pdrIds.Contains(c.Id))
                    .SelectMany(c => c.PlanDesignRequestClass)
                    .SelectMany(c => c.CensusParticipants)
                    .ToList();

                if (censusParticipants.Any())
                {
                    var eligibleParticipants = censusParticipants.Where(p => (p.IsError == false || p.IsError == null) && (p.IsEligible == true || p.IsEligible == null)).ToList();
                    ValidateEligibleParticpants(eligibleParticipants);
                }
            }
            
            Log.TraceFormat("-ValidateParticipantsForPDRApproval");
        }

        private void ValidateEligibleParticpants(List<Participant> censusParticipants)
        {
            var errorMessages = new List<string>();
            ValidateParticpantBasedOnIssueAge(errorMessages, censusParticipants);
            ValidateParticpantBasedOnContractState(errorMessages, censusParticipants);
            ValidateParticpantBasedOnOccClass(errorMessages, censusParticipants);
            if (errorMessages.Any()) throw new ValidationException(errorMessages);
        }

        private void ValidateParticpantBasedOnIssueAge(List<string> errorMessages, List<Participant> censusParticipants)
        {
            Log.TraceFormat("+ValidateParticpantBasedOnIssueAge");

            if (censusParticipants.Where(c => c.IssueAge == null || c.IssueAge == -1).Count() > 0)
            {
                errorMessages.Add("Issue Age not determined.");
            }
            Log.TraceFormat("-ValidateParticpantBasedOnIssueAge");
        }

        private void ValidateParticpantBasedOnContractState(List<string> errorMessages, List<Participant> censusParticipants)
        {
            Log.TraceFormat("+ValidateParticpantBasedOnContractState");

            if (censusParticipants.Where(c => c.ContractState == null).Count() > 0)
            {
                errorMessages.Add("Contract State not determined.");
            }
            Log.TraceFormat("-ValidateParticpantBasedOnContractState");
        }

        private void ValidateParticpantBasedOnOccClass(List<string> errorMessages, List<Participant> censusParticipants)
        {
            Log.TraceFormat("+ValidateParticpantBasedOnOccClass");

            if (censusParticipants.Where(c => c.OccupationClass_Id == null).Count() > 0)
            {
                errorMessages.Add("Assign Occ Class to eligible participants prior to PDR Approval.");
            }
            Log.TraceFormat("-ValidateParticpantBasedOnOccClass");
        }

        public List<UserInfoDto> GetUnderWriterInfo()
        {
            Log.TraceFormat("+GetUnderWriterInfo");

            List<UserInfoDto> userInfo;

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                int groupId = UserGroup.Group_Underwriting;

                userInfo = unitOfWork.Repository<CmsUser>().Linq().Where(c => c.UserGroups.Where(ug => groupId == ug.Id).Count() > 0).Select(t => new UserInfoDto
                {
                    TitanUserId = t.Id,
                    Name = string.Format("{0} {1}", t.LastName, t.FirstName)
                }).ToList();

            }

            Log.TraceFormat("-GetUnderWriterInfo");

            return userInfo;
        }

        public void ValidateSoldPDR(List<PDRReleaseDto> pdrReleaseDtos)
        {
            Log.TraceFormat("+ValidateSoldPDR");

            var errorMessages = new List<string>();

            using (var unitOfWork = _unitOfWorkFactory.CreateUnitOfWork())
            {
                List<int> pdrIds = pdrReleaseDtos.Select(c => c.PDRId).ToList();
                var pdrlist = unitOfWork.Repository<PDRSoldClass>().Linq()
                    .Where(c => pdrIds.Contains(c.Id))                   
                    .ToList();
                if (pdrlist.Any())
                {
                    errorMessages.Add("Cannot decline a Sold PDR.");
                }
                if (errorMessages.Any()) throw new ValidationException(errorMessages);
            }

            Log.TraceFormat("-ValidateSoldPDR");
        }
    }
}
